package com.novan.filemanagermax

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/** Editor teks bawaan. Dapat membuka berkas lokal (bisa disimpan) atau Uri dari aplikasi lain (hanya baca). */
class TextEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        private const val MAX_BYTES = 2L * 1024 * 1024
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var edit: EditText
    private var file: File? = null
    private var uri: Uri? = null
    private var loaded = false
    private var dirty = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_editor)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        edit = findViewById(R.id.editor)

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path != null) {
            file = File(path)
        } else {
            val d = intent.data
            if (d != null && d.scheme == "file" && d.path != null) file = File(d.path!!) else uri = d
        }
        title = file?.name ?: uri?.lastPathSegment ?: getString(R.string.text_editor)
        if (file == null) edit.inputType = InputType.TYPE_NULL

        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loaded) dirty = true
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                confirmExit()
            }
        })
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun load() {
        executor.execute {
            var text: String? = null
            var err: String? = null
            try {
                val f = file
                if (f != null) {
                    if (f.length() > MAX_BYTES) err = getString(R.string.editor_too_large)
                    else text = f.readText()
                } else if (uri != null) {
                    contentResolver.openInputStream(uri!!)?.use { ins ->
                        val bytes = ins.readBytes()
                        if (bytes.size > MAX_BYTES) err = getString(R.string.editor_too_large)
                        else text = String(bytes, Charsets.UTF_8)
                    }
                }
            } catch (e: Exception) {
                err = getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                if (text != null) {
                    edit.setText(text)
                    loaded = true
                    dirty = false
                    invalidateOptionsMenu()
                } else {
                    say(err ?: getString(R.string.cannot_open))
                }
            }
        }
    }

    private fun save(after: (() -> Unit)? = null) {
        val f = file
        if (f == null) { say(getString(R.string.editor_readonly)); return }
        val text = edit.text.toString()
        executor.execute {
            val msg = try {
                f.writeText(text)
                dirty = false
                getString(R.string.saved)
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isDestroyed) return@post
                say(msg)
                if (!dirty) after?.invoke()
            }
        }
    }

    private fun confirmExit() {
        if (!dirty) { finish(); return }
        AlertDialog.Builder(this)
            .setTitle(R.string.unsaved_title)
            .setMessage(R.string.unsaved_message)
            .setPositiveButton(R.string.action_save) { _, _ -> save { finish() } }
            .setNegativeButton(R.string.discard) { _, _ -> dirty = false; finish() }
            .setNeutralButton(R.string.cancel, null)
            .show()
    }

    private fun promptFind() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.search_hint)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.editor_find)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> find(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private var lastQuery = ""

    private fun find(q: String) {
        if (q.isEmpty()) return
        lastQuery = q
        val text = edit.text.toString()
        var from = edit.selectionEnd.coerceAtLeast(0)
        var i = text.indexOf(q, from, ignoreCase = true)
        if (i < 0 && from > 0) i = text.indexOf(q, 0, ignoreCase = true)
        if (i < 0) { say(getString(R.string.editor_not_found)); return }
        edit.requestFocus()
        edit.setSelection(i, i + q.length)
        val line = text.substring(0, i).count { it == '\n' } + 1
        say(getString(R.string.editor_found_line, line))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.editor_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_save).isVisible = file != null
        menu.findItem(R.id.action_find_next).isVisible = lastQuery.isNotEmpty()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> confirmExit()
            R.id.action_save -> save()
            R.id.action_find -> promptFind()
            R.id.action_find_next -> find(lastQuery)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
