package org.telegram.messenger;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.net.Uri;
import android.system.Os;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.SparseArray;
import android.text.TextUtils;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.IdentityHashMap;
import java.util.Locale;

import org.telegram.tgnet.TLObject;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.ChatActivity;

/**
 * Novan Tel - titik editan (tahap 3).
 *
 * ConnectionsManager.sendRequest(...) memanggil NovanMod.blokir(permintaan) lebih dulu.
 * Bila hasilnya true, permintaan tidak dikirim ke server. Dari satu titik ini kita mendapat:
 *  - mode hantu: tidak menandai terbaca, tidak tampil mengetik, tidak tampil online,
 *    cerita dilihat tanpa jejak, pesan suara didengar tanpa jejak
 *  - blokir pesan bersponsor
 *  - unduh otomatis pesan suara (tahap 5), lewat kait di DownloadController
 *
 * Nilai konstanta di bawah adalah BAWAAN dari build (diisi tools/terapkan.py dari novan-mod.properties).
 * Pilihan pengguna di layar "Pengaturan Novan Tel" disimpan di SharedPreferences dan menimpa bawaan,
 * tanpa perlu membangun ulang.
 *
 * Kualitas pesan suara dikirim ke kode native lewat variabel lingkungan NOVAN_BITRATE.
 */
public class NovanMod {

    public static final boolean HANTU_BACA = __HANTU_BACA__;
    public static final boolean HANTU_MENGETIK = __HANTU_MENGETIK__;
    public static final boolean HANTU_ONLINE = __HANTU_ONLINE__;
    public static final boolean HANTU_CERITA = __HANTU_CERITA__;
    public static final boolean HANTU_KONTEN = __HANTU_KONTEN__;
    public static final boolean BLOKIR_IKLAN = __BLOKIR_IKLAN__;
    public static final boolean ANTI_HAPUS = __ANTI_HAPUS__;
    public static final boolean UNDUH_SUARA = __UNDUH_SUARA__;
    public static final boolean SIMPAN_UNDUHAN = __SIMPAN_UNDUHAN__;
    public static final boolean TERUSKAN_TANPA_KUTIPAN = __TERUSKAN_TANPA_KUTIPAN__;
    public static final boolean SALIN_SEBAGIAN = __SALIN_SEBAGIAN__;
    /** Tombol 'Simpan ke Unduhan' di bilah atas saat memilih banyak pesan (tahap 15). */
    public static final boolean SIMPAN_BANYAK = __SIMPAN_BANYAK__;
    /** Tombol 'Menuju ke pesan' di daftar berkas info grup/kanal (tahap 15). */
    public static final boolean TOMBOL_KE_PESAN = __TOMBOL_KE_PESAN__;
    /** Nomor item bilah atas (mode pilih) milik Novan Tel. */
    public static final int OPSI_SIMPAN_BANYAK = 9063;
    /** Nomor pilihan menu 'Salin sebagian teks'. */
    public static final int OPSI_SALIN = 9062;
    /** Baris 'Transkripsi' di menu pesan suara dan video bulat (tahap 16, lewat Groq Whisper). */
    public static final boolean TRANSKRIPSI = __TRANSKRIPSI__;
    /** Nomor pilihan menu 'Transkripsi'. */
    public static final int OPSI_TRANSKRIP = 9064;
    /** Nomor item 'Transkripsi' di bilah atas (mode pilih). */
    public static final int OPSI_TRANSKRIP_ATAS = 9065;
    /** Folder di dalam Download tempat "Simpan ke Unduhan" menaruh berkas (dibuat otomatis). */
    public static final String FOLDER_UNDUHAN = "__FOLDER_UNDUHAN__";
    /** Nomor pilihan menu tekan-tahan milik Novan Tel (dipakai kait di ChatActivity). */
    public static final int OPSI_SIMPAN = 9061;
    public static final String KUALITAS_SUARA = "__KUALITAS_SUARA__";
    /** Efek pesan suara (gema, pengubah suara) terpasang di build ini? Diisi false oleh terapkan.py bila tambalan tidak cocok. */
    public static final boolean EFEK_SUARA = __EFEK_SUARA__;

    /** Tahap 39: Penghematan Daya bawaan: mode hemat daya Mati dan semua opsi (animasi, efek, putar otomatis, partikel, transisi halus) Mati. */
    public static final boolean HEMAT_DAYA_MATI = __HEMAT_DAYA_MATI__;

    public static final String PREF = "novan_mod";

    private static volatile boolean dimuat = false;
    private static volatile boolean hBaca = HANTU_BACA;
    private static volatile boolean hMengetik = HANTU_MENGETIK;
    private static volatile boolean hOnline = HANTU_ONLINE;
    private static volatile boolean hCerita = HANTU_CERITA;
    private static volatile boolean hKonten = HANTU_KONTEN;
    private static volatile boolean bIklan = BLOKIR_IKLAN;
    private static volatile boolean aHapus = ANTI_HAPUS;
    private static volatile boolean uSuara = UNDUH_SUARA;
    private static volatile boolean sUnduhan = SIMPAN_UNDUHAN;
    private static volatile boolean tKutipan = TERUSKAN_TANPA_KUTIPAN;
    private static volatile boolean sSalin = SALIN_SEBAGIAN;

    private NovanMod() {
    }

    /** Baca pilihan pengguna (atau bawaan build) dan pasang kualitas suara. */
    public static void muat() {
        muat(ApplicationLoader.applicationContext);
    }

    public static synchronized void muat(Context c) {
        if (c == null) {
            return;
        }
        try {
            SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            hBaca = p.getBoolean("hantu_baca", HANTU_BACA);
            hMengetik = p.getBoolean("hantu_mengetik", HANTU_MENGETIK);
            hOnline = p.getBoolean("hantu_online", HANTU_ONLINE);
            hCerita = p.getBoolean("hantu_cerita", HANTU_CERITA);
            hKonten = p.getBoolean("hantu_konten", HANTU_KONTEN);
            bIklan = p.getBoolean("blokir_iklan", BLOKIR_IKLAN);
            aHapus = p.getBoolean("anti_hapus", ANTI_HAPUS);
            uSuara = p.getBoolean("unduh_suara", UNDUH_SUARA);
            sUnduhan = p.getBoolean("simpan_unduhan", SIMPAN_UNDUHAN);
            tKutipan = p.getBoolean("teruskan_tanpa_kutipan", TERUSKAN_TANPA_KUTIPAN);
            sSalin = p.getBoolean("salin_sebagian", SALIN_SEBAGIAN);
            pasangKualitas(p.getString("kualitas_suara", KUALITAS_SUARA));
            dimuat = true;
            if (HEMAT_DAYA_MATI && !p.getBoolean("hemat_daya_mati_v1", false)) {
                // sekali saja per pemasangan; setelah itu pilihan pengguna di Pengaturan Telegram dihormati
                hematDayaMati();
                p.edit().putBoolean("hemat_daya_mati_v1", true).apply();
            }
        } catch (Throwable ignored) {
        }
        try {
            NovanKategori.mulai();
        } catch (Throwable ignored) {
        }
    }

    /** Pengaturan > Penghematan Daya: mode hemat daya Mati (geser ke kiri) dan semua sakelar opsi Mati. Lewat refleksi supaya tahan beda nama. */
    private static void hematDayaMati() {
        try {
            Class<?> lm = Class.forName("org.telegram.messenger.LiteMode");
            try {
                lm.getMethod("loadPreference").invoke(null);
            } catch (Throwable ignored) {
            }
            lm.getMethod("setAllFlags", boolean.class).invoke(null, false);
            lm.getMethod("setPowerSaverLevel", int.class).invoke(null, 0);
        } catch (Throwable ignored) {
        }
        try {
            // sakelar "Aktifkan Transisi Halus"
            Class<?> sc = Class.forName("org.telegram.messenger.SharedConfig");
            sc.getMethod("setAnimationsEnabled", boolean.class).invoke(null, false);
        } catch (Throwable t) {
            try {
                MessagesController.getGlobalMainSettings().edit().putBoolean("view_animations", false).apply();
            } catch (Throwable ignored) {
            }
        }
    }

    /** Nilai variabel lingkungan untuk kode native: angka bps, atau "asli" = biarkan seperti Telegram. */
    public static String nilaiBitrate(String kualitas) {
        if ("asli".equals(kualitas)) {
            return "asli";
        }
        if ("terendah".equals(kualitas)) {
            return "18000";
        }
        if ("sedang".equals(kualitas)) {
            return "48000";
        }
        if ("tinggi".equals(kualitas)) {
            return "64000";
        }
        return "32000";
    }

    private static void pasangKualitas(String kualitas) {
        try {
            Os.setenv("NOVAN_BITRATE", nilaiBitrate(kualitas), true);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Efek pesan suara ini dicentang di Pengaturan Novan Tel? Bawaan tidak (false). Dibaca NovanEfek saat rekaman dimulai,
     * jadi pilihan berlaku untuk rekaman berikutnya.
     */
    public static boolean efekDipilih(String id) {
        return EFEK_SUARA && pilihanAktif("efek_" + id);
    }

    /** Nilai teks dari pilihan pengguna, atau null bila belum pernah diatur. */
    public static String teksPref(String kunci) {
        try {
            Context c = ApplicationLoader.applicationContext;
            return c == null ? null : c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(kunci, null);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Unduh otomatis pesan suara aktif? Dipakai kait di DownloadController (semua jaringan, semua jenis obrolan). */
    public static boolean unduhSuaraAktif() {
        if (!dimuat) {
            muat();
        }
        return uSuara;
    }

    /** true = pesan ini pesan suara dan harus diunduh otomatis. */
    public static boolean unduhSuara(TLRPC.Message pesan) {
        try {
            return pesan != null && unduhSuaraAktif() && MessageObject.isVoiceMessage(pesan);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean unduhSuara(MessageObject pesan) {
        return pesan != null && unduhSuara(pesan.messageOwner);
    }

    // ------------------------------------------------------------ fitur ala TurboTel (tahap 10)

    /** Bawaan layar teruskan: sembunyikan nama pengirim (tanpa kutipan). Dipakai sebagai nilai awal di kode Telegram. */
    public static boolean teruskanTanpaKutipan() {
        if (!dimuat) {
            muat();
        }
        return tKutipan;
    }

    /** Tampilkan baris "Salin sebagian teks" untuk pesan ini? Hanya bila sakelar nyala dan pesan punya teks. */
    public static boolean bisaSalinSebagian(MessageObject m) {
        if (!dimuat) {
            muat();
        }
        return sSalin && m != null && m.messageOwner != null && !TextUtils.isEmpty(m.messageOwner.message);
    }

    /** Tampilkan baris \"Transkripsi\" untuk pesan ini? Hanya pesan suara dan video bulat. */
    public static boolean bisaTranskripsi(MessageObject m) {
        return NovanTranskripsi.bisa(m);
    }

    /** Transkripsi pesan suara (dan terjemahan) lewat Groq; hasilnya tampil di kotak teks. */
    public static void transkripsi(Activity act, MessageObject m) {
        NovanTranskripsi.mulai(act, m);
    }

    /** Simpan teks sebagai berkas txt di Download/Telegram Novan. Jalankan di thread latar. */
    static boolean simpanTeks(Context ctx, String nama, String teks) {
        try {
            return tulisKeUnduhan(ctx, nama, "text/plain", null, teks.getBytes("UTF-8"));
        } catch (Throwable e) {
            return false;
        }
    }

    private static void salinKePapanKlip(Context c, String teks, String ket) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("pesan", teks));
            Toast.makeText(c, ket, Toast.LENGTH_SHORT).show();
        } catch (Throwable e) {
            Toast.makeText(c, "Gagal menyalin", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Kotak teks yang bisa dipilih (ramah TalkBack): pilih sebagian teks lalu "Salin pilihan";
     * bila tidak ada yang dipilih, seluruh teks disalin.
     */
    public static void salinSebagian(final Activity act, MessageObject m) {
        if (act == null || m == null || m.messageOwner == null || TextUtils.isEmpty(m.messageOwner.message)) {
            return;
        }
        final String teks = m.messageOwner.message;
        final android.widget.EditText et = new android.widget.EditText(act);
        et.setText(teks);
        et.setKeyListener(null);
        et.setTextIsSelectable(true);
        et.setFocusable(true);
        et.setFocusableInTouchMode(true);
        et.setTextSize(17);
        et.setContentDescription("Teks pesan");
        int pad = (int) (16 * act.getResources().getDisplayMetrics().density + 0.5f);
        et.setPadding(pad, pad, pad, pad);
        android.widget.ScrollView sv = new android.widget.ScrollView(act);
        sv.addView(et);
        new android.app.AlertDialog.Builder(act)
                .setTitle("Salin sebagian teks")
                .setMessage("Pilih bagian teks, lalu tekan Salin pilihan. Bila tidak ada yang dipilih, seluruh teks disalin.")
                .setView(sv)
                .setPositiveButton("Salin pilihan", (d, w) -> {
                    int a = et.getSelectionStart();
                    int b = et.getSelectionEnd();
                    if (a < 0 || b < 0 || a == b) {
                        salinKePapanKlip(act, teks, "Seluruh teks tersalin");
                    } else {
                        salinKePapanKlip(act, teks.substring(Math.min(a, b), Math.max(a, b)), "Teks pilihan tersalin");
                    }
                })
                .setNeutralButton("Salin semua", (d, w) -> salinKePapanKlip(act, teks, "Seluruh teks tersalin"))
                .setNegativeButton("Tutup", null)
                .show();
    }

    // ------------------------------------------------------------ simpan ke Unduhan (tahap 6)

    /** Berkas pesan di HP, atau null bila belum terunduh. */
    static File berkasPesan(MessageObject m) {
        try {
            if (m == null || m.messageOwner == null) {
                return null;
            }
            String ap = m.messageOwner.attachPath;
            if (!TextUtils.isEmpty(ap)) {
                File a = new File(ap);
                if (a.exists() && a.length() > 0) {
                    return a;
                }
            }
            File g = FileLoader.getInstance(m.currentAccount).getPathToMessage(m.messageOwner);
            if (g != null && g.exists() && g.length() > 0) {
                return g;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Pesan teks murni (tanpa lampiran)? Pesan seperti itu disimpan sebagai berkas txt. */
    private static boolean tanpaLampiran(MessageObject m) {
        try {
            return m != null && m.messageOwner != null && (m.messageOwner.media == null || m.type == 0);
        } catch (Throwable e) {
            return false;
        }
    }

    /** Teks pesan untuk disimpan sebagai txt, atau null bila pesan bukan teks atau kosong. */
    private static String teksUntukSimpan(MessageObject m) {
        try {
            if (!tanpaLampiran(m)) {
                return null;
            }
            String t = m.messageOwner.message;
            if (TextUtils.isEmpty(t) && m.messageOwner.media == null && m.messageText != null) {
                t = m.messageText.toString();
            }
            if (t == null) {
                return null;
            }
            t = t.trim();
            return t.isEmpty() ? null : t;
        } catch (Throwable e) {
            return null;
        }
    }

    /** Tampilkan baris "Simpan ke Unduhan" di menu pesan ini? Bila sakelar nyala dan berkas sudah ada di HP, atau pesannya teks. */
    public static boolean bisaSimpan(MessageObject m) {
        if (!dimuat) {
            muat();
        }
        return sUnduhan && (berkasPesan(m) != null || teksUntukSimpan(m) != null);
    }

    private static String ekstensi(String nama) {
        int t = nama == null ? -1 : nama.lastIndexOf('.');
        return t >= 0 && t < nama.length() - 1 ? nama.substring(t + 1).toLowerCase() : "";
    }

    /** Tulis satu berkas (dari berkas sumber atau isi teks) ke Download/Telegram Novan. Jalankan di thread latar. */
    private static boolean tulisKeUnduhan(Context ctx, String nama, String mime, File sumber, byte[] isi) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, nama);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER_UNDUHAN);
                Uri u = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) {
                    return false;
                }
                try (OutputStream o = ctx.getContentResolver().openOutputStream(u)) {
                    salinKe(o, sumber, isi);
                }
                return true;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            dir = new File(dir, FOLDER_UNDUHAN);
            dir.mkdirs();
            File tujuan = new File(dir, nama);
            int n = 1;
            String dasar = nama;
            String ek = "";
            int t = nama.lastIndexOf('.');
            if (t > 0) {
                dasar = nama.substring(0, t);
                ek = nama.substring(t);
            }
            while (tujuan.exists()) {
                tujuan = new File(dir, dasar + " (" + (n++) + ")" + ek);
            }
            try (OutputStream o = new java.io.FileOutputStream(tujuan)) {
                salinKe(o, sumber, isi);
            }
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static void salinKe(OutputStream o, File sumber, byte[] isi) throws java.io.IOException {
        if (o == null) {
            throw new java.io.IOException("tujuan tidak bisa dibuka");
        }
        if (isi != null) {
            o.write(isi);
            o.flush();
            return;
        }
        try (InputStream i = new FileInputStream(sumber)) {
            salin(i, o);
        }
    }

    /**
     * Simpan satu pesan ke folder Download/Telegram Novan: berkasnya bila sudah terunduh, atau teksnya sebagai
     * berkas txt. Mengembalikan nama berkas yang tersimpan, atau null bila tidak ada yang bisa disimpan / gagal.
     * Berkas asli Telegram tidak diubah. Jalankan di thread latar.
     */
    private static String simpanSatu(Context ctx, MessageObject m) {
        File sumber = berkasPesan(m);
        String nama;
        String mime;
        byte[] isi = null;
        if (sumber != null) {
            nama = sumber.getName();
            String ext = ekstensi(nama);
            boolean suara = false;
            try {
                suara = MessageObject.isVoiceMessage(m.messageOwner);
            } catch (Throwable ignored) {
            }
            if (suara) {
                nama = "pesan_suara_" + (m.getId() > 0 ? m.getId() : System.currentTimeMillis()) + ".ogg";
                ext = "ogg";
            } else if (ext.isEmpty()) {
                nama = nama + ".bin";
            }
            mime = "ogg".equals(ext) ? "audio/ogg" : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (mime == null) {
                mime = "application/octet-stream";
            }
        } else {
            String teks = teksUntukSimpan(m);
            if (teks == null) {
                return null;
            }
            long detik = 0;
            try {
                detik = m.messageOwner.date;
            } catch (Throwable ignored) {
            }
            String waktu = detik > 0
                    ? new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(detik * 1000L))
                    : String.valueOf(System.currentTimeMillis());
            nama = "pesan_" + waktu + "_" + m.getId() + ".txt";
            mime = "text/plain";
            try {
                isi = teks.getBytes("UTF-8");
            } catch (Throwable e) {
                return null;
            }
        }
        return tulisKeUnduhan(ctx, nama, mime, sumber, isi) ? nama : null;
    }

    private static void toastUI(final Context ctx, final String pesan) {
        AndroidUtilities.runOnUIThread(() -> Toast.makeText(ctx, pesan, Toast.LENGTH_LONG).show());
    }

    /** Menu tekan-tahan satu pesan: simpan berkasnya (atau teksnya sebagai txt) ke folder Unduhan. */
    public static void simpanKeUnduhan(final Activity act, final MessageObject m) {
        final Context c = act != null ? act : ApplicationLoader.applicationContext;
        if (c == null) {
            return;
        }
        if (berkasPesan(m) == null && teksUntukSimpan(m) == null) {
            Toast.makeText(c, "Berkas belum terunduh, tidak bisa disimpan", Toast.LENGTH_SHORT).show();
            return;
        }
        final Context ctx = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        new Thread(() -> {
            String nama = simpanSatu(ctx, m);
            toastUI(ctx, nama != null ? "Tersimpan di folder " + FOLDER_UNDUHAN + ": " + nama : "Gagal menyimpan ke Unduhan");
        }).start();
    }

    // ------------------------------------------------------------ simpan banyak pesan (tahap 15)

    private static void kumpul(Object o, ArrayList<MessageObject> hasil, IdentityHashMap<Object, Boolean> terlihat) {
        if (o == null) {
            return;
        }
        if (o instanceof MessageObject) {
            if (terlihat.put(o, Boolean.TRUE) == null) {
                hasil.add((MessageObject) o);
            }
        } else if (o instanceof SparseArray) {
            SparseArray<?> a = (SparseArray<?>) o;
            for (int i = 0; i < a.size(); i++) {
                kumpul(a.valueAt(i), hasil, terlihat);
            }
        } else if (o instanceof LongSparseArray) {
            LongSparseArray<?> a = (LongSparseArray<?>) o;
            for (int i = 0; i < a.size(); i++) {
                kumpul(a.valueAt(i), hasil, terlihat);
            }
        } else if (o instanceof Object[]) {
            for (Object e : (Object[]) o) {
                kumpul(e, hasil, terlihat);
            }
        } else if (o instanceof Collection) {
            for (Object e : (Collection<?>) o) {
                kumpul(e, hasil, terlihat);
            }
        }
    }

    /** Semua MessageObject di struktur pilihan (SparseArray, array SparseArray, daftar), tanpa duplikat. */
    private static ArrayList<MessageObject> pesanTerpilih(Object terpilih) {
        ArrayList<MessageObject> hasil = new ArrayList<>();
        try {
            kumpul(terpilih, hasil, new IdentityHashMap<>());
        } catch (Throwable ignored) {
        }
        return hasil;
    }

    /**
     * Dipanggil dari updateActionModeTitle() (tiap pilihan berubah): item 'Transkripsi' di bilah atas hanya terlihat
     * bila tepat satu pesan suara/video bulat terpilih. Tanpa pemeriksaan berkala.
     */
    private static java.lang.ref.WeakReference<View> itemTranskripsiAtas;
    private static Runnable tugasPerbaruiTranskrip;

    /** Dipanggil saat item dibuat: simpan rujukan langsung ke tampilannya (tidak bergantung pencarian lewat tag). */
    public static void daftarItemTranskripsi(View item) {
        itemTranskripsiAtas = item == null ? null : new java.lang.ref.WeakReference<View>(item);
    }

    /**
     * Dipanggil di awal addToSelectedMessages (tiap pesan dipilih atau dilepas). Pilihan baru terisi setelah metode itu
     * selesai, jadi pembaruan dijalankan sebentar kemudian (dua kali: segera dan setelah animasi bilah atas).
     */
    public static void jadwalPerbaruiTranskripsi(final org.telegram.ui.ActionBar.ActionBar bar, final Object terpilih) {
        try {
            if (tugasPerbaruiTranskrip != null) {
                AndroidUtilities.cancelRunOnUIThread(tugasPerbaruiTranskrip);
            }
            final Runnable ulang = new Runnable() {
                @Override
                public void run() {
                    perbaruiTranskripsiAtas(bar, terpilih);
                }
            };
            tugasPerbaruiTranskrip = new Runnable() {
                @Override
                public void run() {
                    perbaruiTranskripsiAtas(bar, terpilih);
                    AndroidUtilities.runOnUIThread(ulang, 350);
                }
            };
            AndroidUtilities.runOnUIThread(tugasPerbaruiTranskrip, 60);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Item 'Transkripsi' di bilah atas hanya terlihat bila tepat satu pesan suara/video bulat terpilih.
     * Dipanggil dari updateActionModeTitle() dan dari jadwalPerbaruiTranskripsi() (addToSelectedMessages).
     */
    public static void perbaruiTranskripsiAtas(org.telegram.ui.ActionBar.ActionBar bar, Object terpilih) {
        try {
            View item = itemTranskripsiAtas == null ? null : itemTranskripsiAtas.get();
            if (item == null && bar != null) {
                item = bar.createActionMode().getItem(OPSI_TRANSKRIP_ATAS);
            }
            if (item == null) {
                return;
            }
            ArrayList<MessageObject> d = pesanTerpilih(terpilih);
            int mau = (d.size() == 1 && NovanTranskripsi.bisa(d.get(0))) ? View.VISIBLE : View.GONE;
            if (item.getVisibility() != mau) {
                item.setVisibility(mau);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Item 'Transkripsi' di bilah atas mode pilih: hanya bila tepat satu pesan suara/video bulat terpilih. */
    public static void transkripsiTerpilih(Activity act, Object terpilih) {
        final Context c = act != null ? act : ApplicationLoader.applicationContext;
        if (c == null) {
            return;
        }
        ArrayList<MessageObject> daftar = pesanTerpilih(terpilih);
        if (daftar.size() == 1 && !NovanTranskripsi.menuAktif()) {
            Toast.makeText(c, "Transkripsi sedang dimatikan di Pengaturan Novan Tel", Toast.LENGTH_LONG).show();
            return;
        }
        if (daftar.size() != 1 || !NovanTranskripsi.bisa(daftar.get(0))) {
            Toast.makeText(c, "Pilih satu pesan suara atau video bulat untuk transkripsi", Toast.LENGTH_LONG).show();
            return;
        }
        NovanTranskripsi.mulai(act, daftar.get(0));
    }

    /**
     * Item 'Simpan ke Unduhan' di bilah atas ChatActivity saat memilih pesan (tekan-tahan lalu ketuk pesan lain).
     * Pesan terunduh disalin berkasnya, pesan teks jadi berkas txt, urut dari yang terlama.
     */
    public static void simpanTerpilih(Activity act, Object terpilih) {
        final Context c = act != null ? act : ApplicationLoader.applicationContext;
        if (c == null) {
            return;
        }
        if (!dimuat) {
            muat();
        }
        if (!sUnduhan) {
            Toast.makeText(c, "Simpan ke Unduhan sedang dimatikan di Pengaturan Novan Tel", Toast.LENGTH_LONG).show();
            return;
        }
        final ArrayList<MessageObject> daftar = pesanTerpilih(terpilih);
        if (daftar.isEmpty()) {
            Toast.makeText(c, "Tidak ada pesan yang dipilih", Toast.LENGTH_SHORT).show();
            return;
        }
        Collections.sort(daftar, (x, y) -> Integer.compare(x.getId(), y.getId()));
        final Context ctx = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        Toast.makeText(ctx, "Menyimpan " + daftar.size() + " pesan...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            int ok = 0;
            int lewat = 0;
            int gagal = 0;
            for (MessageObject m : daftar) {
                if (berkasPesan(m) == null && teksUntukSimpan(m) == null) {
                    lewat++;
                    continue;
                }
                if (simpanSatu(ctx, m) != null) {
                    ok++;
                } else {
                    gagal++;
                }
            }
            StringBuilder sb = new StringBuilder();
            if (ok > 0) {
                sb.append(ok).append(" berkas tersimpan di folder ").append(FOLDER_UNDUHAN);
            } else {
                sb.append("Tidak ada yang tersimpan");
            }
            if (lewat > 0) {
                sb.append(". ").append(lewat).append(" pesan dilewati karena berkasnya belum terunduh");
            }
            if (gagal > 0) {
                sb.append(". ").append(gagal).append(" gagal disimpan");
            }
            toastUI(ctx, sb.toString());
        }).start();
    }

    // ------------------------------------------------------------ tombol 'Menuju ke pesan' di daftar berkas (tahap 15)

    /**
     * Dipanggil di akhir konstruktor SharedMediaLayout (daftar Media/Berkas/Musik di info grup, kanal, dan profil).
     * Menambah tombol 'Menuju ke pesan' di bilah mode pilih (muncul setelah tekan-tahan satu berkas). Semua
     * parameter bertipe Object supaya kait tidak bergantung pada tipe asli di kode Telegram.
     */
    public static void pasangKePesan(Object bar, Object tombolBawaan, Object terpilih, Object fragmen, Object konteks) {
        try {
            if (!TOMBOL_KE_PESAN) {
                return;
            }
            View acuan = tombolBawaan instanceof View ? (View) tombolBawaan : null;
            ViewGroup induk = bar instanceof ViewGroup ? (ViewGroup) bar : null;
            if (induk == null && acuan != null && acuan.getParent() instanceof ViewGroup) {
                induk = (ViewGroup) acuan.getParent();
            }
            if (!(induk instanceof LinearLayout)) {
                Log.w("NovanMod", "Tombol Menuju ke pesan: bilah mode pilih tidak ditemukan");
                return;
            }
            final Context cx = konteks instanceof Context ? (Context) konteks : induk.getContext();
            final BaseFragment f = fragmen instanceof BaseFragment ? (BaseFragment) fragmen : null;
            final ImageView v = new ImageView(cx);
            int ikon = cx.getResources().getIdentifier("msg_message", "drawable", cx.getPackageName());
            if (ikon == 0) {
                ikon = android.R.drawable.ic_menu_directions;
            }
            v.setImageResource(ikon);
            v.setScaleType(ImageView.ScaleType.CENTER);
            boolean terang = true;
            if (induk.getBackground() instanceof ColorDrawable) {
                int w = ((ColorDrawable) induk.getBackground()).getColor();
                terang = (Color.red(w) * 299 + Color.green(w) * 587 + Color.blue(w) * 114) / 1000 > 140;
            }
            v.setColorFilter(terang ? 0xFF676A6F : 0xFFFFFFFF);
            try {
                TypedValue tv = new TypedValue();
                if (cx.getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
                    v.setBackgroundResource(tv.resourceId);
                }
            } catch (Throwable ignored) {
            }
            v.setContentDescription("Menuju ke pesan");
            v.setFocusable(true);
            v.setOnClickListener(x -> menujuKePesan(cx, terpilih, f));
            int idx = acuan != null && acuan.getParent() == induk ? induk.indexOfChild(acuan) + 1 : induk.getChildCount();
            induk.addView(v, idx, new LinearLayout.LayoutParams(AndroidUtilities.dp(54), ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Throwable t) {
            Log.w("NovanMod", "Tombol Menuju ke pesan gagal dipasang", t);
        }
    }

    private static BaseFragment fragmenTerakhir() {
        try {
            Class<?> k = Class.forName("org.telegram.ui.LaunchActivity");
            for (String nama : new String[]{"getSafeLastFragment", "getLastFragment"}) {
                try {
                    Object r = k.getMethod(nama).invoke(null);
                    if (r instanceof BaseFragment) {
                        return (BaseFragment) r;
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Buka obrolan asal berkas yang dipilih, langsung di pesan yang mengirimnya. */
    private static void menujuKePesan(Context cx, Object terpilih, BaseFragment f) {
        try {
            ArrayList<MessageObject> d = pesanTerpilih(terpilih);
            if (d.size() != 1) {
                Toast.makeText(cx, d.isEmpty() ? "Pilih satu berkas dulu" : "Pilih satu berkas saja untuk menuju ke pesannya", Toast.LENGTH_SHORT).show();
                return;
            }
            MessageObject m = d.get(0);
            long did = m.getDialogId();
            if (did == 0) {
                Toast.makeText(cx, "Pesan asal berkas tidak diketahui", Toast.LENGTH_SHORT).show();
                return;
            }
            Bundle args = new Bundle();
            if (did < 0) {
                args.putLong("chat_id", -did);
            } else {
                args.putLong("user_id", did);
            }
            args.putInt("message_id", m.getId());
            BaseFragment induk = f != null ? f : fragmenTerakhir();
            if (induk == null) {
                Toast.makeText(cx, "Gagal membuka pesan", Toast.LENGTH_SHORT).show();
                return;
            }
            induk.presentFragment(new ChatActivity(args));
        } catch (Throwable t) {
            Log.w("NovanMod", "Menuju ke pesan gagal", t);
            Toast.makeText(cx, "Gagal membuka pesan", Toast.LENGTH_SHORT).show();
        }
    }

    private static void salin(InputStream i, OutputStream o) throws java.io.IOException {
        if (o == null) {
            throw new java.io.IOException("tujuan tidak bisa dibuka");
        }
        byte[] b = new byte[16384];
        int n;
        while ((n = i.read(b)) > 0) {
            o.write(b, 0, n);
        }
        o.flush();
    }

    /** Anti hapus aktif? Dipakai kait di MessagesController (pesan dihapus lawan bicara lewat notifikasi dorong). */
    public static boolean tahanHapus() {
        if (!dimuat) {
            muat();
        }
        return aHapus;
    }

    /**
     * Anti hapus untuk pembaruan dari server: true = lewati pembaruan "pesan dihapus" ini, sehingga
     * pesan tetap ada di HP. Penghapusan yang Anda lakukan sendiri tidak lewat jalur ini.
     */
    public static boolean tahanHapus(TLObject pembaruan) {
        return tahanHapus(-1, pembaruan);
    }

    /** Sama seperti di atas, dan mencatat pesan yang ditahan supaya bisa ditandai "dihapus" (akun >= 0). */
    public static boolean tahanHapus(int akun, TLObject pembaruan) {
        if (pembaruan == null || !tahanHapus()) {
            return false;
        }
        String nama = pembaruan.getClass().getSimpleName();
        boolean biasa = "TL_updateDeleteMessages".equals(nama);
        boolean kanal = "TL_updateDeleteChannelMessages".equals(nama);
        if (!biasa && !kanal) {
            return false;
        }
        if (akun >= 0) {
            try {
                if (pembaruan instanceof org.telegram.tgnet.tl.TL_update.TL_updateDeleteMessages) {
                    catatDihapus(akun, 0, ((org.telegram.tgnet.tl.TL_update.TL_updateDeleteMessages) pembaruan).messages);
                } else if (pembaruan instanceof org.telegram.tgnet.tl.TL_update.TL_updateDeleteChannelMessages) {
                    org.telegram.tgnet.tl.TL_update.TL_updateDeleteChannelMessages u = (org.telegram.tgnet.tl.TL_update.TL_updateDeleteChannelMessages) pembaruan;
                    catatDihapus(akun, u.channel_id, u.messages);
                }
            } catch (Throwable ignored) {
            }
        }
        return true;
    }

    // ---- penanda pesan yang dihapus lawan bicara (ditahan oleh anti hapus)
    private static final java.util.LinkedHashSet<String> dihapus = new java.util.LinkedHashSet<>();
    private static boolean dihapusDimuat = false;

    private static String kunciHapus(int akun, long kanal, int id) {
        return "a" + akun + (kanal != 0 ? "c" + kanal : "m") + "_" + id;
    }

    private static void muatDihapus() {
        if (dihapusDimuat) {
            return;
        }
        Context c = ApplicationLoader.applicationContext;
        if (c == null) {
            return;
        }
        dihapusDimuat = true;
        try {
            String s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("daftar_dihapus", "");
            for (String k : s.split(",")) {
                if (!k.isEmpty()) {
                    dihapus.add(k);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static synchronized void catatDihapus(int akun, long kanal, java.util.List<Integer> ids) {
        if (ids == null || ids.isEmpty()) {
            return;
        }
        muatDihapus();
        for (Integer id : ids) {
            if (id != null) {
                dihapus.add(kunciHapus(akun, kanal, id));
            }
        }
        while (dihapus.size() > 3000) {
            java.util.Iterator<String> it = dihapus.iterator();
            it.next();
            it.remove();
        }
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c != null) {
                c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("daftar_dihapus", TextUtils.join(",", dihapus)).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    public static synchronized boolean sudahDihapus(MessageObject mo) {
        try {
            if (mo == null || mo.messageOwner == null) {
                return false;
            }
            muatDihapus();
            return dihapus.contains(kunciHapus(mo.currentAccount, MessageObject.getChannelId(mo.messageOwner), mo.getId()));
        } catch (Throwable t) {
            return false;
        }
    }

    /** Awalan yang dibacakan pembaca layar untuk pesan yang sudah dihapus lawan bicara; null bila tidak perlu. */
    public static CharSequence awalanAksesibilitas(MessageObject mo) {
        return aHapus && sudahDihapus(mo) ? "Sudah dihapus oleh pengirim. " : null;
    }


    // ---- konfirmasi sebelum tindakan yang mudah salah ketuk (semua mati secara bawaan)
    private static volatile boolean lanjutKonfirmasi = false;

    private static boolean pilihanAktif(String kunci) {
        try {
            Context c = ApplicationLoader.applicationContext;
            return c != null && c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(kunci, false);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Tampilkan dialog konfirmasi bila pilihan "kunci" aktif. true = dialog ditampilkan (pemanggil harus berhenti dan
     * menunggu); false = lanjutkan seperti biasa. Bila pengguna menjawab Ya, aksi dijalankan ulang tanpa bertanya lagi.
     */
    public static boolean tanyaDulu(final Activity a, String kunci, String pertanyaan, final Runnable aksi) {
        if (lanjutKonfirmasi || a == null || a.isFinishing() || !pilihanAktif(kunci)) {
            return false;
        }
        try {
            new android.app.AlertDialog.Builder(a)
                    .setTitle("Konfirmasi")
                    .setMessage(pertanyaan)
                    .setPositiveButton("Ya", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            lanjutKonfirmasi = true;
                            try {
                                aksi.run();
                            } finally {
                                lanjutKonfirmasi = false;
                            }
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Konfirmasi kirim pesan suara. Batal atau menutup dialog membuang rekaman supaya perekam tidak tertinggal menyala. */
    public static boolean tanyaKirimSuara(final Activity a, final Runnable kirim, final Runnable buang) {
        if (a == null || a.isFinishing() || !pilihanAktif("konfirmasi_suara")) {
            return false;
        }
        try {
            final boolean[] selesai = {false};
            new android.app.AlertDialog.Builder(a)
                    .setTitle("Konfirmasi")
                    .setMessage("Kirim pesan suara ini? Pilih Batal untuk membuang rekaman.")
                    .setPositiveButton("Kirim", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            selesai[0] = true;
                            kirim.run();
                        }
                    })
                    .setNegativeButton("Batal", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            selesai[0] = true;
                            buang.run();
                        }
                    })
                    .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(android.content.DialogInterface d) {
                            if (!selesai[0]) {
                                selesai[0] = true;
                                buang.run();
                            }
                        }
                    })
                    .show();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }


    /**
     * Rapikan layar Pengaturan Telegram: sembunyikan item yang jarang dipakai (Dompet, Premium, Bintang, Pendapatan Gram,
     * Bisnis, Kirim Hadiah) lalu buang pemisah ganda. Bawaan aktif; bisa dimatikan di Pengaturan Novan Tel.
     */
    /** Pindahkan baris "Pengaturan Novan Tel" (id 9001) ke posisi paling atas di antara baris menu Pengaturan. */
    private static void naikkanMenuNovan(java.util.List<org.telegram.ui.Components.UItem> items) {
        try {
            int idx = -1;
            for (int i = 0; i < items.size(); i++) {
                org.telegram.ui.Components.UItem it = items.get(i);
                if (it.id == 9001 && it.viewType != org.telegram.ui.Components.UniversalAdapter.VIEW_TYPE_SHADOW) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) {
                return;
            }
            org.telegram.ui.Components.UItem novan = items.get(idx);
            int tujuan = -1;
            for (int i = 0; i < idx; i++) {
                org.telegram.ui.Components.UItem it = items.get(i);
                if (it.viewType == novan.viewType && it.id != 9001) {
                    tujuan = i;
                    break;
                }
            }
            if (tujuan < 0 || tujuan >= idx) {
                return;
            }
            items.remove(idx);
            items.add(tujuan, novan);
        } catch (Throwable ignored) {
        }
    }

    public static void rapikanPengaturan(java.util.List<org.telegram.ui.Components.UItem> items) {
        naikkanMenuNovan(items);
        try {
            Context c = ApplicationLoader.applicationContext;
            if (items == null || c == null || !c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("rapikan_pengaturan", true)) {
                return;
            }
            for (int i = items.size() - 1; i >= 0; i--) {
                org.telegram.ui.Components.UItem it = items.get(i);
                if (it.viewType == org.telegram.ui.Components.UniversalAdapter.VIEW_TYPE_SHADOW) {
                    continue;
                }
                int id = it.id;
                if (id == 11 || id == 12 || id == 13 || id == 15 || id == 16 || id == 25) {
                    items.remove(i);
                }
            }
            for (int i = items.size() - 1; i > 0; i--) {
                if (items.get(i).viewType == org.telegram.ui.Components.UniversalAdapter.VIEW_TYPE_SHADOW
                        && items.get(i - 1).viewType == org.telegram.ui.Components.UniversalAdapter.VIEW_TYPE_SHADOW) {
                    items.remove(i);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static volatile long izinBacaSampai = 0;

    /** Dipanggil saat pengguna sengaja menekan "Tandai sebagai dibaca": izinkan pengiriman tanda baca selama beberapa detik. */
    public static void izinkanBaca() {
        izinBacaSampai = android.os.SystemClock.elapsedRealtime() + 6000;
    }

    // ---- nama permintaan yang seragam untuk semua tata letak kode Telegram
    /**
     * Ubah nama kelas permintaan jadi bentuk seragam "TL_grup_nama". Kode Telegram terbaru memindahkan kelas dari
     * TLRPC.TL_account_updateStatus menjadi TL_account.updateStatus (atau TL_account.TL_updateStatus); semuanya
     * dijadikan TL_account_updateStatus supaya mode hantu tetap mengenalinya.
     */
    static String namaSeragam(Class<?> k) {
        String n = k.getName();
        int titik = n.lastIndexOf('.');
        if (titik >= 0) {
            n = n.substring(titik + 1);
        }
        n = n.replace('$', '_');
        if (n.startsWith("TLRPC_")) {
            n = n.substring(6);
        }
        n = n.replace("_TL_", "_");
        n = n.replaceAll("_layer\\d+$", "");
        if (!n.startsWith("TL_")) {
            n = "TL_" + n;
        }
        return n;
    }

    /** Permintaan yang mengubah status online / terakhir dilihat di server. */
    private static boolean permintaanStatus(String nama) {
        return "TL_account_updateStatus".equals(nama);
    }

    /** Sama, untuk permintaan bertipe lain (misalnya TLMethod) yang tipenya tidak dikenal kompilator sebagai TLObject. */
    public static boolean blokir(Object permintaan) {
        return permintaan instanceof TLObject && blokir((TLObject) permintaan);
    }

    /** true = permintaan ini jangan dikirim ke server. */
    public static boolean blokir(TLObject permintaan) {
        if (permintaan == null) {
            return false;
        }
        if (!dimuat) {
            muat();
        }
        String nama = namaSeragam(permintaan.getClass());
        // Jaring pengaman: apa pun tata letak kodenya, permintaan yang namanya memuat updateStatus ditangani sebagai status online.
        if (!permintaanStatus(nama) && nama.toLowerCase(java.util.Locale.ROOT).endsWith("updatestatus")
                && nama.toLowerCase(java.util.Locale.ROOT).contains("account")) {
            nama = "TL_account_updateStatus";
        }
        if (permintaanStatus(nama)) {
            return hOnline;
        }
        switch (nama) {
            case "TL_messages_readHistory":
            case "TL_channels_readHistory":
            case "TL_messages_readEncryptedHistory":
            case "TL_messages_readDiscussion":
                // Dilepas sebentar bila Anda sendiri menekan "Tandai sebagai dibaca".
                return hBaca && android.os.SystemClock.elapsedRealtime() > izinBacaSampai;
            case "TL_messages_getMessagesViews":
                // Tetap ambil jumlah dilihat, tetapi jangan menambah hitungan dilihat milik Anda.
                if (hBaca) {
                    try {
                        permintaan.getClass().getField("increment").setBoolean(permintaan, false);
                    } catch (Throwable ignored) {
                    }
                }
                return false;
            case "TL_messages_setTyping":
            case "TL_messages_setEncryptedTyping":
                return hMengetik;
            case "TL_stories_readStories":
            case "TL_stories_incrementStoryViews":
                return hCerita;
            case "TL_messages_readMessageContents":
            case "TL_channels_readMessageContents":
                return hKonten;
            case "TL_messages_getSponsoredMessages":
            case "TL_channels_getSponsoredMessages":
            case "TL_messages_viewSponsoredMessage":
            case "TL_messages_clickSponsoredMessage":
            case "TL_channels_viewSponsoredMessage":
            case "TL_channels_clickSponsoredMessage":
                return bIklan;
            default:
                return false;
        }
    }
}
