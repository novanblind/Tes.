package com.makroku.automation.engine

import android.content.Context
import android.net.Uri
import android.provider.Settings
import com.makroku.automation.adb.AdbBackend

/** Daftar pengaturan sistem (nama dan nilai sekarang) untuk satu namespace: system, secure, atau global. Panggil dari thread latar. */
object SettingsLister {
    fun list(ctx: Context, ns: String): List<Pair<String, String>> {
        val n = when (ns.trim()) {
            "system", "secure" -> ns.trim()
            else -> "global"
        }
        var hasil = lewatProvider(ctx, n)
        if (hasil.isEmpty()) hasil = lewatAdb(ctx, n)
        if (hasil.isEmpty() && n == "global") hasil = lewatRefleksi(ctx)
        return hasil.distinctBy { it.first }.sortedBy { it.first.lowercase() }
    }

    private fun lewatProvider(ctx: Context, ns: String): List<Pair<String, String>> = try {
        val out = ArrayList<Pair<String, String>>()
        ctx.contentResolver.query(Uri.parse("content://settings/$ns"), arrayOf("name", "value"), null, null, "name")?.use { c ->
            while (c.moveToNext()) {
                val k = c.getString(0).orEmpty()
                if (k.isNotEmpty()) out.add(k to c.getString(1).orEmpty())
            }
        }
        out
    } catch (e: Throwable) {
        emptyList()
    }

    private fun lewatAdb(ctx: Context, ns: String): List<Pair<String, String>> = try {
        if (!AdbBackend.dipasangkan(ctx)) emptyList() else {
            AdbBackend.shell(ctx, "settings list $ns", 20).lineSequence().mapNotNull { ln ->
                val i = ln.indexOf('=')
                if (i <= 0) null else ln.substring(0, i).trim() to ln.substring(i + 1).trim()
            }.toList()
        }
    } catch (e: Throwable) {
        emptyList()
    }

    /** Cadangan terakhir: konstanta publik di Settings.Global. */
    private fun lewatRefleksi(ctx: Context): List<Pair<String, String>> = try {
        Settings.Global::class.java.fields.mapNotNull { f ->
            if (f.type != String::class.java) return@mapNotNull null
            val k = f.get(null) as? String ?: return@mapNotNull null
            if (k.contains(' ') || k.contains('/') || k.contains(':')) return@mapNotNull null
            k to (Settings.Global.getString(ctx.contentResolver, k) ?: "")
        }
    } catch (e: Throwable) {
        emptyList()
    }
}
