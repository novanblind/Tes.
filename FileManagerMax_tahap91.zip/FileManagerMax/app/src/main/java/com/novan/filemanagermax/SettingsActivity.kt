package com.novan.filemanagermax

import android.os.Bundle
import android.view.MenuItem
import android.widget.RadioGroup
import androidx.appcompat.widget.SwitchCompat
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val group = findViewById<RadioGroup>(R.id.themeGroup)
        group.check(
            when (ThemeManager.get(this)) {
                ThemeManager.LIGHT -> R.id.themeLight
                ThemeManager.DARK -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        val sw = findViewById<SwitchCompat>(R.id.switchTrash)
        sw.isChecked = Prefs.useTrash(this)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setUseTrash(this, v) }
        val swUsb = findViewById<SwitchCompat>(R.id.switchUsb)
        swUsb.isChecked = Prefs.usbConnect(this)
        swUsb.setOnCheckedChangeListener { _, v -> Prefs.setUsbConnect(this, v) }
        val swConfirm = findViewById<SwitchCompat>(R.id.switchTrashConfirm)
        swConfirm.isChecked = Prefs.trashConfirm(this)
        swConfirm.setOnCheckedChangeListener { _, v -> Prefs.setTrashConfirm(this, v) }
        val swThumbs = findViewById<SwitchCompat>(R.id.switchThumbs)
        swThumbs.isChecked = Prefs.showThumbs(this)
        swThumbs.setOnCheckedChangeListener { _, v -> Prefs.setShowThumbs(this, v) }
        val swHidden = findViewById<SwitchCompat>(R.id.switchHidden)
        swHidden.isChecked = Prefs.showHidden(this)
        swHidden.setOnCheckedChangeListener { _, v -> Prefs.setShowHidden(this, v) }
        val swSystem = findViewById<SwitchCompat>(R.id.switchSystem)
        swSystem.isChecked = Prefs.showSystem(this)
        swSystem.setOnCheckedChangeListener { _, v -> Prefs.setShowSystem(this, v) }
        val unitGroup = findViewById<RadioGroup>(R.id.unitGroup)
        unitGroup.check(
            when (Prefs.sizeUnit(this)) {
                1 -> R.id.unitBinary
                2 -> R.id.unitDecimal
                else -> R.id.unitAuto
            }
        )
        unitGroup.setOnCheckedChangeListener { _, id ->
            Prefs.setSizeUnit(
                this,
                when (id) {
                    R.id.unitBinary -> 1
                    R.id.unitDecimal -> 2
                    else -> 0
                }
            )
        }
        for ((id, key) in listOf(
            R.id.swImage to "image", R.id.swAudio to "audio",
            R.id.swVideo to "video", R.id.swText to "text"
        )) {
            val s = findViewById<SwitchCompat>(id)
            s.isChecked = Prefs.useInternal(this, key)
            s.setOnCheckedChangeListener { _, v -> Prefs.setUseInternal(this, key, v) }
        }
        findViewById<SwitchCompat>(R.id.swPdf).apply {
            isChecked = Prefs.usePdf(this@SettingsActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setUsePdf(this@SettingsActivity, v) }
        }
        findViewById<SwitchCompat>(R.id.swOcr).apply {
            isChecked = Prefs.ocrPdf(this@SettingsActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setOcrPdf(this@SettingsActivity, v) }
        }
        findViewById<SwitchCompat>(R.id.swOffice).apply {
            isChecked = Prefs.useOffice(this@SettingsActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setUseOffice(this@SettingsActivity, v) }
        }
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<android.widget.TextView>(R.id.aboutVersion).text =
            getString(R.string.about_version, ver)
        findViewById<android.widget.Button>(R.id.btnLicenses).setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.open_source_licenses)
                .setMessage(R.string.licenses_text)
                .setPositiveButton(R.string.close, null)
                .show()
        }
        group.setOnCheckedChangeListener { _, id ->
            ThemeManager.set(
                this,
                when (id) {
                    R.id.themeLight -> ThemeManager.LIGHT
                    R.id.themeDark -> ThemeManager.DARK
                    else -> ThemeManager.SYSTEM
                }
            )
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) {
            finish()
            true
        } else super.onOptionsItemSelected(item)
}
