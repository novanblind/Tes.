package com.novan.audiolabnovan.videolab;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/** Notifikasi kemajuan dan hasil ekspor. */
final class ExportNotifier {
    static final String CH_PROGRESS = "ekspor_berjalan";
    static final String CH_DONE = "ekspor_selesai";
    static final int ID_PROGRESS = 1001;
    static final int ID_DONE = 1002;

    private ExportNotifier() { }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel p = new NotificationChannel(CH_PROGRESS, "Ekspor berjalan",
                NotificationManager.IMPORTANCE_LOW);
        p.setDescription("Kemajuan ekspor video");
        NotificationChannel d = new NotificationChannel(CH_DONE, "Ekspor selesai",
                NotificationManager.IMPORTANCE_DEFAULT);
        d.setDescription("Pemberitahuan saat ekspor selesai atau gagal");
        d.enableVibration(true);
        nm.createNotificationChannel(p);
        nm.createNotificationChannel(d);
    }

    private static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, VideoLabActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static Notification progress(Context c, int pct) {
        ensureChannels(c);
        return new NotificationCompat.Builder(c, CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("VideoLab sedang mengekspor")
                .setContentText(pct + " persen")
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp(c))
                .build();
    }

    static void update(Context c, int pct) {
        post(c, ID_PROGRESS, progress(c, pct));
    }

    static void finished(Context c, boolean ok, String text) {
        ensureChannels(c);
        Notification n = new NotificationCompat.Builder(c, CH_DONE)
                .setSmallIcon(ok ? android.R.drawable.stat_sys_upload_done
                        : android.R.drawable.stat_notify_error)
                .setContentTitle(ok ? "Ekspor selesai" : "Ekspor gagal")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(openApp(c))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build();
        post(c, ID_DONE, n);
    }

    private static void post(Context c, int id, Notification n) {
        try {
            NotificationManagerCompat.from(c).notify(id, n);
        } catch (SecurityException ignored) {
            // izin notifikasi belum diberikan
        }
    }
}
