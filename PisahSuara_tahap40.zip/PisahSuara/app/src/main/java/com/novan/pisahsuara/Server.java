package com.novan.pisahsuara;

import android.content.Context;
import android.content.ContextWrapper;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileWriter;
import java.util.HashSet;
import java.util.Set;

/**
 * Dijalankan di proses shell lewat ADB: app_process /system/bin com.novan.pisahsuara.Server hp bt kunci log
 * Memegang kebijakan audio selama hidup. Aturan baru dibaca dari berkas .cfg tiap 0,4 detik dan langsung
 * diterapkan tanpa memulai ulang proses. Laporan keadaan nyata ditulis ke berkas .state.
 */
public class Server {
    /** Konteks palsu atas nama shell agar AudioPolicy mau dibuat tanpa aplikasi. */
    static class Palsu extends ContextWrapper {
        Palsu(Context base) { super(base); }
        @Override public String getPackageName() { return "com.android.shell"; }
        public String getOpPackageName() { return "com.android.shell"; }
        @Override public Context getApplicationContext() { return this; }
        @Override public android.content.AttributionSource getAttributionSource() {
            if (Build.VERSION.SDK_INT >= 31) {
                return new android.content.AttributionSource.Builder(2000)
                        .setPackageName("com.android.shell").build();
            }
            return super.getAttributionSource();
        }
    }

    private static int[] angka(String s) {
        if (s == null || s.equals("-") || s.isEmpty()) return new int[0];
        String[] p = s.split(",");
        int[] r = new int[p.length];
        for (int i = 0; i < p.length; i++) r[i] = Integer.parseInt(p[i].trim());
        return r;
    }

    private static String gabung(int[] a) {
        if (a.length == 0) return "-";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(a[i]); }
        return sb.toString();
    }

    private static String logPath = "/data/local/tmp/pisahsuara.log";
    private static String versi = "?";
    private static String statePath, cfgPath, mutePath;
    private static Context ctx;
    private static AudioManager am;
    private static Handler h;
    private static int[] curHp = new int[0], curBt = new int[0];
    private static String curSig = "", curHasil = "";
    private static String curKunci = null;
    private static boolean pasangUlangTerjadwal = false;
    private static int lastVol = -1;
    private static long lastVolWaktu = 0;
    private static String curVol = "-";
    private static android.os.FileObserver observer;
    private static boolean volAktif = false;

    /** Pantau volume (tiap 0,5 detik) hanya selama ada suara media aktif; berhenti sendiri bila sunyi. */
    private static void mulaiVolume() {
        if (volAktif) return;
        volAktif = true;
        h.post(new Runnable() {
            @Override public void run() {
                try { sinkronVolume(); } catch (Throwable ignored) {}
                boolean bicara = Policy.aksesibilitasAktif(am);
                if (am.isMusicActive() || bicara) h.postDelayed(this, bicara ? 250 : 500);
                else volAktif = false;
            }
        });
    }

    /** System.out di app_process dialihkan ke logcat, jadi hasil ditulis langsung ke berkas. */
    private static void tulis(String t) {
        try (FileWriter w = new FileWriter(logPath, true)) { w.write(t + "\n"); } catch (Throwable ignored) {}
    }

    private static String baca(File f) throws Exception {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[512];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        }
    }

    private static void tulisState() {
        try {
            String tmp = statePath + ".tmp";
            try (FileWriter w = new FileWriter(tmp, false)) {
                w.write(Policy.laporan(am));
                w.write("VERSI " + versi + "\n");
                w.write("CFG " + curSig + "\n");
                w.write("HASIL " + curHasil.replace('\n', ' ') + "\n");
                w.write("VOL " + curVol + "\n");
                w.write("PAKSA " + Policy.paksaCatatan.replace('\n', ' ') + "\n");
                w.write("PILIHAN " + Policy.pilihanMedia(am) + " | awal: " + pilihanAwal + "\n");
                w.write("DUMP " + dumpMix.replace('\n', ' ') + "\n");
                w.write("VOLDIAG " + volDiag.replace('\n', ' ') + "\n");
                w.write("RIWAYAT " + android.text.TextUtils.join(" ", riwayat) + "\n");
            }
            new File(tmp).renameTo(new File(statePath));
        } catch (Throwable ignored) {}
    }

    private static int sasaran(int uid, int[] hp, int[] bt) {
        for (int x : hp) if (x == uid) return 1;
        for (int x : bt) if (x == uid) return 2;
        return 0;
    }

    /** UID yang sasarannya berubah antara aturan lama dan baru. */
    private static int[] berubah(int[] hpL, int[] btL, int[] hpB, int[] btB) {
        Set<Integer> semua = new HashSet<>();
        for (int x : hpL) semua.add(x);
        for (int x : btL) semua.add(x);
        for (int x : hpB) semua.add(x);
        for (int x : btB) semua.add(x);
        Set<Integer> beda = new HashSet<>();
        for (int u : semua) if (sasaran(u, hpL, btL) != sasaran(u, hpB, btB)) beda.add(u);
        int[] r = new int[beda.size()];
        int i = 0;
        for (int u : beda) r[i++] = u;
        return r;
    }

    private static int lastSeen = -1;
    private static int kandidat = -2;
    private static long kandidatSejak = 0;
    private static long tahanSampai = 0;
    private static String volDiag = "-";
    private static String dumpMix = "-";
    private static String pilihanAwal = "-";
    private static final java.util.ArrayList<String> riwayat = new java.util.ArrayList<>();

    private static void jadwalSinkron(long ms) {
        h.postDelayed(new Runnable() {
            @Override public void run() { try { sinkronVolume(); } catch (Throwable ignored) {} }
        }, ms);
    }

    /**
     * Volume media speaker HP mengikuti volume media aktif (tombol volume). Nilai baru baru dipakai setelah
     * stabil sekitar 0,6 detik, sehingga nilai sesaat (mis. saat pemaksaan pindah saluran atau saat mesin suara
     * bicara) tidak ikut menurunkan volume speaker HP. Tidak bergantung pada status pemutar aksesibilitas.
     */
    private static void sinkronVolume() {
        if (curHp.length == 0) { curVol = "-"; return; }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now < tahanSampai) { jadwalSinkron(tahanSampai - now + 50); return; }
        boolean a11y = Policy.aksesibilitasAktif(am);
        int vStream = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        // Dengan volume absolut Bluetooth, angka dari getStreamVolume bisa tetap di nilai maksimum; indeks
        // yang tersimpan untuk perangkat luar itu sendiri lebih bisa dipercaya bila terbaca.
        int vBt = Policy.bacaVolumePerangkat(am, false);
        int v = vBt >= 0 ? vBt : vStream;
        // Tahap 36: volume aksesibilitas (stream 10, skala sendiri) SELALU dibaca dan ikut dibandingkan. Sebelumnya hanya
        // volume media yang dipantau, sehingga mengubah volume aksesibilitas tidak dianggap perubahan, dan saat mesin
        // suara tidak bicara angka media (mis. 71) ikut dituliskan ke stream aksesibilitas (skala kecil) lalu terpotong
        // ke maksimum, jadi awal suara mesin suara keras sebelum disamakan lagi.
        int vA = -1;
        try { vA = am.getStreamVolume(10); } catch (Throwable ignored) {}
        if (vA < 0) vA = v;
        int kunci = v * 1000 + vA;
        if (kunci != lastSeen) {
            lastSeen = kunci;
            riwayat.add((a11y ? "*" : "") + v + "/" + vA);
            while (riwayat.size() > 12) riwayat.remove(0);
        }
        if (kunci != kandidat) {
            // Tahap 37: bila volume media sama dan hanya volume aksesibilitas yang berubah (tombol volume aksesibilitas),
            // langsung diterapkan. Jeda stabil 0,6 detik hanya untuk perubahan volume media (nilai sesaat saat mesin
            // suara bicara). Suara "50 persen" setelah volume diubah dibunyikan segera, jadi harus sudah memakai volume baru.
            boolean cepat = kandidat >= 0 && kandidat / 1000 == v;
            kandidat = kunci; kandidatSejak = now;
            if (!cepat) { jadwalSinkron(700); return; }
        } else if (now - kandidatSejak < 600) { jadwalSinkron(kandidatSejak + 650 - now); return; }
        if (kunci == lastVol && now - lastVolWaktu < 3000) return;
        lastVol = kunci;
        lastVolWaktu = now;
        String r = Policy.setVolumeSpeakerSemua(am, v, vA);
        curVol = v + " " + r;
        volDiag = "stream=" + vStream + "/" + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                + " perangkatLuar=" + vBt + " speakerSetelah=" + Policy.bacaVolumePerangkat(am, true)
                + " metode=" + Policy.volMetode + " | aksesibilitas(stream10)=" + vA + " " + Policy.volRinci;
    }

    // ---------- Penyembuhan otomatis: aplikasi yang memutar di perangkat yang salah ----------
    private static long lastPaksa = 0;
    private static boolean periksaTerjadwal = false;
    private static final java.util.HashMap<Integer, Integer> coba = new java.util.HashMap<>();

    private static void jadwalPeriksa(long ms) {
        if (periksaTerjadwal) return;
        periksaTerjadwal = true;
        h.postDelayed(new Runnable() {
            @Override public void run() {
                periksaTerjadwal = false;
                try { periksaKesesuaian(); } catch (Throwable e) { tulis("ERR periksa: " + e); }
            }
        }, ms);
    }

    /**
     * Bila ada aplikasi yang sedang memutar di perangkat yang salah, paksa saluran dibuat ulang (maksimal 3 kali
     * per aplikasi, jarak minimal 6 detik), lalu periksa lagi. Berlaku untuk perpindahan arah mana pun dan untuk
     * suara yang baru mulai, bukan hanya saat centang diubah.
     */
    private static java.util.HashSet<Integer> salahSebelumnya = new java.util.HashSet<>();

    private static void periksaKesesuaian() {
        if (curHp.length == 0 && curBt.length == 0) return;
        // Sedang telepon / panggilan: jangan ganggu pengaturan rute sama sekali (telepon tetap di jalurnya sendiri).
        if (am.getMode() != AudioManager.MODE_NORMAL) { salahSebelumnya.clear(); return; }
        int[] terbaca = Policy.tidakSesuai(am, curHp, curBt);
        java.util.HashSet<Integer> set = new java.util.HashSet<>();
        for (int u : terbaca) set.add(u);
        // Pembacaan perangkat sesaat bisa keliru (mis. saat pemutar baru mulai). Pemaksaan pindah mengalihkan SEMUA
        // media sebentar, jadi baru dilakukan bila ketidaksesuaian terbaca dua kali berturut-turut (jarak 3 detik).
        java.util.HashSet<Integer> terkonfirmasi = new java.util.HashSet<>(set);
        terkonfirmasi.retainAll(salahSebelumnya);
        salahSebelumnya = set;
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastPaksa > 60000) coba.clear();
        if (set.isEmpty()) return;
        if (terkonfirmasi.isEmpty()) { jadwalPeriksa(3000); return; }
        if (now - lastPaksa < 6000) { jadwalPeriksa(6000 - (now - lastPaksa) + 100); return; }
        java.util.ArrayList<Integer> layak = new java.util.ArrayList<>();
        for (int u : terkonfirmasi) {
            int n = coba.containsKey(u) ? coba.get(u) : 0;
            if (n < 3) { coba.put(u, n + 1); layak.add(u); }
        }
        if (layak.isEmpty()) return;
        int[] uids = new int[layak.size()];
        for (int i = 0; i < uids.length; i++) uids[i] = layak.get(i);
        lastPaksa = now;
        tahanSampai = now + 1300;
        String hasil = paksaAman();
        Policy.paksaCatatan = "otomatis (uid " + gabung(uids) + "): " + hasil;
        tulis("PAKSA " + Policy.paksaCatatan);
        tulisState();
        Policy.dorong(ctx, am, uids, curHp, curBt, h);
        jadwalPeriksa(3500);
    }

    /**
     * Tahap 34: pemaksaan pindah saluran mengalihkan SEMUA media (yang tidak dicentang) sebentar ke perangkat lain.
     * Bila media sistem sedang di Bluetooth, suara aplikasi lain bocor ke speaker HP selama jendela itu. Bila tidak ada
     * aplikasi daftar HP yang sedang memutar, speaker HP diredam (volume 0) selama pemaksaan lalu dikembalikan.
     * Nilai volume asli dicatat di berkas .mute supaya dipulihkan juga bila Server mati di tengah jalan.
     */
    private static String paksaAman() {
        int simpan = -1;
        try {
            int aktif = Policy.tipeMediaAktif(am);
            if (aktif != 2 && aktif != -1 && !Policy.sedangMemutar(am, curHp)) {
                int v = Policy.bacaVolumePerangkat(am, true);
                if (v > 0) {
                    try (FileWriter w = new FileWriter(mutePath, false)) { w.write(String.valueOf(v)); }
                    Policy.setVolumeSpeaker(am, 0);
                    simpan = v;
                }
            }
        } catch (Throwable e) { tulis("ERR redam: " + e); }
        final int pulih = simpan;
        String hasil = Policy.paksaPindah(am, h);
        if (pulih >= 0) {
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    try { Policy.setVolumeSpeaker(am, pulih); } catch (Throwable ignored) {}
                    try { new File(mutePath).delete(); } catch (Throwable ignored) {}
                    lastVol = -1;
                }
            }, 800);
            hasil += " (speaker HP diredam sementara)";
        }
        return hasil;
    }

    /** Bila Server sebelumnya mati saat speaker diredam, kembalikan volume speaker HP yang tercatat. */
    private static void pulihkanRedam() {
        try {
            File f = new File(mutePath);
            if (!f.exists()) return;
            int v = Integer.parseInt(baca(f).trim());
            String r = Policy.setVolumeSpeaker(am, v);
            f.delete();
            tulis("REDAM dipulihkan: volume speaker " + v + " " + r);
        } catch (Throwable e) { tulis("ERR pulih redam: " + e); }
    }

    private static void terapkan(int[] hp, int[] bt, String kunci) {
        int[] ubah = berubah(curHp, curBt, hp, bt);
        String hasil = Policy.register(ctx, am, hp, bt, kunci);
        curHp = hp;
        curBt = bt;
        curKunci = kunci;
        curSig = "hp=" + gabung(hp) + ";bt=" + gabung(bt) + ";key=" + (kunci == null ? "auto" : kunci);
        curHasil = hasil;
        lastVol = -1;
        try { sinkronVolume(); } catch (Throwable ignored) {}
        tulis((hasil.startsWith("Aktif") ? "OK " : "ERR ") + hasil);
        tulisState();
        // Tahap 34: pemaksaan hanya bila uid yang berubah punya pemain (aktif atau jeda). Tanpa pemain, suara yang
        // baru mulai langsung mengikuti aturan, jadi tidak perlu mengalihkan media siapa pun.
        if (ubah.length > 0 && hasil.startsWith("Aktif") && Policy.adaPemain(am, ubah)) {
            // Aliran suara yang sudah ada (termasuk yang sedang jeda/di latar, mis. YouTube yang ditinggalkan)
            // tidak ikut aturan baru sampai saluran keluarnya dibuat ulang: tandai semua aliran media tidak
            // berlaku; yang sedang jeda membuat ulang saluran saat diputar lagi. Tidak perlu ada suara aktif.
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    tahanSampai = android.os.SystemClock.elapsedRealtime() + 1300;
                    final String dasar = paksaAman();
                    final String sebelum = Policy.ringkasUid(am, ubah);
                    Policy.paksaCatatan = dasar + "; sebelum[uid:status:tipe:usage:flags]=" + sebelum;
                    tulis("PAKSA " + Policy.paksaCatatan);
                    tulisState();
                    h.postDelayed(new Runnable() {
                        @Override public void run() {
                            dumpMix = Policy.dumpMix(am);
                            Policy.paksaCatatan = dasar + "; sebelum=" + sebelum + "; sesudah=" + Policy.ringkasUid(am, ubah);
                            tulis("PAKSA " + Policy.paksaCatatan);
                            tulisState();
                        }
                    }, 1500);
                }
            }, 30);
        }
        Policy.dorong(ctx, am, ubah, hp, bt, h);
    }

    /**
     * Perangkat keluaran bertambah/berkurang (mis. Bluetooth tersambung setelah kebijakan dipasang): kebijakan dibuat
     * ulang, karena aturan ke perangkat luar hanya terbentuk bila perangkatnya ada saat pendaftaran. Semua UID
     * dianggap berubah supaya saluran suara yang sudah ada ikut dipaksa pindah.
     */
    private static void jadwalPasangUlang() {
        if (pasangUlangTerjadwal) return;
        pasangUlangTerjadwal = true;
        h.postDelayed(new Runnable() {
            @Override public void run() {
                pasangUlangTerjadwal = false;
                try {
                    if (curBt.length == 0) return;
                    // Telepon/panggilan: perangkat suara bisa muncul-hilang (SCO, dsb). Tunda, jangan sentuh kebijakan.
                    if (am.getMode() != AudioManager.MODE_NORMAL) { jadwalPasangUlang(); return; }
                    // Pasang ulang hanya bila perangkat luar MUNCUL atau BERGANTI dibanding yang dipakai aturan. Bila hanya
                    // hilang/berkedip, aturan lama dibiarkan terpasang (tanpa celah tanpa aturan yang membuat suara bocor ke
                    // speaker HP); saat perangkat yang sama kembali, aturan lama langsung berlaku lagi.
                    String k = Policy.pilihExt(am, curKunci);
                    if (k == null || k.equals(Policy.extTerpakai)) {
                        tulis("PERANGKAT berubah: aturan dibiarkan (luar=" + k + ", terpakai=" + Policy.extTerpakai + ")");
                        return;
                    }
                    int[] hp = curHp, bt = curBt;
                    String kunci = curKunci;
                    curHp = new int[0];
                    curBt = new int[0];
                    tulis("PERANGKAT luar baru " + k + ": kebijakan dipasang ulang");
                    terapkan(hp, bt, kunci);
                } catch (Throwable e) { tulis("ERR pasang ulang: " + e); }
            }
        }, 3000);
    }

    private static void bacaKonfigurasi() throws Exception {
        File f = new File(cfgPath);
        if (!f.exists()) return;
        String t = baca(f).trim();
        if (t.isEmpty() || t.equals(curSig)) return;
        int[] hp = new int[0], bt = new int[0];
        String kunci = null;
        for (String bagian : t.split(";")) {
            if (bagian.startsWith("hp=")) hp = angka(bagian.substring(3));
            else if (bagian.startsWith("bt=")) bt = angka(bagian.substring(3));
            else if (bagian.startsWith("key=")) {
                String k = bagian.substring(4);
                kunci = k.equals("auto") || k.isEmpty() ? null : k;
            }
        }
        terapkan(hp, bt, kunci);
    }

    public static void main(String[] a) {
        if (a.length > 3) logPath = a[3];
        if (a.length > 4) versi = a[4];
        String dasar = logPath.endsWith(".log") ? logPath.substring(0, logPath.length() - 4) : logPath;
        statePath = dasar + ".state";
        cfgPath = dasar + ".cfg";
        mutePath = dasar + ".mute";
        tulis("MULAI");
        try {
            if (Looper.getMainLooper() == null) Looper.prepareMainLooper();
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object t = at.getMethod("systemMain").invoke(null);
            Context sys = (Context) at.getMethod("getSystemContext").invoke(t);
            ctx = new Palsu(sys);
            am = (AudioManager) sys.getSystemService(Context.AUDIO_SERVICE);
            h = new Handler(Looper.getMainLooper());
            pulihkanRedam();
            pilihanAwal = Policy.bersihkanPilihan(am);
            tulis("PILIHAN awal: " + pilihanAwal);
            int[] hp = angka(a.length > 0 ? a[0] : "-");
            int[] bt = angka(a.length > 1 ? a[1] : "-");
            String kunci = a.length > 2 && !a[2].equals("auto") ? a[2] : null;
            terapkan(hp, bt, kunci);
            // Hemat baterai: tanpa pemeriksaan berkala yang rapat. Berkas aturan dipantau lewat inotify,
            // volume hanya dipantau selama ada suara media aktif, denyut tiap 10 detik.
            final Runnable bacaCfg = new Runnable() {
                @Override public void run() {
                    try { bacaKonfigurasi(); } catch (Throwable e) { tulis("ERR cfg: " + e); }
                }
            };
            File dir = new File(cfgPath).getParentFile();
            final String namaCfg = new File(cfgPath).getName();
            observer = new android.os.FileObserver(dir, android.os.FileObserver.CLOSE_WRITE | android.os.FileObserver.MOVED_TO) {
                @Override public void onEvent(int event, String path) {
                    if (path != null && path.equals(namaCfg)) h.post(bacaCfg);
                }
            };
            observer.startWatching();
            am.registerAudioDeviceCallback(new android.media.AudioDeviceCallback() {
                @Override public void onAudioDevicesAdded(android.media.AudioDeviceInfo[] d) { jadwalPasangUlang(); }
                @Override public void onAudioDevicesRemoved(android.media.AudioDeviceInfo[] d) { jadwalPasangUlang(); }
            }, h);
            am.registerAudioPlaybackCallback(new AudioManager.AudioPlaybackCallback() {
                @Override public void onPlaybackConfigChanged(java.util.List<android.media.AudioPlaybackConfiguration> c) {
                    try { sinkronVolume(); } catch (Throwable ignored) {}
                    mulaiVolume();
                    tulisState();
                    jadwalPeriksa(2500);
                }
            }, h);
            h.post(new Runnable() {
                @Override public void run() {
                    bacaCfg.run(); // cadangan bila inotify terlewat
                    tulisState();
                    if (am.isMusicActive()) mulaiVolume();
                    h.postDelayed(this, 10000);
                }
            });
            mulaiVolume();
            // Galat di salah satu tugas tidak boleh mematikan Server: catat lalu lanjutkan putaran.
            while (true) {
                try { Looper.loop(); break; }
                catch (Throwable e) {
                    Throwable c = e.getCause() != null ? e.getCause() : e;
                    StackTraceElement[] st = c.getStackTrace();
                    StringBuilder sb = new StringBuilder("ERR putaran: " + c.getClass().getSimpleName() + ": " + c.getMessage());
                    for (int i = 0; i < Math.min(4, st.length); i++) sb.append(" @").append(st[i].getClassName()).append(".").append(st[i].getMethodName()).append(":").append(st[i].getLineNumber());
                    tulis(sb.toString());
                }
            }
        } catch (Throwable e) {
            Throwable c = e.getCause() != null ? e.getCause() : e;
            StringBuilder sb = new StringBuilder("ERR Server: " + c.getClass().getSimpleName() + ": " + c.getMessage());
            StackTraceElement[] st = c.getStackTrace();
            for (int i = 0; i < Math.min(6, st.length); i++) sb.append(" @").append(st[i].getClassName()).append(".").append(st[i].getMethodName()).append(":").append(st[i].getLineNumber());
            tulis(sb.toString());
        }
    }
}
