package com.novan.filemanagermax

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** Dilempar saat operasi dibatalkan lewat tombol Batal. */
class OpCancelled : RuntimeException()

/** Kemajuan satu operasi: dibaca layanan untuk notifikasi, ditulis oleh pekerjaan. */
class Progress {
    @Volatile var total = 0L
    @Volatile var done = 0L
    @Volatile var label = ""
    @Volatile var cancelled = false

    /**
     * Bukan 0 bila pekerjaan sedang berada di langkah yang lamanya tidak bisa diukur (menghitung ukuran,
     * menghapus satu berkas besar, merapikan berkas asal). Selama itu persen tidak ditampilkan supaya
     * tidak menunjukkan angka palsu; layar dan notifikasi memakai [busyRes] untuk keterangannya.
     */
    @Volatile var busy = 0

    companion object {
        const val BUSY_SCAN = 1
        const val BUSY_BIG_DELETE = 2
        const val BUSY_FINISH = 3
    }

    fun add(n: Long) {
        done += n
        check()
    }

    fun advanceTo(n: Long) {
        if (n > done) done = n
    }

    fun check() {
        if (cancelled) throw OpCancelled()
    }

    fun percent(): Int =
        if (total <= 0L) 0 else ((done * 100) / total).toInt().coerceIn(0, 100)
}

/** Keterangan untuk langkah yang persennya belum bisa dihitung (lihat [Progress.busy]). */
fun busyRes(kind: Int): Int = when (kind) {
    Progress.BUSY_SCAN -> R.string.op_busy_scan
    Progress.BUSY_BIG_DELETE -> R.string.op_busy_big_delete
    else -> R.string.op_busy_finish
}

/**
 * Layanan latar depan untuk pindah, salin, hapus, dan kompres. Pekerjaan masuk antrean dan
 * dijalankan satu per satu; notifikasi menampilkan nama operasi, persentase, dan tombol Batal.
 */
class OpService : Service() {

    /** [work] menerima konteks aplikasi dan kemajuan, lalu mengembalikan pesan hasil dan berkas baru. */
    class Job(
        val title: String,
        val before: List<File>,
        val work: (Context, Progress) -> Pair<String, List<File>>
    ) {
        val progress = Progress()
        @Volatile var finished = false
    }

    companion object {
        const val ACTION_RUN = "com.novan.filemanagermax.OP_RUN"
        const val ACTION_CANCEL = "com.novan.filemanagermax.OP_CANCEL"
        private const val CHANNEL = "ops"
        private const val NOTIF_ID = 78
        private const val DONE_ID = 79

        private val queue = ArrayDeque<Job>()
        @Volatile private var running = false
        @Volatile private var current: Job? = null

        /** Bertambah setiap operasi selesai; layar yang sedang tidak tampil memakainya untuk memuat ulang. */
        @Volatile var version = 0
            private set

        /** Pendengar hasil, dipanggil di utas utama. Hanya layar yang sedang tampil yang terdaftar. */
        val listeners = CopyOnWriteArrayList<(String) -> Unit>()

        fun enqueue(ctx: Context, job: Job) {
            synchronized(queue) { queue.addLast(job) }
            ContextCompat.startForegroundService(
                ctx.applicationContext,
                Intent(ctx.applicationContext, OpService::class.java).setAction(ACTION_RUN)
            )
        }

        fun needsNotifPermission(ctx: Context): Boolean =
            Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED

        private fun pendingCount(): Int = synchronized(queue) { queue.size }
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var wake: PowerManager.WakeLock? = null

    private val ticker = object : Runnable {
        override fun run() {
            if (current != null) {
                postProgress()
                main.postDelayed(this, 500)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            val job = current
            if (job == null) {
                stopIfIdle()
            } else {
                job.progress.cancelled = true
            }
            return START_NOT_STICKY
        }
        // Wajib memanggil startForeground segera setelah startForegroundService.
        startForegroundNow(current)
        val start = synchronized(queue) {
            if (running) false else { running = true; true }
        }
        if (start) {
            acquireWake()
            main.removeCallbacks(ticker)
            main.postDelayed(ticker, 500)
            worker.execute { loop() }
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        while (true) {
            val job = synchronized(queue) {
                val j = queue.removeFirstOrNull()
                if (j == null) running = false
                j
            } ?: break
            current = job
            main.post { postProgress() }
            val p = job.progress
            var news: List<File> = emptyList()
            val old = filesUnder(job.before)
            val message = try {
                val r = job.work(applicationContext, p)
                news = r.second
                r.first
            } catch (e: OpCancelled) {
                getString(R.string.op_cancelled)
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: e.javaClass.simpleName)
            }
            current = null
            job.finished = true
            val paths = (old + filesUnder(news)).distinct()
            if (paths.isNotEmpty()) {
                try {
                    MediaScannerConnection.scanFile(applicationContext, paths.toTypedArray(), null, null)
                } catch (e: Exception) {
                    // abaikan
                }
            }
            main.post { finished(job, message) }
        }
        main.post { stopIfIdle() }
    }

    private fun finished(job: Job, message: String) {
        version++
        if (listeners.isNotEmpty()) {
            listeners.forEach { it(message) }
        } else {
            postDone(job.title, message)
        }
        if (pendingCount() > 0 || current != null) postProgress()
    }

    private fun stopIfIdle() {
        val busy = synchronized(queue) { running || queue.isNotEmpty() }
        if (busy) return
        main.removeCallbacks(ticker)
        releaseWake()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun filesUnder(list: List<File>): List<String> {
        val out = ArrayList<String>()
        for (f in list) {
            try {
                if (f.isDirectory) f.walkTopDown().filter { it.isFile }.forEach { out.add(it.absolutePath) }
                else out.add(f.absolutePath)
            } catch (e: Exception) {
                // abaikan
            }
        }
        return out
    }

    // ---------------------------------------------------------------- notifikasi

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.op_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildProgress(job: Job?): Notification {
        ensureChannel()
        val cancel = PendingIntent.getService(
            this, 3,
            Intent(this, OpService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentIntent(openApp())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, getString(R.string.op_cancel), cancel)
        if (job == null) {
            b.setContentTitle(getString(R.string.op_channel))
            b.setProgress(0, 0, true)
        } else {
            val p = job.progress
            val pct = p.percent()
            val text = StringBuilder()
            val busy = p.busy
            if (busy != 0) text.append(getString(busyRes(busy)))
            else if (p.total > 0) text.append(getString(R.string.op_percent, pct))
            if (p.label.isNotEmpty()) {
                if (text.isNotEmpty()) text.append(" · ")
                text.append(p.label)
            }
            val waiting = pendingCount()
            if (waiting > 0) {
                if (text.isNotEmpty()) text.append(" · ")
                text.append(getString(R.string.op_queue, waiting))
            }
            b.setContentTitle(job.title)
            b.setContentText(text.toString())
            b.setProgress(100, pct, p.total <= 0L || busy != 0)
        }
        return b.build()
    }

    private fun startForegroundNow(job: Job?) {
        val n = buildProgress(job)
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun postProgress() {
        val job = current ?: return
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildProgress(job))
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun postDone(title: String, message: String) {
        try {
            ensureChannel()
            val n = NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(openApp())
                .setAutoCancel(true)
                .build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(DONE_ID, n)
        } catch (e: Exception) {
            // abaikan
        }
    }

    // ---------------------------------------------------------------- kunci daya

    private fun acquireWake() {
        if (wake != null) return
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FileManagerMax:ops").also {
                it.setReferenceCounted(false)
                it.acquire(6 * 60 * 60 * 1000L)
            }
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun releaseWake() {
        try { wake?.release() } catch (e: Exception) { }
        wake = null
    }

    override fun onDestroy() {
        main.removeCallbacks(ticker)
        current?.progress?.cancelled = true
        worker.shutdownNow()
        releaseWake()
        super.onDestroy()
    }
}

/** Pembuat pekerjaan yang dipakai BrowserActivity dan LibraryActivity. */
object OpJobs {

    fun paste(
        items: List<File>, cut: Boolean, dest: File, title: String,
        actions: Map<String, ConflictAction> = emptyMap()
    ): OpService.Job =
        OpService.Job(title, if (cut) items else emptyList()) { ctx, p ->
            p.busy = Progress.BUSY_SCAN
            val sizes = items.map { try { FileOps.sizeOf(it) } catch (e: Exception) { 0L } }
            p.total = sizes.sum()
            p.busy = 0
            var ok = 0
            var fail = 0
            var skipped = 0
            var cancelled = false
            var base = 0L
            val news = ArrayList<File>()
            val destPath = dest.canonicalPath + "/"
            try {
                for ((i, f) in items.withIndex()) {
                    p.check()
                    p.label = f.name
                    try {
                        if (!f.exists()) { fail++; continue }
                        if (f.isDirectory && destPath.startsWith(f.canonicalPath + "/")) { fail++; continue }
                        val act = actions[f.absolutePath] ?: ConflictAction.RENAME
                        if (act == ConflictAction.MERGE && f.isDirectory && File(dest, f.name).isDirectory) {
                            if (cut && f.parentFile?.canonicalPath == dest.canonicalPath) continue
                            val r = FileOps.merge(f, File(dest, f.name), actions, cut, p)
                            skipped += r.skipped
                            if (r.failed > 0) fail++ else ok++
                            news.add(File(dest, f.name))
                            continue
                        }
                        if (cut) {
                            if (f.parentFile?.canonicalPath == dest.canonicalPath) continue
                            if (act == ConflictAction.SKIP) { skipped++; continue }
                            val t = if (act == ConflictAction.OVERWRITE) FileOps.moveReplace(f, dest, p)
                            else FileOps.moveTo(f, dest, p)
                            if (t != null) { ok++; news.add(t) } else fail++
                        } else {
                            if (act == ConflictAction.SKIP) { skipped++; continue }
                            news.add(
                                if (act == ConflictAction.OVERWRITE) FileOps.copyReplace(f, dest, p)
                                else FileOps.copy(f, dest, p)
                            )
                            ok++
                        }
                    } catch (e: OpCancelled) {
                        throw e
                    } catch (e: Exception) {
                        fail++
                    } finally {
                        base += sizes[i]
                        p.advanceTo(base)
                    }
                }
            } catch (e: OpCancelled) {
                cancelled = true
            }
            val msg = if (cancelled) ctx.getString(R.string.op_cancelled_result, ok, fail)
            else if (skipped > 0) ctx.getString(R.string.paste_result_skip, ok, fail, skipped)
            else ctx.getString(R.string.paste_result, ok, fail)
            msg to news
        }

    /** Salin atau pindah isi zip ke folder biasa; bila [cut], entri yang berhasil keluar dibuang dari zip. */
    fun pasteZip(
        archive: File, entries: List<ArchiveOps.Edit>, tops: List<String>,
        cut: Boolean, dest: File, title: String,
        actions: Map<String, ConflictAction> = emptyMap()
    ): OpService.Job =
        OpService.Job(title, if (cut) listOf(archive) else emptyList()) { ctx, p ->
            p.total = entries.filter { !it.isDir }.sumOf { it.size.coerceAtLeast(0L) }
            var ok = 0
            var fail = 0
            var skipped = 0
            var cancelled = false
            val news = ArrayList<File>()
            val moved = ArrayList<String>()
            try {
                for (top in tops) {
                    p.check()
                    val items = entries.filter { it.path == top || it.path.startsWith("$top/") }
                    if (items.isEmpty() || !archive.exists()) { fail++; continue }
                    val topName = top.substringAfterLast('/')
                    val act = actions[topName] ?: ConflictAction.RENAME
                    if (act == ConflictAction.SKIP) { skipped++; continue }
                    if (act == ConflictAction.MERGE && File(dest, topName).isDirectory) {
                        // Gabung: isi folder di zip dimasukkan ke folder yang sudah ada.
                        val target = File(dest, topName)
                        val renamed = ArrayList<ArchiveOps.Edit>()
                        val skipP = ArrayList<String>()
                        val remap = LinkedHashMap<String, String>()
                        val extracted = ArrayList<ArchiveOps.Edit>()
                        var anySkip = false
                        fun mapRel(rel: String): String {
                            for ((k, v) in remap) {
                                if (rel == k) return v
                                if (rel.startsWith("$k/")) return v + rel.removePrefix(k)
                            }
                            return rel
                        }
                        try {
                            for (it in items.sortedBy { e -> e.path }) {
                                if (it.path == top) { renamed.add(it.copy(path = topName)); continue }
                                if (skipP.any { s -> it.path == s || it.path.startsWith("$s/") }) { anySkip = true; continue }
                                val rel = it.path.removePrefix("$top/")
                                var relNew = mapRel(rel)
                                val t2 = File(target, relNew)
                                if (t2.exists() && !(it.isDir && t2.isDirectory)) {
                                    when (actions[it.path] ?: ConflictAction.RENAME) {
                                        ConflictAction.SKIP -> { skipP.add(it.path); anySkip = true; continue }
                                        ConflictAction.OVERWRITE -> t2.deleteRecursively()
                                        else -> {
                                            val newName = FileOps.uniqueTarget(t2.parentFile ?: target, t2.name).name
                                            val parentRel = relNew.substringBeforeLast('/', "")
                                            relNew = if (parentRel.isEmpty()) newName else "$parentRel/$newName"
                                            remap[rel] = relNew
                                        }
                                    }
                                }
                                renamed.add(it.copy(path = "$topName/$relNew"))
                                extracted.add(it)
                            }
                            ArchiveOps.extractItems(archive, renamed, dest, "", p)
                            news.add(target)
                            if (!anySkip) {
                                moved.add(top)
                            } else {
                                // Hanya buang dari zip apa yang benar-benar keluar.
                                for (e in extracted) {
                                    val keep = e.isDir && skipP.any { s -> s.startsWith(e.path + "/") }
                                    if (!keep) moved.add(e.path)
                                }
                                skipped++
                            }
                            ok++
                        } catch (e: OpCancelled) {
                            throw e
                        } catch (e: Exception) {
                            fail++
                        }
                        continue
                    }
                    val overwrite = act == ConflictAction.OVERWRITE
                    val target = if (overwrite) File(dest, topName) else FileOps.uniqueTarget(dest, topName)
                    var backup: File? = null
                    try {
                        if (overwrite) {
                            backup = FileOps.setAside(target) ?: throw java.io.IOException(target.absolutePath)
                        }
                        val renamed = items.map { it.copy(path = target.name + it.path.removePrefix(top)) }
                        ArchiveOps.extractItems(archive, renamed, dest, "", p)
                        if (backup != null && backup != target) backup.deleteRecursively()
                        news.add(target)
                        moved.add(top)
                        ok++
                    } catch (e: OpCancelled) {
                        target.deleteRecursively()
                        backup?.let { FileOps.putBack(it, target) }
                        throw e
                    } catch (e: Exception) {
                        target.deleteRecursively()
                        backup?.let { FileOps.putBack(it, target) }
                        fail++
                    }
                }
            } catch (e: OpCancelled) {
                cancelled = true
            }
            if (cut && moved.isNotEmpty()) {
                try {
                    ArchiveOps.removeFromZip(ctx, archive, moved)
                } catch (e: Exception) {
                    fail += moved.size
                    ok -= moved.size
                }
            }
            val msg = if (cancelled) ctx.getString(R.string.op_cancelled_result, ok, fail)
            else if (skipped > 0) ctx.getString(R.string.paste_result_skip, ok, fail, skipped)
            else ctx.getString(R.string.paste_result, ok, fail)
            msg to news
        }

    /**
     * Hapus permanen: kemajuan dihitung per byte (setiap berkas bobotnya ukurannya + 1, folder 1), jadi folder
     * berisi satu berkas raksasa dan banyak berkas kecil tetap akurat. Berkas sangat besar yang dihapus
     * sekaligus ditandai "busy" (tanpa persen). Ke Sampah: bobot per item sama dengan ukurannya + 1; bila
     * lintas penyimpanan, byte yang disalin ikut dilaporkan.
     */
    fun delete(list: List<File>, toTrash: Boolean, title: String): OpService.Job =
        OpService.Job(title, list) { ctx, p ->
            p.busy = Progress.BUSY_SCAN
            val sizes = list.map {
                try { if (toTrash) FileOps.sizeOf(it) + 1L else FileOps.weightOf(it) } catch (e: Exception) { 1L }
            }
            p.total = sizes.sum()
            p.busy = 0
            var ok = 0
            var cancelled = false
            var base = 0L
            try {
                for ((i, f) in list.withIndex()) {
                    p.check()
                    p.label = f.name
                    try {
                        if (toTrash) {
                            if (TrashManager.trash(f, p, sizes[i] - 1L)) ok++
                        } else {
                            if (FileOps.deleteWithProgress(f, p)) ok++
                        }
                    } finally {
                        base += sizes[i]
                        p.advanceTo(base)
                    }
                }
            } catch (e: OpCancelled) {
                cancelled = true
            }
            val failed = list.size - ok
            val msg = if (cancelled) ctx.getString(R.string.op_cancelled_result, ok, failed)
            else ctx.getString(if (toTrash) R.string.trash_result else R.string.delete_result, ok, failed)
            msg to emptyList()
        }

    /** Hapus permanen dari layar Sampah; [all] = kosongkan seluruh Sampah. Kemajuan dihitung per byte seperti hapus biasa. */
    fun trashDelete(entries: List<TrashManager.Entry>, all: Boolean, title: String): OpService.Job =
        OpService.Job(title, emptyList()) { ctx, p ->
            val list = if (all) TrashManager.load() else entries
            p.busy = Progress.BUSY_SCAN
            val sizes = list.map { try { FileOps.weightOf(TrashManager.fileOf(it)) } catch (e: Exception) { 1L } }
            p.total = sizes.sum()
            p.busy = 0
            var ok = 0
            var cancelled = false
            var base = 0L
            try {
                for ((i, en) in list.withIndex()) {
                    p.check()
                    p.label = en.name
                    try {
                        if (TrashManager.deleteForever(en, p)) ok++
                    } finally {
                        base += sizes[i]
                        p.advanceTo(base)
                    }
                }
            } catch (e: OpCancelled) {
                cancelled = true
            }
            val failed = list.size - ok
            val msg = if (cancelled) ctx.getString(R.string.op_cancelled_result, ok, failed)
            else if (all) ctx.getString(R.string.trash_emptied, ok)
            else ctx.getString(R.string.delete_result, ok, failed)
            msg to emptyList<File>()
        }

    /** Memulihkan satu item Sampah; bila lintas penyimpanan, byte yang disalin dilaporkan. */
    fun trashRestore(entry: TrashManager.Entry, title: String): OpService.Job =
        OpService.Job(title, emptyList()) { ctx, p ->
            p.busy = Progress.BUSY_SCAN
            p.total = try { FileOps.weightOf(TrashManager.fileOf(entry)) } catch (e: Exception) { 1L }
            p.busy = 0
            p.label = entry.name
            val ok = TrashManager.restore(entry, p)
            ctx.getString(if (ok) R.string.restored else R.string.restore_failed, entry.name) to emptyList<File>()
        }

    fun compress(list: List<File>, format: Int, out: File, title: String, level: Int = ArchiveOps.LEVEL_NORMAL, password: String? = null, splitSize: Long = 0L): OpService.Job =
        OpService.Job(title, emptyList()) { ctx, p ->
            p.busy = Progress.BUSY_SCAN
            p.total = list.sumOf { try { FileOps.sizeOf(it) } catch (e: Exception) { 0L } }
            p.busy = 0
            p.label = out.name
            ArchiveOps.compress(list, format, out, p, level, password, splitSize)
            ctx.getString(R.string.compress_done, out.name) to listOf(out)
        }

    fun splitFile(file: File, size: Long, title: String): OpService.Job =
        OpService.Job(title, emptyList()) { ctx, p ->
            p.total = file.length()
            p.label = file.name
            val dir = file.parentFile ?: throw java.io.IOException("Folder tidak diketahui")
            val made = ArchiveOps.splitFile(file, dir, size, p)
            ctx.getString(R.string.split_files_done, made.size) to made
        }

    fun joinParts(first: File, title: String): OpService.Job =
        OpService.Job(title, emptyList()) { ctx, p ->
            val parts = ArchiveOps.partsOf(first)
            if (parts.isEmpty()) throw java.io.IOException("Potongan tidak ditemukan")
            p.total = parts.sumOf { it.length() }
            val out = FileOps.uniqueTarget(first.parentFile ?: throw java.io.IOException("Folder tidak diketahui"), first.name.removeSuffix(".001"))
            ArchiveOps.joinParts(parts, out, p)
            ctx.getString(R.string.join_done, parts.size, out.name) to listOf(out)
        }
}
