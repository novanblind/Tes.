#!/bin/sh
# Memberi izin tingkat tinggi ke MakroKu lewat ADB. Aktifkan USB debugging, sambungkan ponsel, lalu:  sh scripts/setup_permissions.sh
PKG=com.makroku.automation
COMP_A11Y=$PKG/$PKG.service.MacroAccessibilityService
COMP_NL=$PKG/$PKG.service.MacroNotificationListener

adb get-state >/dev/null 2>&1 || { echo "Perangkat tidak terdeteksi (adb devices)"; exit 1; }

run() { echo "+ $*"; adb shell "$@" || echo "  (gagal, lanjut)"; }

run pm grant $PKG android.permission.WRITE_SECURE_SETTINGS
for p in SEND_SMS RECEIVE_SMS READ_PHONE_STATE READ_CALL_LOG READ_CONTACTS READ_CALENDAR CALL_PHONE POST_NOTIFICATIONS BLUETOOTH_CONNECT; do
  run pm grant $PKG android.permission.$p
done
run appops set $PKG WRITE_SETTINGS allow
run appops set $PKG SYSTEM_ALERT_WINDOW allow
run appops set $PKG SCHEDULE_EXACT_ALARM allow
run cmd notification allow_dnd $PKG
run cmd notification allow_listener $COMP_NL
run dumpsys deviceidle whitelist +$PKG

# Aksesibilitas: tambahkan tanpa menimpa layanan lain yang sudah aktif
CUR=$(adb shell settings get secure enabled_accessibility_services | tr -d '\r')
case "$CUR" in
  *"$COMP_A11Y"*) ;;
  null|"") run settings put secure enabled_accessibility_services $COMP_A11Y ;;
  *) run settings put secure enabled_accessibility_services "$CUR:$COMP_A11Y" ;;
esac
run settings put secure accessibility_enabled 1
echo "Selesai. Buka MakroKu → Izin via ADB → Segarkan."
