package com.novan.githubbynovan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Mengunduh APK sebagai layanan latar depan, sehingga unduhan tetap berjalan walaupun pengguna
 * pindah ke aplikasi lain. Hasilnya disimpan dan diberitahukan lewat notifikasi.
 */
public class DownloadService extends Service {

    /** Hasil akhir unduhan, menunggu ditampilkan. */
    public static class Result {
        boolean ok;
        String message, name, url, fallback;
        Saver.Target target;
    }

    public interface Listener {
        void onStatus(String text);
        void onFinished();
    }

    private static final String ACTION_STOP = "com.novan.githubbynovan.STOP_DOWNLOAD";
    private static final String CH_PROGRESS = "unduh_apk";
    private static final String CH_RESULT = "hasil_unduh_apk";
    private static final int ID_PROGRESS = 43, ID_RESULT = 44;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static volatile Listener listener;
    static volatile String lastText = "";
    static volatile boolean running;
    private static Result pending;

    static synchronized void setPending(Result r) { pending = r; }
    static synchronized Result takePending() { Result r = pending; pending = null; return r; }
    static synchronized boolean hasPending() { return pending != null; }

    private PowerManager.WakeLock lock;
    private volatile boolean cancelled;

    // ---------- pintu masuk ----------

    public static boolean busy() { return running; }

    public static boolean start(Context c, String url, String token, String name, boolean zip,
                                boolean octet, String fallback) {
        if (running) return false;
        setPending(null);
        lastText = "";
        cancelResultNotification(c);
        Saver.cancelDownload = false;
        Intent i = new Intent(c, DownloadService.class)
                .putExtra("url", url).putExtra("token", token).putExtra("name", name)
                .putExtra("zip", zip).putExtra("octet", octet).putExtra("fallback", fallback);
        try {
            running = true;
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            running = false;
            return false;
        }
    }

    /** Membatalkan unduhan yang sedang berjalan. */
    public static void cancel(Context c) {
        Saver.cancelDownload = true;
        c.startService(new Intent(c, DownloadService.class).setAction(ACTION_STOP));
    }

    public static void cancelResultNotification(Context c) {
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_RESULT);
        } catch (Exception ignored) { }
    }

    // ---------- siklus layanan ----------

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            cancelled = true;
            Saver.cancelDownload = true;
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || intent.getStringExtra("url") == null) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        final String url = intent.getStringExtra("url");
        final String token = intent.getStringExtra("token");
        final String name = intent.getStringExtra("name");
        final boolean zip = intent.getBooleanExtra("zip", false);
        final boolean octet = intent.getBooleanExtra("octet", false);
        final String fallback = intent.getStringExtra("fallback");

        cancelled = false;
        running = true;
        Notification n = progressNotification(name, "Memulai unduhan...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_PROGRESS, n);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (lock == null) lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "githubbynovan:unduh");
            if (!lock.isHeld()) lock.acquire(30 * 60 * 1000L);
        } catch (Exception ignored) { }

        Saver.saveUrl(this, url, token, name, zip, octet, fallback, new Saver.UrlListener() {
            @Override public void progress(long bytes) {
                String t = "Mengunduh " + name + ": " + Ui.size(bytes);
                lastText = t;
                updateOngoing(name, Ui.size(bytes));
                Listener l = listener;
                if (l != null) l.onStatus(t);
            }

            @Override public void done(boolean ok, String message, Saver.Target t) {
                running = false;
                if (cancelled || Saver.cancelDownload) {
                    stopForeground(true);
                    stopSelf();
                    return;
                }
                Result r = new Result();
                r.ok = ok;
                r.message = message;
                r.target = t;
                r.name = name;
                r.url = url;
                r.fallback = fallback;
                setPending(r);
                postResultNotification(r);
                Listener l = listener;
                if (l != null) l.onFinished();
                stopForeground(true);
                stopSelf();
            }
        });
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ---------- notifikasi ----------

    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_PROGRESS, "Unduhan APK",
                NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_RESULT, "Hasil unduhan APK",
                NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, 2, i, f);
    }

    private Notification.Builder builder(String channel) {
        ensureChannels();
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification progressNotification(String name, String text) {
        Intent stop = new Intent(this, DownloadService.class).setAction(ACTION_STOP);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPi = PendingIntent.getService(this, 3, stop, f);
        return builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Mengunduh " + name)
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(openApp())
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Batalkan unduhan", stopPi)
                .build();
    }

    private void updateOngoing(String name, String text) {
        try {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .notify(ID_PROGRESS, progressNotification(name, text));
        } catch (Exception ignored) { }
    }

    private void postResultNotification(Result r) {
        try {
            Notification n = builder(CH_RESULT)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(r.ok ? "APK berhasil diunduh" : "Gagal mengunduh APK")
                    .setContentText(r.ok ? r.name + ". Ketuk untuk memasang." : r.name + ". Ketuk untuk melihat rincian.")
                    .setAutoCancel(true)
                    .setContentIntent(openApp())
                    .build();
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_RESULT, n);
        } catch (Exception ignored) { }
    }
}
