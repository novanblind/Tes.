package com.novan.talkbacknovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Halaman Ekstensi: kelola, jalankan, ubah, dan pasang plugin Lua. */
public class PluginActivity extends Activity {
    private static final int MINTA_BERKAS = 71;
    private LinearLayout kolom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Ekstensi");
        ScrollView sv = new ScrollView(this);
        kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        kolom.setPadding(pad, pad, pad, pad);
        sv.addView(kolom);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        susun();
    }

    private void susun() {
        kolom.removeAllViews();
        TextView judul = new TextView(this);
        judul.setText("Ekstensi (plugin Lua)");
        judul.setTextSize(20);
        judul.setAccessibilityHeading(true);
        kolom.addView(judul);

        TextView info = new TextView(this);
        boolean aktif = TalkBackNovanService.instance != null;
        info.setText(aktif ? "Layanan aktif. Pilih plugin untuk menjalankan atau mengubahnya."
                : "Layanan aksesibilitas belum aktif; plugin baru bisa dijalankan setelah layanan aktif.");
        info.setPadding(0, 8, 0, 8);
        kolom.addView(info);

        kolom.addView(tombol("Buat plugin baru (tulis atau tempel kode Lua)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor(null);
            }
        }));
        kolom.addView(tombol("Pasang plugin dari berkas (.lua atau .zip)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, MINTA_BERKAS);
            }
        }));
        kolom.addView(tombol("Catatan umum ekstensi", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tampilTeks("Catatan umum", PluginManager.catatanUmum());
            }
        }));

        List<String> daftar = PluginManager.daftar(this);
        if (daftar.isEmpty()) {
            TextView kosong = new TextView(this);
            kosong.setText("Belum ada plugin.");
            kosong.setPadding(0, 16, 0, 0);
            kolom.addView(kosong);
        }
        for (final String nama : daftar) {
            String s = nama + ", " + (PluginManager.berjalan(nama) ? "berjalan" : "berhenti")
                    + (PluginManager.otomatis(this, nama) ? ", jalan otomatis" : "");
            kolom.addView(tombol(s, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    menuPlugin(nama);
                }
            }));
        }
    }

    private Button tombol(String teks, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(teks);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void menuPlugin(final String nama) {
        final boolean jalan = PluginManager.berjalan(nama);
        final boolean oto = PluginManager.otomatis(this, nama);
        final String[] pilihan = {
                jalan ? "Hentikan" : "Jalankan",
                oto ? "Matikan jalan otomatis" : "Jalankan otomatis saat layanan aktif",
                "Ubah kode",
                "Lihat catatan dan galat",
                "Hapus"
        };
        new AlertDialog.Builder(this)
                .setTitle(nama)
                .setItems(pilihan, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                if (jalan) {
                                    PluginManager.henti(nama);
                                    Toast.makeText(PluginActivity.this, "Plugin dihentikan.", Toast.LENGTH_SHORT).show();
                                } else {
                                    String galat = PluginManager.mulai(PluginActivity.this, nama);
                                    if (galat == null) {
                                        Toast.makeText(PluginActivity.this, "Plugin berjalan.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        tampilTeks("Plugin gagal berjalan", galat);
                                    }
                                }
                                break;
                            case 1:
                                PluginManager.aturOtomatis(PluginActivity.this, nama, !oto);
                                break;
                            case 2:
                                editor(nama);
                                return;
                            case 3:
                                String c = PluginManager.catatan(nama);
                                tampilTeks("Catatan " + nama, c.isEmpty() ? "Belum ada catatan." : c);
                                return;
                            case 4:
                                konfirmHapus(nama);
                                return;
                            default:
                        }
                        susun();
                    }
                })
                .show();
    }

    private void konfirmHapus(final String nama) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus " + nama + "?")
                .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Toast.makeText(PluginActivity.this, PluginManager.hapus(PluginActivity.this, nama),
                                Toast.LENGTH_SHORT).show();
                        susun();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void tampilTeks(String judul, String isi) {
        EditText e = new EditText(this);
        e.setText(isi);
        e.setKeyListener(null);
        e.setTextIsSelectable(true);
        e.setGravity(Gravity.TOP);
        e.setContentDescription(judul);
        new AlertDialog.Builder(this)
                .setTitle(judul)
                .setView(e)
                .setPositiveButton("Tutup", null)
                .show();
    }

    /** Editor sederhana; nama null berarti plugin baru. */
    private void editor(final String nama) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        final EditText namaEt = new EditText(this);
        namaEt.setSingleLine(true);
        namaEt.setHint("Nama plugin");
        namaEt.setContentDescription("Nama plugin");
        if (nama != null) {
            namaEt.setText(nama);
            namaEt.setEnabled(false);
        }
        final EditText kodeEt = new EditText(this);
        kodeEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        kodeEt.setMinLines(8);
        kodeEt.setGravity(Gravity.TOP);
        kodeEt.setContentDescription("Kode Lua main.lua");
        kodeEt.setText(nama == null
                ? "-- main.lua\nfunction onCreate()\n  service.speak(\"Plugin berjalan\")\nend\n"
                : PluginManager.baca(this, nama));
        box.addView(namaEt);
        box.addView(kodeEt);
        new AlertDialog.Builder(this)
                .setTitle(nama == null ? "Plugin baru" : "Ubah " + nama)
                .setView(box)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = nama != null ? nama : namaEt.getText().toString();
                        Toast.makeText(PluginActivity.this,
                                PluginManager.simpan(PluginActivity.this, n, kodeEt.getText().toString()),
                                Toast.LENGTH_SHORT).show();
                        susun();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MINTA_BERKAS && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                Toast.makeText(this, PluginManager.pasang(this, uri), Toast.LENGTH_LONG).show();
                susun();
            }
        }
    }
}
