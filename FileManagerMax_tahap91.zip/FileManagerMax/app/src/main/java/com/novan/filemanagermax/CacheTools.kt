package com.novan.filemanagermax

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import java.io.File

/**
 * File cache aplikasi. Android 11 ke atas melarang membaca Android/data milik aplikasi lain,
 * jadi ukuran cache diambil dari StorageStatsManager (perlu akses penggunaan) dan penghapusan
 * semua cache dilakukan lewat dialog sistem [StorageManager.ACTION_CLEAR_APP_CACHE].
 * Yang masih bisa dijangkau langsung (Android 10 ke bawah, dan cache aplikasi ini) dihapus sendiri.
 */
object CacheTools {

    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun usageSettingsIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    fun clearAllIntent(): Intent = Intent(StorageManager.ACTION_CLEAR_APP_CACHE)

    /** Folder cache yang bisa dijangkau langsung, dan apakah Android/data bisa dibaca. */
    private fun reachable(c: Context): Pair<List<File>, Boolean> {
        val out = LinkedHashMap<String, File>()
        var readable = false
        for (v in Volumes.list(c)) {
            val apps = try { File(v.root, "Android/data").listFiles() } catch (e: Exception) { null } ?: continue
            if (apps.isNotEmpty() || Build.VERSION.SDK_INT < 30) readable = true
            for (a in apps) {
                val d = File(a, "cache")
                if (d.isDirectory) out.putIfAbsent(d.absolutePath, d)
            }
        }
        c.cacheDir?.let { out.putIfAbsent(it.absolutePath, it) }
        for (d in c.externalCacheDirs) if (d != null) out.putIfAbsent(d.absolutePath, d)
        return out.values.toList() to readable
    }

    /** Total cache semua aplikasi, atau null bila tidak bisa diketahui. */
    fun totalSize(c: Context): Long? {
        val (dirs, readable) = reachable(c)
        if (readable) return dirs.sumOf { try { FileOps.sizeOf(it) } catch (e: Exception) { 0L } }
        if (Build.VERSION.SDK_INT >= 26 && hasUsageAccess(c)) return statsTotal(c)
        return null
    }

    private fun statsTotal(c: Context): Long? {
        val ssm = c.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val user = Process.myUserHandle()
        var total = 0L
        var answered = false
        for (ai in c.packageManager.getInstalledApplications(0)) {
            try {
                total += ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, user).cacheBytes
                answered = true
            } catch (e: SecurityException) {
                return null
            } catch (e: Exception) {
                // aplikasi ini dilewati
            }
        }
        return if (answered) total else null
    }

    /** Menghapus isi cache yang bisa dijangkau langsung. Mengembalikan jumlah byte yang dibebaskan. */
    fun deleteReachable(c: Context): Long {
        var freed = 0L
        for (d in reachable(c).first) {
            val kids = try { d.listFiles() } catch (e: Exception) { null } ?: continue
            for (k in kids) {
                val s = try { FileOps.sizeOf(k) } catch (e: Exception) { 0L }
                if (k.deleteRecursively()) freed += s
            }
        }
        return freed
    }
}
