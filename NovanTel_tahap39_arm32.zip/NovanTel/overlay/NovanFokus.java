package org.telegram.messenger;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Novan Tel - urutan fokus pembaca layar di halaman utama (tahap 30).
 *
 * Urutan yang diinginkan (geseran pertama langsung ke tab):
 *   tab kategori (Semua, Grup, Pribadi, Channel)  ->  daftar obrolan  ->  judul/menu dan kolom cari  ->  tombol-tombol bilah bawah layar.
 *
 * Caranya memakai aturan urutan telusur bawaan Android (setAccessibilityTraversalAfter/Before), yang dipahami TalkBack
 * dan pembaca layar lain, tanpa mengubah susunan atau gambar layar. Semua pekerjaan dibungkus try/catch: bila gagal,
 * urutan fokus kembali seperti bawaan Telegram dan aplikasi tidak terganggu.
 */
public final class NovanFokus {

    private static final String TAG = "NovanFokus";

    /** Bawaan build (novan-mod.properties: fokus_diagnosa). true = sekali per pembukaan aplikasi muncul kotak berisi daftar susunan layar, bisa disalin. */
    private static final boolean DIAGNOSA = __FOKUS_DIAGNOSA__;
    private static boolean diagnosaTampil = false;

    private NovanFokus() {
    }

    /**
     * Dipanggil dari DialogsActivity (onResume dan onBecomeFullyVisible).
     *
     * @param tab    tampilan tab kategori (filterTabsView)
     * @param halaman halaman daftar obrolan (viewPages; dua halaman karena geser antar tab saling bertukar)
     * @param akar   tampilan layar DialogsActivity (fragmentView)
     * @param atas   bilah judul/menu dan kolom cari (boleh berisi null); dibaca setelah daftar obrolan
     */
    public static void atur(final View tab, final View[] halaman, final View akar, final View[] atas) {
        try {
            if (Build.VERSION.SDK_INT < 22 || tab == null || halaman == null) {
                return;
            }
            beriId(tab);
            for (View h : halaman) {
                if (h != null) {
                    beriId(h);
                    // setiap halaman daftar dibaca SETELAH tab (dua halaman, karena keduanya bergantian saat geser antar tab)
                    h.setAccessibilityTraversalAfter(tab.getId());
                }
            }
            // judul/menu dan kolom cari dibaca SETELAH daftar obrolan (halaman yang sedang tampil), jadi tab tetap yang pertama
            View tampil = null;
            for (View h : halaman) {
                if (h != null && h.getVisibility() == View.VISIBLE) {
                    tampil = h;
                    break;
                }
            }
            if (tampil == null) {
                for (View h : halaman) {
                    if (h != null) {
                        tampil = h;
                        break;
                    }
                }
            }
            if (atas != null && tampil != null) {
                for (View a : atas) {
                    if (a != null) {
                        beriId(a);
                        a.setAccessibilityTraversalAfter(tampil.getId());
                    }
                }
            }
            if (akar != null) {
                // bilah bawah baru diketahui letaknya setelah layar selesai disusun
                akar.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            aturBilahBawah(tab, halaman, akar, atas);
                        } catch (Throwable t) {
                            Log.w(TAG, "bilah bawah gagal diatur", t);
                        }
                    }
                }, 400);
                if (DIAGNOSA && !diagnosaTampil) {
                    akar.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                tampilkanDiagnosa(akar);
                            } catch (Throwable t) {
                                Log.w(TAG, "diagnosa gagal", t);
                            }
                        }
                    }, 2500);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "urutan fokus gagal diatur", t);
        }
    }

    // ------------------------------------------------------------------ diagnosa susunan layar

    private static void tampilkanDiagnosa(View akar) {
        if (diagnosaTampil) {
            return;
        }
        diagnosaTampil = true;
        final Context c = akar.getContext();
        final String teks = kumpulkanDiagnosa(akar);
        Log.i(TAG, teks);
        ScrollView gulung = new ScrollView(c);
        TextView isi = new TextView(c);
        isi.setText(teks);
        isi.setTextIsSelectable(true);
        isi.setTextSize(11);
        isi.setPadding(32, 24, 32, 24);
        gulung.addView(isi);
        new AlertDialog.Builder(c)
                .setTitle("Diagnosa urutan fokus")
                .setView(gulung)
                .setPositiveButton("Salin", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        try {
                            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(ClipData.newPlainText("diagnosa fokus", teks));
                            Toast.makeText(c, "Tersalin", Toast.LENGTH_SHORT).show();
                        } catch (Throwable ignore) {
                        }
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private static String potong(CharSequence s, int maks) {
        if (s == null) {
            return "";
        }
        String t = s.toString().replace('\n', ' ');
        return t.length() > maks ? t.substring(0, maks) + "..." : t;
    }

    private static String kumpulkanDiagnosa(View akar) {
        StringBuilder sb = new StringBuilder();
        sb.append("Android ").append(Build.VERSION.SDK_INT).append(" ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        try {
            String layanan = Settings.Secure.getString(akar.getContext().getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            sb.append("Pembaca layar aktif: ").append(layanan == null ? "(tidak ada)" : layanan).append("\n");
        } catch (Throwable ignore) {
        }
        sb.append("Format: kelas #id [imp=mode F=fokus K=klik] teks/deskripsi (sebelum/sesudah)\n\n");
        int[] hitung = new int[]{0};
        tulisPohon(akar.getRootView(), 0, sb, hitung);
        return sb.toString();
    }

    private static void tulisPohon(View v, int kedalaman, StringBuilder sb, int[] hitung) {
        if (hitung[0] >= 400 || v.getVisibility() != View.VISIBLE) {
            return;
        }
        hitung[0]++;
        boolean grup = v instanceof ViewGroup;
        CharSequence teks = v instanceof TextView ? ((TextView) v).getText() : null;
        CharSequence desk = v.getContentDescription();
        boolean tampil = grup ? kedalaman <= 12 : (teks != null && teks.length() > 0) || desk != null || v.isClickable() || v.isFocusable();
        if (tampil) {
            for (int i = 0; i < kedalaman; i++) {
                sb.append(' ');
            }
            sb.append(v.getClass().getSimpleName());
            if (v.getId() != View.NO_ID) {
                sb.append(" #").append(Integer.toHexString(v.getId()));
            }
            sb.append(" [imp=").append(v.getImportantForAccessibility());
            if (v.isFocusable()) {
                sb.append(" F");
            }
            if (v.isClickable()) {
                sb.append(" K");
            }
            sb.append("]");
            if (teks != null && teks.length() > 0) {
                sb.append(" '").append(potong(teks, 30)).append("'");
            }
            if (desk != null) {
                sb.append(" \"").append(potong(desk, 30)).append("\"");
            }
            if (Build.VERSION.SDK_INT >= 22) {
                int sebelum = v.getAccessibilityTraversalBefore();
                int sesudah = v.getAccessibilityTraversalAfter();
                if (sebelum != View.NO_ID || sesudah != View.NO_ID) {
                    sb.append(" (sebelum=").append(Integer.toHexString(sebelum)).append(" sesudah=").append(Integer.toHexString(sesudah)).append(")");
                }
            }
            sb.append("\n");
        }
        if (grup) {
            ViewGroup g = (ViewGroup) v;
            int n = g.getChildCount();
            int batas = n > 8 ? 5 : n;
            for (int i = 0; i < batas; i++) {
                tulisPohon(g.getChildAt(i), kedalaman + 1, sb, hitung);
            }
            if (n > batas) {
                for (int i = 0; i < kedalaman + 1; i++) {
                    sb.append(' ');
                }
                sb.append("(").append(n - batas).append(" anak lain tidak ditampilkan)\n");
            }
        }
    }

    private static void beriId(View v) {
        if (v.getId() == View.NO_ID) {
            v.setId(View.generateViewId());
        }
    }

    private static boolean leluhurDari(View calon, View v) {
        // true bila 'calon' adalah v sendiri atau salah satu induk v
        Object p = v;
        int batas = 64;
        while (p instanceof View && batas-- > 0) {
            if (p == calon) {
                return true;
            }
            p = ((View) p).getParent();
        }
        return false;
    }

    private static void aturBilahBawah(View tab, View[] halaman, View akar, View[] atas) {
        View bilah = cariBilahBawah(tab, halaman, akar);
        if (bilah == null) {
            return;
        }
        beriId(bilah);
        tab.setAccessibilityTraversalBefore(bilah.getId());
        for (View h : halaman) {
            if (h != null) {
                h.setAccessibilityTraversalBefore(bilah.getId());
            }
        }
        if (atas != null) {
            for (View a : atas) {
                if (a != null && a != bilah && !leluhurDari(a, bilah) && !leluhurDari(bilah, a)) {
                    a.setAccessibilityTraversalBefore(bilah.getId());
                }
            }
        }
        Log.i(TAG, "bilah bawah ditemukan: " + bilah.getClass().getName());
    }

    /** Mencari wadah tombol di dasar layar: lebar, rendah, menempel dekat dasar jendela, berisi beberapa tombol. */
    private static View cariBilahBawah(View tab, View[] halaman, View akar) {
        View akarJendela = akar.getRootView();
        if (!(akarJendela instanceof ViewGroup)) {
            return null;
        }
        int lebar = akarJendela.getWidth();
        int tinggi = akarJendela.getHeight();
        if (lebar <= 0 || tinggi <= 0) {
            return null;
        }
        int[] lokasiAkar = new int[2];
        akarJendela.getLocationOnScreen(lokasiAkar);
        int dasarJendela = lokasiAkar[1] + tinggi;
        float dp = akar.getResources().getDisplayMetrics().density;

        View terbaik = null;
        long luasTerbaik = -1;
        ArrayList<View> tumpukan = new ArrayList<View>();
        tumpukan.add(akarJendela);
        int diperiksa = 0;
        int[] lok = new int[2];
        while (!tumpukan.isEmpty() && diperiksa < 6000) {
            View v = tumpukan.remove(tumpukan.size() - 1);
            diperiksa++;
            if (!(v instanceof ViewGroup) || v.getVisibility() != View.VISIBLE) {
                continue;
            }
            ViewGroup g = (ViewGroup) v;
            boolean terkecualikan = leluhurDari(g, tab) || leluhurDari(tab, g);
            for (View h : halaman) {
                if (h != null && (leluhurDari(g, h) || leluhurDari(h, g))) {
                    terkecualikan = true;
                }
            }
            if (!terkecualikan && g.isShown() && g.getWidth() >= lebar * 0.5f && g.getHeight() > 0 && g.getHeight() <= tinggi * 0.3f) {
                g.getLocationOnScreen(lok);
                int dasar = lok[1] + g.getHeight();
                if (dasar >= dasarJendela - 96 * dp && lok[1] > tinggi * 0.5f && jumlahTombol(g) >= 2) {
                    long luas = (long) g.getWidth() * g.getHeight();
                    if (luas > luasTerbaik) {
                        luasTerbaik = luas;
                        terbaik = g;
                    }
                }
            }
            for (int i = 0; i < g.getChildCount(); i++) {
                tumpukan.add(g.getChildAt(i));
            }
        }
        return terbaik;
    }

    private static int jumlahTombol(ViewGroup g) {
        int n = 0;
        ArrayList<View> tumpukan = new ArrayList<View>();
        tumpukan.add(g);
        int diperiksa = 0;
        while (!tumpukan.isEmpty() && diperiksa < 200) {
            View v = tumpukan.remove(tumpukan.size() - 1);
            diperiksa++;
            if (v != g && v.getVisibility() == View.VISIBLE && (v.isClickable() || v.isFocusable())) {
                n++;
                if (n >= 2) {
                    return n;
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) v;
                for (int i = 0; i < vg.getChildCount(); i++) {
                    tumpukan.add(vg.getChildAt(i));
                }
            }
        }
        return n;
    }
}
