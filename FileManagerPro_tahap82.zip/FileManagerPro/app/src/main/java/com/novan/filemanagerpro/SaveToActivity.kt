package com.novan.filemanagerpro

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.content.Intent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import java.io.File

/** Menerima berkas dari menu Bagikan aplikasi lain dan menyimpannya ke folder pilihan. */
class SaveToActivity : AppCompatActivity() {

    private var uris: List<Uri> = emptyList()

    private val launcher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) save(File(p)) else finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Access.hasAccess(this)) {
            Toast.makeText(this, R.string.permission_needed, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val list = ArrayList<Uri>()
        if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                ?.let { list.addAll(it) }
        } else {
            IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                ?.let { list.add(it) }
        }
        uris = list
        if (uris.isEmpty()) {
            Toast.makeText(this, R.string.saveto_nothing, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (savedInstanceState == null) {
            launcher.launch(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.saveto_title))
                    .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FOLDER)
            )
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n.replace('/', '_')
                }
            }
        } catch (e: Exception) {
            // abaikan
        }
        return (u.lastPathSegment ?: "berkas").substringAfterLast('/')
    }

    private fun save(dir: File) {
        val app = applicationContext
        val items = uris
        Toast.makeText(app, R.string.saveto_working, Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            for (u in items) {
                try {
                    val target = FileOps.uniqueTarget(dir, nameOf(u))
                    app.contentResolver.openInputStream(u)?.use { ins ->
                        target.outputStream().use { ins.copyTo(it) }
                        ok++
                    }
                } catch (e: Exception) {
                    // lanjut ke berkas berikut
                }
            }
            val fail = items.size - ok
            runOnUiThread {
                Toast.makeText(app, app.getString(R.string.paste_result, ok, fail), Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }
}
