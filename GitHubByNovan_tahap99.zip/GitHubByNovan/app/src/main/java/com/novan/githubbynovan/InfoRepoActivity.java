package com.novan.githubbynovan;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ubah deskripsi, tautan situs, topik, dan status arsip repositori. */
public class InfoRepoActivity extends Activity {
    private Ui ui;
    private String full, token;
    private boolean busy;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        full = getIntent().getStringExtra("repo");
        muat();
    }

    private String namaRepo() {
        return full.substring(full.indexOf('/') + 1);
    }

    private void muat() {
        ui = new Ui(this, "Info: " + namaRepo());
        ui.progress("Memuat info repositori...");
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
            if (isFinishing()) return;
            if (!ok) {
                ui = new Ui(this, "Info: " + namaRepo());
                ui.label("Gagal memuat info repositori.\n\n" + res);
                ui.button("Coba lagi", v -> muat());
                ui.button("Kembali", v -> finish());
                return;
            }
            tampil(Api.parse(res));
        });
    }

    private void tampil(JSONObject r) {
        busy = false;
        final boolean arsip = r.optBoolean("archived", false);
        ui = new Ui(this, "Info: " + namaRepo());
        ui.label("Repositori: " + full + "\nStatus: " + (arsip ? "diarsipkan (hanya baca)" : "aktif"));
        final EditText desc = ui.edit("Deskripsi", "keterangan singkat", false, Api.str(r, "description"));
        final EditText home = ui.edit("Tautan situs (homepage)", "contoh: https://contoh.com", false,
                Api.str(r, "homepage"));
        StringBuilder sb = new StringBuilder();
        JSONArray t = r.optJSONArray("topics");
        if (t != null) {
            for (int i = 0; i < t.length(); i++) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(t.optString(i));
            }
        }
        final EditText top = ui.edit("Topik (pisahkan dengan koma)", "contoh: android, apk", false, sb.toString());
        ui.button("Simpan", v -> simpan(desc.getText().toString().trim(), home.getText().toString().trim(),
                top.getText().toString()));
        if (arsip) {
            ui.button("Batalkan arsip (bisa diubah lagi)", v -> ubahArsip(false));
        } else {
            ui.button("Arsipkan repositori (hanya baca)", v -> ui.confirm("Arsipkan repositori?",
                    "Repositori jadi hanya baca: tidak bisa unggah berkas atau membangun APK sampai arsip dibatalkan.",
                    "arsipkan", () -> ubahArsip(true)));
        }
        ui.button("Kembali", v -> finish());
    }

    /** Topik GitHub: huruf kecil, angka, tanda hubung; maksimal 50 karakter dan 20 topik. */
    private static JSONArray topik(String teks) {
        JSONArray a = new JSONArray();
        List<String> sudah = new ArrayList<>();
        for (String bagian : teks.split("[,\\n]")) {
            String t = bagian.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", "-")
                    .replaceAll("[^a-z0-9-]", "").replaceAll("^-+", "");
            if (t.length() > 50) t = t.substring(0, 50);
            if (t.isEmpty() || sudah.contains(t) || sudah.size() >= 20) continue;
            sudah.add(t);
            a.put(t);
        }
        return a;
    }

    private void simpan(String desc, String home, String teksTopik) {
        if (busy) return;
        busy = true;
        ui.progress("Menyimpan...");
        final JSONArray names = topik(teksTopik);
        Api.request("PATCH", Api.BASE + "/repos/" + full, token,
                Api.o("description", desc, "homepage", home).toString(), (ok, res) -> {
                    if (isFinishing()) return;
                    if (!ok) {
                        busy = false;
                        ui.say("Gagal menyimpan: " + res);
                        return;
                    }
                    Api.request("PUT", Api.BASE + "/repos/" + full + "/topics", token,
                            Api.o("names", names).toString(), (ok2, res2) -> {
                                if (isFinishing()) return;
                                if (!ok2) {
                                    busy = false;
                                    ui.say("Deskripsi dan tautan tersimpan, tetapi topik gagal: " + res2);
                                    return;
                                }
                                ReposActivity.invalidate();
                                ui.say("Tersimpan.");
                                muat();
                            });
                });
    }

    private void ubahArsip(final boolean arsip) {
        if (busy) return;
        busy = true;
        ui.progress(arsip ? "Mengarsipkan..." : "Membatalkan arsip...");
        Api.request("PATCH", Api.BASE + "/repos/" + full, token, Api.o("archived", arsip).toString(), (ok, res) -> {
            if (isFinishing()) return;
            busy = false;
            if (!ok) {
                ui.say("Gagal: " + res);
                return;
            }
            ReposActivity.invalidate();
            ui.say(arsip ? "Repositori diarsipkan." : "Arsip dibatalkan.");
            muat();
        });
    }
}
