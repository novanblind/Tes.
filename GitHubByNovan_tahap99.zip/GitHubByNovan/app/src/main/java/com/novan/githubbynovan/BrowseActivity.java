package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BrowseActivity extends Activity {
    private static final int REQ_PICK = 5;
    private static final long MAX_UPLOAD = UnggahBesar.MAX;

    private Ui ui;
    private String full, path, repoName, token;
    private JSONArray items = new JSONArray();
    private boolean loaded;
    private boolean deleting;
    private UnggahService.Listener unggahListener;
    private boolean tampilUnggah;
    private final long[] baseline = {0};
    private boolean modePilih;
    /** Jalur item yang dicentang -> jenis (dir/file) dan sha. */
    private final Map<String, String[]> terpilih = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        full = getIntent().getStringExtra("repo");
        path = getIntent().getStringExtra("path");
        if (path == null) path = "";
        repoName = getIntent().getStringExtra("name");
        if (repoName == null) repoName = "";
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
        if (UnggahService.untuk(full)) {
            sambungUnggah();
        } else {
            tampilUnggah = false;
        }
    }

    @Override
    protected void onPause() {
        lepasUnggah();
        super.onPause();
    }

    private void load() {
        // Folder utama: jangan pakai garis miring di akhir ("/contents/"), karena bisa 404.
        String ep = Api.enc(path);
        String url = Api.BASE + "/repos/" + full + "/contents" + (ep.isEmpty() ? "" : "/" + ep);
        Api.request("GET", url, token, null, (ok, res) -> {
            loaded = true;
            if (!ok) {
                items = new JSONArray();
                render();
                if (res.contains("404") && path.isEmpty()) {
                    ui.say("Repositori masih kosong. Unggah atau tambah berkas untuk memulai.");
                } else if (res.contains("404")) {
                    ui.say("Folder tidak ditemukan. Kembali lalu coba lagi.");
                } else {
                    ui.say("Tidak bisa memuat isi: " + res);
                }
                return;
            }
            JSONArray arr = Api.parseArr(res);
            if (arr.length() == 0 && res.trim().startsWith("{")) {
                // Jalur ini berisi satu berkas, bukan folder.
                ui.say("Jalur ini adalah berkas, bukan folder.");
            }
            items = arr;
            render();
            ui.say("Ditemukan " + items.length() + " item.");
        });
    }

    private void render() {
        ui = new Ui(this, path.isEmpty() ? "Berkas: " + repoName : "Folder: " + path);
        if (UnggahService.untuk(full)) {
            String t = UnggahService.lastText;
            ui.progress(t.isEmpty() ? "Mengunggah..." : t);
            tambahBatal();
        }
        if (!loaded) {
            ui.label("Memuat...");
        } else {
            List<JSONObject> dirs = new ArrayList<>(), files = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it == null) continue;
                if ("dir".equals(it.optString("type"))) dirs.add(it); else files.add(it);
            }
            if (dirs.isEmpty() && files.isEmpty()) ui.label("Folder ini kosong.");
            if (modePilih) {
                renderPilih(dirs, files);
                ui.button("Kembali", v -> finish());
                return;
            }
            for (final JSONObject d : dirs) {
                android.widget.Button bd = ui.button("Folder " + d.optString("name"), v -> startActivity(
                        new Intent(this, BrowseActivity.class).putExtra("repo", full)
                                .putExtra("path", d.optString("path")).putExtra("name", repoName)));
                bd.setOnLongClickListener(v -> { mulaiPilih(d); return true; });
            }
            for (final JSONObject f : files) {
                android.widget.Button bf = ui.button("Berkas " + f.optString("name") + ", " + Ui.size(f.optLong("size")), v ->
                        startActivity(new Intent(this, FileActivity.class)
                                .putExtra("repo", full)
                                .putExtra("path", f.optString("path"))
                                .putExtra("name", f.optString("name"))
                                .putExtra("sha", f.optString("sha"))
                                .putExtra("size", f.optLong("size"))
                                .putExtra("html", f.optString("html_url"))
                                .putExtra("raw", f.optString("download_url"))));
                bf.setOnLongClickListener(v -> { mulaiPilih(f); return true; });
            }
            ui.button("Unggah berkas dari HP ke folder ini", v -> pilihBerkas());
            ui.button("Buat folder baru di sini", v -> promptFolder());
            ui.button("Tambah berkas teks baru di folder ini", v ->
                    ui.prompt("Nama berkas baru", "contoh: catatan.txt", "", n -> {
                        if (n.isEmpty()) return;
                        startActivity(new Intent(this, EditActivity.class)
                                .putExtra("repo", full).putExtra("path", target(n))
                                .putExtra("sha", "").putExtra("new", true));
                    }));
            ui.button("Riwayat commit " + (path.isEmpty() ? "repositori" : "folder ini")
                    + " (lihat dan kembalikan versi lama)", v -> startActivity(
                    new Intent(this, RiwayatActivity.class).putExtra("repo", full).putExtra("path", path)
                            .putExtra("name", path.isEmpty() ? repoName : path)));
            if (!dirs.isEmpty() || !files.isEmpty()) {
                ui.button("Hapus semua berkas di folder ini", Ui.DANGER, v -> confirmDeleteAll());
            }
        }
        ui.button("Kembali", v -> finish());
    }

    private String target(String name) {
        return path.isEmpty() ? name : path + "/" + name;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        List<Uri> uris = MultiUnggah.ambil(data);
        if (uris.isEmpty()) {
            ui.say("Tidak ada berkas yang dipilih.");
        } else if (uris.size() == 1) {
            upload(uris.get(0));
        } else {
            unggahBanyak(uris);
        }
    }

    private void promptFolder() {
        ui.prompt("Buat folder baru", "Nama folder", "", n -> {
            String nama = n.trim().replaceAll("^/+", "").replaceAll("/+$", "");
            if (nama.isEmpty()) {
                ui.say("Nama folder wajib diisi.");
                return;
            }
            for (String seg : nama.split("/")) {
                if (seg.trim().isEmpty() || seg.equals(".") || seg.equals("..") || seg.equalsIgnoreCase(".git")) {
                    ui.say("Nama folder tidak valid: " + seg);
                    return;
                }
            }
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it != null && nama.equals(it.optString("name"))) {
                    ui.say(("dir".equals(it.optString("type")) ? "Folder " : "Berkas ")
                            + nama + " sudah ada di sini.");
                    return;
                }
            }
            buatFolder(nama);
        });
    }

    /** GitHub tidak punya folder kosong, jadi folder dibuat lewat berkas penanda .gitkeep di dalamnya. */
    private void buatFolder(final String nama) {
        final String folderBaru = target(nama);
        ui.say("Membuat folder " + nama + "...");
        JSONObject body = Api.o("message", "Buat folder " + folderBaru,
                "content", Base64.encodeToString("\n".getBytes(), Base64.NO_WRAP));
        Api.request("PUT", Api.BASE + "/repos/" + full + "/contents/" + Api.enc(folderBaru + "/.gitkeep"),
                token, body.toString(), (ok, res) -> {
                    if (!ok) {
                        ui.say("Gagal membuat folder: " + res);
                        return;
                    }
                    ui.say("Folder " + nama + " berhasil dibuat.");
                    startActivity(new Intent(this, BrowseActivity.class).putExtra("repo", full)
                            .putExtra("path", folderBaru).putExtra("name", repoName));
                });
    }

    private void pilihBerkas() {
        if (UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        try {
            startActivityForResult(MultiUnggah.pemilih(), REQ_PICK);
        } catch (Exception e) {
            ui.say("Pemilih berkas tidak tersedia di HP ini: " + e.getMessage());
        }
    }

    private void tambahBatal() {
        ui.button("Batalkan unggahan", Ui.DANGER, v -> {
            UnggahService.cancel(this);
            ui.say("Unggahan sedang dihentikan...");
        });
    }

    private void unggahBanyak(final List<Uri> uris) {
        if (UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        final String tujuan = path.isEmpty() ? "folder utama repositori" : "folder " + path;
        ui.confirmCheck("Unggah " + uris.size() + " berkas?",
                "Diunggah ke " + tujuan + ". Berkas bernama sama akan diganti. "
                        + "Berjalan di latar belakang, boleh pindah aplikasi. "
                        + "Bila kotak di bawah dicentang, APK dibangun sekali setelah semua berhasil.",
                "Setelah berhasil, langsung bangun APK dan pantau", Store.autoBangun(this), "unggah semua", auto -> {
                    Store.setAutoBangun(this, auto);
                    ui.progress("Menyiapkan unggahan...");
                    ApkTools.baselineRun(full, token, () -> mulaiUnggah(uris, path, null, auto), baseline);
                });
    }

    /** Menyerahkan unggahan ke layanan latar depan, lalu menampilkan kemajuannya di layar ini. */
    private void mulaiUnggah(List<Uri> uris, String folder, String jalurTunggal, boolean auto) {
        if (UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        ApkTools.askNotif(this);
        if (!UnggahService.start(this, full, token, folder, uris, jalurTunggal, baseline[0], auto)) {
            ui.say("Unggahan belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.");
            return;
        }
        if (UnggahService.lastText.isEmpty()) {
            UnggahService.lastText = jalurTunggal != null ? "Mulai mengunggah " + jalurTunggal + "..."
                    : "Mulai mengunggah " + uris.size() + " berkas...";
        }
        sambungUnggah();
    }

    /** Menampilkan kemajuan unggahan yang sedang berjalan; dipanggil juga saat kembali ke layar ini. */
    private void sambungUnggah() {
        lepasUnggah();
        tampilUnggah = true;
        render();
        final UnggahService.Listener[] self = new UnggahService.Listener[1];
        self[0] = new UnggahService.Listener() {
            @Override public void onStatus(String text) {
                if (!isFinishing()) ui.progress(text);
            }

            @Override public void onFinished() {
                if (UnggahService.listener == self[0]) UnggahService.listener = null;
                if (unggahListener == self[0]) unggahListener = null;
                if (!isFinishing() && !isDestroyed()) selesaiUnggah();
            }
        };
        unggahListener = self[0];
        UnggahService.listener = self[0];
        if (!UnggahService.busy()) self[0].onFinished();
    }

    private void lepasUnggah() {
        if (UnggahService.listener == unggahListener) UnggahService.listener = null;
        unggahListener = null;
    }

    private void selesaiUnggah() {
        tampilUnggah = false;
        load();
        UnggahService.Hasil r = UnggahService.takePending();
        if (r == null) {
            ui.say("Unggahan dihentikan.");
            return;
        }
        UnggahService.cancelResultNotification(this);
        MultiUnggah.Hasil h = r.h;
        if (r.tunggal) {
            ui.say(h.berhasil > 0 ? "Berkas berhasil diunggah." : h.dibatalkan ? "Unggahan dibatalkan." : "Gagal mengunggah berkas.");
        } else {
            ui.say("Unggahan selesai. Berhasil " + h.berhasil + " dari " + h.total + " berkas"
                    + (h.gagal.isEmpty() ? "." : ", gagal " + h.gagal.size() + "."));
        }
        ApkTools.hasilUnggah(this, r, null, this::pilihBerkas);
    }

    private void upload(final Uri uri) {
        if (UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        String name = "berkas";
        long size = -1;
        try {
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) { }
        if (size > MAX_UPLOAD) {
            ui.say("Berkas lebih dari 100 MB, terlalu besar.");
            return;
        }
        final String fn = name;
        boolean sudahAda = false;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it != null && fn.equals(it.optString("name"))) sudahAda = true;
        }
        // Satu dialog untuk satu berkas: ringkasan, peringatan timpa (bila ada), dan pilihan bangun otomatis.
        final String tujuan1 = path.isEmpty() ? "folder utama repositori" : "folder " + path;
        ui.confirmCheck(sudahAda ? "Berkas sudah ada. Timpa?" : "Unggah berkas?",
                fn + (size >= 0 ? " (" + Ui.size(size) + ")" : "") + " akan diunggah ke " + tujuan1 + "."
                        + (sudahAda ? " Berkas lama bernama sama akan ditimpa." : "")
                        + " Bila kotak di bawah dicentang, APK dibangun setelah unggahan berhasil.",
                "Setelah berhasil, langsung bangun APK dan pantau", Store.autoBangun(this), sudahAda ? "timpa" : "unggah", auto -> {
                    Store.setAutoBangun(this, auto);
                    kirimTunggal(uri, fn, auto);
                });
    }

    /** Unggah satu berkas (sampai 100 MB) lewat layanan latar depan, dengan kemajuan, tombol batal, dan ulang otomatis. */
    private void kirimTunggal(final Uri uri, final String name, final boolean auto) {
        if (UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        ui.progress("Menyiapkan unggahan " + name + "...");
        ApkTools.baselineRun(full, token,
                () -> mulaiUnggah(java.util.Collections.singletonList(uri), "", target(name), auto), baseline);
    }

    /** Tekan tahan pada folder atau berkas: masuk mode pilih dengan item itu sudah tercentang. */
    private void mulaiPilih(JSONObject it) {
        if (deleting) { ui.say("Penghapusan sedang berjalan. Mohon tunggu."); return; }
        terpilih.clear();
        terpilih.put(it.optString("path"),
                new String[]{"dir".equals(it.optString("type")) ? "dir" : "file", it.optString("sha")});
        modePilih = true;
        render();
        ui.say("Mode pilih aktif. " + it.optString("name") + " tercentang. Ketuk item lain untuk mengubah centang.");
    }

    @Override
    public void onBackPressed() {
        if (modePilih) {
            terpilih.clear();
            modePilih = false;
            render();
            ui.say("Mode pilih dibatalkan.");
            return;
        }
        super.onBackPressed();
    }

    /** Tampilan mode centang: tiap folder dan berkas punya kotak centang. */
    private void renderPilih(List<JSONObject> dirs, List<JSONObject> files) {
        ui.label("Mode pilih. Ketuk item untuk mencentang, lalu tekan Hapus yang dicentang. "
                + "Folder ikut terhapus beserta isinya.");
        final List<JSONObject> semua = new ArrayList<>();
        semua.addAll(dirs);
        semua.addAll(files);
        for (final JSONObject it : semua) {
            final boolean dir = "dir".equals(it.optString("type"));
            final String jalur = it.optString("path");
            String teks = dir ? "Folder " + it.optString("name")
                    : "Berkas " + it.optString("name") + ", " + Ui.size(it.optLong("size"));
            android.widget.CheckBox cb = ui.check(teks, terpilih.containsKey(jalur));
            cb.setOnCheckedChangeListener((b, on) -> {
                if (on) terpilih.put(jalur, new String[]{dir ? "dir" : "file", it.optString("sha")});
                else terpilih.remove(jalur);
            });
        }
        ui.button("Pilih semua", v -> {
            for (JSONObject it : semua) {
                terpilih.put(it.optString("path"),
                        new String[]{"dir".equals(it.optString("type")) ? "dir" : "file", it.optString("sha")});
            }
            render();
            ui.say("Semua " + semua.size() + " item dicentang.");
        });
        ui.button("Hapus yang dicentang", Ui.DANGER, v -> konfirmasiHapusPilihan());
        ui.button("Batal pilih", v -> {
            terpilih.clear();
            modePilih = false;
            render();
        });
    }

    private void konfirmasiHapusPilihan() {
        if (deleting) { ui.say("Penghapusan sedang berjalan. Mohon tunggu."); return; }
        if (terpilih.isEmpty()) { ui.say("Belum ada yang dicentang."); return; }
        int d = 0, f = 0;
        for (String[] v : terpilih.values()) { if ("dir".equals(v[0])) d++; else f++; }
        final String ringkas = f + " berkas dan " + d + " folder";
        ui.confirm("Hapus yang dicentang?",
                ringkas + " akan dihapus dari " + lokasi() + ". Isi folder ikut terhapus dan tidak bisa dibatalkan.",
                "hapus", this::deleteTerpilih);
    }

    private void deleteTerpilih() {
        if (deleting) return;
        deleting = true;
        final Map<String, String[]> pilihan = new LinkedHashMap<>(terpilih);
        ui.say("Menghitung berkas yang akan dihapus...");
        Api.POOL.execute(() -> {
            List<String[]> list = new ArrayList<>();
            for (Map.Entry<String, String[]> e : pilihan.entrySet()) {
                if ("dir".equals(e.getValue()[0])) {
                    String err = collect(e.getKey(), list);
                    if (err != null) {
                        final String fe = err;
                        runOnUiThread(() -> { deleting = false; ui.say(fe); });
                        return;
                    }
                } else {
                    list.add(new String[]{e.getKey(), e.getValue()[1]});
                }
            }
            hapusDaftar(list, "item yang dicentang", true);
        });
    }

    private String lokasi() {
        return path.isEmpty() ? "seluruh repositori " + repoName : "folder " + path;
    }

    private void confirmDeleteAll() {
        if (deleting) { ui.say("Penghapusan sedang berjalan. Mohon tunggu."); return; }
        ui.confirm("Hapus semua berkas?",
                "Semua berkas dan folder di dalam " + lokasi() + " akan dihapus, termasuk subfolder. Lanjutkan?", "lanjut", () ->
                ui.confirm("Yakin hapus semua?",
                        "Penghapusan terakhir untuk " + lokasi() + ". Tidak bisa dibatalkan.", "hapus semua", this::deleteAll));
    }

    /** Kumpulkan semua berkas (rekursif) di bawah jalur p. Mengembalikan pesan galat, atau null bila sukses. */
    private String collect(String p, List<String[]> out) {
        String ep = Api.enc(p);
        Api.Result r = Api.requestSync("GET",
                Api.BASE + "/repos/" + full + "/contents" + (ep.isEmpty() ? "" : "/" + ep), token, null);
        if (!r.ok) return "Gagal membaca " + (p.isEmpty() ? "folder utama" : p) + ": " + r.text;
        JSONArray arr = Api.parseArr(r.text);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject it = arr.optJSONObject(i);
            if (it == null) continue;
            String type = it.optString("type");
            if ("dir".equals(type)) {
                String err = collect(it.optString("path"), out);
                if (err != null) return err;
            } else if (!"submodule".equals(type)) {
                out.add(new String[]{it.optString("path"), it.optString("sha")});
            }
        }
        return null;
    }

    private void deleteAll() {
        if (deleting) return;
        deleting = true;
        final String start = path;
        final String lokasiTeks = lokasi();
        ui.say("Menghitung berkas yang akan dihapus...");
        Api.POOL.execute(() -> {
            List<String[]> list = new ArrayList<>();
            String err = collect(start, list);
            if (err != null) {
                final String fe = err;
                runOnUiThread(() -> { deleting = false; ui.say(fe); });
                return;
            }
            hapusDaftar(list, lokasiTeks, false);
        });
    }

    /** Hapus daftar berkas (jalur, sha) satu per satu. Dipanggil dari thread latar. */
    private void hapusDaftar(final List<String[]> list, final String lokasiTeks, final boolean dariPilihan) {
        final int total = list.size();
        if (total == 0) {
            runOnUiThread(() -> { deleting = false; ui.say("Tidak ada berkas untuk dihapus."); load(); });
            return;
        }
        runOnUiThread(() -> ui.say("Menghapus " + total + " berkas. Jangan tutup aplikasi."));
        int ok = 0, fail = 0;
        String lastErr = "";
        for (int i = 0; i < total; i++) {
            String[] f = list.get(i);
            String nama = f[0].substring(f[0].lastIndexOf('/') + 1);
            final int n = i + 1;
            final String shown = nama;
            runOnUiThread(() -> ui.progress("Menghapus " + n + " dari " + total + ": " + shown));
            String url = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(f[0]);
            String body = Api.o("message", "Hapus " + f[0], "sha", f[1]).toString();
            Api.Result r = null;
            for (int a = 1; a <= 3; a++) {
                r = Api.requestSync("DELETE", url, token, body);
                // 409 = komit lain sedang berjalan di GitHub; coba lagi sebentar kemudian.
                if (r.ok || !r.text.contains("409")) break;
                try { Thread.sleep(1500L * a); } catch (Exception ignored) { }
            }
            if (r != null && r.ok) ok++; else { fail++; lastErr = r == null ? "" : r.text; }
        }
        final int fok = ok, ffail = fail;
        final String fl = lastErr;
        runOnUiThread(() -> {
            deleting = false;
            if (dariPilihan) { terpilih.clear(); modePilih = false; }
            if (isFinishing()) return;
            String msg = "Selesai. " + fok + " berkas dihapus dari " + lokasiTeks + ".";
            if (ffail > 0) msg += " " + ffail + " berkas gagal dihapus. Galat terakhir: " + fl;
            if (!dariPilihan) msg += " Bila masih ada sisa, ulangi hapus.";
            load();
            ui.say(msg);
        });
    }
}
