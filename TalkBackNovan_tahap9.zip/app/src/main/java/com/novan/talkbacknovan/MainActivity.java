package com.novan.talkbacknovan;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("TalkBack Novan");

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        kolom.setPadding(pad, pad, pad, pad);

        TextView judul = new TextView(this);
        judul.setText("TalkBack Novan");
        judul.setTextSize(24);
        judul.setAccessibilityHeading(true);
        kolom.addView(judul);

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0, pad, 0, pad);
        kolom.addView(status);

        kolom.addView(tombol("Buka pengaturan aksesibilitas", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));
        kolom.addView(tombol("Beri akses notifikasi", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        }));
        kolom.addView(tombol("Pengaturan TalkBack Novan", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        }));
        kolom.addView(tombol("Uji suara", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TalkBackNovanService.instance != null) {
                    TalkBackNovanService.ucapkanContoh("Ini contoh suara TalkBack Novan.");
                } else {
                    Toast.makeText(MainActivity.this,
                            "Layanan belum aktif. Aktifkan dulu di pengaturan aksesibilitas.",
                            Toast.LENGTH_LONG).show();
                }
            }
        }));

        TextView tentang = new TextView(this);
        tentang.setPadding(0, pad, 0, 0);
        tentang.setText("Versi 0.6.0 (tahap 6)\n"
                + "Satu jari: geser kanan/kiri pindah menurut granularitas; geser bawah/atas "
                + "ganti granularitas (item, judul, tautan, tombol, kolom isian, kotak centang, gambar, "
                + "karakter, kata, kalimat, paragraf); geser atas lalu kiri = beranda, "
                + "bawah lalu kiri = kembali, kiri lalu atas = aplikasi terbaru, kanan lalu bawah = notifikasi.\n"
                + "Dua jari: ketuk = hentikan suara; usap dan ketuk dua kali sesuai pengaturan "
                + "(bawaan: gulir, halaman, baca seluruh layar).\n"
                + "Tiga jari: ketuk = jam dan baterai; usap sesuai pengaturan.\n"
                + "Notifikasi dibacakan lewat akses notifikasi (tombol di atas). Pasang aksi \"Ganti nama elemen terfokus\" "
                + "ke gestur atau tombol untuk memberi nama baru pada elemen.\n"
                + "Ketuk dua kali tiga jari = menu elemen terfokus (ketuk, salin, tempel, aksi khusus aplikasi). "
                + "Aksi Salin, Tempel, Potong, Pilih semua teks, dan Tampilkan teks layar bisa dipasang ke gestur lain.\n"
                + "OCR memakai Gemini dan Groq: isi kunci API di Pengaturan, lalu pasang aksi \"OCR seluruh layar\" "
                + "atau \"OCR elemen terfokus\" ke gestur. Gambar yang dibagikan ke TalkBack Novan juga dikenali.\n"
                + "Perintah suara: ketuk empat jari lalu ucapkan, misalnya \"beranda\", \"baca layar\", \"salin\", "
                + "\"gulir ke bawah\", atau \"buka WhatsApp\". Semua gestur (termasuk kombinasi usapan dan empat jari) "
                + "bisa diberi aksi bebas di Pengaturan.\n"
                + "Tekan lama volume atas = ketuk elemen terfokus; volume bawah = baca dari item ini.");
        kolom.addView(tentang);

        ScrollView sv = new ScrollView(this);
        sv.addView(kolom);
        setContentView(sv);
    }

    private Button tombol(String teks, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(teks);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText(layananAktif()
                ? "Status: TalkBack Novan aktif."
                : "Status: belum aktif. Buka pengaturan aksesibilitas, pilih TalkBack Novan, lalu nyalakan.");
    }

    private boolean layananAktif() {
        String aktif = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (aktif == null) return false;
        ComponentName cn = new ComponentName(this, TalkBackNovanService.class);
        return aktif.contains(cn.flattenToString()) || aktif.contains(cn.flattenToShortString());
    }
}
