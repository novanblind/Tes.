cmake_minimum_required(VERSION 3.18)
project(lamejni C)

# Sumber LAME diunduh oleh tugas Gradle "unduhLame" ke folder lame_src (-DLAME_DIR dari Gradle).
if(NOT EXISTS "${LAME_DIR}/libmp3lame/lame.c")
    message(FATAL_ERROR "Sumber LAME tidak ditemukan di ${LAME_DIR}")
endif()

file(GLOB LAME_SRC "${LAME_DIR}/libmp3lame/*.c")
# Penguraian MP3 (mpglib) tidak dipakai; hanya penyandian.
list(FILTER LAME_SRC EXCLUDE REGEX "mpglib_interface\\.c$")

add_library(lamejni SHARED lamejni.c ${LAME_SRC})

target_include_directories(lamejni PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/compat
    ${LAME_DIR}/include
    ${LAME_DIR}/libmp3lame)

target_compile_definitions(lamejni PRIVATE HAVE_CONFIG_H LAME_LIBRARY_BUILD NDEBUG)
target_compile_options(lamejni PRIVATE -Os -ffunction-sections -fdata-sections -fvisibility=hidden -w)
# Selaras dengan ukuran halaman 16 KB (Android 15+).
target_link_options(lamejni PRIVATE -Wl,-z,max-page-size=16384 -Wl,--gc-sections -Wl,-s)
target_link_libraries(lamejni m log)
