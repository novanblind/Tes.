package com.novan.filemanagerpro

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipFile

/** Memasang berkas APK (.apk) dan paket split (.apk+, .apks, .xapk, .apkm) lewat PackageInstaller. */
class SplitInstallActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        private const val ACTION_RESULT = "com.novan.filemanagerpro.INSTALL_RESULT"
        fun isSplitPackage(f: File): Boolean =
            f.extension.lowercase() in setOf("apk", "apk+", "apks", "xapk", "apkm")
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btnOpen: Button
    private lateinit var btnDone: Button
    private var launchIntent: Intent? = null
    private var started = false
    private var askedPermission = false
    private var copiedFile: File? = null
    private var prepared: File? = null
    private var kindChecked = false
    private var sessionId = -1
    private var finished = false
    private var installedSource: File? = null

    private val resultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, i: Intent) {
            if (i.action == ACTION_RESULT) handleResult(i)
        }
    }

    // cadangan: bila hasil dari pemasang tidak sampai, pasangnya paket tetap terdeteksi
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, i: Intent) {
            if (sessionId < 0 || finished) return
            val pkg = i.data?.schemeSpecificPart ?: return
            val expected = try {
                packageManager.packageInstaller.getSessionInfo(sessionId)?.appPackageName
            } catch (e: Exception) { null }
            if (expected != null && expected != pkg) return
            showSuccess(pkg)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.split_title)
        status = TextView(this).apply {
            setPadding(48, 48, 48, 48)
            textSize = 18f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        val gap = (16 * resources.displayMetrics.density).toInt()
        fun buttonParams() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(gap, 0, gap, gap) }
        btnOpen = Button(this).apply {
            setText(R.string.split_open)
            visibility = View.GONE
            setOnClickListener {
                launchIntent?.let { li ->
                    try { startActivity(li) } catch (e: Exception) { /* tidak bisa dibuka */ }
                }
                finish()
            }
        }
        btnDone = Button(this).apply {
            setText(R.string.split_finish)
            visibility = View.GONE
            setOnClickListener { finish() }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(btnOpen, buttonParams())
            addView(btnDone, buttonParams())
        }
        setContentView(root)
        val rf = IntentFilter(ACTION_RESULT)
        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(resultReceiver, rf, Context.RECEIVER_EXPORTED)
            registerReceiver(packageReceiver, pf, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(resultReceiver, rf)
            registerReceiver(packageReceiver, pf)
        }
        if (intent.action == ACTION_RESULT) {
            handleResult(intent)
            started = true
        }
    }

    /** Berkas yang dibuka dari aplikasi lain (WhatsApp, Telegram, peramban, dll). */
    private fun incomingUri(): Uri? =
        if (intent.action == Intent.ACTION_VIEW) intent.data else null

    private fun displayName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
            } catch (e: Exception) { /* abaikan */ }
        }
        return (name ?: uri.lastPathSegment ?: "paket.apk").substringAfterLast('/')
            .replace(Regex("[^A-Za-z0-9._+ -]"), "_")
    }

    /** Mengubah Uri masuk menjadi File di penyimpanan aplikasi (content://) atau File asli (file://). */
    private fun materialize(uri: Uri): File {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: throw IllegalStateException(getString(R.string.split_no_file)))
            if (f.canRead()) return f
        }
        val dir = File(cacheDir, "incoming").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, displayName(uri))
        val ins = contentResolver.openInputStream(uri)
            ?: throw IllegalStateException(getString(R.string.split_no_file))
        ins.use { i -> out.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        copiedFile = out
        return out
    }

    /** true bila berkas ZIP ini adalah satu APK biasa (punya AndroidManifest.xml di akar). */
    private fun isSingleApk(file: File): Boolean = try {
        ZipFile(file).use { it.getEntry("AndroidManifest.xml") != null }
    } catch (e: Exception) {
        throw IllegalStateException(getString(R.string.split_no_apk))
    }

    override fun onResume() {
        super.onResume()
        if (!started) tryStart()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_RESULT) handleResult(intent)
        else if (intent.action == Intent.ACTION_VIEW) {
            started = false
            finished = false
            kindChecked = false
            prepared = null
            sessionId = -1
            btnOpen.visibility = View.GONE
            btnDone.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        try { unregisterReceiver(resultReceiver) } catch (e: Exception) { }
        try { unregisterReceiver(packageReceiver) } catch (e: Exception) { }
        if (isFinishing) copiedFile?.delete()
    }

    private fun tryStart() {
        val path = intent.getStringExtra(EXTRA_PATH)
        val uri = incomingUri()
        if (path == null && uri == null) {
            status.setText(R.string.split_no_file)
            started = true
            return
        }
        if (path == null && uri != null && !kindChecked) {
            val n = displayName(uri).lowercase()
            val known = listOf(".apk", ".apks", ".xapk", ".apkm", ".apk+").any { n.endsWith(it) }
            if (!known) {
                // jenis berkas belum jelas (zip biasa?): periksa isinya dulu sebelum meminta izin pasang
                started = true
                status.setText(R.string.split_checking)
                executor.execute {
                    // 0 = paket aplikasi, 1 = arsip biasa, 2 = bukan keduanya
                    val kind = try {
                        val f = materialize(uri)
                        prepared = f
                        ZipFile(f).use { z ->
                            val hasApk = z.getEntry("AndroidManifest.xml") != null ||
                                z.entries().asSequence().any { !it.isDirectory && it.name.lowercase().endsWith(".apk") }
                            if (hasApk) 0 else 1
                        }
                    } catch (e: Exception) {
                        2
                    }
                    main.post {
                        if (isFinishing || isDestroyed) return@post
                        when (kind) {
                            1 -> {
                                startActivity(
                                    Intent(this, ArchiveActivity::class.java)
                                        .setData(uri)
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                )
                                finish()
                            }
                            2 -> {
                                status.setText(R.string.split_not_package)
                                btnDone.visibility = View.VISIBLE
                                btnDone.requestFocus()
                                btnDone.announceForAccessibility(getString(R.string.split_not_package))
                            }
                            else -> {
                                kindChecked = true
                                started = false
                                tryStart()
                            }
                        }
                    }
                }
                return
            }
        }
        if (!packageManager.canRequestPackageInstalls()) {
            if (askedPermission) {
                // pengguna kembali tanpa mengizinkan: tutup tanpa keterangan apa pun
                finish()
                return
            }
            askedPermission = true
            status.setText(R.string.split_need_permission)
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                // pengguna membuka pengaturan sendiri
            }
            return
        }
        started = true
        status.setText(R.string.split_installing)
        executor.execute {
            val err = try {
                val file = if (path != null) File(path) else (prepared ?: materialize(uri!!))
                install(file)
                null
            } catch (e: Exception) {
                e.message ?: e.javaClass.simpleName
            }
            if (err != null) main.post { status.text = getString(R.string.split_failed, err) }
        }
    }

    private fun install(file: File) {
        val pi = packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        installedSource = file
        val id = pi.createSession(params)
        sessionId = id
        val session = pi.openSession(id)
        var count = 0
        try {
            val written = HashSet<String>()
            if (isSingleApk(file)) {
                file.inputStream().use { ins ->
                    session.openWrite("base.apk", 0, file.length()).use { out ->
                        ins.copyTo(out)
                        session.fsync(out)
                    }
                }
                count++
            } else ZipFile(file).use { z ->
                for (e in z.entries()) {
                    if (e.isDirectory || !e.name.lowercase().endsWith(".apk")) continue
                    // lewati bila nama sama (mis. base.apk dan splits/base-master.apk)
                    if (!written.add(File(e.name).name)) continue
                    z.getInputStream(e).use { ins ->
                        session.openWrite(File(e.name).name, 0, e.size).use { out ->
                            ins.copyTo(out)
                            session.fsync(out)
                        }
                    }
                    count++
                }
            }
            if (count == 0) throw IllegalStateException(getString(R.string.split_no_apk))
            val cb = PendingIntent.getBroadcast(
                this, id,
                Intent(ACTION_RESULT).setPackage(packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            session.commit(cb.intentSender)
        } catch (e: Exception) {
            session.abandon()
            throw e
        } finally {
            session.close()
        }
    }

    // XAPK/APK+ dapat membawa data OBB (Android/obb/<paket>/file.obb): disalin ke folder obb setelah terpasang.
    private fun copyObb(file: File): Int {
        var n = 0
        try {
            ZipFile(file).use { z ->
                val rx = Regex("(?i)^(?:.*/)?Android/obb/([^/]+)/([^/]+\\.obb)$")
                for (e in z.entries()) {
                    if (e.isDirectory) continue
                    val m = rx.find(e.name) ?: continue
                    val dir = File(android.os.Environment.getExternalStorageDirectory(), "Android/obb/${m.groupValues[1]}")
                    dir.mkdirs()
                    z.getInputStream(e).use { ins ->
                        File(dir, m.groupValues[2]).outputStream().use { o -> ins.copyTo(o, 256 * 1024) }
                    }
                    n++
                }
            }
        } catch (e: Exception) { /* izin tidak ada atau bukan zip: lewati */ }
        return n
    }

    private fun showSuccess(pkg: String?) {
        if (finished) return
        finished = true
        val src = installedSource
        executor.execute {
            val obb = try { if (src != null) copyObb(src) else 0 } catch (e: Exception) { 0 }
            main.post {
                if (obb > 0) status.text = getString(R.string.split_done_obb, obb)
                else status.setText(R.string.split_done)
            }
        }
        main.post {
            status.setText(R.string.split_done)
            launchIntent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
            btnOpen.visibility = if (launchIntent != null) View.VISIBLE else View.GONE
            btnDone.visibility = View.VISIBLE
            btnDone.requestFocus()
            btnDone.announceForAccessibility(getString(R.string.split_done))
        }
    }

    @Suppress("DEPRECATION")
    private fun handleResult(i: Intent) {
        when (val st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                status.setText(R.string.split_confirm)
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) startActivity(confirm)
            }
            PackageInstaller.STATUS_SUCCESS ->
                showSuccess(i.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME))
            // pengguna menekan batal: kembali ke halaman sebelumnya tanpa pesan
            PackageInstaller.STATUS_FAILURE_ABORTED -> finish()
            else -> status.text = getString(
                R.string.split_failed,
                (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "") + " ($st)"
            )
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) { finish(); true } else super.onOptionsItemSelected(item)
}
