plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.novan.pembacauang"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.novan.pembacauang"
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        // Satu APK untuk HP 64-bit (arm64-v8a) dan 32-bit (armeabi-v7a). x86/x86_64 dibuang
        // karena library OCR ML Kit dibawa per ABI.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        // Hanya bahasa yang dipakai; string bahasa lain dari library dibuang.
        resourceConfigurations += listOf("id", "en")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    packaging {
        resources.excludes += listOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/LICENSE*", "/META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // OCR ML Kit (model Latin sudah ikut di dalam aplikasi, jalan offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")

    testImplementation("junit:junit:4.13.2")
}
