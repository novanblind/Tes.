package com.novan.talkbacknovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {
    private SharedPreferences sp;
    private LinearLayout kolom;
    private Button tombolGema;
    private Button tombolMesin;

    private static final String[] NAMA_GEMA = {"Tidak ada", "Karakter", "Kata", "Karakter dan kata"};

    public static final String EXTRA_HALAMAN = "halaman";

    static final String[][] MENU_UTAMA = {
            {"cari", "Cari"},
            {"umum", "Pengaturan umum"},
            {"tts", "Pengaturan teks ke ucapan"},
            {"umpan", "Pengaturan umpan balik"},
            {"tindakan", "Pengaturan tindakan"},
            {"konten", "Pengaturan pengucapan konten"},
            {"notifikasi", "Pengaturan pemberitahuan"},
            {"lanjutan", "Pengaturan lanjutan"},
            {"ekstensi", "Ekstensi"},
            {"alat", "Plugin dan peralatan"},
            {"lainnya", "Pengaturan lainnya"},
    };

    /** Halaman yang ikut dicari oleh menu Cari. */
    private static final String[] INDEKS = {
            "umum", "tts", "umpan", "tindakan", "gdefault", "alternatif", "gerakan", "gestur1", "gestur2", "gestur3",
            "deskripsi", "kelola", "pintasan",
            "konten", "label", "notifikasi", "lanjutan", "ocr", "masukan", "alat", "lainnya", "bantuan"
    };

    private static String judulHalaman(String h) {
        for (String[] m : MENU_UTAMA) if (m[0].equals(h)) return m[1];
        switch (h) {
            case "gestur1": return "Pengaturan gestur satu jari";
            case "gestur2": return "Pengaturan gestur dua jari";
            case "gestur3": return "Pengaturan gestur tiga dan empat jari";
            case "gdefault": return "Pengaturan Gestur Default";
            case "alternatif": return "Pengaturan gerakan alternatif";
            case "gerakan": return "Pengaturan gerakan";
            case "deskripsi": return "Deskripsi gerakan";
            case "kelola": return "Kelola gerakan";
            case "pintasan": return "Pengaturan tombol pintasan";
            case "ocr": return "Pengaturan OCR";
            case "masukan": return "Pengaturan metode masukan";
            case "label": return "Pengaturan kustom konten fokus";
            case "bantuan": return "Bantuan dan umpan balik";
            default: return "Pengaturan TalkBack Novan";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = Prefs.get(this);
        String halaman = getIntent().getStringExtra(EXTRA_HALAMAN);
        if (halaman == null) halaman = "";
        setTitle(halaman.isEmpty() ? "Pengaturan" : judulHalaman(halaman));

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        kolom.setPadding(pad, pad, pad, pad);

        if (halaman.isEmpty()) {
            for (String[] m : MENU_UTAMA) tambahMenu(m[1], m[0]);
        } else {
            bangunHalaman(halaman);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(kolom);
        setContentView(sv);
    }

    private void bangunHalaman(String halaman) {
        switch (halaman) {
            case "cari": halamanCari(); break;
            case "umum": halamanUmum(); break;
            case "tts": halamanTts(); break;
            case "umpan": halamanUmpan(); break;
            case "tindakan": halamanTindakan(); break;
            case "gestur1": halamanGestur1(); break;
            case "gestur2": halamanGestur2(); break;
            case "gestur3": halamanGestur3(); break;
            case "gdefault": halamanGdefault(); break;
            case "alternatif": halamanAlternatif(); break;
            case "gerakan": halamanGerakan(); break;
            case "deskripsi": halamanDeskripsi(); break;
            case "kelola": halamanKelola(); break;
            case "pintasan": halamanPintasan(); break;
            case "konten": halamanKonten(); break;
            case "label": halamanLabel(); break;
            case "notifikasi": halamanNotifikasi(); break;
            case "lanjutan": halamanLanjutan(); break;
            case "ocr": halamanOcr(); break;
            case "masukan": halamanMasukan(); break;
            case "alat": halamanAlat(); break;
            case "lainnya": halamanLainnya(); break;
            case "bantuan": halamanBantuan(); break;
            default:
                for (String[] m : MENU_UTAMA) tambahMenu(m[1], m[0]);
                break;
        }
    }

    private void halamanCari() {
        final android.widget.EditText kotak = new android.widget.EditText(this);
        kotak.setHint("Cari pengaturan");
        kotak.setSingleLine(true);
        kolom.addView(kotak);
        final LinearLayout hasil = new LinearLayout(this);
        hasil.setOrientation(LinearLayout.VERTICAL);
        kolom.addView(hasil);
        final List<String[]> indeks = bangunIndeks();
        kotak.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                tampilkanHasil(hasil, indeks, e.toString());
            }
        });
    }

    /** Kumpulkan semua teks pengaturan dari tiap halaman: {teks, halaman}. */
    private List<String[]> bangunIndeks() {
        List<String[]> daftar = new ArrayList<>();
        LinearLayout asli = kolom;
        for (String k : INDEKS) {
            kolom = new LinearLayout(this);
            bangunHalaman(k);
            for (int i = 0; i < kolom.getChildCount(); i++) {
                View v = kolom.getChildAt(i);
                if (!(v instanceof TextView)) continue;
                CharSequence t = ((TextView) v).getText();
                if (t == null || t.length() == 0 || t.length() > 120) continue;
                daftar.add(new String[]{t.toString(), k});
            }
        }
        kolom = asli;
        return daftar;
    }

    private void tampilkanHasil(LinearLayout hasil, List<String[]> indeks, String kata) {
        hasil.removeAllViews();
        String[] bagian = kata.trim().toLowerCase(java.util.Locale.getDefault()).split("\\s+");
        if (bagian.length == 1 && bagian[0].isEmpty()) return;
        int jumlah = 0;
        for (final String[] x : indeks) {
            String teks = x[0].toLowerCase(java.util.Locale.getDefault());
            boolean cocok = true;
            for (String b : bagian) if (!teks.contains(b)) cocok = false;
            if (!cocok) continue;
            Button b = new Button(this);
            b.setText(x[0] + " (" + judulHalaman(x[1]) + ")");
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new android.content.Intent(SettingsActivity.this, SettingsActivity.class)
                            .putExtra(EXTRA_HALAMAN, x[1]));
                }
            });
            hasil.addView(b);
            if (++jumlah >= 40) break;
        }
        if (jumlah == 0) {
            TextView t = new TextView(this);
            t.setText("Tidak ada hasil");
            t.setTextSize(18);
            hasil.addView(t);
        }
    }

    private void halamanAlat() {
        tambahUjiSuara();
        Button n = new Button(this);
        n.setText("Beri akses notifikasi");
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(
                        android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        kolom.addView(n);
    }

    private void halamanLainnya() {
        TextView status = new TextView(this);
        status.setTextSize(18);
        status.setText(MainActivity.layananAktif(this)
                ? "Status: TalkBack Novan aktif."
                : "Status: belum aktif. Buka pengaturan aksesibilitas, pilih TalkBack Novan, lalu nyalakan.");
        kolom.addView(status);
        Button a = new Button(this);
        a.setText("Buka pengaturan aksesibilitas");
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        kolom.addView(a);
        tambahMenu("Bantuan dan umpan balik", "bantuan");
        TextView versi = new TextView(this);
        versi.setText("TalkBack Novan versi 0.13.0 (tahap 13)");
        versi.setPadding(0, (int) (16 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(versi);
    }

    /** Tombol yang membuka halaman pengaturan lain (seperti daftar menu di JieShuo). */
    private void tambahMenu(String label, final String halaman) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (halaman.equals("ekstensi")) {
                    startActivity(new android.content.Intent(SettingsActivity.this, PluginActivity.class));
                    return;
                }
                if (halaman.equals("aksesibilitas")) {
                    startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                startActivity(new android.content.Intent(SettingsActivity.this, SettingsActivity.class)
                        .putExtra(EXTRA_HALAMAN, halaman));
            }
        });
        kolom.addView(b);
    }

    private void halamanUmum() {
        tambahMenu("Panduan", "bantuan");
        tambahGeser("Kecepatan teks ke ucapan", Prefs.K_LAJU, 50, 300, 100);
        tambahGeser("Volume teks ke ucapan", Prefs.K_VOL_TTS, 10, 100, 100);
        tambahSakelar("Baca petunjuk penggunaan", Prefs.K_PETUNJUK, true);
        tambahSakelar("Baca daftar item", Prefs.K_GULIR_INFO, true);
        tambahSakelar("Baca pemberitahuan dari panel pemberitahuan", Prefs.K_NOTIF, true);
        tambahSakelar("Gunakan gerakan ke kiri atau ke kanan dengan 1 jari untuk bernavigasi", Prefs.K_USAP_NAV, true);
        TextView ringkas = new TextView(this);
        ringkas.setText("Usap kiri/kanan pindah fokus, atas/bawah fungsi pintas.");
        ringkas.setTextSize(14);
        kolom.addView(ringkas);
        tambahMenu("Pengaturan gerakan yang dibuat", "tindakan");
    }

    private void halamanTts() {
        tombolMesin = new Button(this);
        tombolMesin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihMesin();
            }
        });
        kolom.addView(tombolMesin);
        perbaruiTombolMesin();
        Button sistem = new Button(this);
        sistem.setText("Pengaturan teks ke ucapan");
        sistem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new android.content.Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new android.content.Intent(android.provider.Settings.ACTION_SETTINGS));
                }
            }
        });
        kolom.addView(sistem);
        tambahGeser("Kecepatan teks ke ucapan", Prefs.K_LAJU, 50, 300, 100);
        tambahGeser("Volume teks ke ucapan", Prefs.K_VOL_TTS, 10, 100, 100);
        tambahGeser("Nada teks ke ucapan", Prefs.K_NADA, 50, 200, 100);
        tambahSakelarRingkas("Pengecilan audio", "Kecilkan audio lain saat berbicara.", Prefs.K_DUCK, false);
        tambahSakelarRingkas("Gunakan sensor kedekatan", "Berhenti membaca saat sensor kedekatan ditutup.",
                Prefs.K_JARAK, false);
        tambahSakelar("Sentuh layar untuk menghentikan ucapan", Prefs.K_SENTUH_DIAM, false);
    }

    private void tambahSakelarRingkas(String label, String ringkas, String kunci, boolean awal) {
        tambahSakelar(label, kunci, awal);
        TextView t = new TextView(this);
        t.setText(ringkas);
        t.setTextSize(14);
        kolom.addView(t);
    }

    private void halamanUmpan() {
        tambahSakelar("Gunakan umpan balik suara", Prefs.K_EFEK, true);
        tambahGeser("Volume tema suara", Prefs.K_EFEK_VOL, 5, 100, 60);
        tambahTombolDaftar("Aplikasi yang tidak memakai efek suara", Prefs.K_HITAM_EFEK);
        tambahSakelar("Umpan balik getaran", Prefs.K_GETAR, true);
        tambahGeser("Intensitas getaran", Prefs.K_GETAR_KUAT, 1, 255, 32, " dari 255");
        tambahGeser("Lama getaran", Prefs.K_GETAR_LAMA, 5, 100, 15, " milidetik");
    }

    private void halamanTindakan() {
        tambahMenu("Pengaturan Gestur Default", "gdefault");
        tambahMenu("Pengaturan gerakan", "gerakan");
        tambahMenu("Deskripsi gerakan", "deskripsi");
        tambahMenu("Kelola gerakan", "kelola");
        tambahMenu("Pengaturan tombol pintasan", "pintasan");
    }

    private void halamanGdefault() {
        tambahSakelar("Jelajah menurut jenis navigasi di semua tampilan (atas/bawah ganti jenis, kiri/kanan pindah item)",
                Prefs.K_NAV_JENIS, true);
        tambahSakelar("Tetap pada jenis navigasi saat jendela berubah", Prefs.K_JENIS_TETAP, false);
        tambahMenu("Pengaturan gerakan alternatif", "alternatif");
    }

    private void halamanAlternatif() {
        tambahSakelar("Pindahkan kursor di kotak edit yang aktif", Prefs.K_GERAK_KURSOR, true);
        tambahSakelar("Sesuaikan kemajuan pada penggeser", Prefs.K_GERAK_PENGGESER, true);
        tambahSakelar("Gulir daftar di dalam daftar", Prefs.K_GERAK_GULIR, true);
        tambahSakelar("Gunakan gerakan multi jari", Prefs.K_MULTI_JARI, true);
    }

    private void halamanGerakan() {
        tambahMenu("Gestur satu jari", "gestur1");
        tambahMenu("Gestur dua jari", "gestur2");
        tambahMenu("Gestur tiga dan empat jari", "gestur3");
    }

    private static final String[][] GESTUR_BANYAK_JARI = {
            {"Usap atas dua jari", Prefs.G2_ATAS}, {"Usap bawah dua jari", Prefs.G2_BAWAH},
            {"Usap kiri dua jari", Prefs.G2_KIRI}, {"Usap kanan dua jari", Prefs.G2_KANAN},
            {"Ketuk dua kali dua jari", Prefs.G2_KETUK2},
            {"Ketuk tiga jari", Prefs.G3_KETUK}, {"Ketuk dua kali tiga jari", Prefs.G3_KETUK2},
            {"Usap atas tiga jari", Prefs.G3_ATAS}, {"Usap bawah tiga jari", Prefs.G3_BAWAH},
            {"Usap kiri tiga jari", Prefs.G3_KIRI}, {"Usap kanan tiga jari", Prefs.G3_KANAN},
    };

    private void tambahTeks(String teks) {
        TextView t = new TextView(this);
        t.setText(teks);
        t.setTextSize(16);
        t.setPadding(0, (int) (6 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
    }

    private void halamanDeskripsi() {
        tambahTeks("Ketuk dua jari: hentikan suara");
        for (String[] g : GESTUR_BANYAK_JARI) {
            tambahTeks(g[0] + ": " + Aksi.NAMA[Prefs.aksi(this, g[1])]);
        }
        for (int i = 0; i < Gestur.jumlah(); i++) {
            tambahTeks(Gestur.nama(i) + ": " + Aksi.NAMA[Prefs.aksi(this, Gestur.kunciPref(i))]);
        }
    }

    private void halamanKelola() {
        Button b = new Button(this);
        b.setText("Kembalikan semua gerakan ke bawaan");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Kembalikan gerakan")
                        .setMessage("Semua gerakan kembali ke bawaan?")
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                SharedPreferences.Editor e = sp.edit();
                                for (String k : new ArrayList<>(sp.getAll().keySet())) {
                                    if (k.startsWith("gx_") || k.startsWith("g2_") || k.startsWith("g3_")) e.remove(k);
                                }
                                e.apply();
                                android.widget.Toast.makeText(SettingsActivity.this,
                                        "Gerakan dikembalikan ke bawaan", android.widget.Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void halamanPintasan() {
        tambahSakelar("Gunakan tombol volume sebagai tombol pintasan", Prefs.K_VOLUME, true);
        tambahSakelar("Gunakan tombol headset untuk mengontrol pembaca layar", Prefs.K_HEADSET, false);
        tambahAksi("Tekan lama volume atas", Prefs.VOL_ATAS);
        tambahAksi("Tekan lama volume bawah", Prefs.VOL_BAWAH);
        tambahAksi("Dua kali klik volume naik", Prefs.VA_KLIK2);
        tambahAksi("Tiga kali klik volume naik", Prefs.VA_KLIK3);
        tambahAksi("Dua kali klik volume turun", Prefs.VB_KLIK2);
        tambahAksi("Tiga kali klik volume turun", Prefs.VB_KLIK3);
        tambahAksi("Tombol headset: klik sekali", Prefs.HS_KLIK);
        tambahAksi("Tombol headset: klik dua kali", Prefs.HS_KLIK2);
        tambahAksi("Tombol headset: tahan", Prefs.HS_LAMA);
    }

    private void halamanGestur1() {
        tambahSakelar("Usap kiri/kanan pindah fokus, atas/bawah fungsi pintas", Prefs.K_USAP_NAV, true);
        for (int g = 0; g < Gestur.JUMLAH_SATU_JARI; g++) {
            tambahAksi(Gestur.nama(g), Gestur.kunciPref(g));
        }
    }

    private void halamanGestur2() {
        tambahAksi("Usap atas dua jari", Prefs.G2_ATAS);
        tambahAksi("Usap bawah dua jari", Prefs.G2_BAWAH);
        tambahAksi("Usap kiri dua jari", Prefs.G2_KIRI);
        tambahAksi("Usap kanan dua jari", Prefs.G2_KANAN);
        tambahAksi("Ketuk dua kali dua jari", Prefs.G2_KETUK2);
    }

    private void halamanGestur3() {
        tambahAksi("Ketuk tiga jari", Prefs.G3_KETUK);
        tambahAksi("Ketuk dua kali tiga jari", Prefs.G3_KETUK2);
        tambahAksi("Usap atas tiga jari", Prefs.G3_ATAS);
        tambahAksi("Usap bawah tiga jari", Prefs.G3_BAWAH);
        tambahAksi("Usap kiri tiga jari", Prefs.G3_KIRI);
        tambahAksi("Usap kanan tiga jari", Prefs.G3_KANAN);
        bagian("Gestur tiga dan empat jari lainnya");
        for (int g = Gestur.JUMLAH_SATU_JARI; g < Gestur.jumlah(); g++) {
            tambahAksi(Gestur.nama(g), Gestur.kunciPref(g));
        }
    }

    private void halamanKonten() {
        bagian("Pengaturan pengucapan label");
        tambahSakelar("Bacakan jenis dan status kontrol yang difokuskan", Prefs.K_PERAN, true);
        tambahSakelar("Bacakan emoji dengan nama bahasa Indonesia", Prefs.K_EMOJI, true);
        bagian("Pengaturan pengucapan konten yang berubah");
        tambahSakelar("Bacakan perubahan judul jendela dan dialog", Prefs.K_JENDELA, true);
        tambahSakelar("Bacakan notifikasi dan pesan toast", Prefs.K_NOTIF, true);
        bagian("Pengaturan daftar");
        tambahSakelar("Baca posisi daftar saat digulir", Prefs.K_GULIR_INFO, true);
        tambahMenu("Pengaturan kustom konten fokus", "label");
    }

    private void halamanLabel() {
        Button aturan = new Button(this);
        aturan.setText("Manajemen nama fokus (aturan ganti nama)");
        aturan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ubahAturanNama();
            }
        });
        kolom.addView(aturan);
    }

    private void halamanNotifikasi() {
        tambahSakelar("Baca pemberitahuan timbul dan pesan toast", Prefs.K_NOTIF, true);
        tambahSakelar("Baca sumber pemberitahuan (nama aplikasi)", Prefs.K_NOTIF_APP, true);
        tambahTombolDaftar("Daftar hitam pemberitahuan (aplikasi yang notifikasinya diam)", Prefs.K_HITAM_NOTIF);
        tambahTombolDaftar("Daftar hitam konten pembacaan otomatis (perubahan isi, gulir, pengumuman)", Prefs.K_HITAM_OTOMATIS);
    }

    private void halamanLanjutan() {
        tambahMenu("Pengaturan OCR", "ocr");
        tambahMenu("Pengaturan metode masukan", "masukan");
    }

    private void halamanOcr() {
        tambahTombolMesinOcr();
        tambahIsian("Kunci API Gemini", Prefs.K_GEMINI_KUNCI, true);
        tambahIsian("Model Gemini", Prefs.K_GEMINI_MODEL, false);
        tambahIsian("Kunci API Groq", Prefs.K_GROQ_KUNCI, true);
        tambahIsian("Model Groq", Prefs.K_GROQ_MODEL, false);
        tambahSakelar("Buka hasil OCR di halaman baca", Prefs.K_OCR_BUKA, false);
    }

    private void halamanMasukan() {
        tombolGema = new Button(this);
        tombolGema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihGema();
            }
        });
        kolom.addView(tombolGema);
        perbaruiTombolGema();
    }

    private void halamanBantuan() {
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Gestur bawaan, mirip JieShuo:\n"
                + "Satu jari (bawaan): usap kiri = item sebelumnya; usap kanan = item berikutnya; "
                + "usap atas/bawah = ganti granularitas (fungsi pintas, bisa diganti). "
                + "Bila pilihan usap kiri/kanan dimatikan: atas/bawah pindah item, kiri/kanan menurut konteks.\n"
                + "Dua usapan: atas lalu bawah = fokus terakhir; bawah lalu atas = fokus pertama; "
                + "kiri lalu kanan = aplikasi terbaru; kanan lalu kiri = kembali; atas lalu kanan = menu tindakan; "
                + "bawah lalu kanan = menu utama; atas lalu kiri = ekstensi; bawah lalu kiri = perintah suara; "
                + "kiri lalu bawah = mode per karakter; kanan lalu atas = baca otomatis; "
                + "kiri lalu atas = notifikasi; kanan lalu bawah = daftar elemen layar.\n"
                + "Dua jari: ketuk dua kali = putar atau jeda media; ketuk = hentikan suara.\n"
                + "Tiga jari: usap bawah = notifikasi; atas = beranda; kiri = aplikasi terbaru; kanan = pengaturan cepat; "
                + "ketuk dua kali = baca otomatis.\n"
                + "Empat jari: usap bawah = ke fokus terakhir; atas = ke fokus pertama; kiri = matikan atau nyalakan "
                + "gestur banyak jari; kanan = ketuk dua kali; ketuk dua kali = mode baca.\n"
                + "Semua gestur dan tombol bisa diberi aksi lain di Pengaturan tindakan.");
        kolom.addView(t);
    }

    private void tambahUjiSuara() {
        Button uji = new Button(this);
        uji.setText("Uji suara");
        uji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TalkBackNovanService.ucapkanContoh("Ini contoh suara TalkBack Novan. \uD83D\uDE00");
            }
        });
        kolom.addView(uji);
    }

    private void tambahTombolMesinOcr() {
        final Button b = new Button(this);
        final String[] nama = {"Gemini", "Groq"};
        b.setText("Mesin OCR utama: " + nama[sp.getInt(Prefs.K_OCR_MESIN, 0) == 1 ? 1 : 0]);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Mesin OCR utama")
                        .setSingleChoiceItems(nama, sp.getInt(Prefs.K_OCR_MESIN, 0) == 1 ? 1 : 0,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putInt(Prefs.K_OCR_MESIN, which).apply();
                                        b.setText("Mesin OCR utama: " + nama[which]);
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
        kolom.addView(b);
    }

    /** Tombol yang membuka isian teks (kunci API atau nama model). */
    private void tambahIsian(final String label, final String kunci, final boolean rahasia) {
        final Button b = new Button(this);
        perbaruiIsian(b, label, kunci, rahasia);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final android.widget.EditText e = new android.widget.EditText(SettingsActivity.this);
                e.setSingleLine(true);
                e.setContentDescription(label);
                e.setText(sp.getString(kunci, ""));
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(label)
                        .setMessage(rahasia ? "" : "Kosongkan untuk memakai model bawaan.")
                        .setView(e)
                        .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                sp.edit().putString(kunci, e.getText().toString().trim()).apply();
                                perbaruiIsian(b, label, kunci, rahasia);
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void perbaruiIsian(Button b, String label, String kunci, boolean rahasia) {
        String v = sp.getString(kunci, "");
        String ringkas;
        if (rahasia) ringkas = v.isEmpty() ? "belum diisi" : "sudah diisi";
        else if (!v.isEmpty()) ringkas = v;
        else ringkas = kunci.equals(Prefs.K_GEMINI_MODEL) ? "bawaan (" + OcrKlien.MODEL_GEMINI + ")"
                : "bawaan (" + OcrKlien.MODEL_GROQ + ")";
        b.setText(label + ": " + ringkas);
    }

    private void tambahTombolDaftar(final String label, final String kunci) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihAplikasi(label, kunci);
            }
        });
        kolom.addView(b);
    }

    private void pilihAplikasi(String judul, final String kunci) {
        android.content.pm.PackageManager pm = getPackageManager();
        android.content.Intent q = new android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER);
        final java.util.TreeMap<String, String> urut = new java.util.TreeMap<>();
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
            String paket = ri.activityInfo.packageName;
            if (paket.equals(getPackageName())) continue;
            urut.put(ri.loadLabel(pm).toString() + "\u0000" + paket, paket);
        }
        final List<String> paket = new ArrayList<>(urut.values());
        String[] nama = new String[paket.size()];
        final boolean[] dipilih = new boolean[paket.size()];
        final java.util.Set<String> kini = Prefs.daftar(this, kunci);
        int i = 0;
        for (String k : urut.keySet()) {
            nama[i] = k.substring(0, k.indexOf('\u0000'));
            dipilih[i] = kini.contains(paket.get(i));
            i++;
        }
        new AlertDialog.Builder(this)
                .setTitle(judul)
                .setMultiChoiceItems(nama, dipilih, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean centang) {
                        if (centang) kini.add(paket.get(which));
                        else kini.remove(paket.get(which));
                    }
                })
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        sp.edit().putStringSet(kunci, kini).apply();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void ubahAturanNama() {
        final android.widget.EditText e = new android.widget.EditText(this);
        e.setMinLines(5);
        e.setGravity(android.view.Gravity.TOP);
        e.setContentDescription("Aturan ganti nama, satu per baris");
        e.setText(sp.getString(Prefs.K_NAMA, ""));
        new AlertDialog.Builder(this)
                .setTitle("Aturan ganti nama")
                .setMessage("Satu aturan per baris: teks asli=nama baru, atau id:paket:id/nama=nama baru.")
                .setView(e)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        sp.edit().putString(Prefs.K_NAMA, e.getText().toString()).apply();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Tombol yang memilih aksi untuk satu gestur atau tombol. */
    private void tambahAksi(final String label, final String kunci) {
        final Button b = new Button(this);
        b.setText(label + ": " + Aksi.NAMA[Prefs.aksi(this, kunci)]);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(label)
                        .setSingleChoiceItems(Aksi.NAMA, Prefs.aksi(SettingsActivity.this, kunci),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putInt(kunci, which).apply();
                                        b.setText(label + ": " + Aksi.NAMA[which]);
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void bagian(String teks) {
        TextView t = new TextView(this);
        t.setText(teks);
        t.setTextSize(20);
        t.setAccessibilityHeading(true);
        t.setPadding(0, (int) (16 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
    }

    private void tambahSakelar(String label, final String kunci, boolean awal) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(kunci, awal));
        s.setMinHeight((int) (48 * getResources().getDisplayMetrics().density));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean dicentang) {
                sp.edit().putBoolean(kunci, dicentang).apply();
            }
        });
        kolom.addView(s);
    }

    private void tambahGeser(String label, String kunci, int min, int maks, int awal) {
        tambahGeser(label, kunci, min, maks, awal, " persen");
    }

    private void tambahGeser(final String label, final String kunci,
                             final int min, int maks, int awal, final String satuan) {
        final TextView t = new TextView(this);
        t.setPadding(0, (int) (8 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(maks - min);
        int nilai = sp.getInt(kunci, awal);
        sb.setProgress(nilai - min);
        sb.setContentDescription(label);
        t.setText(label + ": " + nilai + satuan);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progres, boolean daripengguna) {
                int v = progres + min;
                t.setText(label + ": " + v + satuan);
                if (daripengguna) sp.edit().putInt(kunci, v).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        kolom.addView(sb);
    }

    private void perbaruiTombolGema() {
        int m = sp.getInt(Prefs.K_GEMA, 3);
        tombolGema.setText("Gema ketikan: " + NAMA_GEMA[m]);
    }

    private void pilihGema() {
        new AlertDialog.Builder(this)
                .setTitle("Gema ketikan")
                .setSingleChoiceItems(NAMA_GEMA, sp.getInt(Prefs.K_GEMA, 3),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                sp.edit().putInt(Prefs.K_GEMA, which).apply();
                                perbaruiTombolGema();
                                d.dismiss();
                            }
                        })
                .show();
    }

    private void perbaruiTombolMesin() {
        String mesin = sp.getString(Prefs.K_MESIN, "");
        tombolMesin.setText("Mesin suara: " + (mesin.isEmpty() ? "bawaan sistem" : mesin));
    }

    private void pilihMesin() {
        final TextToSpeech[] pemegang = new TextToSpeech[1];
        pemegang[0] = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                final List<String> nama = new ArrayList<>();
                final List<String> paket = new ArrayList<>();
                nama.add("Bawaan sistem");
                paket.add("");
                if (status == TextToSpeech.SUCCESS && pemegang[0] != null) {
                    for (TextToSpeech.EngineInfo info : pemegang[0].getEngines()) {
                        nama.add(info.label);
                        paket.add(info.name);
                    }
                }
                if (pemegang[0] != null) pemegang[0].shutdown();
                if (isFinishing() || isDestroyed()) return;
                int terpilih = Math.max(0, paket.indexOf(sp.getString(Prefs.K_MESIN, "")));
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Mesin suara")
                        .setSingleChoiceItems(nama.toArray(new String[0]), terpilih,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putString(Prefs.K_MESIN, paket.get(which)).apply();
                                        perbaruiTombolMesin();
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
    }
}
