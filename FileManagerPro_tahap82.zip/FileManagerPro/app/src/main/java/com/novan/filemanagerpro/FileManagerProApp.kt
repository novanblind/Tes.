package com.novan.filemanagerpro

import android.app.Application

class FileManagerProApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ThemeManager.apply(ThemeManager.get(this))
    }
}
