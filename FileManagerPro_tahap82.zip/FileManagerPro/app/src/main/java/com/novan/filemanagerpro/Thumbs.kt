package com.novan.filemanagerpro

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

/** Pemuat gambar mini (thumbnail) untuk gambar dan video, dengan cache di memori. */
object Thumbs {
    private const val SIZE = 192
    private val cache = LruCache<String, Bitmap>(160)
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun load(view: ImageView, path: String) {
        view.tag = path
        val hit = cache.get(path)
        if (hit != null) {
            view.scaleType = ImageView.ScaleType.CENTER_CROP
            view.setImageBitmap(hit)
            return
        }
        pool.execute {
            val bmp = try { decode(path) } catch (e: Throwable) { null }
            if (bmp != null) cache.put(path, bmp)
            main.post {
                if (bmp != null && view.tag == path) {
                    view.scaleType = ImageView.ScaleType.CENTER_CROP
                    view.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun decode(path: String): Bitmap? {
        val f = java.io.File(path)
        return when (Util.kindOf(f)) {
            Util.K_IMAGE -> {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) return null
                var sample = 1
                while (o.outWidth / (sample * 2) >= SIZE && o.outHeight / (sample * 2) >= SIZE) sample *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeFile(path, o2)
            }
            Util.K_VIDEO -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(path)
                    r.getFrameAtTime(0)?.let {
                        Bitmap.createScaledBitmap(it, SIZE, SIZE * it.height / it.width.coerceAtLeast(1), true)
                    }
                } finally {
                    try { r.release() } catch (e: Exception) { }
                }
            }
            else -> null
        }
    }
}
