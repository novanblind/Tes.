package com.androlua;

import android.os.Handler;
import android.os.Looper;

import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

/**
 * Http.get / Http.post tak sinkron bergaya AndroLua: callback(kode, isi, cookie, header)
 * dipanggil di thread utama. Argumen tengah (cookie, charset, header) boleh dihilangkan.
 */
public final class Http {
    private Http() {}

    private static final Handler UTAMA = new Handler(Looper.getMainLooper());

    public static void get(String url, LuaFunction cb) {
        minta("GET", url, null, null, null, null, cb);
    }

    public static void get(String url, String cookie, LuaFunction cb) {
        minta("GET", url, null, cookie, null, null, cb);
    }

    public static void get(String url, String cookie, String charset, LuaFunction cb) {
        minta("GET", url, null, cookie, charset, null, cb);
    }

    public static void get(String url, String cookie, String charset, LuaTable header, LuaFunction cb) {
        minta("GET", url, null, cookie, charset, header, cb);
    }

    public static void post(String url, LuaValue data, LuaFunction cb) {
        minta("POST", url, data, null, null, null, cb);
    }

    public static void post(String url, LuaValue data, String cookie, LuaFunction cb) {
        minta("POST", url, data, cookie, null, null, cb);
    }

    public static void post(String url, LuaValue data, String cookie, String charset, LuaFunction cb) {
        minta("POST", url, data, cookie, charset, null, cb);
    }

    public static void post(String url, LuaValue data, String cookie, String charset, LuaTable header,
                            LuaFunction cb) {
        minta("POST", url, data, cookie, charset, header, cb);
    }

    private static String badan(LuaValue data, String charset) throws Exception {
        if (data == null || data.isnil()) return null;
        if (!data.istable()) return data.tojstring();
        StringBuilder sb = new StringBuilder();
        LuaValue k = LuaValue.NIL;
        while (true) {
            Varargs nx = data.next(k);
            k = nx.arg1();
            if (k.isnil()) break;
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(k.tojstring(), charset))
                    .append('=')
                    .append(URLEncoder.encode(nx.arg(2).tojstring(), charset));
        }
        return sb.toString();
    }

    private static void minta(final String metode, final String url, final LuaValue data, final String cookie,
                              final String charsetIn, final LuaTable header, final LuaFunction cb) {
        final String charset = charsetIn == null || charsetIn.isEmpty() ? "UTF-8" : charsetIn;
        new Thread(new Runnable() {
            @Override
            public void run() {
                int kode = -1;
                String isi = "";
                String cookieBaru = cookie == null ? "" : cookie;
                LuaTable headerBalas = new LuaTable();
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(metode);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(60000);
                    c.setInstanceFollowRedirects(true);
                    if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
                    if (header != null) {
                        LuaValue k = LuaValue.NIL;
                        while (true) {
                            Varargs nx = header.next(k);
                            k = nx.arg1();
                            if (k.isnil()) break;
                            c.setRequestProperty(k.tojstring(), nx.arg(2).tojstring());
                        }
                    }
                    if (metode.equals("POST")) {
                        String b = badan(data, charset);
                        c.setDoOutput(true);
                        if (c.getRequestProperty("Content-Type") == null) {
                            c.setRequestProperty("Content-Type", data != null && data.istable()
                                    ? "application/x-www-form-urlencoded" : "application/x-www-form-urlencoded");
                        }
                        byte[] bytes = (b == null ? "" : b).getBytes(charset);
                        try (OutputStream os = c.getOutputStream()) {
                            os.write(bytes);
                        }
                    }
                    kode = c.getResponseCode();
                    InputStream in = kode >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        in.close();
                        isi = new String(out.toByteArray(), charset);
                    }
                    for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                        if (e.getKey() == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                        headerBalas.set(e.getKey(), LuaValue.valueOf(e.getValue().get(0)));
                        if (e.getKey().equalsIgnoreCase("Set-Cookie")) {
                            StringBuilder sb = new StringBuilder();
                            for (String s : e.getValue()) {
                                int p = s.indexOf(';');
                                if (sb.length() > 0) sb.append("; ");
                                sb.append(p > 0 ? s.substring(0, p) : s);
                            }
                            cookieBaru = sb.toString();
                        }
                    }
                } catch (Exception e) {
                    kode = -1;
                    isi = String.valueOf(e.getMessage());
                } finally {
                    if (c != null) c.disconnect();
                }
                final int kodeAkhir = kode;
                final String isiAkhir = isi;
                final String cookieAkhir = cookieBaru;
                final LuaTable headerAkhir = headerBalas;
                UTAMA.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            cb.invoke(LuaValue.varargsOf(new LuaValue[]{
                                    LuaValue.valueOf(kodeAkhir), LuaValue.valueOf(isiAkhir),
                                    LuaValue.valueOf(cookieAkhir), headerAkhir}));
                        } catch (Throwable t) {
                            com.novan.talkbacknovan.PluginManager.catatUmum("galat pada callback Http: " + t.getMessage());
                        }
                    }
                });
            }
        }).start();
    }
}
