package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Peta nada (chroma) lagu pengiring: untuk tiap potongan waktu sekitar 186 milidetik, seberapa kuat tiap dari 12
 * kelas nada (C, C kres, D, ... B) terdengar di musik, dinormalkan terhadap kelas terkuat pada potongan itu (0..1).
 * Dipakai penilaian nyanyian untuk mengecek apakah nada yang dinyanyikan cocok dengan nada yang sedang dimainkan
 * musik. Ini belum sama dengan membandingkan melodi vokal asli, tetapi nyanyian yang salah lagu atau salah kunci
 * akan jatuh di kelas nada yang lemah.
 *
 * Murni hitungan, tanpa kelas Android. Hasil dihitung sekali per lagu di utas latar.
 */
class ChromaLagu private constructor(private val nilai: FloatArray, private val bingkai: Int) {

    /**
     * Rata-rata kekuatan kelas nada [pc] (0 = C sampai 11 = B) pada waktu [dariMs]..[sampaiMs], lebih lebar 100
     * milidetik di kedua sisi supaya pergantian akor tidak memotong nada. Mengembalikan -1 bila di rentang itu
     * musiknya senyap atau di luar lagu.
     */
    fun kecocokan(pc: Int, dariMs: Long, sampaiMs: Long): Float {
        if (bingkai == 0 || pc < 0 || pc > 11) return -1f
        val dari = ((dariMs - 100L) / BINGKAI_MS).toInt().coerceAtLeast(0)
        val sampai = ((sampaiMs + 100L) / BINGKAI_MS).toInt().coerceAtMost(bingkai - 1)
        var jum = 0f
        var cacah = 0
        for (f in dari..sampai) {
            val v = nilai[f * 12 + pc]
            if (v >= 0f) {
                jum += v
                cacah++
            }
        }
        return if (cacah == 0) -1f else jum / cacah
    }

    /** Peta nada yang ikut bergeser [setengahNada] setengah nada (dipakai bila nada dasar lagu diubah), supaya penilaian tetap cocok. */
    fun geser(setengahNada: Int): ChromaLagu {
        val n = ((setengahNada % 12) + 12) % 12
        if (n == 0 || bingkai == 0) return this
        val baru = FloatArray(nilai.size)
        for (f in 0 until bingkai) for (p in 0 until 12) baru[f * 12 + (p + n) % 12] = nilai[f * 12 + p]
        return ChromaLagu(baru, bingkai)
    }

    companion object {
        private const val SR_RENDAH = 11_025
        private const val JENDELA = 2_048
        private const val MIDI_AWAL = 48
        private const val MIDI_AKHIR = 83

        /** Lama satu potongan dalam milidetik (sekitar 186). */
        private const val BINGKAI_MS = JENDELA * 1000L / SR_RENDAH

        /**
         * Menghitung peta nada dari [lagu]. Mengembalikan null bila dibatalkan lewat [batal] atau lagu terlalu
         * pendek. Beban: sekitar 290 juta perkalian untuk lagu 12 menit, beberapa detik di utas latar.
         */
        fun hitung(lagu: Lagu, batal: () -> Boolean): ChromaLagu? {
            val pcm = lagu.pcm
            val rendah = lagu.frame / 4
            val jumlah = rendah / JENDELA
            if (jumlah < 2) return null

            // Mono 11.025 Hz: rata-rata empat frame stereo (sekaligus penyaring lolos-rendah sederhana).
            val mono = DoubleArray(jumlah * JENDELA)
            for (i in mono.indices) {
                var j = i * 8
                var s = 0
                for (k in 0 until 8) s += pcm[j + k].toInt()
                mono[i] = s / (8.0 * 32768.0)
            }

            val hann = DoubleArray(JENDELA) { 0.5 - 0.5 * cos(2.0 * PI * it / JENDELA) }
            val jumlahNada = MIDI_AKHIR - MIDI_AWAL + 1
            val koef = DoubleArray(jumlahNada) {
                val hz = 440.0 * Math.pow(2.0, (MIDI_AWAL + it - 69) / 12.0)
                2.0 * cos(2.0 * PI * hz / SR_RENDAH)
            }

            val hasil = FloatArray(jumlah * 12)
            val kekuatan = DoubleArray(12)
            val x = DoubleArray(JENDELA)
            var puncakGlobal = 0.0
            val mentah = DoubleArray(jumlah * 12)

            for (f in 0 until jumlah) {
                if (f % 40 == 0 && batal()) return null
                val dasar = f * JENDELA
                for (k in 0 until JENDELA) x[k] = mono[dasar + k] * hann[k]
                java.util.Arrays.fill(kekuatan, 0.0)
                for (n in 0 until jumlahNada) {
                    val c = koef[n]
                    var s1 = 0.0
                    var s2 = 0.0
                    for (k in 0 until JENDELA) {
                        val s0 = x[k] + c * s1 - s2
                        s2 = s1
                        s1 = s0
                    }
                    val daya = s1 * s1 + s2 * s2 - c * s1 * s2
                    kekuatan[(MIDI_AWAL + n) % 12] += sqrt(if (daya > 0.0) daya else 0.0)
                }
                var puncak = 0.0
                for (p in 0 until 12) {
                    mentah[f * 12 + p] = kekuatan[p]
                    if (kekuatan[p] > puncak) puncak = kekuatan[p]
                }
                if (puncak > puncakGlobal) puncakGlobal = puncak
            }
            if (puncakGlobal <= 0.0) return null

            // Potongan yang sangat sepi dibanding bagian terkeras dianggap senyap (-1), lainnya dinormalkan.
            val ambangSenyap = puncakGlobal * 0.02
            for (f in 0 until jumlah) {
                var puncak = 0.0
                for (p in 0 until 12) if (mentah[f * 12 + p] > puncak) puncak = mentah[f * 12 + p]
                for (p in 0 until 12) {
                    hasil[f * 12 + p] = if (puncak < ambangSenyap) -1f else (mentah[f * 12 + p] / puncak).toFloat()
                }
            }
            return ChromaLagu(hasil, jumlah)
        }
    }
}
