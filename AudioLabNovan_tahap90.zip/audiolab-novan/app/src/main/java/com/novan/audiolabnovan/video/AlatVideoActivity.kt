package com.novan.audiolabnovan.video

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private class Galat(pesan: String) : Exception(pesan)

private enum class Jenis { VIDEO, AUDIO, GAMBAR }

private class Rencana(
    val args: List<String>,
    val dest: File?,
    val dirBanyak: File?,
    val ext: String,
    val jenis: Jenis,
    val mime: String,
    val outMs: Long
)

private class Simpanan(val file: File, var uri: Uri?, val nama: String, val mime: String, val jenis: Jenis)

/**
 * Tahap 85: satu halaman untuk semua alat video (potong, kompres, balik, splitter, mixer, kecepatan,
 * video ke audio, video ke GIF, volume booster, hapus, heningkan, loop, penghapus noise, stabilkan).
 * Alat yang dipakai ditentukan extra [VideoFitur.EXTRA]; hanya opsi alat itu yang tampil.
 * Semua proses memakai FFmpeg di perangkat, tanpa AI dan tanpa internet.
 */
class AlatVideoActivity : AppCompatActivity() {

    private var modeId = "trim"
    private var judulFitur = "Alat Video"

    private var sumber: Uri? = null
    private var namaSumber = ""
    private var durSec = 0.0
    private var adaSuara = true
    private var adaGambar = true
    private var sumber2: Uri? = null
    private var nama2 = ""

    private var sesi: FFmpegSession? = null
    private var sibuk = false
    private var batal = false
    private var terakhirUmum = -1
    private val hasilList = ArrayList<Simpanan>()
    private val dialogHasil by lazy { DialogHasil(this) }

    private val sp = LinkedHashMap<String, Spinner>()
    private val et = LinkedHashMap<String, EditText>()

    private lateinit var panelOpsi: LinearLayout
    private lateinit var tvBerkas: TextView
    private lateinit var tvBerkas2: TextView
    private lateinit var btnPilih: Button
    private lateinit var btnPilih2: Button
    private lateinit var btnMulai: Button
    private lateinit var btnBatal: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView
    private lateinit var panelHasil: LinearLayout
    private lateinit var tvHasil: TextView
    private lateinit var btnBuka: Button
    private lateinit var btnMenu: Button
    private lateinit var btnBagikan: Button
    private lateinit var btnSimpan: Button

    private val pilihVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setSumber(uri)
    }

    private val pilihTambahan = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            sumber2 = uri
            nama2 = namaDari(uri)
            tvBerkas2.text = "Audio tambahan: $nama2"
            segarkanTombol()
            status("Audio tambahan dipilih: $nama2.")
        }
    }

    private val simpanSebagai = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val s = hasilList.firstOrNull()
        if (r.resultCode == RESULT_OK && uri != null && s != null && s.file.exists()) {
            thread {
                val err = try { Converter.copyTo(this, s.file, uri); null } catch (e: Exception) { e.message ?: "galat" }
                runOnUiThread {
                    if (err == null) { s.uri = uri; status("Berkas tersimpan.") } else status("Gagal menyimpan: $err")
                }
            }
        } else status("Penyimpanan dibatalkan.")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun warna(id: Int) = ContextCompat.getColor(this, id)

    // =====================================================================================
    //  Tampilan
    // =====================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modeId = intent.getStringExtra(VideoFitur.EXTRA) ?: "trim"
        val def = VideoFitur.cari(modeId)
        judulFitur = intent.getStringExtra(VideoFitur.EXTRA_JUDUL) ?: def?.judul ?: "Alat Video"
        title = judulFitur

        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(buatBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val isi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        val lebar = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        isi.addView(TextView(this).apply {
            text = def?.petunjuk ?: ""
            textSize = 15f
            setPadding(0, dp(8), 0, dp(8))
        }, lebar)

        btnPilih = tombol("Pilih video") { pilihVideo.launch(arrayOf("video/*")) }
        isi.addView(btnPilih, lebar)
        tvBerkas = TextView(this).apply {
            text = "Belum ada video dipilih."
            textSize = 16f
            setPadding(0, dp(6), 0, dp(6))
        }
        isi.addView(tvBerkas, lebar)

        btnPilih2 = tombol("Pilih audio tambahan") { pilihTambahan.launch(arrayOf("audio/*", "video/*")) }
        tvBerkas2 = TextView(this).apply {
            text = "Belum ada audio tambahan dipilih."
            textSize = 16f
            setPadding(0, dp(6), 0, dp(6))
        }
        if (modeId == "mixer") {
            isi.addView(btnPilih2, lebar)
            isi.addView(tvBerkas2, lebar)
        }

        panelOpsi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        isi.addView(panelOpsi, lebar)
        siapkanOpsi()

        btnMulai = tombol("Mulai proses") { jalankan() }
        isi.addView(btnMulai, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
        btnBatal = tombol("Batalkan") { batalkan() }
        isi.addView(btnBatal, lebar)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        isi.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(12)).apply { topMargin = dp(8) })
        tvProgress = TextView(this).apply { textSize = 15f }
        isi.addView(tvProgress, lebar)

        tvStatus = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(8))
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setTextIsSelectable(true)
        }
        isi.addView(tvStatus, lebar)

        panelHasil = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        tvHasil = TextView(this).apply { textSize = 16f; setPadding(0, dp(8), 0, dp(8)) }
        panelHasil.addView(tvHasil, lebar)
        btnBuka = tombol("Buka hasil") { bukaHasil() }
        btnMenu = tombol("Menu hasil (putar, ubah nama, hapus)") { bukaMenuHasil() }
        btnBagikan = tombol("Bagikan") { bagikan() }
        btnSimpan = tombol("Simpan sebagai…") { simpanKeLokasi() }
        for (b in listOf(btnBuka, btnMenu, btnBagikan, btnSimpan)) panelHasil.addView(b, lebar)
        isi.addView(panelHasil, lebar)

        akar.addView(ScrollView(this).apply { addView(isi) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        ViewCompat.setOnApplyWindowInsetsListener(akar) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        setContentView(akar)
        status("Pilih video dulu, atur opsi, lalu tekan Mulai proses.")
        segarkanTombol()
        // Tahap 86: video dari menu Bagikan langsung terpilih.
        val kiriman = intent.getStringExtra(VideoFitur.EXTRA_URI)
        if (kiriman != null && sumber == null) setSumber(Uri.parse(kiriman))
    }

    private fun buatBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(warna(R.color.bar_bg))
            setPadding(dp(8), dp(10), dp(16), dp(10))
        }
        bar.addView(TextView(this).apply {
            text = "\u2190"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(warna(R.color.bar_teks))
            contentDescription = "Kembali"
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        bar.addView(TextView(this).apply {
            text = judulFitur
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(warna(R.color.bar_teks))
            ViewCompat.setAccessibilityHeading(this, true)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        return bar
    }

    private fun tombol(teks: String, aksi: () -> Unit): Button = Button(this).apply {
        text = teks
        isAllCaps = false
        minHeight = dp(48)
        setOnClickListener { aksi() }
    }

    private fun tambahPilihan(kunci: String, label: String, items: List<String>, awal: Int = 0) {
        panelOpsi.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setPadding(0, dp(12), 0, dp(2))
        })
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.setSelection(awal)
        s.contentDescription = label
        sp[kunci] = s
        panelOpsi.addView(s, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun tambahIsian(kunci: String, label: String, awal: String, angka: Boolean = false) {
        panelOpsi.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setPadding(0, dp(12), 0, dp(2))
        })
        val e = EditText(this).apply {
            setText(awal)
            contentDescription = label
            inputType = if (angka) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        et[kunci] = e
        panelOpsi.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private val daftarKecepatan = listOf(0.25, 0.5, 0.75, 1.25, 1.5, 2.0, 3.0, 4.0)
    private val daftarBooster = listOf(150, 200, 300, 400, 500)
    private val daftarLoop = listOf(2, 3, 4, 5, 10)
    private val daftarBagi = listOf(10, 30, 60, 120, 300, 600)
    private val daftarFps = listOf(5, 8, 10, 12, 15)
    private val daftarLebarGif = listOf(240, 320, 480, 640)
    private val daftarKbpsAudio = listOf(128, 192, 256, 320)

    private fun siapkanOpsi() {
        when (modeId) {
            "trim" -> {
                tambahIsian("mulai", "Mulai dari. Tulis detik, misalnya 90, atau menit:detik, misalnya 1:30", "0")
                tambahIsian("sampai", "Sampai. Kosongkan bila sampai akhir video", "")
                tambahPilihan("cara", "Cara memotong", listOf(
                    "Cepat, tanpa encode ulang (titik potong bisa meleset sedikit)",
                    "Tepat, encode ulang (lebih lama)"))
            }
            "kompres" -> {
                tambahPilihan("kualitas", "Kualitas gambar", listOf("Tinggi (ukuran lebih besar)", "Sedang", "Rendah (ukuran paling kecil)"), 1)
                tambahPilihan("resolusi", "Resolusi", listOf("Sama seperti asli", "Maksimal 720p", "Maksimal 480p", "Maksimal 360p"))
                tambahPilihan("kbps", "Kualitas suara", listOf("128 kbps", "96 kbps", "64 kbps"), 1)
            }
            "balik" -> {
                tambahPilihan("suara", "Suara", listOf("Ikut dibalik", "Tetap normal", "Dibuang"))
                tambahPilihan("resolusi", "Resolusi hasil (makin kecil makin hemat memori)",
                    listOf("Maksimal 360p", "Maksimal 480p", "Maksimal 720p", "Sama seperti asli"), 1)
            }
            "splitter" -> {
                tambahPilihan("interval", "Bagi setiap", listOf("10 detik", "30 detik", "1 menit", "2 menit", "5 menit", "10 menit"), 2)
                tambahIsian("titik", "Titik waktu sendiri, misalnya 1:30, 4:05. Kosongkan untuk memakai pilihan di atas", "")
            }
            "mixer" -> {
                tambahIsian("vol1", "Volume suara asli video, persen", "100", true)
                tambahIsian("vol2", "Volume audio tambahan, persen", "100", true)
                tambahPilihan("ulang", "Bila audio tambahan lebih pendek dari video",
                    listOf("Ulangi sampai video selesai", "Putar sekali saja"))
            }
            "kecepatan" -> {
                tambahPilihan("kec", "Kecepatan", listOf(
                    "0,25 kali (sangat lambat)", "0,5 kali", "0,75 kali", "1,25 kali",
                    "1,5 kali", "2 kali", "3 kali", "4 kali"), 5)
            }
            "video_audio" -> {
                tambahPilihan("fmt", "Format audio", OutFmt.values().map { it.label })
                tambahPilihan("kbps", "Kualitas (untuk MP3 dan M4A)", daftarKbpsAudio.map { "$it kbps" }, 1)
            }
            "gif" -> {
                tambahIsian("mulai", "Mulai dari. Detik atau menit:detik", "0")
                tambahIsian("lama", "Lama GIF, detik (maksimal 30)", "5", true)
                tambahPilihan("fps", "Jumlah gambar per detik", daftarFps.map { "$it" }, 2)
                tambahPilihan("lebar", "Lebar GIF", daftarLebarGif.map { "$it piksel" }, 1)
            }
            "booster" -> {
                tambahPilihan("pct", "Naikkan volume menjadi", daftarBooster.map { "$it persen" }, 1)
            }
            "hapus" -> {
                tambahPilihan("apa", "Yang dihapus", listOf("Suara dari video", "Satu bagian di tengah video"))
                tambahIsian("mulai", "Untuk bagian tengah: mulai dari. Detik atau menit:detik", "0")
                tambahIsian("sampai", "Untuk bagian tengah: sampai", "")
            }
            "heningkan" -> {
                tambahIsian("mulai", "Senyapkan mulai dari. Detik atau menit:detik", "0")
                tambahIsian("sampai", "Sampai. Kosongkan bila sampai akhir video", "")
            }
            "loop" -> {
                tambahPilihan("kali", "Jumlah putaran", daftarLoop.map { "$it kali" })
            }
            "noise" -> {
                tambahPilihan("kuat", "Kekuatan", listOf("Ringan", "Sedang", "Kuat"), 1)
                tambahPilihan("dengung", "Dengung rendah", listOf("Biarkan", "Buang dengung di bawah 80 Hz"))
            }
            "stabilkan" -> {
                tambahPilihan("kuat", "Kekuatan", listOf("Ringan", "Sedang", "Kuat"), 1)
            }
        }
    }

    // =====================================================================================
    //  Pilih video
    // =====================================================================================

    private fun namaDari(uri: Uri): String {
        var nama = uri.lastPathSegment ?: "berkas"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (k >= 0) nama = c.getString(k) ?: nama
                }
            }
        } catch (_: Exception) { }
        return nama
    }

    private fun setSumber(uri: Uri) {
        sumber = uri
        namaSumber = namaDari(uri)
        durSec = 0.0
        adaSuara = true
        adaGambar = true
        tvBerkas.text = "Video: $namaSumber. Membaca info…"
        hapusHasil()
        segarkanTombol()
        thread {
            var dur = 0.0
            var suara = true
            var gambar = true
            try {
                val p = FFmpegKitConfig.getSafParameterForRead(this, uri)
                val mi = FFprobeKit.getMediaInformation(p).mediaInformation
                if (mi != null) {
                    dur = mi.duration?.toDoubleOrNull() ?: 0.0
                    val st = mi.streams
                    if (st != null) {
                        suara = st.any { it.type == "audio" }
                        gambar = st.any { it.type == "video" }
                    }
                }
            } catch (_: Throwable) { }
            runOnUiThread {
                if (sumber != uri) return@runOnUiThread
                durSec = dur
                adaSuara = suara
                adaGambar = gambar
                val sb = StringBuilder("Video: ").append(namaSumber)
                if (dur > 0) sb.append(". Lama ").append(Converter.durasiTeks(dur))
                sb.append(if (suara) ". Ada suara." else ". Tanpa suara.")
                if (!gambar) sb.append(" Berkas ini tidak berisi gambar.")
                tvBerkas.text = sb.toString()
                status("Video dipilih. Atur opsi, lalu tekan Mulai proses.")
                segarkanTombol()
            }
        }
    }

    // =====================================================================================
    //  Rencana perintah FFmpeg
    // =====================================================================================

    private fun f3(v: Double) = String.format(Locale.US, "%.3f", v)

    private fun mimeDari(ext: String): String = when (ext) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "webm" -> "video/webm"
        "3gp" -> "video/3gpp"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "flac" -> "audio/flac"
        "wav" -> "audio/x-wav"
        "gif" -> "image/gif"
        else -> "video/*"
    }

    /** Ekstensi untuk hasil tanpa encode ulang gambar. [ulangSuara] true bila suara di-encode ke AAC (webm tidak bisa). */
    private fun extSalinan(ulangSuara: Boolean): String {
        val e = namaSumber.substringAfterLast('.', "").lowercase(Locale.US)
        val aman = if (ulangSuara) setOf("mp4", "mkv", "mov", "m4v") else setOf("mp4", "mkv", "mov", "m4v", "webm", "3gp")
        return if (e in aman) e else "mkv"
    }

    private fun vEnc(x264: Boolean, crf: Int, q: Int): List<String> =
        if (x264) listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "$crf", "-pix_fmt", "yuv420p")
        else listOf("-c:v", "mpeg4", "-q:v", "$q", "-pix_fmt", "yuv420p")

    private fun aac(kbps: Int): List<String> = listOf("-c:a", "aac", "-b:a", "${kbps}k")

    private fun atempo(s: Double): String {
        val b = ArrayList<String>()
        var x = s
        while (x > 2.0) { b += "atempo=2.0"; x /= 2.0 }
        while (x < 0.5) { b += "atempo=0.5"; x /= 0.5 }
        b += "atempo=" + String.format(Locale.US, "%.4f", x)
        return b.joinToString(",")
    }

    private fun skala(tinggi: Int) = "scale=-2:min($tinggi\\,ih)"

    private fun rencana(x264: Boolean, n: Map<String, String>, masuk: String, masuk2: String?): Rencana {
        val stempel = System.currentTimeMillis()
        fun p(k: String) = n[k]?.toIntOrNull() ?: 0
        fun t(k: String) = n[k] ?: ""
        fun waktu(k: String, nama: String): Double =
            Converter.parseTime(t(k)) ?: throw Galat("$nama tidak valid. Tulis detik, misalnya 90, atau menit:detik, misalnya 1:30.")
        fun angka(k: String, nama: String, min: Double, maks: Double): Double {
            val v = t(k).replace(',', '.').toDoubleOrNull() ?: throw Galat("$nama harus berupa angka.")
            if (v < min || v > maks) throw Galat("$nama harus antara ${min.toInt()} dan ${maks.toInt()}.")
            return v
        }
        fun dasar(): ArrayList<String> = arrayListOf("-y", "-nostdin")
        fun selesai(a: ArrayList<String>, ext: String, jenis: Jenis, outSec: Double): Rencana {
            val d = File(cacheDir, "avt_$stempel.$ext")
            a += d.absolutePath
            return Rencana(a, d, null, ext, jenis, mimeDari(ext), (outSec * 1000).toLong())
        }
        fun perluSuara(pesan: String) { if (!adaSuara) throw Galat(pesan) }
        fun perluGambar() { if (!adaGambar) throw Galat("Berkas ini tidak berisi gambar. Pilih berkas video.") }

        perluGambar()
        val maps = listOf("-map", "0:v:0?", "-map", "0:a:0?")

        return when (modeId) {
            "trim" -> {
                val s = waktu("mulai", "Waktu mulai")
                val e = waktu("sampai", "Waktu sampai")
                if (e > 0 && e <= s) throw Galat("Waktu sampai harus lebih besar dari waktu mulai.")
                if (durSec > 0 && s >= durSec) throw Galat("Waktu mulai sudah melewati akhir video.")
                val len = if (e > 0) e - s else if (durSec > 0) durSec - s else 0.0
                val a = dasar()
                if (s > 0) a += listOf("-ss", f3(s))
                a += listOf("-i", masuk)
                if (e > 0) a += listOf("-t", f3(len))
                a += maps
                if (p("cara") == 0) {
                    a += listOf("-c", "copy", "-avoid_negative_ts", "make_zero")
                    selesai(a, extSalinan(false), Jenis.VIDEO, len)
                } else {
                    a += vEnc(x264, 20, 3)
                    a += aac(160)
                    a += listOf("-movflags", "+faststart")
                    selesai(a, "mp4", Jenis.VIDEO, len)
                }
            }
            "kompres" -> {
                val crf = listOf(23, 28, 32)[p("kualitas").coerceIn(0, 2)]
                val q = listOf(4, 8, 12)[p("kualitas").coerceIn(0, 2)]
                val tinggi = listOf(0, 720, 480, 360)[p("resolusi").coerceIn(0, 3)]
                val kbps = listOf(128, 96, 64)[p("kbps").coerceIn(0, 2)]
                val a = dasar()
                a += listOf("-i", masuk)
                a += maps
                if (tinggi > 0) a += listOf("-vf", skala(tinggi))
                a += vEnc(x264, crf, q)
                a += aac(kbps)
                a += listOf("-movflags", "+faststart")
                selesai(a, "mp4", Jenis.VIDEO, durSec)
            }
            "balik" -> {
                if (durSec > 30) throw Galat("Balik memuat seluruh gambar video di memori, jadi dibatasi sampai 30 detik. Potong video ini dulu dengan alat Potong.")
                val tinggi = listOf(360, 480, 720, 0)[p("resolusi").coerceIn(0, 3)]
                val suara = p("suara")
                val a = dasar()
                a += listOf("-i", masuk)
                a += listOf("-map", "0:v:0")
                if (adaSuara && suara != 2) a += listOf("-map", "0:a:0")
                a += listOf("-vf", (if (tinggi > 0) skala(tinggi) + "," else "") + "reverse")
                if (adaSuara && suara == 0) a += listOf("-af", "areverse")
                a += vEnc(x264, 23, 4)
                if (adaSuara && suara != 2) a += aac(160) else a += "-an"
                a += listOf("-movflags", "+faststart")
                selesai(a, "mp4", Jenis.VIDEO, durSec)
            }
            "splitter" -> {
                val titik = t("titik")
                val a = dasar()
                a += listOf("-i", masuk)
                a += maps
                a += listOf("-c", "copy")
                if (titik.isNotEmpty()) {
                    val daftar = Converter.parseTimeList(titik)
                        ?: throw Galat("Titik waktu tidak valid. Contoh yang benar: 1:30, 4:05, 10:00. Tidak boleh nol atau kembar.")
                    if (daftar.isEmpty()) throw Galat("Isi minimal satu titik waktu.")
                    if (durSec > 0 && daftar.last() >= durSec) throw Galat("Ada titik waktu yang melewati akhir video.")
                    a += listOf("-f", "segment", "-segment_times", daftar.joinToString(",") { f3(it) })
                } else {
                    val dtk = daftarBagi[p("interval").coerceIn(0, daftarBagi.size - 1)]
                    if (durSec > 0 && dtk >= durSec) throw Galat("Video ini lebih pendek dari lama bagian yang dipilih. Pilih bagian yang lebih pendek.")
                    a += listOf("-f", "segment", "-segment_time", "$dtk")
                }
                a += listOf("-reset_timestamps", "1")
                val ext = extSalinan(false)
                val dir = File(cacheDir, "avt_$stempel")
                dir.mkdirs()
                a += File(dir, "bagian_%03d.$ext").absolutePath
                Rencana(a, null, dir, ext, Jenis.VIDEO, mimeDari(ext), (durSec * 1000).toLong())
            }
            "mixer" -> {
                if (masuk2 == null) throw Galat("Pilih audio tambahan dulu.")
                val v1 = angka("vol1", "Volume suara asli", 0.0, 1000.0) / 100.0
                val v2 = angka("vol2", "Volume audio tambahan", 0.0, 1000.0) / 100.0
                val ulang = p("ulang") == 0
                val a = dasar()
                a += listOf("-i", masuk)
                if (ulang) a += listOf("-stream_loop", "-1")
                a += listOf("-i", masuk2)
                val vs1 = String.format(Locale.US, "%.3f", v1)
                val vs2 = String.format(Locale.US, "%.3f", v2)
                val graf = if (adaSuara)
                    "[0:a]volume=$vs1[a0];[1:a]volume=$vs2[a1];[a0][a1]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[m];[m]alimiter=limit=0.97[a]"
                else
                    "[1:a]volume=$vs2,apad,alimiter=limit=0.97[a]"
                a += listOf("-filter_complex", graf, "-map", "0:v:0", "-map", "[a]", "-c:v", "copy")
                a += aac(192)
                if (!adaSuara) a += "-shortest"
                a += listOf("-movflags", "+faststart")
                selesai(a, extSalinan(true), Jenis.VIDEO, durSec)
            }
            "kecepatan" -> {
                val s = daftarKecepatan[p("kec").coerceIn(0, daftarKecepatan.size - 1)]
                val a = dasar()
                a += listOf("-i", masuk)
                a += maps
                a += listOf("-vf", "setpts=PTS/" + String.format(Locale.US, "%.4f", s))
                if (adaSuara) a += listOf("-af", atempo(s))
                a += vEnc(x264, 23, 4)
                a += aac(160)
                a += listOf("-movflags", "+faststart")
                selesai(a, "mp4", Jenis.VIDEO, if (durSec > 0) durSec / s else 0.0)
            }
            "video_audio" -> {
                perluSuara("Video ini tidak punya suara, jadi tidak ada yang bisa diambil.")
                val fmt = OutFmt.values()[p("fmt").coerceIn(0, OutFmt.values().size - 1)]
                val kbps = daftarKbpsAudio[p("kbps").coerceIn(0, daftarKbpsAudio.size - 1)]
                val a = dasar()
                a += listOf("-i", masuk, "-vn", "-map", "0:a:0")
                a += fmt.codecArgs(kbps)
                selesai(a, fmt.ext, Jenis.AUDIO, durSec)
            }
            "gif" -> {
                val s = waktu("mulai", "Waktu mulai")
                val lama = angka("lama", "Lama GIF", 1.0, 30.0)
                if (durSec > 0 && s >= durSec) throw Galat("Waktu mulai sudah melewati akhir video.")
                val fps = daftarFps[p("fps").coerceIn(0, daftarFps.size - 1)]
                val lebar = daftarLebarGif[p("lebar").coerceIn(0, daftarLebarGif.size - 1)]
                val a = dasar()
                if (s > 0) a += listOf("-ss", f3(s))
                a += listOf("-i", masuk, "-t", f3(lama), "-an")
                a += listOf(
                    "-vf",
                    "fps=$fps,scale=min($lebar\\,iw):-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[pl];[s1][pl]paletteuse=dither=bayer:bayer_scale=5",
                    "-loop", "0"
                )
                selesai(a, "gif", Jenis.GAMBAR, lama)
            }
            "booster" -> {
                perluSuara("Video ini tidak punya suara, jadi tidak ada yang bisa dikeraskan.")
                val pct = daftarBooster[p("pct").coerceIn(0, daftarBooster.size - 1)]
                val af = "acompressor=threshold=0.5:ratio=2:attack=10:release=150:knee=6:makeup=1," +
                    "volume=" + String.format(Locale.US, "%.2f", pct / 100.0) + "," +
                    "alimiter=limit=0.95:attack=15:release=250:level=0"
                val a = dasar()
                a += listOf("-i", masuk, "-map", "0:v:0", "-map", "0:a:0", "-c:v", "copy", "-af", af)
                a += aac(192)
                a += listOf("-movflags", "+faststart")
                selesai(a, extSalinan(true), Jenis.VIDEO, durSec)
            }
            "hapus" -> {
                if (p("apa") == 0) {
                    perluSuara("Video ini sudah tidak punya suara.")
                    val a = dasar()
                    a += listOf("-i", masuk, "-map", "0:v:0", "-an", "-c:v", "copy")
                    selesai(a, extSalinan(false), Jenis.VIDEO, durSec)
                } else {
                    val s = waktu("mulai", "Waktu mulai")
                    val e = waktu("sampai", "Waktu sampai")
                    if (e <= s) throw Galat("Isi waktu sampai, dan harus lebih besar dari waktu mulai.")
                    if (durSec > 0 && s >= durSec) throw Galat("Waktu mulai sudah melewati akhir video.")
                    val ss = f3(s)
                    val ee = f3(e)
                    val a = dasar()
                    a += listOf("-i", masuk, "-map", "0:v:0")
                    if (adaSuara) a += listOf("-map", "0:a:0")
                    a += listOf("-vf", "select='not(between(t,$ss,$ee))',setpts=N/FRAME_RATE/TB")
                    if (adaSuara) a += listOf("-af", "aselect='not(between(t,$ss,$ee))',asetpts=N/SR/TB")
                    a += vEnc(x264, 21, 3)
                    if (adaSuara) a += aac(160)
                    a += listOf("-movflags", "+faststart")
                    val sisa = if (durSec > 0) (durSec - (minOf(e, durSec) - s)).coerceAtLeast(0.0) else 0.0
                    selesai(a, "mp4", Jenis.VIDEO, sisa)
                }
            }
            "heningkan" -> {
                perluSuara("Video ini tidak punya suara.")
                val s = waktu("mulai", "Waktu mulai")
                val e = waktu("sampai", "Waktu sampai")
                if (e > 0 && e <= s) throw Galat("Waktu sampai harus lebih besar dari waktu mulai.")
                val cond = if (e > 0) "between(t,${f3(s)},${f3(e)})" else "gte(t,${f3(s)})"
                val a = dasar()
                a += listOf("-i", masuk, "-map", "0:v:0", "-map", "0:a:0", "-c:v", "copy",
                    "-af", "volume=enable='$cond':volume=0")
                a += aac(192)
                a += listOf("-movflags", "+faststart")
                selesai(a, extSalinan(true), Jenis.VIDEO, durSec)
            }
            "loop" -> {
                val kali = daftarLoop[p("kali").coerceIn(0, daftarLoop.size - 1)]
                val a = dasar()
                a += listOf("-stream_loop", "${kali - 1}", "-i", masuk)
                a += maps
                a += listOf("-c", "copy")
                selesai(a, extSalinan(false), Jenis.VIDEO, durSec * kali)
            }
            "noise" -> {
                perluSuara("Video ini tidak punya suara, jadi tidak ada noise yang bisa dikurangi.")
                val nr = listOf(8, 14, 22)[p("kuat").coerceIn(0, 2)]
                val af = (if (p("dengung") == 1) "highpass=f=80," else "") + "afftdn=nr=$nr:nf=-40:tn=1"
                val a = dasar()
                a += listOf("-i", masuk, "-map", "0:v:0", "-map", "0:a:0", "-c:v", "copy", "-af", af)
                a += aac(192)
                a += listOf("-movflags", "+faststart")
                selesai(a, extSalinan(true), Jenis.VIDEO, durSec)
            }
            "stabilkan" -> {
                val r = listOf(8, 16, 32)[p("kuat").coerceIn(0, 2)]
                val a = dasar()
                a += listOf("-i", masuk)
                a += maps
                a += listOf("-vf", "deshake=rx=$r:ry=$r")
                a += vEnc(x264, 21, 3)
                a += aac(160)
                a += listOf("-movflags", "+faststart")
                selesai(a, "mp4", Jenis.VIDEO, durSec)
            }
            else -> throw Galat("Alat ini belum dikenal.")
        }
    }

    private fun labelNama(): String = when (modeId) {
        "trim" -> "Potong"
        "kompres" -> "Kompres"
        "balik" -> "Balik"
        "splitter" -> "Bagi"
        "mixer" -> "Campur"
        "kecepatan" -> "Kecepatan"
        "video_audio" -> "VideoKeAudio"
        "gif" -> "VideoKeGif"
        "booster" -> "Volume"
        "hapus" -> "Hapus"
        "heningkan" -> "Senyap"
        "loop" -> "Ulang"
        "noise" -> "BersihNoise"
        "stabilkan" -> "Stabil"
        else -> "Video"
    }

    // =====================================================================================
    //  Proses
    // =====================================================================================

    private fun ambilNilai(): Map<String, String> {
        val m = HashMap<String, String>()
        for ((k, s) in sp) m[k] = s.selectedItemPosition.toString()
        for ((k, e) in et) m[k] = e.text.toString().trim()
        return m
    }

    private fun jalankan() {
        val src = sumber
        if (src == null) { status("Pilih video dulu."); return }
        if (sibuk) return
        if (modeId == "mixer" && sumber2 == null) { status("Pilih audio tambahan dulu."); return }
        val n = ambilNilai()
        hapusHasil()
        batal = false
        setSibuk(true)
        progres(0, "Menyiapkan")
        status("Memproses. Biarkan layar menyala sampai selesai.")
        thread { proses(true, n, src) }
    }

    private fun proses(x264: Boolean, n: Map<String, String>, src: Uri) {
        val r: Rencana = try {
            val masuk = FFmpegKitConfig.getSafParameterForRead(this, src)
            val s2 = sumber2
            val masuk2 = if (s2 != null) FFmpegKitConfig.getSafParameterForRead(this, s2) else null
            rencana(x264, n, masuk, masuk2)
        } catch (e: Galat) {
            val pesan = e.message ?: "Pengaturan tidak valid."
            runOnUiThread { gagal(pesan) }
            return
        } catch (e: Throwable) {
            val pesan = "Berkas tidak bisa dibuka: ${e.message ?: e.javaClass.simpleName}"
            runOnUiThread { gagal(pesan) }
            return
        }
        if (batal) { runOnUiThread { gagal("Dibatalkan.") }; return }

        sesi = FFmpegKit.executeWithArgumentsAsync(
            r.args.toTypedArray(),
            { s ->
                when {
                    ReturnCode.isCancel(s.returnCode) -> {
                        bersihkan(r)
                        runOnUiThread { gagal("Dibatalkan.") }
                    }
                    ReturnCode.isSuccess(s.returnCode) && hasilAda(r) -> simpanSemua(r)
                    else -> {
                        bersihkan(r)
                        val log = s.allLogsAsString ?: ""
                        val tanpaX264 = x264 && (log.contains("Unknown encoder", true) ||
                            log.contains("Encoder not found", true) ||
                            (log.contains("libx264", true) && log.contains("not", true)))
                        if (tanpaX264) {
                            runOnUiThread { status("Mesin H.264 tidak ada di pustaka ini, memakai MPEG-4 sebagai cadangan.") }
                            thread { proses(false, n, src) }
                        } else {
                            val ringkas = log.takeLast(300).replace('\n', ' ')
                            runOnUiThread { gagal("Gagal (kode ${s.returnCode}): $ringkas") }
                        }
                    }
                }
            },
            null,
            { st ->
                if (r.outMs > 0) {
                    val pr = (st.time.toLong() * 100L / r.outMs).toInt().coerceIn(0, 99)
                    runOnUiThread { progres(pr, "Memproses") }
                }
            }
        )
    }

    private fun hasilAda(r: Rencana): Boolean {
        val d = r.dest
        if (d != null) return d.length() > 0
        val dir = r.dirBanyak ?: return false
        return (dir.listFiles { f -> f.name.startsWith("bagian_") && f.length() > 0 }?.size ?: 0) > 0
    }

    private fun bersihkan(r: Rencana) {
        r.dest?.delete()
        r.dirBanyak?.deleteRecursively()
    }

    private fun batalkan() {
        if (!sibuk) return
        batal = true
        try { sesi?.cancel() } catch (_: Exception) { }
        status("Membatalkan…")
    }

    private fun gagal(pesan: String) {
        setSibuk(false)
        progres(0, "")
        status(pesan)
    }

    private fun simpanSemua(r: Rencana) {
        val dest = r.dest
        val berkas: List<File> = if (dest != null) listOf(dest)
        else (r.dirBanyak?.listFiles { f -> f.name.startsWith("bagian_") && f.length() > 0 }?.sortedBy { it.name } ?: emptyList())
        val stempel = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val daftar = ArrayList<Simpanan>()
        var galat: String? = null
        for ((i, f) in berkas.withIndex()) {
            val nomor = if (berkas.size > 1) "_" + String.format(Locale.US, "%03d", i + 1) else ""
            val nama = "${labelNama()}_$stempel$nomor.${r.ext}"
            var uri: Uri? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try { uri = simpanOtomatis(f, nama, r.mime, r.jenis) } catch (e: Exception) { galat = e.message ?: "galat" }
            }
            daftar += Simpanan(f, uri, nama, r.mime, r.jenis)
        }
        val g = galat
        runOnUiThread { tampilHasil(daftar, g) }
    }

    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanOtomatis(src: File, nama: String, mime: String, jenis: Jenis): Uri {
        val (koleksi, folder) = when (jenis) {
            Jenis.VIDEO -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "Movies/AudioLab Novan/Alat Video"
            Jenis.AUDIO -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "Music/AudioLab Novan/Alat Video"
            Jenis.GAMBAR -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to "Pictures/AudioLab Novan/Alat Video"
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nama)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    private fun ukuranTeks(b: Long): String = when {
        b >= 1024L * 1024 -> String.format(Locale("id"), "%.2f MB", b / 1048576.0)
        b >= 1024 -> String.format(Locale("id"), "%.1f KB", b / 1024.0)
        else -> "$b byte"
    }

    // =====================================================================================
    //  Hasil
    // =====================================================================================

    private fun tampilHasil(daftar: List<Simpanan>, galat: String?) {
        setSibuk(false)
        if (daftar.isEmpty()) { gagal("Proses selesai, tetapi tidak ada berkas hasil."); return }
        hasilList.clear()
        hasilList.addAll(daftar)
        progres(100, "Selesai")
        val jenis = daftar[0].jenis
        val folder = when (jenis) { Jenis.VIDEO -> "Film"; Jenis.AUDIO -> "Musik"; Jenis.GAMBAR -> "Gambar" }
        val total = ukuranTeks(daftar.sumOf { it.file.length() })
        val semuaTersimpan = daftar.all { it.uri != null }
        val sb = StringBuilder("Selesai. ")
        if (daftar.size > 1) sb.append("${daftar.size} bagian, ") 
        sb.append("ukuran $total. ")
        when {
            semuaTersimpan -> sb.append("Tersimpan di folder $folder, AudioLab Novan, Alat Video, dengan nama ${daftar[0].nama}")
                .append(if (daftar.size > 1) " dan seterusnya." else ".")
            galat != null -> sb.append("Tidak bisa disimpan otomatis ($galat). Tekan Simpan sebagai.")
            else -> sb.append("Tekan Simpan sebagai untuk memilih lokasi simpan.")
        }
        tvHasil.text = sb.toString()
        panelHasil.visibility = View.VISIBLE
        btnMenu.visibility = if (jenis == Jenis.GAMBAR) View.GONE else View.VISIBLE
        btnSimpan.text = if (daftar.size > 1) "Simpan bagian pertama sebagai…" else "Simpan sebagai…"
        status(tvHasil.text.toString())
        segarkanTombol()
        if (jenis != Jenis.GAMBAR) bukaMenuHasil()
    }

    private fun uriBagikan(s: Simpanan): Uri =
        s.uri ?: FileProvider.getUriForFile(this, "$packageName.berkas", s.file)

    private fun bukaMenuHasil() {
        if (hasilList.isEmpty()) return
        dialogHasil.tampilkan(hasilList.map { DialogHasil.Hasil(uriBagikan(it), it.nama, it.mime) }, "Proses selesai")
    }

    private fun bukaHasil() {
        val s = hasilList.firstOrNull() ?: return
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uriBagikan(s), s.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            status("Tidak ada aplikasi yang bisa membuka berkas ini.")
        }
    }

    private fun bagikan() {
        if (hasilList.isEmpty()) return
        try {
            val kirim = if (hasilList.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = hasilList[0].mime
                    putExtra(Intent.EXTRA_STREAM, uriBagikan(hasilList[0]))
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = hasilList[0].mime
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(hasilList.map { uriBagikan(it) }))
                }
            }
            kirim.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(kirim, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            status("Menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    private fun simpanKeLokasi() {
        val s = hasilList.firstOrNull()
        if (s == null || !s.file.exists()) { status("Belum ada hasil untuk disimpan."); return }
        simpanSebagai.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = s.mime
            putExtra(Intent.EXTRA_TITLE, s.nama)
        })
    }

    private fun hapusHasil() {
        hasilList.forEach { it.file.delete() }
        hasilList.clear()
        if (::panelHasil.isInitialized) panelHasil.visibility = View.GONE
        hapusCache()
    }

    private fun hapusCache() {
        try { cacheDir.listFiles { f -> f.name.startsWith("avt_") }?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
    }

    // =====================================================================================
    //  Status, progres, tombol
    // =====================================================================================

    private fun status(t: String) { if (::tvStatus.isInitialized) tvStatus.text = t }

    private fun progres(p: Int, teks: String) {
        progress.progress = p
        tvProgress.text = if (teks.isEmpty()) "" else "$teks, $p persen."
        val kelompok = p / 10
        tvProgress.accessibilityLiveRegion =
            if (kelompok == terakhirUmum) View.ACCESSIBILITY_LIVE_REGION_NONE else View.ACCESSIBILITY_LIVE_REGION_POLITE
        terakhirUmum = kelompok
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        if (s) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        segarkanTombol()
    }

    private fun segarkanTombol() {
        if (!::btnMulai.isInitialized) return
        btnMulai.isEnabled = sumber != null && !sibuk && (modeId != "mixer" || sumber2 != null)
        btnBatal.isEnabled = sibuk
        btnPilih.isEnabled = !sibuk
        btnPilih2.isEnabled = !sibuk
        sp.values.forEach { it.isEnabled = !sibuk }
        et.values.forEach { it.isEnabled = !sibuk }
        btnSimpan.isEnabled = !sibuk
    }

    override fun onStop() {
        super.onStop()
        if (!sibuk) dialogHasil.hentikanSuara()
    }

    override fun onDestroy() {
        batal = true
        try { sesi?.cancel() } catch (_: Exception) { }
        dialogHasil.lepas()
        if (!isChangingConfigurations) hapusCache()
        super.onDestroy()
    }
}
