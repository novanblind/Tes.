package com.novan.penghilangvokal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.File;
import java.util.ArrayList;

/**
 * Menjalankan pemisahan vokal di latar belakang (foreground service) supaya proses terus
 * berjalan saat aplikasi lain dibuka. Kemajuan tampil di notifikasi.
 */
public class ProsesService extends Service {

    static final String AKSI_MULAI = "com.novan.penghilangvokal.MULAI";
    static final String AKSI_BATAL = "com.novan.penghilangvokal.BATAL";
    private static final String EKS_NAMA = "nama";
    private static final String EKS_VOKAL = "vokal";
    private static final String EKS_KUALITAS = "kualitas";
    private static final String EKS_KECEPATAN = "kecepatan";
    private static final String EKS_BERSIH = "bersih";
    private static final String CH_PROSES = "proses";
    private static final String CH_HASIL = "hasil";
    private static final int ID_PROSES = 1;
    private static final int ID_HASIL = 2;

    private static volatile boolean sibuk = false;

    private PowerManager.WakeLock wakeLock;

    static void mulai(Context c, Uri uri, String nama, boolean denganVokal, int vbrQ, int kecepatan,
                      boolean bersih) {
        Intent i = new Intent(c, ProsesService.class);
        i.setAction(AKSI_MULAI);
        i.setData(uri);
        i.putExtra(EKS_NAMA, nama);
        i.putExtra(EKS_VOKAL, denganVokal);
        i.putExtra(EKS_KUALITAS, vbrQ);
        i.putExtra(EKS_KECEPATAN, kecepatan);
        i.putExtra(EKS_BERSIH, bersih);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(i);
        } else {
            c.startService(i);
        }
    }

    static void batal(Context c) {
        VocalRemover r = ProsesStatus.remover;
        if (r != null) r.cancel();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel proses = new NotificationChannel(CH_PROSES,
                    getString(R.string.kanal_proses), NotificationManager.IMPORTANCE_LOW);
            proses.setShowBadge(false);
            nm.createNotificationChannel(proses);
            NotificationChannel hasil = new NotificationChannel(CH_HASIL,
                    getString(R.string.kanal_hasil), NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(hasil);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && AKSI_BATAL.equals(intent.getAction())) {
            batal(this);
            return START_NOT_STICKY;
        }

        // startForegroundService mewajibkan startForeground dalam beberapa detik.
        Notification n = bangunNotifikasi(0, getString(R.string.notif_memproses));
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_PROSES, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_PROSES, n);
        }

        if (intent == null || !AKSI_MULAI.equals(intent.getAction()) || intent.getData() == null) {
            if (!sibuk) {
                stopForeground(Service.STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (sibuk) {
            return START_NOT_STICKY;
        }
        sibuk = true;

        final Uri uri = intent.getData();
        final String nama = intent.getStringExtra(EKS_NAMA) != null
                ? intent.getStringExtra(EKS_NAMA) : "lagu";
        final boolean denganVokal = intent.getBooleanExtra(EKS_VOKAL, false);
        final int vbrQ = intent.getIntExtra(EKS_KUALITAS, 2);
        final int kecepatan = intent.getIntExtra(EKS_KECEPATAN, 1);
        final boolean bersih = intent.getBooleanExtra(EKS_BERSIH, false);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "penghilangvokal:proses");
            wakeLock.acquire(3L * 60 * 60 * 1000);
        }

        final VocalRemover r = new VocalRemover();
        ProsesStatus.remover = r;
        ProsesStatus.berjalan = true;
        ProsesStatus.persen = 0;
        ProsesStatus.namaLagu = nama;
        ProsesStatus.pesan = getString(R.string.memproses);
        ProsesStatus.perbarui();

        new Thread(() -> kerjakan(r, uri, nama, denganVokal, vbrQ, kecepatan, bersih)).start();
        return START_NOT_STICKY;
    }

    private void kerjakan(VocalRemover r, Uri uri, String nama, boolean denganVokal,
                          int vbrQ, int kecepatan, boolean bersih) {
        File tmp = new File(getCacheDir(), "hasil.mp3");
        File tmpV = denganVokal ? new File(getCacheDir(), "hasil_vokal.mp3") : null;
        String message;
        boolean ok = false;
        final ArrayList<Penyimpan.Hasil> daftar = new ArrayList<>();
        try {
            r.process(this, uri, tmp, tmpV, vbrQ, kecepatan, bersih, p -> {
                ProsesStatus.persen = p;
                perbaruiNotifikasi(p);
                ProsesStatus.perbarui();
            });
            ProsesStatus.pesan = getString(R.string.menyimpan);
            ProsesStatus.perbarui();
            Penyimpan.Hasil h1 = Penyimpan.simpan(this, tmp, nama, " (tanpa vokal).mp3");
            daftar.add(h1);
            message = getString(R.string.selesai, h1.nama);
            if (tmpV != null) {
                Penyimpan.Hasil h2 = Penyimpan.simpan(this, tmpV, nama, " (vokal saja).mp3");
                daftar.add(h2);
                message = message + " " + getString(R.string.selesai_vokal, h2.nama);
            }
            ok = true;
        } catch (VocalRemover.CancelledException e) {
            message = getString(R.string.dibatalkan);
        } catch (VocalRemover.NoAudioException e) {
            message = getString(R.string.tanpa_audio);
        } catch (Throwable e) {
            message = getString(R.string.gagal, String.valueOf(e.getMessage()));
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            if (tmpV != null) {
                //noinspection ResultOfMethodCallIgnored
                tmpV.delete();
            }
        }
        selesai(message, ok, daftar);
    }

    private void selesai(String message, boolean ok, ArrayList<Penyimpan.Hasil> daftar) {
        ProsesStatus.remover = null;
        if (ok) {
            ProsesStatus.persen = 100;
            ProsesStatus.hasil.clear();
            ProsesStatus.hasil.addAll(daftar);
            ProsesStatus.hasilBaru = true;
        }
        ProsesStatus.pesan = message;
        ProsesStatus.berjalan = false;
        ProsesStatus.perbarui();

        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);

        try {
            Notification.Builder b = pembangun(CH_HASIL)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(getString(R.string.notif_selesai_judul))
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message))
                    .setContentIntent(intentBuka())
                    .setAutoCancel(true);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(ID_HASIL, b.build());
        } catch (Throwable ignored) { }

        sibuk = false;
        stopSelf();
    }

    private Notification.Builder pembangun(String channel) {
        return Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
    }

    private PendingIntent intentBuka() {
        Intent buka = new Intent(this, MainActivity.class);
        buka.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, buka,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification bangunNotifikasi(int persen, String teks) {
        Intent batal = new Intent(this, ProsesService.class);
        batal.setAction(AKSI_BATAL);
        PendingIntent pBatal = PendingIntent.getService(this, 1, batal,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = pembangun(CH_PROSES)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(getString(R.string.notif_judul))
                .setContentText(teks)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setProgress(100, persen, false)
                .setContentIntent(intentBuka())
                .addAction(android.R.drawable.ic_delete, getString(R.string.batal), pBatal);
        return b.build();
    }

    private void perbaruiNotifikasi(int persen) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(ID_PROSES, bangunNotifikasi(persen,
                    getString(R.string.notif_persen, persen)));
        } catch (Throwable ignored) { }
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
