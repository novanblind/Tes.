import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.novan.audiolabnovan"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.novan.audiolabnovan"
        minSdk = 24
        targetSdk = 36
        versionCode = 60
        versionName = "1.50"

        // Varian 32-bit saja (armeabi-v7a). Varian 64-bit ada di proyek terpisah.
        ndk {
            abiFilters += setOf("armeabi-v7a")
        }
    }

    // Keystore disertakan di repo agar tanda tangan APK sama di setiap build.
    signingConfigs {
        create("app") {
            storeFile = rootProject.file("keystore/toolkit.jks")
            storePassword = "ytplayer123"
            keyAlias = "ytplayer"
            keyPassword = "ytplayer123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Pustaka native (.so) dikompresi di dalam APK supaya berkas APK lebih kecil.
    // Saat dipasang, Android mengekstraknya ke penyimpanan aplikasi.
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// Unduh pustaka FFmpeg otomatis bila belum ada (armeabi-v7a).
val fetchFfmpeg by tasks.registering(Exec::class) {
    val aar = file("libs/ffmpeg-kit-6.1.1-arm32.aar")
    onlyIf { !aar.exists() }
    workingDir = rootProject.projectDir
    commandLine("bash", "scripts/fetch-ffmpeg.sh")
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation(files("libs/ffmpeg-kit-6.1.1-arm32.aar").builtBy(fetchFfmpeg))
    implementation("com.arthenica:smart-exception-java:0.2.1")
}
