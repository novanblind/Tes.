package com.novan.filemanagermax

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/**
 * Membaca tulisan di foto atau gambar (tahap 79), offline lewat ML Kit.
 * Dibuka dari menu OCR di penampil gambar, atau dari menu Bagikan aplikasi lain (satu atau banyak gambar).
 * Hasil tampil sebagai blok teks yang bisa difokus pembaca layar, bisa disalin, dibagikan, atau disimpan .txt.
 */
class OcrActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "ocr_path"
        private const val MAX_IMAGES = 50
        private const val MAX_SHARE_CHARS = 100_000
        private const val K_INFO = 0
        private const val K_HEAD = 1
        private const val K_PARA = 2
    }

    private class Item(val kind: Int, val text: String)
    private class Src(val path: String?, val uri: Uri?, val name: String)

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var list: RecyclerView
    private lateinit var progress: View
    private lateinit var percent: TextView
    private lateinit var lm: LinearLayoutManager

    private val items = ArrayList<Item>()
    private val adapter = TextAdapter()
    private var srcs: List<Src> = emptyList()
    private var textScale = 1f
    private var destroyed = false
    private var finished = false

    private fun prefs() = getSharedPreferences("ocrviewer", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ocr)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        list = findViewById(R.id.ocrList)
        progress = findViewById(R.id.ocrProgress)
        percent = findViewById(R.id.ocrPercent)
        textScale = prefs().getFloat("text_scale", 1f)
        lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.adapter = adapter

        srcs = collectSources().take(MAX_IMAGES)
        if (srcs.isEmpty()) {
            android.widget.Toast.makeText(this, R.string.ocr_nothing, android.widget.Toast.LENGTH_LONG).show()
            finish()
            return
        }
        title = getString(R.string.ocr_title)
        list.announceForAccessibility(getString(R.string.ocr_loading))
        startOcr()
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        exec.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    // ------------------------------------------------------------------ sumber gambar

    private fun collectSources(): List<Src> {
        val out = ArrayList<Src>()
        val p = intent.getStringExtra(EXTRA_PATH)
        if (p != null) {
            out.add(Src(p, null, File(p).name))
            return out
        }
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                    ?.forEach { out.add(srcOf(it)) }
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                    ?.let { out.add(srcOf(it)) }
            else -> intent.data?.let { out.add(srcOf(it)) }
        }
        return out
    }

    private fun srcOf(u: Uri): Src {
        if (u.scheme == "file" && u.path != null) {
            val f = File(u.path!!)
            return Src(f.absolutePath, null, f.name)
        }
        return Src(null, u, queryName(u))
    }

    private fun queryName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n.replace('/', '_')
                }
            }
        } catch (e: Exception) {
            // abaikan
        }
        return (u.lastPathSegment ?: "gambar").substringAfterLast('/')
    }

    // ------------------------------------------------------------------ membaca

    private fun startOcr() {
        val total = srcs.size
        if (total <= 1) percent.visibility = View.GONE
        exec.execute {
            var lastStep = -1
            for ((i, s) in srcs.withIndex()) {
                if (destroyed) return@execute
                if (total > 1) {
                    val pct = i * 100 / total
                    if (pct / 10 != lastStep) {
                        lastStep = pct / 10
                        val msg = getString(R.string.ocr_percent, pct)
                        main.post { if (!destroyed) percent.text = msg }
                    }
                }
                val bmp = try {
                    OcrEngine.loadImage(this, s.path, s.uri)
                } catch (e: Throwable) {
                    null
                }
                var paras = emptyList<String>()
                if (bmp != null) {
                    paras = try {
                        OcrEngine.paragraphs(bmp)
                    } catch (e: Throwable) {
                        emptyList<String>()
                    }
                    bmp.recycle()
                }
                // gambar tanpa tulisan dilewati begitu saja, tanpa keterangan
                if (paras.isNotEmpty()) {
                    val batch = ArrayList<Item>()
                    if (total > 1) batch.add(Item(K_HEAD, getString(R.string.ocr_image_heading, i + 1)))
                    for (t in paras) batch.add(Item(K_PARA, t))
                    main.post {
                        if (destroyed) return@post
                        val from = items.size
                        items.addAll(batch)
                        adapter.notifyItemRangeInserted(from, batch.size)
                    }
                }
            }
            main.post {
                if (destroyed) return@post
                finished = true
                progress.visibility = View.GONE
                invalidateOptionsMenu()
                if (items.isEmpty()) {
                    list.announceForAccessibility(getString(R.string.ocr_done_none))
                } else {
                    list.postDelayed({ focusItem(0) }, 500)
                }
            }
        }
    }

    private fun focusItem(pos: Int, retry: Int = 2) {
        val v = list.findViewHolderForAdapterPosition(pos)?.itemView
        if (v != null) {
            v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
            v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        } else if (retry > 0) {
            list.postDelayed({ focusItem(pos, retry - 1) }, 200)
        }
    }

    // ------------------------------------------------------------------ menu

    private fun allText(): String {
        val sb = StringBuilder()
        for (it in items) {
            if (it.kind == K_INFO) continue
            sb.append(it.text).append(if (it.kind == K_HEAD) "\n" else "\n\n")
        }
        return sb.toString().trim()
    }

    private fun copyAll() {
        val t = allText()
        if (t.isEmpty()) { say(getString(R.string.ocr_no_result)); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.ocr_title), t))
        say(getString(R.string.office_copied))
    }

    private fun shareText() {
        val t = allText()
        if (t.isEmpty()) { say(getString(R.string.ocr_no_result)); return }
        if (t.length > MAX_SHARE_CHARS) { say(getString(R.string.ocr_too_long)); return }
        try {
            val i = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, t)
            startActivity(Intent.createChooser(i, getString(R.string.share_chooser)))
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    private fun saveTxt() {
        val t = allText()
        if (t.isEmpty()) { say(getString(R.string.ocr_no_result)); return }
        if (!Access.hasAccess(this)) { say(getString(R.string.permission_needed)); return }
        val base = srcs.firstOrNull()?.name?.substringBeforeLast('.', "")?.ifBlank { null }
            ?: srcs.firstOrNull()?.name ?: "ocr"
        val dir = File(Environment.getExternalStorageDirectory(), "FileManagerMax/OCR")
        try {
            dir.mkdirs()
            val target = FileOps.uniqueTarget(dir, "$base.txt")
            target.writeText(t, Charsets.UTF_8)
            say(getString(R.string.ocr_saved, target.absolutePath))
        } catch (e: Exception) {
            say(getString(R.string.ocr_save_failed))
        }
    }

    private fun changeScale(delta: Float) {
        val n = (textScale + delta).coerceIn(0.8f, 3.0f)
        if (n == textScale) { say(getString(R.string.pdf_scale_limit)); return }
        textScale = n
        prefs().edit().putFloat("text_scale", n).apply()
        adapter.notifyDataSetChanged()
        say(getString(R.string.pdf_scale_now, (n * 100).toInt()))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.ocr_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        for (id in listOf(
            R.id.action_ocr_copy, R.id.action_ocr_share, R.id.action_ocr_save,
            R.id.action_ocr_bigger, R.id.action_ocr_smaller
        )) menu.findItem(id).isVisible = finished && items.isNotEmpty()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_ocr_copy -> copyAll()
            R.id.action_ocr_share -> shareText()
            R.id.action_ocr_save -> saveTxt()
            R.id.action_ocr_bigger -> changeScale(0.2f)
            R.id.action_ocr_smaller -> changeScale(-0.2f)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ------------------------------------------------------------------ adapter

    private inner class TextAdapter : RecyclerView.Adapter<TextAdapter.VH>() {

        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_office_block, parent, false) as TextView
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val b = items[position]
            val head = b.kind == K_HEAD
            h.tv.text = b.text
            h.tv.setTypeface(null, if (head || b.kind == K_INFO) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            h.tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, (if (head) 20f else 16f) * textScale)
            ViewCompat.setAccessibilityHeading(h.tv, head)
        }
    }
}
