package com.makroku.automation.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** Dialog pesan popup dari aksi "Tampilkan pesan popup". Tombol OK, dibacakan otomatis oleh pembaca layar. */
class PopupActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val judul = intent.getStringExtra("title").orEmpty().ifBlank { "MakroKu" }
        val isi = intent.getStringExtra("text").orEmpty()
        val detik = intent.getIntExtra("seconds", 0)
        val dlg = AlertDialog.Builder(this)
            .setTitle(judul)
            .setMessage(isi)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        dlg.show()
        if (detik > 0) handler.postDelayed({ if (!isFinishing) finish() }, detik * 1000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
