package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Pencatat galat: bila aplikasi tertutup sendiri karena galat, rinciannya disimpan dan
 * ditampilkan sebagai dialog saat aplikasi dibuka lagi, supaya penyebabnya bisa dibacakan
 * TalkBack dan dikirim ke pengembang tanpa perlu komputer.
 */
object CrashReport {
    private fun file(c: Context) = File(c.applicationContext.filesDir, "galat_terakhir.txt")

    fun install(c: Context) {
        val app = c.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                file(app).writeText("Utas: ${t.name}\n$sw")
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }

    fun showIfAny(act: Activity) {
        val f = file(act)
        if (!f.exists()) return
        val text = try { f.readText().take(3000) } catch (_: Exception) { return }
        f.delete()
        AlertDialog.Builder(act)
            .setTitle("Aplikasi tertutup karena galat")
            .setMessage(text)
            .setPositiveButton("Tutup", null)
            .show()
    }
}
