package com.novan.adbshell;

import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Adapter daftar aplikasi dengan baris rapat. Di mode biasa barisnya teks polos;
 * di mode pilih (setelah tekan lama / ketuk dua kali tahan) tiap baris menjadi kotak centang
 * yang dibacakan pembaca layar sebagai "dicentang" atau "tidak dicentang".
 */
class PilihAdapter extends BaseAdapter {
    private final Context ctx;
    private final LayoutInflater inf;
    private final List<String> teks = new ArrayList<>();
    private final List<String> kunci = new ArrayList<>();
    private final Set<String> terpilih = new HashSet<>();
    private boolean modePilih = false;

    PilihAdapter(Context c) {
        ctx = c;
        inf = LayoutInflater.from(c);
    }

    void kosongkan() {
        teks.clear();
        kunci.clear();
    }

    void tambah(String kunciItem, String teksItem) {
        kunci.add(kunciItem);
        teks.add(teksItem);
    }

    void setModePilih(boolean m) { modePilih = m; }
    boolean isModePilih() { return modePilih; }
    Set<String> terpilih() { return terpilih; }

    /** Balik status centang; hasilnya true bila sekarang tercentang. */
    boolean balik(String k) {
        if (terpilih.remove(k)) return false;
        terpilih.add(k);
        return true;
    }

    @Override public int getCount() { return teks.size(); }
    @Override public Object getItem(int i) { return teks.get(i); }
    @Override public long getItemId(int i) { return i; }
    @Override public int getViewTypeCount() { return 2; }
    @Override public int getItemViewType(int i) { return modePilih ? 1 : 0; }

    @Override public View getView(int pos, View cv, ViewGroup parent) {
        View v = cv;
        if (v == null) {
            v = inf.inflate(modePilih ? android.R.layout.simple_list_item_multiple_choice
                    : android.R.layout.simple_list_item_1, parent, false);
        }
        if (v instanceof TextView) {
            TextView t = (TextView) v;
            float d = ctx.getResources().getDisplayMetrics().density;
            int h = (int) (10 * d), vv = (int) (5 * d);
            t.setMinHeight(0);
            t.setMinimumHeight(0);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding(h, vv, h, vv);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            t.setMaxLines(2);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setText(teks.get(pos));
        }
        if (v instanceof CheckedTextView) {
            ((CheckedTextView) v).setChecked(terpilih.contains(kunci.get(pos)));
        }
        return v;
    }
}
