package com.novan.filemanagermax

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.format.DateFormat
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Calendar
import java.util.Date
import java.util.concurrent.Executors

/**
 * Pencarian lanjutan: kata kunci (boleh memakai * dan ?), jenis berkas, tanggal diubah,
 * ukuran, dan lokasi. Mendukung riwayat dan pencarian suara.
 */
class SearchActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROOT = "root"
        const val EXTRA_TITLE = "title"
        private const val LIMIT = 1000
        private const val DAY = 86400000L
    }

    private class Filter(
        val name: (String) -> Boolean,
        val type: Int,
        val from: Long,
        val to: Long,
        val minSize: Long,
        val maxSize: Long,
        val hidden: Boolean
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var token = 0

    private lateinit var form: View
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var query: EditText
    private lateinit var spType: Spinner
    private lateinit var spDate: Spinner
    private lateinit var spSize: Spinner
    private lateinit var spWhere: Spinner
    private lateinit var rowAdapter: RowAdapter
    private lateinit var backCallback: OnBackPressedCallback

    private var roots: List<File> = emptyList()
    private var files: List<File> = emptyList()
    private var showingResults = false

    private val voice =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    query.setText(text)
                    runSearch()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.search_title)

        form = findViewById(R.id.form)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        query = findViewById(R.id.q)
        spType = findViewById(R.id.spType)
        spDate = findViewById(R.id.spDate)
        spSize = findViewById(R.id.spSize)
        spWhere = findViewById(R.id.spWhere)

        fun fill(sp: Spinner, labels: List<String>) {
            val a = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
            a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            sp.adapter = a
        }
        fill(spType, listOf(
            getString(R.string.type_all), getString(R.string.lib_images), getString(R.string.lib_audio),
            getString(R.string.lib_video), getString(R.string.lib_docs), getString(R.string.lib_archives),
            getString(R.string.lib_apks)
        ))
        fill(spDate, listOf(
            getString(R.string.date_any), getString(R.string.date_today), getString(R.string.date_7),
            getString(R.string.date_30), getString(R.string.date_old)
        ))
        fill(spSize, listOf(
            getString(R.string.size_any), getString(R.string.size_lt_1), getString(R.string.size_1_10),
            getString(R.string.size_10_100), getString(R.string.size_100_1000), getString(R.string.size_gt_1000)
        ))

        val labels = ArrayList<String>()
        val rs = ArrayList<File>()
        val presetRoot = intent.getStringExtra(EXTRA_ROOT)
        if (presetRoot != null) {
            labels.add(getString(R.string.search_this_folder, intent.getStringExtra(EXTRA_TITLE) ?: File(presetRoot).name))
            rs.add(File(presetRoot))
        }
        for (v in Volumes.list(this)) {
            labels.add(v.label)
            rs.add(v.root)
        }
        roots = rs
        fill(spWhere, labels)

        rowAdapter = RowAdapter(onClick = { onClickRow(it) }, onLong = { showActions(it) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter

        backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                showForm()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        findViewById<Button>(R.id.btnSearch).setOnClickListener { runSearch() }
        findViewById<Button>(R.id.btnHistory).setOnClickListener { showHistory() }
        findViewById<Button>(R.id.btnMic).setOnClickListener { startVoice() }
        query.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { runSearch(); true } else false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        token++
        executor.shutdownNow()
    }

    // ---------------------------------------------------------------- tampilan

    private fun showForm() {
        token++
        showingResults = false
        backCallback.isEnabled = false
        form.visibility = View.VISIBLE
        list.visibility = View.GONE
        empty.visibility = View.GONE
        supportActionBar?.subtitle = null
        title = getString(R.string.search_title)
        invalidateOptionsMenu()
    }

    private fun showResultsPane() {
        showingResults = true
        backCallback.isEnabled = true
        form.visibility = View.GONE
        invalidateOptionsMenu()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.search_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.search_edit).isVisible = showingResults
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> if (showingResults) showForm() else finish()
            R.id.search_edit -> showForm()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------------------------------------------------------- suara dan riwayat

    private fun startVoice() {
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.search_voice_prompt))
            )
        } catch (e: ActivityNotFoundException) {
            say(getString(R.string.search_voice_missing))
        }
    }

    private fun showHistory() {
        val h = Prefs.searchHistory(this)
        if (h.isEmpty()) { say(getString(R.string.search_history_empty)); return }
        val items = (h + getString(R.string.search_history_clear)).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.search_history)
            .setItems(items) { _, which ->
                if (which == h.size) {
                    Prefs.clearSearchHistory(this)
                    say(getString(R.string.search_history_cleared))
                } else {
                    query.setText(h[which])
                    runSearch()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- pencarian

    private fun nameMatcher(q: String): (String) -> Boolean {
        if (q.isEmpty()) return { true }
        if (q.contains('*') || q.contains('?')) {
            val sb = StringBuilder()
            for (ch in q) {
                when (ch) {
                    '*' -> sb.append(".*")
                    '?' -> sb.append('.')
                    else -> sb.append(Regex.escape(ch.toString()))
                }
            }
            val re = Regex(sb.toString(), RegexOption.IGNORE_CASE)
            return { re.matches(it) }
        }
        return { it.contains(q, ignoreCase = true) }
    }

    private fun buildFilter(q: String): Filter {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        var from = 0L
        var to = Long.MAX_VALUE
        when (spDate.selectedItemPosition) {
            1 -> from = cal.timeInMillis
            2 -> from = now - 7 * DAY
            3 -> from = now - 30 * DAY
            4 -> to = now - 365 * DAY
        }
        val mb = 1024L * 1024L
        var minS = 0L
        var maxS = Long.MAX_VALUE
        when (spSize.selectedItemPosition) {
            1 -> maxS = mb
            2 -> { minS = mb; maxS = 10 * mb }
            3 -> { minS = 10 * mb; maxS = 100 * mb }
            4 -> { minS = 100 * mb; maxS = 1024 * mb }
            5 -> minS = 1024 * mb
        }
        return Filter(nameMatcher(q), spType.selectedItemPosition, from, to, minS, maxS, Prefs.showHidden(this))
    }

    private fun typeOk(f: File, type: Int): Boolean {
        val ext = f.extension.lowercase()
        return when (type) {
            1 -> Util.kindOf(f) == Util.K_IMAGE
            2 -> Util.kindOf(f) == Util.K_AUDIO
            3 -> Util.kindOf(f) == Util.K_VIDEO
            4 -> ext in LibraryActivity.DOC_EXT
            5 -> ext in LibraryActivity.ARCHIVE_EXT
            6 -> ext in LibraryActivity.APK_EXT
            else -> true
        }
    }

    private fun matches(k: File, isDir: Boolean, f: Filter): Boolean {
        if (!f.name(k.name)) return false
        val m = k.lastModified()
        if (m < f.from || m > f.to) return false
        if (isDir) return f.type == 0 && f.minSize == 0L && f.maxSize == Long.MAX_VALUE
        val len = k.length()
        if (len < f.minSize || len > f.maxSize) return false
        return typeOk(k, f.type)
    }

    private fun walk(dir: File, f: Filter, out: MutableList<File>, tk: Int) {
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (tk != token || out.size >= LIMIT) return
            if (!f.hidden && k.name.startsWith(".")) continue
            val isDir = k.isDirectory
            if (matches(k, isDir, f)) out.add(k)
            if (isDir && !java.nio.file.Files.isSymbolicLink(k.toPath())) walk(k, f, out, tk)
        }
    }

    private fun runSearch() {
        val q = query.text.toString().trim()
        val where = roots.getOrNull(spWhere.selectedItemPosition) ?: return
        val filter = buildFilter(q)
        if (q.isNotEmpty()) Prefs.addSearchHistory(this, q)
        val tk = ++token
        showResultsPane()
        title = if (q.isEmpty()) getString(R.string.search_title) else getString(R.string.search_results, q)
        supportActionBar?.subtitle = where.absolutePath
        rowAdapter.submit(emptyList())
        list.visibility = View.GONE
        empty.setText(R.string.search_running)
        empty.visibility = View.VISIBLE
        executor.execute {
            val out = ArrayList<File>()
            walk(where, filter, out, tk)
            val sorted = out.sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() })
            val rows = sorted.map { toRow(it) }
            main.post {
                if (isFinishing || isDestroyed || tk != token) return@post
                files = sorted
                rowAdapter.submit(rows)
                list.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE
                empty.setText(R.string.search_none)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                val msg = if (sorted.size >= LIMIT) getString(R.string.search_limit, LIMIT)
                else getString(R.string.search_done, rows.size)
                say(msg)
                list.announceForAccessibility(msg)
            }
        }
    }

    private fun toRow(f: File): Row {
        val date = DateFormat.getMediumDateFormat(this).format(Date(f.lastModified()))
        val where = f.parent ?: ""
        return if (f.isDirectory) {
            val detail = "$date, $where"
            Row(Util.iconFor(f), f.name, detail, "${f.name}, $detail", f.absolutePath)
        } else {
            val detail = "${Util.formatSize(this, f.length())}, $date, $where"
            val kind = Util.kindOf(f)
            val thumb = if (Prefs.showThumbs(this) && (kind == Util.K_IMAGE || kind == Util.K_VIDEO))
                f.absolutePath else null
            Row(Util.iconFor(f), f.name, detail, "${f.name}, $detail", f.absolutePath, thumb = thumb)
        }
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun openFolder(p: File) {
        startActivity(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_ROOT, p.absolutePath)
                .putExtra(BrowserActivity.EXTRA_TITLE, p.name)
        )
    }

    private fun onClickRow(i: Int) {
        if (i !in files.indices) return
        val f = files[i]
        if (f.isDirectory) openFolder(f)
        else if (!Util.openSmart(this, f, files)) say(getString(R.string.cannot_open))
    }

    private fun showActions(i: Int) {
        if (i !in files.indices) return
        val f = files[i]
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.act_open)); acts.add { onClickRow(i) }
        if (f.isFile) {
            labels.add(getString(R.string.action_share))
            acts.add { if (!Util.share(this, f)) say(getString(R.string.cannot_open)) }
            labels.add(getString(R.string.action_share_doc))
            acts.add { if (!Util.shareAsDocument(this, listOf(f))) say(getString(R.string.cannot_open)) }
        }
        labels.add(getString(R.string.act_show_in_folder))
        acts.add { (if (f.isDirectory) f.parentFile else f.parentFile)?.let { openFolder(it) } }
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }
}
