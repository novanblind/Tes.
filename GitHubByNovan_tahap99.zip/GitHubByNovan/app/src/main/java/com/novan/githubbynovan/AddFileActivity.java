package com.novan.githubbynovan;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.widget.EditText;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/** Tambah berkas baru ke repositori dengan mengetik/menempel isinya. */
public class AddFileActivity extends Activity {
    private Ui ui;
    private String full, token;
    private boolean busy;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        full = getIntent().getStringExtra("repo");
        form();
    }

    private void form() {
        ui = new Ui(this, "Tambah berkas baru");
        ui.label("Repositori: " + full);
        final EditText name = ui.edit("Nama berkas (boleh pakai folder)", "contoh: app/src/main/AndroidManifest.xml", false, "");
        final EditText body = ui.edit("Isi berkas", "Ketik / tempel isi berkas...", true, "");
        ui.button("Simpan berkas", v -> {
            if (busy) return;
            final String path = name.getText().toString().trim().replaceFirst("^/+", "");
            if (path.isEmpty()) {
                ui.say("Nama berkas wajib diisi.");
                return;
            }
            final String content = Base64.encodeToString(
                    body.getText().toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            busy = true;
            ui.say("Menyimpan berkas...");

            final String url = Api.BASE + "/repos/" + full + "/contents/" + encPath(path);

            // Periksa sha bila berkas lama sudah ada agar bisa diperbarui tanpa galat
            Api.request("GET", url, token, null, (found, resGet) -> {
                String oldSha = null;
                if (found) {
                    String sh = Api.str(Api.parse(resGet), "sha");
                    if (!sh.isEmpty()) oldSha = sh;
                }
                final String sha = oldSha;
                JSONObject bodyJson = Api.o("message", (sha != null ? "Perbarui " : "Tambah ") + path,
                        "content", content);
                if (sha != null) {
                    try { bodyJson.put("sha", sha); } catch (Exception ignored) { }
                }

                Api.request("PUT", url, token, bodyJson.toString(), (ok, res) -> runOnUiThread(() -> {
                    busy = false;
                    if (!ok) {
                        ui.say("Gagal: " + res);
                        return;
                    }
                    JSONObject c = Api.parse(res).optJSONObject("content");
                    result(path, Api.str(c, "download_url"), Api.str(c, "html_url"));
                }));
            });
        });
        ui.button("Kembali", v -> finish());
    }

    private void result(final String path, final String raw, final String web) {
        ui = new Ui(this, "Berkas disimpan");
        ui.label("Nama: " + path + "\nRepositori: " + full);
        ui.say("Berkas berhasil disimpan.");
        final Runnable back = this::form;

        ui.button("1. Bangun APK dari repo ini", v -> TandaTanganRepo.mulai(this, full, token, back));
        ui.button("2. Cek status pembangunan APK", v -> ApkTools.cekStatus(this, full, token, back));
        ui.button("3. Salin tautan raw", v -> Ui.copy(this, "Tautan raw", raw));
        ui.button("4. Bagikan", v -> Ui.share(this, "Berkas: " + path, raw.isEmpty() ? web : raw));
        ui.button("5. Tambah berkas lain", v -> form());
        ui.button("Kembali", v -> finish());
    }

    private String encPath(String path) {
        if (path == null || path.isEmpty()) return "";
        String[] parts = path.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append("/");
            sb.append(Api.enc(parts[i]));
        }
        return sb.toString();
    }
}
