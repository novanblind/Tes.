package novan.terminal;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dialog kemajuan berisi persentase: penyiapan alat, pemasangan paket, dan pembangunan APK.
 * Penanda dari skrip: @@P awal akhir teks (tahap), @@S persen (kemajuan dalam tahap),
 * @@I teks (keterangan), @@T jumlah (perkiraan jumlah tugas Gradle).
 */
public class Progres {
    static final Handler H = MainActivity.H;
    static volatile boolean aktif;
    static boolean usai, ok, disembunyi, belumDilihat, updTunda, gradle, aptDaftar;
    static String judul = "", teksTahap = "", teksRinci = "", hasil = "", pesanTunda = null;
    /** Keluaran mentah proses yang sedang/baru berjalan, dipakai tombol "Salin keterangan error". */
    static final StringBuilder log = new StringBuilder();
    static int persen, lo, hi = 100, wlo, whi = 100, sub, total, nTugas, aptTotal, aptHitung, bucket = -1, stageId;
    static long t0, waktuSay;
    static Runnable ulang;
    static AlertDialog dlg;
    /** Apakah dialog yang sedang tampil dibuat saat proses sudah usai (berisi tombol Pasang APK dan Buka dengan). */
    static boolean dlgUsai;
    /** Semua APK hasil bangun Gradle (baris Salinan), untuk proyek dengan banyak flavor atau pecahan ABI. */
    static final java.util.List<String> semua = new java.util.ArrayList<>();
    /** Sudah membuka pilihan aplikasi pemasang otomatis untuk proses ini (sekali saja per proses). */
    static boolean terbukaOtomatis;
    static TextView tvT, tvP, tvR, tvW;
    static ProgressBar bar;

    static final Pattern P_SDK = Pattern.compile("^\\[[=\\s]*\\]\\s*(\\d{1,3})%\\s*(.*)$");
    static final Pattern P_PCT = Pattern.compile("(\\d{1,3})%");
    static final Pattern P_TITIK = Pattern.compile("^[.\\d%\\s]*\\d%[.\\d%\\s]*$");

    static final Runnable TICK = new Runnable() {
        @Override public void run() {
            if (dlg == null || !aktif) return;
            update();
            H.postDelayed(this, 1000);
        }
    };

    /** Memulai proses baru dan menampilkan dialog. */
    static synchronized void mulai(String j, String awal, Runnable coba) {
        aktif = true; usai = false; ok = false; disembunyi = false; belumDilihat = false; terbukaOtomatis = false;
        judul = j; teksTahap = awal; teksRinci = ""; hasil = ""; semua.clear();
        persen = 0; lo = 0; hi = 100; wlo = 0; whi = 100; sub = 0; total = 0; nTugas = 0;
        aptTotal = 0; aptHitung = 0; aptDaftar = false; gradle = false; bucket = -1; pesanTunda = null;
        t0 = SystemClock.elapsedRealtime(); waktuSay = 0; ulang = coba;
        log.setLength(0);
        H.post(Progres::render);
    }

    /** Catat satu baris keluaran proses yang sedang berjalan, untuk tombol salin keterangan error. */
    static synchronized void catat(String s) {
        if (!aktif && !usai) return;
        log.append(s).append('\n');
        if (log.length() > 50000) log.delete(0, log.length() - 50000);
    }

    /** Inti galat dari keluaran: bagian "What went wrong" Gradle, atau baris yang memuat error, atau baris terakhir. */
    static synchronized String ringkasError() {
        String[] b = log.toString().split("\n");
        StringBuilder r = new StringBuilder();
        int mulai = -1;
        for (int i = 0; i < b.length; i++) if (b[i].contains("What went wrong")) mulai = i;
        if (mulai >= 0) {
            for (int i = mulai + 1; i < b.length && i < mulai + 15; i++) {
                if (b[i].startsWith("* Try")) break;
                if (!b[i].trim().isEmpty()) r.append(b[i].trim()).append('\n');
            }
        }
        if (r.length() == 0) {
            java.util.ArrayList<String> cocok = new java.util.ArrayList<>();
            for (String l : b) {
                String x = l.toLowerCase();
                if (x.contains("error") || x.contains("exception") || x.contains("failed")) cocok.add(l.trim());
            }
            for (int i = Math.max(0, cocok.size() - 6); i < cocok.size(); i++) r.append(cocok.get(i)).append('\n');
        }
        if (r.length() == 0) {
            int dari = Math.max(0, b.length - 8);
            for (int i = dari; i < b.length; i++) if (!b[i].trim().isEmpty()) r.append(b[i].trim()).append('\n');
        }
        String t = r.toString().trim();
        return t.length() > 900 ? t.substring(0, 900) + " ..." : t;
    }

    /** Salin judul, pesan akhir, dan keluaran mentah proses terakhir ke papan klip. */
    static void salinError() {
        String teks = judul + "\n" + teksTahap + (log.length() > 0 ? "\n\n" + log : "");
        try {
            ((ClipboardManager) MainActivity.ctx.getSystemService(Context.CLIPBOARD_SERVICE))
                .setPrimaryClip(ClipData.newPlainText("error", teks));
            MainActivity.say("Keterangan error disalin");
        } catch (Exception e) {
            MainActivity.say("Gagal menyalin keterangan error");
        }
    }

    /** Semua persen berikutnya dipetakan ke rentang a..b dari total (untuk proses bertahap). */
    static synchronized void window(int a, int b) { wlo = a; whi = b; }

    static int peta(int lokal) { return wlo + (whi - wlo) * lokal / 100; }

    /** Masuk tahap baru yang mencakup persen a sampai b. */
    static synchronized void tahap(int a, int b, String teks) {
        if (!aktif) return;
        stageId++;
        lo = a; hi = b; sub = 0; teksTahap = teks; teksRinci = "";
        aptTotal = 0; aptHitung = 0; aptDaftar = false;
        persen = Math.max(persen, peta(a));
        kabar(true);
    }

    /**
     * Majukan sub-persen tahap yang sedang berjalan secara perlahan berdasarkan perkiraan waktu
     * (dalam detik), untuk langkah yang berjalan di dalam aplikasi sendiri (javac, d8, dll.) dan
     * tidak memberi tanda kemajuan sendiri sehingga tanpa ini persen akan diam total. Berhenti
     * otomatis begitu tahap() atau selesai() berikutnya dipanggil, dan tidak pernah melewati 92
     * persen dari tahap ini supaya tidak terasa "selesai" sebelum langkah sungguhan beres.
     */
    static synchronized void perkiraan(int detik) {
        if (!aktif) return;
        final int id = stageId;
        final long mulaiT = SystemClock.elapsedRealtime();
        final long totalMs = Math.max(1, detik) * 1000L;
        H.postDelayed(new Runnable() {
            @Override public void run() {
                synchronized (Progres.class) {
                    if (!aktif || id != stageId) return;
                }
                long lewat = SystemClock.elapsedRealtime() - mulaiT;
                int s = (int) Math.min(92, lewat * 92 / totalMs);
                sub(s);
                if (s < 92) H.postDelayed(this, 400);
            }
        }, 400);
    }

    /** Kemajuan 0 sampai 100 di dalam tahap yang sedang berjalan. */
    static synchronized void sub(int s) {
        if (!aktif) return;
        s = Math.max(0, Math.min(100, s));
        if (s == sub) return;
        sub = s;
        persen = Math.max(persen, peta(lo + (hi - lo) * s / 100));
        kabar(false);
    }

    static synchronized void info(String t) {
        if (!aktif) return;
        if (t.length() > 110) t = t.substring(0, 110);
        teksRinci = t;
        kabar(false);
    }

    /** Menyiapkan pengumuman untuk pembaca layar (tiap kelipatan 10 persen atau ganti tahap) dan memperbarui tampilan. */
    static void kabar(boolean ganti) {
        int bk = persen / 10;
        if (ganti || bk != bucket) {
            bucket = bk;
            long n = SystemClock.elapsedRealtime();
            if (n - waktuSay > 1500) { pesanTunda = persen + " persen. " + teksTahap; waktuSay = n; }
        }
        if (!updTunda) { updTunda = true; H.postDelayed(Progres::update, 200); }
        KeepAliveService.persen(MainActivity.ctx, persen, teksTahap);
    }

    /** Dipanggil untuk tiap baris keluaran proses. Mengembalikan true bila baris hanya penanda kemajuan (tidak perlu ditampilkan). */
    static synchronized boolean baris(String l) {
        if (!aktif || l == null) return false;
        String s = l.trim();
        if (s.isEmpty()) return false;
        if (s.startsWith("@@")) { penanda(s); return true; }
        Matcher m;
        if (s.startsWith("[") && (m = P_SDK.matcher(s)).find()) {
            sub(Integer.parseInt(m.group(1)));
            info(m.group(2));
            return true;
        }
        if (P_TITIK.matcher(s).matches()) {
            m = P_PCT.matcher(s);
            int v = -1;
            while (m.find()) v = Integer.parseInt(m.group(1));
            if (v >= 0) sub(v);
            return true;
        }
        if (s.startsWith("Salinan: ")) { hasil = s.substring(9).trim(); if (!semua.contains(hasil)) semua.add(hasil); }
        if (gradle) {
            if (s.startsWith("Downloading https://services.gradle.org") && lo <= 44) tahap(44, 52, "Mengunduh Gradle");
            else if (s.startsWith("> Configure project") && lo < 52) tahap(52, 60, "Mengonfigurasi proyek");
            else if (s.startsWith("> Task ")) {
                if (lo < 60) tahap(60, 97, "Membangun proyek");
                nTugas++;
                double f = total > 0 ? Math.min(0.99, nTugas / (double) total) : nTugas / (nTugas + 40.0);
                sub((int) (f * 100));
                String nama = s.substring(7);
                info(total > 0 ? "Tugas " + nTugas + " dari " + total + ": " + nama
                    : "Tugas " + nTugas + " (jumlah total belum diketahui, persen perkiraan): " + nama);
                return false;
            }
        }
        if (s.startsWith("The following NEW packages will be installed")) { aptDaftar = true; aptTotal = 0; aptHitung = 0; return false; }
        if (aptDaftar) {
            if (l.startsWith(" ")) { aptTotal += s.split("\\s+").length; return false; }
            aptDaftar = false;
        }
        if (aptTotal > 0 && (s.startsWith("Get:") || s.startsWith("Unpacking ") || s.startsWith("Setting up "))) {
            aptHitung++;
            sub(Math.min(99, aptHitung * 100 / (aptTotal * 3)));
        }
        info(s);
        return false;
    }

    static void penanda(String s) {
        String[] t = s.split("\\s+", 4);
        try {
            switch (t[0]) {
                case "@@P": tahap(Integer.parseInt(t[1]), Integer.parseInt(t[2]), t.length > 3 ? t[3] : ""); break;
                case "@@S": sub(Integer.parseInt(t[1])); break;
                case "@@I": info(s.substring(3).trim()); break;
                case "@@T": total = Integer.parseInt(t[1]); gradle = true; break;
                default: break;
            }
        } catch (Exception e) { }
    }

    /** Menutup proses: berhasil (100 persen) atau gagal, dengan pesan akhir. */
    static synchronized void selesai(boolean berhasil, String pesan) {
        if (!aktif) return;
        stageId++;
        aktif = false; usai = true; ok = berhasil; disembunyi = false; belumDilihat = true;
        if (berhasil) persen = 100;
        teksTahap = pesan; teksRinci = "";
        pesanTunda = (berhasil ? "Selesai. " : "Gagal. ") + pesan;
        if (berhasil) H.post(Progres::render);
        else H.post(() -> {
            String e = ringkasError();
            synchronized (Progres.class) { teksRinci = e; }
            render();
        });
    }

    /** Tombol Lihat kemajuan: membuka dialog proses yang berjalan atau hasil terakhir. */
    static void buka() {
        H.post(() -> {
            if (judul.isEmpty()) {
                MainActivity.say(Pkg.sudahSiap() ? "Tidak ada proses berjalan. Alat sudah siap." : "Tidak ada proses berjalan. Alat belum siap. Ketik: siap");
                return;
            }
            disembunyi = false;
            render();
        });
    }

    /** Dipanggil saat aplikasi kembali tampil: munculkan lagi dialog bila perlu. */
    static void pulihkan() {
        H.post(() -> {
            // Dialog lama yang dibuat saat proses masih berjalan harus diganti bila proses sudah usai,
            // supaya tombol Pasang APK dan Buka dengan muncul.
            if (dlg != null) { if (usai && !dlgUsai) render(); return; }
            if ((aktif && !disembunyi) || (usai && belumDilihat)) render();
        });
    }

    /** Dipanggil saat aktivitas dihancurkan. */
    static void lepas() {
        AlertDialog d = dlg;
        dlg = null;
        if (d != null) try { d.dismiss(); } catch (Exception e) { }
    }

    static void render() {
        MainActivity a = MainActivity.front;
        if (a == null || !MainActivity.visible) return;
        lepas();
        float d = a.getResources().getDisplayMetrics().density;
        int p = (int) (20 * d);
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(p, p, p, p);
        tvT = new TextView(a); tvT.setTextSize(18);
        tvP = new TextView(a); tvP.setTextSize(28);
        bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        tvR = new TextView(a); tvR.setTextSize(14);
        tvW = new TextView(a); tvW.setTextSize(14);
        l.addView(tvT); l.addView(tvP); l.addView(bar); l.addView(tvR); l.addView(tvW);
        if (usai) belumDilihat = false;
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.addView(l);
        AlertDialog.Builder b = new AlertDialog.Builder(a).setTitle(judul).setView(sv);
        if (!usai) b.setNegativeButton("Sembunyikan, proses tetap berjalan", (x, w) -> { disembunyi = true; });
        else {
            final String apk = ok && hasil.toLowerCase().endsWith(".apk") && new File(hasil).isFile() ? hasil : null;
            if (apk != null) {
                b.setPositiveButton("Pasang APK", (x, w) -> Pasang.pasang(a, apk, false));
                b.setNeutralButton("Pilih pemasang...", (x, w) -> Pasang.pasang(a, apk, true));
                b.setNegativeButton("Tutup", null);
                if (!terbukaOtomatis) {
                    // APK selesai dibangun: pakai pemasang yang sudah diingat; kalau belum ada, tampilkan pilihan (ada kotak Jangan tanyakan lagi).
                    terbukaOtomatis = true;
                    H.postDelayed(() -> {
                        MainActivity f = MainActivity.front;
                        if (f != null && MainActivity.visible) Pasang.pasang(f, apk, false);
                    }, 400);
                }
            } else b.setPositiveButton("Tutup", null);
            if (!ok && ulang != null) b.setNeutralButton("Coba lagi", (x, w) -> { Runnable r = ulang; if (r != null) r.run(); });
            if (!ok) b.setNegativeButton("Salin error", (x, w) -> salinError());
        }
        b.setOnDismissListener(x -> { if (dlg == x) { dlg = null; if (!usai) disembunyi = true; } });
        dlg = b.create();
        dlgUsai = usai;
        dlg.show();
        update();
        H.removeCallbacks(TICK);
        H.postDelayed(TICK, 1000);
    }

    static String fmt(long dt) {
        return dt >= 60 ? (dt / 60) + " menit " + (dt % 60) + " detik" : dt + " detik";
    }

    static void update() {
        String say, t, r;
        int pr;
        boolean selesaiNow;
        long dt;
        synchronized (Progres.class) {
            updTunda = false;
            say = pesanTunda; pesanTunda = null;
            t = teksTahap; r = teksRinci; pr = persen; selesaiNow = usai;
            dt = (SystemClock.elapsedRealtime() - t0) / 1000;
        }
        if (dlg == null || tvT == null) {
            if (say != null) MainActivity.say(say);
            return;
        }
        if (selesaiNow && !dlgUsai && MainActivity.front != null && MainActivity.visible) {
            // Proses usai tetapi dialog masih versi berjalan: bangun ulang agar tombol hasil muncul.
            render();
            if (say != null && tvT != null) tvT.announceForAccessibility(say);
            return;
        }
        tvT.setText(t);
        tvP.setText(pr + " persen");
        bar.setProgress(pr);
        tvR.setText(r);
        tvW.setText((selesaiNow ? "Total waktu " : "Berjalan ") + fmt(dt));
        if (say != null) tvT.announceForAccessibility(say);
    }
}
