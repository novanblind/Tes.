package com.novan.penghilangvokal;

/**
 * Bagian pemrosesan sinyal untuk MDX-Net (UVR): STFT dan iSTFT yang sama dengan torch.stft /
 * torch.istft (jendela Hann periodik, center=true dengan bantalan pantulan, tanpa normalisasi).
 *
 * Ukuran FFT 6144 = 3 x 2048, jadi dipakai FFT campuran radix-3 dan radix-2. Kiri dan kanan
 * dikerjakan sekaligus dalam satu FFT kompleks (kiri = bagian nyata, kanan = bagian khayal).
 * Kelas ini tidak aman dipakai dari beberapa utas sekaligus.
 */
final class MdxDsp {

    static final int N_FFT = 6144;
    static final int HOP = 1024;
    /** Jumlah bin frekuensi yang dimasukkan ke model (bin ke-3072 / Nyquist dibuang). */
    static final int DIM_F = 3072;
    /** Jumlah bingkai waktu per potongan. */
    static final int DIM_T = 256;
    /** Panjang satu potongan masukan (sampel per kanal). */
    static final int CHUNK = HOP * (DIM_T - 1);
    /** Konteks di kiri dan kanan potongan yang dibuang dari hasil. */
    static final int TRIM = N_FFT / 2;
    /** Sampel hasil yang dipakai dari satu potongan. */
    static final int GEN = CHUNK - 2 * TRIM;

    private static final int OLA = N_FFT + HOP * (DIM_T - 1);

    private final double[] win = new double[N_FFT];
    private final double[] env = new double[OLA];
    private final double[] zr = new double[N_FFT];
    private final double[] zi = new double[N_FFT];
    private final double[] olaL = new double[OLA];
    private final double[] olaR = new double[OLA];
    private final Fft fft = new Fft(N_FFT);

    MdxDsp() {
        for (int i = 0; i < N_FFT; i++) {
            win[i] = 0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / N_FFT);
        }
        for (int t = 0; t < DIM_T; t++) {
            for (int i = 0; i < N_FFT; i++) env[t * HOP + i] += win[i] * win[i];
        }
    }

    /**
     * @param l kiri, panjang CHUNK
     * @param r kanan, panjang CHUNK
     * @param spec keluaran, panjang 4 * DIM_F * DIM_T; urutan bidang [L nyata, L khayal, R nyata,
     *             R khayal], indeks ((bidang * DIM_F) + bin) * DIM_T + bingkai
     */
    void stft(float[] l, float[] r, float[] spec) {
        for (int t = 0; t < DIM_T; t++) {
            for (int i = 0; i < N_FFT; i++) {
                int idx = t * HOP + i - TRIM;
                if (idx < 0) idx = -idx;
                if (idx >= CHUNK) idx = 2 * (CHUNK - 1) - idx;
                zr[i] = l[idx] * win[i];
                zi[i] = r[idx] * win[i];
            }
            fft.fft(zr, zi);
            for (int k = 0; k < DIM_F; k++) {
                int bk = k == 0 ? 0 : N_FFT - k;
                double ar = zr[k], ai = zi[k], br = zr[bk], bi = zi[bk];
                int o = k * DIM_T + t;
                spec[o] = (float) ((ar + br) * 0.5);
                spec[DIM_F * DIM_T + o] = (float) ((ai - bi) * 0.5);
                spec[2 * DIM_F * DIM_T + o] = (float) ((ai + bi) * 0.5);
                spec[3 * DIM_F * DIM_T + o] = (float) ((br - ar) * 0.5);
            }
        }
    }

    /** Kebalikan stft: bin DIM_F ke atas dianggap nol. Keluaran l dan r sepanjang CHUNK. */
    void istft(float[] spec, float[] l, float[] r) {
        java.util.Arrays.fill(olaL, 0.0);
        java.util.Arrays.fill(olaR, 0.0);
        final int pl = DIM_F * DIM_T;
        for (int t = 0; t < DIM_T; t++) {
            for (int k = 0; k <= N_FFT / 2; k++) {
                double lr = 0, li = 0, rr = 0, ri = 0;
                if (k < DIM_F) {
                    int o = k * DIM_T + t;
                    lr = spec[o];
                    li = spec[pl + o];
                    rr = spec[2 * pl + o];
                    ri = spec[3 * pl + o];
                }
                if (k == 0) { li = 0; ri = 0; }
                zr[k] = lr - ri;
                zi[k] = li + rr;
                if (k > 0 && k < N_FFT / 2) {
                    int j = N_FFT - k;
                    zr[j] = lr + ri;
                    zi[j] = rr - li;
                }
            }
            fft.fft(zi, zr);   // kebalikan FFT: tukar bagian nyata dan khayal
            final double sk = 1.0 / N_FFT;
            final int base = t * HOP;
            for (int i = 0; i < N_FFT; i++) {
                olaL[base + i] += zr[i] * sk * win[i];
                olaR[base + i] += zi[i] * sk * win[i];
            }
        }
        for (int j = 0; j < CHUNK; j++) {
            double e = env[TRIM + j];
            l[j] = (float) (olaL[TRIM + j] / e);
            r[j] = (float) (olaR[TRIM + j] / e);
        }
    }

    /** FFT kompleks maju berukuran 3 x 2^k (di tempat). */
    static final class Fft {
        private final int n, m;
        private final int[] rev;
        private final double[] c2, s2;      // W_m^j
        private final double[] cn, sn;      // W_n^j untuk j < 2m
        private final double[][] pr = new double[3][], pi = new double[3][];

        Fft(int n) {
            if (n % 3 != 0 || Integer.bitCount(n / 3) != 1) throw new IllegalArgumentException("ukuran FFT harus 3 x 2^k");
            this.n = n;
            this.m = n / 3;
            rev = new int[m];
            int bits = Integer.numberOfTrailingZeros(m);
            for (int i = 0; i < m; i++) rev[i] = bits == 0 ? 0 : Integer.reverse(i) >>> (32 - bits);
            c2 = new double[m];
            s2 = new double[m];
            for (int j = 0; j < m; j++) {
                c2[j] = Math.cos(2.0 * Math.PI * j / m);
                s2[j] = -Math.sin(2.0 * Math.PI * j / m);
            }
            cn = new double[2 * m];
            sn = new double[2 * m];
            for (int j = 0; j < 2 * m; j++) {
                cn[j] = Math.cos(2.0 * Math.PI * j / n);
                sn[j] = -Math.sin(2.0 * Math.PI * j / n);
            }
            for (int q = 0; q < 3; q++) {
                pr[q] = new double[m];
                pi[q] = new double[m];
            }
        }

        private void fft2(double[] re, double[] im) {
            for (int i = 0; i < m; i++) {
                int j = rev[i];
                if (j > i) {
                    double t = re[i]; re[i] = re[j]; re[j] = t;
                    t = im[i]; im[i] = im[j]; im[j] = t;
                }
            }
            for (int len = 2; len <= m; len <<= 1) {
                int half = len >> 1, step = m / len;
                for (int i = 0; i < m; i += len) {
                    for (int k = 0; k < half; k++) {
                        double wr = c2[k * step], wi = s2[k * step];
                        int a = i + k, b = a + half;
                        double tr = re[b] * wr - im[b] * wi;
                        double ti = re[b] * wi + im[b] * wr;
                        re[b] = re[a] - tr;
                        im[b] = im[a] - ti;
                        re[a] += tr;
                        im[a] += ti;
                    }
                }
            }
        }

        void fft(double[] re, double[] im) {
            for (int j = 0; j < m; j++) {
                for (int q = 0; q < 3; q++) {
                    pr[q][j] = re[3 * j + q];
                    pi[q][j] = im[3 * j + q];
                }
            }
            for (int q = 0; q < 3; q++) fft2(pr[q], pi[q]);
            final double s = Math.sqrt(3.0) / 2.0;
            for (int k = 0; k < m; k++) {
                double t0r = pr[0][k], t0i = pi[0][k];
                double w1r = cn[k], w1i = sn[k], w2r = cn[2 * k], w2i = sn[2 * k];
                double t1r = pr[1][k] * w1r - pi[1][k] * w1i, t1i = pr[1][k] * w1i + pi[1][k] * w1r;
                double t2r = pr[2][k] * w2r - pi[2][k] * w2i, t2i = pr[2][k] * w2i + pi[2][k] * w2r;
                re[k] = t0r + t1r + t2r;
                im[k] = t0i + t1i + t2i;
                // W3 = (-0,5; -s), W3^2 = (-0,5; +s)
                re[k + m] = t0r + (-0.5 * t1r + s * t1i) + (-0.5 * t2r - s * t2i);
                im[k + m] = t0i + (-s * t1r - 0.5 * t1i) + (s * t2r - 0.5 * t2i);
                re[k + 2 * m] = t0r + (-0.5 * t1r - s * t1i) + (-0.5 * t2r + s * t2i);
                im[k + 2 * m] = t0i + (s * t1r - 0.5 * t1i) + (-s * t2r - 0.5 * t2i);
            }
        }
    }
}
