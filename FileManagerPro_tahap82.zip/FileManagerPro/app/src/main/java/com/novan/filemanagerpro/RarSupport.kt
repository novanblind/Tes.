package com.novan.filemanagerpro

import android.content.Context
import com.github.junrar.Archive
import me.zhanghai.android.libarchive.Archive as LaArchive
import me.zhanghai.android.libarchive.ArchiveEntry as LaEntry
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

/** Dukungan baca RAR lewat pustaka junrar (dipisah agar mudah diganti bila perlu). */
/** Arsip butuh kata sandi (atau kata sandi yang diberikan salah). */
class PasswordRequired(msg: String, val wrong: Boolean) : java.io.IOException(msg)

object RarSupport {

        

    private val SIG5 = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00)
    private val SIG4 = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00)

    /** Versi RAR dari tanda tangan berkas: 5, 4 (RAR 1.5-4.x), atau 0 bila bukan RAR. */
    fun version(f: File): Int = try {
        val b = ByteArray(8)
        val n = FileInputStream(f).use { it.read(b) }
        when {
            n >= 8 && b.contentEquals(SIG5) -> 5
            n >= 7 && b.copyOf(7).contentEquals(SIG4) -> 4
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    fun walk(c: Context, f: File, visit: (ArchiveOps.ArchEntry, () -> InputStream) -> Boolean) {
        val v = version(f)
        if (v == 5) {
            walkV5(c, f, visit)
            return
        }
        if (v == 0) throw java.io.IOException(c.getString(R.string.rar_not_valid))
        val pw = ArchiveOps.passwords[f.absolutePath]
        try {
            walkV4(c, f, pw, visit)
        } catch (e: com.github.junrar.exception.RarException) {
            val m = e.javaClass.simpleName + " " + (e.message ?: "")
            if (m.contains("ncrypt", true) || m.contains("password", true)) {
                throw PasswordRequired(c.getString(R.string.rar_encrypted), pw != null)
            }
            throw java.io.IOException(
                c.getString(if (m.contains("V5")) R.string.rar5_unsupported else R.string.rar_not_valid), e
            )
        }
    }

    /** RAR5 lewat libarchive (hanya baca). Data entri dibaca berurutan langsung dari arsip. */
    private fun walkV5(c: Context, f: File, visit: (ArchiveOps.ArchEntry, () -> InputStream) -> Boolean) {
        val ar = try {
            LaArchive.readNew()
        } catch (e: Throwable) {
            throw java.io.IOException(c.getString(R.string.rar5_unsupported), e)
        }
        try {
            val buf = java.nio.ByteBuffer.allocateDirect(65536)
            LaArchive.readSupportFilterAll(ar)
            LaArchive.readSupportFormatAll(ar)
            LaArchive.readOpenFileName(ar, f.absolutePath.toByteArray(Charsets.UTF_8), 65536L)
            while (true) {
                val e = LaArchive.readNextHeader(ar)
                if (e == 0L) break
                val raw = LaEntry.pathnameUtf8(e)
                    ?: LaEntry.pathname(e)?.toString(Charsets.UTF_8) ?: continue
                val name = raw.replace('\\', '/').trim('/')
                if (name.isEmpty()) continue
                val isDir = LaEntry.filetype(e) == LaEntry.AE_IFDIR
                val size = if (LaEntry.sizeIsSet(e)) LaEntry.size(e) else -1L
                val time = if (LaEntry.mtimeIsSet(e)) LaEntry.mtime(e) * 1000L else 0L
                if (!isDir && LaEntry.isEncrypted(e)) {
                    throw java.io.IOException(c.getString(R.string.rar5_encrypted))
                }
                val cont = visit(ArchiveOps.ArchEntry(name, isDir, size, time)) {
                    object : InputStream() {
                        private var done = false
                        private val one = ByteArray(1)
                        override fun read(): Int {
                            val n = read(one, 0, 1)
                            return if (n <= 0) -1 else one[0].toInt() and 0xFF
                        }
                        override fun read(b: ByteArray, off: Int, len: Int): Int {
                            if (done) return -1
                            if (len == 0) return 0
                            buf.clear()
                            if (len < buf.capacity()) buf.limit(len)
                            LaArchive.readData(ar, buf)
                            val n = buf.position()
                            if (n <= 0) {
                                done = true
                                return -1
                            }
                            buf.flip()
                            buf.get(b, off, n)
                            return n
                        }
                    }
                }
                if (!cont) break
            }
        } catch (e: java.io.IOException) {
            val m = e.message ?: ""
            if (e is me.zhanghai.android.libarchive.ArchiveException &&
                (m.contains("passphrase", true) || m.contains("encrypt", true))
            ) throw java.io.IOException(c.getString(R.string.rar5_encrypted), e)
            throw e
        } finally {
            try { LaArchive.free(ar) } catch (e: Throwable) { /* abaikan */ }
        }
    }

    private fun walkV4(c: Context, f: File, pw: String?, visit: (ArchiveOps.ArchEntry, () -> InputStream) -> Boolean) {
        (if (pw == null) Archive(f) else Archive(f, pw)).use { a ->
            for (fh in a.fileHeaders) {
                if (pw == null && fh.isEncrypted) throw PasswordRequired(c.getString(R.string.rar_encrypted), false)
                val name = (fh.fileName ?: continue).replace('\\', '/').trim('/')
                if (name.isEmpty()) continue
                val time = try { fh.getMTime()?.time ?: 0L } catch (e: Exception) { 0L }
                val entry = ArchiveOps.ArchEntry(name, fh.isDirectory, fh.fullUnpackSize, time)
                val cont = visit(entry) {
                    val tmp = File.createTempFile("rar", ".tmp", c.cacheDir)
                    FileOutputStream(tmp).use { out -> a.extractFile(fh, out) }
                    object : FileInputStream(tmp) {
                        override fun close() {
                            super.close()
                            tmp.delete()
                        }
                    }
                }
                if (!cont) break
            }
        }
    }
}
