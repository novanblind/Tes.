# TalkBack Novan

Pembaca layar Android buatan Novan. Paket: `com.novan.talkbacknovan`.
Kode ditulis baru (Java, tanpa dependensi luar), terinspirasi fitur Jieshuo Lite.

## Membangun APK (tanpa Android Studio)
1. Unggah isi folder ini ke repo GitHub.
2. Buka tab Actions, jalankan "Bangun APK" (otomatis saat push).
3. Unduh artefak `TalkBackNovan` (berisi `TalkBackNovan.apk`).
APK memakai kunci tanda tangan tetap `app/novan.jks`, sehingga bisa dipasang sebagai pembaruan.
minSdk 30, targetSdk 36. Tidak ada kode native, jadi satu APK berjalan di 32-bit dan 64-bit.

## Tahap 1
- Layanan aksesibilitas dengan mode jelajah sentuh
- Ucapan: fokus, jendela/dialog, status sakelar, notifikasi dan toast, live region
- Gema ketikan (karakter/kata), pembacaan kursor
- Gestur: geser kanan/kiri, beranda, kembali, aplikasi terbaru, notifikasi, ketuk dua jari = diam
- Pengaturan: kecepatan, nada, pilihan mesin TTS, umpan balik, getar

## Tahap 2 (ini)
- Granularitas: geser bawah/atas mengganti cara pindah. Pilihan: item, judul, tautan, tombol,
  kolom isian, kotak centang dan sakelar, gambar, karakter, kata, kalimat, paragraf.
  Geser kanan/kiri lalu pindah menurut pilihan itu (per teks juga menggeser kursor di kolom isian).
- Gestur dua jari (bisa diganti di Pengaturan): usap atas = gulir maju, bawah = gulir mundur,
  kiri = halaman berikutnya, kanan = halaman sebelumnya, ketuk dua kali = baca seluruh layar.
- Gestur tiga jari (bisa diganti): ketuk = jam dan baterai, atas = pengaturan cepat,
  bawah = notifikasi, kiri = ulangi ucapan terakhir, kanan = baca dari item ini.
- Tombol volume: tekan lama volume atas = ketuk elemen terfokus, volume bawah = baca dari item ini
  (bisa diganti atau dimatikan). Tekan singkat tetap mengatur volume.
- Ucapan posisi saat daftar digulir ("item 5 sampai 10 dari 30").
- Ada 22 aksi yang bisa dipasang ke gestur/tombol (lihat `Aksi.java`).

## Tahap 3 (ini)
- Pendengar notifikasi: membaca nama aplikasi, judul, dan isi (aktifkan lewat tombol "Beri akses notifikasi"); toast tetap dibaca lewat layanan aksesibilitas
- Daftar hitam notifikasi dan daftar hitam bacaan otomatis (perubahan isi, gulir, pengumuman) per aplikasi
- Ganti nama elemen: aksi "Ganti nama elemen terfokus" (pasang ke gestur/tombol) atau ubah aturan di Pengaturan

## Tahap 4 (ini)
- Salin, tempel, potong, dan pilih semua teks (aksi yang bisa dipasang ke gestur/tombol)
- Menu elemen terfokus (bawaan: ketuk dua kali tiga jari): ketuk, ketuk lama, salin, tempel, aksi khusus aplikasi, baca dari sini, ganti nama
- Mode baca: aksi "Tampilkan teks layar" membuka halaman berisi seluruh teks layar, bisa dijelajahi per karakter/kata/paragraf, disalin, atau dibagikan

## Tahap 5 (ini)
- OCR memakai Gemini dan Groq lewat API (tanpa pustaka tambahan, butuh internet dan kunci API sendiri)
- Aksi "OCR seluruh layar" dan "OCR elemen terfokus" (pasang ke gestur/tombol; OCR elemen juga ada di menu elemen)
- Bagikan gambar dari aplikasi lain ke "OCR TalkBack Novan" untuk mengenali teksnya
- Mesin utama bisa dipilih; bila gagal, mesin lain dicoba otomatis. Nama model bisa diubah di Pengaturan
  (bawaan: gemini-2.5-flash dan qwen/qwen3.8-27b)

## Tahap 6 (ini)
- Perintah suara (bawaan: ketuk empat jari): memakai pengenal suara bawaan sistem. Contoh: "beranda", "kembali",
  "aplikasi terbaru", "notifikasi", "baca layar", "baca dari sini", "salin", "tempel", "gulir ke bawah",
  "berikutnya", "ocr", "menu", "jam", "buka WhatsApp" (membuka aplikasi menurut nama)
- Gestur kustom: 12 kombinasi usapan satu jari, ketuk tiga kali dua/tiga/empat jari, ketuk satu/dua kali dan usap empat jari,
  semuanya bisa diberi aksi apa pun di Pengaturan (sebelumnya empat kombinasi tertanam: beranda, kembali, terbaru, notifikasi)

## Tahap 7 (ini)
- Efek suara buatan kode (tanpa berkas audio): fokus, ketuk, ketuk lama, ganti jendela, gulir, batas daftar, salin. Volume dan sakelar di Pengaturan
- Kecilkan audio lain saat berbicara (audio focus)
- Berhenti bicara saat sensor jarak tertutup, dan saat layar disentuh (keduanya opsional)
- Volume ucapan terpisah, kekuatan dan lama getar bisa diatur

## Tahap 8 (ini)
- Tombol volume: tekan dua/tiga kali (atas dan bawah) bisa diberi aksi. Tanpa aksi, volume tetap berubah seperti biasa
- Tombol headset: klik, klik dua kali, tahan (aktifkan di Pengaturan)
- Aksi baru: percepat/perlambat bicara, tangkapan layar, menu daya, bisukan suara, salin ucapan terakhir, baca papan klip

## Tahap 8b (ini): tema suara
- Tema suara memakai berkas suara yang sama dengan JieShuo Lite (res/raw): fokus 0-4, klik, klik lama, ganti jendela, gulir atas/bawah, beep (akhir daftar), batal (kembali)
- Pemilihan suara fokus mengikuti aslinya: tombol/centang/isian = fokus1, papan ketik = fokus3, lainnya = fokus2; ganti granularitas = fokus0
- Belum ada: fokus4 (area tak terfokus), gestur tepi, tik/jam (menunggu timer), paket tema suara kustom

## Tahap 9 (ini): emoji Indonesia dan menu pengaturan bertingkat
- Emoji dibacakan dengan nama bahasa Indonesia dari `assets/emoji_id.txt` (3988 entri, termasuk warna kulit dan gabungan ZWJ; pencocokan terpanjang dulu). Sakelar di Pengaturan pengucapan konten (bawaan aktif)
- Pengaturan dibuat bertingkat seperti JieShuo Lite: Pengaturan umum, teks ke ucapan, umpan balik, tindakan (gestur satu/dua/tiga jari, volume, headset), pengucapan konten, pemberitahuan, lanjutan (OCR, metode masukan), aksesibilitas, bantuan
- Belum ada: Cari pengaturan, profil per aplikasi, plugin, gestur tepi dan multipart

## Tahap 10 (ini): ekstensi (plugin Lua)
- Menu Pengaturan > Ekstensi: buat plugin baru (tulis/tempel kode), pasang dari berkas .lua atau .zip, jalankan, hentikan, jalan otomatis saat layanan aktif, ubah kode, lihat catatan dan galat, hapus
- Plugin = folder berisi `main.lua` di `Android/data/com.novan.talkbacknovan/files/plugin/NAMA/` (bisa memakai `require` untuk berkas lain di folder itu)
- Mesin Lua: LuaJ (Lua 5.2, Java murni, dependensi `org.luaj:luaj-jse:3.0.1`). Tidak ada pustaka native
- Jembatan Lua-Java bergaya AndroLua (`LuaJava.java`): `import "android.widget.*"`, `require "import"`, kelas Java dipanggil seperti fungsi, metode boleh dipanggil dengan titik atau titik dua, properti lewat getX/setX/isX, fungsi atau tabel Lua otomatis menjadi pendengar/antarmuka Java (misalnya `View.OnClickListener{onClick=function(v) end}`), larik 0-based
- Objek global: `service` dan `this` (layanan itu sendiri, jadi semua metode AccessibilityService ikut tersedia), `print` (dicatat dan ditampilkan sebagai toast), `Http` (get/post tak sinkron: callback(kode, isi, cookie, header)), modul `cjson` dan `json` (encode/decode)
- Metode `service` bernama sama dengan JieShuo: speak, rawSpeak, asyncSpeak, appendSpeak, asyncAppendSpeak, stop, asyncStop, allStop, isSpeaking, getLastSpeakText, getAllText, isScreenOn, getBatteryLevel
- Fungsi pengait yang dipanggil bila ada di skrip: `onCreate()`, `onDestroy()`, `onAccessibilityEvent(event)`, `onSpeak(teks)` (kembalikan string untuk mengganti ucapan, atau true untuk membatalkan), `onKeyEvent(event)` (kembalikan true untuk menelan tombol)
- Belum ada: ratusan metode `service` lain milik JieShuo (ditambah sesuai plugin yang dipakai), Lua 5.3 (operator `//`, `&`, bilangan bulat 64-bit), `LuaThread`/`task`/`timer`, `LuaActivity`/layout .aly, ekstensi per aplikasi

## Tahap 11: layar utama ala JieShuo dan gestur bawaan ala JieShuo
- Layar utama kini daftar menu gelap seperti JieShuo: Cari, Pengaturan umum, teks ke ucapan, umpan balik, tindakan, pengucapan konten, pemberitahuan, lanjutan, Ekstensi, Plugin dan peralatan, Pengaturan lainnya
- Cari: ketik kata, hasil berasal dari semua halaman pengaturan, ketuk hasil untuk membuka halamannya
- Status layanan, tombol pengaturan aksesibilitas, dan bantuan dipindah ke Pengaturan lainnya; uji suara dan akses notifikasi ke Plugin dan peralatan
- Gestur satu jari bawaan: kiri = item sebelumnya, kanan = item berikutnya, atas/bawah = fungsi pintas (granularitas). Sakelar "Usap kiri/kanan pindah fokus" di Gestur satu jari; bila mati: atas/bawah pindah item, kiri/kanan menurut konteks
- Dua usapan bawaan: atas-bawah fokus terakhir, bawah-atas fokus pertama, kiri-kanan aplikasi terbaru, kanan-kiri kembali, atas-kanan menu tindakan, bawah-kanan menu utama, atas-kiri ekstensi, bawah-kiri perintah suara, kiri-bawah mode per karakter, kanan-atas baca otomatis, kiri-atas notifikasi, kanan-bawah daftar elemen
- Banyak jari bawaan: dua jari ketuk dua kali = putar/jeda media; tiga jari bawah = notifikasi, atas = beranda, kiri = terbaru, kanan = pengaturan cepat, ketuk dua kali = baca otomatis; empat jari bawah = fokus terakhir, atas = fokus pertama, kiri = matikan/nyalakan gestur banyak jari, kanan = ketuk dua kali, ketuk dua kali = mode baca
- Empat usapan satu jari kini bisa diberi aksi lain di Pengaturan tindakan; 10 aksi baru
- Sakelar "Jelajah menurut jenis navigasi di semua tampilan" (bawaan aktif): usap atas/bawah ganti jenis navigasi, kiri/kanan pindah item menurut jenis itu, di semua tampilan
- Pengaturan umum disusun seperti JieShuo: Panduan, kecepatan, volume, baca petunjuk penggunaan (baru, bawaan aktif), baca daftar item, baca pemberitahuan, gerakan kiri/kanan 1 jari, pengaturan gerakan
- Pengaturan teks ke ucapan disusun seperti JieShuo: mesin, pengaturan TTS sistem, kecepatan, volume, nada, pengecilan audio (kini bawaan mati), sensor kedekatan, sentuh layar. Tidak dibuat: mesin TTS tunggal, kecepatan teks ke suara, volume aksesibilitas (sudah selalu dipakai), wake lock
- Belum ada: Unduh fitur tambahan, gestur kiri/kanan khusus dialog (batal/oke), mode per karakter hanya kiri/kanan dan atas/bawah

## Tahap 12: Pengaturan umpan balik ala JieShuo
- Urutan: umpan balik suara, volume tema suara (bawaan 60), aplikasi yang tidak memakai efek suara (baru), umpan balik getaran, intensitas getaran (bawaan 32), lama getaran
- Efek suara diam di aplikasi yang dipilih
- Belum ada: pilihan tema suara, kelola dan unduh tema suara

## Tahap 13 (ini): Pengaturan tindakan ala JieShuo
- Menu: Pengaturan Gestur Default, Pengaturan gerakan, Deskripsi gerakan, Kelola gerakan, Pengaturan tombol pintasan
- Gestur Default: jelajah menurut jenis navigasi, tetap pada jenis navigasi saat jendela berubah (baru, bawaan mati), gerakan alternatif (kursor di kolom isian, penggeser, gulir daftar, gerakan multi jari; semua bawaan aktif)
- Deskripsi gerakan: daftar semua gestur dan aksinya. Kelola gerakan: kembalikan semua gestur ke bawaan
- Tombol pintasan: volume dan headset digabung dalam satu halaman
- Belum ada: tema gerakan, mode permainan, pengaturan pengguliran, pengaturan tindakan ketuk, tombol pintasan buatan, sidik jari, goyang, gerakan tepi layar, multipart

## Usulan tahap berikutnya
9. Baca otomatis pesan chat per aplikasi, info penelepon, jam bicara dan timer, aturan ucapan (regex, simbol, emoji)
10. Mode edit lanjutan, terjemahan, deskripsi gambar otomatis
11. Profil per aplikasi, pencadangan pengaturan, log
