package com.novan.githubbynovan;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.security.MessageDigest;
import java.util.Random;

/**
 * Penjaga tanda tangan (dibuat otomatis oleh GitHub by novan).
 * Jika APK ditandatangani ulang dengan kunci lain, sidik jari sertifikat tidak cocok
 * dan aplikasi langsung ditutup. Pengecekan berjalan di beberapa titik:
 * saat aplikasi mulai, setiap layar tampil, secara berkala, dan dari MainActivity.
 * Sidik jari disimpan terpecah (dua bagian yang di-XOR), bukan sebagai teks utuh.
 * Penjaga hanya aktif bila APK dibangun dengan tanda tangan pribadi.
 */
public class TTGuard extends ContentProvider {
    // Diisi otomatis oleh alur kerja GitHub Actions saat membangun dengan tanda tangan pribadi.
    private static final String A = "__TT_A__";
    private static final String B = "__TT_B__";
    private static final String KOSONG = "__TT" + "_A__";
    private static volatile boolean terpasang;

    private static boolean aktif() {
        return !KOSONG.equals(A);
    }

    @Override
    public boolean onCreate() {
        if (!aktif()) return true; // bukan tanda tangan pribadi: penjaga tidak aktif
        Context c = getContext();
        periksa(c);
        pasangPengawas(c);
        return true;
    }

    /** Titik pengecekan: dipanggil dari provider, siklus layar, jadwal berkala, dan MainActivity. */
    public static void periksa(Context c) {
        if (!aktif()) return;
        boolean ok = false;
        try {
            ok = cocok(c);
        } catch (Throwable ignored) { }
        if (!ok) tutup(c);
    }

    private static void pasangPengawas(final Context c) {
        if (terpasang) return;
        terpasang = true;
        try {
            Context ctx = c.getApplicationContext();
            if (ctx == null) ctx = c;
            if (ctx instanceof Application) {
                ((Application) ctx).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityCreated(Activity a, Bundle b) { periksa(a); }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityResumed(Activity a) { periksa(a); }
                    @Override public void onActivityPaused(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
            }
            final Context app = ctx;
            final Handler h = new Handler(Looper.getMainLooper());
            final Random r = new Random();
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    periksa(app);
                    h.postDelayed(this, 30000L + r.nextInt(60000));
                }
            }, 20000L + r.nextInt(20000));
        } catch (Throwable ignored) { }
    }

    private static byte[] hex(String s) {
        int n = s.length() / 2;
        byte[] o = new byte[n];
        for (int i = 0; i < n; i++) {
            o[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        }
        return o;
    }

    private static byte[] harapan() {
        byte[] x = hex(A);
        byte[] y = hex(B);
        byte[] o = new byte[x.length];
        for (int i = 0; i < o.length; i++) o[i] = (byte) (x[i] ^ y[i % y.length]);
        return o;
    }

    private static boolean cocok(Context c) throws Exception {
        PackageManager pm = c.getPackageManager();
        String pkg = c.getPackageName();
        Signature[] sigs;
        if (Build.VERSION.SDK_INT >= 28) {
            PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES);
            SigningInfo si = pi.signingInfo;
            if (si == null) return false;
            sigs = si.getApkContentsSigners();
        } else {
            PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES);
            sigs = pi.signatures;
        }
        if (sigs == null || sigs.length == 0) return false;
        byte[] h = harapan();
        for (Signature s : sigs) {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray());
            if (!MessageDigest.isEqual(d, h)) return false;
        }
        return true;
    }

    private static void tutup(Context c) {
        try {
            if (c instanceof Activity) ((Activity) c).finishAffinity();
        } catch (Throwable ignored) { }
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(10);
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
