package com.novan.pisahsuara

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.Executors

class RoutingService : Service() {
    @Volatile private var exec = Executors.newSingleThreadExecutor()
    private lateinit var am: AudioManager
    private var lastKeys: Set<String>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sedangTerapkan = java.util.concurrent.atomic.AtomicBoolean(false)

    @Volatile private var jeda = 15000L

    /**
     * Penjaga hemat baterai: periksa tiap 30 detik saat sehat. Bila gagal, jeda digandakan sampai 1 menit
     * (tidak memindai terus-menerus). Saat Wi-Fi tersambung, jeda dikembalikan dan pemeriksaan langsung dilakukan.
     */
    private val jaga = object : Runnable {
        override fun run() {
            // Pengawas: apply yang menggantung > 60 detik ditinggalkan (thread baru), supaya antrean tidak macet selamanya.
            val mulai = AudioRouter.mulaiApply
            if (lama() || (mulai != 0L && System.currentTimeMillis() - mulai > 60000)) {
                try { exec.shutdownNow() } catch (_: Throwable) {}
                exec = Executors.newSingleThreadExecutor()
                sedangTerapkan.set(false); terapkanSejak = 0L
            }
            exec.execute {
                try {
                    if (Rules.active(this@RoutingService) && !sedangTerapkan.get()) {
                        if (AudioRouter.sehat(this@RoutingService)) {
                            jeda = 15000L
                        } else {
                            sedangTerapkan.set(true); terapkanSejak = System.currentTimeMillis()
                            try { AudioRouter.apply(this@RoutingService) } finally { sedangTerapkan.set(false); terapkanSejak = 0L }
                            jeda = if (AudioRouter.sehat(this@RoutingService)) 15000L else minOf(jeda * 2, 60000L)
                        }
                    }
                } catch (_: Throwable) {}
            }
            handler.postDelayed(this, jeda)
        }
    }

    private var terapkanSejak = 0L
    private fun lama(): Boolean = terapkanSejak != 0L && System.currentTimeMillis() - terapkanSejak > 90000

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            jeda = 15000L
            reapply(true)
        }
    }

    private val cb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = reapply(false)
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = reapply(false)
    }

    override fun onCreate() {
        super.onCreate()
        val n = Kompat.pembuat(this, "rute", "Pisahkan suara aplikasi", NotificationManager.IMPORTANCE_LOW)
            .setContentTitle("Pisahkan suara aplikasi aktif")
            .setContentText("Suara aplikasi dialihkan sesuai daftar centang")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()
        startForeground(1, n)
        am = getSystemService(AudioManager::class.java)
        am.registerAudioDeviceCallback(cb, Handler(Looper.getMainLooper()))
        handler.postDelayed(jaga, 30000)
        try {
            getSystemService(ConnectivityManager::class.java).registerNetworkCallback(
                NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), netCb)
        } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        reapply(true)
        return START_STICKY
    }

    private fun reapply(force: Boolean) {
        exec.execute {
            val keys = AudioRouter.outputs(this).map { AudioRouter.key(it) }.toSet()
            if (!force && keys == lastKeys) return@execute
            lastKeys = keys
            sedangTerapkan.set(true); terapkanSejak = System.currentTimeMillis()
            try { AudioRouter.apply(this) } finally { sedangTerapkan.set(false); terapkanSejak = 0L }
            if (!Rules.active(this)) stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(jaga)
        try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(netCb) } catch (_: Throwable) {}
        try { am.unregisterAudioDeviceCallback(cb) } catch (_: Throwable) {}
        exec.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
