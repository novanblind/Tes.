package com.novan.audiolabnovan

import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.IOException

/** Format keluaran audio. Encoder aac, flac, dan pcm bawaan FFmpeg; mp3 memakai libmp3lame (sama seperti YTPlayer). */
enum class OutFmt(val label: String, val ext: String, val mime: String, val lossy: Boolean) {
    MP3("MP3", "mp3", "audio/mpeg", true),
    AAC("M4A (AAC)", "m4a", "audio/mp4", true),
    FLAC("FLAC (tanpa susut)", "flac", "audio/flac", false),
    WAV("WAV (tanpa susut)", "wav", "audio/x-wav", false);

    fun codecArgs(kbps: Int): List<String> = when (this) {
        MP3 -> listOf("-c:a", "libmp3lame", "-b:a", "${kbps}k", "-id3v2_version", "3", "-write_xing", "1")
        AAC -> listOf("-c:a", "aac", "-b:a", "${kbps}k", "-movflags", "+faststart")
        FLAC -> listOf("-c:a", "flac")
        WAV -> listOf("-c:a", "pcm_s16le")
    }
}

/** Opsi: potong, kecepatan, normalisasi (tahap 2); penguat volume dan fade (tahap 7). */
data class Opts(
    val startSec: Double = 0.0,
    val endSec: Double = 0.0,      // 0 = sampai akhir
    val speed: Double = 1.0,       // 0.5 - 2.0
    val normalize: Boolean = false,
    val gainDb: Int = 0,           // penguat volume, -12..+12 dB
    val fadeInSec: Double = 0.0,   // 0 = tanpa fade masuk
    val fadeOutSec: Double = 0.0,  // 0 = tanpa fade keluar
    val title: String = "",        // tahap 8: metadata; kosong = pakai bawaan sumber
    val artist: String = "",
    val album: String = "",
    val trimSilence: Boolean = false, // tahap 9: buang hening di awal dan akhir
    val channels: Int = 0,           // tahap 11: 0 = ikut sumber, 1 = mono, 2 = stereo
    val sampleRate: Int = 0,         // tahap 11: 0 = ikut sumber, selain itu dalam Hz
    val pitchSemi: Int = 0,          // tahap 13: ubah nada dalam setengah nada, -6..+6, durasi tetap
    val bassDb: Int = 0,             // tahap 16: bass -12..+12 dB
    val trebleDb: Int = 0,           // tahap 16: treble -12..+12 dB
    val noiseLevel: Int = 0,         // tahap 17: hapus derau, 0 = mati, 1 ringan, 2 sedang, 3 kuat
    val highpassHz: Int = 0,         // tahap 17: filter dengung/frekuensi rendah, 0 = mati
    val echoMode: Int = 0,           // tahap 18: 0 = mati, 1 ruang kecil, 2 aula, 3 gema
    val reverse: Boolean = false,    // tahap 19: balik audio (putar mundur)
    val loops: Int = 1,              // tahap 19: ulangi hasil, 1 = tanpa ulang, maksimal 10
    val compressor: Int = 0,         // tahap 21: kompresor dinamis, 0 = mati, 1 ringan, 2 sedang, 3 kuat
    val splitMin: Int = 0,           // tahap 22: bagi hasil per N menit, 0 = tidak dibagi
    val eq: List<Int> = listOf(0, 0, 0, 0, 0), // tahap 23: ekualiser 60, 230, 910, 3600, 14000 Hz; -12..+12 dB
    val voice: Int = 0,              // tahap 26: pengubah suara, 0 = mati, 1 tupai, 2 raksasa, 3 robot, 4 radio telepon, 5 bergetar
    val echoLevel: Int = 100,        // tahap 29: kadar efek ruang/gema, 25..100 persen
    val vocalCut: Int = 0,           // tahap 29: 0 = mati, 1 = seluruh audio, 2 = hanya berkas kedua dst saat campur
    val echoVoiceOnly: Boolean = false, // tahap 29: saat campur, gema hanya pada berkas pertama
    val cutFrom: Double = 0.0,       // tahap 31: hapus bagian tengah dari detik ini ...
    val cutTo: Double = 0.0,         // ... sampai detik ini (0 dan 0 = mati); waktu dihitung sesudah potong awal
    val year: String = "",           // tahap 31: tag tambahan
    val genre: String = "",
    val track: String = "",
    val comment: String = "",
    val cover: Uri? = null,          // tahap 31: gambar sampul (tidak untuk WAV)
    val loudPct: Int = 100,          // tahap 39: pengeras volume aman, 100 = mati, sampai 400 persen
    val duck: Int = 0,               // tahap 40: saat campur, musik turun otomatis saat suara bicara; 0 = mati, 1 ringan, 2 sedang, 3 kuat
    val duckSens: Int = 0,           // tahap 75: kepekaan deteksi bicara: 0 normal, 1 tinggi, 2 sangat tinggi
    val duckRel: Int = 1,            // tahap 75: kecepatan musik naik lagi: 0 cepat, 1 sedang, 2 pelan
    val loopBg: Boolean = true,      // tahap 73: saat campur dan durasi mengikuti berkas pertama, musik latar yang lebih pendek diulang
    val mixFollowFirst: Boolean = true, // tahap 72: saat campur, durasi hasil mengikuti berkas pertama (musik dipotong bila lebih panjang)
    val equalize: Boolean = false,   // tahap 42: samakan kekerasan tiap berkas sebelum digabung atau dicampur
    val deEcho: Int = 0,             // tahap 83: kurangi gema dan dengung ruang; 0 = mati, 1 ringan, 2 sedang, 3 kuat
    val spatial: Int = 0,            // tahap 83: audio 8D (suara berputar di kepala); 0 = mati, 1 pelan, 2 sedang, 3 cepat
    val splitAt: List<Double> = emptyList(), // tahap 84: bagi hasil di titik waktu (detik) yang diisi sendiri; menggantikan splitMin
    val midSilence: Int = 0          // tahap 41: pendekkan hening di tengah; 0 = mati, 1 (jeda >1 dtk jadi 1 dtk), 2 (>0,6 jadi 0,6), 3 (>0,3 jadi 0,3)
) {
    /** Tahap 84: true bila hasil akan dibagi, per N menit atau di titik waktu. */
    val bagi: Boolean get() = splitMin > 0 || splitAt.isNotEmpty()

    /** Tahap 11: argumen kanal dan laju sampel keluaran (kosong bila "ikut sumber"). */
    fun audioFormatArgs(): List<String> {
        val r = ArrayList<String>()
        if (channels > 0) r += listOf("-ac", channels.toString())
        if (sampleRate > 0) r += listOf("-ar", sampleRate.toString())
        return r
    }

    /** Argumen -metadata untuk kolom yang diisi saja. */
    fun metadataArgs(): List<String> {
        val r = ArrayList<String>()
        if (title.isNotBlank()) r += listOf("-metadata", "title=" + title.trim())
        if (artist.isNotBlank()) r += listOf("-metadata", "artist=" + artist.trim())
        if (album.isNotBlank()) r += listOf("-metadata", "album=" + album.trim())
        if (year.isNotBlank()) r += listOf("-metadata", "date=" + year.trim())
        if (genre.isNotBlank()) r += listOf("-metadata", "genre=" + genre.trim())
        if (track.isNotBlank()) r += listOf("-metadata", "track=" + track.trim())
        if (comment.isNotBlank()) r += listOf("-metadata", "comment=" + comment.trim())
        return r
    }
}

object Converter {
    /** Terima "90", "1:30", "01:02:03", boleh desimal. Kosong = 0. Null bila tidak valid. */
    fun parseTime(t: String): Double? {
        val s = t.trim()
        if (s.isEmpty()) return 0.0
        return try {
            s.split(":").fold(0.0) { acc, part -> acc * 60 + part.trim().toDouble() }
        } catch (e: NumberFormatException) {
            null
        }
    }

    /**
     * Tahap 84: daftar titik waktu dipisah koma, titik koma, atau spasi, mis. "1:30, 4:05, 10:00".
     * Kosong = daftar kosong. Null bila ada yang tidak valid, nol/negatif, atau ada titik kembar.
     * Hasil diurutkan naik.
     */
    fun parseTimeList(t: String): List<Double>? {
        val bagian = t.split(',', ';', ' ', '\n').map { it.trim() }.filter { it.isNotEmpty() }
        val hasil = ArrayList<Double>()
        for (b in bagian) {
            val v = try {
                b.split(":").fold(0.0) { acc, part -> acc * 60 + part.trim().toDouble() }
            } catch (e: NumberFormatException) { return null }
            if (v <= 0.0 || v.isNaN() || v.isInfinite()) return null
            hasil += v
        }
        val urut = hasil.sorted()
        for (i in 1 until urut.size) if (Math.abs(urut[i] - urut[i - 1]) < 0.01) return null
        return urut
    }

    /** Durasi dalam milidetik (0 bila tidak diketahui). Panggil dari thread latar. */
    fun probeDurationMs(ctx: Context, uri: Uri): Long {
        return try {
            val path = FFmpegKitConfig.getSafParameterForRead(ctx, uri)
            val d = FFprobeKit.getMediaInformation(path).mediaInformation?.duration
            ((d?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
        } catch (e: Throwable) {
            0L
        }
    }

    /** Tahap 12: ringkasan berkas (format, durasi, codec, kanal, laju sampel, bitrate). Panggil dari thread latar. */
    fun probeInfo(ctx: Context, uri: Uri): String {
        return try {
            val path = FFmpegKitConfig.getSafParameterForRead(ctx, uri)
            val mi = FFprobeKit.getMediaInformation(path).mediaInformation ?: return "informasi tidak terbaca"
            val parts = ArrayList<String>()
            mi.format?.let { parts += "format $it" }
            val d = mi.duration?.toDoubleOrNull()
            if (d != null && d > 0) parts += "durasi " + durasiTeks(d)
            val a = mi.streams?.firstOrNull { it.type == "audio" }
            if (a != null) {
                a.codec?.let { parts += "codec $it" }
                a.sampleRate?.toIntOrNull()?.let { parts += "laju sampel $it Hz" }
                a.channelLayout?.let { parts += "kanal $it" }
                (a.bitrate ?: mi.bitrate)?.toLongOrNull()?.let { parts += "bitrate ${it / 1000} kbps" }
            } else {
                parts += "tanpa jalur audio"
            }
            if (mi.streams?.any { it.type == "video" } == true) parts += "berisi video"
            parts.joinToString(", ")
        } catch (e: Throwable) {
            "informasi tidak terbaca"
        }
    }

    /** Durasi dibacakan jelas: "3 menit 25 detik". */
    fun durasiTeks(sec: Double): String {
        val t = sec.toLong()
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        val sb = StringBuilder()
        if (h > 0) sb.append("$h jam ")
        if (h > 0 || m > 0) sb.append("$m menit ")
        sb.append("$s detik")
        return sb.toString()
    }

    /**
     * Konversi asinkron. Hasil ditulis ke [dest] (berkas cache), lalu [onDone] dipanggil
     * dengan null bila sukses atau pesan galat bila gagal. Mengembalikan sesi agar bisa dibatalkan.
     */
    fun convert(
        ctx: Context, src: Uri, dest: File, fmt: OutFmt, kbps: Int, durationMs: Long, opts: Opts,
        onProgress: (Int) -> Unit, onDone: (String?) -> Unit
    ): FFmpegSession {
        val input = FFmpegKitConfig.getSafParameterForRead(ctx, src)
        val args = ArrayList<String>()
        args += listOf("-y", "-nostdin")
        if (opts.startSec > 0) args += listOf("-ss", fmt3(opts.startSec))
        // -t diletakkan sebelum -i (opsi masukan) agar membatasi panjang sumber, bukan panjang hasil.
        // Bila diletakkan sesudah -i, kecepatan 2x akan memotong hasil di tempat yang salah.
        if (opts.endSec > opts.startSec) args += listOf("-t", fmt3(opts.endSec - opts.startSec))
        val hasCover = opts.cover != null && fmt != OutFmt.WAV
        args += listOf("-i", input)
        args += coverInput(ctx, opts, fmt)
        if (!hasCover) args += "-vn"
        args += listOf("-map", "0:a:0")
        args += coverMap(opts, fmt, 1)
        val srcLenSec = (if (opts.endSec > 0) opts.endSec else durationMs / 1000.0) - opts.startSec
        val filters = ArrayList<String>()
        filters += cutFilters(opts)
        filters += cleanFilters(opts)
        filters += silenceFilters(opts)
        filters += pitchFilters(opts)
        filters += voiceFilters(opts)
        if (opts.reverse) filters += "areverse"
        if (opts.speed != 1.0) filters += "atempo=" + fmt3(opts.speed)
        filters += loopFilters(opts)
        val outSec = (if (srcLenSec > 0) (srcLenSec - cutLength(opts, srcLenSec)).coerceAtLeast(0.0) / opts.speed else 0.0) * opts.loops.coerceAtLeast(1)
        filters += tailFilters(opts, outSec)
        if (filters.isNotEmpty()) args += listOf("-af", filters.joinToString(","))
        args += opts.audioFormatArgs()
        args += fmt.codecArgs(kbps)
        args += opts.metadataArgs()
        args += dest.absolutePath
        // Panjang hasil (ms) dipakai untuk menghitung persen progres.
        val outMs = (outSec * 1000).toLong()
        return run(args, dest, outMs, onProgress, onDone)
    }

    /**
     * Tahap 5: gabung beberapa berkas (urut sesuai [srcs]) menjadi satu. Potong, kecepatan, dan
     * normalisasi berlaku pada hasil gabungan. [totalMs] = jumlah durasi semua sumber.
     */
    fun merge(
        ctx: Context, srcs: List<Uri>, dest: File, fmt: OutFmt, kbps: Int, totalMs: Long, opts: Opts,
        onProgress: (Int) -> Unit, onDone: (String?) -> Unit,
        mix: Boolean = false, bgVolume: Double = 1.0
    ): FFmpegSession {
        val args = ArrayList<String>()
        args += listOf("-y", "-nostdin")
        for (u in srcs) args += listOf("-i", FFmpegKitConfig.getSafParameterForRead(ctx, u))
        val g = StringBuilder()
        // Samakan laju sampel dan kanal tiap sumber, karena concat menuntut format yang sama.
        for (i in srcs.indices) {
            // Tahap 42: bila "samakan volume" aktif, tiap berkas dinormalkan ke kekerasan yang sama (loudnorm -16 LUFS)
            // sebelum digabung; loudnorm bekerja pada laju tinggi, jadi dikembalikan ke 44,1 kHz sesudahnya.
            val eq = if (opts.equalize) ",loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo" else ""
            g.append("[$i:a:0]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo$eq[a$i];")
        }
        if (mix) {
            // Tahap 25: mixer. Semua berkas diputar bersamaan; berkas pertama tetap 100%, sisanya pakai
            // [bgVolume]. Panjang hasil mengikuti berkas terpanjang; pembatas menjaga agar tidak pecah.
            for (i in srcs.indices) {
                val v = if (i == 0) 1.0 else bgVolume
                val chain = ArrayList<String>()
                if (i == 0 && opts.echoVoiceOnly) chain += echoFilters(opts)   // tahap 29: gema hanya pada suara
                if (i >= 1 && opts.vocalCut == 2) chain += vocalCutFilters()   // tahap 29: kurangi vokal lagu
                chain += "volume=${String.format(java.util.Locale.US, "%.2f", v)}"
                // Tahap 73: musik latar diulang tanpa batas; panjang hasil dikunci oleh amix duration=first dan atrim di bawah.
                if (i >= 1 && opts.mixFollowFirst && opts.loopBg) chain += "aloop=loop=-1:size=2147483647"
                g.append("[a$i]${chain.joinToString(",")}[m$i];")
            }
            // Tahap 40: musik turun otomatis. Suara berkas pertama dibelah: satu ke hasil akhir, sisanya jadi
            // pemicu (sidechain) yang menekan tiap musik saat suara bicara muncul, lalu musik naik lagi saat jeda.
            val duckOn = opts.duck > 0 && srcs.size > 1
            val labels = ArrayList<String>()
            if (duckOn) {
                val nBg = srcs.size - 1
                g.append("[m0]asplit=${nBg + 1}[v0]")
                for (i in 1..nBg) g.append("[sr$i]")
                g.append(";")
                // apad: pemicu diberi hening tak terbatas di ujungnya supaya musik yang lebih panjang tidak terpotong.
                // Tahap 75: deteksi bicara dibuat tegas. Pemicu disaring ke pita suara (120-4500 Hz), dikuatkan, lalu dipotong
                // rata (asoftclip) sehingga tingkatnya sama untuk suara keras maupun pelan. Dengan begitu musik turun
                // sedalam yang sama (sekitar 6, 12, atau 20 dB) dan langsung (attack 3 md), bukan tergantung keras suara.
                // Diuji dengan ffmpeg 6.1 pada suara contoh: turun dalam 50 md, naik lagi 150 sampai 550 md.
                val gainDb = when (opts.duckSens) { 1 -> 34; 2 -> 37; else -> 30 }
                val relMs = when (opts.duckRel) { 0 -> 150; 2 -> 700; else -> 350 }
                val thr = when (opts.duck) { 1 -> "0.24"; 3 -> "0.045"; else -> "0.11" }
                for (i in 1..nBg) g.append("[sr$i]apad,highpass=f=120,lowpass=f=4500,volume=${gainDb}dB,asoftclip=type=hard:threshold=0.5[sc$i];")
                for (i in 1..nBg) {
                    g.append("[m$i][sc$i]sidechaincompress=threshold=$thr:ratio=20:attack=3:release=$relMs:makeup=1[d$i];")
                }
                labels += "v0"
                for (i in 1..nBg) labels += "d$i"
            } else {
                for (i in srcs.indices) labels += "m$i"
            }
            for (l in labels) g.append("[$l]")
            g.append("amix=inputs=${srcs.size}:duration=${if (opts.mixFollowFirst) "first" else "longest"}:dropout_transition=0:normalize=0,alimiter=limit=0.95")
            // Pengaman: bila musik diulang tanpa batas, potong tepat pada durasi berkas pertama (totalMs).
            if (opts.mixFollowFirst && opts.loopBg && totalMs > 0) g.append(",atrim=duration=${fmt3(totalMs / 1000.0)}")
            g.append("[c0]")
        } else {
            for (i in srcs.indices) g.append("[a$i]")
            g.append("concat=n=${srcs.size}:v=0:a=1[c0]")
        }
        var last = "c0"
        fun step(f: String) {
            g.append(";[$last]$f[s${last}]")
            last = "s$last"
        }
        if (opts.startSec > 0 || opts.endSec > 0) {
            val trim = StringBuilder("atrim=start=${fmt3(opts.startSec)}")
            if (opts.endSec > opts.startSec) trim.append(":end=${fmt3(opts.endSec)}")
            step("$trim,asetpts=PTS-STARTPTS")
        }
        for (f in cutFilters(opts)) step(f)
        for (f in cleanFilters(opts)) step(f)
        for (f in silenceFilters(opts)) step(f)
        for (f in pitchFilters(opts)) step(f)
        for (f in voiceFilters(opts)) step(f)
        if (opts.reverse) step("areverse")
        if (opts.speed != 1.0) step("atempo=" + fmt3(opts.speed))
        for (f in loopFilters(opts)) step(f)
        val lenSec = (if (opts.endSec > 0) opts.endSec else totalMs / 1000.0) - opts.startSec
        val outSec = (if (lenSec > 0) (lenSec - cutLength(opts, lenSec)).coerceAtLeast(0.0) / opts.speed else 0.0) * opts.loops.coerceAtLeast(1)
        for (f in tailFilters(opts, outSec)) step(f)
        args += coverInput(ctx, opts, fmt)
        args += listOf("-filter_complex", g.toString(), "-map", "[$last]")
        args += coverMap(opts, fmt, srcs.size)
        args += opts.audioFormatArgs()
        args += fmt.codecArgs(kbps)
        args += opts.metadataArgs()
        args += dest.absolutePath
        return run(args, dest, (outSec * 1000).toLong(), onProgress, onDone)
    }

    /**
     * Tahap 13: ubah nada tanpa mengubah durasi. Audio disamakan ke 44,1 kHz dulu (agar tidak
     * bergantung pada laju sampel sumber), diputar lebih cepat/lambat lewat asetrate, dikembalikan
     * ke 44,1 kHz, lalu atempo membalik perubahan durasinya.
     */
    fun pitchFilters(opts: Opts): List<String> {
        if (opts.pitchSemi == 0) return emptyList()
        val f = Math.pow(2.0, opts.pitchSemi / 12.0)
        val r = Math.round(44100 * f).toInt()
        return listOf("aresample=44100", "asetrate=$r", "aresample=44100", "atempo=" + String.format(java.util.Locale.US, "%.6f", 1.0 / f))
    }

    /** Pitch dengan durasi tetap, faktor [f] (>1 lebih tinggi). Dipakai pengubah suara. */
    private fun shift(f: Double): List<String> {
        val r = Math.round(44100 * f).toInt()
        return listOf("aresample=44100", "asetrate=$r", "aresample=44100", "atempo=" + String.format(java.util.Locale.US, "%.6f", 1.0 / f))
    }

    /** Tahap 31: filter hapus bagian tengah (frame di antara cutFrom dan cutTo dibuang, sisanya disambung). */
    fun cutFilters(opts: Opts): List<String> {
        if (opts.cutTo <= opts.cutFrom) return emptyList()
        val a = fmt3(opts.cutFrom)
        val b = fmt3(opts.cutTo)
        return listOf("aselect='not(between(t,$a,$b))'", "asetpts=N/SR/TB")
    }

    /** Tahap 31: panjang yang terbuang (detik) dari sumber sepanjang [srcLenSec]; 0 bila mati atau di luar panjang sumber. */
    fun cutLength(opts: Opts, srcLenSec: Double): Double {
        if (opts.cutTo <= opts.cutFrom) return 0.0
        if (srcLenSec <= 0) return opts.cutTo - opts.cutFrom
        return (minOf(opts.cutTo, srcLenSec) - opts.cutFrom).coerceAtLeast(0.0)
    }

    /** Tahap 31: masukan gambar sampul (kosong bila tidak dipakai atau format WAV, yang tidak punya tempat sampul). */
    fun coverInput(ctx: Context, opts: Opts, fmt: OutFmt): List<String> {
        val c = opts.cover ?: return emptyList()
        if (fmt == OutFmt.WAV) return emptyList()
        return listOf("-i", FFmpegKitConfig.getSafParameterForRead(ctx, c))
    }

    /** Tahap 31: petakan gambar sampul (masukan nomor [idx]) sebagai gambar terlampir. */
    fun coverMap(opts: Opts, fmt: OutFmt, idx: Int): List<String> {
        if (opts.cover == null || fmt == OutFmt.WAV) return emptyList()
        return listOf("-map", "$idx:v:0", "-c:v", "copy", "-disposition:v:0", "attached_pic")
    }

    /**
     * Tahap 29: pengurang vokal (minus one). Suara yang sama di kiri dan kanan (biasanya penyanyi di tengah)
     * saling menghilang; hasilnya mono yang dibuat ke dua kanal. Bass yang berada di tengah ikut berkurang.
     */
    fun vocalCutFilters(): List<String> = listOf(
        "aformat=channel_layouts=stereo",
        "pan=stereo|c0=0.5*c0-0.5*c1|c1=0.5*c0-0.5*c1"
    )

    /**
     * Tahap 18 dan 29: efek ruang dan gema (aecho: in_gain:out_gain:jeda ms:peluruhan). Pilihan 1-3 asli,
     * 4 studio vokal, 5 karaoke, 6 katedral, 7 kamar mandi, 8 panggung konser. Kadar efek mengecilkan
     * peluruhan tiap pantulan (100% = penuh). Pembatas agar tidak pecah.
     */
    fun echoFilters(opts: Opts): List<String> {
        val spec: Pair<String, List<Double>> = when (opts.echoMode) {
            1 -> "40|60" to listOf(0.3, 0.2)
            2 -> "60|120|180" to listOf(0.4, 0.3, 0.2)
            3 -> "350" to listOf(0.4)
            4 -> "25|50|80" to listOf(0.25, 0.2, 0.12)
            5 -> "70|140|210|350" to listOf(0.35, 0.3, 0.22, 0.15)
            6 -> "120|240|400|600|800" to listOf(0.4, 0.35, 0.3, 0.22, 0.15)
            7 -> "15|30|45|60|90" to listOf(0.5, 0.45, 0.4, 0.3, 0.2)
            8 -> "90|180|300|450" to listOf(0.35, 0.3, 0.2, 0.15)
            else -> return emptyList()
        }
        val k = opts.echoLevel.coerceIn(10, 100) / 100.0
        val outGain = if (opts.echoMode == 1 || opts.echoMode == 3) "0.88" else "0.9"
        val decays = spec.second.joinToString("|") { String.format(java.util.Locale.US, "%.3f", it * k) }
        return listOf("aecho=0.8:$outGain:${spec.first}:$decays", "alimiter=limit=0.95")
    }

    /**
     * Tahap 26: pengubah suara siap pakai. Semua pilihan menjaga durasi tetap, jadi fade dan progres tetap akurat.
     * Tupai = nada naik; Raksasa = nada turun; Robot = fase dibuang lewat afftfilt; Radio telepon = pita 300-3400 Hz;
     * Bergetar = tremolo.
     */
    fun voiceFilters(opts: Opts): List<String> = when (opts.voice) {
        1 -> shift(1.5)
        2 -> shift(0.7) + "lowpass=f=6000"
        3 -> listOf("aresample=44100", "afftfilt=real='hypot(re,im)*cos(0)':imag='hypot(re,im)*sin(0)':win_size=512:overlap=0.75")
        4 -> listOf("highpass=f=300", "lowpass=f=3400", "acompressor=threshold=-24dB:ratio=4:makeup=3")
        5 -> listOf("tremolo=f=7:d=0.8")
        else -> emptyList()
    }

    /**
     * Tahap 17: pembersihan suara. Filter highpass membuang dengung/gemuruh di bawah batas (Hz),
     * afftdn menekan derau latar (desis) dengan pelacakan derau otomatis. Dijalankan paling awal.
     */
    fun cleanFilters(opts: Opts): List<String> {
        val f = ArrayList<String>()
        if (opts.vocalCut == 1) f += vocalCutFilters()
        if (opts.highpassHz > 0) f += "highpass=f=${opts.highpassHz}"
        val nr = when (opts.noiseLevel) { 1 -> 8; 2 -> 14; 3 -> 22; else -> 0 }
        if (nr > 0) f += "afftdn=nr=$nr:nf=-40:tn=1"
        // Tahap 83: kurangi gema. Gerbang menutup ekor gema di sela kata; makin kuat, makin cepat menutup.
        when (opts.deEcho) {
            1 -> f += "agate=threshold=0.02:ratio=2:attack=5:release=200"
            2 -> f += "agate=threshold=0.04:ratio=4:attack=5:release=120"
            3 -> f += "agate=threshold=0.08:ratio=8:attack=5:release=70"
        }
        return f
    }

    /**
     * Tahap 19: ulangi seluruh hasil (aloop menyimpan seluruh audio di memori lalu mengulangnya).
     * Dijalankan sebelum fade, sehingga fade masuk/keluar berlaku pada hasil ulang secara utuh.
     */
    fun loopFilters(opts: Opts): List<String> {
        val n = opts.loops.coerceIn(1, 10)
        if (n <= 1) return emptyList()
        return listOf("aloop=loop=${n - 1}:size=2147483647")
    }

    /** Tahap 9: buang hening di awal, lalu di akhir (dibalik sementara). Ambang -50 dB, sisakan 0,2 detik. */
    fun silenceFilters(opts: Opts): List<String> {
        val out = ArrayList<String>()
        if (opts.trimSilence) {
            val sr = "silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.2"
            out += sr
            out += "areverse,$sr,areverse"
        }
        // Tahap 41: hening di tengah. silenceremove memendekkan setiap jeda yang lebih panjang dari stop_duration
        // menjadi sepanjang stop_duration (jeda yang lebih pendek tidak disentuh), jadi ucapan tidak terdengar menempel.
        val keep = when (opts.midSilence) {
            1 -> "1"
            2 -> "0.6"
            3 -> "0.3"
            else -> null
        }
        if (keep != null) out += "silenceremove=stop_periods=-1:stop_duration=$keep:stop_threshold=-45dB:stop_silence=0"
        return out
    }

    /**
     * Tahap 7: filter akhir, urutannya tetap: bass/treble (tahap 16), kompresor (tahap 21), efek ruang (tahap 18), normalisasi, penguat volume (dengan pembatas agar tidak pecah),
     * lalu fade paling akhir supaya benar-benar terdengar. [outSec] = panjang hasil sesudah kecepatan
     * (0 = tidak diketahui; fade keluar dilewati).
     */
    fun tailFilters(opts: Opts, outSec: Double): List<String> {
        val f = ArrayList<String>()
        // Tahap 16: bass dan treble lebih dulu; pembatas bila ada yang dinaikkan agar tidak pecah.
        if (opts.bassDb != 0) f += "bass=g=${opts.bassDb}"
        if (opts.trebleDb != 0) f += "treble=g=${opts.trebleDb}"
        if (opts.bassDb > 0 || opts.trebleDb > 0) f += "alimiter=limit=0.95"
        // Tahap 23: ekualiser 5 pita (filter equalizer, lebar 2 oktaf); pembatas bila ada pita yang dinaikkan.
        val eqHz = listOf(60, 230, 910, 3600, 14000)
        opts.eq.forEachIndexed { i, g -> if (g != 0 && i < eqHz.size) f += "equalizer=f=${eqHz[i]}:t=o:w=2:g=$g" }
        if (opts.eq.any { it > 0 }) f += "alimiter=limit=0.95"
        // Tahap 21: kompresor dinamis (suara keras ditekan, suara pelan ikut naik); pembatas agar tidak pecah.
        when (opts.compressor) {
            1 -> f += "acompressor=threshold=-18dB:ratio=2:attack=20:release=250:makeup=1.5"
            2 -> f += "acompressor=threshold=-24dB:ratio=4:attack=10:release=200:makeup=2.5"
            3 -> f += "acompressor=threshold=-30dB:ratio=8:attack=5:release=150:makeup=4"
        }
        if (opts.compressor > 0) f += "alimiter=limit=0.95"
        // Tahap 18 dan 29: efek ruang/gema. Saat campur dengan "gema hanya pada suara", efek dipasang pada berkas pertama saja.
        if (!opts.echoVoiceOnly) f += echoFilters(opts)
        // Tahap 83: audio 8D. Suara dipaksa stereo, lalu berpindah kiri kanan pelan-pelan; gema tipis memberi kesan ruang.
        if (opts.spatial > 0) {
            val hz = when (opts.spatial) { 1 -> "0.08"; 2 -> "0.15"; else -> "0.3" }
            f += "aformat=channel_layouts=stereo"
            f += "apulsator=mode=sine:hz=$hz:amount=1"
            f += "aecho=0.8:0.88:40|70:0.2|0.15"
            f += "alimiter=limit=0.95"
        }
        if (opts.normalize) {
            // loudnorm mengeluarkan audio 192 kHz; tanpa dikembalikan, WAV/FLAC jadi sangat besar. Kembalikan ke laju pilihan atau 44,1 kHz.
            f += "loudnorm=I=-16:TP=-1.5:LRA=11"
            f += "aresample=" + (if (opts.sampleRate > 0) opts.sampleRate else 44100)
        }
        if (opts.gainDb != 0) {
            f += "volume=${opts.gainDb}dB"
            if (opts.gainDb > 0) f += "alimiter=limit=0.95"
        }
        // Tahap 39 (disempurnakan tahap 43): pengeras volume aman. Hanya puncak yang keras (di atas 0,5) ditekan lembut
        // 2:1 lebih dulu, lalu volume dikuatkan, lalu pembatas dengan pandangan ke depan menahan sisa puncak tanpa memotong
        // gelombang. Musik biasa naik hampir sebesar persen yang dipilih; sumber yang sudah sangat keras naik lebih sedikit.
        if (opts.loudPct > 100) {
            f += "acompressor=threshold=0.5:ratio=2:attack=10:release=150:knee=6:makeup=1"
            f += "volume=" + String.format(java.util.Locale.US, "%.2f", opts.loudPct / 100.0)
            f += "alimiter=limit=0.95:attack=15:release=250:level=0"
        }
        if (opts.fadeInSec > 0) f += "afade=t=in:st=0:d=" + fmt3(opts.fadeInSec)
        if (opts.fadeOutSec > 0 && (outSec <= 0 || opts.trimSilence || opts.midSilence > 0)) {
            // Panjang hasil tidak diketahui pasti: balik audio, fade masuk, balik lagi.
            f += "areverse,afade=t=in:st=0:d=" + fmt3(opts.fadeOutSec) + ",areverse"
        } else if (opts.fadeOutSec > 0) {
            val d = minOf(opts.fadeOutSec, outSec)
            f += "afade=t=out:st=" + fmt3(outSec - d) + ":d=" + fmt3(d)
        }
        return f
    }

    /**
     * Tahap 22: bagi berkas hasil jadi beberapa bagian per [minutes] menit tanpa encode ulang
     * (-c copy, jadi cepat dan kualitas tidak berubah). Bagian ditulis ke [outDir] sebagai bagian_000, bagian_001, dst.
     */
    fun split(src: File, outDir: File, ext: String, minutes: Int, onDone: (String?) -> Unit): FFmpegSession {
        val pattern = File(outDir, "bagian_%03d.$ext").absolutePath
        val args = listOf(
            "-y", "-nostdin", "-i", src.absolutePath, "-map", "0:a:0", "-c", "copy",
            "-f", "segment", "-segment_time", (minutes * 60).toString(), "-reset_timestamps", "1", pattern
        )
        return FFmpegKit.executeWithArgumentsAsync(args.toTypedArray()) { s ->
            when {
                ReturnCode.isCancel(s.returnCode) -> onDone("Dibatalkan")
                ReturnCode.isSuccess(s.returnCode) -> onDone(null)
                else -> {
                    val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                    onDone("Pembagian gagal (kode ${s.returnCode}): $log")
                }
            }
        }
    }

    /**
     * Tahap 84: bagi berkas hasil di titik-titik waktu [points] (detik, naik) tanpa encode ulang.
     * Titik waktu dihitung pada berkas hasil (sesudah potong, kecepatan, dan efek lain).
     * Bagian ditulis ke [outDir] sebagai bagian_000, bagian_001, dst.
     */
    fun splitAt(src: File, outDir: File, ext: String, points: List<Double>, onDone: (String?) -> Unit): FFmpegSession {
        val pattern = File(outDir, "bagian_%03d.$ext").absolutePath
        val times = points.joinToString(",") { fmt3(it) }
        val args = listOf(
            "-y", "-nostdin", "-i", src.absolutePath, "-map", "0:a:0", "-c", "copy",
            "-f", "segment", "-segment_times", times, "-reset_timestamps", "1", pattern
        )
        return FFmpegKit.executeWithArgumentsAsync(args.toTypedArray()) { s ->
            when {
                ReturnCode.isCancel(s.returnCode) -> onDone("Dibatalkan")
                ReturnCode.isSuccess(s.returnCode) -> onDone(null)
                else -> {
                    val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                    onDone("Pembagian gagal (kode ${s.returnCode}): $log")
                }
            }
        }
    }

    private fun run(
        args: List<String>, dest: File, outMs: Long,
        onProgress: (Int) -> Unit, onDone: (String?) -> Unit
    ): FFmpegSession {
        return FFmpegKit.executeWithArgumentsAsync(
            args.toTypedArray(),
            { s ->
                when {
                    ReturnCode.isCancel(s.returnCode) -> onDone("Dibatalkan")
                    ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> onDone(null)
                    else -> {
                        val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                        onDone("FFmpeg gagal (kode ${s.returnCode}): $log")
                    }
                }
            },
            null,
            { st ->
                if (outMs > 0) {
                    onProgress((st.time.toLong() * 100L / outMs).toInt().coerceIn(0, 100))
                }
            }
        )
    }

    private fun fmt3(v: Double) = String.format(java.util.Locale.US, "%.3f", v)

    @Throws(IOException::class)
    fun copyTo(ctx: Context, from: File, to: Uri) {
        ctx.contentResolver.openOutputStream(to, "w")!!.use { out ->
            from.inputStream().use { it.copyTo(out) }
        }
    }
}
