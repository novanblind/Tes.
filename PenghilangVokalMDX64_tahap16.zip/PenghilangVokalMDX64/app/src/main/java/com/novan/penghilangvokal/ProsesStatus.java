package com.novan.penghilangvokal;

import android.os.Handler;
import android.os.Looper;

/** Keadaan proses yang dibagi antara layanan latar belakang dan layar utama. */
final class ProsesStatus {

    interface Listener {
        void onPerubahan();
    }

    static volatile boolean berjalan = false;
    static volatile int persen = 0;
    static volatile String pesan = "";
    static volatile String namaLagu = "";
    static volatile VocalRemover remover = null;
    /** Berkas hasil terakhir (instrumental dan, bila diminta, vokal). */
    static final java.util.concurrent.CopyOnWriteArrayList<Penyimpan.Hasil> hasil =
            new java.util.concurrent.CopyOnWriteArrayList<>();
    /** True selama hasil baru belum ditampilkan di dialog. */
    static volatile boolean hasilBaru = false;

    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static Listener listener;

    private ProsesStatus() { }

    static void ganti(Penyimpan.Hasil lama, Penyimpan.Hasil baru) {
        int i = indeks(lama);
        if (i >= 0) hasil.set(i, baru);
    }

    static void buang(Penyimpan.Hasil h) {
        int i = indeks(h);
        if (i >= 0) hasil.remove(i);
    }

    private static int indeks(Penyimpan.Hasil h) {
        for (int i = 0; i < hasil.size(); i++) {
            if (hasil.get(i).uri.equals(h.uri)) return i;
        }
        return -1;
    }

    static synchronized void setListener(Listener l) {
        listener = l;
    }

    /** Memberi tahu layar utama (bila sedang terbuka) agar menyegarkan tampilan. */
    static void perbarui() {
        UI.post(() -> {
            Listener l;
            synchronized (ProsesStatus.class) {
                l = listener;
            }
            if (l != null) l.onPerubahan();
        });
    }
}
