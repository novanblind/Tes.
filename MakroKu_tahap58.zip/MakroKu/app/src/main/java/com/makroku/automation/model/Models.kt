package com.makroku.automation.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** JSON dengan diskriminator "type" untuk kelas sealed (pemicu/aksi/batasan). */
val AppJson = Json {
    classDiscriminator = "type"
    encodeDefaults = true
    ignoreUnknownKeys = true
    prettyPrint = true
}

val ALL_DAYS: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7) // Calendar.DAY_OF_WEEK (1 = Minggu)

@Serializable
data class Macro(
    val id: Long = 0,
    val name: String,
    val description: String = "",
    val category: String = "Umum",
    val enabled: Boolean = true,
    val triggers: List<MacroTrigger> = emptyList(),
    val actions: List<MacroAction> = emptyList(),
    val constraints: List<MacroConstraint> = emptyList(),
    val constraintAny: Boolean = false,
    val lastRun: Long = 0,
    val runCount: Int = 0,
)

@Serializable
data class LogEntry(val time: Long, val macro: String, val message: String, val ok: Boolean = true)

/** Kejadian yang dikirim ke mesin. [kind] mis. "battery", "power", "sms", "notification". */
data class TriggerEvent(val kind: String, val data: Map<String, String> = emptyMap())

// ───────────────────────────── PEMICU ─────────────────────────────
@Serializable
sealed interface MacroTrigger

@Serializable @SerialName("time")
data class TimeTrigger(val hour: Int = 8, val minute: Int = 0, val days: List<Int> = ALL_DAYS) : MacroTrigger

@Serializable @SerialName("periodic")
data class PeriodicTrigger(val minutes: Long = 30) : MacroTrigger

@Serializable @SerialName("battery_level")
data class BatteryLevelTrigger(val level: Int = 20, val below: Boolean = true) : MacroTrigger

@Serializable @SerialName("power")
data class PowerTrigger(val connected: Boolean = true) : MacroTrigger

@Serializable @SerialName("boot")
object BootTrigger : MacroTrigger

@Serializable @SerialName("screen")
data class ScreenTrigger(val on: Boolean = true) : MacroTrigger

@Serializable @SerialName("wifi_state")
data class WifiStateTrigger(val enabled: Boolean = true) : MacroTrigger

@Serializable @SerialName("bluetooth_state")
data class BluetoothStateTrigger(val enabled: Boolean = true) : MacroTrigger

@Serializable @SerialName("airplane")
data class AirplaneTrigger(val on: Boolean = true) : MacroTrigger

@Serializable @SerialName("headphone")
data class HeadphoneTrigger(val plugged: Boolean = true) : MacroTrigger

@Serializable @SerialName("sms")
data class SmsTrigger(val sender: String = "", val contains: String = "") : MacroTrigger

@Serializable @SerialName("call")
data class CallTrigger(val number: String = "") : MacroTrigger

@Serializable @SerialName("notification")
data class NotificationTrigger(
    val pkg: String = "", val contains: String = "",
    /** Bila benar, pemicu jalan saat teks TIDAK mengandung [contains]. */
    val excludes: Boolean = false,
    /** Abaikan notifikasi yang sedang berjalan (ongoing), mis. pemutar musik. */
    val ignoreOngoing: Boolean = false,
    /** [contains] dibaca sebagai regex. */
    val regex: Boolean = false,
) : MacroTrigger

@Serializable @SerialName("app_launched")
data class AppLaunchedTrigger(val pkg: String = "") : MacroTrigger

@Serializable @SerialName("intent")
data class IntentTrigger(val action: String = "com.makroku.automation.CUSTOM") : MacroTrigger

@Serializable @SerialName("manual")
object ManualTrigger : MacroTrigger

@Serializable @SerialName("unlock")
object UnlockTrigger : MacroTrigger

@Serializable @SerialName("package")
data class AppPackageTrigger(val installed: Boolean = true, val pkg: String = "") : MacroTrigger

@Serializable @SerialName("bt_device")
data class BluetoothDeviceTrigger(val connected: Boolean = true, val device: String = "") : MacroTrigger

@Serializable @SerialName("call_end")
data class CallEndedTrigger(val number: String = "") : MacroTrigger

@Serializable @SerialName("shake")
data class ShakeTrigger(val force: Int = 14) : MacroTrigger

@Serializable @SerialName("wifi_network")
data class WifiNetworkTrigger(val connected: Boolean = true, val ssid: String = "") : MacroTrigger

/** Lintang/bujur disimpan sebagai teks (mis. -6.2). Butuh izin lokasi (bisa diberi lewat ADB). */
@Serializable @SerialName("geofence")
data class GeofenceTrigger(
    val lat: String = "-6.2", val lon: String = "106.8", val radius: Int = 200, val enter: Boolean = true,
) : MacroTrigger

@Serializable @SerialName("variable_changed")
data class VariableChangedTrigger(val name: String = "variabel", val value: String = "") : MacroTrigger

@Serializable @SerialName("ringer_changed")
data class RingerChangedTrigger(val ringerMode: String = "silent") : MacroTrigger

@Serializable @SerialName("power_save_changed")
data class PowerSaveTrigger(val on: Boolean = true) : MacroTrigger

@Serializable @SerialName("dnd_changed")
data class DndChangedTrigger(val on: Boolean = true) : MacroTrigger

@Serializable @SerialName("sync_changed")
data class SyncStateTrigger(val on: Boolean = true) : MacroTrigger

@Serializable @SerialName("cell_net")
data class MobileDataTrigger(val connected: Boolean = true) : MacroTrigger

@Serializable @SerialName("monthly")
data class MonthlyTrigger(val day: Int = 1, val hour: Int = 8, val minute: Int = 0) : MacroTrigger

@Serializable @SerialName("date_changed")
object DateChangedTrigger : MacroTrigger

@Serializable @SerialName("usb_state")
data class UsbStateTrigger(val connected: Boolean = true) : MacroTrigger

@Serializable @SerialName("missed_call")
data class MissedCallTrigger(val number: String = "") : MacroTrigger

@Serializable @SerialName("notif_removed")
data class NotificationRemovedTrigger(val pkg: String = "", val contains: String = "") : MacroTrigger

/** Daftar jam dipisah koma, mis. 06:00,12:00,18:00. */
@Serializable @SerialName("times_list")
data class TimesTrigger(val hours: String = "06:00,12:00,18:00", val days: List<Int> = ALL_DAYS) : MacroTrigger

/** Tombol volume ditekan (butuh Aksesibilitas). press: short | long | any. block = tombol tidak mengubah volume. */
@Serializable @SerialName("volume_key")
data class VolumeKeyTrigger(val volKey: String = "up", val press: String = "long", val block: Boolean = false) : MacroTrigger

/** Sensor jarak: dekat = tangan/saku menutup sensor di dekat layar. */
@Serializable @SerialName("proximity")
data class ProximityTrigger(val near: Boolean = true) : MacroTrigger

/** Ponsel dibalik: layar menghadap bawah (true) atau kembali menghadap atas (false). */
@Serializable @SerialName("flip")
data class FlipTrigger(val faceDown: Boolean = true) : MacroTrigger

/** Ubin Pengaturan Cepat nomor 1-3 diketuk (tambahkan ubin "MakroKu 1/2/3" lewat panel pengaturan cepat). */
@Serializable @SerialName("tile")
data class TileTrigger(val tile: Int = 1) : MacroTrigger

/**
 * Webhook lokal: http://127.0.0.1:8765/<hookPath>?token=...&nama=nilai. Parameter jadi placeholder {wh_nama}.
 * Token kosong = hanya bisa dipanggil dari perangkat ini; token terisi = boleh dari jaringan Wi-Fi yang sama.
 */
@Serializable @SerialName("webhook")
data class WebhookTrigger(val hookPath: String = "halo", val token: String = "") : MacroTrigger

/** Tombol widget layar utama nomor 1-3 diketuk. */
@Serializable @SerialName("widget")
data class WidgetTrigger(val slot: Int = 1) : MacroTrigger

/** Tombol bulat melayang di atas aplikasi lain (bisa digeser). Butuh izin "Tampil di atas aplikasi lain". Maksimal 3 label berbeda. */
@Serializable @SerialName("floating")
data class FloatingButtonTrigger(val label: String = "Makro") : MacroTrigger

/** Makro lain selesai dijalankan. Rantai dibatasi 5 tingkat dan makro tidak memicu dirinya sendiri. */
@Serializable @SerialName("macro_done")
data class MacroDoneTrigger(val macroName: String = "") : MacroTrigger

/** Suhu baterai melewati ambang (derajat Celsius). Memicu hanya saat suhu melintasi ambang. */
@Serializable @SerialName("battery_temp")
data class BatteryTempTrigger(val celsius: Int = 40, val above: Boolean = true) : MacroTrigger

/** Jenis pengisi daya saat dicolok: any, ac, usb, wireless. */
@Serializable @SerialName("charger_type")
data class ChargerTypeTrigger(val plugType: String = "any") : MacroTrigger

/** Ponsel sedang dimatikan (siaran shutdown dari sistem). */
@Serializable @SerialName("shutdown")
object ShutdownTrigger : MacroTrigger

/** Baterai penuh (status penuh tercapai). */
@Serializable @SerialName("battery_full")
object BatteryFullTrigger : MacroTrigger

/** Zona waktu perangkat berubah. */
@Serializable @SerialName("timezone_changed")
object TimezoneChangedTrigger : MacroTrigger

/** Matahari terbit atau terbenam di lokasi (lintang dan bujur diketik), dengan selisih menit (boleh negatif). */
@Serializable @SerialName("sun")
data class SunTrigger(
    val sunrise: Boolean = true, val offsetMinutes: Int = 0, val lat: String = "-6.2", val lon: String = "106.8",
) : MacroTrigger

/** Aplikasi ditinggalkan (pindah ke aplikasi lain). Kosong = aplikasi apa pun. Butuh Aksesibilitas. */
@Serializable @SerialName("app_closed")
data class AppClosedTrigger(val pkg: String = "") : MacroTrigger

/** GPS atau lokasi perangkat dinyalakan atau dimatikan. */
@Serializable @SerialName("gps_state")
data class GpsStateTrigger(val on: Boolean = true) : MacroTrigger

/** Panggilan tersambung (telepon sedang aktif, masuk maupun keluar). Nomor hanya diketahui untuk panggilan masuk. */
@Serializable @SerialName("call_active")
data class CallActiveTrigger(val number: String = "") : MacroTrigger

/** Screensaver (daydream) mulai atau berhenti. */
@Serializable @SerialName("daydream")
data class DaydreamTrigger(val on: Boolean = true) : MacroTrigger

/** Mode tidur dalam (Doze) masuk atau keluar. */
@Serializable @SerialName("doze")
data class DozeTrigger(val on: Boolean = true) : MacroTrigger

/** Bahasa perangkat berubah. */
@Serializable @SerialName("locale_changed")
object LocaleChangedTrigger : MacroTrigger

/** Dipasang ke atau dilepas dari dok (mobil, meja, dan sejenisnya). */
@Serializable @SerialName("dock")
data class DockTrigger(val docked: Boolean = true) : MacroTrigger

/** Hotspot Wi-Fi menyala atau mati (bergantung pada siaran sistem perangkat). */
@Serializable @SerialName("hotspot")
data class HotspotTrigger(val on: Boolean = true) : MacroTrigger

/** NFC menyala atau mati. */
@Serializable @SerialName("nfc_state")
data class NfcStateTrigger(val on: Boolean = true) : MacroTrigger

/** Musik mulai atau berhenti diputar oleh aplikasi apa pun. */
@Serializable @SerialName("music")
data class MusicPlayingTrigger(val playing: Boolean = true) : MacroTrigger

/** Sensor cahaya melintasi ambang (lux). darker = menjadi lebih gelap dari ambang; mati = menjadi lebih terang. */
@Serializable @SerialName("light")
data class LightSensorTrigger(val lux: Int = 20, val darker: Boolean = true) : MacroTrigger

/** Layar berputar ke mendatar (nyala) atau tegak (mati), dibaca dari sensor gerak. */
@Serializable @SerialName("orientation")
data class OrientationTrigger(val landscape: Boolean = true) : MacroTrigger

/** Volume sebuah aliran suara berubah (siaran sistem, tidak resmi tetapi dipakai banyak aplikasi). */
@Serializable @SerialName("volume_changed")
data class VolumeChangedTrigger(val stream: String = "music") : MacroTrigger

/** Panggilan keluar dimulai (telepon pindah dari siaga ke tersambung tanpa berdering lebih dulu). Nomor tidak tersedia. */
@Serializable @SerialName("call_out")
object OutgoingCallTrigger : MacroTrigger

/** Tema gelap sistem menyala atau mati. */
@Serializable @SerialName("dark_theme")
data class DarkThemeTrigger(val on: Boolean = true) : MacroTrigger

/** VPN tersambung atau terputus. */
@Serializable @SerialName("vpn_state")
data class VpnStateTrigger(val connected: Boolean = true) : MacroTrigger

/** Internet (jaringan utama yang sudah tervalidasi) tersedia atau hilang. */
@Serializable @SerialName("internet_state")
data class InternetStateTrigger(val connected: Boolean = true) : MacroTrigger

/** Alarm berikutnya di jam sistem berubah: dibuat, diubah, dihapus, atau baru saja berbunyi. */
@Serializable @SerialName("next_alarm")
object NextAlarmChangedTrigger : MacroTrigger

/** Kecerahan layar diubah (diam sebentar setelah geseran selesai baru memicu). */
@Serializable @SerialName("brightness_changed")
object BrightnessChangedTrigger : MacroTrigger

/** Tombol pada notifikasi buatan aksi "Tampilkan notifikasi" diketuk. buttonLabel kosong = tombol apa pun. */
@Serializable @SerialName("notif_button")
data class NotificationButtonTrigger(val buttonLabel: String = "") : MacroTrigger

/** Aplikasi diperbarui (dipasang ulang di atas versi lama). Kosong = aplikasi apa pun. */
@Serializable @SerialName("app_updated")
data class AppUpdatedTrigger(val pkg: String = "") : MacroTrigger

/** Satu kali pada tanggal dan jam tertentu. Tanggal berbentuk tahun-bulan-hari, mis. 2026-12-31. */
@Serializable @SerialName("once")
data class OnceTrigger(val date: String = "2026-12-31", val hour: Int = 8, val minute: Int = 0) : MacroTrigger

/**
 * Rentang waktu: aksi dijalankan saat jam mulai, lalu saat jam selesai keadaan dikembalikan seperti sebelum mulai
 * (untuk aksi yang bisa dibaca keadaannya: sinkron data, Wi-Fi, Bluetooth, volume, dll). Boleh lintas tengah malam.
 * Hari berlaku untuk hari mulai.
 */
@Serializable @SerialName("time_window")
data class TimeWindowTrigger(
    val fromHour: Int = 8, val fromMinute: Int = 0, val toHour: Int = 17, val toMinute: Int = 0, val days: List<Int> = ALL_DAYS,
) : MacroTrigger

/** Menjalankan perintah shell lewat ADB bawaan tiap [everySeconds] detik (minimal 10). onChange nyala: memicu saat keluaran berubah. onChange mati: memicu saat keluaran mulai mengandung [contains]. Butuh pairing ADB. Keluaran jadi placeholder {shell_out}. */
@Serializable @SerialName("shell_output")
data class ShellOutputTrigger(
    val command: String = "dumpsys battery | grep -m1 temperature",
    val contains: String = "",
    val everySeconds: Int = 30,
    val onChange: Boolean = false,
) : MacroTrigger

/** Sebuah pengaturan sistem berubah (system, secure, atau global). Nilai kosong = nilai apa pun. Nilai baru jadi placeholder {setting_value}. */
@Serializable @SerialName("setting_changed")
data class SettingChangedTrigger(val ns: String = "global", val key: String = "", val value: String = "") : MacroTrigger

/** Mikrofon mulai atau berhenti dipakai aplikasi mana pun (termasuk MakroKu). */
@Serializable @SerialName("mic_active")
data class MicActiveTrigger(val active: Boolean = true) : MacroTrigger

/** Kamera mulai atau berhenti dipakai aplikasi mana pun (senter pada sebagian perangkat juga terhitung). */
@Serializable @SerialName("camera_active")
data class CameraActiveTrigger(val active: Boolean = true) : MacroTrigger

/** Gambar baru muncul di galeri: tangkapan layar, foto kamera, atau apa pun. Butuh izin membaca gambar. Nama berkas jadi {media_name}. */
@Serializable @SerialName("new_media")
data class NewMediaTrigger(val mediaKind: String = "screenshot") : MacroTrigger

/** Tulisan tertentu muncul di layar (dicek tiap 2 detik saat layar menyala). Butuh Aksesibilitas. Nama paket kosong = aplikasi apa pun. */
@Serializable @SerialName("screen_text")
data class ScreenTextTrigger(val text: String = "", val pkg: String = "") : MacroTrigger

/** Sambungan ADB bawaan tersambung atau terputus (dicek tiap 20 detik). */
@Serializable @SerialName("adb_state")
data class AdbStateTrigger(val connected: Boolean = false) : MacroTrigger

/** Proses sebuah aplikasi mulai atau berhenti berjalan (pidof lewat ADB, dicek tiap 10 detik). Nama paket wajib diisi. Nama paket jadi {app_pkg}. Butuh ADB. */
@Serializable @SerialName("app_running")
data class AppRunningTrigger(val pkg: String = "", val running: Boolean = true) : MacroTrigger

/** Aplikasi di depan berubah, dibaca lewat ADB tiap beberapa detik saat layar menyala, tanpa Aksesibilitas. Nama paket kosong = aplikasi apa pun. Nama paket jadi {app_pkg}, nama activity jadi {app_activity}. Butuh ADB. */
@Serializable @SerialName("foreground_adb")
data class ForegroundAdbTrigger(val pkg: String = "") : MacroTrigger

/** Berkas baru muncul di sebuah folder memori internal (dicek tiap 10 detik lewat ADB). Teks kosong = nama apa pun. Nama berkas jadi {file_name}, jalur lengkap jadi {file_path}. Butuh ADB. */
@Serializable @SerialName("new_file")
data class NewFileTrigger(val watchDir: String = "/sdcard/Download", val contains: String = "") : MacroTrigger

/** Aplikasi berhenti sendiri karena galat Java (crash), dibaca dari log crash lewat ADB tiap 15 detik. Nama paket kosong = aplikasi apa pun. Nama paket jadi {app_pkg}. Butuh ADB. */
@Serializable @SerialName("app_crash")
data class AppCrashTrigger(val pkg: String = "") : MacroTrigger

/** Tombol daya ditekan beberapa kali berturut-turut (tiap tekan menyalakan atau mematikan layar, jeda antar tekan paling lama 3 detik). Berlaku untuk 2 sampai 6 kali. */
@Serializable @SerialName("power_taps")
data class PowerButtonTrigger(val presses: Int = 3) : MacroTrigger

/** Layar sudah menyala (atau sudah mati) terus-menerus selama sekian menit. Pemicu berjalan sekali setelah waktu itu terlewati, tidak berulang. */
@Serializable @SerialName("screen_duration")
data class ScreenDurationTrigger(val screenOn: Boolean = true, val afterMinutes: Int = 30) : MacroTrigger

/** Panggilan masuk dari kontak yang namanya mengandung teks ini. Kosong = kontak mana pun yang tersimpan. Nama jadi {call_name}. Butuh izin Kontak. */
@Serializable @SerialName("call_contact")
data class CallContactTrigger(val contactName: String = "") : MacroTrigger

/** Senter (lampu kilat) menyala atau mati, dari mana pun penyebabnya. */
@Serializable @SerialName("torch_state")
data class TorchStateTrigger(val on: Boolean = true) : MacroTrigger

/** Pembaca layar (mode jelajah dengan sentuhan, mis. TalkBack) menyala atau mati. */
@Serializable @SerialName("screen_reader")
data class ScreenReaderStateTrigger(val on: Boolean = true) : MacroTrigger

/** Ponsel jatuh bebas atau dilempar: sensor percepatan hampir nol sesaat. */
@Serializable @SerialName("free_fall")
object FreeFallTrigger : MacroTrigger

/** Jaringan utama berpindah jenis: Wi-Fi, seluler, kabel, atau tidak ada. */
@Serializable @SerialName("network_type")
data class NetworkTypeTrigger(val netType: String = "wifi") : MacroTrigger

/** Pembungkus: pemicu dinonaktifkan lewat menu tekan-tahan. Tetap tersimpan, tetapi mesin melewatinya. */
@Serializable @SerialName("off")
data class OffTrigger(val item: MacroTrigger) : MacroTrigger

// ───────────────────────────── AKSI ─────────────────────────────
@Serializable
sealed interface MacroAction

@Serializable @SerialName("toast")
data class ToastAction(val text: String = "Halo dari MakroKu") : MacroAction

@Serializable @SerialName("notify")
data class NotificationAction(
    val title: String = "MakroKu", val text: String = "Makro dijalankan",
    val button1: String = "", val button2: String = "",
) : MacroAction

@Serializable @SerialName("vibrate")
data class VibrateAction(val ms: Long = 500) : MacroAction

@Serializable @SerialName("launch_app")
data class LaunchAppAction(val pkg: String = "") : MacroAction

@Serializable @SerialName("open_url")
data class OpenUrlAction(val url: String = "https://") : MacroAction

@Serializable @SerialName("wifi")
data class WifiAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("bluetooth")
data class BluetoothAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("volume")
data class VolumeAction(val stream: String = "music", val percent: Int = 50) : MacroAction

@Serializable @SerialName("ringer")
data class RingerModeAction(val ringerMode: String = "vibrate") : MacroAction

@Serializable @SerialName("dnd")
data class DndAction(val dndMode: String = "none") : MacroAction

@Serializable @SerialName("flashlight")
data class FlashlightAction(val on: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("send_sms")
data class SendSmsAction(val number: String = "", val text: String = "") : MacroAction

@Serializable @SerialName("call")
data class CallAction(val number: String = "") : MacroAction

@Serializable @SerialName("speak")
data class SpeakAction(val text: String = "Halo") : MacroAction

@Serializable @SerialName("play_sound")
data class PlaySoundAction(val uri: String = "") : MacroAction

@Serializable @SerialName("clipboard")
data class ClipboardAction(val text: String = "") : MacroAction

@Serializable @SerialName("brightness")
data class BrightnessAction(val percent: Int = 50) : MacroAction

@Serializable @SerialName("delay")
data class DelayAction(val seconds: Long = 5) : MacroAction

@Serializable @SerialName("set_variable")
data class SetVariableAction(val name: String = "variabel", val value: String = "1", val op: String = "set") : MacroAction

@Serializable @SerialName("http")
data class HttpRequestAction(
    val url: String = "https://", val method: String = "GET", val body: String = "", val headers: String = "",
    /** Nama variabel tujuan isi respons. Kosong = hanya http_response. */
    val saveTo: String = "",
    /** Batas waktu baca dan sambung, detik. */
    val timeout: Int = 15,
) : MacroAction

@Serializable @SerialName("send_intent")
data class IntentAction(
    val action: String = "", val data: String = "", val asActivity: Boolean = false,
    val pkg: String = "", val cls: String = "",
) : MacroAction

@Serializable @SerialName("if_variable")
data class IfVariableAction(
    val name: String = "variabel",
    val value: String = "1",
    val then: List<MacroAction> = emptyList(),
    val otherwise: List<MacroAction> = emptyList(),
) : MacroAction

/** Setara `settings put <ns> <key> <value>`. secure/global butuh WRITE_SECURE_SETTINGS (diberikan via ADB). */
@Serializable @SerialName("system_setting")
data class SystemSettingAction(val ns: String = "global", val key: String = "", val value: String = "") : MacroAction

/**
 * Jalankan perintah shell lewat sambungan ADB Wi-Fi bawaan (tanpa Shizuku, tanpa awalan "adb shell").
 * Mis. `pm grant paket izin`, `cmd appops set ...`, `am force-stop paket`. Keluaran bisa disimpan ke variabel.
 */
@Serializable @SerialName("adb_shell")
data class AdbShellAction(val command: String = "", val saveTo: String = "") : MacroAction

@Serializable @SerialName("mobile_data")
data class MobileDataAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("airplane")
data class AirplaneAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("nfc")
data class NfcAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("location")
data class LocationAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("force_stop")
data class ForceStopAction(val pkg: String = "") : MacroAction

@Serializable @SerialName("app_enable")
data class AppEnableAction(val pkg: String = "", val enable: Boolean = false) : MacroAction

@Serializable @SerialName("tap")
data class TapAction(val x: Int = 500, val y: Int = 1000) : MacroAction

@Serializable @SerialName("swipe")
data class SwipeAction(val x1: Int = 500, val y1: Int = 1500, val x2: Int = 500, val y2: Int = 500, val ms: Int = 300) : MacroAction

@Serializable @SerialName("key_event")
data class KeyEventAction(val keyName: String = "home") : MacroAction

@Serializable @SerialName("type_text")
data class TypeTextAction(val text: String = "") : MacroAction

@Serializable @SerialName("screenshot")
data class ScreenshotAction(val folder: String = "/sdcard/Pictures") : MacroAction

@Serializable @SerialName("global_action")
data class GlobalAction(val globalAct: String = "back") : MacroAction

@Serializable @SerialName("media")
data class MediaControlAction(val mediaCmd: String = "play_pause") : MacroAction

@Serializable @SerialName("volume_step")
data class VolumeStepAction(val stream: String = "music", val volDir: String = "up") : MacroAction

@Serializable @SerialName("speakerphone")
data class SpeakerphoneAction(val on: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("mic_mute")
data class MicMuteAction(val mute: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("screen_on")
data class ScreenOnAction(val seconds: Int = 10) : MacroAction

@Serializable @SerialName("rotation")
data class RotationAction(val rotation: String = "auto") : MacroAction

@Serializable @SerialName("screen_timeout")
data class ScreenTimeoutAction(val seconds: Int = 60) : MacroAction

@Serializable @SerialName("open_settings")
data class OpenSettingsAction(val panel: String = "wifi") : MacroAction

@Serializable @SerialName("set_alarm")
data class SetAlarmAction(val hour: Int = 7, val minute: Int = 0, val text: String = "MakroKu") : MacroAction

@Serializable @SerialName("set_timer")
data class SetTimerAction(val seconds: Int = 60, val text: String = "MakroKu") : MacroAction

@Serializable @SerialName("email")
data class EmailAction(val to: String = "", val subject: String = "", val body: String = "") : MacroAction

/** pkg kosong = hapus semua notifikasi. Butuh Akses Notifikasi. */
@Serializable @SerialName("clear_notifications")
data class ClearNotificationsAction(
    val pkg: String = "",
    /** Bila diisi, hanya hapus notifikasi yang judulnya mengandung teks ini (mis. {notif_title} = pengirim yang sama). */
    val titleContains: String = "",
) : MacroAction

@Serializable @SerialName("loop")
data class LoopAction(val times: Int = 3, val actions: List<MacroAction> = emptyList()) : MacroAction

@Serializable @SerialName("stop_macro")
data class StopMacroAction(val reason: String = "") : MacroAction

@Serializable @SerialName("run_macro")
data class RunMacroAction(val macro: String = "", val par1: String = "", val par2: String = "", val par3: String = "") : MacroAction

@Serializable @SerialName("if_compare")
data class IfCompareAction(
    val name: String = "variabel",
    val cmp: String = "==",
    val value: String = "0",
    val then: List<MacroAction> = emptyList(),
    val otherwise: List<MacroAction> = emptyList(),
) : MacroAction

/** Jika semua batasan terpenuhi jalankan [then], bila tidak jalankan [otherwise]. Batasan bisa bersarang (AND/OR/XOR/NOT). */
@Serializable @SerialName("if_constraint")
data class IfConstraintAction(
    val constraints: List<MacroConstraint> = emptyList(),
    val then: List<MacroAction> = emptyList(),
    val otherwise: List<MacroAction> = emptyList(),
) : MacroAction

@Serializable @SerialName("random_variable")
data class RandomVariableAction(val name: String = "acak", val min: Int = 1, val max: Int = 100) : MacroAction

@Serializable @SerialName("log")
data class LogAction(val text: String = "") : MacroAction

/** Setara tombol "Sinkronisasi data otomatis" di pengaturan akun. */
@Serializable @SerialName("sync")
data class SyncAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("auto_brightness")
data class AutoBrightnessAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("battery_saver")
data class BatterySaverAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

@Serializable @SerialName("dark_mode")
data class DarkModeAction(val darkMode: String = "yes") : MacroAction

@Serializable @SerialName("enable_macro")
data class EnableMacroAction(val macro: String = "", val enable: Boolean = true) : MacroAction

@Serializable @SerialName("share_text")
data class ShareTextAction(val text: String = "") : MacroAction

@Serializable @SerialName("open_camera")
object OpenCameraAction : MacroAction

@Serializable @SerialName("write_file")
data class WriteFileAction(val fileName: String = "catatan.txt", val text: String = "{date} {time}", val append: Boolean = true) : MacroAction

@Serializable @SerialName("clear_log")
object ClearLogAction : MacroAction

@Serializable @SerialName("find_phone")
data class FindPhoneAction(val seconds: Int = 20) : MacroAction

@Serializable @SerialName("stop_speak")
object StopSpeakAction : MacroAction

@Serializable @SerialName("if_time")
data class IfTimeAction(
    val fromHour: Int = 22, val fromMinute: Int = 0, val toHour: Int = 6, val toMinute: Int = 0,
    val then: List<MacroAction> = emptyList(),
    val otherwise: List<MacroAction> = emptyList(),
) : MacroAction

@Serializable @SerialName("if_battery")
data class IfBatteryAction(
    val level: Int = 20, val below: Boolean = true,
    val then: List<MacroAction> = emptyList(),
    val otherwise: List<MacroAction> = emptyList(),
) : MacroAction

@Serializable @SerialName("whatsapp")
data class WhatsAppAction(val number: String = "", val text: String = "", val business: Boolean = false) : MacroAction

/** Kecepatan dan nada suara TTS dalam persen (100 = normal). */
@Serializable @SerialName("tts_settings")
data class SetTtsAction(val rate: Int = 100, val pitch: Int = 100) : MacroAction

/** Menunggu sampai variabel memenuhi syarat. Bila waktu habis, makro berhenti. */
@Serializable @SerialName("wait_until")
data class WaitUntilAction(val name: String = "variabel", val cmp: String = "==", val value: String = "1", val timeout: Int = 60) : MacroAction

/** Ketuk tombol/teks di layar lewat Aksesibilitas (tanpa ADB). Mengulang pencarian sampai batas waktu. */
@Serializable @SerialName("click_text")
data class ClickTextAction(val text: String = "", val timeout: Int = 5, val longClick: Boolean = false) : MacroAction

/** Ketuk elemen layar berdasarkan ID tampilannya (mis. com.whatsapp:id/send) lewat Aksesibilitas. Setara klik "ID tampilan" MacroDroid. */
@Serializable @SerialName("click_id")
data class ClickIdAction(val viewId: String = "", val timeout: Int = 5, val longClick: Boolean = false) : MacroAction

/**
 * Tunggu sampai tulisan [text] muncul di layar (butuh Aksesibilitas). [pkg] kosong = aplikasi apa pun.
 * [timeout] detik (0 = 120 detik). Waktu habis: makro berhenti, atau lanjut bila [continueOnTimeout]. Setara "Tunggu pemicu: isi layar" MacroDroid.
 */
@Serializable @SerialName("wait_screen_text")
data class WaitScreenTextAction(
    val text: String = "", val pkg: String = "", val timeout: Int = 0, val continueOnTimeout: Boolean = false,
) : MacroAction

@Serializable @SerialName("scroll")
data class ScrollAction(val scrollDir: String = "down") : MacroAction

/** Mengisi kolom teks yang sedang fokus. */
@Serializable @SerialName("set_focused_text")
data class SetFocusedTextAction(val text: String = "", val appendText: Boolean = false) : MacroAction

/** Menyimpan semua teks yang terlihat di layar ke variabel. */
@Serializable @SerialName("read_screen")
data class ReadScreenAction(val saveTo: String = "teks_layar", val maxChars: Int = 2000) : MacroAction

/** Operasi teks: upper, lower, trim, length, replace, substring, regex, split, digits. */
@Serializable @SerialName("text_op")
data class TextOpAction(
    val text: String = "{var:http_response}", val textOp: String = "upper",
    val arg: String = "", val arg2: String = "", val saveTo: String = "hasil",
) : MacroAction

/** Hitung ekspresi: + - * / % dan kurung, boleh memakai {var:x}. */
@Serializable @SerialName("math")
data class MathAction(val expr: String = "{var:a}+1", val saveTo: String = "hasil") : MacroAction

/** Ambil nilai dari JSON dengan jalur, mis. data.items.0.name. */
@Serializable @SerialName("json_pick")
data class JsonPickAction(val json: String = "{var:http_response}", val path: String = "", val saveTo: String = "hasil") : MacroAction

@Serializable @SerialName("while_loop")
data class WhileAction(
    val name: String = "variabel", val cmp: String = "<", val value: String = "5", val maxLoops: Int = 100,
    val actions: List<MacroAction> = emptyList(),
) : MacroAction

/** Ulangi aksi selama semua batasan terpenuhi (mis. notifikasi panggilan masih ada). Berhenti setelah [maxLoops] putaran. */
@Serializable @SerialName("while_constraint")
data class WhileConstraintAction(
    val constraints: List<MacroConstraint> = emptyList(),
    val maxLoops: Int = 300,
    val actions: List<MacroAction> = emptyList(),
) : MacroAction

/** Catatan di dalam makro, tidak melakukan apa-apa. */
@Serializable @SerialName("note")
data class NoteAction(val text: String = "Catatan") : MacroAction

/** Simpan tanggal atau jam sekarang ke variabel. Format Java, mis. yyyy-MM-dd HH:mm:ss atau EEEE. */
@Serializable @SerialName("datetime_var")
data class DateTimeVarAction(val format: String = "yyyy-MM-dd HH:mm", val saveTo: String = "waktu") : MacroAction

/** Simpan level baterai (persen) ke variabel. */
@Serializable @SerialName("battery_var")
data class BatteryVarAction(val saveTo: String = "baterai") : MacroAction

/** Bunyi bip pendek lewat pengeras suara. */
@Serializable @SerialName("beep")
data class BeepAction(val ms: Long = 300) : MacroAction

/** Baca berkas teks dari folder data aplikasi ke variabel (pasangan aksi tulis berkas). */
@Serializable @SerialName("read_file")
data class ReadFileAction(val fileName: String = "catatan.txt", val saveTo: String = "isi_berkas") : MacroAction

/** Simpan volume sebuah aliran suara (persen) ke variabel. */
@Serializable @SerialName("volume_var")
data class VolumeVarAction(val stream: String = "music", val saveTo: String = "volume") : MacroAction

/** Simpan info baterai ke variabel: temp (derajat Celsius), voltage (mV), status, health, plug. */
@Serializable @SerialName("battery_info_var")
data class BatteryInfoVarAction(val info: String = "temp", val saveTo: String = "info_baterai") : MacroAction

/** Hapus berkas teks di folder data aplikasi. */
@Serializable @SerialName("delete_file")
data class DeleteFileAction(val fileName: String = "catatan.txt") : MacroAction

/** Simpan ruang penyimpanan kosong (megabita) ke variabel. */
@Serializable @SerialName("storage_var")
data class StorageVarAction(val saveTo: String = "ruang_kosong_mb") : MacroAction

/** Balas notifikasi terbaru yang punya kolom balasan (chat). pkg kosong = aplikasi dari notifikasi pemicu. Butuh Akses Notifikasi. */
@Serializable @SerialName("reply_notification")
data class ReplyNotificationAction(val pkg: String = "", val text: String = "{notif_text}") : MacroAction

/** Ketuk (buka) notifikasi terbaru milik sebuah aplikasi. Butuh Akses Notifikasi. */
@Serializable @SerialName("tap_notification")
data class TapNotificationAction(val pkg: String = "") : MacroAction

/** Simpan judul atau isi notifikasi aktif terbaru sebuah aplikasi ke variabel. Butuh Akses Notifikasi. */
@Serializable @SerialName("notif_to_var")
data class NotifToVarAction(val pkg: String = "", val notifPart: String = "text", val saveTo: String = "notifikasi") : MacroAction

/** Pesan popup berupa dialog dengan tombol OK. Detik 0 = tetap sampai ditutup. Butuh izin Tampil di atas aplikasi lain. */
@Serializable @SerialName("popup")
data class PopupAction(val title: String = "MakroKu", val text: String = "Halo dari MakroKu", val seconds: Int = 0) : MacroAction

/** Atur nada dering, notifikasi, atau alarm bawaan. uri berupa content://... ; kosong = senyap. Butuh izin Ubah pengaturan sistem. */
@Serializable @SerialName("set_ringtone")
data class SetRingtoneAction(val ringKind: String = "ringtone", val uri: String = "") : MacroAction

/** Atur wallpaper dari berkas gambar di folder data aplikasi (Android/data/com.makroku.automation/files). */
@Serializable @SerialName("set_wallpaper")
data class SetWallpaperAction(val fileName: String = "wallpaper.jpg", val wallTarget: String = "home") : MacroAction

/** Blok aksi: kumpulan aksi bernama yang bisa dipakai ulang di banyak makro (aksi "Jalankan blok aksi"). */
@Serializable
data class ActionBlock(val name: String, val actions: List<MacroAction> = emptyList())

/** Menjalankan blok aksi tersimpan menurut namanya. */
@Serializable @SerialName("run_block")
data class RunBlockAction(val block: String = "") : MacroAction

/**
 * Setara aksi "Keep Device Awake" di MacroDroid: menjaga perangkat tetap terjaga sampai dimatikan atau selama sekian detik.
 * enable mati = matikan penjagaan. awakeScreen: screen_on (layar tetap menyala) atau cpu_only (hanya CPU, layar boleh mati).
 * awakeSeconds 0 = sampai dimatikan lewat aksi ini juga.
 */
@Serializable @SerialName("keep_awake")
data class KeepAwakeAction(val enable: Boolean = true, val awakeScreen: String = "screen_on", val awakeSeconds: Int = 0) : MacroAction

/** Ucapkan jam sekarang lewat TTS. */
@Serializable @SerialName("say_time")
data class SayTimeAction(val withDate: Boolean = false) : MacroAction

/** Ucapkan level baterai lewat TTS. */
@Serializable @SerialName("say_battery")
object SayBatteryAction : MacroAction

@Serializable @SerialName("open_call_log")
object OpenCallLogAction : MacroAction

/** Membuka aplikasi telepon dengan nomor terisi, tanpa menelepon. */
@Serializable @SerialName("dial")
data class DialNumberAction(val number: String = "") : MacroAction

/** Memunculkan dialog sistem untuk mencopot aplikasi (perlu konfirmasi pengguna). */
@Serializable @SerialName("uninstall_app")
data class UninstallAppAction(val pkg: String = "") : MacroAction

@Serializable @SerialName("app_info")
data class AppInfoAction(val pkg: String = "") : MacroAction

@Serializable @SerialName("open_map")
data class OpenMapAction(val query: String = "") : MacroAction

/** Membuka formulir acara baru di aplikasi kalender dengan kolom terisi. */
@Serializable @SerialName("add_calendar_event")
data class AddCalendarEventAction(val title: String = "", val details: String = "", val place: String = "") : MacroAction

/** Pola getar: angka dipisah koma dalam milidetik, berselang jeda lalu getar, mis. 0,200,100,200. */
@Serializable @SerialName("vibrate_pattern")
data class VibratePatternAction(val pattern: String = "0,200,100,200,100,400") : MacroAction

@Serializable @SerialName("clear_clipboard")
object ClearClipboardAction : MacroAction

/** Menjawab panggilan masuk. Butuh izin Jawab panggilan telepon. */
@Serializable @SerialName("answer_call")
object AnswerCallAction : MacroAction

/** Mengakhiri panggilan yang sedang berlangsung. Butuh izin Jawab panggilan telepon. */
@Serializable @SerialName("end_call")
object EndCallAction : MacroAction

/** Menghapus seluruh riwayat panggilan. Butuh izin Tulis riwayat panggilan. */
@Serializable @SerialName("clear_call_log")
object ClearCallLogAction : MacroAction

/** Jeda acak antara dua batas (detik). */
@Serializable @SerialName("random_delay")
data class RandomDelayAction(val minSeconds: Int = 1, val maxSeconds: Int = 5) : MacroAction

/** Kirim paket UDP berisi teks ke alamat dan port tujuan. */
@Serializable @SerialName("udp_send")
data class UdpSendAction(val host: String = "192.168.1.255", val port: Int = 9, val text: String = "") : MacroAction

/** Kirim paket Wake-on-LAN (magic packet) untuk membangunkan komputer di jaringan yang sama. */
@Serializable @SerialName("wake_on_lan")
data class WakeOnLanAction(val mac: String = "", val host: String = "255.255.255.255", val port: Int = 9) : MacroAction

/** Simpan info perangkat ke variabel: model, manufacturer, brand, device, android, sdk. */
@Serializable @SerialName("device_info_var")
data class DeviceInfoVarAction(val deviceInfo: String = "model", val saveTo: String = "info_hp") : MacroAction

/** Simpan lokasi terakhir yang diketahui: variabel berisi "lintang,bujur" ditambah nama_lat dan nama_lon. Butuh izin lokasi. */
@Serializable @SerialName("location_var")
data class LocationVarAction(val saveTo: String = "lokasi") : MacroAction

/** Keluar dari ulangan atau perulangan "selama" terdekat. Di luar ulangan, dicatat sebagai galat. */
@Serializable @SerialName("break_loop")
object BreakLoopAction : MacroAction

/** Lompat ke putaran berikutnya di ulangan atau perulangan "selama" terdekat. */
@Serializable @SerialName("continue_loop")
object ContinueLoopAction : MacroAction

/** Stopwatch bernama. Detik berjalan disimpan ke variabel. Perintah: start, pause, resume, stop, reset, read. Hilang bila proses dimatikan sistem. */
@Serializable @SerialName("stopwatch")
data class StopwatchAction(val swName: String = "stopwatch", val swCmd: String = "start", val saveTo: String = "") : MacroAction

/** Matikan atau mulai ulang ponsel lewat ADB bawaan. */
@Serializable @SerialName("power_cmd")
data class PowerCommandAction(val powerCmd: String = "reboot") : MacroAction

/** Hentikan proses latar belakang sebuah aplikasi lewat ADB (am kill). Beda dengan paksa berhenti. */
@Serializable @SerialName("kill_background")
data class KillBackgroundAction(val pkg: String = "") : MacroAction

/** Rekam layar lewat ADB (maksimal 180 detik). Berkas mp4 disimpan di /sdcard/Movies. */
@Serializable @SerialName("screen_record")
data class ScreenRecordAction(val seconds: Int = 10, val fileName: String = "rekam") : MacroAction

/** Buka asisten suara bawaan perangkat. */
@Serializable @SerialName("assistant")
object AssistantAction : MacroAction

/** Kirim kode USSD (mis. *123#) lewat aplikasi telepon. Butuh izin telepon. */
@Serializable @SerialName("ussd")
data class UssdAction(val code: String = "*123#") : MacroAction

/** Aktifkan atau matikan semua makro dalam satu kategori. Kategori kosong = semua makro kecuali makro ini. */
@Serializable @SerialName("enable_category")
data class EnableCategoryAction(val category: String = "", val enable: Boolean = true) : MacroAction

/** Unduh berkas dari internet ke folder data aplikasi (maksimal 50 MB). Ukuran masuk ke variabel unduh_ukuran. */
@Serializable @SerialName("download_file")
data class DownloadFileAction(val url: String = "https://", val fileName: String = "unduhan.bin") : MacroAction

/** Uji jangkauan: port 0 = ping ICMP, port lain = coba sambung TCP. Hasil (true atau false) ke variabel, waktu (ms) ke variabel_ms. */
@Serializable @SerialName("ping")
data class PingAction(val host: String = "8.8.8.8", val port: Int = 0, val timeoutMs: Int = 3000, val saveTo: String = "ping") : MacroAction

/** Simpan info jaringan ke variabel: ssid, ip, signal (dBm Wi-Fi), net_type, operator. */
@Serializable @SerialName("network_var")
data class NetworkInfoVarAction(val netInfo: String = "ssid", val saveTo: String = "info_jaringan") : MacroAction

/** Simpan isi papan klip ke variabel. Android 10 ke atas sering melarang aplikasi latar membacanya. */
@Serializable @SerialName("clipboard_var")
data class ClipboardVarAction(val saveTo: String = "papan_klip") : MacroAction

/** Dialog isian teks. Jawaban masuk ke variabel; bila dibatalkan atau waktu habis, makro berhenti. Butuh izin Tampil di atas aplikasi lain. */
@Serializable @SerialName("input_prompt")
data class InputPromptAction(
    val title: String = "MakroKu", val text: String = "Ketik jawaban Anda", val defaultText: String = "",
    val numeric: Boolean = false, val saveTo: String = "jawaban", val seconds: Int = 120,
) : MacroAction

/** Atur ukuran font sistem dalam persen (100 = normal). Butuh izin Ubah pengaturan sistem atau ADB. */
@Serializable @SerialName("font_scale")
data class FontScaleAction(val fontPercent: Int = 100) : MacroAction

/** Warna layar: normal, terbalik, atau abu-abu. Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("display_color")
data class DisplayColorAction(val colorMode: String = "normal") : MacroAction

/** Operasi berkas di folder data aplikasi: copy, move, exists, size. exists dan size menyimpan hasil ke variabel. */
@Serializable @SerialName("file_op")
data class FileOpAction(
    val fileOp: String = "copy", val fromFile: String = "catatan.txt", val toFile: String = "salinan.txt", val saveTo: String = "hasil_berkas",
) : MacroAction

/** Hentikan suara yang diputar oleh aksi "Putar suara". */
@Serializable @SerialName("stop_sound")
object StopSoundAction : MacroAction

/** Buka panel notifikasi, panel pengaturan cepat, atau tutup panel lewat ADB. */
@Serializable @SerialName("statusbar")
data class StatusBarAction(val barCmd: String = "notifications") : MacroAction

/** Hapus seluruh data sebuah aplikasi (pm clear). Tidak bisa dibatalkan. Butuh ADB. */
@Serializable @SerialName("clear_app_data")
data class ClearAppDataAction(val pkg: String = "") : MacroAction

/** Beri atau cabut satu izin runtime aplikasi lain (pm grant atau pm revoke). Butuh ADB. */
@Serializable @SerialName("permission")
data class PermissionAction(val pkg: String = "", val permission: String = "android.permission.POST_NOTIFICATIONS", val grant: Boolean = true) : MacroAction

/** Atur izin khusus aplikasi lewat appops, mis. RUN_IN_BACKGROUND atau SYSTEM_ALERT_WINDOW. Butuh ADB. */
@Serializable @SerialName("appops")
data class AppOpsAction(val pkg: String = "", val appOp: String = "RUN_IN_BACKGROUND", val appopMode: String = "allow") : MacroAction

/** Izinkan atau larang aplikasi berjalan di latar belakang (appops RUN_ANY_IN_BACKGROUND dan RUN_IN_BACKGROUND). Butuh ADB. */
@Serializable @SerialName("bg_restrict")
data class BackgroundRestrictAction(val pkg: String = "", val allow: Boolean = false) : MacroAction

/** Jalankan activity, layanan, atau siaran lewat am (ADB). Extra: satu per baris kunci=nilai (true atau false = boolean, angka = integer, lainnya teks). */
@Serializable @SerialName("adb_am")
data class AdbAmAction(
    val amKind: String = "activity", val intentAction: String = "", val data: String = "",
    val component: String = "", val extras: String = "",
) : MacroAction

/** Ubah ukuran atau kepadatan layar (wm size, wm density). Butuh ADB. */
@Serializable @SerialName("wm")
data class WmAction(val wmCmd: String = "size", val wmValue: String = "1080x2400") : MacroAction

/** Ketuk lama di satu titik layar. Butuh ADB. */
@Serializable @SerialName("long_tap")
data class LongTapAction(val x: Int = 500, val y: Int = 1000, val ms: Int = 800) : MacroAction

/** Ketuk dua kali di satu titik layar. Butuh ADB. */
@Serializable @SerialName("double_tap")
data class DoubleTapAction(val x: Int = 500, val y: Int = 1000) : MacroAction

/** Seret dari satu titik lalu lepas di titik lain (drag and drop). Butuh ADB. */
@Serializable @SerialName("drag")
data class DragAction(val x1: Int = 500, val y1: Int = 1500, val x2: Int = 500, val y2: Int = 500, val ms: Int = 600) : MacroAction

/** Ketuk elemen layar berdasarkan tulisan atau deskripsinya lewat uiautomator (ADB), tanpa layanan Aksesibilitas. */
@Serializable @SerialName("click_text_adb")
data class ClickTextAdbAction(val text: String = "", val timeout: Int = 5, val longClick: Boolean = false) : MacroAction

/** Simpan nama paket aplikasi di depan ke variabel (dan nama_activity). Pakai ADB bila ada, bila tidak pakai Aksesibilitas. */
@Serializable @SerialName("foreground_var")
data class ForegroundAppVarAction(val saveTo: String = "aplikasi_depan") : MacroAction

/** Simpan info sebuah aplikasi ke variabel: versi, terpasang, aktif, sedang berjalan, atau lokasi berkas. Butuh ADB. */
@Serializable @SerialName("app_info_var")
data class AppInfoVarAction(val pkg: String = "", val appInfoKind: String = "version", val saveTo: String = "info_app") : MacroAction

/** Simpan nilai properti sistem (getprop) ke variabel. Butuh ADB. */
@Serializable @SerialName("getprop")
data class GetPropAction(val prop: String = "ro.build.version.release", val saveTo: String = "properti") : MacroAction

/** Simpan nilai sebuah pengaturan sistem (system, secure, global) ke variabel. Tanpa ADB. */
@Serializable @SerialName("get_setting")
data class GetSettingAction(val ns: String = "secure", val key: String = "default_input_method", val saveTo: String = "pengaturan") : MacroAction

/** Masukkan atau keluarkan aplikasi dari daftar putih penghemat baterai (Doze). Butuh ADB. */
@Serializable @SerialName("doze_whitelist")
data class DozeWhitelistAction(val pkg: String = "", val add: Boolean = true) : MacroAction

/** Nyalakan layar, geser ke atas, ketik PIN, lalu Enter lewat ADB. PIN disimpan apa adanya di data makro dan ikut terekspor. */
@Serializable @SerialName("unlock_pin")
data class UnlockPinAction(val pin: String = "") : MacroAction

/** Pasang berkas APK dari memori internal secara diam-diam (pm install -r). Butuh ADB. Jalur harus di /sdcard, /storage/emulated/0, atau /data/local/tmp. */
@Serializable @SerialName("install_apk")
data class InstallApkAction(val apkPath: String = "/sdcard/Download/aplikasi.apk") : MacroAction

/** Copot aplikasi tanpa dialog konfirmasi (pm uninstall). Butuh ADB. */
@Serializable @SerialName("silent_uninstall")
data class SilentUninstallAction(val pkg: String = "", val keepData: Boolean = false) : MacroAction

/** Operasi berkas di memori internal lewat shell: salin, pindah, hapus, buat folder, cek ada, ukuran, daftar, baca. Butuh ADB. */
@Serializable @SerialName("shell_file")
data class ShellFileAction(val shellFileOp: String = "copy", val src: String = "/sdcard/", val dst: String = "", val saveTo: String = "hasil_berkas") : MacroAction

/** Sambungkan ke jaringan Wi-Fi tertentu (cmd wifi connect-network, Android 11 ke atas). Butuh ADB. */
@Serializable @SerialName("wifi_connect")
data class WifiConnectAction(val netName: String = "", val wifiSec: String = "wpa2", val netPassword: String = "") : MacroAction

/** Nyalakan atau matikan hotspot Wi-Fi (cmd wifi start-softap, paling andal di Android 12 ke atas). Butuh ADB. */
@Serializable @SerialName("hotspot_set")
data class HotspotAction(val enable: Boolean = true, val netName: String = "MakroKu", val netPassword: String = "12345678") : MacroAction

/** Atur DNS pribadi: mati, otomatis, atau nama host. Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("private_dns")
data class PrivateDnsAction(val dnsMode: String = "hostname", val dnsHost: String = "dns.google") : MacroAction

/** Skala animasi sistem dalam persen (0 = mati, 100 = normal). Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("animation_scale")
data class AnimationScaleAction(val scalePercent: Int = 0) : MacroAction

/** Pilih keyboard (metode input) aktif, mis. com.paket/.LayananKeyboard. Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("ime_set")
data class ImeSetAction(val imeId: String = "") : MacroAction

/** Nyalakan atau matikan layanan Aksesibilitas tertentu, mis. pembaca layar lain. Format paket/kelas. Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("a11y_service")
data class A11yServiceAction(val component: String = "", val enable: Boolean = true) : MacroAction

/** Ganti mesin suara (TTS) bawaan sistem dan, bila angka lebih dari 0, kecepatan bicaranya dalam persen. Butuh WRITE_SECURE_SETTINGS atau ADB. */
@Serializable @SerialName("tts_engine")
data class TtsEngineAction(val pkg: String = "", val ttsRate: Int = 0) : MacroAction

/** Bekukan atau lepaskan aplikasi (pm suspend atau pm unsuspend). Aplikasi beku tidak bisa dibuka. Pembaca layar, keyboard aktif, dan MakroKu ditolak demi keamanan. Butuh ADB. */
@Serializable @SerialName("suspend_app")
data class SuspendAppAction(val pkg: String = "", val freeze: Boolean = true) : MacroAction

/** Atur bucket siaga aplikasi (am set-standby-bucket): seberapa sering aplikasi boleh jalan di latar. Butuh ADB. */
@Serializable @SerialName("standby_bucket")
data class StandbyBucketAction(val pkg: String = "", val bucket: String = "active") : MacroAction

/** Jadikan sebuah peluncur (launcher) layar utama bawaan (cmd package set-home-activity). Isi komponen paket/kelas. Butuh ADB. */
@Serializable @SerialName("set_home_app")
data class SetHomeAppAction(val component: String = "") : MacroAction

/** Simpan daftar nama paket terpasang ke variabel, dipisah koma, dan jumlahnya ke variabel nama_jumlah. Kata kosong = semua. Butuh ADB. */
@Serializable @SerialName("list_packages")
data class ListPackagesAction(val contains: String = "", val userOnly: Boolean = true, val saveTo: String = "daftar_aplikasi") : MacroAction

/** Baca penyedia konten lewat shell (content query), mis. SMS terakhir. Baris pertama jadi isi variabel, jumlah baris di nama_jumlah. Kolom dipisah koma. Butuh ADB. */
@Serializable @SerialName("content_query")
data class ContentQueryAction(
    val providerUri: String = "content://sms/inbox", val projection: String = "body",
    val whereClause: String = "", val sortOrder: String = "date DESC LIMIT 1", val saveTo: String = "hasil_kueri",
) : MacroAction

/** Nyalakan atau matikan Penghemat Data (cmd netpolicy restrict-background). Butuh ADB. */
@Serializable @SerialName("data_saver")
data class DataSaverAction(val enable: Boolean = true, val toggle: Boolean = false) : MacroAction

/** Layar tetap menyala saat dicolok ke pengisi daya (svc power stayon). Butuh ADB. */
@Serializable @SerialName("stay_on")
data class StayOnAction(val stayMode: String = "true") : MacroAction

/** Atur mode USB saat dicolok ke komputer (svc usb setFunctions). Butuh ADB. */
@Serializable @SerialName("usb_mode")
data class UsbModeAction(val usbMode: String = "mtp") : MacroAction

/** Bersihkan cache semua aplikasi sampai ruang kosong mencapai sekian megabita (pm trim-caches). Bila ruang kosong sudah lebih besar, tidak ada yang dibersihkan. Butuh ADB. */
@Serializable @SerialName("trim_caches")
data class TrimCachesAction(val trimMb: Int = 2048) : MacroAction

/** Simpan true atau false ke variabel: apakah sebuah aplikasi sedang diberi izin tertentu (dumpsys package). Butuh ADB. */
@Serializable @SerialName("permission_check")
data class PermissionCheckAction(val pkg: String = "", val permission: String = "android.permission.CAMERA", val saveTo: String = "izin_diberi") : MacroAction

/** Simpan info memori RAM ke variabel: tersedia (MB), total (MB), persen tersedia, atau memori sedang rendah. Tanpa ADB. */
@Serializable @SerialName("ram_var")
data class RamVarAction(val ramInfo: String = "free_mb", val saveTo: String = "ram") : MacroAction

/** Simpan suhu dari sensor termal ke variabel dalam derajat Celsius: CPU, baterai, atau yang tertinggi. Butuh ADB. */
@Serializable @SerialName("thermal_var")
data class ThermalVarAction(val thermalKind: String = "cpu", val saveTo: String = "suhu") : MacroAction

/** Simpan baris log sistem terbaru (logcat) ke variabel, bisa disaring dengan teks. Jumlah baris di nama_jumlah. Butuh ADB. */
@Serializable @SerialName("logcat_var")
data class LogcatVarAction(val contains: String = "", val lines: Int = 200, val saveTo: String = "log_sistem") : MacroAction

/** Mulai ulang aplikasi: hentikan paksa, tunggu sebentar, lalu buka lagi. Butuh ADB. */
@Serializable @SerialName("restart_app")
data class RestartAppAction(val pkg: String = "", val waitSeconds: Int = 1) : MacroAction

/** Cari nama kontak dari sebuah nomor telepon lalu simpan ke variabel. Bila tidak ditemukan, yang disimpan nomornya sendiri supaya tetap bisa diucapkan. Butuh izin Kontak. */
@Serializable @SerialName("contact_name")
data class ContactNameVarAction(val number: String = "{call_number}", val saveTo: String = "nama_kontak") : MacroAction

/** Kedipkan senter beberapa kali: nyala sekian milidetik, mati sekian milidetik. Senter kembali mati di akhir. */
@Serializable @SerialName("flash_blink")
data class FlashBlinkAction(val count: Int = 3, val onMs: Int = 200, val offMs: Int = 200) : MacroAction

/** Tunggu sampai jam tertentu (hari ini atau besok), lalu lanjut ke aksi berikutnya. Batas tunggu paling lama 30 menit karena makro hanya menjaga CPU selama itu; bila lebih lama dari batas, makro berhenti. Untuk jam yang lebih jauh pakai pemicu jadwal waktu. */
@Serializable @SerialName("wait_until_time")
data class WaitUntilTimeAction(val hour: Int = 8, val minute: Int = 0, val maxMinutes: Int = 30) : MacroAction

/** Hitung tanggal dan jam dari sekarang ditambah atau dikurangi sekian satuan, lalu simpan ke variabel dengan format tertentu. Angka negatif berarti mundur. */
@Serializable @SerialName("date_math")
data class DateMathVarAction(
    val amount: Int = 1, val dateUnit: String = "day", val format: String = "yyyy-MM-dd", val saveTo: String = "tanggal_hasil",
) : MacroAction

/** Pilih satu baris secara acak dari daftar (satu pilihan per baris) lalu simpan ke variabel. */
@Serializable @SerialName("random_pick")
data class RandomPickAction(val items: String = "Satu\nDua\nTiga", val saveTo: String = "pilihan") : MacroAction

/** Ucapkan teks dengan angka dibaca satu per satu (mis. nomor telepon). Tanda plus dibaca "plus". */
@Serializable @SerialName("speak_digits")
data class SpeakDigitsAction(val text: String = "{call_number}") : MacroAction

/** Simpan nomor dan nama dari panggilan terakhir di riwayat ke variabel. Jenis: apa saja, masuk, keluar, atau terlewat. Butuh izin Log Panggilan. */
@Serializable @SerialName("last_call_var")
data class LastCallVarAction(val callType: String = "any", val saveTo: String = "nomor_terakhir", val saveNameTo: String = "nama_terakhir") : MacroAction

/** Buat teks acak (angka, huruf, campuran, atau heksadesimal) lalu simpan ke variabel. */
@Serializable @SerialName("generate_text")
data class GenerateTextAction(val length: Int = 8, val genKind: String = "alnum", val saveTo: String = "teks_acak") : MacroAction

/** Telepon kontak berdasarkan nama. Nama cukup sebagian. Bila "langsung" mati, hanya membuka pemanggil nomor. Butuh izin Kontak dan Telepon. */
@Serializable @SerialName("call_contact")
data class CallContactAction(val contact: String = "", val directCall: Boolean = true) : MacroAction

/** Kirim SMS ke kontak berdasarkan nama. Nama cukup sebagian. Butuh izin Kontak dan SMS. */
@Serializable @SerialName("sms_contact")
data class SmsContactAction(val contact: String = "", val text: String = "") : MacroAction

/** Pembungkus: aksi dinonaktifkan lewat menu tekan-tahan. Tetap tersimpan, tetapi dilewati saat makro jalan. */
@Serializable @SerialName("off")
data class OffAction(val item: MacroAction) : MacroAction

// ───────────────────────────── BATASAN ─────────────────────────────
@Serializable
sealed interface MacroConstraint

@Serializable @SerialName("time_range")
data class TimeRangeConstraint(
    val fromHour: Int = 22, val fromMinute: Int = 0, val toHour: Int = 7, val toMinute: Int = 0,
) : MacroConstraint

@Serializable @SerialName("day")
data class DayConstraint(val days: List<Int> = listOf(2, 3, 4, 5, 6)) : MacroConstraint

@Serializable @SerialName("battery")
data class BatteryConstraint(val level: Int = 50, val below: Boolean = true) : MacroConstraint

@Serializable @SerialName("charging")
data class ChargingConstraint(val charging: Boolean = true) : MacroConstraint

@Serializable @SerialName("screen")
data class ScreenConstraint(val on: Boolean = true) : MacroConstraint

@Serializable @SerialName("wifi")
data class WifiConstraint(val connected: Boolean = true) : MacroConstraint

@Serializable @SerialName("variable")
data class VariableConstraint(val name: String = "variabel", val value: String = "1") : MacroConstraint

@Serializable @SerialName("airplane")
data class AirplaneConstraint(val on: Boolean = false) : MacroConstraint

@Serializable @SerialName("bluetooth")
data class BluetoothConstraint(val enabled: Boolean = true) : MacroConstraint

@Serializable @SerialName("ringer")
data class RingerConstraint(val ringerMode: String = "normal") : MacroConstraint

/**
 * Bandingkan dua teks (boleh berisi penanda {var:x}, {notif_title}, dst). textCmp: sama, beda, mengandung, tidak_mengandung,
 * diawali, diakhiri, cocok (regex ditemukan), tidak_cocok. Dibaca saat dijalankan, jadi bisa dipakai di pemicu notifikasi.
 */
@Serializable @SerialName("text_compare")
data class StringCompareConstraint(
    val left: String = "{notif_title}", val textCmp: String = "mengandung", val right: String = "",
    val regex: Boolean = false, val ignoreCase: Boolean = true,
) : MacroConstraint

@Serializable @SerialName("variable_compare")
data class VariableCompareConstraint(val name: String = "variabel", val cmp: String = ">", val value: String = "0") : MacroConstraint

@Serializable @SerialName("day_of_month")
data class DayOfMonthConstraint(val fromDay: Int = 1, val toDay: Int = 15) : MacroConstraint

@Serializable @SerialName("headphone")
data class HeadphoneConstraint(val plugged: Boolean = true) : MacroConstraint

@Serializable @SerialName("internet")
data class InternetConstraint(val connected: Boolean = true) : MacroConstraint

@Serializable @SerialName("locked")
data class LockedConstraint(val locked: Boolean = true) : MacroConstraint

@Serializable @SerialName("sync_on")
data class SyncConstraint(val on: Boolean = true) : MacroConstraint

@Serializable @SerialName("power_save_on")
data class PowerSaveConstraint(val on: Boolean = true) : MacroConstraint

@Serializable @SerialName("dnd_on")
data class DndConstraint(val on: Boolean = true) : MacroConstraint

@Serializable @SerialName("cellular_on")
data class CellularConstraint(val connected: Boolean = true) : MacroConstraint

@Serializable @SerialName("wifi_ssid_on")
data class WifiSsidConstraint(val ssid: String = "", val connected: Boolean = true) : MacroConstraint

/** Gerbang logika: logic = AND (semua benar), OR (salah satu), XOR (tepat satu), NOT (tidak satupun benar). */
@Serializable @SerialName("logic")
data class LogicConstraint(val logic: String = "AND", val constraints: List<MacroConstraint> = emptyList()) : MacroConstraint

/** Benar hanya bila makro dijalankan oleh jenis pemicu ini (batasan per pemicu bila digabung dengan AND/OR). */
@Serializable @SerialName("trigger_kind")
data class TriggerKindConstraint(val triggerKind: String = "time") : MacroConstraint

@Serializable @SerialName("foreground_app")
data class ForegroundAppConstraint(val pkg: String = "") : MacroConstraint

/** Pembungkus: batasan dinonaktifkan lewat menu tekan-tahan. Diabaikan seolah tidak ada. */
@Serializable @SerialName("battery_temp_on")
data class BatteryTempConstraint(val celsius: Int = 40, val below: Boolean = false) : MacroConstraint

@Serializable @SerialName("storage_free")
data class StorageFreeConstraint(val mb: Int = 500, val below: Boolean = true) : MacroConstraint

@Serializable @SerialName("charger_type_on")
data class ChargerTypeConstraint(val plugType: String = "any") : MacroConstraint

@Serializable @SerialName("dark_theme_on")
data class DarkThemeConstraint(val on: Boolean = true) : MacroConstraint

@Serializable @SerialName("music_active")
data class MusicActiveConstraint(val playing: Boolean = true) : MacroConstraint

/** Keadaan telepon: idle (siaga), ringing (berdering), in_call (sedang bicara). */
@Serializable @SerialName("call_state")
data class CallStateConstraint(val callState: String = "idle") : MacroConstraint

@Serializable @SerialName("vpn_on")
data class VpnConstraint(val connected: Boolean = true) : MacroConstraint

/** Benar bila sambungan ADB bawaan sudah dipasangkan dan sedang tersambung (connected mati = tidak tersambung). */
@Serializable @SerialName("adb_on")
data class AdbOnConstraint(val connected: Boolean = true) : MacroConstraint

/** Sebuah aplikasi terpasang (installed mati = tidak terpasang). Memakai ADB bila ada. */
@Serializable @SerialName("app_installed")
data class AppInstalledConstraint(val pkg: String = "", val installed: Boolean = true) : MacroConstraint

/** Keluaran perintah shell (ADB) mengandung teks tertentu. Teks kosong = keluaran tidak kosong. Gagal tersambung = salah. */
@Serializable @SerialName("shell_out_has")
data class ShellOutputConstraint(val command: String = "getprop ro.build.version.release", val contains: String = "") : MacroConstraint

/** Volume sebuah aliran suara di bawah atau di atas persentase tertentu. */
@Serializable @SerialName("volume_level")
data class VolumeLevelConstraint(val stream: String = "music", val percent: Int = 50, val below: Boolean = true) : MacroConstraint

/** Layar sedang mendatar (landscape mati = tegak). */
@Serializable @SerialName("orientation_now")
data class OrientationConstraint(val landscape: Boolean = true) : MacroConstraint

/** Keyboard aktif mengandung teks tertentu (nama paket atau kelas). */
@Serializable @SerialName("ime_is")
data class DefaultKeyboardConstraint(val imeContains: String = "") : MacroConstraint

/** Layanan Aksesibilitas tertentu sedang aktif (cukup tulis sebagian nama paket). */
@Serializable @SerialName("a11y_on")
data class A11yServiceConstraint(val component: String = "", val enabled: Boolean = true) : MacroConstraint

/** Aplikasi sedang berjalan (pidof lewat ADB). running mati = tidak berjalan. Gagal tersambung ADB = salah. */
@Serializable @SerialName("app_running_now")
data class AppRunningConstraint(val pkg: String = "", val running: Boolean = true) : MacroConstraint

/** Memori RAM yang tersedia di bawah (atau di atas) persentase tertentu. Tanpa ADB. */
@Serializable @SerialName("ram_level")
data class RamLevelConstraint(val ramPercent: Int = 15, val below: Boolean = true) : MacroConstraint

/** Aplikasi sedang diberi izin tertentu (dumpsys package lewat ADB). granted mati = belum diberi. Gagal tersambung ADB = salah. */
@Serializable @SerialName("permission_granted")
data class PermissionGrantedConstraint(val pkg: String = "", val permission: String = "android.permission.CAMERA", val granted: Boolean = true) : MacroConstraint

@Serializable @SerialName("off")
data class OffConstraint(val item: MacroConstraint) : MacroConstraint


// ───────────── Tahap 47: pemicu dan aksi ala Tasker ─────────────

/** Papan klip berubah (ada teks yang disalin). Teks kosong = semua. Isi salinan jadi {clip_text} bila Android mengizinkan dibaca dari latar belakang. */
@Serializable @SerialName("clipboard_changed")
data class ClipboardChangedTrigger(val contains: String = "") : MacroTrigger

/** Lagu berganti di pemutar musik apa pun. Teks kosong = semua lagu; bila diisi, dicocokkan dengan judul dan artis. Butuh Akses Notifikasi. Jadi {track_title}, {track_artist}, {track_album}, {track_app}. */
@Serializable @SerialName("music_track")
data class MusicTrackTrigger(val contains: String = "") : MacroTrigger

/** Sensor tekanan udara (hPa), suhu sekitar (derajat C), kelembapan (persen), atau medan magnet (mikrotesla) melewati batas. Nilai jadi {sensor_value}. Tidak semua HP punya sensor ini. */
@Serializable @SerialName("sensor_value")
data class SensorValueTrigger(val sensorKind: String = "pressure", val limit: Int = 1000, val overLimit: Boolean = true) : MacroTrigger

/** Daftar (array) ala Tasker. Satu variabel berisi satu butir per baris. Operasi: tambah, sisip, ambil, hapus, urut, gabung, pisah, hitung, dll. */
@Serializable @SerialName("list_op")
data class ListOpAction(
    val list: String = "daftar", val listOp: String = "push", val value: String = "",
    val separator: String = ",", val index: Int = 1, val saveTo: String = "hasil",
) : MacroAction


// ───────────── Tahap 48: pemicu dan aksi ala Tasker (bagian 2) ─────────────

/** Baris log sistem baru yang mengandung teks tertentu (dibaca lewat ADB tiap 5 detik). Teks wajib diisi. Tag kosong = semua tag. Jadi {log_line} dan {log_tag}. Butuh ADB. */
@Serializable @SerialName("logcat_line")
data class LogcatTrigger(val contains: String = "", val logTag: String = "") : MacroTrigger

/** Jaringan Wi-Fi terdeteksi di sekitar (muncul atau menghilang dari hasil pindai). Nama kosong = jaringan apa pun. Butuh izin Lokasi dan Wi-Fi menyala. */
@Serializable @SerialName("wifi_nearby")
data class WifiNearbyTrigger(val ssid: String = "", val appear: Boolean = true) : MacroTrigger

/** Dialog pilihan: Ya atau Tidak, atau menu dari daftar. Jawaban masuk ke variabel; bila dibatalkan atau waktu habis, makro berhenti. Butuh izin Tampil di atas aplikasi lain. */
@Serializable @SerialName("choice_prompt")
data class ChoicePromptAction(
    val title: String = "MakroKu", val text: String = "Pilih salah satu", val items: String = "Satu\nDua\nTiga",
    val yesNo: Boolean = false, val saveTo: String = "pilihan_dialog", val seconds: Int = 120,
) : MacroAction

/** Daftar nama berkas dan folder di folder data aplikasi (atau subfolder) ke variabel daftar, satu per baris. Folder diberi akhiran garis miring. */
@Serializable @SerialName("file_list")
data class FileListAction(val subFolder: String = "", val saveTo: String = "daftar_berkas") : MacroAction

/** Baca satu baris dari berkas teks di folder data aplikasi. Nomor baris mulai 1, negatif = dari belakang. */
@Serializable @SerialName("file_line")
data class FileLineAction(val fromFile: String = "catatan.txt", val index: Int = 1, val saveTo: String = "baris") : MacroAction

/** Zip: bungkus berkas atau folder jadi arsip zip. Unzip: ekstrak arsip ke folder. Semua di folder data aplikasi. */
@Serializable @SerialName("zip_op")
data class ZipAction(val zipOp: String = "zip", val fromFile: String = "", val toFile: String = "arsip.zip") : MacroAction


// ───────────── Tahap 49: pemicu dan aksi ala Tasker (bagian 3) ─────────────

/** Acara di Kalender mulai atau selesai (dicek tiap 30 detik, acara seharian dilewati). Teks kosong = semua acara. Jadi {cal_title} dan {cal_location}. Butuh izin Kalender. */
@Serializable @SerialName("calendar_event")
data class CalendarEventTrigger(val contains: String = "", val eventStart: Boolean = true) : MacroTrigger

/** Kekuatan sinyal seluler (0 sampai 4 batang) melewati batas. Dicek tiap 20 detik. Butuh izin Telepon. Jadi {signal_level}. */
@Serializable @SerialName("cell_signal")
data class CellSignalTrigger(val signalLevel: Int = 1, val below: Boolean = true) : MacroTrigger

/** Konversi tanggal ala Tasker: teks ke detik epoch, epoch ke teks, atau selisih dua tanggal (nilai kedua dikurangi nilai pertama). */
@Serializable @SerialName("date_convert")
data class DateConvertAction(
    val dateOp: String = "to_epoch", val value: String = "", val value2: String = "",
    val format: String = "yyyy-MM-dd HH:mm", val saveTo: String = "hasil_tanggal",
) : MacroAction

/** Kelola berkas di folder data aplikasi: buat folder, hapus berkas atau folder beserta isinya, ganti nama. */
@Serializable @SerialName("file_manage")
data class FileManageAction(val manageOp: String = "mkdir", val fromFile: String = "", val toFile: String = "") : MacroAction

// ───────────── Tahap 50: parameter makro dan variabel bernomor ─────────────

/** Pisah teks jadi variabel bernomor ala array Tasker: awalan1, awalan2, dan seterusnya, ditambah awalan_jumlah. Variabel bernomor lama dengan awalan sama dibuang dulu. */
@Serializable @SerialName("split_to_vars")
data class SplitToVarsAction(val text: String = "{var:daftar}", val separator: String = ",", val prefix: String = "bagian") : MacroAction

/** Hapus semua variabel yang namanya diawali teks tertentu (awalan wajib diisi). */
@Serializable @SerialName("clear_vars")
data class ClearVarsAction(val prefix: String = "") : MacroAction

/**
 * Ada (atau tidak ada) notifikasi aktif di bilah notifikasi. [pkgs] = paket dipisah koma (kosong = aplikasi apa pun).
 * [contains] = teks yang dicari di judul atau isi; boleh memakai bintang `*` sebagai pengganti apa saja. Kosong = notifikasi apa pun.
 * Butuh Akses Notifikasi.
 */
@Serializable @SerialName("notif_present")
data class NotificationPresentConstraint(val pkgs: String = "", val contains: String = "", val present: Boolean = true) : MacroConstraint

// ───────────── Tahap 53: impor berkas MacroDroid ─────────────
/** Dengar ucapan lewat pengenalan suara Android lalu simpan teksnya ke variabel. Bila dibatalkan atau waktu habis, makro berhenti. Butuh izin Tampil di atas aplikasi lain. */
@Serializable @SerialName("voice_input")
data class VoiceInputAction(val prompt: String = "Silakan bicara", val saveTo: String = "jawaban_suara", val seconds: Int = 60) : MacroAction

/** Benar hanya bila makro dijalankan oleh pemicu nomor ke-N dalam daftar pemicunya (mulai dari 1). */
@Serializable @SerialName("trigger_index")
data class TriggerIndexConstraint(val triggerNumber: Int = 1) : MacroConstraint
