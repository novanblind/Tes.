import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.novan.audiolabnovan"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.novan.audiolabnovan"
        minSdk = 24
        targetSdk = 36
        versionCode = 79
        versionName = "1.69"

        // Satu APK untuk 64-bit (arm64-v8a) dan 32-bit (armeabi-v7a); Android memilih sendiri.
        ndk {
            abiFilters += setOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Keystore disertakan di repo agar tanda tangan APK sama di setiap build.
    signingConfigs {
        create("app") {
            storeFile = rootProject.file("keystore/toolkit.jks")
            storePassword = "ytplayer123"
            keyAlias = "ytplayer"
            keyPassword = "ytplayer123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Pustaka native (.so) dikompresi di dalam APK supaya berkas APK lebih kecil.
    // Saat dipasang, Android mengekstraknya ke penyimpanan aplikasi.
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// Unduh pustaka FFmpeg otomatis bila belum ada (arm64-v8a + armeabi-v7a).
val fetchFfmpeg by tasks.registering(Exec::class) {
    val aar = file("libs/ffmpeg-kit-6.1.1-arm.aar")
    onlyIf { !aar.exists() }
    workingDir = rootProject.projectDir
    commandLine("bash", "scripts/fetch-ffmpeg.sh")
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation(files("libs/ffmpeg-kit-6.1.1-arm.aar").builtBy(fetchFfmpeg))
    implementation("com.arthenica:smart-exception-java:0.2.1")
    // Tahap 87: Editor Video (VideoLab) memakai Media3 (pemutar, efek, dan Transformer untuk ekspor)
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")
    implementation("androidx.media3:media3-effect:1.5.1")
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.google.guava:guava:33.3.1-android")
}
