package org.telegram.messenger;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;

import org.telegram.tgnet.TLRPC;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Novan Tel - kategori halaman utama (tahap 22).
 *
 * Daftar obrolan mendapat tab: Semua Obrolan, Grup, Pribadi, Channel (urutan itu), memakai mesin folder obrolan bawaan
 * Telegram, jadi ketuk nama tab dan usap dua jari kiri/kanan untuk pindah, serta hitungan belum dibaca per tab,
 * semuanya perilaku asli Telegram yang sudah ramah pembaca layar.
 *
 * Tiga folder itu dipasang sebagai folder LOKAL (tidak dikirim ke server): setiap daftar folder dimuat atau diperbarui,
 * kelas ini memastikan urutannya benar. Bila Anda sudah punya folder yang jenisnya sama persis (misalnya folder Grup yang
 * hanya berisi grup), folder itu dipakai ulang dan tidak digandakan.
 *
 * Kelas ini satu paket dengan Telegram dan memakai bidang publik MessagesController/DialogFilter secara langsung (bukan
 * refleksi), jadi tidak terpengaruh R8 yang mengacak nama. Sebelum membangun, pemeriksaan dini memastikan bidangnya ada.
 */
public final class NovanKategori implements NotificationCenter.NotificationCenterDelegate {

    /** Bawaan build (novan-mod.properties: kategori_utama). Bisa diganti di Pengaturan Novan Tel. */
    public static final boolean BAWAAN = __KATEGORI_UTAMA__;

    public static final String KUNCI = "kategori_utama";
    public static final String KUNCI_STATUS = "kategori_status";

    // id folder lokal: jauh di atas id server (yang kecil dan naik satu-satu), di bawah folder bawaan "Semua Obrolan" (Integer.MAX_VALUE)
    private static final int ID_GRUP = Integer.MAX_VALUE - 31;
    private static final int ID_PRIBADI = Integer.MAX_VALUE - 32;
    private static final int ID_CHANNEL = Integer.MAX_VALUE - 33;
    private static final int LOCAL_ID_DASAR = 880000;

    private static final NovanKategori PENGAMAT = new NovanKategori();
    private static final Handler UTAMA = new Handler(Looper.getMainLooper());

    private static volatile boolean sudahMulai = false;
    private static volatile boolean sedangMengubah = false;
    private static int idFolderDiperbarui = -1;
    private static int idButuhMuatUlang = -1;

    private NovanKategori() {
    }

    // ------------------------------------------------------------------ pintu masuk

    /** Dipanggil dari NovanMod.muat(): daftar pengamat sekali, lalu terapkan pada semua akun. */
    public static void mulai() {
        if (sudahMulai) {
            return;
        }
        sudahMulai = true;
        UTAMA.postDelayed(new Runnable() {
            @Override
            public void run() {
                idFolderDiperbarui = NotificationCenter.dialogFiltersUpdated;
                idButuhMuatUlang = NotificationCenter.dialogsNeedReload;
                try {
                    for (int a = 0; a < UserConfig.MAX_ACCOUNT_COUNT; a++) {
                        NotificationCenter.getInstance(a).addObserver(PENGAMAT, idFolderDiperbarui);
                        NotificationCenter.getInstance(a).addObserver(PENGAMAT, idButuhMuatUlang);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal mendaftarkan pengamat folder: " + t);
                    return;
                }
                terapkanSemua();
                UTAMA.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        terapkanSemua();
                    }
                }, 8000);
            }
        }, 2500);
    }

    /** Terapkan (atau lepas, bila dimatikan) pada semua akun yang sedang masuk. Aman dipanggil dari thread mana pun. */
    public static void terapkanSemua() {
        UTAMA.post(new Runnable() {
            @Override
            public void run() {
                try {
                    boolean nyala = nyala();
                    String hasil = null;
                    for (int a = 0; a < UserConfig.MAX_ACCOUNT_COUNT; a++) {
                        if (!UserConfig.getInstance(a).isClientActivated()) {
                            continue;
                        }
                        String s = nyala ? pasang(a) : lepas(a);
                        if (hasil == null) {
                            hasil = s;
                        }
                    }
                    if (hasil != null) {
                        catatStatus(hasil);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal: " + t);
                }
            }
        });
    }

    @Override
    public void didReceivedNotification(int id, int account, Object... args) {
        if (sedangMengubah) {
            return;
        }
        if (idButuhMuatUlang >= 0 && id == idButuhMuatUlang) {
            // daftar obrolan dimuat ulang Telegram: urutkan lagi yang belum dibaca ke atas (tab Grup, Pribadi, Channel)
            final int akunMuat = account;
            UTAMA.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (nyala() && urutkanSemua(akunMuat)) {
                            kirimMuatUlang(akunMuat);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            return;
        }
        if (id != idFolderDiperbarui) {
            return;
        }
        final int akun = account;
        UTAMA.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String s = nyala() ? pasang(akun) : lepas(akun);
                    if (s != null) {
                        catatStatus(s);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal: " + t);
                }
            }
        });
    }

    // ------------------------------------------------------------------ pilihan dan status

    public static boolean nyala() {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null) {
                return BAWAAN;
            }
            return c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE).getBoolean(KUNCI, BAWAAN);
        } catch (Throwable t) {
            return BAWAAN;
        }
    }

    public static String status() {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null) {
                return "";
            }
            return c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE).getString(KUNCI_STATUS, "belum dijalankan");
        } catch (Throwable t) {
            return "";
        }
    }

    private static void catatStatus(String s) {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null || s == null) {
                return;
            }
            SharedPreferences p = c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE);
            if (!s.equals(p.getString(KUNCI_STATUS, ""))) {
                p.edit().putString(KUNCI_STATUS, s).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ inti: susun ulang daftar folder

    private static boolean buatanKita(MessagesController.DialogFilter f) {
        return f.id == ID_GRUP || f.id == ID_PRIBADI || f.id == ID_CHANNEL;
    }

    private static boolean kosong(Collection<?> c) {
        return c == null || c.isEmpty();
    }

    /** Jenis folder: 1 Grup, 2 Pribadi, 3 Channel, 0 bukan salah satunya (ada pengecualian atau pilihan manual). */
    private static int jenis(MessagesController.DialogFilter f) {
        if (f.isChatlist()) {
            return 0;
        }
        final int kecuali = MessagesController.DIALOG_FILTER_FLAG_EXCLUDE_MUTED
                | MessagesController.DIALOG_FILTER_FLAG_EXCLUDE_READ
                | MessagesController.DIALOG_FILTER_FLAG_EXCLUDE_ARCHIVED;
        if ((f.flags & kecuali) != 0) {
            return 0;
        }
        if (!kosong(f.alwaysShow) || !kosong(f.neverShow)) {
            return 0;
        }
        final int kontak = MessagesController.DIALOG_FILTER_FLAG_CONTACTS;
        final int bukanKontak = MessagesController.DIALOG_FILTER_FLAG_NON_CONTACTS;
        final int grup = MessagesController.DIALOG_FILTER_FLAG_GROUPS;
        final int kanal = MessagesController.DIALOG_FILTER_FLAG_CHANNELS;
        final int bot = MessagesController.DIALOG_FILTER_FLAG_BOTS;
        int jenisObrolan = f.flags & (kontak | bukanKontak | grup | kanal | bot);
        if (jenisObrolan == grup) {
            return 1;
        }
        if (jenisObrolan == kanal) {
            return 3;
        }
        if (jenisObrolan == (kontak | bukanKontak) || jenisObrolan == (kontak | bukanKontak | bot)) {
            return 2;
        }
        return 0;
    }

    /** Nama folder Grup / Pribadi / Channel: 1, 2, 3. Selain itu 0. Folder lama bernama begini disembunyikan agar tab tidak kembar. */
    private static int jenisDariNama(String nama) {
        if (nama == null) {
            return 0;
        }
        String n = nama.trim().toLowerCase(java.util.Locale.ROOT);
        if (n.equals("grup") || n.equals("group") || n.equals("groups")) {
            return 1;
        }
        if (n.equals("pribadi") || n.equals("personal")) {
            return 2;
        }
        if (n.equals("channel") || n.equals("channels") || n.equals("saluran")) {
            return 3;
        }
        return 0;
    }

    private static int jenisBuatanKita(MessagesController.DialogFilter f) {
        if (f.id == ID_GRUP) {
            return 1;
        }
        if (f.id == ID_PRIBADI) {
            return 2;
        }
        if (f.id == ID_CHANNEL) {
            return 3;
        }
        return 0;
    }

    private static MessagesController.DialogFilter buatFolder(int jenis) {
        MessagesController.DialogFilter f = new MessagesController.DialogFilter();
        if (jenis == 1) {
            f.id = ID_GRUP;
            f.flags = MessagesController.DIALOG_FILTER_FLAG_GROUPS;
            f.name = "Grup";
        } else if (jenis == 2) {
            f.id = ID_PRIBADI;
            f.flags = MessagesController.DIALOG_FILTER_FLAG_CONTACTS | MessagesController.DIALOG_FILTER_FLAG_NON_CONTACTS
                    | MessagesController.DIALOG_FILTER_FLAG_BOTS;
            f.name = "Pribadi";
        } else {
            f.id = ID_CHANNEL;
            f.flags = MessagesController.DIALOG_FILTER_FLAG_CHANNELS;
            f.name = "Channel";
        }
        f.localId = LOCAL_ID_DASAR + jenis;
        return f;
    }

    /** Folder bawaan "Semua Obrolan" (id 0). Telegram hanya mengisinya bila akun punya folder; bila belum, kita buatkan lokal. */
    private static MessagesController.DialogFilter buatFolderBawaan() {
        MessagesController.DialogFilter f = new MessagesController.DialogFilter();
        f.id = 0;
        f.flags = MessagesController.DIALOG_FILTER_FLAG_CONTACTS | MessagesController.DIALOG_FILTER_FLAG_NON_CONTACTS
                | MessagesController.DIALOG_FILTER_FLAG_GROUPS | MessagesController.DIALOG_FILTER_FLAG_CHANNELS
                | MessagesController.DIALOG_FILTER_FLAG_BOTS;
        f.name = "Semua Obrolan";
        return f;
    }

    /** Susun daftar folder: Semua Obrolan, Grup, Pribadi, Channel, lalu folder lain milik pengguna. Mengembalikan teks status. */
    private static String pasang(int akun) {
        MessagesController mc = MessagesController.getInstance(akun);
        ArrayList<MessagesController.DialogFilter> daftar = mc.dialogFilters;
        if (daftar == null) {
            return "Menunggu: daftar folder Telegram belum siap";
        }
        MessagesController.DialogFilter bawaan = null;
        ArrayList<MessagesController.DialogFilter> lain = new ArrayList<MessagesController.DialogFilter>();
        for (MessagesController.DialogFilter f : new ArrayList<MessagesController.DialogFilter>(daftar)) {
            if (f == null) {
                continue;
            }
            if (f.isDefault()) {
                if (bawaan == null) {
                    bawaan = f;
                }
            } else {
                lain.add(f);
            }
        }
        if (bawaan == null) {
            bawaan = buatFolderBawaan();
        }
        MessagesController.DialogFilter[] pilih = new MessagesController.DialogFilter[4];
        // folder buatan pengguna yang isinya persis satu jenis (semua grup / semua pribadi / semua channel) dipakai ulang
        for (MessagesController.DialogFilter f : lain) {
            if (buatanKita(f)) {
                continue;
            }
            int j = jenis(f);
            if (j > 0 && pilih[j] == null) {
                pilih[j] = f;
            }
        }
        for (MessagesController.DialogFilter f : lain) {
            if (!buatanKita(f)) {
                continue;
            }
            int j = jenisBuatanKita(f);
            if (j > 0 && pilih[j] == null) {
                pilih[j] = f;
            }
        }
        for (int j = 1; j <= 3; j++) {
            if (pilih[j] == null) {
                pilih[j] = buatFolder(j);
            }
        }
        ArrayList<MessagesController.DialogFilter> baru = new ArrayList<MessagesController.DialogFilter>();
        baru.add(bawaan);
        baru.add(pilih[1]);
        baru.add(pilih[2]);
        baru.add(pilih[3]);
        for (MessagesController.DialogFilter f : lain) {
            if (f == pilih[1] || f == pilih[2] || f == pilih[3]) {
                continue;
            }
            if (buatanKita(f)) {
                continue; // sisa buatan kita yang sudah tergantikan folder pengguna
            }
            if (jenisDariNama(f.name) > 0) {
                continue; // folder lama bernama Grup/Pribadi/Channel yang isinya sebagian: disembunyikan dari tab agar tidak kembar
            }
            baru.add(f);
        }
        String ringkas = ringkasan(pilih);
        if (samaUrutan(daftar, baru)) {
            return ringkas;
        }
        sedangMengubah = true;
        try {
            if (mc.dialogFiltersById != null) {
                for (MessagesController.DialogFilter f : daftar) {
                    if (f != null && buatanKita(f) && !baru.contains(f)) {
                        mc.dialogFiltersById.remove(f.id);
                    }
                }
                for (MessagesController.DialogFilter f : baru) {
                    if (buatanKita(f)) {
                        mc.dialogFiltersById.put(f.id, f);
                    }
                }
            }
            for (int j = 1; j <= 3; j++) {
                if (buatanKita(pilih[j])) {
                    pilih[j].order = bawaan.order + j;
                }
            }
            daftar.clear();
            daftar.addAll(baru);
            segarkan(mc, akun);
        } finally {
            sedangMengubah = false;
        }
        return ringkas;
    }

    private static String ringkasan(MessagesController.DialogFilter[] pilih) {
        int sendiri = 0;
        for (int j = 1; j <= 3; j++) {
            if (!buatanKita(pilih[j])) {
                sendiri++;
            }
        }
        String s = "Nyala: tab Grup, Pribadi, Channel terpasang";
        if (sendiri > 0) {
            s += " (" + sendiri + " memakai folder Anda yang isinya persis sama)";
        }
        return s;
    }

    private static boolean samaUrutan(ArrayList<MessagesController.DialogFilter> a, ArrayList<MessagesController.DialogFilter> b) {
        if (a.size() != b.size()) {
            return false;
        }
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i) != b.get(i)) {
                return false;
            }
        }
        return true;
    }

    /** Matikan: buang tiga folder lokal. Folder buatan pengguna tidak disentuh. */
    private static String lepas(int akun) {
        MessagesController mc = MessagesController.getInstance(akun);
        ArrayList<MessagesController.DialogFilter> daftar = mc.dialogFilters;
        if (daftar == null) {
            return "Mati";
        }
        boolean ada = false;
        for (MessagesController.DialogFilter f : daftar) {
            if (f != null && buatanKita(f)) {
                ada = true;
            }
        }
        if (!ada) {
            return "Mati";
        }
        sedangMengubah = true;
        try {
            for (int i = daftar.size() - 1; i >= 0; i--) {
                MessagesController.DialogFilter f = daftar.get(i);
                if (f != null && buatanKita(f)) {
                    daftar.remove(i);
                    if (mc.dialogFiltersById != null) {
                        mc.dialogFiltersById.remove(f.id);
                    }
                }
            }
            segarkan(mc, akun);
        } finally {
            sedangMengubah = false;
        }
        return "Mati";
    }

    /** Hitung ulang isi tiap folder lalu minta layar daftar obrolan menggambar ulang tab. */
    private static void segarkan(MessagesController mc, int akun) {
        try {
            for (Method m : MessagesController.class.getDeclaredMethods()) {
                if ("sortDialogs".equals(m.getName()) && m.getParameterTypes().length == 1) {
                    m.setAccessible(true);
                    m.invoke(mc, new Object[]{null});
                    break;
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            if (nyala()) {
                urutkanSemua(akun);
            }
        } catch (Throwable ignored) {
        }
        try {
            if (idFolderDiperbarui >= 0) {
                NotificationCenter.getInstance(akun).postNotificationName(idFolderDiperbarui);
            }
            if (idButuhMuatUlang >= 0) {
                NotificationCenter.getInstance(akun).postNotificationName(idButuhMuatUlang);
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ belum dibaca di atas (tahap 32)

    private static boolean adaBelumDibaca(TLRPC.Dialog d) {
        return d != null && (d.unread_count > 0 || d.unread_mark);
    }

    /** Tab Grup, Pribadi, Channel (dan folder murni sejenis yang dipakai ulang): obrolan yang ada pesan belum dibacanya dipindah ke paling atas. */
    private static boolean urutkanSemua(int akun) {
        MessagesController mc = MessagesController.getInstance(akun);
        ArrayList<MessagesController.DialogFilter> daftar = mc.dialogFilters;
        if (daftar == null) {
            return false;
        }
        boolean berubah = false;
        for (MessagesController.DialogFilter f : new ArrayList<MessagesController.DialogFilter>(daftar)) {
            if (f == null || f.isDefault()) {
                continue;
            }
            if (!(buatanKita(f) || (jenis(f) > 0 && jenisDariNama(f.name) > 0))) {
                continue;
            }
            if (urutkanBelumDibaca(f)) {
                berubah = true;
            }
        }
        return berubah;
    }

    private static boolean urutkanBelumDibaca(MessagesController.DialogFilter f) {
        ArrayList<TLRPC.Dialog> isi = f.dialogs;
        if (isi == null || isi.size() < 2) {
            return false;
        }
        ArrayList<TLRPC.Dialog> belum = new ArrayList<TLRPC.Dialog>();
        ArrayList<TLRPC.Dialog> sudah = new ArrayList<TLRPC.Dialog>();
        for (TLRPC.Dialog d : isi) {
            if (adaBelumDibaca(d)) {
                belum.add(d);
            } else {
                sudah.add(d);
            }
        }
        if (belum.isEmpty()) {
            return false;
        }
        belum.addAll(sudah);
        boolean sama = true;
        for (int i = 0; i < isi.size(); i++) {
            if (isi.get(i) != belum.get(i)) {
                sama = false;
                break;
            }
        }
        if (sama) {
            return false;
        }
        isi.clear();
        isi.addAll(belum);
        return true;
    }

    private static void kirimMuatUlang(int akun) {
        if (idButuhMuatUlang < 0) {
            return;
        }
        sedangMengubah = true;
        try {
            NotificationCenter.getInstance(akun).postNotificationName(idButuhMuatUlang);
        } catch (Throwable ignored) {
        } finally {
            sedangMengubah = false;
        }
    }

    // ------------------------------------------------------------------ ucapan jumlah belum dibaca pada nama tab (tahap 32)

    private static boolean samaNama(Object nama, String judul) {
        return nama != null && judul != null && String.valueOf(nama).trim().equalsIgnoreCase(judul.trim());
    }

    /**
     * Teks yang dibacakan pembaca layar setelah nama tab, mis. "3 belum dibaca"; string kosong bila tidak ada. Dihitung dari isi folder SENDIRI
     * termasuk obrolan yang dibisukan (angka bawaan Telegram tidak menghitung yang dibisukan). Null bila tab tidak dikenali.
     */
    public static String ucapan(int idTab, String judul) {
        try {
            if (!nyala() || judul == null) {
                return null;
            }
            MessagesController mc = MessagesController.getInstance(UserConfig.selectedAccount);
            ArrayList<MessagesController.DialogFilter> daftar = mc.dialogFilters;
            if (daftar == null) {
                return null;
            }
            MessagesController.DialogFilter f = null;
            for (MessagesController.DialogFilter c : new ArrayList<MessagesController.DialogFilter>(daftar)) {
                if (c != null && !c.isDefault() && samaNama(c.name, judul)) {
                    f = c;
                    break;
                }
            }
            if (f == null) {
                String j = judul.trim().toLowerCase(java.util.Locale.ROOT);
                if (j.equals("semua obrolan") || j.equals("semua") || j.equals("all chats") || j.equals("all")) {
                    for (MessagesController.DialogFilter c : new ArrayList<MessagesController.DialogFilter>(daftar)) {
                        if (c != null && c.isDefault()) {
                            f = c;
                            break;
                        }
                    }
                }
            }
            if (f == null) {
                return null;
            }
            ArrayList<TLRPC.Dialog> isi = f.isDefault() ? mc.getDialogs(0) : f.dialogs;
            int n = 0;
            if (isi != null) {
                for (TLRPC.Dialog d : new ArrayList<TLRPC.Dialog>(isi)) {
                    if (adaBelumDibaca(d)) {
                        n++;
                    }
                }
            }
            // tidak ada yang belum dibaca: string kosong = nama tab dibacakan polos, tanpa keterangan
            return n > 0 ? n + " belum dibaca" : "";
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ keterangan belum dibaca pada tiap baris obrolan (tahap 36)

    /**
     * Dipanggil dari DialogCell (bacaan pembaca layar satu baris obrolan): bila obrolan punya pesan belum dibaca, "N belum dibaca"
     * ditaruh di depan bacaan. Berlaku juga untuk obrolan yang dibisukan. Bila sudah dibaca, bacaan tidak diubah.
     */
    public static void tambahBelumDibaca(android.view.accessibility.AccessibilityNodeInfo info, long idObrolan) {
        try {
            if (info == null || !nyala()) {
                return;
            }
            TLRPC.Dialog d = MessagesController.getInstance(UserConfig.selectedAccount).dialogs_dict.get(idObrolan);
            if (d == null || !adaBelumDibaca(d)) {
                return;
            }
            String awal = d.unread_count > 0 ? d.unread_count + " belum dibaca" : "belum dibaca";
            CharSequence teks = info.getText();
            CharSequence desk = info.getContentDescription();
            boolean adaTeks = teks != null && teks.length() > 0;
            boolean adaDesk = desk != null && desk.length() > 0;
            // bila Telegram sendiri sudah menyebut jumlah belum dibaca pada baris ini, tidak ditambah lagi (hindari bacaan ganda)
            if (sudahMenyebut(teks) || sudahMenyebut(desk)) {
                return;
            }
            if (adaTeks) {
                info.setText(awal + ". " + teks);
            }
            if (adaDesk) {
                info.setContentDescription(awal + ". " + desk);
            }
            if (!adaTeks && !adaDesk) {
                info.setText(awal);
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean sudahMenyebut(CharSequence c) {
        if (c == null) {
            return false;
        }
        String t = c.toString().toLowerCase(java.util.Locale.ROOT);
        return t.contains("belum dibaca") || t.contains("pesan baru") || t.contains("unread") || t.contains("new message");
    }
}
