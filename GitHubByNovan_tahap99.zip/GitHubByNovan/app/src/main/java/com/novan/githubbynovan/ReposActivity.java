package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ReposActivity extends Activity {
    private static final String[] FILTERS = {"semua", "publik", "privat", "nama (A-Z)"};

    private interface Op { void run(String fullName, Api.Callback cb); }

    // Daftar repo disimpan sebentar agar berpindah menu terasa instan.
    private static JSONArray cache;
    private static long cacheTime;
    public static void invalidate() { cache = null; }

    private Ui ui;
    private String token, query;
    private JSONArray all = new JSONArray();
    private boolean loaded, multi, busy;
    private int filter = 0;
    private final Set<String> picked = new LinkedHashSet<>();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        query = getIntent().getStringExtra("query");
        if (cache != null && System.currentTimeMillis() - cacheTime < 120000) {
            all = cache;
            loaded = true;
            render();
            return;
        }
        render();
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Setelah kembali dari layar yang mengubah repo (hapus, ganti nama, privasi), muat ulang.
        if (loaded && cache == null && !busy) load();
    }

    private void load() {
        loaded = false;
        all = new JSONArray();
        render();
        page(1);
    }

    private void page(final int n) {
        Api.request("GET", Api.BASE + "/user/repos?sort=updated&direction=desc&per_page=100"
                + "&affiliation=owner&page=" + n, token, null, (ok, res) -> {
            if (!ok) {
                loaded = true;
                render();
                ui.say("Gagal memuat: " + res);
                return;
            }
            JSONArray a = Api.parseArr(res);
            for (int i = 0; i < a.length(); i++) all.put(a.opt(i));
            if (a.length() == 100 && n < 10) {
                page(n + 1);
                return;
            }
            loaded = true;
            cache = all;
            cacheTime = System.currentTimeMillis();
            render();
            ui.say("Ditemukan " + visible().size() + " repositori.");
        });
    }

    /** Waktu terakhir diedit: yang lebih baru antara pushed_at dan updated_at. */
    private static String lastEdit(JSONObject r) {
        String p = r.isNull("pushed_at") ? "" : r.optString("pushed_at", "");
        String u = r.isNull("updated_at") ? "" : r.optString("updated_at", "");
        return p.compareTo(u) > 0 ? p : u;
    }

    private List<JSONObject> visible() {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < all.length(); i++) {
            JSONObject r = all.optJSONObject(i);
            if (r == null) continue;
            boolean priv = r.optBoolean("private", false);
            if (filter == 1 && priv) continue;
            if (filter == 2 && !priv) continue;
            if (query != null && !r.optString("name", "").toLowerCase().contains(query.toLowerCase())) continue;
            out.add(r);
        }
        Collections.sort(out, (a, b) -> lastEdit(b).compareTo(lastEdit(a)));
        if (filter == 3) {
            Collections.sort(out, (a, b) -> a.optString("name", "").compareToIgnoreCase(b.optString("name", "")));
        }
        return out;
    }

    private void render() {
        ui = new Ui(this, multi ? "Pilih banyak repositori"
                : query == null ? "Repositori saya" : "Hasil pencarian: " + query);
        if (!loaded) {
            ui.label("Memuat daftar repositori...");
            ui.button("Kembali", v -> finish());
            return;
        }
        if (multi) {
            renderMulti();
            return;
        }
        ui.button("Segarkan daftar", v -> load());
        ui.button("Filter: " + FILTERS[filter] + " (ketuk untuk ganti)", v -> {
            filter = (filter + 1) % FILTERS.length;
            render();
            ui.say("Filter " + FILTERS[filter] + ", " + visible().size() + " repositori.");
        });
        List<JSONObject> list = visible();
        if (query == null) {
            ui.button("Pilih banyak (multi-select)", v -> {
                if (visible().isEmpty()) {
                    ui.say("Tidak ada repositori untuk dipilih.");
                    return;
                }
                multi = true;
                picked.clear();
                render();
            });
        }
        if (list.isEmpty()) ui.label("Tidak ada repositori yang cocok.");
        int i = 1;
        for (final JSONObject r : list) {
            String tag = r.optBoolean("private", false) ? "[privat]" : "[publik]";
            final String fn = r.optString("full_name", "");
            Button b = ui.button(i++ + ". " + r.optString("name", "") + " " + tag,
                    v -> startActivity(RepoActivity.of(this, r)));
            // Tekan tahan: repositori ini otomatis tercentang dan mode centang aktif.
            b.setOnLongClickListener(v -> {
                multi = true;
                picked.clear();
                picked.add(fn);
                render();
                ui.say("Mode pilih aktif. " + r.optString("name", "") + " tercentang. "
                        + "Ketuk repositori lain untuk mengubah centang.");
                return true;
            });
        }
        ui.button("Kembali", v -> finish());
    }

    @Override
    public void onBackPressed() {
        // Dalam mode pilih, Kembali keluar dari mode pilih dulu, bukan menutup layar.
        if (multi && !busy) {
            multi = false;
            picked.clear();
            render();
            ui.say("Mode pilih ditutup.");
            return;
        }
        super.onBackPressed();
    }

    private void renderMulti() {
        final TextView cnt = ui.label(picked.size() + " repositori terpilih.");
        ui.button("Hapus terpilih", Ui.DANGER, v -> askDelete());
        ui.button("Ubah privasi terpilih", v -> askPrivacy());
        for (final JSONObject r : visible()) {
            final String fn = r.optString("full_name", "");
            String tag = r.optBoolean("private", false) ? "[privat]" : "[publik]";
            CheckBox c = ui.check(r.optString("name", "") + " " + tag, picked.contains(fn));
            c.setOnCheckedChangeListener((btn, on) -> {
                if (on) picked.add(fn); else picked.remove(fn);
                cnt.setText(picked.size() + " repositori terpilih.");
            });
        }
        ui.button("Selesai memilih", v -> {
            multi = false;
            picked.clear();
            render();
        });
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }

    private void askDelete() {
        if (busy) return;
        final List<String> l = new ArrayList<>(picked);
        if (l.isEmpty()) {
            ui.say("Belum ada repositori dipilih.");
            return;
        }
        ui.confirm("Hapus " + l.size() + " repositori?",
                "Repositori ini dihapus permanen dari GitHub:\n\n" + join(l), "hapus semua",
                () -> runBulk("Menghapus repositori...", "Hapus repositori", l,
                        (fn, cb) -> Api.request("DELETE", Api.BASE + "/repos/" + fn, token, null, cb)));
    }

    private void askPrivacy() {
        if (busy) return;
        final List<String> l = new ArrayList<>(picked);
        if (l.isEmpty()) {
            ui.say("Belum ada repositori dipilih.");
            return;
        }
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Ubah privasi " + l.size() + " repositori menjadi:")
                .setItems(new String[]{"Jadikan publik", "Jadikan privat"}, (x, which) -> {
                    final boolean priv = which == 1;
                    runBulk("Mengubah privasi...", "Ubah privasi repositori", l,
                            (fn, cb) -> {
                                if (priv) {
                                    Api.request("PATCH", Api.BASE + "/repos/" + fn, token,
                                            Api.o("private", true).toString(), cb);
                                    return;
                                }
                                // Jadikan publik: lewati repo yang berisi kunci tanda tangan pribadi.
                                Api.request("GET", Api.BASE + "/repos/" + fn + "/contents/"
                                        + TandaTanganRepo.KS_PATH, token, null, (adaKunci, r0) -> {
                                    if (adaKunci) {
                                        cb.done(false, "Dilewati: berisi kunci tanda tangan pribadi "
                                                + "(.tanda-tangan). Bila dijadikan publik, kuncinya bocor.");
                                    } else {
                                        Api.request("PATCH", Api.BASE + "/repos/" + fn, token,
                                                Api.o("private", false).toString(), cb);
                                    }
                                });
                            });
                })
                .setNegativeButton("batal", null).show();
        ui.fix(d);
    }

    private void runBulk(String progressText, String judul, List<String> l, Op op) {
        busy = true;
        step(0, l, op, judul, progressText, new ArrayList<String>(), new ArrayList<String>());
    }

    private void step(final int i, final List<String> l, final Op op, final String judul,
                      final String progressText, final List<String> okL, final List<String> failL) {
        if (i >= l.size()) {
            finishBulk(judul, okL, failL);
            return;
        }
        final String fn = l.get(i);
        ui.progress(progressText + " (" + (i + 1) + "/" + l.size() + ") " + fn);
        op.run(fn, (ok, res) -> {
            if (ok) okL.add(fn); else failL.add(fn + " (" + res + ")");
            step(i + 1, l, op, judul, progressText, okL, failL);
        });
    }

    private void finishBulk(String judul, List<String> okL, List<String> failL) {
        busy = false;
        String pesan = "Berhasil: " + okL.size() + "\nGagal: " + failL.size();
        if (!failL.isEmpty()) pesan += "\n\nDetail gagal:\n" + join(failL);
        ui.say(judul + " selesai. Berhasil " + okL.size() + ", gagal " + failL.size() + ".");
        ui.info(judul + " selesai", pesan, "oke", () -> {
            multi = false;
            picked.clear();
            load();
        });
    }
}
