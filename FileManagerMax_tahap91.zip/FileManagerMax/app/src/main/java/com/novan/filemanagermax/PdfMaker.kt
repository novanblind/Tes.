package com.novan.filemanagermax

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** Membuat PDF dari beberapa gambar: satu gambar per halaman, ukuran halaman mengikuti arah gambar. */
object PdfMaker {
    private const val SHORT = 595 // A4 pada 72 dpi
    private const val LONG = 842
    private const val MAX_SIDE = 2400

    /** Mengembalikan jumlah halaman yang berhasil dibuat. [progress] dipanggil di thread latar. */
    fun create(images: List<File>, out: File, progress: (done: Int, total: Int) -> Unit): Int {
        val doc = PdfDocument()
        var pages = 0
        try {
            for ((i, f) in images.withIndex()) {
                progress(i, images.size)
                val bmp = load(f) ?: continue
                try {
                    val landscape = bmp.width > bmp.height
                    val pw = if (landscape) LONG else SHORT
                    val ph = if (landscape) SHORT else LONG
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pages + 1).create())
                    val c: Canvas = page.canvas
                    c.drawColor(Color.WHITE)
                    val scale = minOf(pw.toFloat() / bmp.width, ph.toFloat() / bmp.height)
                    val w = bmp.width * scale
                    val h = bmp.height * scale
                    val l = (pw - w) / 2f
                    val t = (ph - h) / 2f
                    c.drawBitmap(bmp, null, RectF(l, t, l + w, t + h), Paint(Paint.FILTER_BITMAP_FLAG))
                    doc.finishPage(page)
                    pages++
                } finally {
                    bmp.recycle()
                }
            }
            if (pages == 0) return 0
            progress(images.size, images.size)
            val tmp = File(out.parentFile, out.name + ".tmp")
            try {
                FileOutputStream(tmp).use { doc.writeTo(it) }
                if (!tmp.renameTo(out)) throw java.io.IOException(out.name)
            } catch (e: Exception) {
                tmp.delete()
                throw e
            }
            return pages
        } finally {
            doc.close()
        }
    }

    private fun load(f: File): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / sample > MAX_SIDE) sample *= 2
            val opt = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = BitmapFactory.decodeFile(f.absolutePath, opt) ?: return null
            val deg = when (
                try {
                    ExifInterface(f.absolutePath).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } catch (e: Exception) {
                    ExifInterface.ORIENTATION_NORMAL
                }
            ) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg == 0f) raw else {
                val r = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(deg) }, true)
                if (r !== raw) raw.recycle()
                r
            }
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: Exception) {
            null
        }
    }
}
