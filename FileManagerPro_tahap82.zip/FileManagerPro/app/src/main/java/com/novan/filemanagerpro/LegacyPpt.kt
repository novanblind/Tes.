package com.novan.filemanagerpro

import java.io.File

/**
 * Pembaca presentasi PowerPoint lama (.ppt, .pps, .pot; PowerPoint 97 sampai 2003) tanpa
 * library tambahan. Urutan slide dan lokasi tiap slide dibaca dari rantai "persist directory",
 * lalu teks diambil dari atom teks di dalam slide dan catatan pembicara.
 */
object LegacyPpt {

    private fun u16(b: ByteArray, o: Int): Int =
        if (o < 0 || o + 2 > b.size) 0 else (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long =
        if (o < 0 || o + 4 > b.size) 0 else
            (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
                ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private const val T_DOCUMENT = 1000
    private const val T_SLIDE = 1006
    private const val T_SLIDE_ATOM = 1007
    private const val T_NOTES = 1008
    private const val T_SLWT = 4080
    private const val T_PERSIST_ATOM = 1011
    private const val T_SSINFO = 1017
    private const val T_TEXT_HEADER = 3999
    private const val T_TEXT_CHARS = 4000
    private const val T_TEXT_BYTES = 4008
    private const val T_USER_EDIT = 4085
    private const val T_PERSIST_DIR = 6002

    private class Text(val type: Int, val lines: List<String>)

    private class SlideData {
        val texts = ArrayList<Text>()
        var hidden = false
        var notesId = 0L
    }

    fun parse(f: File): OfficeReader.Doc {
        OleFile(f).use { ole ->
            val b = ole.readStream("PowerPoint Document")
                ?: throw IllegalStateException("bukan presentasi PowerPoint")
            val cu = ole.readStream("Current User")
            return build(b, cu)
        }
    }

    internal fun build(b: ByteArray, currentUser: ByteArray?): OfficeReader.Doc {
        val persist = HashMap<Int, Int>()
        var documentRef = 0
        if (currentUser != null && currentUser.size >= 20) {
            if (u32(currentUser, 12) == 0xF3D1C4DFL) {
                throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
            }
            documentRef = readPersist(b, u32(currentUser, 16).toInt(), persist)
        }

        // daftar slide menurut urutan tampil
        class Ref(val psr: Int, val slideId: Long, val fallback: List<Text>)
        val slideRefs = ArrayList<Ref>()
        val noteIds = HashMap<Long, Int>() // slideIdentifier catatan -> persistId

        var docOff = persist[documentRef] ?: -1
        if (docOff < 0 || docOff + 8 > b.size || u16(b, docOff + 2) != T_DOCUMENT) docOff = findTop(b, T_DOCUMENT)
        if (docOff >= 0) {
            val len = u32(b, docOff + 4).toInt()
            var p = docOff + 8
            val end = minOf(docOff + 8 + len, b.size)
            while (p + 8 <= end) {
                val type = u16(b, p + 2)
                val l = u32(b, p + 4).toInt()
                if (l < 0 || p + 8 + l > end) break
                if (type == T_SLWT) {
                    val inst = u16(b, p) shr 4
                    var q = p + 8
                    val qEnd = p + 8 + l
                    var curPsr = 0
                    var curId = 0L
                    var curTexts = ArrayList<Text>()
                    var have = false
                    var curType = 4
                    fun flush() {
                        if (!have) return
                        if (inst == 0) slideRefs.add(Ref(curPsr, curId, curTexts))
                        else if (inst == 2) noteIds[curId] = curPsr
                        have = false
                    }
                    while (q + 8 <= qEnd) {
                        val t = u16(b, q + 2)
                        val ql = u32(b, q + 4).toInt()
                        if (ql < 0 || q + 8 + ql > qEnd) break
                        when (t) {
                            T_PERSIST_ATOM -> {
                                flush()
                                curPsr = u32(b, q + 8).toInt()
                                curId = u32(b, q + 20)
                                curTexts = ArrayList()
                                curType = 4
                                have = true
                            }
                            T_TEXT_HEADER -> curType = u32(b, q + 8).toInt()
                            T_TEXT_CHARS, T_TEXT_BYTES -> {
                                val s = decode(b, q + 8, ql, t == T_TEXT_CHARS)
                                if (s.isNotEmpty()) curTexts.add(Text(curType, s))
                            }
                        }
                        q += 8 + ql
                    }
                    flush()
                }
                p += 8 + l
            }
        }

        val slides = ArrayList<SlideData>()
        val notesTexts = ArrayList<String>()
        if (slideRefs.isNotEmpty()) {
            for (r in slideRefs) {
                val sd = SlideData()
                val off = persist[r.psr] ?: -1
                if (off >= 0 && off + 8 <= b.size && u16(b, off + 2) == T_SLIDE) readContainer(b, off, sd)
                if (sd.texts.isEmpty()) sd.texts.addAll(r.fallback)
                slides.add(sd)
                notesTexts.add(noteText(b, persist, noteIds, sd.notesId))
            }
        } else {
            // cadangan: baca semua kontainer slide berurutan dari awal aliran
            var p = 0
            while (p + 8 <= b.size) {
                val l = u32(b, p + 4).toInt()
                if (l < 0 || p + 8 + l > b.size) break
                if (u16(b, p + 2) == T_SLIDE) {
                    val sd = SlideData()
                    readContainer(b, p, sd)
                    slides.add(sd)
                    notesTexts.add("")
                }
                p += 8 + l
            }
        }

        val doc = OfficeReader.Doc()
        doc.format = "ppt"
        doc.kind = "deck"
        doc.typeName = "Presentasi PowerPoint format lama"
        if (slides.isEmpty()) {
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Presentasi ini tidak berisi slide yang bisa dibaca."))
            return doc
        }
        val total = slides.size
        for ((i, sd) in slides.withIndex()) {
            if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) { doc.truncated = true; break }
            doc.slides++
            val titleIdx = sd.texts.indexOfFirst { it.type == 0 || it.type == 6 }
            val title = if (titleIdx >= 0) sd.texts[titleIdx].lines.joinToString(" ") else ""
            var head = "Slide ${i + 1} dari $total"
            if (title.isNotEmpty()) head += ": $title"
            if (sd.hidden) head += " (tersembunyi)"
            doc.headings++
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_HEADING, 1, head))
            var any = false
            for ((k, t) in sd.texts.withIndex()) {
                if (k == titleIdx) continue
                val body = t.type == 1 || t.type == 5 || t.type == 7 || t.type == 8
                for (line in t.lines) {
                    if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) { doc.truncated = true; break }
                    any = true
                    doc.blocks.add(OfficeReader.Block(if (body) OfficeReader.K_LIST else OfficeReader.K_PARA, 0, line))
                }
            }
            if (!any && title.isEmpty()) doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Slide ini tidak berisi teks."))
            val n = notesTexts.getOrNull(i) ?: ""
            if (n.isNotBlank()) doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Catatan pembicara: $n"))
            if (doc.truncated) break
        }
        return doc
    }

    private fun noteText(b: ByteArray, persist: Map<Int, Int>, noteIds: Map<Long, Int>, id: Long): String {
        if (id == 0L) return ""
        val psr = noteIds[id] ?: return ""
        val off = persist[psr] ?: return ""
        if (off < 0 || off + 8 > b.size || u16(b, off + 2) != T_NOTES) return ""
        val sd = SlideData()
        readContainer(b, off, sd)
        val body = sd.texts.filter { it.type == 2 }.ifEmpty { sd.texts }
        return body.flatMap { it.lines }.joinToString(" ").trim()
    }

    private fun findTop(b: ByteArray, type: Int): Int {
        var p = 0
        while (p + 8 <= b.size) {
            val l = u32(b, p + 4).toInt()
            if (l < 0 || p + 8 + l > b.size) break
            if (u16(b, p + 2) == type) return p
            p += 8 + l
        }
        return -1
    }

    /** Membaca rantai UserEdit dan mengisi persistId -> posisi; mengembalikan documentRef terbaru. */
    private fun readPersist(b: ByteArray, start: Int, out: HashMap<Int, Int>): Int {
        var pos = start
        var documentRef = 0
        var first = true
        val seen = HashSet<Int>()
        while (pos > 0 && pos + 8 <= b.size && seen.add(pos) && seen.size < 2000) {
            if (u16(b, pos + 2) != T_USER_EDIT) break
            val d = pos + 8
            val offLast = u32(b, d + 8).toInt()
            val offDir = u32(b, d + 12).toInt()
            if (first) { documentRef = u32(b, d + 16).toInt(); first = false }
            if (offDir > 0 && offDir + 8 <= b.size && u16(b, offDir + 2) == T_PERSIST_DIR) {
                val len = u32(b, offDir + 4).toInt()
                var p = offDir + 8
                val end = minOf(offDir + 8 + len, b.size)
                while (p + 4 <= end) {
                    val info = u32(b, p)
                    p += 4
                    val id0 = (info and 0xFFFFF).toInt()
                    val cnt = (info shr 20).toInt()
                    for (k in 0 until cnt) {
                        if (p + 4 > end) break
                        out.putIfAbsent(id0 + k, u32(b, p).toInt())
                        p += 4
                    }
                }
            }
            pos = offLast
        }
        return documentRef
    }

    private fun readContainer(b: ByteArray, off: Int, sd: SlideData) {
        val len = u32(b, off + 4).toInt()
        scan(b, off + 8, minOf(off + 8 + len, b.size), sd, 0, intArrayOf(4))
    }

    private fun scan(b: ByteArray, from: Int, to: Int, sd: SlideData, depth: Int, curType: IntArray) {
        if (depth > 24) return
        var p = from
        while (p + 8 <= to) {
            val ver = u16(b, p) and 0xF
            val type = u16(b, p + 2)
            val l = u32(b, p + 4).toInt()
            if (l < 0 || p + 8 + l > to) break
            if (ver == 0xF) {
                scan(b, p + 8, p + 8 + l, sd, depth + 1, curType)
            } else {
                when (type) {
                    T_TEXT_HEADER -> curType[0] = u32(b, p + 8).toInt()
                    T_TEXT_CHARS, T_TEXT_BYTES -> {
                        val s = decode(b, p + 8, l, type == T_TEXT_CHARS)
                        if (s.isNotEmpty()) sd.texts.add(Text(curType[0], s))
                        curType[0] = 4
                    }
                    T_SSINFO -> if (l >= 12) sd.hidden = (u16(b, p + 8 + 10) and 0x04) != 0
                    T_SLIDE_ATOM -> if (l >= 20) sd.notesId = u32(b, p + 8 + 16)
                }
            }
            p += 8 + l
        }
    }

    private fun decode(b: ByteArray, off: Int, len: Int, unicode: Boolean): List<String> {
        val end = minOf(off + len, b.size)
        if (off < 0 || end <= off) return emptyList()
        val raw = if (unicode) String(b, off, (end - off) and 1.inv(), Charsets.UTF_16LE)
        else String(b, off, end - off, try { charset("windows-1252") } catch (e: Exception) { Charsets.ISO_8859_1 })
        val out = ArrayList<String>()
        for (part in raw.split('\r', '\u000B', '\n')) {
            val t = part.filter { it.code >= 0x20 || it == '\t' }.trim()
            if (t.isNotEmpty()) out.add(if (t.length > OfficeReader.MAX_BLOCK_CHARS) t.substring(0, OfficeReader.MAX_BLOCK_CHARS) + "…" else t)
        }
        return out
    }
}
