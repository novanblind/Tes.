package com.novan.filemanagerpro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File

/**
 * Berkas yang dikirim sebagai dokumen (mis. lewat WhatsApp) berjenis generik, sehingga aplikasi
 * pemutar tidak muncul di "Buka dengan". Layar tanpa tampilan ini mengenali jenis sebenarnya dari
 * ekstensi nama berkas, lalu:
 *  - audio, video, gambar: langsung dibuka di pemutar/penampil bawaan (izin baca dari aplikasi
 *    pengirim hanya hidup selama layar ini ada, jadi harus diteruskan saat itu juga);
 *  - jenis lain (APK, APK+, arsip, PDF, dokumen, dll): disalin dulu ke folder sementara, lalu dibuka
 *    sesuai jenisnya (pemasang APK, penampil arsip, PDF/Office/teks, atau pilihan aplikasi).
 */
class OpenByTypeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent?.data
        if (u == null) { finish(); return }
        val n = Util.displayName(this, u)
        val ext = n.substringAfterLast('.', "").lowercase()
        val mime = if (ext.isEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        val own: Class<*>? = when {
            mime == null -> null
            mime.startsWith("audio/") -> AudioPlayerActivity::class.java
            mime.startsWith("video/") -> VideoPlayerActivity::class.java
            mime.startsWith("image/") -> ImageViewerActivity::class.java
            else -> null
        }
        if (own != null) {
            try {
                startActivity(
                    Intent(this, own).setDataAndType(u, mime!!)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_LONG).show()
            }
            finish()
            return
        }
        Toast.makeText(this, R.string.open_by_type_preparing, Toast.LENGTH_SHORT).show()
        Thread {
            var out: File? = null
            try {
                val dir = File(cacheDir, "open_other").also { it.deleteRecursively(); it.mkdirs() }
                val f = File(dir, n.replace(Regex("[^A-Za-z0-9_.+\\- ]"), "_"))
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                out = f
            } catch (e: Exception) {
                out = null
            }
            runOnUiThread {
                val f = out
                if (f == null) {
                    Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_LONG).show()
                } else {
                    // APK, APK+, XAPK, arsip, PDF, Office, teks, dll: dibuka sesuai jenisnya
                    if (!Util.openSmart(this, f, listOf(f))) {
                        Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_LONG).show()
                    }
                }
                finish()
            }
        }.start()
    }
}
