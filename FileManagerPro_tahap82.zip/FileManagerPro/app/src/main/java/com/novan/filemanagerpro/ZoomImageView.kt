package com.novan.filemanagerpro

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.abs

/**
 * Gambar yang bisa dicubit untuk diperbesar, diketuk dua kali, dan digeser saat diperbesar.
 * Dipakai di dalam ViewPager: saat diperbesar atau disentuh dua jari, geseran tidak mengganti halaman.
 */
class ZoomImageView(ctx: Context) : AppCompatImageView(ctx) {

    private var zoom = 1f

    /** Dipanggil saat gambar diketuk sekali (menampilkan atau menyembunyikan bilah). */
    var onTap: (() -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            setZoom(zoom * d.scaleFactor)
            return true
        }
    })

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            onTap?.invoke()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            setZoom(if (zoom > 1f) 1f else 2.5f)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (zoom > 1f && !scaleDetector.isInProgress) {
                translationX = clampX(translationX - dx)
                translationY = clampY(translationY - dy)
                return true
            }
            return false
        }
    })

    init {
        scaleType = ScaleType.FIT_CENTER
    }

    private fun clampX(v: Float): Float {
        val max = (zoom - 1f) * width / 2f
        return v.coerceIn(-max, max)
    }

    private fun clampY(v: Float): Float {
        val max = (zoom - 1f) * height / 2f
        return v.coerceIn(-max, max)
    }

    fun setZoom(v: Float) {
        zoom = v.coerceIn(1f, 6f)
        scaleX = zoom
        scaleY = zoom
        if (zoom == 1f) {
            translationX = 0f
            translationY = 0f
        } else {
            translationX = clampX(translationX)
            translationY = clampY(translationY)
        }
    }

    fun resetZoom() = setZoom(1f)

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        gestures.onTouchEvent(ev)
        // diperbesar atau dua jari: jangan biarkan ViewPager mengambil geseran
        parent?.requestDisallowInterceptTouchEvent(zoom > 1f || ev.pointerCount > 1)
        if (ev.actionMasked == MotionEvent.ACTION_UP) performClick()
        return true
    }

    override fun performClick(): Boolean {
        return super.performClick()
    }
}
