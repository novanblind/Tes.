package com.novan.githubbynovan;

import android.app.Activity;
import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/**
 * Menyimpan kunci tanda tangan pribadi di GitHub Secrets (terenkripsi) agar repo publik tidak perlu
 * menyimpan keystore dan sandi sebagai berkas. Alur kerja membaca tiga rahasia ini saat build.
 */
public class RahasiaRepo {
    static final String NAMA_KS = "KS_B64";
    static final String NAMA_ALIAS = "KS_ALIAS";
    static final String NAMA_SANDI = "KS_PASS";

    /** Mengirim keystore, alias, dan sandi ke Secrets repo; {@code next} jalan setelah ketiganya tersimpan. */
    static void simpanKunci(final Activity a, final String full, final String token, final byte[] ks,
                            final String alias, final String sandi, final Runnable ulang, final Runnable next) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/secrets/public-key", token, null, (ok, res) -> {
            if (a.isFinishing()) return;
            if (!ok) {
                gagal(a, "Gagal mengambil kunci enkripsi repo", full, res, ulang);
                return;
            }
            JSONObject j = Api.parse(res);
            final String keyId = j.optString("key_id", "");
            final byte[] pk;
            try {
                pk = Base64.decode(j.optString("key", ""), Base64.DEFAULT);
            } catch (Exception e) {
                gagal(a, "Kunci enkripsi repo tidak terbaca", full, String.valueOf(e.getMessage()), ulang);
                return;
            }
            if (keyId.isEmpty() || pk.length != 32) {
                gagal(a, "Kunci enkripsi repo tidak valid", full, "Jawaban GitHub tidak berisi kunci 32 byte.", ulang);
                return;
            }
            final String[] nama = {NAMA_KS, NAMA_ALIAS, NAMA_SANDI};
            final String[] nilai = {Base64.encodeToString(ks, Base64.NO_WRAP), alias, sandi};
            Api.POOL.execute(() -> {
                final String[] enc = new String[nama.length];
                try {
                    for (int i = 0; i < nama.length; i++) {
                        byte[] segel = SegelRahasia.segel(nilai[i].getBytes(StandardCharsets.UTF_8), pk);
                        enc[i] = Base64.encodeToString(segel, Base64.NO_WRAP);
                    }
                } catch (Exception e) {
                    a.runOnUiThread(() -> gagal(a, "Gagal mengenkripsi rahasia", full, String.valueOf(e), ulang));
                    return;
                }
                a.runOnUiThread(() -> kirim(a, full, token, keyId, nama, enc, 0, ulang, next));
            });
        });
    }

    /**
     * Menyimpan satu secret bernama bebas (tambah baru atau timpa yang lama). Nilai dienkripsi di HP dengan
     * kunci publik repo, lalu dikirim; hasilnya lewat {@code cb} di thread utama (ok, pesan galat).
     */
    static void simpanSatu(final Activity a, final String full, final String token, final String nama,
                           final String nilai, final Api.Callback cb) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/secrets/public-key", token, null, (ok, res) -> {
            if (a.isFinishing()) return;
            if (!ok) {
                cb.done(false, res);
                return;
            }
            JSONObject j = Api.parse(res);
            final String keyId = j.optString("key_id", "");
            final byte[] pk;
            try {
                pk = Base64.decode(j.optString("key", ""), Base64.DEFAULT);
            } catch (Exception e) {
                cb.done(false, "Kunci enkripsi repo tidak terbaca.");
                return;
            }
            if (keyId.isEmpty() || pk.length != 32) {
                cb.done(false, "Kunci enkripsi repo tidak valid.");
                return;
            }
            Api.POOL.execute(() -> {
                final String enc;
                try {
                    byte[] segel = SegelRahasia.segel(nilai.getBytes(StandardCharsets.UTF_8), pk);
                    enc = Base64.encodeToString(segel, Base64.NO_WRAP);
                } catch (Exception e) {
                    a.runOnUiThread(() -> cb.done(false, "Gagal mengenkripsi: " + e));
                    return;
                }
                a.runOnUiThread(() -> {
                    if (a.isFinishing()) return;
                    String body = Api.o("encrypted_value", enc, "key_id", keyId).toString();
                    Api.request("PUT", Api.BASE + "/repos/" + full + "/actions/secrets/" + nama, token, body, cb);
                });
            });
        });
    }

    /** Petunjuk bila token kurang izin (403/404) untuk Secrets, Variables, atau pengaman cabang. */
    static String petunjukIzin(String res, String fitur) {
        if (res != null && (res.contains("403") || res.contains("404"))) {
            return res + "\n\nToken perlu izin untuk " + fitur + ". Token klasik: centang scope repo. "
                    + "Token fine-grained: beri izin yang sesuai (Secrets, Variables, atau Administration) "
                    + "dengan akses Read and write pada repo ini. Pastikan juga Anda pemilik atau admin repo.";
        }
        return res;
    }

    private static void kirim(final Activity a, final String full, final String token, final String keyId,
                              final String[] nama, final String[] enc, final int i,
                              final Runnable ulang, final Runnable next) {
        if (a.isFinishing()) return;
        if (i >= nama.length) {
            if (next != null) next.run();
            return;
        }
        String body = Api.o("encrypted_value", enc[i], "key_id", keyId).toString();
        Api.request("PUT", Api.BASE + "/repos/" + full + "/actions/secrets/" + nama[i], token, body, (ok, res) -> {
            if (ok) {
                kirim(a, full, token, keyId, nama, enc, i + 1, ulang, next);
            } else {
                gagal(a, "Gagal menyimpan rahasia " + nama[i], full, res, ulang);
            }
        });
    }

    private static void gagal(Activity a, String judul, String full, String res, Runnable ulang) {
        String info = res;
        if (res.contains("403") || res.contains("404")) {
            info += "\n\nToken perlu izin untuk mengelola Secrets repo. Token klasik: centang scope repo. "
                    + "Token fine-grained: beri izin Secrets (Read and write) pada repo ini. "
                    + "Pastikan juga GitHub Actions aktif di repo.";
        }
        TandaTanganRepo.gagal(a, judul, full, info, ulang);
    }
}
