package id.ytplayer

import android.app.Application
import android.content.Context
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class App : Application() {
    companion object {
        /** Konteks aplikasi (dipakai WebView tersembunyi untuk TikTok). */
        @Volatile
        var ctx: Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        CrashReport.install(this)
        id.ytplayer.music.Prefs.applyTheme(this)   // tema terang/gelap Music Player
        NewPipe.init(DownloaderImpl, Localization("id", "ID"), ContentCountry("ID"))
        // Sekali saja: kualitas audio online dijadikan Terbaik (sebelumnya bawaannya Normal, Opus <= 100 kbps).
        val p = Store.prefs(this)
        if (!p.getBoolean("audio_best_v1", false)) {
            p.edit().putInt(Store.K_AUDIO_QUALITY, Store.AUDIO_TERBAIK).putBoolean("audio_best_v1", true).apply()
        }
        // Pemanasan: ambil info satu video di latar belakang (video terakhir diputar, bila ada) supaya
        // skrip pemutar YouTube dan data sesi sudah siap sebelum pengguna memilih video pertama.
        val warmUrl = try { Store.history(this).firstOrNull()?.url } catch (_: Throwable) { null }
        Repo.prefetch(warmUrl ?: "https://www.youtube.com/watch?v=jNQXAC9IVRw")
    }
}
