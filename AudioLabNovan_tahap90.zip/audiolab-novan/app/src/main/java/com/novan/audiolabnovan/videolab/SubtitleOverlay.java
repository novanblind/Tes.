package com.novan.audiolabnovan.videolab;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.TextOverlay;

import java.util.List;

/** Teks subtitle yang muncul sesuai waktu (mikrodetik, relatif terhadap awal klip). */
@UnstableApi
public final class SubtitleOverlay extends TextOverlay {
    private final List<long[]> times;
    private final List<String> texts;
    private final OverlaySettings settings;
    private final int sizePx;
    private final int color;
    private final boolean background;
    // Objek yang sama dikembalikan terus supaya gambar teks tidak dibuat ulang tiap bingkai.
    private static final SpannableString IDLE_TEXT = new SpannableString(" ");
    private final SpannableString[] cache;

    public SubtitleOverlay(List<long[]> times, List<String> texts, OverlaySettings settings,
                           int sizePx, int color, boolean background) {
        this.times = times;
        this.texts = texts;
        this.settings = settings;
        this.sizePx = sizePx;
        this.color = color;
        this.background = background;
        this.cache = new SpannableString[texts.size()];
    }

    @Override
    public SpannableString getText(long presentationTimeUs) {
        for (int i = 0; i < times.size(); i++) {
            long[] t = times.get(i);
            if (presentationTimeUs >= t[0] && presentationTimeUs < t[1]) {
                if (cache[i] != null) return cache[i];
                SpannableString ss = new SpannableString(texts.get(i));
                int len = ss.length();
                ss.setSpan(new AbsoluteSizeSpan(sizePx), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ss.setSpan(new ForegroundColorSpan(color), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (background) {
                    ss.setSpan(new BackgroundColorSpan(0x99000000), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                cache[i] = ss;
                return ss;
            }
        }
        return IDLE_TEXT;
    }

    @Override
    public OverlaySettings getOverlaySettings(long presentationTimeUs) {
        return settings;
    }
}
