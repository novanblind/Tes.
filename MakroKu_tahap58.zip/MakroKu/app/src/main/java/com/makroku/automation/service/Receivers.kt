package com.makroku.automation.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.makroku.automation.MakroApp
import com.makroku.automation.adb.AdbBackend
import com.makroku.automation.model.TriggerEvent

/** Menyalakan/mematikan layanan latar depan sesuai saklar utama. */
fun applyAppEnabled(ctx: Context, on: Boolean) {
    val i = Intent(ctx, AutomationService::class.java)
    if (on) runCatching { ContextCompat.startForegroundService(ctx, i) } else runCatching { ctx.stopService(i) }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as MakroApp
        // Alarm-jam boleh memulai layanan latar depan dari latar belakang; pastikan layanan hidup.
        if (app.repo.appEnabled.value) applyAppEnabled(context, true)
        app.engine.fireScheduled(intent.getLongExtra("macroId", 0L), intent.getIntExtra("idx", 0))
    }
}

/** Menerima ketukan tombol pada notifikasi buatan aksi "Tampilkan notifikasi" lalu memicu pemicu Tombol notifikasi. */
class NotifButtonReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val label = intent.getStringExtra("label").orEmpty()
        val nid = intent.getIntExtra("nid", 0)
        context.getSystemService(android.app.NotificationManager::class.java).cancel(nid)
        (context.applicationContext as MakroApp).engine.dispatch(TriggerEvent("notif_button", mapOf("button" to label)))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if ((context.applicationContext as MakroApp).repo.appEnabled.value) runCatching {
            ContextCompat.startForegroundService(context, Intent(context, AutomationService::class.java))
        }
        // Setelah restart, nyalakan lagi Debugging nirkabel dan sambung ADB di latar belakang (bila sudah dipasangkan).
        if (AdbBackend.dipasangkan(context)) {
            val pr = goAsync()
            Thread {
                try {
                    AdbBackend.aktifkanDebugging(context)
                    AdbBackend.pastikanTersambung(context, 5)
                } finally { pr.finish() }
            }.start()
        }
        (context.applicationContext as MakroApp).engine.dispatch(TriggerEvent("boot"))
    }
}
