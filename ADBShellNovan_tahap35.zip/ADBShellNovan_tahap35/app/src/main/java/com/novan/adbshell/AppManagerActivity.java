package com.novan.adbshell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Kelola aplikasi (sistem dan pengguna) lewat ADB (pengguna 0):
 * nonaktifkan, aktifkan kembali, hapus instalan, dan kembalikan yang sudah dihapus instalan.
 * Tekan lama (ketuk dua kali tahan) satu aplikasi untuk mulai memilih banyak aplikasi sekaligus.
 */
public class AppManagerActivity extends Activity {
    private static final int AKTIF = 0, NONAKTIF = 1, DIHAPUS = 2;
    private static final String[] NAMA_FILTER = {"Aktif", "Dinonaktifkan", "Dihapus"};

    /** Paket inti: salah hapus/nonaktif bisa membuat HP bootloop atau layar kosong. */
    static final Set<String> INTI = new HashSet<>();
    static {
        Collections.addAll(INTI, "android", "com.android.systemui", "com.android.settings",
                "com.android.phone", "com.android.shell", "com.android.providers.settings",
                "com.android.providers.contacts", "com.android.providers.telephony",
                "com.android.packageinstaller", "com.google.android.packageinstaller",
                "com.android.permissioncontroller", "com.google.android.permissioncontroller",
                "com.android.server.telecom", "com.android.bluetooth", "com.android.nfc",
                "com.google.android.gms", "com.google.android.gsf", "com.android.vending",
                "com.android.inputmethod.latin", "com.google.android.inputmethod.latin",
                "com.android.launcher3", "com.google.android.apps.nexuslauncher");
    }

    static class Item {
        String pkg, label;
        int state;
        String text() {
            return label.equals(pkg) ? pkg : label + " (" + pkg + ")";
        }
    }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private final Button[] btnFilter = new Button[3];
    private final int[] jumlah = new int[3];
    private int filter = AKTIF;
    /** Cakupan daftar: false = aplikasi sistem, true = aplikasi yang Anda pasang. */
    private boolean pengguna = false;
    private Button btnCakupan;
    private EditText etCari;
    private TextView tvStatus;
    private ListView list;
    private PilihAdapter adapter;
    private LinearLayout barPilih;
    private TextView tvJumlahPilih;
    private LinearLayout barisAksiPilih;
    private volatile String pesanTunda;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Kelola aplikasi");
        int pad = (int) (8 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout barisFilter = new LinearLayout(this);
        for (int i = 0; i < 3; i++) {
            final int f = i;
            btnFilter[i] = new Button(this);
            btnFilter[i].setText(NAMA_FILTER[i]);
            btnFilter[i].setOnClickListener(v -> { filter = f; batalPilih(false); refreshList(true); });
            barisFilter.addView(btnFilter[i], new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(barisFilter);

        etCari = new EditText(this);
        etCari.setHint("Cari nama atau paket");
        etCari.setContentDescription("Cari nama atau paket aplikasi. Ketuk aplikasi di daftar untuk membuka menu tindakan.");
        etCari.setInputType(InputType.TYPE_CLASS_TEXT);
        etCari.setSingleLine(true);
        etCari.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void afterTextChanged(Editable e) { refreshList(false); }
        });
        root.addView(etCari);

        LinearLayout barisAksi = new LinearLayout(this);
        btnCakupan = new Button(this);
        btnCakupan.setText("Cakupan: sistem (ganti)");
        btnCakupan.setOnClickListener(v -> {
            pengguna = !pengguna;
            batalPilih(false);
            all.clear();
            refreshList(false);
            load();
        });
        Button btnMuat = new Button(this);
        btnMuat.setText("Muat ulang daftar");
        btnMuat.setOnClickListener(v -> load());
        barisAksi.addView(btnCakupan, new LinearLayout.LayoutParams(0, -2, 1f));
        barisAksi.addView(btnMuat, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(barisAksi);

        tvStatus = new TextView(this);
        tvStatus.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(tvStatus);

        // Bilah mode pilih: muncul setelah tekan lama satu aplikasi.
        barPilih = new LinearLayout(this);
        barPilih.setOrientation(LinearLayout.VERTICAL);
        barPilih.setVisibility(View.GONE);
        tvJumlahPilih = new TextView(this);
        tvJumlahPilih.setPadding(0, 0, 0, pad / 2);
        barPilih.addView(tvJumlahPilih);
        LinearLayout barisPilihUmum = new LinearLayout(this);
        Button btnSemua = new Button(this);
        btnSemua.setText("Pilih semua yang tampil");
        btnSemua.setOnClickListener(v -> pilihSemua());
        Button btnBatalPilih = new Button(this);
        btnBatalPilih.setText("Batal pilih");
        btnBatalPilih.setOnClickListener(v -> batalPilih(true));
        barisPilihUmum.addView(btnSemua, new LinearLayout.LayoutParams(0, -2, 1f));
        barisPilihUmum.addView(btnBatalPilih, new LinearLayout.LayoutParams(0, -2, 1f));
        barPilih.addView(barisPilihUmum);
        barisAksiPilih = new LinearLayout(this);
        barPilih.addView(barisAksiPilih);
        root.addView(barPilih);

        adapter = new PilihAdapter(this);
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < 0 || pos >= shown.size()) return;
            if (adapter.isModePilih()) balikPilih(shown.get(pos));
            else pilih(shown.get(pos));
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos < 0 || pos >= shown.size()) return false;
            if (!adapter.isModePilih()) mulaiPilih();
            balikPilih(shown.get(pos));
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);

        PairHelper.sink = s -> status(s);
        load();
    }

    private void status(final String s) {
        runOnUiThread(() -> {
            tvStatus.setText(s);
            tvStatus.announceForAccessibility(s);
        });
    }

    // ---------- Memuat daftar ----------

    private static Set<String> parse(String out) {
        Set<String> r = new HashSet<>();
        if (out == null) return r;
        for (String line : out.split("\\r?\\n")) {
            line = line.trim();
            if (line.startsWith("package:")) r.add(line.substring(8).trim());
        }
        return r;
    }

    private Adb siapAdb() throws Exception {
        Adb a = Adb.get(this);
        if (!a.isConnected()) {
            status("Menyambung...");
            PairHelper.connect(this, true);
        }
        if (!a.isConnected()) {
            status("Belum tersambung. Sambungkan dulu di layar utama, lalu muat ulang.");
            return null;
        }
        return a;
    }

    private void load() {
        if (pesanTunda == null) status(pengguna ? "Memuat daftar aplikasi pengguna..." : "Memuat daftar aplikasi sistem...");
        io.execute(() -> {
            try {
                Adb a = siapAdb();
                if (a == null) return;
                final boolean pg = pengguna;
                String f = pg ? "-3" : "-s";
                Set<String> semua = parse(Shell.run(a, "shell:pm list packages " + f + " -u --user 0", null));
                Set<String> terpasang = parse(Shell.run(a, "shell:pm list packages " + f + " --user 0", null));
                Set<String> mati = parse(Shell.run(a, "shell:pm list packages " + f + " -d --user 0", null));
                if (pg != pengguna) return; // cakupan sudah diganti saat memuat
                if (semua.isEmpty()) {
                    status(pg ? "Tidak ada aplikasi pengguna ditemukan." : "Daftar kosong. Pastikan sudah tersambung lalu muat ulang.");
                    return;
                }
                PackageManager pm = getPackageManager();
                List<Item> hasil = new ArrayList<>();
                for (String p : semua) {
                    Item it = new Item();
                    it.pkg = p;
                    it.label = p;
                    try {
                        @SuppressWarnings("deprecation")
                        CharSequence l = pm.getApplicationLabel(
                                pm.getApplicationInfo(p, PackageManager.GET_UNINSTALLED_PACKAGES));
                        if (l != null && l.length() > 0) it.label = l.toString();
                    } catch (Throwable ignored) {}
                    if (!terpasang.contains(p)) it.state = DIHAPUS;
                    else if (mati.contains(p)) it.state = NONAKTIF;
                    else it.state = AKTIF;
                    hasil.add(it);
                }
                Collections.sort(hasil, (x, y) -> x.label.toLowerCase(Locale.ROOT)
                        .compareTo(y.label.toLowerCase(Locale.ROOT)));
                runOnUiThread(() -> {
                    all.clear();
                    all.addAll(hasil);
                    String pt = pesanTunda;
                    pesanTunda = null;
                    refreshList(pt == null);
                    if (pt != null) status(pt + " Daftar " + NAMA_FILTER[filter] + ": " + shown.size() + " aplikasi.");
                });
            } catch (Throwable e) {
                status("Gagal memuat: " + e);
            }
        });
    }

    private void refreshList(boolean umumkan) {
        jumlah[0] = jumlah[1] = jumlah[2] = 0;
        for (Item it : all) jumlah[it.state]++;
        String q = etCari.getText().toString().trim().toLowerCase(Locale.ROOT);
        shown.clear();
        adapter.kosongkan();
        // Buang pilihan yang sudah tidak ada atau keadaannya berubah (mis. setelah muat ulang).
        if (!adapter.terpilih().isEmpty()) {
            Set<String> ada = new HashSet<>();
            for (Item it : all) if (it.state == filter) ada.add(it.pkg);
            adapter.terpilih().retainAll(ada);
            if (adapter.terpilih().isEmpty()) adapter.setModePilih(false);
        }
        for (Item it : all) {
            if (it.state != filter) continue;
            if (!q.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(q)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(it);
            adapter.tambah(it.pkg, it.text() + (INTI.contains(it.pkg) ? " - paket inti" : ""));
        }
        adapter.notifyDataSetChanged();
        perbaruiBarPilih();
        for (int i = 0; i < 3; i++) {
            btnFilter[i].setText(NAMA_FILTER[i] + " (" + jumlah[i] + ")"
                    + (i == filter ? " - dipilih" : ""));
        }
        btnCakupan.setText(pengguna ? "Cakupan: pengguna (ganti)"
                : "Cakupan: sistem (ganti)");
        if (umumkan) status("Daftar " + NAMA_FILTER[filter] + ": " + shown.size() + " aplikasi");
    }

    // ---------- Pilih banyak aplikasi ----------

    private void mulaiPilih() {
        adapter.setModePilih(true);
        adapter.notifyDataSetChanged();
        perbaruiBarPilih();
    }

    private void balikPilih(Item it) {
        boolean cek = adapter.balik(it.pkg);
        int n = adapter.terpilih().size();
        if (n == 0) {
            batalPilih(false);
            status(it.label + " tidak dicentang. Mode pilih ditutup.");
            return;
        }
        adapter.notifyDataSetChanged();
        perbaruiBarPilih();
        status(it.label + (cek ? " dicentang. " : " tidak dicentang. ") + n + " aplikasi dipilih.");
    }

    private void pilihSemua() {
        for (Item it : shown) adapter.terpilih().add(it.pkg);
        adapter.notifyDataSetChanged();
        perbaruiBarPilih();
        status("Semua " + shown.size() + " aplikasi yang tampil dicentang. "
                + adapter.terpilih().size() + " aplikasi dipilih.");
    }

    private void batalPilih(boolean umumkan) {
        boolean tadi = adapter != null && adapter.isModePilih();
        if (adapter != null) {
            adapter.terpilih().clear();
            adapter.setModePilih(false);
            adapter.notifyDataSetChanged();
        }
        if (barPilih != null) barPilih.setVisibility(View.GONE);
        if (umumkan && tadi) status("Pilihan dibatalkan.");
    }

    /** Isi ulang bilah pilih: jumlah terpilih dan tombol tindakan sesuai daftar yang sedang dibuka. */
    private void perbaruiBarPilih() {
        if (!adapter.isModePilih()) {
            barPilih.setVisibility(View.GONE);
            return;
        }
        barPilih.setVisibility(View.VISIBLE);
        tvJumlahPilih.setText(adapter.terpilih().size() + " aplikasi dipilih. Ketuk aplikasi untuk mencentang atau menghapus centang.");
        barisAksiPilih.removeAllViews();
        if (filter == AKTIF) {
            tambahAksiPilih("Nonaktifkan terpilih", "nonaktifkan");
            tambahAksiPilih("Hapus instalan terpilih", "hapus");
        } else if (filter == NONAKTIF) {
            tambahAksiPilih("Aktifkan terpilih", "enable");
            tambahAksiPilih("Hapus instalan terpilih", "hapus");
        } else {
            tambahAksiPilih("Kembalikan terpilih", "restore");
        }
    }

    private void tambahAksiPilih(String nama, final String aksi) {
        Button b = new Button(this);
        b.setText(nama);
        b.setOnClickListener(v -> konfirmasiBanyak(aksi));
        barisAksiPilih.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private List<Item> daftarTerpilih() {
        List<Item> r = new ArrayList<>();
        for (Item it : all) {
            if (it.state == filter && adapter.terpilih().contains(it.pkg)) r.add(it);
        }
        return r;
    }

    private static boolean terlarang(Item it, String paketSendiri) {
        return it.pkg.equals(paketSendiri) || it.pkg.equals("android");
    }

    private void konfirmasiBanyak(final String aksi) {
        final List<Item> dipilih = daftarTerpilih();
        if (dipilih.isEmpty()) {
            status("Belum ada aplikasi yang dicentang.");
            return;
        }
        int tertahan = 0, inti = 0;
        StringBuilder nama = new StringBuilder();
        int tampil = 0;
        for (Item it : dipilih) {
            if (terlarang(it, getPackageName())) { tertahan++; continue; }
            if (INTI.contains(it.pkg) || it.pkg.startsWith("com.android.providers.")) inti++;
            if (tampil < 8) { nama.append("\n- ").append(it.label); tampil++; }
        }
        int jalan = dipilih.size() - tertahan;
        if (jalan == 0) {
            status("Paket yang dipilih tidak boleh diubah.");
            return;
        }
        if (jalan > tampil) nama.append("\n- dan ").append(jalan - tampil).append(" lainnya");
        String kata = aksi.equals("hapus") ? "menghapus instalan"
                : aksi.equals("nonaktifkan") ? "menonaktifkan"
                : aksi.equals("enable") ? "mengaktifkan kembali" : "mengembalikan instalan";
        String msg = "Yakin " + kata + " " + jalan + " aplikasi?" + nama;
        if (tertahan > 0) msg += "\n\n" + tertahan + " paket dilewati karena tidak boleh diubah (aplikasi ini atau paket android).";
        if (aksi.equals("hapus")) {
            msg += pengguna ? "\n\nAplikasi dihapus beserta datanya. Untuk memasang lagi, gunakan Pasang APK."
                    : "\n\nAplikasi sistem tetap bisa dikembalikan dari daftar Dihapus, tetapi datanya ikut terhapus.";
        } else if (aksi.equals("nonaktifkan")) {
            msg += "\n\nBisa diaktifkan kembali dari daftar Dinonaktifkan.";
        }
        if (inti > 0 && (aksi.equals("hapus") || aksi.equals("nonaktifkan"))) {
            msg += "\n\nPERINGATAN KERAS: " + inti + " di antaranya paket inti sistem. Salah langkah bisa membuat HP "
                    + "macet saat menyala atau layar tidak berfungsi. Lanjutkan hanya jika Anda yakin.";
        }
        String tombol = aksi.equals("hapus") ? "Hapus instalan semua"
                : aksi.equals("nonaktifkan") ? "Nonaktifkan semua"
                : aksi.equals("enable") ? "Aktifkan semua" : "Kembalikan semua";
        new AlertDialog.Builder(this)
                .setTitle(inti > 0 ? "Peringatan" : "Konfirmasi")
                .setMessage(msg)
                .setPositiveButton(tombol, (d, w) -> jalankanBanyak(dipilih, aksi))
                .setNegativeButton("Batal", null)
                .show();
    }

    private void jalankanBanyak(final List<Item> dipilih, final String aksi) {
        final String sendiri = getPackageName();
        batalPilih(false);
        status("Memproses " + dipilih.size() + " aplikasi...");
        io.execute(() -> {
            try {
                Adb a = siapAdb();
                if (a == null) return;
                int ok = 0, lewat = 0, no = 0;
                StringBuilder gagalNama = new StringBuilder();
                int i = 0;
                for (Item it : dipilih) {
                    if (Thread.currentThread().isInterrupted()) return;
                    i++;
                    if (terlarang(it, sendiri)) { lewat++; continue; }
                    status("Memproses " + i + " dari " + dipilih.size() + ": " + it.label);
                    String out = perintahAksi(a, it.pkg, aksi);
                    if (adaGagal(out)) {
                        no++;
                        if (no <= 5) gagalNama.append("\n- ").append(it.label).append(": ")
                                .append(out == null ? "" : out.trim());
                    } else {
                        ok++;
                    }
                }
                String kata = aksi.equals("hapus") ? "dihapus instalannya"
                        : aksi.equals("nonaktifkan") ? "dinonaktifkan"
                        : aksi.equals("enable") ? "diaktifkan kembali" : "dikembalikan";
                String hasil = ok + " aplikasi " + kata + ".";
                if (no > 0) hasil += " " + no + " gagal:" + gagalNama;
                if (lewat > 0) hasil += " " + lewat + " dilewati.";
                pesanTunda = hasil;
                runOnUiThread(this::load);
            } catch (Throwable e) {
                status("Gagal: " + e);
            }
        });
    }

    @Override public void onBackPressed() {
        if (adapter != null && adapter.isModePilih()) batalPilih(true);
        else super.onBackPressed();
    }

    // ---------- Tindakan ----------

    /** Dialog menu tindakan, sesuai keadaan aplikasi (aktif, dinonaktifkan, atau sudah dihapus). */
    private void pilih(final Item it) {
        final String[] nama;
        final Runnable[] aksi;
        if (it.state == AKTIF) {
            nama = new String[]{"Nonaktifkan aplikasi", "Hapus instalan"};
            aksi = new Runnable[]{() -> konfirmasi(it, "nonaktifkan"), () -> konfirmasi(it, "hapus")};
        } else if (it.state == NONAKTIF) {
            nama = new String[]{"Aktifkan aplikasi", "Hapus instalan"};
            aksi = new Runnable[]{() -> jalankan(it, "enable"), () -> konfirmasi(it, "hapus")};
        } else {
            nama = new String[]{"Kembalikan instalan aplikasi"};
            aksi = new Runnable[]{() -> jalankan(it, "restore")};
        }
        new AlertDialog.Builder(this)
                // Jangan pakai setMessage bersama setItems: Android menyembunyikan daftar pilihan.
                .setTitle(it.label + "\n" + it.pkg + (INTI.contains(it.pkg) ? " (paket inti sistem)" : ""))
                .setItems(nama, (d, which) -> aksi[which].run())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void konfirmasi(final Item it, final String aksi) {
        if (it.pkg.equals(getPackageName()) || it.pkg.equals("android")) {
            status("Paket ini tidak boleh diubah.");
            return;
        }
        boolean inti = INTI.contains(it.pkg) || it.pkg.startsWith("com.android.providers.");
        String kata = aksi.equals("hapus") ? "menghapus instalan" : "menonaktifkan";
        String msg = "Yakin " + kata + " " + it.label + " (" + it.pkg + ")?";
        if (aksi.equals("hapus")) {
            msg += pengguna ? "\nAplikasi dihapus beserta datanya. Untuk memasang lagi, gunakan Pasang APK."
                    : "\nAplikasi sistem tetap bisa dikembalikan dari daftar Dihapus, tetapi datanya ikut terhapus.";
        } else {
            msg += "\nBisa diaktifkan kembali dari daftar Dinonaktifkan.";
        }
        if (inti) {
            msg += "\n\nPERINGATAN KERAS: ini paket inti sistem. Salah langkah bisa membuat HP "
                    + "macet saat menyala atau layar tidak berfungsi. Lanjutkan hanya jika Anda yakin.";
        }
        new AlertDialog.Builder(this)
                .setTitle(inti ? "Peringatan" : "Konfirmasi")
                .setMessage(msg)
                .setPositiveButton(aksi.equals("hapus") ? "Hapus instalan" : "Nonaktifkan",
                        (d, w) -> jalankan(it, aksi))
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Jalankan satu tindakan untuk satu paket; mengembalikan keluaran perintah. */
    private static String perintahAksi(Adb a, String p, String aksi) throws Exception {
        switch (aksi) {
            case "nonaktifkan":
                return Shell.run(a, "shell:pm disable-user --user 0 " + p, null);
            case "hapus":
                return Shell.run(a, "shell:pm uninstall --user 0 " + p, null);
            case "enable":
                return Shell.run(a, "shell:pm enable --user 0 " + p, null);
            default:
                String out = Shell.run(a, "shell:cmd package install-existing --user 0 " + p, null);
                // jika sebelumnya juga dinonaktifkan, pastikan aktif
                Shell.run(a, "shell:pm enable --user 0 " + p, null);
                return out;
        }
    }

    private static boolean adaGagal(String out) {
        String low = (out == null ? "" : out.trim()).toLowerCase(Locale.ROOT);
        return low.contains("exception") || low.contains("failure")
                || low.contains("error") || low.contains("unknown package")
                || low.contains("not installed") || low.contains("cannot");
    }

    private void jalankan(final Item it, final String aksi) {
        status("Memproses " + it.label + "...");
        io.execute(() -> {
            try {
                Adb a = siapAdb();
                if (a == null) return;
                String out = perintahAksi(a, it.pkg, aksi);
                String berhasil = it.label + (aksi.equals("nonaktifkan") ? " dinonaktifkan."
                        : aksi.equals("hapus") ? " dihapus instalannya."
                        : aksi.equals("enable") ? " diaktifkan kembali." : " dikembalikan.");
                String t = out == null ? "" : out.trim();
                pesanTunda = adaGagal(out) ? "Gagal: " + t : berhasil;
                runOnUiThread(this::load);
            } catch (Throwable e) {
                status("Gagal: " + e);
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
