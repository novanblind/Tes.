package id.ytplayer

import android.os.Handler
import android.os.Looper

/**
 * Antrean putar yang mengikuti daftar yang sedang tampil saat sebuah video dipilih
 * (hasil pencarian, beranda, favorit, atau riwayat). Dipakai tombol "berikutnya" dan
 * "sebelumnya" di layar pemutar, notifikasi, layar kunci, headset, serta putar otomatis,
 * di mode YTPlayer maupun YouTube Musik.
 *
 * Bila video yang sedang diputar tidak ada di antrean (mis. dibuka dari daftar "terkait"
 * atau dari tautan), pemanggil memakai cara lama: video terkait pertama yang belum diputar.
 */
object PlayQueue {
    private val items = ArrayList<VideoItem>()
    private var sourceId = 0
    private var counter = 0
    private var loader: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    /** Nomor sumber baru: tiap kali isi daftar diganti, daftar itu dianggap sumber yang baru. */
    @Synchronized
    fun newSourceId(): Int = ++counter

    /** Jadikan [list] antrean. [loader] memuat halaman hasil berikutnya (boleh null). */
    @Synchronized
    fun set(list: List<VideoItem>, source: Int, loader: (() -> Unit)?) {
        items.clear()
        items.addAll(list.filter { it.url.isNotBlank() })
        sourceId = source
        this.loader = loader
    }

    /** Daftar sumber bertambah (hasil pencarian dimuat lagi): ikut tambahkan ke antrean. */
    @Synchronized
    fun append(source: Int, list: List<VideoItem>) {
        if (source != sourceId || items.isEmpty()) return
        val have = items.mapTo(HashSet()) { idOf(it.url) }
        for (v in list) if (v.url.isNotBlank() && have.add(idOf(v.url))) items.add(v)
    }

    @Synchronized
    fun remove(source: Int, url: String) {
        if (source != sourceId) return
        val k = idOf(url)
        items.removeAll { idOf(it.url) == k }
    }

    @Synchronized
    fun detachLoader(source: Int) {
        if (source == sourceId) loader = null
    }

    @Synchronized
    fun clear() {
        items.clear()
        loader = null
    }

    private fun idOf(url: String): String {
        val m = Regex("[?&]v=([\\w-]{6,})").find(url)
        return m?.groupValues?.get(1) ?: url.trim()
    }

    private fun indexOfLocked(url: String): Int {
        if (url.isBlank()) return -1
        val k = idOf(url)
        return items.indexOfFirst { idOf(it.url) == k }
    }

    @Synchronized
    fun contains(url: String): Boolean = indexOfLocked(url) >= 0

    /** Video sesudah [url] di antrean (siaran langsung dilewati), atau null bila sudah di ujung / tidak ada di antrean. */
    fun next(url: String): VideoItem? {
        var result: VideoItem? = null
        var needMore = false
        var ld: (() -> Unit)? = null
        synchronized(this) {
            val i = indexOfLocked(url)
            if (i < 0) return null
            var j = i + 1
            while (j < items.size && items[j].isLive) j++
            if (j < items.size) result = items[j]
            needMore = j >= items.size - 3
            ld = loader
        }
        val run = ld
        if (needMore && run != null) main.post { run() }
        return result
    }

    /** Video sebelum [url] di antrean (siaran langsung dilewati), atau null. */
    @Synchronized
    fun previous(url: String): VideoItem? {
        val i = indexOfLocked(url)
        if (i <= 0) return null
        var j = i - 1
        while (j >= 0 && items[j].isLive) j--
        return if (j >= 0) items[j] else null
    }
}
