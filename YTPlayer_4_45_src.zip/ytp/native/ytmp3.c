/*
 * Konverter audio -> MP3 (tanpa FFmpeg penuh). Memakai pustaka libav* hasil build ramping
 * (hanya dekoder AAC/Opus/Vorbis/MP3, pembuka M4A/MP4/WebM/Ogg, encoder libmp3lame, muxer MP3).
 * Satu-satunya jalur konversi MP3 di aplikasi (tanpa cadangan).
 */
#include <jni.h>
#include <stdio.h>
#include <string.h>
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/audio_fifo.h>
#include <libavutil/channel_layout.h>
#include <libavutil/opt.h>
#include <libavutil/samplefmt.h>
#include <libswresample/swresample.h>

typedef struct {
    JNIEnv *env;
    jobject cb;
    jmethodID mid;
    int lastPct;
    int cancelled;
} Prog;

static int report(Prog *p, int pct) {
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    if (pct == p->lastPct) return 1;
    p->lastPct = pct;
    jboolean cont = (*p->env)->CallBooleanMethod(p->env, p->cb, p->mid, (jint)pct);
    if ((*p->env)->ExceptionCheck(p->env)) { (*p->env)->ExceptionClear(p->env); return 1; }
    if (!cont) p->cancelled = 1;
    return cont ? 1 : 0;
}

static int valid_rate(int r) {
    static const int ok[] = {8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000};
    for (unsigned i = 0; i < sizeof(ok) / sizeof(ok[0]); i++) if (ok[i] == r) return 1;
    return 0;
}

/* Bitrate MP3 sah untuk laju sampel (MPEG-1: 32-320, MPEG-2: 8-160, MPEG-2.5: 8-64). */
static int valid_bitrate(int rate, int kbps) {
    static const int valid[] = {8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320};
    int max = rate >= 32000 ? 320 : (rate >= 16000 ? 160 : 64);
    int best = valid[0];
    for (unsigned i = 0; i < sizeof(valid) / sizeof(valid[0]); i++)
        if (valid[i] <= max && valid[i] <= kbps) best = valid[i];
    return best;
}

/* Kualitas VBR LAME (0 terbaik .. 9 terkecil) dari target bitrate rata-rata (kbps), mendekati V0..V9. */
static int vbr_quality(int kbps) {
    if (kbps >= 240) return 0;
    if (kbps >= 215) return 1;
    if (kbps >= 185) return 2;
    if (kbps >= 170) return 3;
    if (kbps >= 150) return 4;
    if (kbps >= 125) return 5;
    if (kbps >= 105) return 6;
    if (kbps >= 90) return 7;
    if (kbps >= 75) return 8;
    return 9;
}

typedef struct {
    AVFormatContext *ic, *oc;
    AVCodecContext *dec, *enc;
    SwrContext *swr;
    AVAudioFifo *fifo;
    AVPacket *pkt, *opkt;
    AVFrame *frame, *conv;
    AVStream *ost;
    int64_t next_pts;
} Ctx;

static void free_ctx(Ctx *c) {
    if (c->fifo) av_audio_fifo_free(c->fifo);
    if (c->swr) swr_free(&c->swr);
    if (c->frame) av_frame_free(&c->frame);
    if (c->conv) av_frame_free(&c->conv);
    if (c->pkt) av_packet_free(&c->pkt);
    if (c->opkt) av_packet_free(&c->opkt);
    if (c->dec) avcodec_free_context(&c->dec);
    if (c->enc) avcodec_free_context(&c->enc);
    if (c->oc) {
        if (c->oc->pb) avio_closep(&c->oc->pb);
        avformat_free_context(c->oc);
        c->oc = NULL;
    }
    if (c->ic) avformat_close_input(&c->ic);
}

static int write_encoded(Ctx *c) {
    int r;
    while ((r = avcodec_receive_packet(c->enc, c->opkt)) >= 0) {
        c->opkt->stream_index = c->ost->index;
        av_packet_rescale_ts(c->opkt, c->enc->time_base, c->ost->time_base);
        r = av_interleaved_write_frame(c->oc, c->opkt);
        av_packet_unref(c->opkt);
        if (r < 0) return r;
    }
    return (r == AVERROR(EAGAIN) || r == AVERROR_EOF) ? 0 : r;
}

/* Ambil dari fifo, enkode per bingkai penuh (atau semua sisa bila flush). */
static int drain_fifo(Ctx *c, int flush) {
    int fs = c->enc->frame_size > 0 ? c->enc->frame_size : 1152;
    while (av_audio_fifo_size(c->fifo) >= fs || (flush && av_audio_fifo_size(c->fifo) > 0)) {
        int n = FFMIN(av_audio_fifo_size(c->fifo), fs);
        AVFrame *f = av_frame_alloc();
        if (!f) return AVERROR(ENOMEM);
        f->nb_samples = n;
        f->format = c->enc->sample_fmt;
        f->sample_rate = c->enc->sample_rate;
        av_channel_layout_copy(&f->ch_layout, &c->enc->ch_layout);
        int r = av_frame_get_buffer(f, 0);
        if (r >= 0 && av_audio_fifo_read(c->fifo, (void **)f->data, n) < n) r = AVERROR(EIO);
        if (r >= 0) {
            f->pts = c->next_pts;
            c->next_pts += n;
            r = avcodec_send_frame(c->enc, f);
        }
        av_frame_free(&f);
        if (r < 0) return r;
        r = write_encoded(c);
        if (r < 0) return r;
    }
    return 0;
}

static int push_samples(Ctx *c, const uint8_t **in, int in_n) {
    int max_out = swr_get_out_samples(c->swr, in_n);
    if (max_out < 0) return max_out;
    if (max_out == 0) return 0;
    av_frame_unref(c->conv);
    c->conv->nb_samples = max_out;
    c->conv->format = c->enc->sample_fmt;
    c->conv->sample_rate = c->enc->sample_rate;
    av_channel_layout_copy(&c->conv->ch_layout, &c->enc->ch_layout);
    int r = av_frame_get_buffer(c->conv, 0);
    if (r < 0) return r;
    int got = swr_convert(c->swr, c->conv->data, max_out, in, in_n);
    if (got < 0) return got;
    if (got > 0) {
        r = av_audio_fifo_write(c->fifo, (void **)c->conv->data, got);
        if (r < got) return AVERROR(EIO);
    }
    return 0;
}

static int decode_packet(Ctx *c, AVPacket *pkt) {
    int r = avcodec_send_packet(c->dec, pkt);
    if (r < 0 && r != AVERROR_EOF) return r;
    for (;;) {
        r = avcodec_receive_frame(c->dec, c->frame);
        if (r == AVERROR(EAGAIN) || r == AVERROR_EOF) return 0;
        if (r < 0) return r;
        r = push_samples(c, (const uint8_t **)c->frame->extended_data, c->frame->nb_samples);
        av_frame_unref(c->frame);
        if (r < 0) return r;
        r = drain_fifo(c, 0);
        if (r < 0) return r;
    }
}

static void throw_io(JNIEnv *env, const char *what, int err) {
    char buf[160], msg[256];
    av_strerror(err, buf, sizeof buf);
    snprintf(msg, sizeof msg, "Konversi MP3 gagal (%s): %s", what, buf);
    jclass ex = (*env)->FindClass(env, "java/io/IOException");
    if (ex) (*env)->ThrowNew(env, ex, msg);
}

/* @return true bila selesai; false bila dibatalkan; melempar IOException bila gagal. */
JNIEXPORT jboolean JNICALL
Java_id_ytplayer_FfmpegMp3_nConvert(JNIEnv *env, jclass clazz, jstring jsrc, jstring jdst, jint kbps, jobject cb) {
    Ctx c;
    memset(&c, 0, sizeof c);
    Prog pr = {env, cb, NULL, -1, 0};
    jclass cbc = (*env)->GetObjectClass(env, cb);
    pr.mid = (*env)->GetMethodID(env, cbc, "onProgress", "(I)Z");
    if (!pr.mid) return JNI_FALSE;
    const char *src = (*env)->GetStringUTFChars(env, jsrc, NULL);
    const char *dst = (*env)->GetStringUTFChars(env, jdst, NULL);
    int r = 0, ast = -1;
    const char *what = "buka berkas";
    int done = 0;

    av_log_set_level(AV_LOG_QUIET);
    r = avformat_open_input(&c.ic, src, NULL, NULL);
    if (r < 0) goto fail;
    what = "baca info";
    r = avformat_find_stream_info(c.ic, NULL);
    if (r < 0) goto fail;
    ast = av_find_best_stream(c.ic, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    if (ast < 0) { r = ast; what = "cari trek audio"; goto fail; }
    AVStream *ist = c.ic->streams[ast];

    what = "buka dekoder";
    const AVCodec *dc = avcodec_find_decoder(ist->codecpar->codec_id);
    if (!dc) { r = AVERROR_DECODER_NOT_FOUND; goto fail; }
    c.dec = avcodec_alloc_context3(dc);
    if (!c.dec) { r = AVERROR(ENOMEM); goto fail; }
    r = avcodec_parameters_to_context(c.dec, ist->codecpar);
    if (r < 0) goto fail;
    c.dec->pkt_timebase = ist->time_base;
    r = avcodec_open2(c.dec, dc, NULL);
    if (r < 0) goto fail;

    int in_rate = c.dec->sample_rate;
    int in_ch = c.dec->ch_layout.nb_channels;
    if (in_rate <= 0 || in_ch <= 0) { r = AVERROR_INVALIDDATA; goto fail; }
    int out_rate = valid_rate(in_rate) ? in_rate : 44100;
    int out_ch = in_ch == 1 ? 1 : 2;
    int bitrate = valid_bitrate(out_rate, kbps);

    what = "buka encoder";
    const AVCodec *ec = avcodec_find_encoder_by_name("libmp3lame");
    if (!ec) { r = AVERROR_ENCODER_NOT_FOUND; goto fail; }
    c.enc = avcodec_alloc_context3(ec);
    if (!c.enc) { r = AVERROR(ENOMEM); goto fail; }
    c.enc->sample_rate = out_rate;
    av_channel_layout_default(&c.enc->ch_layout, out_ch);
    c.enc->sample_fmt = AV_SAMPLE_FMT_S16P;
    /* VBR (bitrate berubah mengikuti isi suara). bit_rate tetap diisi hanya sebagai perkiraan untuk
       header Xing; dengan QSCALE aktif, libmp3lame memakai global_quality (V0..V9), bukan bit_rate. */
    c.enc->bit_rate = (int64_t)bitrate * 1000;
    c.enc->flags |= AV_CODEC_FLAG_QSCALE;
    c.enc->global_quality = vbr_quality(bitrate) * FF_QP2LAMBDA;
    c.enc->time_base = (AVRational){1, out_rate};

    what = "siapkan keluaran";
    r = avformat_alloc_output_context2(&c.oc, NULL, "mp3", dst);
    if (r < 0) goto fail;
    r = avio_open(&c.oc->pb, dst, AVIO_FLAG_WRITE);
    if (r < 0) goto fail;
    c.ost = avformat_new_stream(c.oc, NULL);
    if (!c.ost) { r = AVERROR(ENOMEM); goto fail; }
    what = "buka encoder";
    r = avcodec_open2(c.enc, ec, NULL);
    if (r < 0) goto fail;
    r = avcodec_parameters_from_context(c.ost->codecpar, c.enc);
    if (r < 0) goto fail;
    c.ost->time_base = c.enc->time_base;

    AVChannelLayout inl;
    memset(&inl, 0, sizeof inl);
    if (c.dec->ch_layout.order == AV_CHANNEL_ORDER_UNSPEC) av_channel_layout_default(&inl, in_ch);
    else av_channel_layout_copy(&inl, &c.dec->ch_layout);
    what = "siapkan resampler";
    r = swr_alloc_set_opts2(&c.swr, &c.enc->ch_layout, c.enc->sample_fmt, out_rate,
                            &inl, c.dec->sample_fmt, in_rate, 0, NULL);
    av_channel_layout_uninit(&inl);
    if (r < 0) goto fail;
    r = swr_init(c.swr);
    if (r < 0) goto fail;

    c.fifo = av_audio_fifo_alloc(c.enc->sample_fmt, out_ch, 4096);
    c.pkt = av_packet_alloc();
    c.opkt = av_packet_alloc();
    c.frame = av_frame_alloc();
    c.conv = av_frame_alloc();
    if (!c.fifo || !c.pkt || !c.opkt || !c.frame || !c.conv) { r = AVERROR(ENOMEM); goto fail; }

    AVDictionary *opts = NULL;
    av_dict_set(&opts, "id3v2_version", "3", 0);
    av_dict_set(&opts, "write_xing", "1", 0);
    what = "tulis header";
    r = avformat_write_header(c.oc, &opts);
    av_dict_free(&opts);
    if (r < 0) goto fail;

    int64_t dur_us = c.ic->duration > 0 ? c.ic->duration : 0;
    what = "dekode";
    report(&pr, 0);
    while ((r = av_read_frame(c.ic, c.pkt)) >= 0) {
        if (c.pkt->stream_index == ast) {
            if (dur_us > 0 && c.pkt->pts != AV_NOPTS_VALUE) {
                int64_t us = av_rescale_q(c.pkt->pts, ist->time_base, AV_TIME_BASE_Q) - (c.ic->start_time > 0 ? c.ic->start_time : 0);
                if (!report(&pr, (int)(us * 100 / dur_us))) { av_packet_unref(c.pkt); break; }
            }
            r = decode_packet(&c, c.pkt);
            if (r < 0 && r != AVERROR_INVALIDDATA) { av_packet_unref(c.pkt); goto fail; }
        }
        av_packet_unref(c.pkt);
    }
    if (pr.cancelled) goto cancelled;
    if (r != AVERROR_EOF) goto fail;

    what = "selesaikan";
    r = decode_packet(&c, NULL);
    if (r < 0) goto fail;
    r = push_samples(&c, NULL, 0); /* sisa di resampler */
    if (r < 0) goto fail;
    r = drain_fifo(&c, 1);
    if (r < 0) goto fail;
    r = avcodec_send_frame(c.enc, NULL);
    if (r < 0 && r != AVERROR_EOF) goto fail;
    r = write_encoded(&c);
    if (r < 0) goto fail;
    r = av_write_trailer(c.oc);
    if (r < 0) goto fail;
    report(&pr, 100);
    done = 1;
    goto out;

cancelled:
    done = 0;
    goto out;
fail:
    throw_io(env, what, r);
out:
    free_ctx(&c);
    (*env)->ReleaseStringUTFChars(env, jsrc, src);
    (*env)->ReleaseStringUTFChars(env, jdst, dst);
    return done ? JNI_TRUE : JNI_FALSE;
}
