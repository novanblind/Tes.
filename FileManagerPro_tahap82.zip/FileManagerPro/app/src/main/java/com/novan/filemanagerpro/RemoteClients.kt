package com.novan.filemanagerpro

import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.EnumSet
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaTypeOrNull

class RemoteEntry(val name: String, val isDir: Boolean, val size: Long, val time: Long)

/** Klien jarak jauh. Semua jalur memakai "/" dan diawali "/" (relatif terhadap akar klien). */
interface RemoteClient : Closeable {
    fun connect()
    fun list(path: String): List<RemoteEntry>
    fun download(path: String, dest: File)
    fun upload(src: File, path: String)
    fun delete(path: String, isDir: Boolean)
    fun mkdir(path: String)
    fun rename(from: String, to: String)

    /** Jalur awal untuk penjelajahan. */
    fun startPath(): String
}

fun joinPath(a: String, b: String): String = if (a.endsWith("/")) a + b else "$a/$b"

fun parentPath(p: String): String {
    val t = p.trimEnd('/')
    val i = t.lastIndexOf('/')
    return if (i <= 0) "/" else t.substring(0, i)
}

fun RemoteConfig.openClient(): RemoteClient = when (type) {
    "sftp" -> SftpRemote(this)
    "smb" -> SmbRemote(this)
    "webdav", "webdavs" -> WebDavRemote(this)
    else -> FtpRemote(this)
}

// ------------------------------------------------------------------------- FTP

class FtpRemote(private val cfg: RemoteConfig) : RemoteClient {
    private val ftp = FTPClient()

    override fun startPath(): String = cfg.path.ifBlank { "/" }

    override fun connect() {
        ftp.controlEncoding = "UTF-8"
        ftp.connectTimeout = 15000
        ftp.defaultTimeout = 60000
        ftp.connect(cfg.host, if (cfg.port > 0) cfg.port else 21)
        if (!FTPReply.isPositiveCompletion(ftp.replyCode)) throw IOException("FTP: ${ftp.replyString}")
        val user = cfg.user.ifBlank { "anonymous" }
        val pass = if (cfg.user.isBlank()) "anonymous@" else cfg.pass
        if (!ftp.login(user, pass)) throw IOException("Login gagal")
        ftp.enterLocalPassiveMode()
        ftp.setFileType(FTP.BINARY_FILE_TYPE)
        ftp.soTimeout = 60000
    }

    override fun list(path: String): List<RemoteEntry> =
        (ftp.listFiles(path) ?: emptyArray()).filter { it.name != "." && it.name != ".." }.map {
            RemoteEntry(it.name, it.isDirectory, it.size, it.timestamp?.timeInMillis ?: 0L)
        }

    override fun download(path: String, dest: File) {
        FileOutputStream(dest).use { out ->
            if (!ftp.retrieveFile(path, out)) throw IOException("Unduh gagal: ${ftp.replyString}")
        }
    }

    override fun upload(src: File, path: String) {
        FileInputStream(src).use { input ->
            if (!ftp.storeFile(path, input)) throw IOException("Unggah gagal: ${ftp.replyString}")
        }
    }

    override fun delete(path: String, isDir: Boolean) {
        if (!isDir) {
            if (!ftp.deleteFile(path)) throw IOException("Hapus gagal: ${ftp.replyString}")
            return
        }
        for (e in list(path)) delete(joinPath(path, e.name), e.isDir)
        if (!ftp.removeDirectory(path)) throw IOException("Hapus folder gagal: ${ftp.replyString}")
    }

    override fun mkdir(path: String) {
        if (!ftp.makeDirectory(path)) throw IOException("Buat folder gagal: ${ftp.replyString}")
    }

    override fun rename(from: String, to: String) {
        if (!ftp.rename(from, to)) throw IOException("Ganti nama gagal: ${ftp.replyString}")
    }

    override fun close() {
        try { ftp.logout() } catch (e: Exception) { }
        try { ftp.disconnect() } catch (e: Exception) { }
    }
}

// ------------------------------------------------------------------------ SFTP

class SftpRemote(private val cfg: RemoteConfig) : RemoteClient {
    private var session: com.jcraft.jsch.Session? = null
    private var ch: ChannelSftp? = null

    override fun startPath(): String = cfg.path.ifBlank { "/" }

    override fun connect() {
        val js = JSch()
        val s = js.getSession(cfg.user, cfg.host, if (cfg.port > 0) cfg.port else 22)
        s.setPassword(cfg.pass)
        // Kunci host tidak diverifikasi (belum ada daftar host terpercaya).
        s.setConfig("StrictHostKeyChecking", "no")
        s.connect(15000)
        session = s
        val c = s.openChannel("sftp") as ChannelSftp
        c.connect(15000)
        ch = c
    }

    private fun c(): ChannelSftp = ch ?: throw IOException("Belum tersambung")

    override fun list(path: String): List<RemoteEntry> {
        val v: java.util.Vector<*> = c().ls(path)
        val out = ArrayList<RemoteEntry>()
        for (o in v) {
            val e = o as ChannelSftp.LsEntry
            if (e.filename == "." || e.filename == "..") continue
            out.add(RemoteEntry(e.filename, e.attrs.isDir, e.attrs.size, e.attrs.mTime * 1000L))
        }
        return out
    }

    override fun download(path: String, dest: File) {
        FileOutputStream(dest).use { out -> c().get(path, out) }
    }

    override fun upload(src: File, path: String) {
        FileInputStream(src).use { input -> c().put(input, path) }
    }

    override fun delete(path: String, isDir: Boolean) {
        if (!isDir) { c().rm(path); return }
        for (e in list(path)) delete(joinPath(path, e.name), e.isDir)
        c().rmdir(path)
    }

    override fun mkdir(path: String) { c().mkdir(path) }

    override fun rename(from: String, to: String) { c().rename(from, to) }

    override fun close() {
        try { ch?.disconnect() } catch (e: Exception) { }
        try { session?.disconnect() } catch (e: Exception) { }
    }
}

// ------------------------------------------------------------------------- SMB

class SmbRemote(private val cfg: RemoteConfig) : RemoteClient {
    private var client: SMBClient? = null
    private var conn: Connection? = null
    private var sess: Session? = null
    private var share: DiskShare? = null

    private val shareName: String
        get() = cfg.path.trim('/').substringBefore('/')

    override fun startPath(): String {
        val rest = cfg.path.trim('/').substringAfter('/', "")
        return "/" + rest
    }

    override fun connect() {
        if (shareName.isEmpty()) throw IOException("Nama share belum diisi")
        val cl = SMBClient()
        client = cl
        val cn = cl.connect(cfg.host, if (cfg.port > 0) cfg.port else 445)
        conn = cn
        val auth = if (cfg.user.isBlank()) AuthenticationContext.guest()
        else {
            val u = cfg.user
            val domain = if (u.contains("\\")) u.substringBefore("\\") else ""
            val name = if (u.contains("\\")) u.substringAfter("\\") else u
            AuthenticationContext(name, cfg.pass.toCharArray(), domain)
        }
        val s = cn.authenticate(auth)
        sess = s
        share = s.connectShare(shareName) as DiskShare
    }

    private fun sh(): DiskShare = share ?: throw IOException("Belum tersambung")

    /** "/a/b" menjadi "a\\b"; akar menjadi "". */
    private fun p(path: String): String = path.trim('/').replace("/", "\\")

    override fun list(path: String): List<RemoteEntry> {
        val out = ArrayList<RemoteEntry>()
        for (i in sh().list(p(path))) {
            val n = i.fileName
            if (n == "." || n == "..") continue
            val dir = (i.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L
            out.add(RemoteEntry(n, dir, i.endOfFile, i.changeTime.toEpoch(TimeUnit.MILLISECONDS)))
        }
        return out
    }

    override fun download(path: String, dest: File) {
        sh().openFile(
            p(path), EnumSet.of(AccessMask.GENERIC_READ), null,
            SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null
        ).use { f ->
            FileOutputStream(dest).use { out -> f.inputStream.use { it.copyTo(out) } }
        }
    }

    override fun upload(src: File, path: String) {
        sh().openFile(
            p(path), EnumSet.of(AccessMask.GENERIC_WRITE), null,
            SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OVERWRITE_IF, null
        ).use { f ->
            FileInputStream(src).use { input -> f.outputStream.use { input.copyTo(it) } }
        }
    }

    override fun delete(path: String, isDir: Boolean) {
        if (isDir) sh().rmdir(p(path), true) else sh().rm(p(path))
    }

    override fun mkdir(path: String) { sh().mkdir(p(path)) }

    override fun rename(from: String, to: String) {
        sh().open(
            p(from), EnumSet.of(AccessMask.DELETE), null,
            SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null
        ).use { e -> e.rename(p(to)) }
    }

    override fun close() {
        try { share?.close() } catch (e: Exception) { }
        try { sess?.close() } catch (e: Exception) { }
        try { conn?.close() } catch (e: Exception) { }
        try { client?.close() } catch (e: Exception) { }
    }
}

// ---------------------------------------------------------------------- WebDAV

/**
 * WebDAV lewat OkHttp (HTTP atau HTTPS). [RemoteConfig.path] adalah jalur dasar server,
 * mis. "/remote.php/dav/files/nama" pada Nextcloud; di dalam aplikasi jalur dasar itu menjadi akar "/".
 */
class WebDavRemote(private val cfg: RemoteConfig) : RemoteClient {
    private val http = okhttp3.OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    override fun startPath(): String = "/"

    private val secure: Boolean get() = cfg.type == "webdavs"

    private fun baseUrl(): okhttp3.HttpUrl {
        var host = cfg.host.trim()
        host = host.removePrefix("https://").removePrefix("http://").trimEnd('/')
        val b = okhttp3.HttpUrl.Builder()
            .scheme(if (secure) "https" else "http")
            .host(host.substringBefore('/').substringBefore(':'))
        val port = if (cfg.port > 0) cfg.port else if (secure) 443 else 80
        b.port(port)
        val extra = host.substringAfter('/', "")
        val base = (extra + "/" + cfg.path.trim('/')).trim('/')
        if (base.isNotEmpty()) b.addPathSegments(base)
        return b.build()
    }

    private fun urlOf(path: String, dir: Boolean): okhttp3.HttpUrl {
        val b = baseUrl().newBuilder()
        val rel = path.trim('/')
        if (rel.isNotEmpty()) b.addPathSegments(rel)
        if (dir && !b.build().encodedPath.endsWith("/")) b.addPathSegment("")
        return b.build()
    }

    private fun req(url: okhttp3.HttpUrl, method: String, body: okhttp3.RequestBody? = null): okhttp3.Request.Builder {
        val r = okhttp3.Request.Builder().url(url).method(method, body)
        if (cfg.user.isNotBlank()) r.header("Authorization", okhttp3.Credentials.basic(cfg.user, cfg.pass, Charsets.UTF_8))
        return r
    }

    private fun checkResp(resp: okhttp3.Response, what: String) {
        if (resp.isSuccessful || resp.code == 207) return
        val code = resp.code
        resp.close()
        throw IOException(if (code == 401) "Login gagal" else "$what: HTTP $code")
    }

    private val propfindBody = (
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<d:propfind xmlns:d=\"DAV:\"><d:prop><d:resourcetype/><d:getcontentlength/>" +
            "<d:getlastmodified/></d:prop></d:propfind>"
        ).toRequestBodyXml()

    private fun String.toRequestBodyXml(): okhttp3.RequestBody =
        okhttp3.RequestBody.create("application/xml; charset=utf-8".toMediaTypeOrNull(), this)

    override fun connect() {
        val url = urlOf("/", true)
        http.newCall(req(url, "PROPFIND", propfindBody).header("Depth", "0").build()).execute().use {
            checkResp(it, "Sambung gagal")
        }
    }

    override fun list(path: String): List<RemoteEntry> {
        val url = urlOf(path, true)
        val xml = http.newCall(req(url, "PROPFIND", propfindBody).header("Depth", "1").build()).execute().use {
            checkResp(it, "Muat folder gagal")
            it.body?.string() ?: ""
        }
        val selfPath = android.net.Uri.decode(url.encodedPath).trimEnd('/')
        val out = ArrayList<RemoteEntry>()
        val parser = android.util.Xml.newPullParser()
        parser.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        parser.setInput(java.io.StringReader(xml))
        var href = ""
        var isDir = false
        var size = 0L
        var time = 0L
        var inResponse = false
        var ev = parser.eventType
        val fmt = java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", java.util.Locale.US)
        while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                when (parser.name) {
                    "response" -> { inResponse = true; href = ""; isDir = false; size = 0L; time = 0L }
                    "href" -> if (inResponse && href.isEmpty()) href = parser.nextText().trim()
                    "collection" -> isDir = true
                    "getcontentlength" -> size = parser.nextText().trim().toLongOrNull() ?: 0L
                    "getlastmodified" -> time = try { fmt.parse(parser.nextText().trim())?.time ?: 0L } catch (e: Exception) { 0L }
                }
            } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && parser.name == "response") {
                inResponse = false
                val hp = if (href.startsWith("http")) android.net.Uri.parse(href).path ?: "" else android.net.Uri.decode(href)
                val full = android.net.Uri.decode(hp).trimEnd('/')
                if (full != selfPath && full.isNotEmpty()) {
                    val name = full.substringAfterLast('/')
                    if (name.isNotEmpty()) out.add(RemoteEntry(name, isDir, size, time))
                }
            }
            ev = parser.next()
        }
        return out
    }

    override fun download(path: String, dest: File) {
        http.newCall(req(urlOf(path, false), "GET").build()).execute().use { r ->
            checkResp(r, "Unduh gagal")
            FileOutputStream(dest).use { out -> r.body?.byteStream()?.use { it.copyTo(out) } }
        }
    }

    override fun upload(src: File, path: String) {
        val body = okhttp3.RequestBody.create("application/octet-stream".toMediaTypeOrNull(), src)
        http.newCall(req(urlOf(path, false), "PUT", body).build()).execute().use { checkResp(it, "Unggah gagal") }
    }

    override fun delete(path: String, isDir: Boolean) {
        http.newCall(req(urlOf(path, isDir), "DELETE").build()).execute().use { checkResp(it, "Hapus gagal") }
    }

    override fun mkdir(path: String) {
        http.newCall(req(urlOf(path, true), "MKCOL").build()).execute().use { checkResp(it, "Buat folder gagal") }
    }

    override fun rename(from: String, to: String) {
        val dest = urlOf(to, false).toString()
        http.newCall(
            req(urlOf(from, false), "MOVE").header("Destination", dest).header("Overwrite", "F").build()
        ).execute().use { checkResp(it, "Ganti nama gagal") }
    }

    override fun close() {
        try { http.dispatcher.executorService.shutdown() } catch (e: Exception) { }
        try { http.connectionPool.evictAll() } catch (e: Exception) { }
    }
}
