package com.novan.pisahsuara;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayDeque;

import java.util.function.Consumer;

/** Pencarian port pairing (mDNS), notifikasi input kode ala Brevent, pairing, dan sambung. */
public class PairHelper {
    static final String CHANNEL = "adbpair";
    static final int NOTIF_ID = 77;
    static volatile int pairPort = -1;
    static volatile String pairHost = "127.0.0.1";
    static volatile Consumer<String> sink;
    private static NsdManager.DiscoveryListener listener;

    // Antrean resolve: Android hanya mengizinkan satu resolveService aktif. Resolve yang
    // bertabrakan (error ALREADY_ACTIVE) dulu diabaikan diam-diam sehingga tombol kode tidak muncul.
    private static final Object kunci = new Object();
    private static final ArrayDeque<NsdServiceInfo> antrian = new ArrayDeque<>();
    private static boolean sibuk = false;
    private static final Handler ui = new Handler(Looper.getMainLooper());

    static void say(Context c, String text, boolean withInput) {
        Consumer<String> s = sink;
        if (s != null) s.accept(text);
        notify(c, text, withInput);
    }

    static void notify(Context c, String text, boolean withInput) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        Notification.Builder b = Kompat.pembuat(c, CHANNEL, "Pairing ADB", NotificationManager.IMPORTANCE_HIGH)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Pisahkan suara aplikasi")
                .setContentText(text)
                .setOnlyAlertOnce(false);
        if (withInput) {
            Intent i = new Intent(c, PairReceiver.class).setPackage(c.getPackageName());
            PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            RemoteInput ri = new RemoteInput.Builder("code").setLabel("Kode pairing 6 angka").build();
            Notification.Action a = new Notification.Action.Builder(
                    Icon.createWithResource(c, android.R.drawable.ic_menu_send),
                    "Masukkan kode pairing", pi).addRemoteInput(ri).build();
            b.addAction(a);
        }
        try { nm.notify(NOTIF_ID, b.build()); } catch (Exception ignored) {}
    }

    /** Mulai mencari layanan pairing yang muncul saat dialog "Pasangkan dengan kode" terbuka. */
    static void startDiscovery(final Context ctx) {
        stopDiscovery(ctx);
        pairPort = -1;
        synchronized (kunci) { antrian.clear(); sibuk = false; }
        final NsdManager nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
        listener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) {}
            @Override public void onDiscoveryStopped(String t) {}
            @Override public void onStartDiscoveryFailed(String t, int e) { say(ctx, "Gagal mencari pairing: " + e, false); }
            @Override public void onStopDiscoveryFailed(String t, int e) {}
            @Override public void onServiceLost(NsdServiceInfo s) {}
            @Override public void onServiceFound(NsdServiceInfo si) {
                resolve(ctx, nsd, si);
            }
        };
        nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, listener);
        // Kolom kode langsung tersedia di notifikasi; port dicari di latar belakang.
        say(ctx, "Siap. Buka Opsi pengembang > Wireless debugging > Pasangkan dengan kode pairing, "
                + "lalu ketik kode 6 angka di notifikasi ini.", true);
    }

    private static void resolve(Context ctx, NsdManager nsd, NsdServiceInfo si) {
        synchronized (kunci) {
            if (sibuk) { antrian.add(si); return; }
            sibuk = true;
        }
        jalankanResolve(ctx, nsd, si, 0);
    }

    private static void resolveSelesai(Context ctx, NsdManager nsd) {
        NsdServiceInfo n;
        synchronized (kunci) {
            n = antrian.poll();
            if (n == null) { sibuk = false; return; }
        }
        jalankanResolve(ctx, nsd, n, 0);
    }

    private static void jalankanResolve(final Context ctx, final NsdManager nsd,
                                        final NsdServiceInfo si, final int coba) {
        try {
            nsd.resolveService(si, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo s, int e) {
                    if (coba < 4) ui.postDelayed(() -> jalankanResolve(ctx, nsd, si, coba + 1), 300);
                    else resolveSelesai(ctx, nsd);
                }
                @Override public void onServiceResolved(NsdServiceInfo r) {
                    pairPort = r.getPort();
                    try { if (r.getHost() != null) pairHost = r.getHost().getHostAddress(); } catch (Throwable ignored) {}
                    say(ctx, "Pairing ditemukan (port " + pairPort
                            + "). Ketik kode 6 angka di notifikasi ini.", true);
                    resolveSelesai(ctx, nsd);
                }
            });
        } catch (Throwable t) {
            resolveSelesai(ctx, nsd);
        }
    }

    static void stopDiscovery(Context ctx) {
        if (listener == null) return;
        try { ((NsdManager) ctx.getSystemService(Context.NSD_SERVICE)).stopServiceDiscovery(listener); }
        catch (Exception ignored) {}
        listener = null;
    }

    /** Pasangkan dengan kode lalu langsung sambung. Panggil dari thread latar. */
    static void pairAndConnect(Context ctx, int port, String code) {
        if (port <= 0) { say(ctx, "Port pairing belum diketahui.", false); return; }
        try {
            say(ctx, "Memasangkan...", false);
            Adb a = Adb.get(ctx);
            boolean ok;
            try {
                ok = a.pair(pairHost, port, code);
            } catch (Throwable first) {
                if ("127.0.0.1".equals(pairHost)) throw first;
                ok = a.pair("127.0.0.1", port, code);
            }
            if (!ok) { say(ctx, "Pairing gagal. Periksa kode, lalu ulangi.", false); return; }
            ctx.getSharedPreferences("adb_pisah", Context.MODE_PRIVATE).edit().putBoolean("paired", true).apply();
            say(ctx, "Pairing berhasil. Menyambung...", false);
            connect(ctx);
        } catch (Throwable e) {
            say(ctx, "Pairing gagal: " + e, false);
        }
    }

    static void connect(Context ctx) { connect(ctx, false); }

    static void report(Context c, String t, boolean quiet) {
        if (quiet) { Consumer<String> s = sink; if (s != null) s.accept(t); }
        else say(c, t, false);
    }

    /** Sambung otomatis ke port Wireless debugging (ditemukan lewat mDNS). */
    static void connect(Context ctx, boolean quiet) {
        try {
            Adb a = Adb.get(ctx);
            if (a.isConnected()) { report(ctx, "Sudah tersambung", quiet); return; }
            if (!Kompat.adaNirkabel()) {
                // Android 7 sampai 10: tidak ada Debugging nirkabel. Komputer (USB) atau HP lain (kabel OTG) menjalankan
                // "adb tcpip 5555" sekali; aplikasi lalu menyambung sendiri ke 127.0.0.1:5555.
                if (Lokal.sambungLokal(a)) {
                    AdbBackend.tandaiPasang(ctx);
                    report(ctx, "Tersambung lewat jalur lokal (127.0.0.1:" + Lokal.PORT + ").", quiet);
                    AdbBackend.setelahTersambung(ctx, a);
                } else {
                    report(ctx, "Belum tersambung. Dari komputer (kabel USB) atau HP lain (kabel OTG) jalankan: adb tcpip 5555. "
                            + "Bila muncul 'Izinkan debugging USB?', pilih Selalu izinkan, lalu ketuk lagi.", quiet);
                }
                return;
            }
            if (Lokal.modeAktif(ctx) && Lokal.sambungLokal(a)) {
                report(ctx, "Tersambung tanpa Wi-Fi (127.0.0.1:" + Lokal.PORT + ").", quiet);
                AdbBackend.setelahTersambung(ctx, a);
                return;
            }
            Lokal.viaLokal = false;
            a.sambungTls(ctx, 10000L);
            report(ctx, a.isConnected() ? "Tersambung."
                    : "Gagal menyambung. Pastikan Debugging nirkabel aktif dan Wi-Fi tersambung.", quiet);
            if (a.isConnected()) {
                ctx.getSharedPreferences("adb_pisah", Context.MODE_PRIVATE).edit().putBoolean("paired", true).apply();
                AdbBackend.setelahTersambung(ctx, a);
            }
        } catch (Throwable e) {
            report(ctx, "Gagal menyambung: " + e, quiet);
        }
    }

    /** Hasil {@link #sambungPintar}. */
    static final int TERSAMBUNG = 0, NYALAKAN_DEBUGGING = 1, BUTUH_PAIRING = 2, WIFI_MATI = 3;
    private static volatile boolean menunggu = false;

    /** Satu kali percobaan sambung memakai kunci tetap (tanpa kode bila HP sudah mengenal kuncinya). Panggil dari thread latar. */
    static int sambungPintar(Context ctx) {
        try {
            Adb a = Adb.get(ctx);
            if (a.isConnected()) return TERSAMBUNG;
            if (Lokal.modeAktif(ctx) && Lokal.sambungLokal(a)) { AdbBackend.setelahTersambung(ctx, a); return TERSAMBUNG; }
            Lokal.viaLokal = false;
            if (!AdbBackend.INSTANCE.wifiAda(ctx)) return WIFI_MATI;
            try { a.sambungTls(ctx, 10000L); } catch (Throwable ignored) {}
            if (a.isConnected()) {
                ctx.getSharedPreferences("adb_pisah", Context.MODE_PRIVATE).edit().putBoolean("paired", true).apply();
                AdbBackend.setelahTersambung(ctx, a);
                return TERSAMBUNG;
            }
            return Adb.layananDitemukan ? BUTUH_PAIRING : NYALAKAN_DEBUGGING;
        } catch (Throwable e) {
            return NYALAKAN_DEBUGGING;
        }
    }

    /**
     * Tombol "Sambung tanpa kode Wi-Fi": setelah Debugging nirkabel dinyalakan di Opsi pengembang, aplikasi menyambung sendiri
     * (tidak perlu kembali ke aplikasi dulu, menunggu sampai 3 menit). Bila HP belum mengenal kunci, pairing dimulai.
     * Panggil dari thread latar.
     */
    static void sambungTanpaKode(Context ctx) {
        if (menunggu) return;
        menunggu = true;
        try {
            Context app = ctx.getApplicationContext();
            long habis = System.currentTimeMillis() + 180000L;
            say(app, "Menunggu Debugging nirkabel dinyalakan di Opsi pengembang...", false);
            while (System.currentTimeMillis() < habis) {
                int h = sambungPintar(app);
                if (h == TERSAMBUNG) { say(app, "Tersambung tanpa kode Wi-Fi.", false); return; }
                if (h == BUTUH_PAIRING) {
                    startDiscovery(app);
                    say(app, "HP belum mengenal aplikasi ini. Buka Pasangkan perangkat dengan kode pairing, lalu ketik kode 6 angka di notifikasi (cukup sekali).", true);
                    return;
                }
                if (h == WIFI_MATI) say(app, "Wi-Fi belum tersambung. Nyalakan Wi-Fi.", false);
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
            }
            say(app, "Waktu menunggu habis. Nyalakan Debugging nirkabel di Opsi pengembang lalu ketuk Sambung tanpa kode Wi-Fi lagi.", false);
        } finally {
            menunggu = false;
        }
    }
}
