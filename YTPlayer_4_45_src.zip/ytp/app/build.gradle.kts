import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.ytplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "id.ytplayer"
        minSdk = 24
        targetSdk = 36
        versionCode = 76
        versionName = "4.45"

        // Satu APK untuk HP 32-bit dan 64-bit: pustaka native untuk armeabi-v7a dan arm64-v8a.
        ndk {
            abiFilters += setOf("armeabi-v7a", "arm64-v8a")
        }
    }


    // Keystore disertakan di repo agar tanda tangan APK sama di setiap build
    // (APK baru bisa menimpa yang lama tanpa uninstall). Untuk pemakaian pribadi.
    signingConfigs {
        create("app") {
            storeFile = rootProject.file("keystore/ytplayer.jks")
            storePassword = "ytplayer123"
            keyAlias = "ytplayer"
            keyPassword = "ytplayer123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // NewPipeExtractor memakai API Java 11+ yang perlu di-desugar untuk Android 7.
        isCoreLibraryDesugaringEnabled = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources.excludes += setOf("META-INF/INDEX.LIST", "META-INF/io.netty.versions.properties")
        // Pustaka native 32-bit dan 64-bit dikompres di dalam APK (APK lebih kecil;
        // diekstrak ke penyimpanan saat instal).
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // Buang terjemahan bahasa lain bawaan pustaka (Material, AppCompat, dll).
    // "in" = kode lama untuk Indonesia, "id" = kode baru; dua-duanya disertakan agar aman.
    androidResources {
        localeFilters += listOf("en", "id", "in")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// Bangun pustaka native MP3 ramping (FFmpeg + LAME) bila belum ada: native/build-native.sh
// (butuh Android NDK dan git; untuk armeabi-v7a dan arm64-v8a, keduanya masuk ke satu APK).
val buildNative by tasks.registering(Exec::class) {
    val so32 = file("src/main/jniLibs/armeabi-v7a/libytmp3.so")
    val so64 = file("src/main/jniLibs/arm64-v8a/libytmp3.so")
    onlyIf { !so32.exists() || !so64.exists() }
    workingDir = rootProject.projectDir
    commandLine("bash", "-c", "bash native/build-native.sh armeabi-v7a && bash native/build-native.sh arm64-v8a")
}
tasks.named("preBuild") { dependsOn(buildNative) }

dependencies {
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")

    implementation("androidx.media3:media3-exoplayer:1.6.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.6.1")
    implementation("androidx.media3:media3-session:1.6.1")

    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.core:core-ktx:1.15.0")
    // Music Player (dari proyek MusikPlayerNovan) dan menu laci
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    implementation("com.google.guava:guava:33.4.0-android")
}
