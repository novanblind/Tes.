package com.makroku.automation.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.makroku.automation.MakroApp
import com.makroku.automation.model.TriggerEvent

/** Sumber pemicu "Notifikasi diterima". Aktifkan di Pengaturan → Akses notifikasi. */
class MacroNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: MacroNotificationListener? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    /** Teks terpanjang yang bisa dibaca: teks besar, lalu baris-baris (gaya inbox), lalu teks biasa. */
    private fun teksBesar(ex: android.os.Bundle, text: String): String {
        val besar = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        if (besar.isNotBlank()) return besar
        val baris = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString("\n") { it.toString() }.orEmpty()
        if (baris.isNotBlank()) return baris
        return text
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val besar = teksBesar(ex, text)
        (applicationContext as MakroApp).engine.dispatch(
            TriggerEvent(
                "notification",
                mapOf(
                    "notif_pkg" to sbn.packageName, "notif_title" to title, "notif_text" to text,
                    // notif_big = teks besar (atau teks biasa bila tidak ada), notif_full = padanan {notification} MacroDroid.
                    "notif_big" to besar, "notif_full" to besar.ifBlank { text },
                    "notif_key" to sbn.key,
                    "notif_ongoing" to ((sbn.notification.flags and Notification.FLAG_ONGOING_EVENT) != 0).toString(),
                ),
            ),
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        (applicationContext as MakroApp).engine.dispatch(
            TriggerEvent(
                "notif_removed",
                mapOf("notif_pkg" to sbn.packageName, "notif_title" to title, "notif_text" to text),
            ),
        )
    }
}
