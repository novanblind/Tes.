package com.novan.audiolabnovan.gemini;

/**
 * Pembersih ujung audio PCM 16-bit mono. Dipakai untuk model Gemini 3.8 ke atas, yang kadang
 * menyisakan desis / derau kasar setelah kata terakhir selesai diucapkan.
 *
 * Caranya: cari titik terakhir yang masih berisi suara ucapan (energi per 20 md), buang sisa
 * setelahnya (menyisakan jeda alami), lalu pudarkan ujungnya agar tidak ada bunyi "tek".
 */
public final class PcmCleaner {
    private PcmCleaner() {}

    /** Hasil: audio yang sudah dirapikan + jeda hening di ujung (agar sambungan antarbagian enak didengar). */
    public static byte[] cleanTail(byte[] pcm, int rate, int tailSilenceMs) {
        int n = pcm.length / 2;
        if (n < rate / 5) return pcm;           // terlalu pendek, biarkan
        short[] s = new short[n];
        for (int i = 0; i < n; i++) s[i] = (short) ((pcm[2 * i] & 0xFF) | (pcm[2 * i + 1] << 8));

        int win = Math.max(1, rate / 50);       // 20 md
        int nw = n / win;
        if (nw < 5) return pcm;
        double[] rms = new double[nw];
        for (int w = 0; w < nw; w++) {
            double sum = 0;
            int off = w * win;
            for (int k = 0; k < win; k++) {
                double v = s[off + k];
                sum += v * v;
            }
            rms[w] = Math.sqrt(sum / win);
        }

        // Tingkat suara ucapan = persentil ke-90 dari energi seluruh jendela.
        double[] sorted = rms.clone();
        java.util.Arrays.sort(sorted);
        double speech = sorted[(int) (nw * 0.9)];
        if (speech < 300) return pcm;           // hampir senyap seluruhnya, jangan diutak-atik

        // Ucapan "kuat" = di atas sekitar -18 dB dari tingkat ucapan. Derau/desis sisa di ujung hampir selalu
        // jauh di bawah ini, sedangkan suku kata terakhir yang wajar masih melewatinya. Dua jendela berurutan
        // dibutuhkan agar letupan derau tunggal tidak dianggap ucapan.
        double thr = Math.max(speech * 0.12, 150);
        int last = -1;
        for (int w = nw - 2; w >= 0; w--) {
            if (rms[w] >= thr && rms[w + 1] >= thr) { last = w + 1; break; }
        }
        if (last < 0) return pcm;

        // Sisakan 250 md setelahnya agar akhiran lembut ("s", "h", "t") dan jeda alami tetap utuh.
        int keepEnd = Math.min(n, (last + 1) * win + rate * 250 / 1000);

        int fade = Math.min(keepEnd, rate * 100 / 1000);                   // pudar 100 md di ujung
        for (int i = 0; i < fade; i++) {
            int idx = keepEnd - fade + i;
            s[idx] = (short) (s[idx] * (1.0 - (double) (i + 1) / fade));
        }
        int fadeIn = Math.min(keepEnd, rate * 4 / 1000);                   // 4 md di awal, mencegah klik
        for (int i = 0; i < fadeIn; i++) s[i] = (short) (s[i] * ((double) i / fadeIn));

        int silence = Math.max(0, rate * tailSilenceMs / 1000);
        byte[] out = new byte[(keepEnd + silence) * 2];
        for (int i = 0; i < keepEnd; i++) {
            out[2 * i] = (byte) (s[i] & 0xFF);
            out[2 * i + 1] = (byte) ((s[i] >> 8) & 0xFF);
        }
        return out;
    }
}
