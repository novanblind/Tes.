package com.makroku.automation.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.makroku.automation.MakroApp
import com.makroku.automation.data.ImportResult
import com.makroku.automation.service.AutomationService
import android.widget.Toast

sealed interface Screen {
    data object Home : Screen
    data class Editor(val id: Long?) : Screen
    data object Logs : Screen
    data object Variables : Screen
    data object Templates : Screen
    data object Settings : Screen
    data object Adb : Screen
    data object Blocks : Screen
}

class MainActivity : ComponentActivity() {
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startAutomation() }

    private var pendingImport by mutableStateOf<ImportResult?>(null)

    /** Berkas makro dibuka dari aplikasi lain (WhatsApp, Berkas, dsb) atau dibagikan ke MakroKu. */
    private fun tanganiBerkas(i: Intent?) {
        val uri = uriDariIntent(i) ?: return
        val repo = (application as MakroApp).repo
        runCatching { pendingImport = repo.parseImportFull(bacaTeksUri(this, uri)) }
            .onFailure { Toast.makeText(this, "Bukan berkas makro MakroKu yang sah", Toast.LENGTH_LONG).show() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tanganiBerkas(intent)
    }

    private fun startAutomation() {
        if (!(application as MakroApp).repo.appEnabled.value) return
        runCatching { ContextCompat.startForegroundService(this, Intent(this, AutomationService::class.java)) }
    }

    private fun stopAutomation() {
        stopService(Intent(this, AutomationService::class.java))
    }

    private fun runtimePermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
        return list.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as MakroApp
        startAutomation()
        if (savedInstanceState == null) tanganiBerkas(intent)
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))

        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                    pendingImport?.let { l ->
                        ImportMacroDialog(
                            hasil = l,
                            onApply = {
                                val n = app.repo.applyImport(l)
                                pendingImport = null
                                screen = Screen.Home
                                Toast.makeText(this@MainActivity, "$n makro diterapkan", Toast.LENGTH_LONG).show()
                            },
                            onCancel = { pendingImport = null },
                        )
                    }
                    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
                    when (val s = screen) {
                        Screen.Home -> HomeScreen(app.repo, app.engine) { screen = it }
                        is Screen.Editor -> EditorScreen(app.repo, s.id) { screen = Screen.Home }
                        Screen.Logs -> LogsScreen(app.repo) { screen = Screen.Home }
                        Screen.Variables -> VariablesScreen(app.repo) { screen = Screen.Home }
                        Screen.Templates -> TemplatesScreen(app.repo) { screen = Screen.Home }
                        Screen.Adb -> AdbScreen { screen = Screen.Home }
                        Screen.Blocks -> BlocksScreen(app.repo, app.engine) { screen = Screen.Home }
                        Screen.Settings -> SettingsScreen(
                            repo = app.repo,
                            onBack = { screen = Screen.Home },
                            onRequestPermissions = { permLauncher.launch(runtimePermissions()) },
                            onStartService = { app.repo.setAppEnabled(true); startAutomation() },
                            onStopService = { app.repo.setAppEnabled(false); stopAutomation() },
                            onImport = { pendingImport = it },
                        )
                    }
                }
            }
        }
    }
}
