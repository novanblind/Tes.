#!/usr/bin/env python3
"""Mengecilkan model ONNX tanpa mengubah cara kerjanya.

Bobot float32 yang besar disimpan sebagai float16 (ukuran berkas hampir separuh), lalu di depan
tiap bobot dipasang satu simpul Cast ke float32. ONNX Runtime melipat simpul Cast itu saat model
dimuat, jadi saat berjalan modelnya tetap float32 dan kecepatannya sama.

Tidak butuh pustaka onnx: berkas dibaca dan ditulis langsung sebagai protobuf.
Setelah selesai, hasil dibandingkan dengan model asli lewat onnxruntime; bila selisihnya terlalu
besar atau pengujian tidak bisa dijalankan, skrip keluar dengan kode 2 dan pemanggil memakai model asli.

Mode "int8" (opsional): bobot disimpan sebagai int8 per-saluran (tiap saluran keluaran punya skala
sendiri) dan di depan tiap bobot dipasang simpul DequantizeLinear. Aktivasi tetap float32. Ukuran
sekitar seperempat model asli. Bila selisih hasil terlalu besar, otomatis jatuh ke float16.

Pemakaian: kecilkan_model.py masuk.onnx keluar.onnx [fp16|int8]
"""
import struct
import sys

try:
    import numpy as np
except Exception:  # numpy tidak ada: pakai jalur lambat
    np = None

AMBANG_ELEMEN = 1024
BATAS_SELISIH = 0.05
BATAS_SELISIH_INT8 = 0.08


# ---------------------------------------------------------------- protobuf mentah
def baca_varint(b, i):
    n = 0
    s = 0
    while True:
        c = b[i]
        i += 1
        n |= (c & 0x7F) << s
        if not (c & 0x80):
            return n, i
        s += 7


def urai(b):
    """Daftar (nomor_bidang, jenis_kawat, nilai); nilai int untuk varint, bytes untuk lainnya."""
    i = 0
    n = len(b)
    hasil = []
    while i < n:
        k, i = baca_varint(b, i)
        f, w = k >> 3, k & 7
        if w == 0:
            v, i = baca_varint(b, i)
        elif w == 2:
            ln, i = baca_varint(b, i)
            v = b[i:i + ln]
            i += ln
        elif w == 5:
            v = b[i:i + 4]
            i += 4
        elif w == 1:
            v = b[i:i + 8]
            i += 8
        else:
            raise ValueError("jenis kawat tidak dikenal: %d" % w)
        hasil.append((f, w, v))
    return hasil


def kode_varint(n):
    out = bytearray()
    while True:
        c = n & 0x7F
        n >>= 7
        if n:
            out.append(c | 0x80)
        else:
            out.append(c)
            return bytes(out)


def tulis(daftar):
    out = bytearray()
    for f, w, v in daftar:
        out += kode_varint((f << 3) | w)
        if w == 0:
            out += kode_varint(v)
        elif w == 2:
            out += kode_varint(len(v))
            out += v
        else:
            out += v
    return bytes(out)


def len_(f, v):
    return (f, 2, v)


# ---------------------------------------------------------------- konversi bobot
def ke_float16(raw):
    n = len(raw) // 4
    if np is not None:
        a = np.frombuffer(raw, dtype="<f4")
        if not np.all(np.isfinite(a)) or float(np.max(np.abs(a))) > 60000.0:
            return None
        return a.astype("<f2").tobytes()
    out = bytearray()
    langkah = 1 << 18
    for mulai in range(0, n, langkah):
        cnt = min(langkah, n - mulai)
        vals = struct.unpack_from("<%df" % cnt, raw, mulai * 4)
        try:
            out += struct.pack("<%de" % cnt, *vals)
        except (OverflowError, struct.error):
            return None
    return bytes(out)


def ubah_tensor(bidang):
    """Mengembalikan (nama_asal, bidang_tensor_baru) bila tensor layak dikonversi, selain itu None."""
    dims = []
    tipe = None
    nama = b""
    raw = None
    fdata = []
    luar = False
    for f, w, v in bidang:
        if f == 1:
            if w == 2:
                i = 0
                while i < len(v):
                    d, i = baca_varint(v, i)
                    dims.append(d)
            else:
                dims.append(v)
        elif f == 2:
            tipe = v
        elif f == 8:
            nama = v
        elif f == 9:
            raw = v
        elif f == 4:
            fdata.append(v)
        elif f in (13, 14):
            luar = True          # data luar (external_data / data_location)
    if tipe != 1 or luar or not nama:
        return None
    if raw is None:
        raw = b"".join(fdata)
    jumlah = 1
    for d in dims:
        jumlah *= d
    if not dims or len(raw) != jumlah * 4 or jumlah < AMBANG_ELEMEN:
        return None
    baru = ke_float16(raw)
    if baru is None:
        return None
    nama_baru = nama + b"__f16"
    hasil = []
    for f, w, v in bidang:
        if f in (2, 4, 8, 9):
            continue
        hasil.append((f, w, v))
    hasil.append((2, 0, 10))              # FLOAT16
    hasil.append((8, 2, nama_baru))
    hasil.append((9, 2, baru))
    return nama, nama_baru, hasil



def ke_int8(raw, dims):
    """Kuantisasi simetris per saluran pada sumbu 0. Mengembalikan (bytes_int8, bytes_skala_float32)."""
    if np is None:
        return None
    a = np.frombuffer(raw, dtype="<f4")
    if not np.all(np.isfinite(a)):
        return None
    c = dims[0]
    m = a.reshape(c, -1)
    amax = np.max(np.abs(m), axis=1)
    skala = np.where(amax > 0, amax / 127.0, 1.0).astype("<f4")
    q = np.clip(np.rint(m / skala[:, None]), -127, 127).astype(np.int8)
    return q.tobytes(), skala.tobytes()


def ubah_tensor_int8(bidang):
    """Seperti ubah_tensor, tetapi ke int8 + skala. Mengembalikan (asal, nama_q, nama_s, [bidang_q, bidang_s])."""
    dims = []
    tipe = None
    nama = b""
    raw = None
    fdata = []
    luar = False
    for f, w, v in bidang:
        if f == 1:
            if w == 2:
                i = 0
                while i < len(v):
                    d, i = baca_varint(v, i)
                    dims.append(d)
            else:
                dims.append(v)
        elif f == 2:
            tipe = v
        elif f == 8:
            nama = v
        elif f == 9:
            raw = v
        elif f == 4:
            fdata.append(v)
        elif f in (13, 14):
            luar = True
    if tipe != 1 or luar or not nama:
        return None
    if raw is None:
        raw = b"".join(fdata)
    jumlah = 1
    for d in dims:
        jumlah *= d
    if len(dims) < 2 or len(raw) != jumlah * 4 or jumlah < AMBANG_ELEMEN:
        return None
    hasil = ke_int8(raw, dims)
    if hasil is None:
        return None
    qb, sb = hasil
    nq = nama + b"__q8"
    ns = nama + b"__sk"
    tq = [(1, 2, b"".join(kode_varint(d) for d in dims)), (2, 0, 3), (8, 2, nq), (9, 2, qb)]
    ts = [(1, 2, kode_varint(dims[0])), (2, 0, 1), (8, 2, ns), (9, 2, sb)]
    return nama, nq, ns, [tq, ts]


def simpul_dequant(q, s, ke):
    attr = tulis([(1, 2, b"axis"), (3, 0, 0), (20, 0, 2)])   # axis = 0, tipe INT
    return tulis([
        (1, 2, q),
        (1, 2, s),
        (2, 2, ke),
        (3, 2, b"dq_" + ke),
        (4, 2, b"DequantizeLinear"),
        (5, 2, attr),
    ])


def versi_opset(model):
    for f, w, v in model:
        if f == 8 and w == 2:
            dom = b""
            ver = 0
            for ff, ww, vv in urai(v):
                if ff == 1:
                    dom = vv
                elif ff == 2:
                    ver = vv
            if dom in (b"", b"ai.onnx"):
                return ver
    return 0


def simpul_cast(dari, ke):
    attr = tulis([(1, 2, b"to"), (3, 0, 1), (20, 0, 2)])   # to = FLOAT (1), tipe INT
    return tulis([
        (1, 2, dari),
        (2, 2, ke),
        (3, 2, b"cast_" + ke),
        (4, 2, b"Cast"),
        (5, 2, attr),
    ])


def ubah_graf(gb, mode="fp16"):
    bidang = urai(gb)
    simpul_baru = []
    diubah = set()
    keluaran = []
    for f, w, v in bidang:
        if f == 5 and w == 2:
            if mode == "int8":
                h8 = ubah_tensor_int8(urai(v))
                if h8 is not None:
                    asal, nq, ns, (tq, ts) = h8
                    simpul_baru.append((1, 2, simpul_dequant(nq, ns, asal)))
                    diubah.add(asal)
                    keluaran.append((5, 2, tulis(tq)))
                    keluaran.append((5, 2, tulis(ts)))
                    continue
            hasil = ubah_tensor(urai(v))
            if hasil is not None:
                asal, nama_baru, tb = hasil
                simpul_baru.append((1, 2, simpul_cast(nama_baru, asal)))
                diubah.add(asal)
                keluaran.append((5, 2, tulis(tb)))
                continue
        keluaran.append((f, w, v))
    final = list(simpul_baru)
    for f, w, v in keluaran:
        if f == 11 and w == 2 and diubah:           # input graf yang juga bobot (model lama)
            nama = None
            for ff, ww, vv in urai(v):
                if ff == 1:
                    nama = vv
            if nama in diubah:
                continue
        final.append((f, w, v))
    return tulis(final), len(diubah)


def konversi(masuk, keluar, mode="fp16"):
    with open(masuk, "rb") as fh:
        data = fh.read()
    model = urai(data)
    if mode == "int8" and (np is None or versi_opset(model) < 13):
        print("int8 tidak bisa dipakai (numpy tidak ada atau opset < 13), dicoba float16")
        mode = "fp16"
    hasil = []
    total = 0
    for f, w, v in model:
        if f == 7 and w == 2:
            v, n = ubah_graf(v, mode)
            total += n
        hasil.append((f, w, v))
    with open(keluar, "wb") as fh:
        fh.write(tulis(hasil))
    return total, mode


# ---------------------------------------------------------------- pengujian
def uji(asal, baru, batas):
    import numpy as _np
    import onnxruntime as ort
    a = ort.InferenceSession(asal, providers=["CPUExecutionProvider"])
    b = ort.InferenceSession(baru, providers=["CPUExecutionProvider"])
    masuk = a.get_inputs()[0]
    bentuk = [d if isinstance(d, int) and d > 0 else 1 for d in masuk.shape]
    terburuk = 0.0
    for seed, skala in ((0, 1.0), (1, 0.1)):
        x = (_np.random.default_rng(seed).standard_normal(bentuk) * skala).astype("float32")
        ya = a.run(None, {masuk.name: x})[0]
        yb = b.run(None, {masuk.name: x})[0]
        selisih = float(_np.linalg.norm(ya - yb) / (_np.linalg.norm(ya) + 1e-12))
        print("Selisih relatif (masukan %d): %.6f" % (seed, selisih))
        terburuk = max(terburuk, selisih)
    return terburuk < batas


def main():
    if len(sys.argv) not in (3, 4):
        print(__doc__)
        return 2
    masuk, keluar = sys.argv[1], sys.argv[2]
    mode = sys.argv[3] if len(sys.argv) == 4 else "fp16"
    import os
    urutan = ["int8", "fp16"] if mode == "int8" else ["fp16"]
    for m in urutan:
        try:
            n, dipakai = konversi(masuk, keluar, m)
            print("Mode %s: %d tensor diubah; %d -> %d byte" % (
                dipakai, n, os.path.getsize(masuk), os.path.getsize(keluar)))
            if n == 0:
                print("Tidak ada bobot yang diubah")
                continue
            batas = BATAS_SELISIH_INT8 if dipakai == "int8" else BATAS_SELISIH
            if uji(masuk, keluar, batas):
                print("HASIL: mode %s dipakai" % dipakai)
                return 0
            print("Selisih terlalu besar untuk mode %s" % dipakai)
        except Exception as e:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            print("Pengecilan (%s) gagal: %r" % (m, e))
    print("Semua mode gagal, model asli dipakai")
    return 2


if __name__ == "__main__":
    sys.exit(main())
