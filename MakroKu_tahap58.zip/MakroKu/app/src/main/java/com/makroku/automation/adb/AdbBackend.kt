package com.makroku.automation.adb

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import io.github.muntashirakon.adb.AdbStream
import java.io.InputStreamReader
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Jalur tanpa Shizuku: sambung ke adbd lewat Debugging nirkabel lalu jalankan perintah sebagai shell. */
object AdbBackend {
    private const val SECURE = "android.permission.WRITE_SECURE_SETTINGS"

    fun dipasangkan(c: Context) = c.getSharedPreferences("adb_makroku", Context.MODE_PRIVATE).getBoolean("paired", false)

    fun tersambung(c: Context): Boolean = try { Adb.get(c).isConnected } catch (e: Throwable) { false }

    fun jalankanPublik(a: Adb, tujuan: String): String = jalankan(a, tujuan)

    private val kolam = Executors.newCachedThreadPool()

    /** Satu panggilan ADB yang tidak menjawab tidak boleh menahan semuanya: batas waktu lalu galat. */
    private fun jalankan(a: Adb, tujuan: String, batasDetik: Long = 20): String {
        val f = kolam.submit(Callable { jalankanLangsung(a, tujuan) })
        return try {
            f.get(batasDetik, TimeUnit.SECONDS)
        } catch (e: TimeoutException) {
            f.cancel(true)
            throw java.io.IOException("ADB tidak menjawab (>${batasDetik} dtk): ${tujuan.take(60)}")
        } catch (e: ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    private fun jalankanLangsung(a: Adb, tujuan: String): String {
        val s: AdbStream = a.openStream(tujuan)
        val sb = StringBuilder()
        try {
            val r = InputStreamReader(s.openInputStream(), Charsets.UTF_8)
            val buf = CharArray(2048)
            while (true) {
                val n = r.read(buf)
                if (n <= 0) break
                sb.append(buf, 0, n)
            }
        } catch (_: java.io.IOException) {
        } finally {
            try { s.close() } catch (_: Throwable) {}
        }
        return sb.toString()
    }

    /** Dipanggil sekali setiap berhasil tersambung: beri diri izin agar bisa menyalakan Debugging nirkabel sendiri. */
    @JvmStatic
    fun setelahTersambung(c: Context, a: Adb) {
        if (c.checkSelfPermission(SECURE) != PackageManager.PERMISSION_GRANTED) {
            try { jalankan(a, "shell:pm grant ${c.packageName} $SECURE") } catch (_: Throwable) {}
        }
        aktifkanDebugging(c)
        // Pindah ke jalur lokal (127.0.0.1:5555) supaya tetap tersambung saat Wi-Fi dimatikan.
        if (!Lokal.viaLokal) Lokal.aktifkanModeTanpaWifi(c, a)
    }

    /** Bila nyala, MakroKu tidak menyalakan lagi Opsi pengembang (development_settings_enabled) sendiri. */
    fun jagaOpsiPengembang(c: Context) = c.getSharedPreferences("adb_makroku", Context.MODE_PRIVATE).getBoolean("jaga_dev", false)

    fun setJagaOpsiPengembang(c: Context, nyala: Boolean) =
        c.getSharedPreferences("adb_makroku", Context.MODE_PRIVATE).edit().putBoolean("jaga_dev", nyala).apply()

    fun aktifkanDebugging(c: Context) {
        if (c.checkSelfPermission(SECURE) != PackageManager.PERMISSION_GRANTED) return
        val r = c.contentResolver
        if (!jagaOpsiPengembang(c)) { try { Settings.Global.putInt(r, "development_settings_enabled", 1) } catch (_: Throwable) {} }
        try { Settings.Global.putInt(r, "adb_enabled", 1) } catch (_: Throwable) {}
        try { Settings.Global.putInt(r, "adb_wifi_enabled", 1) } catch (_: Throwable) {}
        try { Settings.Global.putLong(r, "adb_allowed_connection_time", 0L) } catch (_: Throwable) {}
    }

    /** Wi-Fi tersambung? Tanpa Wi-Fi tidak ada gunanya memindai Debugging nirkabel (boros baterai). */
    fun wifiAda(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
    } catch (e: Throwable) { false }

    /** Pastikan tersambung; coba beberapa kali (mis. setelah HP restart, Wi-Fi belum siap). */
    fun pastikanTersambung(c: Context, percobaan: Int = 3): Adb? {
        val a = try { Adb.get(c) } catch (e: Throwable) { return null }
        for (i in 0 until percobaan) {
            if (a.isConnected) return a
            aktifkanDebugging(c)
            if (Lokal.modeAktif(c) && Lokal.sambungLokal(a)) return a
            Lokal.viaLokal = false
            if (!wifiAda(c)) return null
            try { a.sambungTls(c, 6000L) } catch (_: Throwable) {}
            if (a.isConnected) { setelahTersambung(c, a); return a }
            try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
        }
        return if (a.isConnected) a else null
    }

    /**
     * Jalankan satu perintah shell (tanpa awalan "adb shell") dan kembalikan keluarannya.
     * Panggil dari thread latar. Melempar galat bila belum dipasangkan / tidak bisa tersambung.
     */
    @JvmStatic
    fun shell(c: Context, perintah: String, batasDetik: Long = 20): String {
        val a = pastikanTersambung(c)
            ?: throw IllegalStateException(
                if (!dipasangkan(c)) "ADB belum dipasangkan — buka menu 'Izin via ADB' lalu pasangkan sekali"
                else "ADB tidak tersambung — nyalakan Wi-Fi dan Debugging nirkabel"
            )
        return jalankan(a, "shell:$perintah", batasDetik).trim()
    }

    /** Apakah [izin] sedang diberikan ke [pkg]: dibaca dari baris "izin: granted=true" di dumpsys package. Panggil dari thread latar. */
    @JvmStatic
    fun izinDiberi(c: Context, pkg: String, izin: String): Boolean {
        require(Regex("[A-Za-z0-9_.]+").matches(pkg)) { "Nama paket tidak valid" }
        require(Regex("[A-Za-z0-9_.]+").matches(izin)) { "Nama izin tidak valid" }
        val out = shell(c, "dumpsys package $pkg | grep -F ': granted='", 25)
        val re = Regex(Regex.escape(izin) + ": granted=(true|false)")
        return re.findAll(out).any { it.groupValues[1] == "true" }
    }

    /** Putuskan sambungan (mis. saat pengguna menekan Putuskan). */
    fun putuskan(c: Context) {
        try { Adb.get(c).disconnect() } catch (_: Throwable) {}
        Lokal.viaLokal = false
    }
}
