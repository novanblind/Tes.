package com.novan.filemanagermax

import android.content.Context

/** Penanda: daftar jalur folder atau berkas favorit. */
object Bookmarks {
    private fun p(c: Context) = c.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)

    fun list(c: Context): List<String> =
        (p(c).getString("paths", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun has(c: Context, path: String): Boolean = list(c).contains(path)

    private fun save(c: Context, l: List<String>) {
        p(c).edit().putString("paths", l.joinToString("\n")).apply()
    }

    fun add(c: Context, path: String) {
        val l = list(c)
        if (!l.contains(path)) save(c, l + path)
    }

    fun remove(c: Context, path: String) {
        save(c, list(c).filter { it != path })
    }
}
