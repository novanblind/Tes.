package com.novan.talkbacknovan;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** OCR lewat model visi Gemini dan Groq. Bila mesin utama gagal, dicoba mesin lainnya. */
final class OcrKlien {
    interface Hasil {
        void selesai(String teks, String galat);
    }

    static final int GEMINI = 0;
    static final int GROQ = 1;
    static final String MODEL_GEMINI = "gemini-2.5-flash";
    static final String MODEL_GROQ = "qwen/qwen3.8-27b";

    private static final String PROMPT =
            "Ekstrak semua teks yang terlihat pada gambar ini persis apa adanya, urut dari atas ke bawah "
                    + "dan dari kiri ke kanan. Jangan menambah komentar, tanda kutip, atau format markdown. "
                    + "Jika tidak ada teks sama sekali, jawab: Tidak ada teks.";

    /** Bila true, pemanggilan kenali berikutnya juga menerjemahkan hasilnya ke bahasa Indonesia (sekali pakai). */
    static volatile boolean terjemahSekali;

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();

    private OcrKlien() {}

    static boolean adaKunci(Context c) {
        return !Prefs.get(c).getString(Prefs.K_GEMINI_KUNCI, "").trim().isEmpty()
                || !Prefs.get(c).getString(Prefs.K_GROQ_KUNCI, "").trim().isEmpty();
    }

    static void kenali(Context c, final Bitmap bmp, final Hasil hasil) {
        final Context app = c.getApplicationContext();
        final String prompt = terjemahSekali
                ? PROMPT + " Setelah itu, terjemahkan seluruh teks tersebut ke bahasa Indonesia dan berikan hanya hasil terjemahannya."
                : PROMPT;
        terjemahSekali = false;
        final Handler main = new Handler(Looper.getMainLooper());
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                String teks = null;
                String galat = null;
                try {
                    String b64 = enkode(bmp);
                    int utama = Prefs.get(app).getInt(Prefs.K_OCR_MESIN, GEMINI);
                    int[] urutan = utama == GROQ ? new int[]{GROQ, GEMINI} : new int[]{GEMINI, GROQ};
                    for (int mesin : urutan) {
                        String kunci = Prefs.get(app).getString(
                                mesin == GEMINI ? Prefs.K_GEMINI_KUNCI : Prefs.K_GROQ_KUNCI, "").trim();
                        if (kunci.isEmpty()) continue;
                        try {
                            teks = mesin == GEMINI ? lewatGemini(app, kunci, b64, prompt) : lewatGroq(app, kunci, b64, prompt);
                            galat = null;
                            break;
                        } catch (Exception e) {
                            galat = (mesin == GEMINI ? "Gemini" : "Groq") + " gagal: " + e.getMessage();
                        }
                    }
                    if (teks == null && galat == null) galat = "Kunci API Gemini atau Groq belum diisi";
                } catch (Throwable t) {
                    galat = "OCR gagal: " + t.getMessage();
                }
                final String t = teks;
                final String g = galat;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        hasil.selesai(t, g);
                    }
                });
            }
        });
    }

    private static String enkode(Bitmap src) {
        int maks = 1600;
        Bitmap b = src;
        int sisi = Math.max(src.getWidth(), src.getHeight());
        if (sisi > maks) {
            float skala = maks / (float) sisi;
            b = Bitmap.createScaledBitmap(src, Math.max(1, Math.round(src.getWidth() * skala)),
                    Math.max(1, Math.round(src.getHeight() * skala)), true);
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 85, o);
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
    }

    private static String model(Context c, int mesin) {
        String m = Prefs.get(c).getString(mesin == GEMINI ? Prefs.K_GEMINI_MODEL : Prefs.K_GROQ_MODEL, "").trim();
        return m.isEmpty() ? (mesin == GEMINI ? MODEL_GEMINI : MODEL_GROQ) : m;
    }

    private static String lewatGemini(Context c, String kunci, String b64, String prompt) throws Exception {
        JSONObject gambar = new JSONObject().put("inline_data",
                new JSONObject().put("mime_type", "image/jpeg").put("data", b64));
        JSONObject isi = new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", prompt)).put(gambar));
        JSONObject badan = new JSONObject().put("contents", new JSONArray().put(isi));
        String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                + model(c, GEMINI) + ":generateContent";
        String balas = kirim(url, new String[]{"x-goog-api-key", kunci}, badan.toString());
        JSONObject r = new JSONObject(balas);
        JSONArray kandidat = r.optJSONArray("candidates");
        if (kandidat == null || kandidat.length() == 0) throw new Exception("tidak ada hasil");
        JSONObject konten = kandidat.getJSONObject(0).optJSONObject("content");
        JSONArray bagian = konten == null ? null : konten.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (bagian != null) {
            for (int i = 0; i < bagian.length(); i++) {
                JSONObject p = bagian.getJSONObject(i);
                if (p.optBoolean("thought", false)) continue;
                sb.append(p.optString("text", ""));
            }
        }
        String teks = sb.toString().trim();
        if (teks.isEmpty()) throw new Exception("hasil kosong");
        return teks;
    }

    private static String lewatGroq(Context c, String kunci, String b64, String prompt) throws Exception {
        JSONObject url = new JSONObject().put("url", "data:image/jpeg;base64," + b64);
        JSONArray isi = new JSONArray()
                .put(new JSONObject().put("type", "text").put("text", prompt))
                .put(new JSONObject().put("type", "image_url").put("image_url", url));
        JSONObject badan = new JSONObject()
                .put("model", model(c, GROQ))
                .put("temperature", 0)
                .put("messages", new JSONArray().put(
                        new JSONObject().put("role", "user").put("content", isi)));
        String balas = kirim("https://api.groq.com/openai/v1/chat/completions",
                new String[]{"Authorization", "Bearer " + kunci}, badan.toString());
        JSONArray pilihan = new JSONObject(balas).optJSONArray("choices");
        if (pilihan == null || pilihan.length() == 0) throw new Exception("tidak ada hasil");
        String teks = pilihan.getJSONObject(0).getJSONObject("message").optString("content", "");
        teks = teks.replaceAll("(?s)<think>.*?</think>", "").trim();
        if (teks.isEmpty()) throw new Exception("hasil kosong");
        return teks;
    }

    private static String kirim(String alamat, String[] header, String badan) throws Exception {
        HttpURLConnection k = (HttpURLConnection) new URL(alamat).openConnection();
        try {
            k.setConnectTimeout(15000);
            k.setReadTimeout(60000);
            k.setRequestMethod("POST");
            k.setDoOutput(true);
            k.setRequestProperty("Content-Type", "application/json");
            k.setRequestProperty(header[0], header[1]);
            OutputStream o = k.getOutputStream();
            o.write(badan.getBytes(StandardCharsets.UTF_8));
            o.close();
            int kode = k.getResponseCode();
            InputStream in = kode < 400 ? k.getInputStream() : k.getErrorStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            if (in != null) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
            }
            String isi = bo.toString("UTF-8");
            if (kode >= 400) {
                String ringkas = isi.length() > 200 ? isi.substring(0, 200) : isi;
                throw new Exception("HTTP " + kode + " " + ringkas);
            }
            return isi;
        } finally {
            k.disconnect();
        }
    }
}
