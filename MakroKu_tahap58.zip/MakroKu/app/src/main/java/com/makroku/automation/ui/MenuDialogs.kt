package com.makroku.automation.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** Satu baris menu tekan-tahan. [danger] = berwarna merah (mis. Hapus). */
class MenuEntry(val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
fun MenuRow(text: String, danger: Boolean = false, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        colors = ButtonDefaults.textButtonColors(
            contentColor = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        ),
    ) {
        Text(text, Modifier.fillMaxWidth(), textAlign = TextAlign.Start, style = MaterialTheme.typography.bodyLarge)
    }
}

/**
 * Menu konteks yang muncul saat sebuah item ditekan tahan (mirip MacroDroid).
 * Menutup diri sendiri sebelum menjalankan pilihan.
 */
@Composable
fun MenuDialog(title: String, entries: List<MenuEntry>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, Modifier.semantics { heading() }) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                entries.forEach { e -> MenuRow(e.label, e.danger) { onDismiss(); e.onClick() } }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}

/** Dialog satu kolom teks (ganti nama, ganti kategori). */
@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    okLabel: String = "Simpan",
    onDismiss: () -> Unit,
    onOk: (String) -> Unit,
) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, Modifier.semantics { heading() }) },
        text = { OutlinedTextField(v, { v = it }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { if (v.isNotBlank()) onOk(v.trim()) }) { Text(okLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

/** Dialog info: tiap baris satu perhentian pembaca layar. */
@Composable
fun InfoDialog(title: String, lines: List<String>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, Modifier.semantics { heading() }) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                lines.forEach { Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.heightIn(min = 32.dp)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
    )
}

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "$label disalin", Toast.LENGTH_SHORT).show()
}

/** Bagikan teks lewat menu Bagikan Android (mis. kirim JSON satu makro). */
fun shareText(ctx: Context, title: String, text: String) {
    val i = android.content.Intent(android.content.Intent.ACTION_SEND)
        .setType("text/plain")
        .putExtra(android.content.Intent.EXTRA_SUBJECT, title)
        .putExtra(android.content.Intent.EXTRA_TEXT, text)
    runCatching {
        ctx.startActivity(android.content.Intent.createChooser(i, title).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { Toast.makeText(ctx, "Tidak bisa membuka menu bagikan", Toast.LENGTH_SHORT).show() }
}
