package com.novan.githubbynovan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Mengunduh berkas/ZIP repositori langsung ke folder Download di HP. */
public class Saver {
    /** Diset true untuk membatalkan unduhan APK yang sedang berjalan. */
    static volatile boolean cancelDownload = false;

    public interface Listener {
        void progress(long bytes);
        void done(boolean ok, String message);
    }

    public static class Target {
        OutputStream os;
        Uri uri;
        File file;
        String name;
    }

    public static void save(final Context ctx, final String full, final String path, final String token,
                            final String fileName, final boolean zip, final Listener l) {
        final Handler main = new Handler(Looper.getMainLooper());
        final Context app = ctx.getApplicationContext();
        Api.POOL.execute(() -> {
            Target t = null;
            boolean ok = false;
            String msg;
            try {
                String url = zip ? Api.BASE + "/repos/" + full + "/zipball"
                                 : Api.BASE + "/repos/" + full + "/contents/" + Api.enc(path);
                HttpURLConnection c = open(url, token,
                        zip ? "application/vnd.github+json" : "application/vnd.github.raw+json");
                int code = c.getResponseCode();
                if (code >= 400) {
                    throw new IOException(code == 404 ? "Berkas tidak ditemukan (kode 404)"
                            : code == 403 ? "Akses ditolak atau batas API tercapai (kode 403)"
                            : "Kode " + code);
                }
                String name = sanitize(fileName);
                t = create(app, name, mimeOf(name));
                InputStream in = c.getInputStream();
                byte[] buf = new byte[16384];
                long total = 0, last = 0;
                int n;
                while ((n = in.read(buf)) != -1) {
                    t.os.write(buf, 0, n);
                    total += n;
                    long now = System.currentTimeMillis();
                    if (now - last > 500) {
                        last = now;
                        final long tt = total;
                        main.post(() -> l.progress(tt));
                    }
                }
                in.close();
                t.os.flush();
                t.os.close();
                c.disconnect();
                if (t.file != null && Build.VERSION.SDK_INT < 29) {
                    MediaScannerConnection.scanFile(app, new String[]{t.file.getAbsolutePath()}, null, null);
                }
                ok = true;
                msg = "Berhasil. Berkas " + t.name + " tersimpan di folder Download.";
            } catch (Exception e) {
                msg = "Gagal mengunduh: " + e.getMessage();
                if (t != null) {
                    try { if (t.os != null) t.os.close(); } catch (Exception ignored) { }
                    try {
                        if (t.uri != null) app.getContentResolver().delete(t.uri, null, null);
                        if (t.file != null) t.file.delete();
                    } catch (Exception ignored) { }
                }
            }
            final boolean fo = ok;
            final String fm = msg;
            main.post(() -> l.done(fo, fm));
        });
    }


    public interface UrlListener {
        void progress(long bytes);
        void done(boolean ok, String message, Target result);
    }

    /**
     * Unduh satu alamat ke folder Download. {@code zipApk}: alamat berupa ZIP artifact, ambil berkas
     * .apk di dalamnya. {@code fallback}: alamat cadangan (tanpa token) bila yang pertama gagal.
     */
    public static void saveUrl(final Context ctx, final String url, final String token, final String fileName,
                               final boolean zipApk, final boolean octet, final String fallback,
                               final UrlListener l) {
        final Handler main = new Handler(Looper.getMainLooper());
        final Context app = ctx.getApplicationContext();
        Api.POOL.execute(() -> {
            Target res = null;
            String err = null;
            final String accept = octet ? "application/octet-stream" : "application/vnd.github+json";
            for (int attempt = 1; attempt <= 3 && res == null; attempt++) {
                try {
                    res = fetch(app, url, token, fileName, zipApk, accept, l, main);
                } catch (Exception e) {
                    err = String.valueOf(e.getMessage());
                    if (!retryable(err)) break;
                    try { Thread.sleep(1200L * attempt); } catch (InterruptedException ignored) { }
                }
            }
            if (res == null && !cancelDownload && fallback != null && !fallback.isEmpty()) {
                try {
                    res = fetch(app, fallback, null, fileName, zipApk, "*/*", l, main);
                } catch (Exception e2) {
                    err = err + "\n\nPercobaan cadangan:\n" + e2.getMessage();
                }
            }
            final Target fr = res;
            final String fe = err;
            main.post(() -> l.done(fr != null,
                    fr != null ? "Berhasil. Berkas " + fr.name + " tersimpan di folder Download." : fe, fr));
        });
    }

    /** Kesalahan jaringan layak diulang; jawaban server (4xx/5xx) atau isi salah tidak. */
    private static boolean retryable(String msg) {
        return msg != null && !msg.startsWith("Server menjawab kode")
                && !msg.startsWith("Artefak yang dipilih") && !msg.startsWith("Tidak bisa")
                && !msg.startsWith("Dibatalkan");
    }

    private static Target fetch(Context app, String url, String token, String fileName, boolean zipApk,
                                String accept, final UrlListener l, Handler main) throws Exception {
        HttpURLConnection c = open(url, token, accept);
        Target t = null;
        try {
            int code = c.getResponseCode();
            if (code >= 400) throw new IOException("Server menjawab kode " + code + " untuk " + url);
            InputStream in = c.getInputStream();
            if (zipApk) {
                ZipInputStream z = new ZipInputStream(in);
                ZipEntry e;
                while ((e = z.getNextEntry()) != null) {
                    if (e.getName().toLowerCase().endsWith(".apk")) {
                        String nm = e.getName();
                        nm = nm.substring(nm.lastIndexOf('/') + 1);
                        t = create(app, sanitize(nm), "application/vnd.android.package-archive");
                        copy(z, t.os, l, main);
                        break;
                    }
                }
                if (t == null) {
                    throw new IOException("Artefak bukan berkas aplikasi. Tunggu build APK selesai.");
                }
            } else {
                String name = sanitize(fileName);
                t = create(app, name, mimeOf(name));
                copy(in, t.os, l, main);
            }
            t.os.flush();
            t.os.close();
            if (t.file != null && Build.VERSION.SDK_INT < 29) {
                MediaScannerConnection.scanFile(app, new String[]{t.file.getAbsolutePath()}, null, null);
            }
            return t;
        } catch (Exception e) {
            if (t != null) {
                try { if (t.os != null) t.os.close(); } catch (Exception ignored) { }
                try {
                    if (t.uri != null) app.getContentResolver().delete(t.uri, null, null);
                    if (t.file != null) t.file.delete();
                } catch (Exception ignored) { }
            }
            throw e;
        } finally {
            c.disconnect();
        }
    }

    private static void copy(InputStream in, OutputStream os, final UrlListener l, Handler main) throws IOException {
        byte[] buf = new byte[16384];
        long total = 0, last = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            if (cancelDownload) throw new IOException("Dibatalkan oleh pengguna");
            os.write(buf, 0, n);
            total += n;
            long now = System.currentTimeMillis();
            if (now - last > 500) {
                last = now;
                final long tt = total;
                main.post(() -> l.progress(tt));
            }
        }
    }

    /** Buka koneksi; pengalihan diikuti manual agar token tidak dikirim ke host lain. */
    static HttpURLConnection open(String url, String token, String accept) throws IOException {
        String cur = url;
        boolean sendAuth = true;
        for (int i = 0; i < 5; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent", "GitHub-by-novan");
            c.setRequestProperty("Accept", accept);
            if (sendAuth && token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Pengalihan tidak valid");
                URL base = new URL(cur);
                URL next = new URL(base, loc);
                if (!next.getHost().equals(base.getHost())) sendAuth = false;
                cur = next.toString();
                continue;
            }
            return c;
        }
        throw new IOException("Terlalu banyak pengalihan");
    }

    /** Simpan data kecil (misalnya keystore) langsung ke folder Download. Mengembalikan lokasi tampilannya. */
    public static String simpanBytes(Context ctx, String name, String mime, byte[] data) throws IOException {
        Context app = ctx.getApplicationContext();
        Target t = create(app, sanitize(name), mime);
        try {
            t.os.write(data);
            t.os.flush();
        } catch (IOException e) {
            try { t.os.close(); } catch (Exception ignored) { }
            try {
                if (t.uri != null) app.getContentResolver().delete(t.uri, null, null);
                if (t.file != null) t.file.delete();
            } catch (Exception ignored) { }
            throw e;
        }
        t.os.close();
        if (t.file != null && Build.VERSION.SDK_INT < 29) {
            MediaScannerConnection.scanFile(app, new String[]{t.file.getAbsolutePath()}, null, null);
        }
        return t.file != null ? t.file.getAbsolutePath() : "Download/" + t.name;
    }

    private static Target create(Context ctx, String name, String mime) throws IOException {
        Target t = new Target();
        t.name = name;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IOException("Tidak bisa membuat berkas di folder Download");
            t.uri = u;
            t.os = ctx.getContentResolver().openOutputStream(u);
            if (t.os == null) throw new IOException("Tidak bisa menulis berkas");
            try {
                Cursor q = ctx.getContentResolver().query(u,
                        new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
                if (q != null) {
                    if (q.moveToFirst()) t.name = q.getString(0);
                    q.close();
                }
            } catch (Exception ignored) { }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, name);
            int dot = name.lastIndexOf('.');
            String base = dot > 0 ? name.substring(0, dot) : name;
            String ext = dot > 0 ? name.substring(dot) : "";
            int n = 1;
            while (f.exists()) f = new File(dir, base + " (" + (n++) + ")" + ext);
            t.file = f;
            t.name = f.getName();
            t.os = new FileOutputStream(f);
        }
        return t;
    }

    private static String sanitize(String n) {
        String s = n.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return s.isEmpty() ? "berkas" : s;
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase());
            if (m != null) return m;
        }
        return "application/octet-stream";
    }
}
