package com.novan.filemanagerpro

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.util.Date
import java.util.concurrent.Executors

class TrashActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var entries: List<TrashManager.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.trash)
        empty = findViewById(R.id.empty)
        empty.setText(R.string.trash_empty)
        rowAdapter = RowAdapter(onClick = { showActions(it) }, onLong = { showActions(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        load()
    }

    private var opSeen = OpService.version

    private val opListener: (String) -> Unit = { msg ->
        if (!isDestroyed) {
            opSeen = OpService.version
            say(msg)
            load()
        }
    }

    override fun onStart() {
        super.onStart()
        OpService.listeners.add(opListener)
        if (opSeen != OpService.version) {
            opSeen = OpService.version
            load()
        }
    }

    override fun onStop() {
        super.onStop()
        OpService.listeners.remove(opListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        opDialog?.dismiss()
        executor.shutdownNow()
    }

    private var notifAsked = false

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var opDialog: OpDialog? = null

    /** Menjalankan pekerjaan di layanan latar depan: ada dialog kemajuan, notifikasi, dan tombol Batal. */
    private fun startOp(job: OpService.Job) {
        if (OpService.needsNotifPermission(this) && !notifAsked) {
            notifAsked = true
            notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        OpService.enqueue(this, job)
        opDialog?.dismiss()
        opDialog = OpDialog(this, job) { say(getString(R.string.op_hidden)) }.also { it.show() }
    }

    private fun load() {
        executor.execute {
            val list = TrashManager.load().sortedByDescending { it.time }
            val rows = list.map {
                val date = DateFormat.getMediumDateFormat(this).format(Date(it.time))
                val detail = "${Formatter.formatFileSize(this, it.size)}, " +
                    getString(R.string.deleted_on, date) + ", " + (java.io.File(it.orig).parent ?: "")
                Row(R.drawable.ic_trash, it.name, detail, "${it.name}, $detail", it.id)
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                entries = list
                rowAdapter.submit(rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                invalidateOptionsMenu()
            }
        }
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun showActions(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        val labels = arrayOf(getString(R.string.act_restore), getString(R.string.act_delete_forever))
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    startOp(OpJobs.trashRestore(e, getString(R.string.act_restore)))
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.act_delete_forever)
                        .setMessage(getString(R.string.delete_confirm, 1))
                        .setPositiveButton(R.string.action_delete) { _, _ ->
                            startOp(OpJobs.trashDelete(listOf(e), false, getString(R.string.act_delete_forever)))
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.trash_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_empty).isVisible = entries.isNotEmpty()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_empty -> AlertDialog.Builder(this)
                .setTitle(R.string.empty_trash)
                .setMessage(R.string.empty_trash_confirm)
                .setPositiveButton(R.string.empty_trash) { _, _ ->
                    startOp(OpJobs.trashDelete(emptyList(), true, getString(R.string.empty_trash)))
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
