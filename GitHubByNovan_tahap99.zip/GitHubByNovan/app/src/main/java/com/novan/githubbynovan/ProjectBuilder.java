package com.novan.githubbynovan;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Menyusun seluruh berkas proyek Android + workflow GitHub Actions dari pilihan pengguna. */
public class ProjectBuilder {
    public static final String WORKFLOW_NAME = "bangun-apk.yml";

    public static class Options {
        public String nama = "", slug = "", paket = "", versi = "1.0.0", url = "", html = "";
        public String jenisProyek = "webview", tema = "Terang", orientasi = "Otomatis";
        public String warnaIkon = "#1976D2", abi = "universal";
        public int versionCode = 1, minSdk = 24, targetSdk = 35, compileSdk = 35;
        public final Set<String> flags = new HashSet<>();

        public boolean on(String k) { return flags.contains(k); }
        public boolean kotlin() { return "kotlin".equals(jenisProyek) || "compose".equals(jenisProyek); }
        public boolean web() { return "webview".equals(jenisProyek) || "html".equals(jenisProyek); }
    }

    // ---------- fungsi bantu (padanan fungsi di skrip Lua) ----------

    public static String slug(String teks) {
        if (teks == null) return "aplikasi";
        String s = teks.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-");
        s = s.replaceAll("^-+", "").replaceAll("-+$", "");
        return s.isEmpty() ? "aplikasi" : s;
    }

    public static String autoPackage(String slug) {
        if (slug == null || slug.isEmpty()) slug = "aplikasi";
        String s = slug.replace("-", "");
        if (s.isEmpty() || Character.isDigit(s.charAt(0))) s = "app" + s;
        return "com.aplikasi." + s;
    }

    public static boolean packageValid(String p) {
        if (p == null || p.startsWith(".") || p.endsWith(".") || p.contains("..")) return false;
        int n = 0;
        for (String seg : p.split("\\.")) {
            if (seg.isEmpty()) continue;
            if (!seg.matches("[a-z][a-z0-9_]*")) return false;
            n++;
        }
        return n >= 2;
    }

    static String escXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String escJava(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    static String bool(boolean b) { return b ? "true" : "false"; }

    static String theme(String n) {
        return "Terang".equals(n) ? "@android:style/Theme.DeviceDefault.Light.NoActionBar"
                : "@android:style/Theme.DeviceDefault.NoActionBar";
    }

    static String orientation(String n) {
        if ("Potret".equals(n)) return "portrait";
        if ("Lanskap".equals(n)) return "landscape";
        return "unspecified";
    }

    static String permissions(Options o) {
        final List<String> p = new ArrayList<>();
        final String readExt = "    <uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\" android:maxSdkVersion=\"32\" />";
        if (o.on("internet")) p.add(perm("INTERNET"));
        if (o.on("statusJaringan")) p.add(perm("ACCESS_NETWORK_STATE"));
        if (o.on("statusWifi")) p.add(perm("ACCESS_WIFI_STATE"));
        if (o.on("penyimpanan")) {
            p.add(readExt);
            p.add("    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\" android:maxSdkVersion=\"28\" />");
        }
        if (o.on("kelolaBerkas")) p.add(perm("MANAGE_EXTERNAL_STORAGE"));
        if (o.on("pasangApk")) p.add(perm("REQUEST_INSTALL_PACKAGES"));
        if (o.on("audioSetting")) p.add(perm("MODIFY_AUDIO_SETTINGS"));
        if (o.on("kamera")) p.add(perm("CAMERA"));
        if (o.on("mikrofon")) p.add(perm("RECORD_AUDIO"));
        if (o.on("notifikasi")) p.add(perm("POST_NOTIFICATIONS"));
        if (o.on("lokasi")) {
            p.add(perm("ACCESS_COARSE_LOCATION"));
            p.add(perm("ACCESS_FINE_LOCATION"));
        }
        if (o.on("lokasiLatar")) p.add(perm("ACCESS_BACKGROUND_LOCATION"));
        if (o.on("bluetooth")) {
            p.add(perm("BLUETOOTH"));
            p.add(perm("BLUETOOTH_ADMIN"));
            p.add(perm("BLUETOOTH_CONNECT"));
            p.add(perm("BLUETOOTH_SCAN"));
        }
        if (o.on("bluetoothAdv")) p.add(perm("BLUETOOTH_ADVERTISE"));
        if (o.on("wifiDekat")) p.add(perm("NEARBY_WIFI_DEVICES"));
        if (o.on("nfc")) p.add(perm("NFC"));
        boolean t33 = o.targetSdk >= 33;
        if (o.on("audio")) p.add(t33 ? perm("READ_MEDIA_AUDIO") : readExt);
        if (o.on("foto")) p.add(t33 ? perm("READ_MEDIA_IMAGES") : readExt);
        if (o.on("video")) p.add(t33 ? perm("READ_MEDIA_VIDEO") : readExt);
        if (o.on("mediaVisual") && o.targetSdk >= 34) p.add(perm("READ_MEDIA_VISUAL_USER_SELECTED"));
        if (o.on("kontak")) { p.add(perm("READ_CONTACTS")); p.add(perm("WRITE_CONTACTS")); }
        if (o.on("kalender")) { p.add(perm("READ_CALENDAR")); p.add(perm("WRITE_CALENDAR")); }
        if (o.on("telepon")) p.add(perm("READ_PHONE_STATE"));
        if (o.on("panggilan")) p.add(perm("CALL_PHONE"));
        if (o.on("sms")) { p.add(perm("READ_SMS")); p.add(perm("SEND_SMS")); }
        if (o.on("sensorTubuh")) p.add(perm("BODY_SENSORS"));
        if (o.on("aktivitas")) p.add(perm("ACTIVITY_RECOGNITION"));
        if (o.on("alarm")) p.add(perm("SCHEDULE_EXACT_ALARM"));
        if (o.on("boot")) p.add(perm("RECEIVE_BOOT_COMPLETED"));
        if (o.on("getar")) p.add(perm("VIBRATE"));
        if (o.on("wake")) p.add(perm("WAKE_LOCK"));
        if (o.on("overlay")) p.add(perm("SYSTEM_ALERT_WINDOW"));
        if (o.on("battery")) p.add(perm("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"));
        if (o.on("fgs") || o.on("fgsMedia") || o.on("fgsCamera") || o.on("fgsMic") || o.on("fgsLocation")
                || o.on("fgsData") || o.on("fgsDevice") || o.on("fgsMediaProc") || o.on("fgsProjection")
                || o.on("fgsPhone")) {
            p.add(perm("FOREGROUND_SERVICE"));
        }
        if (o.on("fgsMedia")) p.add(perm("FOREGROUND_SERVICE_MEDIA_PLAYBACK"));
        if (o.on("fgsCamera")) p.add(perm("FOREGROUND_SERVICE_CAMERA"));
        if (o.on("fgsMic")) p.add(perm("FOREGROUND_SERVICE_MICROPHONE"));
        if (o.on("fgsLocation")) p.add(perm("FOREGROUND_SERVICE_LOCATION"));
        if (o.on("fgsData")) p.add(perm("FOREGROUND_SERVICE_DATA_SYNC"));
        if (o.on("fgsDevice")) p.add(perm("FOREGROUND_SERVICE_CONNECTED_DEVICE"));
        if (o.on("fgsMediaProc")) p.add(perm("FOREGROUND_SERVICE_MEDIA_PROCESSING"));
        if (o.on("fgsProjection")) p.add(perm("FOREGROUND_SERVICE_MEDIA_PROJECTION"));
        if (o.on("fgsPhone")) p.add(perm("FOREGROUND_SERVICE_PHONE_CALL"));
        return join(p, "\n");
    }

    private static String perm(String name) {
        return "    <uses-permission android:name=\"android.permission." + name + "\" />";
    }

    static String dependencies(Options o) {
        List<String> d = new ArrayList<>();
        boolean kt = o.kotlin();
        boolean compose = "compose".equals(o.jenisProyek);
        if (o.on("camerax")) {
            d.add("implementation 'androidx.camera:camera-core:1.3.4'");
            d.add("implementation 'androidx.camera:camera-camera2:1.3.4'");
            d.add("implementation 'androidx.camera:camera-lifecycle:1.3.4'");
            d.add("implementation 'androidx.camera:camera-view:1.3.4'");
        }
        if (o.on("mlkit")) d.add("implementation 'com.google.mlkit:text-recognition:16.0.1'");
        if (o.on("room")) {
            d.add("implementation 'androidx.room:room-runtime:2.6.1'");
            d.add(kt ? "kapt 'androidx.room:room-compiler:2.6.1'"
                    : "annotationProcessor 'androidx.room:room-compiler:2.6.1'");
        }
        if (o.on("recyclerview")) d.add("implementation 'androidx.recyclerview:recyclerview:1.3.2'");
        if (o.on("constraint")) d.add("implementation 'androidx.constraintlayout:constraintlayout:2.1.4'");
        if (o.on("lifecycle")) d.add("implementation 'androidx.lifecycle:lifecycle-runtime:2.8.4'");
        if (o.on("navigation")) {
            d.add("implementation 'androidx.navigation:navigation-fragment:2.7.7'");
            d.add("implementation 'androidx.navigation:navigation-ui:2.7.7'");
        }
        if (compose) {
            d.add("implementation platform('androidx.compose:compose-bom:2024.06.00')");
            d.add("implementation 'androidx.activity:activity-compose:1.9.1'");
            d.add("implementation 'androidx.compose.ui:ui'");
            d.add("implementation 'androidx.compose.ui:ui-tooling-preview'");
            d.add("implementation 'androidx.compose.material3:material3'");
            d.add("debugImplementation 'androidx.compose.ui:ui-tooling'");
        }
        d.add("implementation fileTree(dir: 'libs', include: ['*.jar','*.aar'])");
        return join(d, "\n    ");
    }

    static String join(List<String> l, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    private static final Pattern KEY = Pattern.compile("@@([A-Z_]+)@@");

    static String fill(String template, Map<String, String> map) {
        Matcher m = KEY.matcher(template);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String v = map.get(m.group(1));
            m.appendReplacement(sb, Matcher.quoteReplacement(v == null ? "" : v));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Isi berkas workflow pembangun APK untuk repo yang belum memilikinya. */
    public static String workflowFor(Context c, String slug) throws Exception {
        return workflowFor(c, slug, new ArrayList<String>());
    }

    /** Alur kerja dengan daftar nama secret yang diteruskan ke Gradle (satu per satu, tanpa toJSON(secrets)). */
    public static String workflowFor(Context c, String slug, List<String> rahasia) throws Exception {
        Map<String, String> m = new HashMap<>();
        m.put("NAMA_APK", slug);
        m.put("TT_GUARD_SOURCE", guardSource(c));
        m.put("KT_GUARD_SOURCE", kunciSource(c));
        m.put("ENV_RAHASIA", envRahasia(rahasia));
        return fill(asset(c, "workflowLengkap"), m);
    }

    /** Nama secret yang layak diteruskan ke Gradle: huruf besar, tanpa KS_* dan GITHUB_*, tanpa ganda. */
    static List<String> layakRahasia(List<String> rahasia) {
        List<String> out = new ArrayList<>();
        Set<String> sudah = new HashSet<>();
        if (rahasia != null) {
            for (String n : rahasia) {
                if (n == null) continue;
                String u = n.trim().toUpperCase(Locale.ROOT);
                if (!u.matches("[A-Z_][A-Z0-9_]*")) continue;
                if (u.equals("KS_B64") || u.equals("KS_ALIAS") || u.equals("KS_PASS")) continue;
                if (u.startsWith("GITHUB_")) continue;
                if (!sudah.add(u)) continue;
                out.add(u);
            }
        }
        return out;
    }

    /** Baris env "NAMA: ${{ secrets.NAMA }}" untuk langkah kompilasi; nama kunci tanda tangan dilewati. */
    static String envRahasia(List<String> rahasia) {
        StringBuilder sb = new StringBuilder();
        for (String u : layakRahasia(rahasia)) {
            if (sb.length() > 0) sb.append("\n          ");
            sb.append(u).append(": ${{ secrets.").append(u).append(" }}");
        }
        return sb.toString();
    }

    /** Tahap 99: secret layak yang belum diteruskan isi alur kerja ini (tidak ada "secrets.NAMA"). */
    public static List<String> rahasiaBelumTerusan(String isiAlur, List<String> rahasia) {
        List<String> kurang = new ArrayList<>();
        String isi = isiAlur == null ? "" : isiAlur;
        for (String u : layakRahasia(rahasia)) {
            if (!Pattern.compile("secrets\\." + Pattern.quote(u) + "(?![A-Za-z0-9_])").matcher(isi).find()) kurang.add(u);
        }
        return kurang;
    }

    public interface NamaCb { void done(boolean ok, List<String> nama); }

    /** Tahap 99: ambil daftar NAMA secret repo (bukan isinya). ok=false bila token tidak boleh membacanya. */
    public static void namaRahasia(String full, String token, NamaCb cb) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/secrets?per_page=100", token, null, (ok, res) -> {
            List<String> nama = new ArrayList<>();
            if (ok) {
                org.json.JSONArray arr = Api.parse(res).optJSONArray("secrets");
                for (int i = 0; arr != null && i < arr.length(); i++) {
                    org.json.JSONObject o = arr.optJSONObject(i);
                    if (o != null) nama.add(o.optString("name", ""));
                }
            }
            cb.done(ok, nama);
        });
    }

    /** Ambil nama secret repo dari GitHub (bukan isinya), lalu susun alur kerja. Hasil lewat cb di thread utama. */
    public static void workflowUntuk(final Context c, final String full, final String token, final String slug,
                                     final Api.Callback cb) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/secrets?per_page=100", token, null, (ok, res) -> {
            List<String> nama = new ArrayList<>();
            if (ok) {
                org.json.JSONArray arr = Api.parse(res).optJSONArray("secrets");
                for (int i = 0; arr != null && i < arr.length(); i++) {
                    org.json.JSONObject o = arr.optJSONObject(i);
                    if (o != null) nama.add(o.optString("name", ""));
                }
            }
            try {
                cb.done(true, workflowFor(c, slug, nama));
            } catch (Exception e) {
                cb.done(false, "Templat tidak terbaca: " + e.getMessage());
            }
        });
    }

    /** Kode penjaga untuk disisipkan ke alur kerja (heredoc YAML, menjorok 10 spasi); paket diisi saat build. */
    static String guardSource(Context c) throws Exception {
        return heredoc(asset(c, "ttGuard").replace("@@PAKET@@", "__TT_PAKET__"));
    }

    /** Kode kelas kunci terikat tanda tangan untuk disisipkan ke alur kerja; paket diisi saat build. */
    static String kunciSource(Context c) throws Exception {
        return heredoc(asset(c, "kunciGuard").replace("@@PAKET@@", "__KT_PAKET__"));
    }

    private static String heredoc(String src) {
        StringBuilder sb = new StringBuilder();
        String[] lines = src.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            if (i > 0) sb.append('\n');
            if (!lines[i].isEmpty()) sb.append("          ").append(lines[i]);
        }
        return sb.toString();
    }

    static String asset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open("templates/" + name + ".txt");
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    // ---------- penyusun berkas ----------

    /** Daftar berkas proyek: setiap elemen {jalur, isi}. */
    public static List<String[]> files(Context ctx, Options o) throws Exception {
        boolean web = o.web();
        boolean kt = o.kotlin();
        String alamat = o.url.isEmpty() ? "file:///android_asset/index.html" : o.url;
        String versiBersih = o.versi.replaceAll("[^A-Za-z0-9.\\-]", "");
        if (versiBersih.isEmpty()) versiBersih = "1.0.0";
        String hex = o.warnaIkon.replace("#", "");

        Map<String, String> m = new HashMap<>();
        m.put("TT_GUARD_SOURCE", guardSource(ctx));
        m.put("KT_GUARD_SOURCE", kunciSource(ctx));
        m.put("NAMA_PROYEK", o.slug);
        m.put("NAMA_APK", o.slug);
        m.put("NAMA_XML", escXml(o.nama));
        m.put("PAKET", o.paket);
        m.put("VERSI", versiBersih);
        m.put("VERSION_CODE", String.valueOf(o.versionCode));
        m.put("COMPILE_SDK", String.valueOf(o.compileSdk));
        m.put("MIN_SDK", String.valueOf(o.minSdk));
        m.put("TARGET_SDK", String.valueOf(o.targetSdk));
        m.put("ALAMAT", escJava(alamat));
        m.put("JS", bool(o.on("js")));
        m.put("SIMPAN", bool(o.on("simpan")));
        m.put("FILE_ACCESS", bool(o.on("fileAccess")));
        m.put("CONTENT_ACCESS", bool(o.on("contentAccess")));
        m.put("ZOOM", bool(o.on("zoom")));
        m.put("MEDIA_GESTURE", bool(!o.on("mediaGesture")));
        m.put("KEMBALI", bool(o.on("kembali")));
        m.put("TT_PANGGIL", o.on("lindungiTT") ? "TTGuard.periksa(this);" : "");
        m.put("IZIN", permissions(o));
        m.put("BACKUP", "true");
        m.put("CLEAR_TEXT", "false");
        m.put("TEMA", theme(o.tema));
        m.put("ORIENTASI", orientation(o.orientasi));
        m.put("WARNA_IKON", o.warnaIkon);
        m.put("WARNA_IKON_HEX", hex);
        m.put("COMPONENTS", (o.on("lindungiTT")
                ? "        <provider android:name=\".TTGuard\" android:authorities=\"${applicationId}.ttguard\" android:exported=\"false\" android:initOrder=\"2147483647\" />\n" : "")
                + (o.on("lindungiKT")
                ? "        <provider android:name=\".KunciTandaTangan$Init\" android:authorities=\"${applicationId}.ktguard\" android:exported=\"false\" android:initOrder=\"2147483647\" />\n" : "")
                + (o.on("service") ? "        <service android:name=\".NovanService\" android:exported=\"false\" />\n" : "")
                + (o.on("receiver") ? "        <receiver android:name=\".NovanReceiver\" android:exported=\"false\" />" : ""));
        m.put("KOTLIN_PLUGIN", kt ? (o.on("room")
                ? "id 'org.jetbrains.kotlin.android'\n     id 'org.jetbrains.kotlin.kapt'"
                : "id 'org.jetbrains.kotlin.android'") : "");
        m.put("KOTLIN_OPTIONS", kt ? "kotlinOptions { jvmTarget = '17' }" : "");
        m.put("COMPOSE_ENABLED", bool("compose".equals(o.jenisProyek)));
        m.put("COMPOSE_OPTIONS", "compose".equals(o.jenisProyek)
                ? "composeOptions { kotlinCompilerExtensionVersion '1.5.14' }" : "");
        m.put("DEPENDENCIES", dependencies(o));
        m.put("MINIFY", bool(o.on("minify")));
        m.put("SHRINK", bool(o.on("shrink")));
        m.put("ABI_SPLIT", bool(!"universal".equals(o.abi)));
        String abiInc;
        if ("arm64".equals(o.abi)) abiInc = "'arm64-v8a'";
        else if ("armv7".equals(o.abi)) abiInc = "'armeabi-v7a'";
        else abiInc = "'arm64-v8a', 'armeabi-v7a'";
        m.put("ABI_INCLUDE", abiInc);

        String dir = o.paket.replace('.', '/');
        List<String[]> f = new ArrayList<>();
        f.add(new String[]{"settings.gradle", fill(asset(ctx, "settings"), m)});
        f.add(new String[]{"build.gradle", fill(asset(ctx, "buildRoot"), m)});
        f.add(new String[]{"gradle.properties", fill(asset(ctx, "gradleProps"), m)});
        f.add(new String[]{"app/build.gradle", fill(asset(ctx, "buildApp"), m)});
        f.add(new String[]{"app/proguard-rules.pro", asset(ctx, "proguard")});
        f.add(new String[]{"app/src/main/AndroidManifest.xml", fill(asset(ctx, "manifest"), m)});
        f.add(new String[]{"app/src/main/res/values/strings.xml", fill(asset(ctx, "strings"), m)});
        f.add(new String[]{"app/src/main/res/drawable/ikon_aplikasi.xml", fill(asset(ctx, "icon"), m)});
        if (!kt) {
            f.add(new String[]{"app/src/main/java/" + dir + "/MainActivity.java",
                    fill(asset(ctx, web ? "activity" : "nativeJava"), m)});
        }
        f.add(new String[]{".github/workflows/" + WORKFLOW_NAME, fill(asset(ctx, "workflowLengkap"), m)});
        if (o.on("readme")) f.add(new String[]{"README.md", fill(asset(ctx, "readme"), m)});
        if (kt) {
            f.add(new String[]{"app/src/main/java/" + dir + "/MainActivity.kt",
                    fill(asset(ctx, "compose".equals(o.jenisProyek) ? "composeKotlin" : "nativeKotlin"), m)});
        }
        if (o.on("lindungiTT")) {
            f.add(new String[]{"app/src/main/java/" + dir + "/TTGuard.java", fill(asset(ctx, "ttGuard"), m)});
        }
        if (o.on("lindungiKT")) {
            f.add(new String[]{"app/src/main/java/" + dir + "/KunciTandaTangan.java", fill(asset(ctx, "kunciGuard"), m)});
        }
        if (o.on("service")) {
            f.add(new String[]{"app/src/main/java/" + dir + "/NovanService.java", fill(asset(ctx, "serviceJava"), m)});
        }
        if (o.on("receiver")) {
            f.add(new String[]{"app/src/main/java/" + dir + "/NovanReceiver.java", fill(asset(ctx, "receiverJava"), m)});
        }
        if (o.on("instrumentationTest")) {
            f.add(new String[]{"app/src/androidTest/java/" + dir + "/MainActivityTest.java",
                    fill(asset(ctx, "activityTest"), m)});
        }
        f.add(new String[]{"app/libs/README.txt",
                "Letakkan file .jar atau .aar lokal di folder libs.\n"
                        + "Library native .so dapat ditempatkan sesuai ABI di src/main/jniLibs/."});
        if (web && o.url.isEmpty()) {
            String html = o.html;
            if (html.isEmpty()) html = fill(asset(ctx, "html"), m);
            f.add(new String[]{"app/src/main/assets/index.html", html});
        }
        return f;
    }
}
