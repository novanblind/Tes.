package com.makroku.automation.engine

import android.content.Context
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.model.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.builtins.ListSerializer

/** Inti otomatisasi: menerima kejadian, mencocokkan pemicu, memeriksa batasan, lalu menjalankan aksi. */
class MacroEngine(app: Context, val repo: MacroRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val executor = ActionExecutor(app, repo)
    private val checker = ConstraintChecker(app, repo)
    val scheduler = Scheduler(app)

    @Volatile private var lastBattery = -1
    @Volatile private var lastTemp = -999

    /** Jadwalkan ulang alarm hanya saat pemicu/status aktif berubah. */
    fun start() {
        watchVariables()
        scope.launch {
            repo.macros
                .distinctUntilChangedBy { l -> l.map { Triple(it.id, it.enabled, it.triggers) } }
                .collect { scheduler.reschedule(it); scope.launch { syncWindows(it) } }
        }
    }

    private var prevVars: Map<String, String> = emptyMap()

    /** Mengirim kejadian "variable" saat nilai variabel berubah (untuk pemicu Variabel berubah). */
    private fun watchVariables() {
        scope.launch {
            repo.variables.collect { now ->
                val before = prevVars
                prevVars = now
                if (!lastVarInit) { lastVarInit = true; return@collect }
                now.forEach { (k, v) ->
                    if (before[k] != v) dispatch(TriggerEvent("variable", mapOf("var_name" to k, "var_value" to v)))
                }
            }
        }
    }
    @Volatile private var lastVarInit = false

    fun dispatch(event: TriggerEvent) {
        if (!repo.appEnabled.value) return
        // Jam atau zona waktu diubah: hitung ulang semua jadwal (seperti BateraiBicara).
        if (event.kind == "time_changed") { scheduler.reschedule(repo.macros.value); scope.launch { syncWindows(repo.macros.value) }; return }
        if (event.kind == "timezone_changed") { scheduler.reschedule(repo.macros.value); scope.launch { syncWindows(repo.macros.value) } }
        var e = event
        if (e.kind == "battery") {
            val level = e.data["level"]?.toIntOrNull() ?: return
            e = e.copy(data = e.data + ("prev" to lastBattery.toString()))
            lastBattery = level
        }
        if (e.kind == "battery_temp") {
            val c = e.data["temp"]?.toIntOrNull() ?: return
            e = e.copy(data = e.data + ("prev" to lastTemp.toString()))
            lastTemp = c
            if (lastTemp == c && e.data["prev"] == "-999") return
        }
        val ev = e
        scope.launch {
            repo.macros.value
                .mapNotNull { m ->
                    if (!m.enabled) null
                    else m.triggers.indexOfFirst { TriggerMatcher.matches(it, ev, m) }.takeIf { it >= 0 }?.let { m to it }
                }
                .forEach { (m, i) -> launch { run(m, ev.copy(data = ev.data + ("trigger_index" to i.toString())), force = false) } }
        }
    }

    /** Jalankan makro secara manual (tombol, pintasan) — mengabaikan batasan. */
    fun runNow(id: Long): Boolean {
        if (!repo.appEnabled.value) return false
        scope.launch {
            repo.find(id)?.let { run(it, TriggerEvent("manual", mapOf("macroId" to id.toString())), force = true) }
        }
        return true
    }

    /** Dipanggil AlarmReceiver untuk pemicu waktu/interval. Nomor >= END_OFFSET = alarm SELESAI milik pemicu rentang waktu. */
    fun fireScheduled(macroId: Long, idx: Int) {
        scope.launch {
            val selesai = idx >= Scheduler.END_OFFSET
            val real = if (selesai) idx - Scheduler.END_OFFSET else idx
            val m = repo.find(macroId)
            if (selesai) {
                // Pasang alarm berikutnya dulu, lalu kembalikan keadaan. Pengembalian tetap jalan walau MakroKu dimatikan.
                m?.takeIf { it.enabled }?.let { scheduler.scheduleOne(it, real) }
                endWindow(macroId, real, m?.name ?: "Rentang waktu")
                return@launch
            }
            if (m == null || !m.enabled) return@launch
            // Pasang alarm berikutnya DULU, baru jalankan makro. Jadwal tidak hilang bila makro lama (mis. jeda 10 menit)
            // atau proses dimatikan sistem di tengah jalan, dan tidak bergeser sebesar lama makro berjalan.
            scheduler.scheduleOne(m, real)
            if (!repo.appEnabled.value) return@launch
            if (m.triggers.getOrNull(real) is TimeWindowTrigger) startWindow(m, real) else run(m, TriggerEvent("time", mapOf("trigger_index" to real.toString())), force = false)
        }
    }

    // ───────────── Rentang waktu: mulai → jalankan aksi, selesai → kembalikan keadaan ─────────────
    private val winPrefs = app.getSharedPreferences("windows", Context.MODE_PRIVATE)
    private val winLock = Mutex()
    private val undoSer = ListSerializer(MacroAction.serializer())

    private fun winKey(id: Long, idx: Int) = "undo:$id:$idx"

    /** Simpan keadaan awal lalu jalankan aksi. Bila rentang itu sudah aktif, tidak diulang (keadaan awal tidak tertimpa). */
    private suspend fun startWindow(m: Macro, idx: Int): Unit = winLock.withLock {
        val key = winKey(m.id, idx)
        if (winPrefs.contains(key)) return@withLock
        if (!constraintsOk(m, mapOf("trigger_kind" to "time"))) {
            repo.log(m.name, "Rentang waktu dilewati: batasan tidak terpenuhi", true)
            return@withLock
        }
        val undo = try { executor.snapshotUndo(m.actions) } catch (ce: CancellationException) { throw ce } catch (ex: Exception) { emptyList() }
        winPrefs.edit().putString(key, AppJson.encodeToString(undoSer, undo)).apply()
        repo.log(m.name, "Rentang waktu dimulai (${undo.size} keadaan disimpan untuk dikembalikan)", true)
        run(m, TriggerEvent("time", mapOf("window" to "start")), force = true)
    }

    /** Kembalikan keadaan seperti sebelum rentang dimulai. Tidak melakukan apa-apa bila rentang itu tidak sedang aktif. */
    private suspend fun endWindow(id: Long, idx: Int, name: String): Unit = winLock.withLock {
        val key = winKey(id, idx)
        val txt = winPrefs.getString(key, null) ?: return@withLock
        winPrefs.edit().remove(key).apply()
        val undo = try { AppJson.decodeFromString(undoSer, txt) } catch (e: Exception) { emptyList() }
        val wl = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "makroku:rentang")
        wl.acquire(10 * 60_000L)
        try {
            if (undo.isNotEmpty()) executor.runTop(undo, mapOf("trigger_kind" to "time", "window" to "end"), name)
            repo.log(name, "Rentang waktu selesai: keadaan dikembalikan seperti semula", true)
        } catch (ce: CancellationException) {
            throw ce
        } catch (ex: Exception) {
            repo.log(name, "Rentang waktu selesai, tetapi pengembalian gagal: ${ex.message}", false)
        } finally {
            if (wl.isHeld) wl.release()
        }
    }

    /**
     * Cocokkan keadaan dengan jam sekarang (dipanggil saat aplikasi mulai, jam/zona waktu berubah, atau makro diubah):
     * rentang yang sudah lewat dikembalikan (juga bila makronya dimatikan atau dihapus), rentang yang sedang berlangsung dimulai.
     */
    private suspend fun syncWindows(macros: List<Macro>) {
        val now = System.currentTimeMillis()
        for (key in winPrefs.all.keys.filter { it.startsWith("undo:") }) {
            val p = key.split(":")
            val id = p.getOrNull(1)?.toLongOrNull() ?: continue
            val idx = p.getOrNull(2)?.toIntOrNull() ?: continue
            val m = macros.firstOrNull { it.id == id }
            val t = m?.triggers?.getOrNull(idx) as? TimeWindowTrigger
            if (m == null || !m.enabled || t == null || !Scheduler.inWindow(t, now)) endWindow(id, idx, m?.name ?: "Rentang waktu")
        }
        if (!repo.appEnabled.value) return
        for (m in macros.filter { it.enabled }) {
            m.triggers.forEachIndexed { i, t ->
                if (t is TimeWindowTrigger && Scheduler.inWindow(t, now) && !winPrefs.contains(winKey(m.id, i))) startWindow(m, i)
            }
        }
    }

    private fun constraintsOk(m: Macro, ctxData: Map<String, String>): Boolean {
        val aktif = m.constraints.filter { it !is OffConstraint }
        return aktif.isEmpty() ||
            if (m.constraintAny) aktif.any { checker.check(it, ctxData) } else aktif.all { checker.check(it, ctxData) }
    }

    /** Uji satu aksi saja (menu tekan-tahan di editor), tanpa pemicu dan tanpa batasan. */
    fun testAction(a: MacroAction, label: String) {
        scope.launch {
            try {
                val data = mapOf("battery" to checker.batteryLevel().toString(), "trigger_kind" to "manual")
                executor.runTop(listOf(a), data, "Uji aksi")
                repo.log("Uji aksi", "$label dijalankan", true)
            } catch (ce: CancellationException) {
                throw ce
            } catch (ex: Exception) {
                repo.log("Uji aksi", "Gagal: ${ex.message}", false)
            }
        }
    }

    private val powerManager = app.getSystemService(android.os.PowerManager::class.java)

    /** Jaga CPU tetap hidup selama makro berjalan (maksimal 30 menit) agar jeda dan aksi berurutan tidak molor saat layar mati. */
    private suspend fun run(m: Macro, e: TriggerEvent, force: Boolean) {
        val wl = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "makroku:makro")
        wl.acquire(30 * 60_000L)
        try {
            runInner(m, e, force)
        } finally {
            if (wl.isHeld) wl.release()
        }
    }

    private suspend fun runInner(m: Macro, e: TriggerEvent, force: Boolean) {
        // Data pemicu (nomor pemicu, judul/isi notifikasi, dst) ikut ke pemeriksaan batasan, supaya batasan per pemicu dan
        // batasan "Bandingkan dua teks" yang memakai penanda seperti {notif_title} bisa dinilai.
        val ctxData = e.data + ("trigger_kind" to e.kind)
        if (!force && !constraintsOk(m, ctxData)) {
            repo.log(m.name, "Dilewati: batasan tidak terpenuhi", true)
            return
        }
        val data = e.data + ("battery" to checker.batteryLevel().toString()) + ctxData
        try {
            executor.runTop(m.actions, data, m.name)
            repo.markRun(m.id)
            repo.log(m.name, "Dijalankan (pemicu: ${e.kind})", true)
            val chain = e.data["chain"]?.toIntOrNull() ?: 0
            if (chain < 5) dispatch(TriggerEvent("macro_done", mapOf("macro_name" to m.name, "chain" to (chain + 1).toString())))
        } catch (ce: CancellationException) {
            throw ce
        } catch (ex: Exception) {
            repo.log(m.name, "Gagal: ${ex.message}", false)
        }
    }
}

object TriggerMatcher {
    fun matches(t: MacroTrigger, e: TriggerEvent, m: Macro): Boolean = when (t) {
        is TimeTrigger, is PeriodicTrigger, is MonthlyTrigger, is TimesTrigger, is SunTrigger, is OnceTrigger, is TimeWindowTrigger -> false // ditangani Scheduler
        is BootTrigger -> e.kind == "boot"
        is ManualTrigger -> e.kind == "manual" && e.data["macroId"] == m.id.toString()
        is BatteryLevelTrigger -> e.kind == "battery" && batteryCrossed(t, e)
        is PowerTrigger -> e.kind == "power" && e.data["connected"] == t.connected.toString()
        is ScreenTrigger -> e.kind == "screen" && e.data["on"] == t.on.toString()
        is WifiStateTrigger -> e.kind == "wifi" && e.data["enabled"] == t.enabled.toString()
        is BluetoothStateTrigger -> e.kind == "bluetooth" && e.data["enabled"] == t.enabled.toString()
        is AirplaneTrigger -> e.kind == "airplane" && e.data["on"] == t.on.toString()
        is HeadphoneTrigger -> e.kind == "headphone" && e.data["plugged"] == t.plugged.toString()
        is SmsTrigger -> e.kind == "sms" &&
            has(e.data["sms_sender"], t.sender) && has(e.data["sms_body"], t.contains)
        is CallTrigger -> e.kind == "call" && has(e.data["call_number"], t.number)
        is NotificationTrigger -> e.kind == "notification" &&
            (t.pkg.isBlank() || e.data["notif_pkg"] == t.pkg) &&
            !(t.ignoreOngoing && e.data["notif_ongoing"] == "true") &&
            notifTextOk(t, (e.data["notif_title"].orEmpty() + " " + e.data["notif_full"].orEmpty().ifBlank { e.data["notif_text"].orEmpty() }))
        is AppLaunchedTrigger -> e.kind == "app" && (t.pkg.isBlank() || e.data["app_pkg"] == t.pkg)
        is IntentTrigger -> e.kind == "intent" && e.data["action"] == t.action
        is UnlockTrigger -> e.kind == "unlock"
        is AppPackageTrigger -> e.kind == "package" && e.data["installed"] == t.installed.toString() &&
            (t.pkg.isBlank() || e.data["app_pkg"] == t.pkg)
        is BluetoothDeviceTrigger -> e.kind == "bt_device" && e.data["connected"] == t.connected.toString() &&
            has(e.data["bt_name"], t.device)
        is CallEndedTrigger -> e.kind == "call_end" && has(e.data["call_number"], t.number)
        is ShakeTrigger -> e.kind == "shake" && (e.data["force"]?.toFloatOrNull() ?: 0f) >= t.force.coerceIn(5, 40)
        is WifiNetworkTrigger -> e.kind == "wifi_net" && e.data["connected"] == t.connected.toString() &&
            (t.ssid.isBlank() || e.data["wifi_ssid"].orEmpty().trim('"').equals(t.ssid.trim('"'), ignoreCase = true))
        is GeofenceTrigger -> e.kind == "location" && geoMatches(t, e, m)
        is VariableChangedTrigger -> e.kind == "variable" && e.data["var_name"] == t.name &&
            (t.value.isBlank() || e.data["var_value"] == t.value)
        is RingerChangedTrigger -> e.kind == "ringer" && e.data["mode"] == t.ringerMode
        is PowerSaveTrigger -> e.kind == "power_save" && e.data["on"] == t.on.toString()
        is DndChangedTrigger -> e.kind == "dnd" && e.data["on"] == t.on.toString()
        is SyncStateTrigger -> e.kind == "sync" && e.data["on"] == t.on.toString()
        is MobileDataTrigger -> e.kind == "cell_net" && e.data["connected"] == t.connected.toString()
        is DateChangedTrigger -> e.kind == "date_changed"
        is MissedCallTrigger -> e.kind == "missed_call" && has(e.data["call_number"], t.number)
        is NotificationRemovedTrigger -> e.kind == "notif_removed" &&
            (t.pkg.isBlank() || e.data["notif_pkg"] == t.pkg) &&
            has((e.data["notif_title"].orEmpty() + " " + e.data["notif_text"].orEmpty()), t.contains)
        is VolumeKeyTrigger -> e.kind == "volume_key" && e.data["key"] == t.volKey &&
            (t.press == "any" || e.data["press"] == t.press)
        is ProximityTrigger -> e.kind == "proximity" && e.data["near"] == t.near.toString()
        is FlipTrigger -> e.kind == "flip" && e.data["down"] == t.faceDown.toString()
        is WidgetTrigger -> e.kind == "widget" && e.data["slot"] == t.slot.toString()
        is FloatingButtonTrigger -> e.kind == "floating" && e.data["label"] == t.label
        is TileTrigger -> e.kind == "tile" && e.data["tile"] == t.tile.toString()
        is WebhookTrigger -> e.kind == "webhook" &&
            e.data["hook"].orEmpty().trim('/').equals(t.hookPath.trim('/'), ignoreCase = true) &&
            (if (t.token.isBlank()) e.data["loopback"] == "true" else e.data["token"] == t.token)
        is UsbStateTrigger -> e.kind == "usb" && e.data["connected"] == t.connected.toString()
        is OffTrigger -> false
        is BatteryTempTrigger -> e.kind == "battery_temp" && tempCrossed(t, e)
        is ChargerTypeTrigger -> e.kind == "charger_type" &&
            (t.plugType == "any" || e.data["plug"] == t.plugType)
        is ShutdownTrigger -> e.kind == "shutdown"
        is AppClosedTrigger -> e.kind == "app_closed" &&
            (t.pkg.isBlank() || e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true))
        is BatteryFullTrigger -> e.kind == "battery_full"
        is TimezoneChangedTrigger -> e.kind == "timezone_changed"
        is GpsStateTrigger -> e.kind == "gps" && e.data["on"] == t.on.toString()
        is CallActiveTrigger -> e.kind == "call_active" && has(e.data["call_number"], t.number)
        is DaydreamTrigger -> e.kind == "daydream" && e.data["on"] == t.on.toString()
        is DozeTrigger -> e.kind == "doze" && e.data["on"] == t.on.toString()
        is LocaleChangedTrigger -> e.kind == "locale_changed"
        is DockTrigger -> e.kind == "dock" && e.data["docked"] == t.docked.toString()
        is HotspotTrigger -> e.kind == "hotspot" && e.data["on"] == t.on.toString()
        is NfcStateTrigger -> e.kind == "nfc_state" && e.data["on"] == t.on.toString()
        is MusicPlayingTrigger -> e.kind == "music" && e.data["playing"] == t.playing.toString()
        is LightSensorTrigger -> e.kind == "light" && lightCrossed(t, e)
        is OrientationTrigger -> e.kind == "orientation" && e.data["landscape"] == t.landscape.toString()
        is VolumeChangedTrigger -> e.kind == "volume_changed" && e.data["stream"] == t.stream
        is OutgoingCallTrigger -> e.kind == "call_out"
        is DarkThemeTrigger -> e.kind == "dark_theme" && e.data["on"] == t.on.toString()
        is VpnStateTrigger -> e.kind == "vpn" && e.data["connected"] == t.connected.toString()
        is InternetStateTrigger -> e.kind == "internet" && e.data["connected"] == t.connected.toString()
        is NextAlarmChangedTrigger -> e.kind == "next_alarm"
        is BrightnessChangedTrigger -> e.kind == "brightness"
        is NotificationButtonTrigger -> e.kind == "notif_button" &&
            (t.buttonLabel.isBlank() || e.data["button"].orEmpty().equals(t.buttonLabel.trim(), ignoreCase = true))
        is AppUpdatedTrigger -> e.kind == "package_updated" &&
            (t.pkg.isBlank() || e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true))
        is ShellOutputTrigger -> e.kind == "shell_output" &&
            e.data["shell_cmd"].orEmpty() == t.command.trim() && shellHit(t, e)
        is SettingChangedTrigger -> e.kind == "setting_changed" &&
            e.data["setting_ns"] == t.ns.trim() && e.data["setting_key"] == t.key.trim() &&
            (t.value.isBlank() || e.data["setting_value"] == t.value.trim())
        is MicActiveTrigger -> e.kind == "mic_active" && e.data["active"] == t.active.toString()
        is CameraActiveTrigger -> e.kind == "camera_active" && e.data["active"] == t.active.toString()
        is NewMediaTrigger -> e.kind == "new_media" && (t.mediaKind == "any" || e.data["media_kind"] == t.mediaKind)
        is ScreenTextTrigger -> e.kind == "screen_text" && e.data["screen_needle"] == t.text.trim() &&
            (t.pkg.isBlank() || e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true))
        is AdbStateTrigger -> e.kind == "adb_state" && e.data["connected"] == t.connected.toString()
        is AppRunningTrigger -> e.kind == "app_running" && e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true) &&
            e.data["running"] == t.running.toString()
        is ForegroundAdbTrigger -> e.kind == "foreground_adb" &&
            (t.pkg.isBlank() || e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true))
        is NewFileTrigger -> e.kind == "new_file" && e.data["watch_dir"] == t.watchDir.trim().trimEnd('/') &&
            (t.contains.isBlank() || e.data["file_name"].orEmpty().contains(t.contains.trim(), ignoreCase = true))
        is AppCrashTrigger -> e.kind == "app_crash" &&
            (t.pkg.isBlank() || e.data["app_pkg"].orEmpty().equals(t.pkg.trim(), ignoreCase = true))
        is TorchStateTrigger -> e.kind == "torch" && e.data["on"] == t.on.toString()
        is ScreenReaderStateTrigger -> e.kind == "screen_reader" && e.data["on"] == t.on.toString()
        is FreeFallTrigger -> e.kind == "free_fall"
        is ClipboardChangedTrigger -> e.kind == "clipboard" &&
            (t.contains.isBlank() || e.data["clip_text"].orEmpty().contains(t.contains.trim(), ignoreCase = true))
        is MusicTrackTrigger -> e.kind == "music_track" &&
            (t.contains.isBlank() || (e.data["track_title"].orEmpty() + " " + e.data["track_artist"].orEmpty())
                .contains(t.contains.trim(), ignoreCase = true))
        is SensorValueTrigger -> e.kind == "sensor_value" && e.data["sensor"] == t.sensorKind && sensorCrossed(t, e)
        is LogcatTrigger -> e.kind == "logcat" && t.contains.isNotBlank() &&
            e.data["log_line"].orEmpty().contains(t.contains.trim(), ignoreCase = true) &&
            (t.logTag.isBlank() || e.data["log_tag"].orEmpty().equals(t.logTag.trim(), ignoreCase = true))
        is CalendarEventTrigger -> e.kind == "calendar" && e.data["cal_start"] == t.eventStart.toString() &&
            (t.contains.isBlank() || e.data["cal_title"].orEmpty().contains(t.contains.trim(), ignoreCase = true))
        is CellSignalTrigger -> e.kind == "cell_signal" && signalCrossed(t, e)
        is WifiNearbyTrigger -> e.kind == "wifi_nearby" && e.data["needle"] == t.ssid.trim() && e.data["appear"] == t.appear.toString()
        is NetworkTypeTrigger -> e.kind == "network_type" && e.data["net"] == t.netType
        is PowerButtonTrigger -> e.kind == "power_taps" && e.data["count"] == t.presses.coerceIn(2, 6).toString()
        is ScreenDurationTrigger -> e.kind == "screen_duration" && e.data["on"] == t.screenOn.toString() &&
            e.data["minutes"] == t.afterMinutes.coerceIn(1, 1440).toString()
        is CallContactTrigger -> e.kind == "call" && e.data["call_name"].orEmpty().isNotEmpty() &&
            has(e.data["call_name"], t.contactName)
        is MacroDoneTrigger -> e.kind == "macro_done" &&
            e.data["macro_name"].orEmpty().equals(t.macroName.trim(), ignoreCase = true) &&
            !m.name.equals(t.macroName.trim(), ignoreCase = true)
    }

    /** Pemicu shell: berubah dari bacaan sebelumnya, atau mulai mengandung teks yang dicari. */
    private fun shellHit(t: ShellOutputTrigger, e: TriggerEvent): Boolean {
        val cur = e.data["shell_out"].orEmpty()
        val prev = e.data["shell_prev"].orEmpty()
        if (t.onChange) return cur != prev
        if (t.contains.isBlank()) return false
        return cur.contains(t.contains, ignoreCase = true) && !prev.contains(t.contains, ignoreCase = true)
    }

    private val insideState = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /** Memicu hanya saat status masuk/keluar area berubah. */
    private fun geoMatches(t: GeofenceTrigger, e: TriggerEvent, m: Macro): Boolean {
        val lat = t.lat.trim().toDoubleOrNull() ?: return false
        val lon = t.lon.trim().toDoubleOrNull() ?: return false
        val cl = e.data["lat"]?.toDoubleOrNull() ?: return false
        val co = e.data["lon"]?.toDoubleOrNull() ?: return false
        val res = FloatArray(1)
        android.location.Location.distanceBetween(lat, lon, cl, co, res)
        val inside = res[0] <= t.radius.coerceAtLeast(20)
        val key = "${m.id}:${t.lat}:${t.lon}:${t.radius}"
        val prev = insideState.put(key, inside)
        if (prev == null || prev == inside) return false
        return inside == t.enter
    }

    /** Teks pemicu notifikasi: mengandung (atau regex), atau kebalikannya bila [NotificationTrigger.excludes]. Teks pencarian kosong = semua. */
    private fun notifTextOk(t: NotificationTrigger, gabung: String): Boolean {
        if (t.contains.isBlank()) return true
        val ada = if (t.regex) runCatching { Regex(t.contains, RegexOption.IGNORE_CASE).containsMatchIn(gabung) }.getOrDefault(false)
        else gabung.contains(t.contains, ignoreCase = true)
        return if (t.excludes) !ada else ada
    }

    private fun has(value: String?, needle: String) =
        needle.isBlank() || (value ?: "").contains(needle, ignoreCase = true)

    /** Memicu hanya saat suhu melintasi ambang (derajat Celsius). */
    private fun tempCrossed(t: BatteryTempTrigger, e: TriggerEvent): Boolean {
        val c = e.data["temp"]?.toIntOrNull() ?: return false
        val p = e.data["prev"]?.toIntOrNull() ?: return false
        return if (t.above) c >= t.celsius && p < t.celsius else c <= t.celsius && p > t.celsius
    }

    /** Memicu hanya saat sinyal seluler melintasi batas. */
    private fun signalCrossed(t: CellSignalTrigger, e: TriggerEvent): Boolean {
        val c = e.data["level"]?.toIntOrNull() ?: return false
        val p = e.data["prev"]?.toIntOrNull() ?: return false
        return if (t.below) c <= t.signalLevel && p > t.signalLevel else c >= t.signalLevel && p < t.signalLevel
    }

    /** Memicu hanya saat nilai sensor melintasi batas (bukan tiap perubahan). */
    private fun sensorCrossed(t: SensorValueTrigger, e: TriggerEvent): Boolean {
        val c = e.data["sensor_value"]?.toFloatOrNull() ?: return false
        val p = e.data["prev"]?.toFloatOrNull() ?: return false
        return if (t.overLimit) c >= t.limit && p < t.limit else c <= t.limit && p > t.limit
    }

    /** Memicu hanya saat cahaya melintasi ambang lux. */
    private fun lightCrossed(t: LightSensorTrigger, e: TriggerEvent): Boolean {
        val c = e.data["lux"]?.toFloatOrNull() ?: return false
        val p = e.data["prev"]?.toFloatOrNull() ?: return false
        return if (t.darker) c < t.lux && p >= t.lux else c >= t.lux && p < t.lux
    }

    /** Memicu hanya saat level melewati ambang (bukan setiap perubahan). */
    private fun batteryCrossed(t: BatteryLevelTrigger, e: TriggerEvent): Boolean {
        val lv = e.data["level"]?.toIntOrNull() ?: return false
        val pv = e.data["prev"]?.toIntOrNull() ?: return false
        if (pv < 0) return false
        return if (t.below) lv <= t.level && pv > t.level else lv >= t.level && pv < t.level
    }
}
