package com.novan.audiolabnovan.sfx

import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Tahap 89: efek suara bawaan yang dibuat dari rumus (sinus, derau, dan selubung), tanpa AI dan tanpa berkas unduhan.
 * Hasil mono 16 bit, puncaknya dinormalkan sekitar -2 dBFS, dengan sentuhan awal dan akhir yang halus supaya tidak "klik".
 */
object PembuatSfx {

    val NAMA = listOf(
        "Ding (bel kecil)",
        "Lonceng",
        "Beep",
        "Nada notifikasi",
        "Whoosh naik",
        "Whoosh turun",
        "Dentuman",
        "Tepuk tangan",
        "Gulungan drum dan simbal",
        "Sirene",
        "Ketukan",
        "Telepon berdering",
        "Kilau",
        "Level naik",
        "Gagal (nada turun)"
    )

    fun buat(id: Int, sr: Int): ShortArray {
        val x = when (id) {
            0 -> ding(sr)
            1 -> lonceng(sr)
            2 -> beep(sr)
            3 -> notifikasi(sr)
            4 -> whoosh(sr, true)
            5 -> whoosh(sr, false)
            6 -> dentuman(sr)
            7 -> tepukTangan(sr)
            8 -> drum(sr)
            9 -> sirene(sr)
            10 -> ketukan(sr)
            11 -> telepon(sr)
            12 -> kilau(sr)
            13 -> levelNaik(sr)
            else -> gagal(sr)
        }
        return normalkan(x, sr)
    }

    private fun normalkan(x: DoubleArray, sr: Int): ShortArray {
        var p = 1e-9
        for (v in x) p = max(p, abs(v))
        val g = 0.8 * 32_767.0 / p
        val masuk = (sr * 0.004).toInt()
        val keluar = (sr * 0.012).toInt()
        return ShortArray(x.size) { i ->
            var a = 1.0
            if (i < masuk) a = i.toDouble() / masuk
            val sisa = x.size - 1 - i
            if (sisa < keluar) a = min(a, sisa.toDouble() / keluar)
            (x[i] * g * a).toInt().coerceIn(-32_767, 32_767).toShort()
        }
    }

    private fun tau(t: Double, t0: Double) = exp(-t / t0)
    private fun nada(f: Double, t: Double) = sin(2.0 * PI * f * t)

    private fun ding(sr: Int) = DoubleArray((sr * 1.4).toInt()) { i ->
        val t = i.toDouble() / sr
        (nada(1318.5, t) + 0.35 * nada(2637.0, t) * tau(t, 0.15)) * min(1.0, t / 0.002) * tau(t, 0.35)
    }

    private fun lonceng(sr: Int): DoubleArray {
        val rasio = doubleArrayOf(1.0, 2.0, 2.76, 5.4, 8.93)
        val amp = doubleArrayOf(1.0, 0.6, 0.5, 0.3, 0.15)
        val sus = doubleArrayOf(1.2, 0.9, 0.6, 0.35, 0.2)
        return DoubleArray((sr * 3.0).toInt()) { i ->
            val t = i.toDouble() / sr
            var v = 0.0
            for (k in rasio.indices) v += amp[k] * nada(330.0 * rasio[k], t) * tau(t, sus[k])
            v * min(1.0, t / 0.002)
        }
    }

    private fun beep(sr: Int): DoubleArray {
        val len = 0.3
        return DoubleArray((sr * len).toInt()) { i ->
            val t = i.toDouble() / sr
            nada(1000.0, t) * min(1.0, t / 0.003) * min(1.0, (len - t) / 0.005)
        }
    }

    private fun notifikasi(sr: Int) = DoubleArray((sr * 0.5).toInt()) { i ->
        val t = i.toDouble() / sr
        if (t < 0.12) nada(880.0, t) * tau(t, 0.1)
        else (t - 0.12).let { u -> nada(1318.5, u) * tau(u, 0.15) }
    }

    /** Derau disaring lolos-rendah yang frekuensinya menyapu naik atau turun, dengan selubung berbentuk bukit. */
    private fun whoosh(sr: Int, naik: Boolean): DoubleArray {
        val n = sr
        val r = Random(1)
        var y1 = 0.0
        var y2 = 0.0
        return DoubleArray(n) { i ->
            val p = i.toDouble() / n
            val q = if (naik) p else 1.0 - p
            val fc = 300.0 * (6000.0 / 300.0).pow(q)
            val a = 1.0 - exp(-2.0 * PI * fc / sr)
            val x = r.nextDouble() * 2.0 - 1.0
            y1 += a * (x - y1)
            y2 += a * (y1 - y2)
            val env = sin(PI * p).pow(2.0)
            y2 * env
        }
    }

    private fun dentuman(sr: Int): DoubleArray {
        val n = (sr * 1.6).toInt()
        val r = Random(2)
        var fase = 0.0
        var lp = 0.0
        val a = 1.0 - exp(-2.0 * PI * 400.0 / sr)
        return DoubleArray(n) { i ->
            val t = i.toDouble() / sr
            fase += 2.0 * PI * (35.0 + 80.0 * exp(-t * 6.0)) / sr
            lp += a * ((r.nextDouble() * 2.0 - 1.0) - lp)
            (sin(fase) * tau(t, 0.5) + 0.6 * lp * tau(t, 0.12)) * min(1.0, t / 0.001)
        }
    }

    private fun tepukTangan(sr: Int): DoubleArray {
        val n = sr * 3
        val out = DoubleArray(n)
        val r = Random(7)
        val panjang = (sr * 0.05).toInt()
        for (i in 0 until n) {
            val p = i.toDouble() / n
            val rapat = 60.0 * sin(PI * p).pow(0.7)
            if (r.nextDouble() < rapat / sr) {
                val amp = 0.4 + 0.6 * r.nextDouble()
                var prev = r.nextDouble() * 2.0 - 1.0
                for (k in 0 until panjang) {
                    if (i + k >= n) break
                    val x = r.nextDouble() * 2.0 - 1.0
                    out[i + k] += (x - prev) * amp * exp(-k / (0.012 * sr))
                    prev = x
                }
            }
        }
        return out
    }

    private fun drum(sr: Int): DoubleArray {
        val n = (sr * 3.0).toInt()
        val out = DoubleArray(n)
        val r = Random(5)
        fun pukul(pos: Int, amp: Double) {
            val panjang = (sr * 0.12).toInt()
            for (k in 0 until panjang) {
                if (pos + k >= n) break
                val t = k.toDouble() / sr
                out[pos + k] += amp * (nada(190.0, t) * tau(t, 0.03) + 0.6 * (r.nextDouble() * 2.0 - 1.0) * tau(t, 0.02))
            }
        }
        var t = 0.0
        while (t < 1.6) {
            val p = t / 1.6
            pukul((t * sr).toInt(), 0.25 + 0.75 * p)
            t += 1.0 / (18.0 + 12.0 * p)
        }
        val pos = (sr * 1.7).toInt()
        pukul(pos, 1.0)
        var prev = 0.0
        for (k in 0 until sr) {
            if (pos + k >= n) break
            val x = r.nextDouble() * 2.0 - 1.0
            out[pos + k] += 0.9 * (x - prev) * exp(-k / (0.4 * sr))
            prev = x
        }
        return out
    }

    private fun sirene(sr: Int): DoubleArray {
        val n = (sr * 2.4).toInt()
        var fase = 0.0
        return DoubleArray(n) { i ->
            val t = i.toDouble() / sr
            fase += 2.0 * PI * (1000.0 + 400.0 * sin(2.0 * PI * t / 1.2 - PI / 2.0)) / sr
            (sin(fase) + 0.25 * sin(2.0 * fase)) * min(1.0, t / 0.01) * min(1.0, (2.4 - t) / 0.01)
        }
    }

    private fun ketukan(sr: Int): DoubleArray {
        val r = Random(3)
        return DoubleArray((sr * 0.15).toInt()) { i ->
            val t = i.toDouble() / sr
            nada(1800.0, t) * tau(t, 0.012) + 0.5 * (r.nextDouble() * 2.0 - 1.0) * tau(t, 0.002)
        }
    }

    private fun telepon(sr: Int) = DoubleArray((sr * 2.0).toInt()) { i ->
        val t = i.toDouble() / sr
        val nyala = (t < 0.4) || (t in 0.6..1.0)
        if (!nyala) 0.0
        else {
            val u = if (t < 0.4) t else t - 0.6
            val tepi = min(1.0, min(u / 0.005, (0.4 - u) / 0.005))
            (nada(440.0, t) + nada(480.0, t)) * 0.5 * (0.6 + 0.4 * nada(20.0, t)) * tepi
        }
    }

    private fun kilau(sr: Int): DoubleArray {
        val n = (sr * 1.5).toInt()
        val out = DoubleArray(n)
        val r = Random(11)
        val nadaAtas = doubleArrayOf(2093.0, 2637.0, 3136.0, 3951.0, 4186.0)
        for (k in 0 until 14) {
            val awal = (r.nextDouble() * 0.9 * sr).toInt()
            val f = nadaAtas[r.nextInt(nadaAtas.size)]
            val amp = 1.0 - 0.6 * awal.toDouble() / (0.9 * sr)
            for (j in 0 until (sr * 0.4).toInt()) {
                if (awal + j >= n) break
                val t = j.toDouble() / sr
                out[awal + j] += amp * nada(f, t) * tau(t, 0.12) * min(1.0, t / 0.002)
            }
        }
        return out
    }

    private fun urutanNada(sr: Int, panjang: Double, awal: DoubleArray, frek: DoubleArray, sus: DoubleArray, jeda: Double): DoubleArray {
        val n = (sr * panjang).toInt()
        return DoubleArray(n) { i ->
            val t = i.toDouble() / sr
            var v = 0.0
            for (k in frek.indices) {
                val u = t - awal[k]
                if (u >= 0.0) v += (nada(frek[k], u) + 0.3 * nada(2.0 * frek[k], u)) * tau(u, sus[k]) * min(1.0, u / 0.003)
            }
            v
        }
    }

    private fun levelNaik(sr: Int) = urutanNada(
        sr, 0.9, doubleArrayOf(0.0, 0.08, 0.16, 0.24),
        doubleArrayOf(523.25, 659.25, 783.99, 1046.5), doubleArrayOf(0.15, 0.15, 0.15, 0.35), 0.08
    )

    private fun gagal(sr: Int) = urutanNada(
        sr, 1.1, doubleArrayOf(0.0, 0.2, 0.4, 0.6),
        doubleArrayOf(392.0, 349.2, 311.1, 261.6), doubleArrayOf(0.2, 0.2, 0.2, 0.3), 0.2
    )
}
