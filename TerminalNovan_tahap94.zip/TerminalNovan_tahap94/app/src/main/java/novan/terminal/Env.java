package novan.terminal;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.util.*;

/** Lingkungan bergaya Termux: folder usr (PREFIX) dan home milik aplikasi sendiri. */
public class Env {
    static File prefix, home, tmp;
    static int target;
    static String nativeDir;

    static void init(Context c) {
        File base = c.getFilesDir();
        prefix = new File(base, "usr");
        home = new File(base, "home");
        tmp = new File(prefix, "tmp");
        for (File d : new File[]{prefix, new File(prefix, "bin"), new File(prefix, "lib"),
                new File(prefix, "etc"), new File(prefix, "share"), home, tmp}) d.mkdirs();
        target = c.getApplicationInfo().targetSdkVersion;
        nativeDir = c.getApplicationInfo().nativeLibraryDir;
    }

    static String path() {
        return prefix.getPath() + "/bin:/system/bin:/system/xbin:/vendor/bin";
    }

    static void apply(Map<String, String> m) {
        m.put("PREFIX", prefix.getPath());
        m.put("HOME", home.getPath());
        m.put("TMPDIR", tmp.getPath());
        m.put("PATH", path());
        m.put("LD_LIBRARY_PATH", prefix.getPath() + "/lib");
        m.put("TERM", "xterm-256color");
        m.put("LANG", "en_US.UTF-8");
        m.put("ANDROID_DATA", "/data");
        m.put("ANDROID_ROOT", "/system");
        m.put("EXTERNAL_STORAGE", "/sdcard");
        // Android SDK hasil "siap": dikenali otomatis oleh ./gradlew biasa, tanpa local.properties.
        File sdk = new File(home, "android-sdk");
        if (sdk.isDirectory()) { m.put("ANDROID_HOME", sdk.getPath()); m.put("ANDROID_SDK_ROOT", sdk.getPath()); }
        // Penyadap exec milik aplikasi (libnovanexec.so): menjalankan biner lewat linker sistem pada targetSdk 29+.
        String pl = "";
        if (target >= 29 && nativeDir != null) {
            File mine = new File(nativeDir, "libnovanexec.so");
            if (mine.exists()) pl = mine.getPath();
        }
        File pre = new File(prefix, "lib/libtermux-exec-ld-preload.so");
        if (!pre.exists()) pre = new File(prefix, "lib/libtermux-exec.so");
        if (pre.exists()) pl = pl.isEmpty() ? pre.getPath() : pl + ":" + pre.getPath();
        if (!pl.isEmpty()) m.put("LD_PRELOAD", pl);
    }

    /** Shell utama: bash dari bootstrap Termux bila sudah terpasang, bila belum shell sistem. */
    static String shell() {
        File b = new File(prefix, "bin/bash");
        return b.exists() ? b.getPath() : "/system/bin/sh";
    }

    /**
     * Android 10 ke atas (targetSdk 29+) melarang exec() langsung pada berkas di folder aplikasi.
     * Biner ELF di usr/ atau home/ dijalankan lewat /system/bin/linker64, skrip lewat interpreternya.
     * Program yang dijalankan dari dalam shell ditangani libtermux-exec lewat LD_PRELOAD.
     */
    static String[] wrap(String... cmd) {
        if (target < 29 || cmd.length == 0) return cmd;
        try {
            File f = new File(cmd[0]);
            String p = f.getCanonicalPath();
            String d = prefix.getParentFile().getCanonicalPath() + "/";
            if (!p.startsWith(d) || !f.isFile()) return cmd;
            String linker = android.os.Process.is64Bit() ? "/system/bin/linker64" : "/system/bin/linker";
            byte[] h = new byte[256];
            int n;
            try (InputStream in = new FileInputStream(f)) { n = in.read(h); }
            ArrayList<String> r = new ArrayList<>();
            r.add(linker);
            if (n >= 4 && h[0] == 0x7f && h[1] == 'E' && h[2] == 'L' && h[3] == 'F') {
                r.add(p);
            } else if (n >= 2 && h[0] == '#' && h[1] == '!') {
                String l = new String(h, 2, n - 2, "UTF-8");
                int e = l.indexOf('\n');
                if (e >= 0) l = l.substring(0, e);
                l = l.trim();
                String[] w = l.split("\\s+", 2);
                String w0 = w[0];
                for (String d0 : new String[]{"/usr/bin/", "/bin/", "/usr/local/bin/"}) {
                    if (w0.startsWith(d0) && !new File(w0).exists()) {
                        File alt = new File(prefix, "bin/" + w0.substring(d0.length()));
                        if (alt.exists()) w0 = alt.getPath();
                    }
                }
                File ip = new File(w0);
                if (!ip.isFile()) return cmd;
                if (ip.getCanonicalPath().startsWith(d)) r.add(ip.getCanonicalPath());
                else { r.clear(); r.add(w0); }
                if (w.length > 1 && !w[1].isEmpty()) r.add(w[1]);
                r.add(p);
            } else return cmd;
            for (int i = 1; i < cmd.length; i++) r.add(cmd[i]);
            return r.toArray(new String[0]);
        } catch (Throwable t) { return cmd; }
    }

    static String[] vars(int rows, int cols) {
        HashMap<String, String> m = new HashMap<>();
        apply(m);
        m.put("COLUMNS", String.valueOf(cols));
        m.put("LINES", String.valueOf(rows));
        String[] r = new String[m.size()];
        int i = 0;
        for (Map.Entry<String, String> e : m.entrySet()) r[i++] = e.getKey() + "=" + e.getValue();
        return r;
    }

    static String info() {
        return "PREFIX=" + prefix + "\nHOME=" + home + "\nTMPDIR=" + tmp + "\nPATH=" + path()
            + "\nABI=" + Build.SUPPORTED_ABIS[0] + "\nAndroid API=" + Build.VERSION.SDK_INT
            + "\ntargetSdk aplikasi=" + target;
    }

    /** Menyalin shell sistem ke usr/bin lalu menjalankannya: membuktikan biner di folder aplikasi boleh dieksekusi. */
    static String selfTest() {
        try {
            File t = new File(prefix, "bin/uji-sh");
            try (InputStream in = new FileInputStream("/system/bin/sh"); OutputStream out = new FileOutputStream(t)) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
            }
            t.setExecutable(true, false);
            ProcessBuilder pb = new ProcessBuilder(wrap(t.getPath(), "-c", "echo eksekusi-ok"));
            apply(pb.environment());
            pb.redirectErrorStream(true);
            Process p = pb.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l = r.readLine();
            p.waitFor();
            t.delete();
            if ("eksekusi-ok".equals(l)) return "Berhasil: biner di folder usr/bin bisa dijalankan. Siap untuk tahap berikutnya.";
            return "Gagal: keluaran tidak sesuai: " + l;
        } catch (Throwable e) {
            return "Gagal: " + e.getMessage() + ". Android menolak eksekusi dari folder aplikasi.";
        }
    }
}
