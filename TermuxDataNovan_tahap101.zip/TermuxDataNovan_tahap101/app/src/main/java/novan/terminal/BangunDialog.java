package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Alur Bangun APK: setelah proyek dipilih, tanda tangan dan keamanan berjalan otomatis.
 * Bila hanya ada satu tanda tangan pribadi, langsung terpilih; penjaga tanda tangan bawaannya aktif.
 * Dialog pilihan tanda tangan hanya muncul bila belum ada tanda tangan pribadi atau ada beberapa
 * dan belum pernah dipilih. Tanda tangan dan keamanan diatur di pengaturan aplikasi (Menu lainnya).
 * Bila arg bernilai null, dialog dipakai hanya untuk pengaturan, tanpa membangun.
 */
class BangunDialog {

    static void say(String s) { MainActivity.say(s); }

    /** Mulai bangun APK dari proyek di folder arg (kosong = folder kerja). */
    static void mulai(Activity a, String arg) {
        String ttd = Ks.otomatis();
        if (ttd == null) { langkah1(a, arg); return; }
        say("Memakai tanda tangan " + (ttd.equals("bawaan") ? "bawaan" : ttd) + ", keamanan penjaga "
            + (ttd.equals("bawaan") ? "tidak dipakai" : Penjaga.aktif() ? "aktif" : "nonaktif"));
        mulaiBangun(a, arg);
    }

    /** Kelola tanda tangan saja, tanpa membangun. */
    static void kelola(Activity a) { langkah1(a, null); }

    private static String ket(String nama, String aktif) {
        return nama.equals(aktif) ? " (pribadi, dipakai terakhir)" : " (pribadi)";
    }

    static void mulaiBangun(Activity a, String arg) {
        if (a instanceof MainActivity) ((MainActivity) a).mulaiBangun(arg);
    }

    // ---------------------------------------------------------------- pilih tanda tangan / pengaturan

    static void langkah1(final Activity a, final String arg) {
        final boolean bangun = arg != null;
        final List<String> pribadi = Ks.daftar();
        if (!bangun) Ks.otomatis();
        final String aktif = Ks.aktif();
        final List<String> nama = new ArrayList<>();
        final List<Runnable> aksi = new ArrayList<>();

        if (!bangun) {
            nama.add("Keamanan penjaga tanda tangan: " + (Penjaga.aktif() ? "aktif" : "nonaktif") + ". Ketuk untuk mengganti");
            aksi.add(() -> {
                boolean on = !Penjaga.aktif();
                Penjaga.set(on);
                say("Keamanan penjaga tanda tangan " + (on ? "diaktifkan" : "dimatikan")
                    + (on ? ". Berlaku bila membangun dengan tanda tangan pribadi" : ""));
                langkah1(a, null);
            });
        }
        nama.add("Bawaan (uji coba, tanpa penjaga)" + (aktif.equals("bawaan") ? " (dipakai terakhir)" : ""));
        aksi.add(() -> {
            Ks.setAktif("bawaan");
            if (bangun) mulaiBangun(a, arg); else { say("Tanda tangan bawaan dipilih"); langkah1(a, null); }
        });
        for (final String p : pribadi) {
            nama.add(p + ket(p, aktif));
            aksi.add(() -> {
                Ks.setAktif(p);
                if (bangun) mulaiBangun(a, arg); else { say("Tanda tangan " + p + " dipilih"); langkah1(a, null); }
            });
        }
        nama.add("Buat tanda tangan baru");
        aksi.add(() -> buatBaru(a, arg));
        nama.add("Impor tanda tangan dari berkas p12");
        aksi.add(() -> imporBerkas(a, arg));
        if (!pribadi.isEmpty()) {
            nama.add("Kelola: ekspor cadangan atau hapus tanda tangan");
            aksi.add(() -> kelolaDaftar(a, arg));
        }

        new AlertDialog.Builder(a)
            .setTitle(bangun ? "Pilih tanda tangan" : "Pengaturan tanda tangan dan keamanan APK")
            .setItems(nama.toArray(new String[0]), (d, i) -> aksi.get(i).run())
            .setNegativeButton("Batal", (d, w) -> say("Dibatalkan"))
            .show();
    }

    // ---------------------------------------------------------------- buat baru

    private static void buatBaru(final Activity a, final String arg) {
        final EditText et = new EditText(a);
        et.setHint("Contoh: pribadi");
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setSingleLine(true);
        et.setContentDescription("Nama tanda tangan baru");
        new AlertDialog.Builder(a)
            .setTitle("Nama tanda tangan baru")
            .setMessage("Pakai huruf, angka, strip, atau garis bawah, tanpa spasi.")
            .setView(et)
            .setPositiveButton("Buat", (d, w) -> {
                final String nm = Ks.nama(et.getText().toString());
                if (nm.isEmpty()) { say("Nama kosong"); langkah1(a, arg); return; }
                if (Ks.p12(nm).exists()) { say("Nama " + nm + " sudah dipakai"); langkah1(a, arg); return; }
                Ks.buat(nm, () -> {
                    Ks.setAktif(nm);
                    if (arg != null) mulaiBangun(a, arg); else langkah1(a, null);
                });
            })
            .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
            .show();
    }

    // ---------------------------------------------------------------- impor

    private static void imporBerkas(final Activity a, final String arg) {
        final List<File> ada = Ks.cari();
        if (ada.isEmpty()) {
            new AlertDialog.Builder(a)
                .setTitle("Berkas p12 tidak ditemukan")
                .setMessage("Tidak ada berkas .p12 di folder Download atau subfoldernya. Tekan Cari di folder lain untuk mencarinya di folder mana saja, atau taruh berkas di Download dan pastikan izin penyimpanan aktif.")
                .setPositiveButton("Izin penyimpanan", (d, w) -> { if (a instanceof MainActivity) ((MainActivity) a).askStorage(); })
                .setNeutralButton("Cari di folder lain", (d, w) -> jelajahP12(a, arg))
                .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
                .show();
            return;
        }
        String[] n = new String[ada.size()];
        for (int i = 0; i < n.length; i++) n[i] = ada.get(i).getName() + " di " + Ks.lokasiSingkat(ada.get(i));
        new AlertDialog.Builder(a)
            .setTitle("Pilih berkas p12")
            .setItems(n, (d, i) -> coba(a, arg, ada.get(i)))
            .setNeutralButton("Cari di folder lain", (d, w) -> jelajahP12(a, arg))
            .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
            .show();
    }

    /** Penjelajah folder untuk memilih berkas .p12 atau .pfx di folder mana saja (bukan hanya Download). */
    private static void jelajahP12(final Activity a, final String arg) {
        Jelajah.buka(a, "Pilih berkas tanda tangan (.p12 atau .pfx)", new String[]{".p12", ".pfx"}, false, f -> coba(a, arg, f));
    }

    /** Bila ada berkas "<nama>-info.txt" di sebelah .p12 (hasil Ekspor), pakai sandi dan alias di dalamnya tanpa bertanya. */
    private static void coba(final Activity a, final String arg, final File f) {
        String sandi = "", alias = "";
        try {
            File info = new File(f.getParentFile(), f.getName().replaceAll("(?i)\\.(p12|pfx)$", "") + "-info.txt");
            if (info.isFile()) {
                for (String l : Ks.readAll(info).split("\n")) {
                    if (l.startsWith("Sandi: ")) sandi = l.substring(7).trim();
                    else if (l.startsWith("Alias: ")) alias = l.substring(7).trim();
                }
            }
        } catch (Exception e) { }
        if (sandi.isEmpty()) { tanyaSandi(a, arg, f, ""); return; }
        final String sd = sandi, al = alias;
        say("Berkas info ditemukan, sandi dibaca otomatis");
        new Thread(() -> {
            final Ks.Impor h = Ks.imporFile(f, sd, al, "");
            MainActivity.H.post(() -> { if (h.ok || h.banyakAlias != null) hasilImpor(a, arg, f, sd, h); else tanyaSandi(a, arg, f, ""); });
        }).start();
    }

    private static void tanyaSandi(final Activity a, final String arg, final File f, final String alias) {
        final EditText et = new EditText(a);
        et.setHint("Sandi berkas");
        // Dibuat terlihat supaya pengguna pembaca layar bisa memeriksa yang diketik.
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        et.setSingleLine(true);
        et.setContentDescription("Sandi berkas " + f.getName());
        new AlertDialog.Builder(a)
            .setTitle("Sandi untuk " + f.getName())
            .setView(et)
            .setPositiveButton("Impor", (d, w) -> {
                final String sandi = et.getText().toString();
                say("Mengimpor, mohon tunggu");
                new Thread(() -> {
                    final Ks.Impor h = Ks.imporFile(f, sandi, alias, "");
                    MainActivity.H.post(() -> hasilImpor(a, arg, f, sandi, h));
                }).start();
            })
            .setNegativeButton("Kembali", (d, w) -> imporBerkas(a, arg))
            .show();
    }

    private static void hasilImpor(final Activity a, final String arg, final File f, final String sandi, final Ks.Impor h) {
        if (h.banyakAlias != null) {
            final String[] al = h.banyakAlias.toArray(new String[0]);
            new AlertDialog.Builder(a)
                .setTitle("Pilih alias")
                .setItems(al, (d, i) -> {
                    new Thread(() -> {
                        final Ks.Impor h2 = Ks.imporFile(f, sandi, al[i], "");
                        MainActivity.H.post(() -> hasilImpor(a, arg, f, sandi, h2));
                    }).start();
                })
                .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
                .show();
            return;
        }
        MainActivity.add(h.pesan);
        if (h.ok) {
            say("Tanda tangan " + h.nama + " berhasil diimpor");
            Ks.setAktif(h.nama);
            if (arg != null) mulaiBangun(a, arg); else langkah1(a, null);
            return;
        }
        new AlertDialog.Builder(a)
            .setTitle("Impor gagal")
            .setMessage(h.pesan)
            .setPositiveButton("Coba lagi", (d, w) -> tanyaSandi(a, arg, f, ""))
            .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
            .show();
    }

    // ---------------------------------------------------------------- kelola

    private static void kelolaDaftar(final Activity a, final String arg) {
        final List<String> pribadi = Ks.daftar();
        if (pribadi.isEmpty()) { langkah1(a, arg); return; }
        new AlertDialog.Builder(a)
            .setTitle("Kelola: pilih tanda tangan")
            .setItems(pribadi.toArray(new String[0]), (d, i) -> kelolaAksi(a, arg, pribadi.get(i)))
            .setNegativeButton("Kembali", (d, w) -> langkah1(a, arg))
            .show();
    }

    private static void kelolaAksi(final Activity a, final String arg, final String nm) {
        new AlertDialog.Builder(a)
            .setTitle(nm)
            .setItems(new String[]{"Ekspor cadangan ke folder Download", "Hapus tanda tangan ini"}, (d, i) -> {
                if (i == 0) { Ks.ekspor(nm); langkah1(a, arg); }
                else konfirmasiHapus(a, arg, nm);
            })
            .setNegativeButton("Kembali", (d, w) -> kelolaDaftar(a, arg))
            .show();
    }

    private static void konfirmasiHapus(final Activity a, final String arg, final String nm) {
        new AlertDialog.Builder(a)
            .setTitle("Hapus tanda tangan " + nm + "?")
            .setMessage("Aplikasi yang sudah dipasang dengan tanda tangan ini tidak bisa diperbarui bila kuncinya hilang. "
                + "Ekspor cadangan dulu bila masih perlu.")
            .setPositiveButton("Hapus", (d, w) -> { Ks.hapus(nm); langkah1(a, arg); })
            .setNegativeButton("Batal", (d, w) -> kelolaAksi(a, arg, nm))
            .show();
    }
}
