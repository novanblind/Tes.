package com.novan.audiolabnovan.info

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.novan.audiolabnovan.Converter

/**
 * Tahap 82: Info Media Audio. Pilih satu berkas, lalu tampil nama, ukuran, format, durasi,
 * codec, kanal, laju sampel, bitrate, dan tag (judul, artis, album, tahun, genre).
 */
class InfoMediaActivity : AppCompatActivity() {

    private lateinit var hasil: TextView
    private lateinit var salin: Button
    private var teks = ""

    private val pilih = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) baca(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = intent.getStringExtra(com.novan.audiolabnovan.video.VideoFitur.EXTRA_JUDUL) ?: getString(com.novan.audiolabnovan.R.string.judul_info_media)

        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val judul = TextView(this).apply {
            text = title
            textSize = 24f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        akar.addView(judul, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val tombolPilih = Button(this).apply {
            text = "Pilih berkas audio atau video"
            setOnClickListener { pilih.launch(arrayOf("audio/*", "video/*")) }
        }
        akar.addView(tombolPilih, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), 0, dp(16), dp(8))
        })

        salin = Button(this).apply {
            text = "Salin info"
            isEnabled = false
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("info", teks))
                Toast.makeText(this@InfoMediaActivity, "Info disalin.", Toast.LENGTH_SHORT).show()
            }
        }
        akar.addView(salin, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), 0, dp(16), dp(8))
        })

        hasil = TextView(this).apply {
            text = "Belum ada berkas dipilih."
            textSize = 16f
            setTextIsSelectable(true)
            setPadding(dp(20), dp(8), dp(20), dp(16))
        }
        akar.addView(ScrollView(this).apply { addView(hasil) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        ViewCompat.setOnApplyWindowInsetsListener(akar) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        setContentView(akar)
        // Tahap 86: berkas dari menu Bagikan langsung dibaca.
        val kiriman = intent.getStringExtra(com.novan.audiolabnovan.video.VideoFitur.EXTRA_URI)
        if (kiriman != null) baca(Uri.parse(kiriman))
    }

    private fun baca(uri: Uri) {
        hasil.text = "Membaca info..."
        salin.isEnabled = false
        Thread {
            val sb = StringBuilder()
            var nama = "berkas"
            var ukuran = -1L
            try {
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val z = c.getColumnIndex(OpenableColumns.SIZE)
                        if (n >= 0) nama = c.getString(n) ?: nama
                        if (z >= 0 && !c.isNull(z)) ukuran = c.getLong(z)
                    }
                }
            } catch (e: Throwable) { }
            sb.append("Nama: ").append(nama).append('\n')
            if (ukuran >= 0) sb.append("Ukuran: ").append(ukuranTeks(ukuran)).append('\n')
            sb.append("Teknis: ").append(Converter.probeInfo(this, uri)).append('\n')
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                fun tag(label: String, kode: Int) {
                    val v = r.extractMetadata(kode)
                    if (!v.isNullOrBlank()) sb.append(label).append(": ").append(v.trim()).append('\n')
                }
                tag("Judul", MediaMetadataRetriever.METADATA_KEY_TITLE)
                tag("Artis", MediaMetadataRetriever.METADATA_KEY_ARTIST)
                tag("Album", MediaMetadataRetriever.METADATA_KEY_ALBUM)
                tag("Tahun", MediaMetadataRetriever.METADATA_KEY_YEAR)
                tag("Genre", MediaMetadataRetriever.METADATA_KEY_GENRE)
                tag("Nomor lagu", MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)
                r.release()
            } catch (e: Throwable) { }
            val akhir = sb.toString().trim()
            runOnUiThread {
                teks = akhir
                hasil.text = akhir
                salin.isEnabled = true
                hasil.announceForAccessibility("Info siap.")
            }
        }.start()
    }

    private fun ukuranTeks(b: Long): String = when {
        b >= 1024L * 1024 -> String.format(java.util.Locale("id"), "%.2f MB", b / 1048576.0)
        b >= 1024 -> String.format(java.util.Locale("id"), "%.1f KB", b / 1024.0)
        else -> "$b byte"
    }
}
