package com.makroku.automation.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.AppJson
import com.makroku.automation.model.Catalog
import com.makroku.automation.model.LogEntry
import com.makroku.automation.model.MacroAction
import com.makroku.automation.model.MacroConstraint
import com.makroku.automation.model.MacroTrigger
import com.makroku.automation.model.Macro
import kotlinx.serialization.json.jsonObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val timeFmt = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SubScreen(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } },
                actions = actions,
            )
        },
        content = content,
    )
}

// ───────────────────────── Beranda ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(repo: MacroRepository, engine: MacroEngine, nav: (Screen) -> Unit) {
    val macros by repo.macros.collectAsState()
    val appOn by repo.appEnabled.collectAsState()
    val ctx = LocalContext.current
    val view = LocalView.current
    fun jalankan(m: Macro) {
        if (engine.runNow(m.id)) view.announceForAccessibility("${m.name} dijalankan")
        else view.announceForAccessibility("MakroKu sedang tidak aktif. Aktifkan dulu di bagian atas layar.")
    }
    var menu by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Macro?>(null) }
    var menuMacro by remember { mutableStateOf<Macro?>(null) }
    var renameMacro by remember { mutableStateOf<Macro?>(null) }
    var moveMacro by remember { mutableStateOf<Macro?>(null) }
    var newCatMacro by remember { mutableStateOf<Macro?>(null) }
    var infoMacro by remember { mutableStateOf<Macro?>(null) }
    var catMenu by remember { mutableStateOf<String?>(null) }
    var catRename by remember { mutableStateOf<String?>(null) }
    val collapsed = remember { mutableStateListOf<String>() }
    val groups = macros.groupBy { it.category.ifBlank { "Umum" } }.toList().sortedBy { it.first.lowercase() }
    val showHeaders = groups.size > 1

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MakroKu") },
                actions = {
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu lainnya") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Templat") }, onClick = { menu = false; nav(Screen.Templates) })
                            DropdownMenuItem(text = { Text("Blok aksi") }, onClick = { menu = false; nav(Screen.Blocks) })
                            DropdownMenuItem(text = { Text("Variabel") }, onClick = { menu = false; nav(Screen.Variables) })
                            DropdownMenuItem(text = { Text("Log") }, onClick = { menu = false; nav(Screen.Logs) })
                            DropdownMenuItem(text = { Text("Pengaturan & izin") }, onClick = { menu = false; nav(Screen.Settings) })
                            DropdownMenuItem(text = { Text("Izin via ADB") }, onClick = { menu = false; nav(Screen.Adb) })
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { nav(Screen.Editor(null)) }) { Icon(Icons.Default.Add, "Makro baru") }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
        MasterSwitch(appOn) {
            repo.setAppEnabled(it)
            com.makroku.automation.service.applyAppEnabled(ctx, it)
            view.announceForAccessibility(if (it) "MakroKu aktif" else "MakroKu tidak aktif")
        }
        if (macros.isEmpty()) {
            Column(Modifier.weight(1f).padding(24.dp).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Belum ada makro", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Ketuk + untuk membuat makro, atau pilih dari Templat.")
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(onClick = { nav(Screen.Templates) }) { Text("Lihat templat") }
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                groups.forEach { (cat, list) ->
                    if (showHeaders) {
                        item(key = "cat_$cat") {
                            CategoryHeader(
                                name = cat, count = list.size, collapsed = cat in collapsed,
                                onToggle = { if (cat in collapsed) collapsed.remove(cat) else collapsed.add(cat) },
                                onMenu = { catMenu = cat },
                            )
                        }
                    }
                    if (!showHeaders || cat !in collapsed) {
                        items(list, key = { it.id }) { m ->
                            MacroCard(
                                m = m, repo = repo,
                                onOpen = { nav(Screen.Editor(m.id)) },
                                onRun = { jalankan(m) },
                                onMenu = { menuMacro = m },
                                onPin = { pinShortcut(ctx, m) },
                                onDelete = { toDelete = m },
                            )
                        }
                    }
                }
            }
        }
        }
    }

    menuMacro?.let { m ->
        val entries = buildList {
            add(MenuEntry("Jalankan sekarang, abaikan batasan") { jalankan(m) })
            add(MenuEntry("Ubah makro") { nav(Screen.Editor(m.id)) })
            add(MenuEntry(if (m.enabled) "Matikan makro" else "Nyalakan makro") {
                repo.setEnabled(m.id, !m.enabled)
                view.announceForAccessibility(m.name + if (!m.enabled) " aktif" else " nonaktif")
            })
            add(MenuEntry("Ganti nama") { renameMacro = m })
            add(MenuEntry("Pindahkan ke kategori lain") { moveMacro = m })
            add(MenuEntry("Gandakan makro") {
                repo.duplicate(m.id)
                view.announceForAccessibility("${m.name} digandakan. Salinan dalam keadaan nonaktif.")
            })
            add(MenuEntry("Bagikan makro sebagai berkas (WhatsApp dll.)") { repo.exportOne(m.id)?.let { shareMacroFile(ctx, m.name, it) } })
            add(MenuEntry("Bagikan makro sebagai JSON") { repo.exportOne(m.id)?.let { shareText(ctx, m.name, it) } })
            add(MenuEntry("Salin JSON makro ke papan klip") { repo.exportOne(m.id)?.let { copyText(ctx, "JSON makro", it) } })
            add(MenuEntry("Buat pintasan di layar utama") { pinShortcut(ctx, m) })
            add(MenuEntry("Lihat info lengkap makro") { infoMacro = m })
            add(MenuEntry("Hapus makro", true) { toDelete = m })
        }
        MenuDialog(m.name, entries) { menuMacro = null }
    }

    renameMacro?.let { m ->
        TextInputDialog("Ganti nama makro", "Nama makro", m.name, onDismiss = { renameMacro = null }) {
            repo.rename(m.id, it); renameMacro = null
            view.announceForAccessibility("Nama diganti menjadi $it")
        }
    }

    moveMacro?.let { m ->
        val cats = groups.map { it.first }
        PickerDialog(
            title = "Pindahkan ${m.name} ke kategori",
            labels = cats + "Kategori baru",
            searchable = false,
            onPick = { i ->
                moveMacro = null
                if (i < cats.size) {
                    repo.setCategory(m.id, cats[i])
                    view.announceForAccessibility("${m.name} dipindah ke ${cats[i]}")
                } else newCatMacro = m
            },
            onDismiss = { moveMacro = null },
        )
    }

    newCatMacro?.let { m ->
        TextInputDialog("Kategori baru", "Nama kategori", "", onDismiss = { newCatMacro = null }) {
            repo.setCategory(m.id, it); newCatMacro = null
            view.announceForAccessibility("${m.name} dipindah ke $it")
        }
    }

    infoMacro?.let { m -> InfoDialog("Info makro", infoLines(m)) { infoMacro = null } }

    catMenu?.let { cat ->
        val entries = buildList {
            add(MenuEntry(if (cat in collapsed) "Buka kategori" else "Tutup kategori") {
                if (cat in collapsed) collapsed.remove(cat) else collapsed.add(cat)
            })
            add(MenuEntry("Nyalakan semua makro di kategori ini") {
                repo.setCategoryEnabled(cat, true); view.announceForAccessibility("Semua makro di $cat dinyalakan")
            })
            add(MenuEntry("Matikan semua makro di kategori ini") {
                repo.setCategoryEnabled(cat, false); view.announceForAccessibility("Semua makro di $cat dimatikan")
            })
            add(MenuEntry("Ganti nama kategori") { catRename = cat })
        }
        MenuDialog("Kategori $cat", entries) { catMenu = null }
    }

    catRename?.let { cat ->
        TextInputDialog("Ganti nama kategori", "Nama kategori", cat, onDismiss = { catRename = null }) {
            repo.renameCategory(cat, it); catRename = null
            view.announceForAccessibility("Kategori diganti menjadi $it")
        }
    }

    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Hapus makro?") },
            text = { Text("\"${m.name}\" akan dihapus permanen.") },
            confirmButton = { TextButton(onClick = { repo.delete(m.id); toDelete = null; view.announceForAccessibility("${m.name} dihapus") }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Batal") } },
        )
    }
}

/** Ringkasan lengkap makro: tiap baris satu perhentian pembaca layar. */
internal fun infoLines(m: Macro): List<String> = buildList {
    add("Nama: ${m.name}")
    add("Kategori: ${m.category}")
    if (m.description.isNotBlank()) add("Deskripsi: ${m.description}")
    add("Status: " + if (m.enabled) "aktif" else "nonaktif")
    add(if (m.runCount == 0) "Belum pernah dijalankan" else "Dijalankan ${m.runCount} kali, terakhir ${timeFmt.format(Date(m.lastRun))}")
    add(if (m.constraintAny) "Batasan: salah satu cukup" else "Batasan: semua harus terpenuhi")
    m.triggers.forEachIndexed { i, t ->
        add("Pemicu ${i + 1}: " + Catalog.describe(AppJson.encodeToJsonElement(MacroTrigger.serializer(), t).jsonObject))
    }
    m.constraints.forEachIndexed { i, c ->
        add("Batasan ${i + 1}: " + Catalog.describe(AppJson.encodeToJsonElement(MacroConstraint.serializer(), c).jsonObject))
    }
    m.actions.forEachIndexed { i, a ->
        add("Aksi ${i + 1}: " + Catalog.describe(AppJson.encodeToJsonElement(MacroAction.serializer(), a).jsonObject))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CategoryHeader(name: String, count: Int, collapsed: Boolean, onToggle: () -> Unit, onMenu: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .combinedClickable(
                onClickLabel = if (collapsed) "Buka kategori" else "Tutup kategori",
                onLongClickLabel = "Buka menu kategori",
                onLongClick = onMenu,
            ) { onToggle() }
            .semantics(mergeDescendants = true) {
                heading()
                contentDescription = "Kategori $name, $count makro, " + if (collapsed) "tertutup" else "terbuka"
                customActions = listOf(CustomAccessibilityAction("Buka menu kategori") { onMenu(); true })
            }
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(name, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
        Text(if (collapsed) "$count makro, tertutup" else "$count makro", style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MacroCard(
    m: Macro,
    repo: MacroRepository,
    onOpen: () -> Unit,
    onRun: () -> Unit,
    onMenu: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit,
) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .combinedClickable(
                    onClickLabel = "Ubah",
                    onLongClickLabel = "Buka menu",
                    onLongClick = onMenu,
                ) { onOpen() }
                .semantics {
                    stateDescription = if (m.enabled) "Aktif" else "Nonaktif"
                    customActions = listOf(
                        CustomAccessibilityAction("Buka menu") { onMenu(); true },
                        CustomAccessibilityAction(if (m.enabled) "Matikan makro" else "Nyalakan makro") {
                            val now = !m.enabled
                            repo.setEnabled(m.id, now)
                            Toast.makeText(ctx, m.name + if (now) " aktif" else " nonaktif", Toast.LENGTH_SHORT).show()
                            true
                        },
                        CustomAccessibilityAction("Jalankan") { onRun(); true },
                        CustomAccessibilityAction("Pintasan") { onPin(); true },
                        CustomAccessibilityAction("Hapus") { onDelete(); true },
                    )
                }
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name, style = MaterialTheme.typography.titleMedium)
                    Text(m.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Switch(m.enabled, { repo.setEnabled(m.id, it) }, modifier = Modifier.clearAndSetSemantics {})
            }
            if (m.description.isNotBlank()) Text(m.description, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Text(
                "${m.triggers.size} pemicu • ${m.constraints.size} batasan • ${m.actions.size} aksi • " +
                    if (m.runCount == 0) "belum pernah jalan" else "jalan ${m.runCount}× (terakhir ${timeFmt.format(Date(m.lastRun))})",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(Modifier.clearAndSetSemantics {}) {
                IconButton(onClick = onRun) { Icon(Icons.Default.PlayArrow, "Jalankan") }
                IconButton(onClick = onOpen) { Icon(Icons.Default.Edit, "Ubah") }
                IconButton(onClick = onMenu) { Icon(Icons.Default.MoreVert, "Menu") }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Hapus") }
            }
        }
    }
}

@Composable
private fun MasterSwitch(on: Boolean, onChange: (Boolean) -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
        ),
    ) {
        Row(
            Modifier.toggleable(value = on, role = Role.Switch, onValueChange = onChange).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("MakroKu: " + if (on) "Aktif" else "Tidak aktif", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (on) "Semua makro yang menyala berjalan." else "Semua makro dan layanan latar belakang dimatikan sampai diaktifkan lagi.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(on, null)
        }
    }
}

private fun pinShortcut(ctx: Context, m: Macro) {
    if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
        Toast.makeText(ctx, "Launcher tidak mendukung pintasan", Toast.LENGTH_SHORT).show()
        return
    }
    val intent = Intent(ctx, RunMacroActivity::class.java)
        .setAction("com.makroku.automation.RUN_MACRO")
        .putExtra("macroId", m.id)
    val info = ShortcutInfoCompat.Builder(ctx, "macro_${m.id}")
        .setShortLabel(m.name.take(20))
        .setIcon(IconCompat.createWithResource(ctx, android.R.drawable.ic_media_play))
        .setIntent(intent)
        .build()
    ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
}

// ───────────────────────── Log ─────────────────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LogsScreen(repo: MacroRepository, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val logs by repo.logs.collectAsState()
    var menuLog by remember { mutableStateOf<LogEntry?>(null) }
    fun baris(l: LogEntry) = "${timeFmt.format(Date(l.time))} ${l.macro}: ${l.message}"
    SubScreen("Log", onBack, actions = { TextButton(onClick = { repo.clearLogs(); view.announceForAccessibility("Log dibersihkan") }) { Text("Bersihkan") } }) { pad ->
        if (logs.isEmpty()) {
            Text("Belum ada aktivitas.", Modifier.padding(pad).padding(16.dp))
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(logs) { l ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .combinedClickable(onClickLabel = "Buka menu", onLongClickLabel = "Buka menu", onLongClick = { menuLog = l }) { menuLog = l }
                            .semantics(mergeDescendants = true) {},
                    ) {
                        Text("${timeFmt.format(Date(l.time))} • ${l.macro}", style = MaterialTheme.typography.labelMedium)
                        Text(
                            l.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (l.ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                        )
                        HorizontalDivider(Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
    menuLog?.let { l ->
        MenuDialog(
            "Log ${l.macro}",
            listOf(
                MenuEntry("Salin baris ini") { copyText(ctx, "Baris log", baris(l)) },
                MenuEntry("Salin semua log") { copyText(ctx, "Semua log", logs.joinToString("\n") { baris(it) }) },
                MenuEntry("Bagikan semua log") { shareText(ctx, "Log MakroKu", logs.joinToString("\n") { baris(it) }) },
                MenuEntry("Hapus semua log", true) { repo.clearLogs(); view.announceForAccessibility("Log dibersihkan") },
            ),
        ) { menuLog = null }
    }
}

// ───────────────────────── Variabel ─────────────────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VariablesScreen(repo: MacroRepository, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val vars by repo.variables.collectAsState()
    var editing by remember { mutableStateOf<Pair<String, String>?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var menuVar by remember { mutableStateOf<Pair<String, String>?>(null) }

    SubScreen("Variabel", onBack, actions = {
        TextButton(onClick = { isNew = true; editing = "" to "" }) { Text("Tambah") }
    }) { pad ->
        if (vars.isEmpty()) {
            Text("Belum ada variabel. Buat lewat aksi 'Atur variabel' atau tombol Tambah.", Modifier.padding(pad).padding(16.dp))
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vars.toList().sortedBy { it.first }) { (k, v) ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(
                                Modifier
                                    .weight(1f)
                                    .combinedClickable(
                                        onClickLabel = "Ubah",
                                        onLongClickLabel = "Buka menu",
                                        onLongClick = { menuVar = k to v },
                                    ) { isNew = false; editing = k to v }
                                    .semantics(mergeDescendants = true) {
                                        customActions = listOf(CustomAccessibilityAction("Buka menu") { menuVar = k to v; true })
                                    },
                            ) {
                                Text(k, style = MaterialTheme.typography.titleSmall)
                                Text(v, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                            IconButton(onClick = { isNew = false; editing = k to v }) { Icon(Icons.Default.Edit, "Ubah variabel $k") }
                            IconButton(onClick = { repo.deleteVariable(k); view.announceForAccessibility("Variabel $k dihapus") }) { Icon(Icons.Default.Delete, "Hapus variabel $k") }
                        }
                    }
                }
            }
        }
    }

    menuVar?.let { (k, v) ->
        MenuDialog(
            "Variabel $k",
            listOf(
                MenuEntry("Ubah nilai") { isNew = false; editing = k to v },
                MenuEntry("Salin nama") { copyText(ctx, "Nama variabel", k) },
                MenuEntry("Salin nilai") { copyText(ctx, "Nilai variabel", v) },
                MenuEntry("Salin penanda untuk disisipkan ke teks") { copyText(ctx, "Penanda variabel", "{var:$k}") },
                MenuEntry("Hapus variabel", true) { repo.deleteVariable(k); view.announceForAccessibility("Variabel $k dihapus") },
            ),
        ) { menuVar = null }
    }

    editing?.let { (k0, v0) ->
        var k by remember { mutableStateOf(k0) }
        var v by remember { mutableStateOf(v0) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(if (isNew) "Variabel baru" else "Ubah variabel") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(k, { k = it }, label = { Text("Nama") }, enabled = isNew, singleLine = true)
                    OutlinedTextField(v, { v = it }, label = { Text("Nilai") })
                }
            },
            confirmButton = {
                TextButton(onClick = { if (k.isNotBlank()) { repo.setVariable(k.trim(), v); view.announceForAccessibility("Variabel disimpan") }; editing = null }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Batal") } },
        )
    }
}

// ───────────────────────── Templat ─────────────────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TemplatesScreen(repo: MacroRepository, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var menuT by remember { mutableStateOf<Macro?>(null) }
    var infoT by remember { mutableStateOf<Macro?>(null) }
    fun tambah(t: Macro) {
        repo.save(t.copy(id = 0))
        Toast.makeText(ctx, "Ditambahkan: ${t.name}", Toast.LENGTH_SHORT).show()
    }
    SubScreen("Templat makro", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Catalog.templates) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClickLabel = "Lihat isi templat",
                                    onLongClickLabel = "Buka menu",
                                    onLongClick = { menuT = t },
                                ) { infoT = t }
                                .semantics(mergeDescendants = true) {
                                    customActions = listOf(CustomAccessibilityAction("Buka menu") { menuT = t; true })
                                },
                        ) {
                            Text(t.name, style = MaterialTheme.typography.titleMedium)
                            Text(t.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            if (t.description.isNotBlank()) Text(t.description, style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(Modifier.height(6.dp))
                        FilledTonalButton(modifier = Modifier.semantics { contentDescription = "Tambahkan templat ${t.name}" }, onClick = { tambah(t) }) { Text("Tambahkan") }
                    }
                }
            }
        }
    }
    menuT?.let { t ->
        MenuDialog(
            t.name,
            listOf(
                MenuEntry("Tambahkan ke makro saya") { tambah(t) },
                MenuEntry("Lihat isi templat") { infoT = t },
            ),
        ) { menuT = null }
    }
    infoT?.let { t -> InfoDialog("Isi templat", infoLines(t)) { infoT = null } }
}

// ───────────────────────── Pengaturan ─────────────────────────
@Composable
fun SettingsScreen(
    repo: MacroRepository,
    onBack: () -> Unit,
    onRequestPermissions: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onImport: (com.makroku.automation.data.ImportResult) -> Unit = {},
) {
    val ctx = LocalContext.current
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(repo.exportBackup().toByteArray()) }
            Toast.makeText(ctx, "Cadangan diekspor", Toast.LENGTH_SHORT).show()
        }.onFailure { Toast.makeText(ctx, "Gagal ekspor: ${it.message}", Toast.LENGTH_LONG).show() }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
            onImport(repo.parseImportFull(text))
        }.onFailure { Toast.makeText(ctx, "Gagal impor: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    fun open(i: Intent) {
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(ctx, "Tidak dapat membuka pengaturan", Toast.LENGTH_SHORT).show() }
    }
    val pkgUri = Uri.parse("package:${ctx.packageName}")

    SubScreen("Pengaturan & izin", onBack) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Layanan (sama dengan saklar utama di Beranda)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStartService) { Text("Mulai") }
                OutlinedButton(onClick = onStopService) { Text("Hentikan") }
            }

            HorizontalDivider()
            Text("Izin", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
            PermRow("Izin runtime (SMS, telepon, notifikasi, Bluetooth)", "Beri izin") { onRequestPermissions() }
            PermRow("Akses notifikasi — untuk pemicu Notifikasi", "Buka") {
                open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            PermRow("Aksesibilitas — untuk pemicu Aplikasi dibuka", "Buka") {
                open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            PermRow("Jangan ganggu — untuk aksi DND & mode senyap", "Buka") {
                open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            PermRow("Ubah pengaturan sistem — untuk kecerahan", "Buka") {
                open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri))
            }
            PermRow("Tampil di atas aplikasi lain — agar bisa membuka aplikasi dari latar belakang", "Buka") {
                open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
            }
            if (Build.VERSION.SDK_INT >= 31) {
                PermRow("Alarm tepat waktu — agar jadwal akurat", "Buka") {
                    open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri))
                }
            }
            PermRow("Abaikan optimasi baterai — agar layanan tidak dimatikan sistem", "Buka") {
                open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
            }

            HorizontalDivider()
            Text("Cadangan", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exporter.launch("makroku-backup.json") }) { Text("Ekspor cadangan") }
                OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Impor berkas makro") }
            }
            Button(onClick = { shareMacroFile(ctx, "makroku-cadangan", repo.exportBackup()) }) { Text("Bagikan cadangan lengkap sebagai berkas") }
            Text("Cadangan berisi semua makro dan variabel. Impor berkas menerima cadangan MakroKu (.makroku, .json) dan berkas makro MacroDroid (.macro); sebelum diterapkan, daftar makro dan bagian yang tidak bisa dibawa ditampilkan dulu. Berkas bisa dikirim ke WhatsApp atau ke mana saja; di HP penerima, buka berkasnya dan pilih MakroKu, lalu ketuk Terapkan.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PermRow(text: String, button: String, onClick: () -> Unit) {
    Row(Modifier.semantics(mergeDescendants = true) {}, verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(8.dp))
        FilledTonalButton(onClick = onClick) { Text(button) }
    }
}
