package id.ytplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Catatan unduhan (sedang berjalan, selesai, gagal) untuk layar "Unduhan".
 * Disimpan di SharedPreferences supaya tetap ada setelah aplikasi ditutup.
 * Kemajuan (persen) hanya di memori; disimpan hanya saat status berubah.
 */
object DownloadLog {
    const val QUEUED = 0
    const val RUNNING = 1
    const val DONE = 2
    const val FAILED = 3
    const val CANCELLED = 4

    private const val PREFS = "dllog"
    private const val KEY = "entries"
    private const val MAX_ENTRIES = 100

    data class Entry(
        val id: Long,
        val url: String,
        var title: String,
        val key: String,
        val playlist: Boolean,
        var status: Int,
        var text: String,
        var pct: Int,
        var uri: String?,
        var mime: String?,
        var time: Long,
        var retry: Boolean
    )

    private val lock = Any()
    private val items = ArrayList<Entry>()
    private var loaded = false
    private var appCtx: Context? = null
    private var lastId = 0L

    private fun ensure(ctx: Context) {
        synchronized(lock) {
            if (loaded) return
            appCtx = ctx.applicationContext
            loaded = true
            try {
                val raw = appCtx!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
                if (!raw.isNullOrEmpty()) {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        var st = o.optInt("st", FAILED)
                        var text = o.optString("tx")
                        // Proses baru: unduhan yang dulu berjalan sudah pasti terhenti.
                        if (st == QUEUED || st == RUNNING) {
                            st = FAILED
                            text = "Terhenti karena aplikasi tertutup."
                        }
                        items += Entry(
                            id = o.optLong("id"),
                            url = o.optString("url"),
                            title = o.optString("ti"),
                            key = o.optString("key"),
                            playlist = o.optBoolean("pl"),
                            status = st,
                            text = text,
                            pct = 0,
                            uri = if (o.has("uri")) o.optString("uri") else null,
                            mime = if (o.has("mime")) o.optString("mime") else null,
                            time = o.optLong("tm"),
                            retry = o.optBoolean("rt", true)
                        )
                        lastId = maxOf(lastId, o.optLong("id"))
                    }
                }
            } catch (_: Exception) {
                items.clear()
            }
        }
    }

    private fun save() {
        val c = appCtx ?: return
        try {
            val arr = JSONArray()
            for (e in items) {
                val o = JSONObject()
                    .put("id", e.id).put("url", e.url).put("ti", e.title).put("key", e.key)
                    .put("pl", e.playlist).put("st", e.status).put("tx", e.text)
                    .put("tm", e.time).put("rt", e.retry)
                e.uri?.let { o.put("uri", it) }
                e.mime?.let { o.put("mime", it) }
                arr.put(o)
            }
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
        } catch (_: Exception) {
        }
    }

    /** Daftar terbaru dulu (salinan, aman dibaca dari thread mana pun). */
    fun list(ctx: Context): List<Entry> {
        ensure(ctx)
        synchronized(lock) { return items.map { it.copy() }.sortedByDescending { it.id } }
    }

    fun enqueue(ctx: Context, url: String, title: String, key: String, playlist: Boolean): Long {
        ensure(ctx)
        synchronized(lock) {
            lastId = maxOf(lastId + 1, System.currentTimeMillis())
            items += Entry(
                lastId, url, title, key, playlist, QUEUED, "Menunggu giliran", 0, null, null,
                System.currentTimeMillis(), true
            )
            // Batasi jumlah catatan: buang yang tertua dan sudah selesai/gagal.
            while (items.size > MAX_ENTRIES) {
                val old = items.filter { it.status != QUEUED && it.status != RUNNING }.minByOrNull { it.id } ?: break
                items.remove(old)
            }
            save()
            return lastId
        }
    }

    fun running(id: Long) {
        synchronized(lock) {
            val e = items.firstOrNull { it.id == id } ?: return
            e.status = RUNNING
            e.text = "Menyiapkan unduhan…"
            e.pct = 0
            save()
        }
    }

    fun progress(id: Long, text: String, pct: Int) {
        synchronized(lock) {
            val e = items.firstOrNull { it.id == id } ?: return
            if (e.status != RUNNING && e.status != QUEUED) return
            e.status = RUNNING
            e.text = text
            e.pct = pct.coerceIn(0, 100)
        }
    }

    /** Hasil akhir; hanya berlaku bila catatan masih menunggu/berjalan (hasil pertama yang dipakai). */
    fun finish(
        id: Long, status: Int, text: String, uri: String? = null, mime: String? = null,
        retry: Boolean = true, title: String? = null
    ) {
        synchronized(lock) {
            val e = items.firstOrNull { it.id == id } ?: return
            if (e.status != QUEUED && e.status != RUNNING) return
            e.status = status
            e.text = text
            e.uri = uri
            e.mime = mime
            e.retry = retry
            e.pct = if (status == DONE) 100 else e.pct
            e.time = System.currentTimeMillis()
            if (!title.isNullOrBlank()) e.title = title
            save()
        }
    }

    /** Jaring pengaman setelah pekerjaan selesai: bila masih "berjalan", berarti terhenti tanpa hasil. */
    fun settle(id: Long) = finish(id, FAILED, "Unduhan terhenti sebelum selesai.")

    fun remove(ctx: Context, id: Long) {
        ensure(ctx)
        synchronized(lock) {
            if (items.removeAll { it.id == id }) save()
        }
    }

    /** Hapus seluruh riwayat (selesai, gagal, dibatalkan); yang masih menunggu/berjalan tetap. */
    fun clearAll(ctx: Context) {
        ensure(ctx)
        synchronized(lock) {
            if (items.removeAll { it.status != QUEUED && it.status != RUNNING }) save()
        }
    }

    /** Hapus semua catatan yang sudah selesai atau dibatalkan (yang gagal dan yang berjalan dipertahankan). */
    fun clearFinished(ctx: Context) {
        ensure(ctx)
        synchronized(lock) {
            if (items.removeAll { it.status == DONE || it.status == CANCELLED }) save()
        }
    }
}
