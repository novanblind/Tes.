package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ComponentName
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType

/**
 * Halaman pilihan untuk satu tautan video.
 * - YouTube: putar (video / audio saja) atau unduh (M4A, MP3, MP4).
 * - Playlist YouTube: unduh semua video (M4A, MP3, MP4) dengan satu pilihan kualitas.
 * - TikTok: unduh (M4A, MP3, MP4 tanpa watermark).
 * - Facebook: unduh video publik (M4A, MP3, MP4).
 * Dibuka dari menu Bagikan aplikasi asli, atau otomatis dari MainActivity saat ada tautan di clipboard.
 */
class LinkActivity : Activity() {

    companion object {
        const val EXTRA_LINK = "link"
        private val FOLDER_BAD = Regex("[\\\\/:*?\"<>|\\p{Cntrl}]")
    }

    private lateinit var titleTv: TextView
    private lateinit var uploaderTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var btnPlayVideo: Button
    private lateinit var btnPlayAudio: Button
    private lateinit var btnM4a: Button
    private lateinit var btnMp3: Button
    private lateinit var btnMp4: Button
    private lateinit var btnPlaylist: Button
    private lateinit var btnRetry: Button

    private var url = ""
    private var isTikTok = false
    private var isFacebook = false
    private var isPlaylist = false
    private var playlistUrl: String? = null       // tautan playlist (bila ada)
    private var plName = ""
    private var plCount = -1L
    private var info: StreamInfo? = null          // YouTube
    private var tt: TikTokResolver.Info? = null   // TikTok
    /** Sambungan ke pemutar yang disiapkan sejak halaman dibuka, supaya tombol Putar langsung bunyi. */
    private var warm: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_link)

        titleTv = findViewById(R.id.linkTitle)
        uploaderTv = findViewById(R.id.linkUploader)
        statusTv = findViewById(R.id.linkStatus)
        btnPlayVideo = findViewById(R.id.btnPlayVideo)
        btnPlayAudio = findViewById(R.id.btnPlayAudio)
        btnM4a = findViewById(R.id.btnM4a)
        btnMp3 = findViewById(R.id.btnMp3)
        btnMp4 = findViewById(R.id.btnMp4)
        btnPlaylist = findViewById(R.id.btnPlaylist)
        btnRetry = findViewById(R.id.btnRetry)
        ViewCompat.setAccessibilityHeading(titleTv, true)

        btnPlayVideo.setOnClickListener { play(false) }
        btnPlayAudio.setOnClickListener { play(true) }
        btnM4a.setOnClickListener { chooseQuality(DownloadOptions.GROUP_M4A, "M4A (audio asli)") }
        btnMp3.setOnClickListener { chooseQuality(DownloadOptions.GROUP_MP3, "MP3 (audio, dikonversi)") }
        btnMp4.setOnClickListener { chooseQuality(DownloadOptions.GROUP_MP4, "MP4 (video)") }
        btnPlaylist.setOnClickListener { switchToPlaylist() }
        btnRetry.setOnClickListener { load() }
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }

        resolveLink(intent)
        if (url.isEmpty()) {
            setButtonsEnabled(false)
            statusTv.text = getString(R.string.link_not_found)
        } else {
            if (isTikTok) {
                titleTv.text = getString(R.string.link_heading_tiktok)
                // TikTok: hanya unduhan (pemutaran tetap di aplikasi TikTok).
                btnPlayVideo.visibility = View.GONE
                btnPlayAudio.visibility = View.GONE
                btnM4a.setText(R.string.link_dl_m4a_tt)
            }
            if (isFacebook) {
                titleTv.text = getString(R.string.link_heading_facebook)
                // Facebook: hanya unduhan (pemutaran tetap di aplikasi Facebook).
                btnPlayVideo.visibility = View.GONE
                btnPlayAudio.visibility = View.GONE
                btnM4a.setText(R.string.link_dl_m4a_fb)
            }
            if (isPlaylist) showPlaylistMode()
            if (!isTikTok && !isFacebook && !isPlaylist) {
                val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
                warm = MediaController.Builder(applicationContext, token).buildAsync()
            }
            load()
        }
    }

    private fun resolveLink(i: Intent?) {
        if (i == null) return
        val text = i.getStringExtra(EXTRA_LINK)
            ?: (if (i.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT) else null)
        val video = YtLink.extract(text)
        val list = YtLink.extractPlaylist(text)
        if (video != null) {
            // Tautan satu video; bila dibuka dari dalam playlist, tawarkan juga unduh seluruh playlist.
            url = video
            isTikTok = false
            playlistUrl = list
            return
        }
        if (list != null) {
            url = list
            playlistUrl = list
            isTikTok = false
            isPlaylist = true
            return
        }
        TikTokLink.extract(text)?.let {
            url = it
            isTikTok = true
            return
        }
        FacebookLink.extract(text)?.let {
            url = it
            isFacebook = true
        }
    }

    private fun setButtonsEnabled(on: Boolean) {
        listOf(btnPlayVideo, btnPlayAudio, btnM4a, btnMp3, btnMp4, btnPlaylist).forEach { it.isEnabled = on }
    }

    /** Gagal memuat: pesan galat, tombol putar/unduh disembunyikan (tidak ada yang bisa diunduh), tinggal Coba lagi. */
    private fun showFailure(msg: String) {
        statusTv.text = msg
        listOf(btnPlayVideo, btnPlayAudio, btnM4a, btnMp3, btnMp4, btnPlaylist).forEach { it.visibility = View.GONE }
        btnRetry.visibility = View.VISIBLE
    }

    /** Kembalikan tombol sesuai mode (YouTube, playlist, TikTok) sebelum memuat ulang. */
    private fun restoreButtons() {
        val showPlay = !isTikTok && !isFacebook && !isPlaylist
        btnPlayVideo.visibility = if (showPlay) View.VISIBLE else View.GONE
        btnPlayAudio.visibility = if (showPlay) View.VISIBLE else View.GONE
        btnM4a.visibility = View.VISIBLE
        btnMp3.visibility = View.VISIBLE
        btnMp4.visibility = View.VISIBLE
        btnPlaylist.visibility = View.GONE   // dimunculkan lagi setelah video YouTube berhasil dimuat
    }

    private fun load() {
        info = null
        tt = null
        btnRetry.visibility = View.GONE
        restoreButtons()
        setButtonsEnabled(false)
        statusTv.text = getString(R.string.loading)
        when {
            isPlaylist -> loadPlaylist()
            isTikTok -> loadTikTok()
            isFacebook -> loadFacebook()
            else -> loadYouTube()
        }
    }

    // ------------------------------------------------------------------ playlist

    /** Tampilan khusus playlist: tombol putar disembunyikan, tombol unduh berlaku untuk semua video. */
    private fun showPlaylistMode() {
        titleTv.text = getString(R.string.link_heading_playlist)
        btnPlayVideo.visibility = View.GONE
        btnPlayAudio.visibility = View.GONE
        btnPlaylist.visibility = View.GONE
        btnM4a.text = getString(R.string.link_pl_m4a)
        btnMp3.text = getString(R.string.link_pl_mp3)
        btnMp4.text = getString(R.string.link_pl_mp4)
    }

    private fun switchToPlaylist() {
        val pl = playlistUrl ?: return
        url = pl
        isPlaylist = true
        info = null
        uploaderTv.text = ""
        showPlaylistMode()
        load()
    }

    private fun loadPlaylist() {
        Repo.fetchPlaylist(url) { pl, err ->
            if (isDestroyed) return@fetchPlaylist
            if (pl == null) {
                showFailure(err ?: "Gagal memuat playlist")
                return@fetchPlaylist
            }
            plName = (pl.name ?: "").ifBlank { "Playlist" }
            plCount = pl.streamCount
            titleTv.text = plName
            uploaderTv.text = pl.uploaderName.orEmpty()
            setButtonsEnabled(true)
            val n = if (plCount > 0) "$plCount video" else "jumlah video belum diketahui"
            statusTv.text = "Playlist berisi $n. Pilih format untuk mengunduh semua video."
        }
    }

    private fun choosePlaylist(group: String, label: String) {
        when (group) {
            DownloadOptions.GROUP_M4A ->
                confirmPlaylist("M4A kualitas terbaik", DownloadOptions.KEY_AUDIO, false)
            DownloadOptions.GROUP_MP3 -> {
                val rates = DownloadOptions.MP3_RATES
                showChoices("$label: pilih kualitas", rates.map { "MP3 $it kbps" }) { which ->
                    confirmPlaylist("MP3 ${rates[which]} kbps", "${DownloadOptions.MP3_PREFIX}${rates[which]}", false)
                }
            }
            else -> {
                val hs = DownloadOptions.PLAYLIST_HEIGHTS
                showChoices("$label: pilih kualitas tertinggi", hs.map { "Hingga ${it}p" }) { which ->
                    confirmPlaylist(
                        "MP4 hingga ${hs[which]}p",
                        "${DownloadOptions.VIDEOMAX_PREFIX}${hs[which]}", true
                    )
                }
            }
        }
    }

    private fun confirmPlaylist(label: String, key: String, video: Boolean) {
        val n = if (plCount > 0) "$plCount video" else "semua video"
        val root = if (video) "Movies/YTPlayer" else "Music/YTPlayer"
        val sub = plName.replace(FOLDER_BAD, " ").replace(Regex("\\s+"), " ").trim().trim('.').take(80)
        val folder = if (sub.isEmpty()) root else "$root/$sub"
        val extra = if (video) {
            "\nBila sebuah video tidak punya kualitas sebesar itu, dipakai kualitas tertinggi di bawahnya."
        } else ""
        AlertDialog.Builder(this)
            .setTitle("Unduh playlist?")
            .setMessage(
                "$plName\n\nAkan diunduh $n sebagai $label, satu per satu berurutan. " +
                    "Hasil disimpan di $folder dengan nomor urut. " +
                    "Progres ada di satu notifikasi, ada tombol Batal untuk menghentikan seluruh playlist.$extra"
            )
            .setPositiveButton("Mulai unduh") { _, _ ->
                Downloads.requestPlaylist(this, url, plName, key)
                statusTv.text = "Memulai unduhan playlist: $label. Progres ada di notifikasi."
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun loadYouTube() {
        Repo.fetchStream(url) { stream, err ->
            if (isDestroyed) return@fetchStream
            if (stream == null) {
                showFailure(err ?: "Gagal memuat video")
                return@fetchStream
            }
            info = stream
            titleTv.text = stream.name ?: getString(R.string.link_heading)
            uploaderTv.text = stream.uploaderName.orEmpty()
            val live = stream.streamType == StreamType.LIVE_STREAM ||
                stream.streamType == StreamType.AUDIO_LIVE_STREAM
            setButtonsEnabled(true)
            btnPlaylist.visibility = if (playlistUrl != null) View.VISIBLE else View.GONE
            if (live) {
                listOf(btnM4a, btnMp3, btnMp4).forEach { it.isEnabled = false }
                statusTv.text = "Siaran langsung hanya bisa diputar, tidak bisa diunduh."
            } else {
                statusTv.text = "Siap. Pilih putar atau unduh."
            }
        }
    }

    private fun loadTikTok() {
        TikTokResolver.resolveAsync(url) { result, err ->
            if (isDestroyed) return@resolveAsync
            if (result == null) {
                showFailure(err ?: "Gagal memuat video TikTok")
                return@resolveAsync
            }
            tt = result
            titleTv.text = result.displayName()
            uploaderTv.text = if (result.author.isBlank()) "" else "TikTok @${result.author}"
            setButtonsEnabled(true)
            statusTv.text = "Siap. Pilih format unduhan."
        }
    }

    private fun loadFacebook() {
        FacebookResolver.resolveAsync(url) { result, err ->
            if (isDestroyed) return@resolveAsync
            if (result == null) {
                showFailure(err ?: "Gagal memuat video Facebook")
                return@resolveAsync
            }
            tt = result
            titleTv.text = result.displayName()
            uploaderTv.text = if (result.author.isBlank()) "Facebook" else "Facebook ${result.author}"
            setButtonsEnabled(true)
            statusTv.text = "Siap. Pilih format unduhan."
        }
    }

    private fun play(audio: Boolean) {
        val s = info ?: return
        Store.setAudioOnly(this, audio)
        PlayQueue.clear()
        // Putar langsung tanpa menunggu layar pemutar terbuka dan tersambung.
        warm?.let { QuickPlay.startFromFuture(applicationContext, it, url) }
        warm = null
        startActivity(PlayerActivity.intent(this, Repo.itemFrom(url, s)))
        finish()
    }

    override fun onDestroy() {
        // Ditutup tanpa memutar: lepas sambungan yang sudah disiapkan.
        warm?.let { MediaController.releaseFuture(it) }
        warm = null
        super.onDestroy()
    }

    private fun chooseQuality(group: String, label: String) {
        if (isPlaylist) {
            choosePlaylist(group, label)
            return
        }
        if (isTikTok || isFacebook) {
            chooseTikTok(group, label)
            return
        }
        val s = info ?: return
        val opts = DownloadOptions.options(s).filter { it.group == group }
        if (opts.isEmpty()) {
            statusTv.text = "Format ini tidak tersedia untuk video ini."
            return
        }
        val name = s.name ?: ""
        showChoices("$label: pilih kualitas", opts.map { it.label }) { which ->
            Downloads.request(this, url, name, opts[which].key)
            statusTv.text = "Memulai unduhan: ${opts[which].label}. Progres ada di notifikasi."
        }
    }

    private fun chooseTikTok(group: String, label: String) {
        val t = tt ?: return
        val name = t.displayName()
        val kMp4 = if (isFacebook) FacebookResolver.KEY_MP4 else TikTokResolver.KEY_MP4
        val kM4a = if (isFacebook) FacebookResolver.KEY_M4A else TikTokResolver.KEY_M4A
        val kMp3 = if (isFacebook) FacebookResolver.KEY_MP3 else TikTokResolver.KEY_MP3
        when (group) {
            DownloadOptions.GROUP_MP4 -> {
                showChoices("$label: pilih kualitas", t.qualities.map { it.label }) { which ->
                    val q = t.qualities[which]
                    Downloads.request(this, url, name, "${kMp4}${q.height}")
                    statusTv.text = "Memulai unduhan: ${q.label}. Progres ada di notifikasi."
                }
            }
            DownloadOptions.GROUP_M4A -> {
                Downloads.request(this, url, name, kM4a)
                statusTv.text = "Memulai unduhan suara M4A. Progres ada di notifikasi."
            }
            else -> {
                val rates = DownloadOptions.MP3_RATES
                showChoices("$label: pilih kualitas", rates.map { "MP3 $it kbps" }) { which ->
                    Downloads.request(this, url, name, "${kMp3}${rates[which]}")
                    statusTv.text = "Memulai unduhan MP3 ${rates[which]} kbps. Progres ada di notifikasi."
                }
            }
        }
    }

    private fun showChoices(title: String, labels: List<String>, onPick: (Int) -> Unit) {
        // Hanya satu pilihan: tidak perlu bertanya, langsung jalankan.
        if (labels.size == 1) {
            onPick(0)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels.toTypedArray()) { _, which -> onPick(which) }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Downloads.onPermissionResult(this, requestCode, grantResults)
    }
}
