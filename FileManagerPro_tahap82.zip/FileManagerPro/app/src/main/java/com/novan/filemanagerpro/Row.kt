package com.novan.filemanagerpro

import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityActionCompat
import androidx.recyclerview.widget.RecyclerView

/**
 * Satu baris daftar. [selected] bernilai null jika tidak dalam mode pilih,
 * true/false jika dalam mode pilih.
 */
data class Row(
    val iconRes: Int,
    val name: String,
    val detail: String,
    val spoken: String,
    val tag: Any,
    val selected: Boolean? = null,
    val thumb: String? = null
)

class RowAdapter(
    private val onClick: (Int) -> Unit,
    private val onLong: ((Int) -> Unit)? = null
) : RecyclerView.Adapter<RowAdapter.VH>() {

    /** true: tampilan kisi (item_grid), false: tampilan daftar (item_row). */
    var grid: Boolean = false

    var rows: MutableList<Row> = ArrayList()
        private set

    fun submit(newRows: List<Row>) {
        rows = ArrayList(newRows)
        notifyDataSetChanged()
    }

    fun setSelected(i: Int, value: Boolean?) {
        if (i < 0 || i >= rows.size) return
        rows[i] = rows[i].copy(selected = value)
        notifyItemChanged(i)
    }

    fun setAllSelected(value: Boolean?) {
        for (i in rows.indices) rows[i] = rows[i].copy(selected = value)
        notifyDataSetChanged()
    }

    fun selectedIndices(): List<Int> = rows.indices.filter { rows[it].selected == true }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val detail: TextView = v.findViewById(R.id.detail)
        val check: CheckBox = v.findViewById(R.id.check)
        val baseBg = v.background
    }

    override fun getItemViewType(position: Int): Int = if (grid) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(
            LayoutInflater.from(parent.context).inflate(
                if (viewType == 1) R.layout.item_grid else R.layout.item_row, parent, false
            )
        )

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        val ctx = h.itemView.context
        h.icon.setImageResource(r.iconRes)
        h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
        if (r.thumb != null) Thumbs.load(h.icon, r.thumb) else h.icon.tag = null
        h.name.text = r.name
        h.detail.text = r.detail
        // baris tercentang diberi warna latar berbeda supaya mudah dibedakan
        h.itemView.background = if (r.selected == true) ColorDrawable(0x551976D2) else h.baseBg
        if (r.selected == null) {
            h.check.visibility = View.GONE
            h.itemView.contentDescription = r.spoken
        } else {
            h.check.visibility = View.VISIBLE
            h.check.isChecked = r.selected
            val state = ctx.getString(
                if (r.selected) R.string.state_selected else R.string.state_not_selected
            )
            h.itemView.contentDescription = state + ", " + r.spoken
        }
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        if (onLong != null) {
            h.itemView.setOnLongClickListener {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) onLong.invoke(p)
                true
            }
            ViewCompat.replaceAccessibilityAction(
                h.itemView,
                AccessibilityActionCompat.ACTION_LONG_CLICK,
                ctx.getString(R.string.act_menu),
                null
            )
        }
    }

    override fun getItemCount(): Int = rows.size
}
