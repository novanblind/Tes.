package com.novan.audiolabnovan.autotune

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.text.InputType
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.karaoke.DeteksiNada
import com.novan.audiolabnovan.karaoke.FilterVokal
import com.novan.audiolabnovan.karaoke.JalurKoreksi
import com.novan.audiolabnovan.karaoke.KonfigFilter
import com.novan.audiolabnovan.karaoke.PemantauNada
import com.novan.audiolabnovan.karaoke.PenguraiLagu
import com.novan.audiolabnovan.karaoke.batasiLembut
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import com.novan.audiolabnovan.sfx.TambahSfxActivity
import java.io.File
import kotlin.math.abs

/**
 * Tahap 89: Vocal AutoTuner. Pilih rekaman vokal; nada yang melenceng ditarik ke not (atau tangga nada kunci)
 * terdekat. Tanpa AI dan tanpa internet: memakai pengolah nada yang sudah ada di proyek, yaitu pendeteksi nada YIN
 * ([PemantauNada]), penaksir kunci dan jalur koreksi ([JalurKoreksi]), serta pergeseran nada berlaju berubah
 * ([FilterVokal]) yang juga dipakai filter suara Studio Karaoke.
 */
class VocalAutoTunerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri_autotune"
        const val EXTRA_NAMA = "nama_autotune"
        private const val SUBFOLDER = "Vocal AutoTuner"
    }

    private class Dibatalkan : Exception()

    private val daftarFormat = listOf(OutFmt.MP3, OutFmt.AAC, OutFmt.FLAC, OutFmt.WAV)
    private val namaNot = listOf("C", "C kres", "D", "D kres", "E", "F", "F kres", "G", "G kres", "A", "A kres", "B")

    /** Himpunan 12 kelas nada tangga mayor atau minor dengan nada dasar [tonik] (0 = C). */
    private fun skala(tonik: Int, minor: Boolean): BooleanArray {
        val langkah = if (minor) intArrayOf(0, 2, 3, 5, 7, 8, 10) else intArrayOf(0, 2, 4, 5, 7, 9, 11)
        val a = BooleanArray(12)
        for (d in langkah) a[(tonik + d) % 12] = true
        return a
    }

    private var sumber: Uri? = null
    private var namaSumber = ""

    private lateinit var tombolPilih: Button
    private lateinit var tombolProses: Button
    private lateinit var tombolBatal: Button
    private lateinit var spKekuatan: Spinner
    private lateinit var spNada: Spinner
    private lateinit var spFormat: Spinner
    private lateinit var spTonik: Spinner
    private lateinit var spJenisKunci: Spinner
    private lateinit var etMulai: EditText
    private lateinit var cekContoh: CheckBox
    private lateinit var tvSumber: TextView
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar

    @Volatile private var batal = false
    @Volatile private var sibuk = false

    private val dialogHasil by lazy { DialogHasil(this) }

    private val pilih = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setSumber(uri, null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Vocal AutoTuner"
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, "Vocal AutoTuner"))
        akar.addView(AlatUi.label(c, "Menyetel nada vokal yang sumbang ke nada yang tepat. Dikerjakan di HP tanpa AI dan tanpa internet. " +
            "Paling bagus untuk rekaman vokal saja, satu suara, tanpa musik. Lagu penuh dengan musik membuat nada sulit diukur."))

        tombolPilih = AlatUi.tombol(c, "Pilih rekaman vokal") { pilih.launch(arrayOf("audio/*", "video/*")) }
        akar.addView(tombolPilih, AlatUi.margin(c))
        tvSumber = AlatUi.label(c, "Belum ada berkas dipilih.")
        akar.addView(tvSumber)

        spKekuatan = AlatUi.spinner(c, listOf(
            "Lembut: koreksi halus, terdengar alami",
            "Sedang: nada ditarik cukup tegas",
            "Kuat: nada hampir pas semua",
            "Robot: nada langsung patah ke not, efek khas"
        )).also { it.setSelection(1) }
        akar.addView(AlatUi.label(c, "Kekuatan koreksi", spKekuatan))
        akar.addView(spKekuatan, AlatUi.margin(c))

        spNada = AlatUi.spinner(c, listOf(
            "Ikuti kunci nada yang terdeteksi dari nyanyian",
            "Semua nada: tarik ke not terdekat"
        ))
        akar.addView(AlatUi.label(c, "Tangga nada", spNada))
        akar.addView(spNada, AlatUi.margin(c))

        spTonik = AlatUi.spinner(c, listOf("Otomatis (terdeteksi)") + namaNot)
        akar.addView(AlatUi.label(c, "Nada dasar kunci lagu (bila Anda tahu kuncinya; hanya berlaku untuk tangga nada ikut kunci)", spTonik))
        akar.addView(spTonik, AlatUi.margin(c))
        spJenisKunci = AlatUi.spinner(c, listOf("Mayor", "Minor"))
        akar.addView(AlatUi.label(c, "Jenis kunci", spJenisKunci))
        akar.addView(spJenisKunci, AlatUi.margin(c))

        spFormat = AlatUi.spinner(c, daftarFormat.map { it.label })
        akar.addView(AlatUi.label(c, "Format hasil", spFormat))
        akar.addView(spFormat, AlatUi.margin(c))

        cekContoh = CheckBox(this).apply { text = "Hanya contoh: 10 detik pertama (cepat untuk mencoba kekuatan)" }
        akar.addView(cekContoh, AlatUi.margin(c))
        etMulai = EditText(this).apply {
            hint = "Mulai contoh dari, contoh 0 atau 1:05"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        akar.addView(AlatUi.label(c, "Mulai contoh dari detik (bagian yang ada nyanyiannya)", etMulai))
        akar.addView(etMulai, AlatUi.margin(c))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = android.view.View.GONE }
        akar.addView(bar, AlatUi.margin(c))

        tombolProses = AlatUi.tombol(c, "Setel nada dan simpan") { proses() }
        akar.addView(tombolProses, AlatUi.margin(c))
        tombolBatal = AlatUi.tombol(c, "Batalkan") { batal = true; try { FFmpegKit.cancel() } catch (_: Throwable) { } }
        tombolBatal.isEnabled = false
        akar.addView(tombolBatal, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)

        // Berkas dari menu Bagikan langsung terpilih.
        intent.getStringExtra(EXTRA_URI)?.let { setSumber(Uri.parse(it), intent.getStringExtra(EXTRA_NAMA)) }
    }

    private fun namaDari(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { q ->
                if (q.moveToFirst()) q.getString(0)?.let { return it }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "rekaman"
    }

    private fun setSumber(uri: Uri, nama: String?) {
        sumber = uri
        namaSumber = nama?.takeIf { it.isNotBlank() } ?: namaDari(uri)
        tvSumber.text = "Berkas: $namaSumber"
        status("Berkas dipilih. Atur kekuatan koreksi, lalu tekan Setel nada dan simpan.", true)
    }

    private fun status(t: String, umumkan: Boolean = false) {
        runOnUiThread {
            tvStatus.text = t
            if (umumkan) tvStatus.announceForAccessibility(t)
        }
    }

    private fun progres(p: Int) = runOnUiThread { bar.progress = p.coerceIn(0, 100) }

    private fun proses() {
        val src = sumber
        if (src == null) { status("Pilih rekaman vokal dulu.", true); return }
        if (sibuk) { Toast.makeText(this, "Masih bekerja. Tunggu atau batalkan dulu.", Toast.LENGTH_SHORT).show(); return }
        val auto = spKekuatan.selectedItemPosition.coerceIn(0, 3) + 1          // 1 lembut .. 4 robot
        val kromatik = auto == 4 || spNada.selectedItemPosition == 1
        val contoh = cekContoh.isChecked
        val fmt = daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val judul = PenyimpanHasil.judulDari(namaSumber)
        val mulaiContoh = if (contoh) (TambahSfxActivity.bacaWaktu(etMulai.text.toString()) ?: 0.0) else 0.0
        val tonik = spTonik.selectedItemPosition - 1                          // -1 = otomatis
        val skalaPaksa = if (tonik >= 0 && spNada.selectedItemPosition == 0 && auto != 4) {
            skala(tonik, spJenisKunci.selectedItemPosition == 1)
        } else {
            null
        }

        sibuk = true
        batal = false
        tombolPilih.isEnabled = false
        tombolProses.isEnabled = false
        tombolBatal.isEnabled = true
        bar.progress = 0
        bar.visibility = android.view.View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Membaca berkas. Biarkan layar menyala sampai selesai.", true)

        Thread {
            var pesan: String? = null
            var uriHasil: Uri? = null
            var namaHasil = ""
            var catatan = ""
            val stamp = System.currentTimeMillis()
            val tmpWav = File(cacheDir, "autotune_$stamp.wav")
            val tmpOut = File(cacheDir, "autotune_$stamp.${fmt.ext}")
            try {
                var terakhir = -10
                val lagu = PenguraiLagu.urai(this, src, { batal }) { p ->
                    if (p - terakhir >= 10) { terakhir = p; status("Membaca berkas $p persen...") }
                }
                if (batal) throw Dibatalkan()
                if (lagu == null) { pesan = "Berkas ini tidak bisa dibaca sebagai audio."; return@Thread }
                val sr = lagu.sr
                val awal = if (contoh) (mulaiContoh * sr).toLong().coerceAtMost(lagu.frame.toLong()).toInt() else 0
                val pcm = if (contoh) lagu.pcm.copyOfRange(awal * 2, minOf(lagu.pcm.size, (awal + sr * 10) * 2)) else lagu.pcm
                val frame = pcm.size / 2
                if (frame < sr) {
                    pesan = if (contoh) "Bagian contoh terlalu pendek. Coba mulai dari detik yang lebih awal." else "Berkas terlalu pendek (kurang dari 1 detik)."
                    return@Thread
                }

                // 1) Ukur nada dari campuran mono; sekalian tahu apakah kedua kanal sama persis.
                status("Mengukur nada suara...", true)
                val pantau = PemantauNada(sr)
                val blok = ShortArray(4096)
                var serupa = true
                var f = 0
                while (f < frame) {
                    if (batal) throw Dibatalkan()
                    val b = minOf(4096, frame - f)
                    for (i in 0 until b) {
                        val l = pcm[(f + i) * 2].toInt()
                        val r = pcm[(f + i) * 2 + 1].toInt()
                        if (l != r) serupa = false
                        blok[i] = ((l + r) / 2).toShort()
                    }
                    pantau.proses(blok, b)
                    f += b
                    progres((f.toLong() * 30L / frame).toInt())
                }
                if (pantau.jumlahBernada < 40) {
                    pesan = "Suara bernada hampir tidak terdeteksi (kurang dari sekitar satu detik nyanyian jelas), jadi tidak ada yang disetel. " +
                        "Pakai rekaman vokal saja tanpa musik, dengan suara yang jelas."
                    return@Thread
                }
                val sal = pantau.salin()
                var jml = 0
                var jumlahSen = 0.0
                for (i in 0 until sal.jumlah) {
                    val h = sal.hz[i]
                    if (h > 0f) { jml++; jumlahSen += abs(PemantauNada.selisihSen(h.toDouble())) }
                }
                val rataSen = if (jml > 0) jumlahSen / jml else 0.0
                val detikNyanyi = jml.toDouble() * DeteksiNada.HOP / sr
                catatan = String.format(java.util.Locale("id"),
                    " Terdeteksi sekitar %.0f detik bernyanyi; rata-rata nada melenceng %.0f sen dari not terdekat (100 sen = satu semiton).", detikNyanyi, rataSen)
                if (rataSen < 8.0) catatan += " Nadanya sudah cukup pas, jadi koreksi hanya sedikit terdengar."

                // 2) Tarik nada ke not; dikerjakan di tempat, per kanal (kanal sama persis cukup dikerjakan sekali).
                status("Menyetel nada...", true)
                val kf = KonfigFilter(auto, kromatik, 0, false, 0, 0)
                val kanal = if (serupa) 1 else 2
                for (c in 0 until kanal) {
                    val fv = FilterVokal(sr, kf, JalurKoreksi(sal, kf, skalaPaksa))
                    val look = fv.lookahead
                    var idx = 0
                    while (idx < frame) {
                        if (batal) throw Dibatalkan()
                        val akhir = minOf(frame, idx + 8192)
                        for (k in idx until akhir) {
                            val a = k + look
                            val x = if (a < frame) pcm[a * 2 + c].toDouble() else 0.0
                            pcm[k * 2 + c] = batasiLembut(fv.proses(k.toLong(), x))
                        }
                        idx = akhir
                        progres(30 + (((c.toLong() * frame) + idx) * 65L / (kanal.toLong() * frame)).toInt())
                    }
                }
                if (serupa) for (k in 0 until frame) pcm[k * 2 + 1] = pcm[k * 2]

                // 3) Tulis, sandi, simpan.
                status("Menyandi hasil...", true)
                progres(96)
                PenyimpanHasil.tulisWav(tmpWav, pcm, frame, sr, 2)
                if (batal) throw Dibatalkan()
                val galat = PenyimpanHasil.sandi(tmpWav, tmpOut, fmt, 192, judul, "Vocal AutoTuner")
                if (galat != null) { pesan = galat; return@Thread }
                namaHasil = (if (contoh) "AutoTuneContoh_" else "AutoTune_") + PenyimpanHasil.stempel() + "." + fmt.ext
                uriHasil = PenyimpanHasil.simpan(this, tmpOut, namaHasil, fmt, SUBFOLDER)
            } catch (e: Dibatalkan) {
                pesan = "Dibatalkan."
            } catch (e: OutOfMemoryError) {
                pesan = "Memori HP tidak cukup untuk berkas ini. Coba berkas yang lebih pendek, atau centang Hanya contoh."
            } catch (e: Throwable) {
                pesan = "Gagal: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                tmpWav.delete()
                tmpOut.delete()
                val u = uriHasil
                val n = namaHasil
                val p = pesan
                val ket = catatan
                runOnUiThread { selesai(u, n, p, fmt, contoh, ket) }
            }
        }.start()
    }

    private fun selesai(uri: Uri?, nama: String, pesan: String?, fmt: OutFmt, contoh: Boolean, catatan: String) {
        sibuk = false
        tombolPilih.isEnabled = true
        tombolProses.isEnabled = true
        tombolBatal.isEnabled = false
        bar.visibility = android.view.View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (uri != null) {
            val teks = (if (contoh) "Contoh selesai. " else "Selesai. ") +
                "Tersimpan di folder Musik, AudioLab Novan, Vocal AutoTuner, dengan nama $nama.$catatan"
            status(teks, true)
            dialogHasil.tampilkan(uri, nama, fmt.mime)
        } else {
            status(pesan ?: "Gagal.", true)
        }
    }

    override fun onDestroy() {
        batal = true
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}
