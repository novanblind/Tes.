package com.novan.filemanagermax

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File

/** Layanan latar depan yang menjalankan server FTP dan HTTP. */
class ServerService : Service() {

    companion object {
        const val ACTION_START = "com.novan.filemanagermax.SERVER_START"
        const val ACTION_STOP = "com.novan.filemanagermax.SERVER_STOP"
        const val EXTRA_KIND = "kind"
        const val EXTRA_PORT = "port"
        const val EXTRA_ROOT = "root"
        const val FTP = "ftp"
        const val HTTP = "http"
        private const val CHANNEL = "server"
        private const val NOTIF_ID = 77

        @Volatile var ftpPort: Int = 0
        @Volatile var httpPort: Int = 0
        @Volatile var error: String? = null
        @Volatile var onChange: (() -> Unit)? = null

        fun isRunning(kind: String) = if (kind == FTP) ftpPort > 0 else httpPort > 0
    }

    private var ftp: FtpServer? = null
    private var http: HttpServer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val kind = intent?.getStringExtra(EXTRA_KIND) ?: FTP
        if (intent?.action == ACTION_STOP) {
            stopKind(kind)
        } else {
            startNotification()
            startKind(kind, intent)
        }
        if (ftp == null && http == null) {
            releaseLocks()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        } else {
            startNotification()
        }
        notifyChange()
        return START_NOT_STICKY
    }

    private fun notifyChange() {
        val cb = onChange ?: return
        android.os.Handler(mainLooper).post { cb() }
    }

    private fun startKind(kind: String, intent: Intent?) {
        error = null
        val port = intent?.getIntExtra(EXTRA_PORT, 0) ?: 0
        val root = File(intent?.getStringExtra(EXTRA_ROOT) ?: "/storage/emulated/0")
        val user = Prefs.serverUser(this)
        val pass = Prefs.serverPass(this)
        try {
            if (kind == FTP) {
                ftp?.stop()
                ftp = FtpServer(root, port, user, pass).also { it.start() }
                ftpPort = port
            } else {
                http?.stop()
                http = HttpServer(applicationContext, root, port, user, pass).also { it.start() }
                httpPort = port
            }
            acquireLocks()
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
            if (kind == FTP) { ftp = null; ftpPort = 0 } else { http = null; httpPort = 0 }
        }
    }

    private fun stopKind(kind: String) {
        if (kind == FTP) { ftp?.stop(); ftp = null; ftpPort = 0 }
        else { http?.stop(); http = null; httpPort = 0 }
    }

    private fun acquireLocks() {
        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FileManagerMax:server").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        }
        if (wifi == null) {
            try {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "FileManagerMax:server").also {
                    it.setReferenceCounted(false)
                    it.acquire()
                }
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    private fun releaseLocks() {
        try { wake?.release() } catch (e: Exception) { }
        try { wifi?.release() } catch (e: Exception) { }
        wake = null
        wifi = null
    }

    private fun startNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.net_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val ip = ServerUtil.localIp() ?: "?"
        val lines = ArrayList<String>()
        if (ftpPort > 0) lines.add("ftp://$ip:$ftpPort")
        if (httpPort > 0) lines.add("http://$ip:$httpPort")
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, NetworkActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ServerService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_KIND, FTP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopHttp = PendingIntent.getService(
            this, 2,
            Intent(this, ServerService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_KIND, HTTP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(getString(R.string.net_notif_title))
            .setContentText(lines.joinToString("  "))
            .setContentIntent(open)
            .setOngoing(true)
            .apply {
                if (ftpPort > 0) addAction(0, getString(R.string.net_stop_ftp), stop)
                if (httpPort > 0) addAction(0, getString(R.string.net_stop_http), stopHttp)
            }
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        ftp?.stop(); http?.stop()
        ftp = null; http = null
        ftpPort = 0; httpPort = 0
        releaseLocks()
        notifyChange()
        super.onDestroy()
    }
}
