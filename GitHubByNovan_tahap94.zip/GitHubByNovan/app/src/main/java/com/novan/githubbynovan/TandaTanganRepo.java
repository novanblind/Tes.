package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.util.Base64;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Pilihan tanda tangan saat "Mulai pembangunan APK": bawaan GitHub atau pribadi.
 * Bila pribadi, keystore dikirim ke repo (folder .tanda-tangan) dan alur kerja menandatangani APK rilis dengannya.
 */
public class TandaTanganRepo {
    static final String KS_PATH = ".tanda-tangan/kunci.p12";
    static final String PROP_PATH = ".tanda-tangan/sandi.properties";
    static final String TANPA_PENJAGA_PATH = ".tanda-tangan/tanpa-penjaga";
    static final String R8_PATH = ".tanda-tangan/r8";
    static final String OBF_PATH = ".tanda-tangan/obfuskasi-kuat";
    static final String TANPA_ENKRIPSI_PATH = ".tanda-tangan/tanpa-enkripsi-string";
    static final String PENANDA = "# tanda-tangan-pribadi: v15";
    private static final String SKIP = " [skip ci]";

    // ---------- pintu masuk ----------

    /** Pintu masuk bangun APK: memakai setelan tanda tangan bawaan (Pengaturan bangun APK) bila sudah diatur. */
    public static void mulai(final Activity a, final String full, final String token, final Runnable back) {
        String m = Store.ttMode(a);
        if ("bawaan".equals(m)) {
            android.widget.Toast.makeText(a, "Memakai tanda tangan bawaan GitHub sesuai pengaturan.",
                    android.widget.Toast.LENGTH_SHORT).show();
            pakaiBawaan(a, full, token, back);
            return;
        }
        if ("pribadi".equals(m)) {
            android.widget.Toast.makeText(a, "Memakai tanda tangan pribadi sesuai pengaturan.",
                    android.widget.Toast.LENGTH_SHORT).show();
            pakaiPribadi(a, full, token, back);
            return;
        }
        mulaiOtomatis(a, full, token, back);
    }

    /**
     * Mode otomatis (bawaan). Bila sudah ada tanda tangan pribadi, setiap pembangunan memakainya
     * (satu tanda tangan langsung dipakai; beberapa: pilih dulu). Di repo publik kunci lewat GitHub Secrets,
     * di repo privat sebagai berkas. Bila belum ada tanda tangan pribadi: langsung tanda tangan bawaan GitHub,
     * tanpa dialog, di repo publik maupun privat.
     */
    private static void mulaiOtomatis(final Activity a, final String full, final String token, final Runnable back) {
        final List<JSONObject> signs = Store.signs(a);
        if (signs == null || signs.isEmpty()) {
            android.widget.Toast.makeText(a, "Belum ada tanda tangan pribadi: memakai tanda tangan bawaan GitHub.",
                    android.widget.Toast.LENGTH_SHORT).show();
            pakaiBawaan(a, full, token, back);
            return;
        }
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> a.runOnUiThread(() -> {
            if (a.isFinishing()) return;
            if (!ok) {
                mulaiTanya(a, full, token, back);
                return;
            }
            final boolean privat = Api.parse(res).optBoolean("private", true);
            android.widget.Toast.makeText(a, privat
                            ? "Memakai tanda tangan pribadi."
                            : "Repo publik: memakai tanda tangan pribadi lewat Secrets.",
                    android.widget.Toast.LENGTH_SHORT).show();
            lanjutPribadi(a, full, token, back, () -> mulaiTanya(a, full, token, back), !privat);
        }));
    }

    /** Selalu menampilkan pilihan tanda tangan; juga tujuan tombol kembali/batal agar tidak berputar otomatis. */
    public static void mulaiTanya(final Activity a, final String full, final String token, final Runnable back) {
        String msg = "Proyek: " + full
                + "\n\nBawaan GitHub: kunci sementara, berganti tiap build. Cocok untuk mencoba. "
                + "Aplikasi lama harus dicopot dulu sebelum pasang yang baru."
                + "\n\nPribadi: pakai kunci Anda, jadi bisa diperbarui. Di repo privat, keystore dikirim ke repo. Di repo publik, kunci disimpan di GitHub Secrets (terenkripsi), bukan sebagai berkas.";
        ApkTools.dialog(a, "Pilih tanda tangan APK", msg, ApkTools.list(
                ApkTools.b("tanda tangan bawaan GitHub", () -> pakaiBawaan(a, full, token, back)),
                ApkTools.b("tanda tangan pribadi", () -> pakaiPribadi(a, full, token, back))), "batal", back);
    }

    // ---------- bawaan ----------

    private static void pakaiBawaan(final Activity a, final String full, final String token, final Runnable back) {
        // Bila sebelumnya repo pernah diberi tanda tangan pribadi, kunci dihapus agar alur kerja memakai kunci bawaan.
        hapus(a, full, token, PROP_PATH, back, () ->
                hapus(a, full, token, KS_PATH, back, () ->
                        hapus(a, full, token, TANPA_PENJAGA_PATH, back, () ->
                                hapus(a, full, token, R8_PATH, back, () ->
                                        hapus(a, full, token, OBF_PATH, back, () ->
                                                hapus(a, full, token, TANPA_ENKRIPSI_PATH, back, () ->
                                                        a.runOnUiThread(() -> ApkTools.bangunUlang(a, full, token, back))))))));
    }

    // ---------- pribadi ----------

    private static void pakaiPribadi(final Activity a, final String full, final String token, final Runnable back) {
        final Runnable ulang = () -> mulaiTanya(a, full, token, back);
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> a.runOnUiThread(() -> {
            if (a.isFinishing()) return;
            if (!ok) {
                gagal(a, "Gagal membaca proyek", full, res, ulang,
                        ApkTools.b("coba lagi", () -> pakaiPribadi(a, full, token, back)));
                return;
            }
            if (!Api.parse(res).optBoolean("private", false)) {
                List<JSONObject> adaSign = Store.signs(a);
                if (adaSign != null && !adaSign.isEmpty()) {
                    // Repo publik dan tanda tangan pribadi sudah ada: langsung lewat Secrets, tanpa dialog.
                    lanjutPribadi(a, full, token, back, ulang, true);
                    return;
                }
                ApkTools.dialog(a, "Repo ini publik",
                        "Repo publik bisa dilihat semua orang, jadi keystore dan sandi tidak boleh disimpan sebagai "
                                + "berkas di repo."
                                + "\n\nPilihan aman: simpan kunci di GitHub Secrets repo ini (terenkripsi). Alur kerja "
                                + "membacanya saat build, dan kunci tidak muncul di berkas, riwayat, maupun log."
                                + "\n\nCatatan: siapa pun dengan akses tulis ke repo bisa membuat alur kerja yang "
                                + "membaca Secrets, jadi jangan tambah kolaborator yang tidak Anda percaya. "
                                + "Pull request dari fork tidak mendapat Secrets.",
                        ApkTools.list(
                                ApkTools.b("pakai tanda tangan pribadi lewat Secrets",
                                        () -> lanjutPribadi(a, full, token, back, ulang, true)),
                                ApkTools.b("pakai tanda tangan bawaan GitHub",
                                        () -> pakaiBawaan(a, full, token, back))), "kembali", ulang);
                return;
            }
            lanjutPribadi(a, full, token, back, ulang, false);
        }));
    }

    private static void lanjutPribadi(final Activity a, final String full, final String token, final Runnable back,
                                      final Runnable ulang, final boolean rahasia) {
        {
            final List<JSONObject> signs = Store.signs(a);
            if (signs == null || signs.isEmpty()) {
                ApkTools.dialog(a, "Belum ada tanda tangan pribadi",
                        "Buat atau impor tanda tangan dulu, lalu ulangi Mulai pembangunan APK.",
                        ApkTools.list(
                                ApkTools.b("buat tanda tangan pribadi",
                                        () -> a.startActivity(new Intent(a, SignActivity.class))),
                                ApkTools.b("impor tanda tangan dari folder Download",
                                        () -> a.startActivity(new Intent(a, SignActivity.class)
                                                .putExtra("impor", true).putExtra("dari_bangun", true))),
                                ApkTools.b("pakai tanda tangan bawaan GitHub",
                                        () -> pakaiBawaan(a, full, token, back))), "kembali", ulang);
                return;
            }
            String idBawaan = Store.ttSignId(a);
            if (!idBawaan.isEmpty()) {
                for (JSONObject sg : signs) {
                    if (idBawaan.equals(sg.optString("id"))) {
                        konfirmasi(a, full, token, sg, rahasia, back);
                        return;
                    }
                }
            }
            if (signs.size() == 1) {
                // Hanya ada satu tanda tangan pribadi: otomatis terpilih, langsung ke langkah keamanan aplikasi.
                konfirmasi(a, full, token, signs.get(0), rahasia, back);
                return;
            }
            pilih(a, full, token, signs, rahasia, back);
        }
    }

    private static void pilih(final Activity a, final String full, final String token,
                              final List<JSONObject> signs, final boolean rahasia, final Runnable back) {
        java.util.List<ApkTools.Btn> btns = new java.util.ArrayList<>();
        for (int i = 0; i < signs.size(); i++) {
            final JSONObject s = signs.get(i);
            btns.add(ApkTools.b((i + 1) + ". " + Store.labelSign(s),
                    () -> konfirmasi(a, full, token, s, rahasia, back)));
        }
        btns.add(ApkTools.b("tambah: buat tanda tangan baru",
                () -> a.startActivity(new Intent(a, SignActivity.class))));
        btns.add(ApkTools.b("tambah: impor dari folder Download",
                () -> a.startActivity(new Intent(a, SignActivity.class)
                        .putExtra("impor", true).putExtra("dari_bangun", true))));
        btns.add(ApkTools.b("kelola atau hapus tanda tangan",
                () -> a.startActivity(new Intent(a, SignActivity.class))));
        ApkTools.dialog(a, "Pilih tanda tangan pribadi",
                "Ada " + signs.size() + " tanda tangan pribadi. Pilih satu untuk membangun APK, atau kelola tanda tangan. "
                        + "Setelah mengubah, ulangi Mulai pembangunan APK.",
                btns, "kembali", () -> mulaiTanya(a, full, token, back));
    }

    private static void konfirmasi(final Activity a, final String full, final String token,
                                   final JSONObject sign, final boolean rahasia, final Runnable back) {
        if (Store.secSimpan(a)) {
            // Keamanan aplikasi sudah diatur di Pengaturan bangun APK: lewati dialog, langsung kirim dan jalan.
            boolean r8 = Store.secR8(a);
            android.widget.Toast.makeText(a, "Memakai setelan keamanan aplikasi tersimpan.",
                    android.widget.Toast.LENGTH_SHORT).show();
            kirim(a, full, token, sign, rahasia, Store.secPenjaga(a), r8, r8 && Store.secKuat(a), Store.secEnk(a), back);
            return;
        }
        String msg = rahasia ? ("Tanda tangan: " + Store.labelSign(sign)
                + "\nSidik jari SHA-256:\n" + sign.optString("sidik")
                + "\n\nYang dikirim ke GitHub Secrets repo " + full + " (terenkripsi):\n- " + RahasiaRepo.NAMA_KS
                + " (keystore)\n- " + RahasiaRepo.NAMA_ALIAS + " (alias)\n- " + RahasiaRepo.NAMA_SANDI + " (sandi)"
                + "\n\nKunci tidak disimpan sebagai berkas di repo. Berkas kunci lama di repo (bila ada) dihapus, "
                + "tetapi masih bisa terlihat di riwayat repo. Bila repo pernah publik dengan kunci di dalamnya, "
                + "anggap kunci itu bocor dan buat tanda tangan baru."
                + "\n\nPenjaga (disarankan): APK yang ditandatangani ulang orang lain akan menutup sendiri."
                + "\n\nR8 (opsional): kode lebih kecil dan sulit dibaca, tapi bisa membuat fitur gagal. Uji semua fitur."
                + "\n\nEnkripsi string otomatis (opsional): teks di kode dienkripsi saat build. "
                + "Teks berisiko dilewati. Uji semua fitur setelah dibangun.")
                : "Tanda tangan: " + Store.labelSign(sign)
                + "\nSidik jari SHA-256:\n" + sign.optString("sidik")
                + "\n\nYang dikirim ke repo " + full + ":\n- " + KS_PATH + " (keystore)\n- " + PROP_PATH
                + " (alias dan sandi)"
                + "\n\nSiapa pun yang bisa membuka repo ini bisa melihat keduanya. Jaga repo tetap privat "
                + "dan jangan tambah kolaborator yang tidak Anda percaya."
                + "\n\nPenjaga (disarankan): APK yang ditandatangani ulang orang lain akan menutup sendiri."
                + "\n\nR8 (opsional): kode lebih kecil dan sulit dibaca, tapi bisa membuat fitur gagal. Uji semua fitur."
                + "\n\nEnkripsi string otomatis (opsional): teks di kode dienkripsi saat build. "
                + "Teks berisiko dilewati. Uji semua fitur setelah dibangun.";
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (a.getResources().getDisplayMetrics().density * 20);
        box.setPadding(pad, pad / 2, pad, 0);
        TextView tv = new TextView(a);
        tv.setText(msg);
        tv.setTextSize(16);
        box.addView(tv);
        final CheckBox cbR8 = new CheckBox(a);
        cbR8.setText("Aktifkan R8 untuk APK rilis");
        cbR8.setChecked(Store.secR8(a));
        box.addView(cbR8);
        final CheckBox cbKuat = new CheckBox(a);
        cbKuat.setText("Samarkan kode lebih kuat (di atas R8). Uji semua fitur setelah dibangun.");
        cbKuat.setChecked(Store.secR8(a) && Store.secKuat(a));
        cbKuat.setVisibility(Store.secR8(a) ? android.view.View.VISIBLE : android.view.View.GONE);
        box.addView(cbKuat);
        cbR8.setOnCheckedChangeListener((btn, checked) -> {
            cbKuat.setVisibility(checked ? android.view.View.VISIBLE : android.view.View.GONE);
            if (!checked) cbKuat.setChecked(false);
        });
        final CheckBox cbEnk = new CheckBox(a);
        cbEnk.setText("Aktifkan enkripsi string otomatis");
        cbEnk.setChecked(Store.secEnk(a));
        box.addView(cbEnk);
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        new android.app.AlertDialog.Builder(a)
                .setTitle("Kirim tanda tangan ke repo")
                .setView(sv)
                .setPositiveButton("kirim, pasang penjaga, dan mulai", (d, w) ->
                        kirim(a, full, token, sign, rahasia, true, cbR8.isChecked(), cbKuat.isChecked(), cbEnk.isChecked(), back))
                .setNeutralButton("batal", (d, w) -> mulaiTanya(a, full, token, back))
                .setNegativeButton("kirim tanpa penjaga", (d, w) ->
                        kirim(a, full, token, sign, rahasia, false, cbR8.isChecked(), cbKuat.isChecked(), cbEnk.isChecked(), back))
                .setCancelable(false)
                .show();
    }

    private static void kirim(final Activity a, final String full, final String token,
                              final JSONObject sign, final boolean rahasia, final boolean penjaga,
                              final boolean r8, final boolean kuat,
                              final boolean enk, final Runnable back) {
        final byte[] ks;
        try {
            ks = baca(Store.signFile(a, sign.optString("id")));
        } catch (Exception e) {
            ApkTools.error(a, "Berkas tanda tangan tidak terbaca",
                    "Keystore di aplikasi tidak ditemukan atau rusak:\n" + e.getMessage()
                            + "\n\nBuat tanda tangan baru di menu Tanda tangan pribadi.", back);
            return;
        }
        final byte[] prop = ("alias=" + sign.optString("alias") + "\nsandi=" + sign.optString("sandi") + "\n")
                .getBytes(StandardCharsets.UTF_8);
        final boolean kuatAktif = r8 && kuat;
        final Runnable ulang = () -> kirim(a, full, token, sign, rahasia, penjaga, r8, kuat, enk, back);
        if (rahasia) {
            // Repo publik: kunci disimpan di GitHub Secrets, bukan sebagai berkas. Berkas lama (bila ada) dihapus.
            final Runnable lanjut = () -> aturPenjaga(a, full, token, penjaga, r8, kuatAktif, enk, ulang, () ->
                    pastikanAlurKerja(a, full, token, back, () -> a.runOnUiThread(() -> {
                        android.widget.Toast.makeText(a, "Tanda tangan pribadi tersimpan di GitHub Secrets.",
                                android.widget.Toast.LENGTH_SHORT).show();
                        ApkTools.bangunUlang(a, full, token, back);
                    })));
            RahasiaRepo.simpanKunci(a, full, token, ks, sign.optString("alias"), sign.optString("sandi"), ulang, () ->
                    hapus(a, full, token, PROP_PATH, ulang, () -> hapus(a, full, token, KS_PATH, ulang, lanjut)));
            return;
        }

        // Dua berkas dikirim dengan [skip ci] agar tidak memicu pembangunan sendiri; pembangunan dimulai sekali
        // oleh bangunUlang setelah semuanya terpasang (termasuk alur kerja yang mendukung tanda tangan pribadi).
        tulis(a, full, token, PROP_PATH, prop, "Simpan sandi tanda tangan pribadi" + SKIP, ulang, () ->
                tulis(a, full, token, KS_PATH, ks, "Simpan tanda tangan pribadi" + SKIP, ulang, () ->
                        aturPenjaga(a, full, token, penjaga, r8, kuatAktif, enk, ulang, () ->
                                pastikanAlurKerja(a, full, token, back, () -> a.runOnUiThread(() -> {
                                    android.widget.Toast.makeText(a, "Tanda tangan pribadi terkirim ke repo.",
                                            android.widget.Toast.LENGTH_SHORT).show();
                                    ApkTools.bangunUlang(a, full, token, back);
                                })))));
    }

    /** Penjaga aktif secara bawaan; memilih "tanpa penjaga" menulis penanda yang dibaca alur kerja. */
    private static void aturPenjaga(final Activity a, final String full, final String token, final boolean penjaga,
                                    final boolean r8, final boolean kuat, final boolean enk,
                                    final Runnable back, final Runnable next) {
        final Runnable lanjut = () -> aturR8(a, full, token, r8, kuat, enk, back, next);
        if (penjaga) {
            hapus(a, full, token, TANPA_PENJAGA_PATH, back, lanjut);
        } else {
            tulis(a, full, token, TANPA_PENJAGA_PATH,
                    "Perlindungan tanda tangan dimatikan untuk proyek ini.\n".getBytes(StandardCharsets.UTF_8),
                    "Matikan penjaga tanda tangan" + SKIP, back, lanjut);
        }
    }

    /** Enkripsi string otomatis aktif bawaan; mematikan centang menulis penanda terpisah dari penjaga. */
    private static void aturEnkripsi(final Activity a, final String full, final String token, final boolean enk,
                                     final Runnable back, final Runnable next) {
        if (enk) {
            hapus(a, full, token, TANPA_ENKRIPSI_PATH, back, next);
        } else {
            tulis(a, full, token, TANPA_ENKRIPSI_PATH,
                    "Enkripsi string otomatis dimatikan untuk proyek ini.\n".getBytes(StandardCharsets.UTF_8),
                    "Matikan enkripsi string otomatis" + SKIP, back, next);
        }
    }

    /** Menandai R8 aktif lewat berkas penanda; tidak dicentang = berkas dihapus. */
    private static void aturR8(final Activity a, final String full, final String token, final boolean r8,
                               final boolean kuat, final boolean enk, final Runnable back, final Runnable next) {
        final Runnable lanjut = () -> aturObfuskasi(a, full, token, kuat, enk, back, next);
        if (r8) {
            tulis(a, full, token, R8_PATH, "on\n".getBytes(StandardCharsets.UTF_8),
                    "Aktifkan R8 untuk APK rilis" + SKIP, back, lanjut);
        } else {
            hapus(a, full, token, R8_PATH, back, lanjut);
        }
    }

    /** Menandai obfuskasi lebih kuat lewat berkas penanda; tidak dicentang (atau R8 mati) = berkas dihapus. */
    private static void aturObfuskasi(final Activity a, final String full, final String token, final boolean kuat,
                                      final boolean enk, final Runnable back, final Runnable next) {
        final Runnable lanjut = () -> aturEnkripsi(a, full, token, enk, back, next);
        if (kuat) {
            tulis(a, full, token, OBF_PATH, "on\n".getBytes(StandardCharsets.UTF_8),
                    "Aktifkan obfuskasi lebih kuat" + SKIP, back, lanjut);
        } else {
            hapus(a, full, token, OBF_PATH, back, lanjut);
        }
    }

    // ---------- alur kerja ----------

    /** Pastikan alur kerja di repo mengenal tanda tangan pribadi (perbarui bila buatan aplikasi tetapi versi lama). */
    static void pastikanAlurKerja(final Activity a, final String full, final String token,
                                          final Runnable back, final Runnable next) {
        final String path = ".github/workflows/" + ProjectBuilder.WORKFLOW_NAME;
        final String url = Api.BASE + "/repos/" + full + "/contents/" + encPath(path);
        Api.request("GET", url, token, null, (found, res) -> {
            if (!found) {
                if (res.contains("404") || res.contains("Not Found")) {
                    if (next != null) next.run();
                    return;
                }
                gagal(a, "Gagal memeriksa alur kerja", full, res, back);
                return;
            }
            JSONObject j = Api.parse(res);
            String isi = "";
            try {
                isi = new String(Base64.decode(j.optString("content", ""), Base64.DEFAULT), StandardCharsets.UTF_8);
            } catch (Exception ignored) { }
            if (isi.contains(PENANDA)) {
                if (next != null) next.run();
                return;
            }
            final String sha = j.optString("sha", "");
            final Runnable ganti = () -> {
                String name = full.substring(full.indexOf('/') + 1);
                String slug = ProjectBuilder.slug(name);
                if (slug.isEmpty()) slug = "aplikasi";
                String baru;
                try {
                    baru = ProjectBuilder.workflowFor(a, slug);
                } catch (Exception e) {
                    a.runOnUiThread(() -> ApkTools.error(a, "Gagal memperbarui alur kerja", "Templat tidak terbaca: " + e.getMessage(), back));
                    return;
                }
                JSONObject body = Api.o("message", "Perbarui alur kerja: dukung tanda tangan pribadi" + SKIP,
                        "content", Base64.encodeToString(baru.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP),
                        "sha", sha);
                Api.request("PUT", url, token, body.toString(), (ok, r2) -> {
                    if (ok) {
                        if (next != null) next.run();
                    } else {
                        String info = "Proyek: " + full + "\n\n" + r2;
                        if (r2.toLowerCase().contains("workflow")) {
                            info += "\n\nToken perlu izin workflow. Buat token baru dengan izin repo dan workflow.";
                        }
                        gagal(a, "Gagal memperbarui alur kerja", full, info, back);
                    }
                });
            };
            if (isi.contains("name: Bangun APK Android") || isi.contains("name: Build Android APK")) {
                ganti.run();
                return;
            }
            a.runOnUiThread(() -> ApkTools.dialog(a, "Alur kerja bukan buatan aplikasi",
                    "Berkas " + path + " bukan buatan aplikasi ini, jadi belum bisa memakai tanda tangan pribadi."
                            + "\n\nGanti dengan alur kerja aplikasi? Isi lama tertimpa (masih ada di riwayat). "
                            + "Syarat: proyek Gradle dengan modul app.",
                    ApkTools.list(ApkTools.b("ganti alur kerja dan lanjut", ganti)), "batal", back));
        });
    }

    // ---------- tulis / hapus berkas di repo ----------

    static void tulis(final Activity a, final String full, final String token, final String path,
                              final byte[] data, final String pesan, final Runnable back, final Runnable next) {
        final String url = Api.BASE + "/repos/" + full + "/contents/" + encPath(path);
        Api.request("GET", url, token, null, (found, res) -> {
            if (!found && !res.contains("404") && !res.contains("Not Found")) {
                gagal(a, "Gagal memeriksa " + path, full, res, back);
                return;
            }
            JSONObject body = Api.o("message", pesan, "content", Base64.encodeToString(data, Base64.NO_WRAP));
            if (found) {
                String sha = Api.parse(res).optString("sha", "");
                if (!sha.isEmpty()) {
                    try { body.put("sha", sha); } catch (Exception ignored) { }
                }
            }
            Api.request("PUT", url, token, body.toString(), (ok, r2) -> {
                if (ok) {
                    if (next != null) next.run();
                } else {
                    gagal(a, "Gagal mengirim " + path, full, r2, back);
                }
            });
        });
    }

    private static void hapus(final Activity a, final String full, final String token, final String path,
                              final Runnable back, final Runnable next) {
        final String url = Api.BASE + "/repos/" + full + "/contents/" + encPath(path);
        Api.request("GET", url, token, null, (found, res) -> {
            if (!found) {
                if (res.contains("404") || res.contains("Not Found")) {
                    if (next != null) next.run();
                    return;
                }
                gagal(a, "Gagal memeriksa " + path, full, res, back);
                return;
            }
            String sha = Api.parse(res).optString("sha", "");
            if (sha.isEmpty()) {
                if (next != null) next.run();
                return;
            }
            JSONObject body = Api.o("message", "Hapus tanda tangan pribadi dari repo" + SKIP, "sha", sha);
            Api.request("DELETE", url, token, body.toString(), (ok, r2) -> {
                if (ok || r2.contains("404") || r2.contains("Not Found")) {
                    if (next != null) next.run();
                } else {
                    gagal(a, "Gagal menghapus " + path, full, r2, back);
                }
            });
        });
    }

    // ---------- bantu ----------

    private static String encPath(String path) {
        if (path == null || path.isEmpty()) return "";
        String[] parts = path.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append("/");
            sb.append(Api.enc(parts[i]));
        }
        return sb.toString();
    }

    static void gagal(Activity a, String judul, String full, String res, Runnable back,
                              ApkTools.Btn... extra) {
        a.runOnUiThread(() -> ApkTools.error(a, judul, "Proyek: " + full + "\n\n" + res, back, extra));
    }

    private static byte[] baca(File f) throws Exception {
        if (f == null || !f.exists()) throw new Exception("berkas tidak ada");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }
}
