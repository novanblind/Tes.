package com.novan.filemanagerpro

import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Pembaca RTF (Rich Text Format) tanpa library tambahan. */
object RtfReader {

    private const val MAX_BYTES = 50L * 1024 * 1024

    private val SKIP = setOf(
        "fonttbl", "colortbl", "stylesheet", "info", "header", "headerl", "headerr", "headerf",
        "footer", "footerl", "footerr", "footerf", "object", "themedata", "colorschememapping",
        "datastore", "listtable", "listoverridetable", "rsidtbl", "generator", "latentstyles",
        "xmlnstbl", "fldinst", "footnote", "private", "revtbl", "pgptbl", "mmathPr"
    )

    private class State(var skip: Boolean, var uc: Int, var pict: Boolean, var sheet: Boolean = false)

    fun isRtf(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(5); it.read(b) == 5 && String(b, Charsets.ISO_8859_1) == "{\\rtf" }
    } catch (e: Exception) { false }

    fun parse(f: File): OfficeReader.Doc {
        if (f.length() > MAX_BYTES) throw IllegalStateException("Berkas terlalu besar untuk dibaca")
        val s = String(f.readBytes(), Charsets.ISO_8859_1)
        val doc = OfficeReader.Doc()
        doc.format = "rtf"
        doc.kind = "text"
        doc.typeName = "Dokumen RTF"

        val rows = ArrayList<List<String>>()
        val cells = ArrayList<String>()
        val cellBuf = StringBuilder()
        val cur = StringBuilder()
        val pending = java.io.ByteArrayOutputStream()
        var cpName = "windows-1252"
        var codec: Charset = Charsets.ISO_8859_1
        try { codec = Charset.forName(cpName) } catch (_: Exception) {}

        var inTable = false
        var outline = 9
        var listFlag = false
        var pageAfter = false
        val stack = ArrayList<State>()
        var st = State(false, 1, false)
        var skipCount = 0 // sisa karakter pengganti setelah \u
        val headingStyles = HashMap<Int, Int>()
        val styleBuf = StringBuilder()
        var sheetStyle = -1
        var curStyle = -1

        fun add(b: OfficeReader.Block) {
            if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) { doc.truncated = true; return }
            doc.blocks.add(b)
        }

        fun flushBytes() {
            if (pending.size() == 0) return
            if (!st.skip) cur.append(String(pending.toByteArray(), codec))
            pending.reset()
        }

        fun flushTable() {
            if (cells.isNotEmpty()) { rows.add(ArrayList(cells)); cells.clear() }
            if (rows.isNotEmpty()) {
                if (rows.any { r -> r.any { it.isNotBlank() } }) {
                    doc.tables++
                    for (b in OfficeReader.tableBlocks(rows, doc.tables)) add(b)
                }
                rows.clear()
            }
            cellBuf.setLength(0)
        }

        fun endPara() {
            flushBytes()
            val t = cur.toString().replace(Regex("\\s+"), " ").trim()
            cur.setLength(0)
            if (inTable) {
                if (t.isNotEmpty()) cellBuf.append(t).append(' ')
                return
            }
            flushTable()
            if (t.isNotEmpty()) {
                when {
                    curStyle >= 0 && headingStyles.containsKey(curStyle) -> { doc.headings++; add(OfficeReader.Block(OfficeReader.K_HEADING, headingStyles[curStyle]!!.coerceAtMost(6), t)) }
                    outline in 0..8 -> { doc.headings++; add(OfficeReader.Block(OfficeReader.K_HEADING, (outline + 1).coerceAtMost(6), t)) }
                    listFlag -> { doc.paragraphs++; add(OfficeReader.Block(OfficeReader.K_LIST, 0, t)) }
                    else -> { doc.paragraphs++; add(OfficeReader.Block(OfficeReader.K_PARA, 0, t)) }
                }
            }
            if (pageAfter) {
                add(OfficeReader.Block(OfficeReader.K_PAGE, 0, "Pemisah halaman"))
                pageAfter = false
            }
        }

        var i = 0
        val n = s.length
        var groupStart = false
        while (i < n && !doc.truncated) {
            val c = s[i]
            when (c) {
                '{' -> {
                    flushBytes()
                    stack.add(State(st.skip, st.uc, st.pict, st.sheet))
                    groupStart = true
                    i++
                    continue
                }
                '}' -> {
                    flushBytes()
                    if (st.pict && !st.skip) { /* tak terjadi */ }
                    if (stack.isNotEmpty()) st = stack.removeAt(stack.size - 1)
                    groupStart = false
                    i++
                    continue
                }
                '\\' -> {
                    i++
                    if (i >= n) break
                    val d = s[i]
                    if (!d.isLetter()) {
                        i++
                        when (d) {
                            '\'' -> {
                                if (i + 2 <= n) {
                                    val v = s.substring(i, i + 2).toIntOrNull(16)
                                    i += 2
                                    if (skipCount > 0) skipCount--
                                    else if (v != null && !st.skip) pending.write(v)
                                }
                            }
                            '*' -> { st.skip = true }
                            '~' -> if (!st.skip) { flushBytes(); cur.append(' ') }
                            '-', '_' -> if (!st.skip) { flushBytes(); if (d == '_') cur.append('-') }
                            '\\', '{', '}' -> if (!st.skip) {
                                if (skipCount > 0) skipCount-- else { flushBytes(); cur.append(d) }
                            }
                            '\r', '\n' -> if (!st.skip) { flushBytes(); endPara() }
                        }
                        groupStart = false
                        continue
                    }
                    var j = i
                    while (j < n && s[j].isLetter()) j++
                    val word = s.substring(i, j)
                    var k = j
                    var neg = false
                    if (k < n && s[k] == '-') { neg = true; k++ }
                    val ds = k
                    while (k < n && s[k].isDigit()) k++
                    val param: Int? = if (k > ds) s.substring(ds, k).toLongOrNull()?.let { (if (neg) -it else it).toInt() } else null
                    if (k < n && s[k] == ' ') k++ // spasi pemisah milik kata kontrol
                    i = k
                    if (groupStart && word in SKIP) st.skip = true
                    if (word == "stylesheet") { st.sheet = true; styleBuf.setLength(0); sheetStyle = -1 }
                    groupStart = false
                    when (word) {
                        "ansicpg" -> if (param != null) {
                            try { codec = Charset.forName("windows-$param"); cpName = "windows-$param" } catch (_: Exception) {}
                        }
                        "uc" -> if (param != null) st.uc = param
                        "u" -> if (!st.skip && param != null) {
                            flushBytes()
                            val code = if (param < 0) param + 65536 else param
                            cur.append(code.toChar())
                            skipCount = st.uc
                        }
                        "par", "sect" -> if (!st.skip) endPara()
                        "line" -> if (!st.skip) { flushBytes(); cur.append(' ') }
                        "tab" -> if (!st.skip) { flushBytes(); cur.append(' ') }
                        "emdash" -> if (!st.skip) { flushBytes(); cur.append('—') }
                        "endash" -> if (!st.skip) { flushBytes(); cur.append('–') }
                        "bullet" -> if (!st.skip) { flushBytes(); cur.append('•') }
                        "lquote" -> if (!st.skip) { flushBytes(); cur.append('‘') }
                        "rquote" -> if (!st.skip) { flushBytes(); cur.append('’') }
                        "ldblquote" -> if (!st.skip) { flushBytes(); cur.append('“') }
                        "rdblquote" -> if (!st.skip) { flushBytes(); cur.append('”') }
                        "page" -> if (!st.skip) {
                            flushBytes()
                            if (cur.isBlank() && !inTable) {
                                flushTable()
                                if (doc.blocks.isNotEmpty() && doc.blocks.last().kind != OfficeReader.K_PAGE) {
                                    add(OfficeReader.Block(OfficeReader.K_PAGE, 0, "Pemisah halaman"))
                                }
                            } else pageAfter = true
                        }
                        "s" -> if (param != null) { if (st.sheet) sheetStyle = param else curStyle = param }
                        "pard" -> if (!st.skip) { outline = 9; listFlag = false; curStyle = -1; inTable = false }
                        "intbl" -> if (!st.skip) inTable = true
                        "trowd" -> if (!st.skip) { inTable = true }
                        "outlinelevel" -> if (param != null) outline = param
                        "ls" -> if (param != null && param > 0) listFlag = true
                        "pntext", "listtext" -> { listFlag = true; st.skip = true }
                        "pict" -> { if (!st.skip) { doc.images++; flushBytes(); cur.append(" [Gambar] ") }; st.skip = true }
                        "cell", "nestcell" -> if (!st.skip) {
                            flushBytes()
                            val t = cur.toString().replace(Regex("\\s+"), " ").trim()
                            cur.setLength(0)
                            cells.add((cellBuf.toString() + t).trim())
                            cellBuf.setLength(0)
                        }
                        "row", "nestrow" -> if (!st.skip) {
                            if (cells.isNotEmpty()) { rows.add(ArrayList(cells)); cells.clear() }
                            inTable = true
                        }
                    }
                    continue
                }
                '\r', '\n' -> { i++; continue }
                else -> {
                    groupStart = false
                    i++
                    if (st.sheet) {
                        if (c == ';') {
                            val nm = styleBuf.toString().trim().lowercase()
                            if (sheetStyle >= 0) {
                                if (nm.startsWith("heading ")) headingStyles[sheetStyle] = nm.substring(8).trim().toIntOrNull() ?: 1
                                else if (nm == "title") headingStyles[sheetStyle] = 1
                            }
                            styleBuf.setLength(0)
                            sheetStyle = -1
                        } else if (c.code in 0x20..0x7E) styleBuf.append(c)
                        continue
                    }
                    if (st.skip) continue
                    if (skipCount > 0) { skipCount--; continue }
                    // karakter biasa di berkas 8-bit: perlakukan sebagai byte kodepage
                    if (c.code in 0x20..0x7E) { flushBytes(); if (cur.length < OfficeReader.MAX_BLOCK_CHARS) cur.append(c) }
                    else if (c.code >= 0x80) pending.write(c.code)
                }
            }
        }
        flushBytes()
        if (cur.isNotBlank()) endPara()
        flushTable()
        if (doc.blocks.isEmpty()) {
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Dokumen kosong atau tidak berisi teks."))
        }
        return doc
    }
}

/** Pembaca CSV/TSV: satu "lembar" dengan baris dibacakan memakai nama kolom dari baris pertama. */
object CsvReader {

    private const val MAX_BYTES = 50L * 1024 * 1024
    private const val MAX_COLS = 500

    fun parse(f: File, name: String, tsv: Boolean): OfficeReader.Doc {
        if (f.length() > MAX_BYTES) throw IllegalStateException("Berkas terlalu besar untuk dibaca")
        val raw = f.readBytes()
        val text = decode(raw)
        val delim = if (tsv) '\t' else detect(text)
        val doc = OfficeReader.Doc()
        doc.format = if (tsv) "tsv" else "csv"
        doc.kind = "sheet"
        doc.typeName = if (tsv) "Data TSV" else "Data CSV"
        doc.sheets = 1
        val sr = OfficeReader.SheetRows()

        var rowNum = 0
        var cells = ArrayList<OfficeReader.Cell>()
        val field = StringBuilder()
        var col = 0
        var inQ = false
        var wasQuoted = false

        fun endField() {
            col++
            var t = field.toString().trim()
            if (t.length > OfficeReader.MAX_BLOCK_CHARS) t = t.substring(0, OfficeReader.MAX_BLOCK_CHARS) + "…"
            if (t.isNotEmpty() && col <= MAX_COLS) cells.add(OfficeReader.Cell(col, t, t.toDoubleOrNull() == null))
            field.setLength(0)
            wasQuoted = false
        }

        fun endRow() {
            endField()
            rowNum++
            if (cells.isNotEmpty() && sr.out.size < OfficeReader.MAX_BLOCKS - 10) sr.addRow(rowNum, cells)
            else if (cells.isNotEmpty()) doc.truncated = true
            cells = ArrayList()
            col = 0
        }

        var i = 0
        val n = text.length
        var any = false
        while (i < n) {
            val c = text[i]
            any = true
            if (inQ) {
                if (c == '"') {
                    if (i + 1 < n && text[i + 1] == '"') { field.append('"'); i++ } else inQ = false
                } else field.append(c)
            } else when {
                c == '"' && field.isEmpty() && !wasQuoted -> { inQ = true; wasQuoted = true }
                c == delim -> endField()
                c == '\r' -> { if (i + 1 < n && text[i + 1] == '\n') i++; endRow() }
                c == '\n' -> endRow()
                else -> field.append(c)
            }
            i++
            if (doc.truncated) break
        }
        if (any && (field.isNotEmpty() || cells.isNotEmpty() || col > 0)) endRow()

        doc.headings++
        doc.blocks.add(OfficeReader.Block(OfficeReader.K_HEADING, 1, "Lembar 1 dari 1: $name"))
        if (sr.out.isEmpty()) {
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Lembar ini kosong."))
        } else {
            val range = if (sr.minCol == sr.maxCol) "kolom ${OfficeReader.colLetters(sr.minCol)}"
            else "kolom ${OfficeReader.colLetters(sr.minCol)} sampai ${OfficeReader.colLetters(sr.maxCol)}"
            doc.tables++
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_TABLE, 0, "${sr.out.size} baris berisi data, $range"))
            for (b in sr.out) {
                if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) { doc.truncated = true; break }
                doc.blocks.add(b)
                doc.rows++
            }
        }
        return doc
    }

    /** UTF-8 (dengan atau tanpa BOM) bila sah, selain itu Windows-1252. */
    private fun decode(raw: ByteArray): String {
        var off = 0
        if (raw.size >= 3 && raw[0] == 0xEF.toByte() && raw[1] == 0xBB.toByte() && raw[2] == 0xBF.toByte()) off = 3
        if (raw.size >= 2 && raw[0] == 0xFF.toByte() && raw[1] == 0xFE.toByte()) return String(raw, 2, raw.size - 2, Charsets.UTF_16LE)
        if (raw.size >= 2 && raw[0] == 0xFE.toByte() && raw[1] == 0xFF.toByte()) return String(raw, 2, raw.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(raw, off, raw.size - off)).toString()
        } catch (e: CharacterCodingException) {
            String(raw, try { Charset.forName("windows-1252") } catch (x: Exception) { Charsets.ISO_8859_1 })
        }
    }

    /** Memilih pemisah (koma, titik koma, tab, atau garis tegak) menurut jumlah di beberapa baris awal. */
    private fun detect(text: String): Char {
        val head = text.take(8192).lines().take(10)
        var best = ','
        var bestScore = -1
        for (d in charArrayOf(',', ';', '\t', '|')) {
            var inQ = false
            val counts = ArrayList<Int>()
            var cnt = 0
            for (ln in head) {
                for (ch in ln) { if (ch == '"') inQ = !inQ else if (ch == d && !inQ) cnt++ }
                if (!inQ) { counts.add(cnt); cnt = 0 }
            }
            val nonZero = counts.filter { it > 0 }
            if (nonZero.isEmpty()) continue
            val consistent = nonZero.groupBy { it }.maxOf { it.value.size }
            val score = consistent * 100 + nonZero.first()
            if (score > bestScore) { bestScore = score; best = d }
        }
        return best
    }
}
