package com.pembacauang

/** Pecahan uang kertas rupiah yang dikenali aplikasi. */
enum class Denomination(val value: Int, val spoken: String) {
    SERIBU(1_000, "Seribu"),
    DUA_RIBU(2_000, "Dua ribu"),
    LIMA_RIBU(5_000, "Lima ribu"),
    SEPULUH_RIBU(10_000, "Sepuluh ribu"),
    DUA_PULUH_RIBU(20_000, "Dua puluh ribu"),
    LIMA_PULUH_RIBU(50_000, "Lima puluh ribu"),
    TUJUH_PULUH_LIMA_RIBU(75_000, "Tujuh puluh lima ribu"),
    SERATUS_RIBU(100_000, "Seratus ribu"),
}
