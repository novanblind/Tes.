package com.makroku.automation.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.TriggerEvent

/** Tombol melayang yang bisa digeser; hanya tampil bila ada makro aktif dengan pemicu "Tombol melayang" dan izin tampil di atas aplikasi lain aktif. */
class FloatingButtons(private val ctx: Context, private val engine: MacroEngine) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val views = LinkedHashMap<String, View>()

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun update(labels: Set<String>) {
        if (!Settings.canDrawOverlays(ctx)) {
            removeAll()
            return
        }
        views.keys.filter { it !in labels }.forEach { remove(it) }
        labels.forEach { if (it !in views) add(it, views.size) }
    }

    fun removeAll() {
        views.keys.toList().forEach { remove(it) }
    }

    private fun remove(label: String) {
        views.remove(label)?.let { runCatching { wm.removeView(it) } }
    }

    private fun add(label: String, index: Int) {
        val tv = TextView(ctx).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            contentDescription = "$label, tombol melayang"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            isClickable = true
            setAccessibilityDelegate(object : View.AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: android.view.accessibility.AccessibilityNodeInfo) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info.className = "android.widget.Button"
                }
            })
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1565C0"))
            }
            setOnClickListener {
                engine.dispatch(TriggerEvent("floating", mapOf("label" to label)))
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(160 + index * 68)
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (moved || dx * dx + dy * dy > dp(10) * dp(10)) {
                        moved = true
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) v.performClick()
            }
            true
        }
        runCatching {
            wm.addView(tv, lp)
            views[label] = tv
        }
    }
}
