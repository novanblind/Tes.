package com.novan.filemanagermax

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Pencari berkas duplikat: mengelompokkan berkas berukuran sama lalu membandingkan isinya
 * (MD5). Ketuk baris untuk memilih, lalu hapus. Tiap grup wajib menyisakan satu berkas.
 */
class DuplicatesActivity : AppCompatActivity() {

    private class Item(val group: Int, val file: File)

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var items: MutableList<Item> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.dup_title)

        empty = findViewById(R.id.empty)
        empty.setText(R.string.dup_scanning)
        empty.visibility = View.VISIBLE
        rowAdapter = RowAdapter(onClick = { toggle(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        scan()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun hash(f: File, limit: Long): String? = try {
        val md = MessageDigest.getInstance("MD5")
        val buf = ByteArray(64 * 1024)
        var left = limit
        f.inputStream().use { input ->
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n <= 0) break
                md.update(buf, 0, n)
                left -= n
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }

    private fun scan() {
        val hidden = Prefs.showHidden(this)
        executor.execute {
            val bySize = HashMap<Long, MutableList<File>>()
            try {
                contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.SIZE),
                    "${MediaStore.Files.FileColumns.SIZE}>0", null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val p = c.getString(0) ?: continue
                        if (p.contains("/.FileManagerMaxTrash/") || p.contains("/Android/")) continue
                        if (!hidden && p.contains("/.")) continue
                        val f = File(p)
                        if (!f.isFile) continue
                        bySize.getOrPut(c.getLong(1)) { ArrayList() }.add(f)
                    }
                }
            } catch (e: Exception) {
                // izin belum diberikan: hasil kosong
            }
            val groups = ArrayList<List<File>>()
            for ((_, same) in bySize) {
                if (same.size < 2) continue
                if (Thread.currentThread().isInterrupted) return@execute
                for ((qk, ql) in same.groupBy { hash(it, 64L * 1024) }) {
                    if (qk == null || ql.size < 2) continue
                    for ((fk, fl) in ql.groupBy { hash(it, Long.MAX_VALUE) }) {
                        if (fk != null && fl.size > 1) groups.add(fl.sortedBy { it.lastModified() })
                    }
                }
            }
            groups.sortByDescending { it[0].length() * (it.size - 1) }
            val found = ArrayList<Item>()
            groups.take(300).forEachIndexed { g, l -> l.forEach { found.add(Item(g, it)) } }
            main.post {
                if (isFinishing || isDestroyed) return@post
                items = found
                render()
                say(getString(R.string.dup_found, groupTotal()))
            }
        }
    }

    private fun groupTotal(): Int = items.map { it.group }.distinct().size

    private fun render() {
        val total = groupTotal()
        val order = items.map { it.group }.distinct()
        val rows = items.map { it ->
            val f = it.file
            val num = order.indexOf(it.group) + 1
            val detail = getString(R.string.dup_group, num, total) + ", " +
                Formatter.formatFileSize(this, f.length()) + ", " + (f.parent ?: "")
            Row(R.drawable.ic_copy, f.name, detail, "${f.name}, $detail", it, false)
        }
        rowAdapter.submit(rows)
        empty.setText(R.string.dup_none)
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = getString(R.string.items_count, rows.size)
        invalidateOptionsMenu()
    }

    private fun toggle(i: Int) {
        if (i !in rowAdapter.rows.indices) return
        rowAdapter.setSelected(i, rowAdapter.rows[i].selected != true)
    }

    private fun autoSelect() {
        var lastGroup = -1
        var n = 0
        for (i in items.indices) {
            val keep = items[i].group != lastGroup
            lastGroup = items[i].group
            rowAdapter.setSelected(i, !keep)
            if (!keep) n++
        }
        say(getString(R.string.dup_auto_done, n))
    }

    private fun confirmDelete() {
        val sel = rowAdapter.selectedIndices()
        if (sel.isEmpty()) { say(getString(R.string.dup_none_selected)); return }
        val perGroup = items.groupingBy { it.group }.eachCount()
        val selPerGroup = sel.groupingBy { items[it].group }.eachCount()
        if (selPerGroup.any { (g, n) -> n >= (perGroup[g] ?: 0) }) {
            say(getString(R.string.dup_keep_one)); return
        }
        DeleteDialog.show(this, sel.map { items[it].file }) { toTrash -> doDelete(sel, toTrash) }
    }

    private fun doDelete(sel: List<Int>, toTrash: Boolean) {
        val targets = sel.map { items[it] }
        val dlg = AlertDialog.Builder(this).setMessage(R.string.dup_deleting).setCancelable(false).show()
        executor.execute {
            val done = ArrayList<Item>()
            var fail = 0
            for (t in targets) {
                val ok = if (toTrash) TrashManager.trash(t.file) else t.file.delete()
                if (ok) done.add(t) else fail++
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                items.removeAll(done.toSet())
                val perGroup = items.groupingBy { it.group }.eachCount()
                items = items.filter { (perGroup[it.group] ?: 0) > 1 }.toMutableList()
                render()
                say(getString(if (toTrash) R.string.trash_result else R.string.delete_result, done.size, fail))
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.dup_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_auto -> autoSelect()
            R.id.action_delete_selected -> confirmDelete()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
