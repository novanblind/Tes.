package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.widget.EditText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Situs web lewat GitHub Pages: buat situs pengguna (username.github.io), aktifkan situs di
 * repositori mana pun, ubah sumber, bangun ulang, domain sendiri, paksa HTTPS, matikan.
 */
public class SitusActivity extends Activity {
    private interface Sumber { void pilih(String cabang, String folder); }

    private Ui ui;
    private String token;
    private boolean busy, dariRepo;
    private String folderSitus = "/";

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        String repo = getIntent().getStringExtra("repo");
        if (repo != null && !repo.isEmpty()) {
            dariRepo = true;
            manage(repo);
        } else {
            menu();
        }
    }

    private void kembali() {
        if (dariRepo) finish();
        else menu();
    }

    // ---------- menu ----------

    private void menu() {
        ui = new Ui(this, "Situs web (GitHub Pages)");
        ui.label("Situs web gratis dari repositori GitHub.");
        ui.button("1. Buat situs pengguna (username.github.io)", v -> formPengguna());
        ui.button("2. Situs saya", v -> daftar(true));
        ui.button("3. Aktifkan situs di repositori lain", v -> daftar(false));
        ui.button("4. Panduan singkat", v -> ui.info("Panduan situs web",
                "Situs pengguna: repositori bernama username.github.io. Alamatnya https://username.github.io.\n\n"
                        + "Situs proyek: dari repositori mana pun. Alamatnya https://username.github.io/nama-repo.\n\n"
                        + "Perubahan tampil sekitar 1 sampai 10 menit.\n\n"
                        + "Repositori privat umumnya butuh akun berbayar.", "mengerti", null));
        ui.button("Kembali", v -> finish());
    }

    // ---------- situs pengguna ----------

    private void formPengguna() {
        ui = new Ui(this, "Situs pengguna");
        ui.label("Memeriksa akun...");
        Api.request("GET", Api.BASE + "/user", token, null, (ok, res) -> {
            String login = ok ? Api.str(Api.parse(res), "login") : "";
            if (login.isEmpty()) {
                ui.say(ok ? "Akun tidak terbaca." : "Gagal membaca akun. " + res);
                ui.button("Kembali", v -> menu());
                return;
            }
            form(login);
        });
    }

    private void form(final String login) {
        ui = new Ui(this, "Situs pengguna");
        final String nama = login.toLowerCase(Locale.ROOT) + ".github.io";
        ui.label("Repositori: " + nama + "\nAlamat: https://" + nama);
        final EditText judul = ui.edit("Judul situs", "contoh: Situs " + login, false, login);
        final EditText isi = ui.edit("Perkenalan", "tulis beberapa kalimat", true, "");
        ui.button("Buat situs", v -> {
            if (busy) return;
            buatPengguna(login, nama, judul.getText().toString().trim(), isi.getText().toString());
        });
        ui.button("Kembali", v -> menu());
    }

    private static String cabangDari(JSONObject o) {
        String b = Api.str(o, "default_branch");
        return b.isEmpty() ? "main" : b;
    }

    private void buatPengguna(final String login, final String nama, final String judul, final String isi) {
        final String full = login + "/" + nama;
        busy = true;
        ui.progress("Memeriksa repositori...");
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
            if (ok) {
                final String br = cabangDari(Api.parse(res));
                busy = false;
                ui.confirm("Repositori sudah ada", nama + " sudah ada. Halaman utamanya akan diganti. Lanjutkan?",
                        "lanjut", () -> {
                            busy = true;
                            isiDanAktifkan(full, br, judul, isi);
                        });
                return;
            }
            ui.progress("Membuat repositori...");
            String body = Api.o("name", nama, "description", "Situs web saya", "private", false,
                    "auto_init", true).toString();
            Api.request("POST", Api.BASE + "/user/repos", token, body, (ok2, res2) -> {
                if (!ok2) {
                    busy = false;
                    ui.say("Gagal membuat repositori. " + res2);
                    return;
                }
                ReposActivity.invalidate();
                final String br = cabangDari(Api.parse(res2));
                // Beri GitHub waktu menyiapkan repositori baru.
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> isiDanAktifkan(full, br, judul, isi), 2000);
            });
        });
    }

    private void isiDanAktifkan(final String full, final String cabang, String judul, String isi) {
        ui.progress("Membuat halaman utama...");
        tulisIndex(full, "/", judul, isi, (ok, msg) -> {
            if (!ok) {
                busy = false;
                ui.say("Gagal membuat halaman utama. " + msg);
                return;
            }
            ui.progress("Mengaktifkan situs...");
            aktifkan(full, cabang, "/", (ok2, msg2) -> {
                busy = false;
                if (!ok2) {
                    ui.say("Situs belum aktif. " + msg2);
                    return;
                }
                ReposActivity.invalidate();
                ui.say("Situs dibuat. Tampil sekitar 1 sampai 10 menit.");
                manage(full);
            });
        });
    }

    // ---------- daftar repositori ----------

    private void daftar(final boolean denganPages) {
        ui = new Ui(this, denganPages ? "Situs saya" : "Aktifkan situs");
        ui.label("Memuat repositori...");
        final JSONArray all = new JSONArray();
        muat(1, all, () -> tampilDaftar(denganPages, all));
    }

    private void muat(final int n, final JSONArray all, final Runnable selesai) {
        Api.request("GET", Api.BASE + "/user/repos?sort=updated&direction=desc&per_page=100"
                + "&affiliation=owner&page=" + n, token, null, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal memuat. " + res);
                ui.button("Kembali", v -> menu());
                return;
            }
            JSONArray a = Api.parseArr(res);
            for (int i = 0; i < a.length(); i++) all.put(a.opt(i));
            if (a.length() == 100 && n < 10) {
                muat(n + 1, all, selesai);
                return;
            }
            selesai.run();
        });
    }

    private void tampilDaftar(boolean denganPages, JSONArray all) {
        ui = new Ui(this, denganPages ? "Situs saya" : "Aktifkan situs");
        int jumlah = 0;
        for (int i = 0; i < all.length(); i++) {
            final JSONObject r = all.optJSONObject(i);
            if (r == null || r.optBoolean("has_pages", false) != denganPages) continue;
            final String full = r.optString("full_name", "");
            if (full.isEmpty()) continue;
            jumlah++;
            ui.button(r.optString("name", full) + (r.optBoolean("private", false) ? ", privat" : ""),
                    v -> manage(full));
        }
        if (jumlah == 0) {
            ui.label(denganPages ? "Belum ada repositori dengan situs aktif."
                    : "Semua repositori sudah punya situs.");
        }
        ui.button("Kembali", v -> menu());
    }

    // ---------- kelola satu situs ----------

    private void manage(final String full) {
        ui = new Ui(this, "Situs web: " + full);
        ui.label("Memuat status situs...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/pages", token, null, (ok, res) -> {
            if (ok) {
                aktif(full, Api.parse(res));
                return;
            }
            if (res.contains("Kode: 404")) {
                belumAktif(full);
                return;
            }
            ui.say("Gagal memuat status. " + res);
            ui.button("Coba lagi", v -> manage(full));
            ui.button("Kembali", v -> kembali());
        });
    }

    private void belumAktif(final String full) {
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
            final String br = ok ? cabangDari(Api.parse(res)) : "main";
            ui = new Ui(this, "Situs web: " + full);
            ui.label("Situs belum aktif di repositori ini.");
            ui.button("1. Aktifkan situs (cabang " + br + ", folder utama)", v -> aktifkanLalu(full, br, "/"));
            ui.button("2. Aktifkan, pilih cabang dan folder",
                    v -> pilihSumber(full, (b, p) -> aktifkanLalu(full, b, p)));
            ui.button("3. Buat halaman utama dulu (index.html)", v -> formIndex(full, "/"));
            ui.button("Kembali", v -> kembali());
        });
    }

    private void aktifkanLalu(final String full, String cabang, String folder) {
        ui.progress("Mengaktifkan situs...");
        aktifkan(full, cabang, folder, (ok, msg) -> {
            if (!ok) {
                ui.say("Gagal mengaktifkan situs. " + msg);
                return;
            }
            ReposActivity.invalidate();
            ui.say("Situs aktif. Tampil sekitar 1 sampai 10 menit.");
            manage(full);
        });
    }

    private void aktif(final String full, final JSONObject p) {
        final String url = Api.str(p, "html_url");
        final JSONObject src = p.optJSONObject("source");
        final boolean actions = "workflow".equals(Api.str(p, "build_type"));
        final String cabang = src == null ? "" : Api.str(src, "branch");
        final String path = src == null ? "" : Api.str(src, "path");
        final String folder = path.isEmpty() ? "/" : path;
        folderSitus = folder;
        final String cname = Api.str(p, "cname");
        final boolean https = p.optBoolean("https_enforced", false);
        ui = new Ui(this, "Situs web: " + full);
        ui.label("Alamat: " + url + "\nStatus: " + statusSitus(Api.str(p, "status"))
                + "\nSumber: " + (actions ? "GitHub Actions" : cabang + ", folder " + folder)
                + "\nDomain sendiri: " + (cname.isEmpty() ? "tidak ada" : cname)
                + "\nPaksa HTTPS: " + (https ? "ya" : "tidak"));
        int n = 1;
        ui.button((n++) + ". Salin tautan situs", v -> Ui.copy(this, "Tautan situs", url));
        ui.button((n++) + ". Bagikan tautan situs", v -> Ui.share(this, "Situs: " + full, url));
        ui.button((n++) + ". Buka situs di browser", v -> Ui.browse(this, url));
        ui.button((n++) + ". Cek status pembangunan situs", v -> cekBangun(full));
        ui.button((n++) + ". Bangun ulang situs", v -> bangunUlang(full));
        ui.button((n++) + ". Buat atau ganti halaman utama (index.html)", v -> formIndex(full, folder));
        ui.button((n++) + ". Buat halaman 404 (halaman tidak ditemukan)", v -> form404(full, folder, cname));
        if (!actions) {
            ui.button((n++) + ". Ubah cabang dan folder sumber",
                    v -> pilihSumber(full, (b, pt) -> ubahSumber(full, b, pt)));
        }
        ui.button((n++) + ". Domain sendiri", v -> domain(full, cname));
        ui.button((n++) + ". Paksa HTTPS: " + (https ? "aktif, ketuk untuk matikan" : "mati, ketuk untuk aktifkan"),
                v -> paksaHttps(full, !https));
        ui.button((n++) + ". Kelola berkas repositori", v -> startActivity(new Intent(this, BrowseActivity.class)
                .putExtra("repo", full).putExtra("path", "")
                .putExtra("name", full.substring(full.indexOf('/') + 1))));
        ui.button((n++) + ". Matikan situs", Ui.DANGER, v -> ui.confirm("Matikan situs?",
                "Situs tidak tampil lagi. Berkas di repositori tetap ada.", "matikan", () -> matikan(full)));
        ui.button("Kembali", v -> kembali());
    }

    private static String statusSitus(String s) {
        if ("built".equals(s)) return "Sudah tampil";
        if ("building".equals(s)) return "Sedang dibangun";
        if ("queued".equals(s)) return "Menunggu giliran";
        if ("errored".equals(s)) return "Gagal dibangun";
        return s.isEmpty() ? "Belum diketahui" : s;
    }

    // ---------- aksi ----------

    /** Aktifkan Pages; bila sudah aktif (409), ubah sumbernya. */
    private void aktifkan(String full, String cabang, String folder, final Api.Callback cb) {
        final String body = Api.o("source", Api.o("branch", cabang, "path", folder)).toString();
        final String url = Api.BASE + "/repos/" + full + "/pages";
        Api.request("POST", url, token, body, (ok, res) -> {
            if (ok) {
                cb.done(true, "");
                return;
            }
            if (res.contains("Kode: 409")) {
                Api.request("PUT", url, token, body, (ok2, res2) -> cb.done(ok2, ok2 ? "" : res2));
                return;
            }
            cb.done(false, res + "\nBila repositori privat, Pages umumnya butuh akun berbayar.");
        });
    }

    private void ubahSumber(final String full, String cabang, String folder) {
        ui.progress("Mengubah sumber...");
        String body = Api.o("source", Api.o("branch", cabang, "path", folder)).toString();
        Api.request("PUT", Api.BASE + "/repos/" + full + "/pages", token, body, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal mengubah sumber. " + res);
                return;
            }
            ui.say("Sumber diubah.");
            manage(full);
        });
    }

    private void pilihSumber(final String full, final Sumber cb) {
        ui.progress("Memuat daftar cabang...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/branches?per_page=100", token, null, (ok, res) -> {
            JSONArray a = ok ? Api.parseArr(res) : new JSONArray();
            if (a.length() == 0) {
                ui.say("Daftar cabang tidak terbaca." + (ok ? "" : " " + res));
                return;
            }
            final String[] nama = new String[a.length()];
            for (int i = 0; i < nama.length; i++) {
                JSONObject o = a.optJSONObject(i);
                nama[i] = o == null ? "" : o.optString("name", "");
            }
            AlertDialog d = new AlertDialog.Builder(this).setTitle("Pilih cabang")
                    .setItems(nama, (x, which) -> pilihFolder(nama[which], cb))
                    .setNegativeButton("batal", null).show();
            ui.fix(d);
        });
    }

    private void pilihFolder(final String cabang, final Sumber cb) {
        final String[] f = {"folder utama (/)", "folder docs (/docs)"};
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Pilih folder")
                .setItems(f, (x, which) -> cb.pilih(cabang, which == 0 ? "/" : "/docs"))
                .setNegativeButton("batal", null).show();
        ui.fix(d);
    }

    private void cekBangun(final String full) {
        ui.progress("Memeriksa pembangunan situs...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/pages/builds/latest", token, null, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal memeriksa. " + res);
                return;
            }
            JSONObject b = Api.parse(res);
            JSONObject er = b.optJSONObject("error");
            String pesan = er == null ? "" : Api.str(er, "message");
            String msg = "Status: " + statusSitus(Api.str(b, "status"));
            if (!pesan.isEmpty()) msg += "\nKesalahan: " + pesan;
            String t = Api.str(b, "updated_at");
            if (!t.isEmpty()) msg += "\nDiperbarui: " + t.replace('T', ' ').replace("Z", " UTC");
            ui.info("Status pembangunan situs", msg, "tutup", null);
        });
    }

    private void bangunUlang(final String full) {
        ui.progress("Memulai pembangunan ulang...");
        Api.request("POST", Api.BASE + "/repos/" + full + "/pages/builds", token, null, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal membangun ulang. " + res);
                return;
            }
            ui.say("Pembangunan ulang dimulai. Tunggu 1 sampai 10 menit.");
        });
    }

    private void domain(final String full, String sekarang) {
        ui.ask("Domain sendiri", "Contoh: situs.contoh.com. Kosongkan untuk menghapus.", "Domain", sekarang,
                "simpan", t -> {
                    JSONObject body = new JSONObject();
                    try {
                        body.put("cname", t.isEmpty() ? JSONObject.NULL : t);
                    } catch (Exception ignored) { }
                    ui.progress("Menyimpan domain...");
                    Api.request("PUT", Api.BASE + "/repos/" + full + "/pages", token, body.toString(),
                            (ok, res) -> {
                                if (!ok) {
                                    ui.say("Gagal menyimpan domain. " + res);
                                    return;
                                }
                                ui.say(t.isEmpty() ? "Domain dihapus."
                                        : "Domain disimpan. Atur DNS domain Anda agar mengarah ke GitHub.");
                                manage(full);
                            });
                });
    }

    private void paksaHttps(final String full, boolean aktif) {
        ui.progress("Menyimpan...");
        String body = Api.o("https_enforced", aktif).toString();
        Api.request("PUT", Api.BASE + "/repos/" + full + "/pages", token, body, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal mengubah HTTPS. " + res);
                return;
            }
            ui.say(aktif ? "Paksa HTTPS diaktifkan." : "Paksa HTTPS dimatikan.");
            manage(full);
        });
    }

    private void matikan(final String full) {
        ui.progress("Mematikan situs...");
        Api.request("DELETE", Api.BASE + "/repos/" + full + "/pages", token, null, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal mematikan situs. " + res);
                return;
            }
            ReposActivity.invalidate();
            ui.say("Situs dimatikan.");
            manage(full);
        });
    }

    // ---------- halaman utama (index.html) ----------

    private static final String[] TEMPLAT = {"Polos", "Profil pribadi", "Daftar tautan"};

    private void formIndex(final String full, final String folder) {
        final String path = "/docs".equals(folder) ? "docs/index.html" : "index.html";
        ui = new Ui(this, "Halaman utama");
        ui.label("Membuat berkas " + path + ".");
        final Ui.Choice tpl = ui.choice("Templat", TEMPLAT, 0);
        final EditText judul = ui.edit("Judul situs (atau nama Anda)", "contoh: Situs saya", false, "");
        final EditText isi = ui.edit("Perkenalan (untuk Daftar tautan: satu tautan per baris, format Nama | alamat)",
                "tulis beberapa kalimat", true, "");
        final EditText kontak = ui.edit("Kontak (opsional, untuk Profil pribadi)",
                "email atau tautan", false, "");
        ui.button("Simpan halaman utama", v -> {
            if (busy) return;
            final String j = judul.getText().toString().trim();
            final String t = isi.getText().toString();
            final int ti = tpl.index;
            final String kt = kontak.getText().toString().trim();
            ui.progress("Memeriksa berkas...");
            Api.request("GET", Api.BASE + "/repos/" + full + "/contents/" + Api.enc(path), token, null,
                    (ok, res) -> {
                        if (ok) {
                            ui.confirm("Ganti halaman utama?", path + " sudah ada dan akan diganti.", "ganti",
                                    () -> simpanIndex(full, folder, j, t, ti, kt));
                        } else {
                            simpanIndex(full, folder, j, t, ti, kt);
                        }
                    });
        });
        ui.button("Kembali", v -> manage(full));
    }

    private void simpanIndex(final String full, String folder, String judul, String isi, int templat, String kontak) {
        busy = true;
        ui.progress("Menyimpan...");
        tulisIndex(full, folder, judul, isi, templat, kontak, (ok, msg) -> {
            busy = false;
            if (!ok) {
                ui.say("Gagal menyimpan. " + msg);
                return;
            }
            ui.say("Halaman utama disimpan. Tampil sekitar 1 sampai 10 menit.");
            manage(full);
        });
    }

    /** Tulis index.html (baru atau ganti) ke folder utama atau /docs, polos. */
    private void tulisIndex(final String full, String folder, final String judul, final String isi,
                            final Api.Callback cb) {
        tulisIndex(full, folder, judul, isi, 0, "", cb);
    }

    private void tulisIndex(final String full, String folder, final String judul, final String isi,
                            final int templat, final String kontak, final Api.Callback cb) {
        final String path = "/docs".equals(folder) ? "docs/index.html" : "index.html";
        tulisBerkas(full, path, halamanTemplat(templat, judul, isi, kontak),
                "Buat halaman utama dari aplikasi", cb);
    }

    /** Tulis satu berkas teks ke repo (baru atau ganti). */
    private void tulisBerkas(final String full, final String path, final String isi, final String pesan,
                             final Api.Callback cb) {
        final String url = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(path);
        Api.request("GET", url, token, null, (ok, res) -> {
            String sha = ok ? Api.str(Api.parse(res), "sha") : "";
            String isiBerkas = Base64.encodeToString(isi.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            JSONObject body = Api.o("message", pesan, "content", isiBerkas);
            if (!sha.isEmpty()) {
                try { body.put("sha", sha); } catch (Exception ignored) { }
            }
            Api.request("PUT", url, token, body.toString(), (ok2, res2) -> cb.done(ok2, ok2 ? "" : res2));
        });
    }

    // ---------- halaman 404 ----------

    private void form404(final String full, final String folder, final String cname) {
        ui = new Ui(this, "Halaman 404");
        ui.label("Halaman 404 tampil saat pengunjung membuka alamat yang tidak ada di situs Anda. "
                + "Berkasnya 404.html di " + ("/docs".equals(folder) ? "folder docs." : "folder utama."));
        final EditText pesan = ui.edit("Pesan", "", false, "Halaman yang Anda cari tidak ditemukan.");
        ui.button("Simpan halaman 404", v -> {
            if (busy) return;
            busy = true;
            ui.progress("Menyimpan...");
            final String nama = full.substring(full.indexOf('/') + 1);
            final String beranda = (!cname.isEmpty() || nama.toLowerCase(Locale.ROOT).endsWith(".github.io"))
                    ? "/" : "/" + nama + "/";
            final String path = "/docs".equals(folder) ? "docs/404.html" : "404.html";
            tulisBerkas(full, path, halaman404(pesan.getText().toString().trim(), beranda),
                    "Buat halaman 404 dari aplikasi", (ok, msg) -> {
                        busy = false;
                        if (!ok) {
                            ui.say("Gagal menyimpan. " + msg);
                            return;
                        }
                        ui.say("Halaman 404 disimpan. Tampil sekitar 1 sampai 10 menit.");
                        manage(full);
                    });
        });
        ui.button("Kembali", v -> manage(full));
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /** Halaman awal sederhana: judul, paragraf, dan tata letak ramah pembaca layar. */
    private static String halaman(String judul, String isi) {
        String j = judul.isEmpty() ? "Situs saya" : judul;
        StringBuilder p = new StringBuilder();
        for (String para : isi.replace("\r", "").split("\n+")) {
            String t = para.trim();
            if (!t.isEmpty()) p.append("    <p>").append(esc(t)).append("</p>\n");
        }
        return "<!DOCTYPE html>\n<html lang=\"id\">\n<head>\n"
                + "  <meta charset=\"utf-8\">\n"
                + "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
                + "  <title>" + esc(j) + "</title>\n"
                + "  <style>body{font-family:sans-serif;max-width:40rem;margin:2rem auto;padding:0 1rem;"
                + "line-height:1.6;font-size:1.2rem}</style>\n"
                + "</head>\n<body>\n  <main>\n    <h1>" + esc(j) + "</h1>\n" + p + "  </main>\n</body>\n</html>\n";
    }

    private static final String GAYA = "  <style>:root{color-scheme:light dark}"
            + "body{font-family:sans-serif;max-width:40rem;margin:2rem auto;padding:0 1rem;line-height:1.6;font-size:1.2rem}"
            + "a{color:inherit}.tautan a{display:block;padding:.8rem 1rem;margin:.6rem 0;border:2px solid;"
            + "border-radius:.5rem;text-decoration:none}</style>\n";

    private static String kepala(String judul) {
        return "<!DOCTYPE html>\n<html lang=\"id\">\n<head>\n"
                + "  <meta charset=\"utf-8\">\n"
                + "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
                + "  <title>" + esc(judul) + "</title>\n" + GAYA + "</head>\n<body>\n";
    }

    private static String paragraf(String isi) {
        StringBuilder p = new StringBuilder();
        for (String para : isi.replace("\r", "").split("\n+")) {
            String t = para.trim();
            if (!t.isEmpty()) p.append("    <p>").append(esc(t)).append("</p>\n");
        }
        return p.toString();
    }

    private static boolean amanTautan(String u) {
        String l = u.toLowerCase(Locale.ROOT);
        return l.startsWith("https://") || l.startsWith("http://") || l.startsWith("mailto:");
    }

    /** 0 = polos, 1 = profil pribadi, 2 = daftar tautan (tiap baris: Nama | alamat). */
    private static String halamanTemplat(int templat, String judul, String isi, String kontak) {
        if (templat == 1) {
            String j = judul.isEmpty() ? "Profil saya" : judul;
            StringBuilder sb = new StringBuilder(kepala(j));
            sb.append("  <header>\n    <h1>").append(esc(j)).append("</h1>\n  </header>\n  <main>\n");
            sb.append("    <section aria-labelledby=\"tentang\">\n    <h2 id=\"tentang\">Tentang saya</h2>\n")
                    .append(paragraf(isi)).append("    </section>\n");
            if (!kontak.isEmpty()) {
                String href = kontak.contains("@") && !kontak.contains("://") && !kontak.toLowerCase(Locale.ROOT).startsWith("mailto:")
                        ? "mailto:" + kontak : kontak;
                sb.append("    <section aria-labelledby=\"kontak\">\n    <h2 id=\"kontak\">Kontak</h2>\n    <p>");
                if (amanTautan(href)) {
                    sb.append("<a href=\"").append(esc(href)).append("\">").append(esc(kontak)).append("</a>");
                } else {
                    sb.append(esc(kontak));
                }
                sb.append("</p>\n    </section>\n");
            }
            return sb.append("  </main>\n</body>\n</html>\n").toString();
        }
        if (templat == 2) {
            String j = judul.isEmpty() ? "Tautan saya" : judul;
            StringBuilder sb = new StringBuilder(kepala(j));
            sb.append("  <main>\n    <h1>").append(esc(j)).append("</h1>\n");
            sb.append("    <nav class=\"tautan\" aria-label=\"Daftar tautan\">\n");
            for (String baris : isi.replace("\r", "").split("\n")) {
                String t = baris.trim();
                if (t.isEmpty()) continue;
                String nama = t, url = "";
                int k = t.indexOf('|');
                if (k >= 0) {
                    nama = t.substring(0, k).trim();
                    url = t.substring(k + 1).trim();
                } else if (amanTautan(t)) {
                    url = t;
                }
                if (nama.isEmpty()) nama = url;
                if (!url.isEmpty() && amanTautan(url)) {
                    sb.append("      <a href=\"").append(esc(url)).append("\">").append(esc(nama)).append("</a>\n");
                } else {
                    sb.append("      <p>").append(esc(nama)).append("</p>\n");
                }
            }
            return sb.append("    </nav>\n  </main>\n</body>\n</html>\n").toString();
        }
        return halaman(judul, isi);
    }

    private static String halaman404(String pesan, String beranda) {
        String m = pesan.isEmpty() ? "Halaman yang Anda cari tidak ditemukan." : pesan;
        return kepala("Halaman tidak ditemukan")
                + "  <main>\n    <h1>Halaman tidak ditemukan</h1>\n    <p>" + esc(m) + "</p>\n"
                + "    <p><a href=\"" + esc(beranda) + "\">Kembali ke beranda</a></p>\n"
                + "  </main>\n</body>\n</html>\n";
    }
}
