package com.makroku.automation.engine

import com.makroku.automation.model.AppJson
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/** Alat teks, hitung, dan JSON untuk aksi variabel. */
object TextTools {

    fun textOp(src: String, op: String, arg: String, arg2: String): String = when (op) {
        "upper" -> src.uppercase()
        "lower" -> src.lowercase()
        "trim" -> src.trim()
        "length" -> src.length.toString()
        "replace" -> if (arg.isEmpty()) src else src.replace(arg, arg2)
        "substring" -> {
            val from = (arg.trim().toIntOrNull() ?: 0).coerceIn(0, src.length)
            val to = (arg2.trim().toIntOrNull() ?: src.length).coerceIn(from, src.length)
            src.substring(from, to)
        }
        "regex" -> {
            val m = Regex(arg).find(src)
            if (m == null) "" else if (m.groupValues.size > 1) m.groupValues[1] else m.value
        }
        "split" -> {
            val idx = arg2.trim().toIntOrNull() ?: 0
            if (arg.isEmpty()) src else src.split(arg).getOrNull(idx).orEmpty()
        }
        "digits" -> src.filter { it.isDigit() }
        "urlencode" -> java.net.URLEncoder.encode(src, "UTF-8")
        "urldecode" -> java.net.URLDecoder.decode(src, "UTF-8")
        "base64enc" -> java.util.Base64.getEncoder().encodeToString(src.toByteArray(Charsets.UTF_8))
        "base64dec" -> String(java.util.Base64.getDecoder().decode(src.trim()), Charsets.UTF_8)
        "md5" -> hash("MD5", src)
        "sha256" -> hash("SHA-256", src)
        "reverse" -> src.reversed()
        "capitalize" -> src.split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
        "count" -> if (arg.isEmpty()) "0" else (src.split(arg).size - 1).toString()
        else -> src
    }

    private fun hash(algo: String, src: String): String =
        java.security.MessageDigest.getInstance(algo).digest(src.toByteArray(Charsets.UTF_8))
            .joinToString("") { b -> "%02x".format(b) }

    /** Hasil operasi daftar: items = daftar baru (null bila tidak berubah), out = nilai untuk disimpan (null bila tidak ada). */
    class ListResult(val items: List<String>?, val out: String?)

    /** Daftar ala array Tasker. Daftar disimpan sebagai teks, satu butir per baris. Nomor butir mulai 1, negatif = dari belakang. */
    fun listOp(src: String, op: String, value: String, separator: String, index: Int): ListResult {
        val items: MutableList<String> = if (src.isEmpty()) mutableListOf() else src.split("\n").toMutableList()
        val v = value.replace("\r", "").replace("\n", " ")
        val sep = separator.replace("\\n", "\n").ifEmpty { "," }
        fun pos(): Int = when {
            index > 0 -> index - 1
            index < 0 -> items.size + index
            else -> -1
        }
        fun nums(): List<Double> = items.mapNotNull { it.trim().toDoubleOrNull() }
        return when (op) {
            "push" -> { items.add(v); ListResult(items, null) }
            "unshift" -> { items.add(0, v); ListResult(items, null) }
            "insert" -> {
                val p = if (index > 0) (index - 1).coerceAtMost(items.size) else if (index < 0) (items.size + index + 1).coerceIn(0, items.size) else 0
                items.add(p, v)
                ListResult(items, null)
            }
            "pop" -> {
                if (items.isEmpty()) error("Daftar kosong")
                val x = items.removeAt(items.size - 1)
                ListResult(items, x)
            }
            "shift" -> {
                if (items.isEmpty()) error("Daftar kosong")
                val x = items.removeAt(0)
                ListResult(items, x)
            }
            "remove_at" -> {
                val p = pos()
                if (p !in items.indices) error("Nomor butir di luar daftar")
                val x = items.removeAt(p)
                ListResult(items, x)
            }
            "remove_value" -> {
                val ada = items.remove(v)
                ListResult(items, ada.toString())
            }
            "get" -> {
                val p = pos()
                ListResult(null, if (p in items.indices) items[p] else "")
            }
            "set_at" -> {
                val p = pos()
                if (p !in items.indices) error("Nomor butir di luar daftar")
                items[p] = v
                ListResult(items, null)
            }
            "size" -> ListResult(null, items.size.toString())
            "clear" -> ListResult(emptyList(), null)
            "join" -> ListResult(null, items.joinToString(sep))
            "split" -> ListResult(v.split(sep).map { it.trim() }.filter { it.isNotEmpty() }, null)
            "sort", "sort_desc" -> {
                val angka = items.isNotEmpty() && items.all { it.trim().toDoubleOrNull() != null }
                val asc = if (angka) items.sortedBy { it.trim().toDouble() } else items.sortedBy { it.lowercase() }
                ListResult(if (op == "sort") asc else asc.reversed(), null)
            }
            "reverse" -> ListResult(items.reversed(), null)
            "unique" -> ListResult(items.distinct(), null)
            "shuffle" -> ListResult(items.shuffled(), null)
            "contains" -> ListResult(null, items.contains(v).toString())
            "index_of" -> ListResult(null, (items.indexOf(v) + 1).toString())
            "sum" -> ListResult(null, formatNum(nums().sum()))
            "min" -> ListResult(null, nums().minOrNull()?.let { formatNum(it) } ?: "")
            "max" -> ListResult(null, nums().maxOrNull()?.let { formatNum(it) } ?: "")
            "average" -> ListResult(null, nums().takeIf { it.isNotEmpty() }?.let { formatNum(it.average()) } ?: "")
            else -> error("Operasi daftar tidak dikenal: $op")
        }
    }

    fun formatNum(v: Double): String =
        if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else java.math.BigDecimal(v).setScale(6, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

    /** Ambil nilai dari JSON; jalur dipisah titik, angka = indeks larik. Jalur kosong = seluruh JSON. */
    fun jsonPick(json: String, path: String): String {
        var cur: JsonElement = AppJson.parseToJsonElement(json)
        for (seg in path.split(".").map { it.trim() }.filter { it.isNotEmpty() }) {
            val c = cur
            cur = when (c) {
                is JsonObject -> c[seg] ?: error("Kunci '$seg' tidak ada di JSON")
                is JsonArray -> {
                    val i = seg.toIntOrNull() ?: error("'$seg' bukan indeks larik")
                    c.getOrNull(i) ?: error("Indeks $i di luar larik")
                }
                else -> error("Jalur '$seg' tidak bisa dibuka (bukan objek/larik)")
            }
        }
        val r = cur
        return if (r is JsonPrimitive) r.content else r.toString()
    }

    /** Penghitung ekspresi sederhana: + - * / % dan kurung. */
    fun eval(expr: String): Double {
        val s = expr.replace(" ", "").replace(",", ".")
        if (s.isEmpty()) error("Ekspresi kosong")
        val p = Parser(s)
        val v = p.parseExpr()
        if (p.pos != s.length) error("Ekspresi tidak valid di posisi ${p.pos + 1}")
        return v
    }

    private class Parser(val s: String) {
        var pos = 0

        fun parseExpr(): Double {
            var v = parseTerm()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val r = parseTerm()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun parseTerm(): Double {
            var v = parseFactor()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/' || s[pos] == '%')) {
                val op = s[pos++]
                val r = parseFactor()
                if ((op == '/' || op == '%') && r == 0.0) error("Pembagian dengan nol")
                v = when (op) {
                    '*' -> v * r
                    '/' -> v / r
                    else -> v % r
                }
            }
            return v
        }

        fun parseFactor(): Double {
            if (pos >= s.length) error("Ekspresi tidak lengkap")
            val c = s[pos]
            if (c == '-') { pos++; return -parseFactor() }
            if (c == '+') { pos++; return parseFactor() }
            if (c == '(') {
                pos++
                val v = parseExpr()
                if (pos >= s.length || s[pos] != ')') error("Kurung tutup hilang")
                pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) error("Karakter tidak dikenal '${s[pos]}'")
            return s.substring(start, pos).toDoubleOrNull() ?: error("Angka tidak valid '${s.substring(start, pos)}'")
        }
    }
}
