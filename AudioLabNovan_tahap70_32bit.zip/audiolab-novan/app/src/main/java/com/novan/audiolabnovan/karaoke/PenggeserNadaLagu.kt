package com.novan.audiolabnovan.karaoke

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.PI
import kotlin.math.sqrt

/**
 * Pengubah nada dasar (kunci) lagu pengiring, -6 sampai +6 setengah nada, tanpa mengubah tempo (tahap 48).
 * Penyanyi bisa menurunkan atau menaikkan kunci lagu supaya pas dengan jangkauan suaranya.
 *
 * Caranya dua langkah: (1) regang waktu dengan WSOLA (potongan 2.048 sampel yang disambung di titik paling
 * mirip, jadi nada tidak berubah), (2) ubah kecepatan baca dengan interpolasi linear (nada berubah, panjang
 * ikut berubah). Urutan dipilih supaya data antara selalu lebih pendek dari lagu asli: naik = ubah kecepatan
 * dulu lalu regang; turun = regang dulu lalu ubah kecepatan. Hasil akhir tepat sepanjang lagu asli, jadi
 * lirik dan jam putar tidak bergeser. Hasil ditulis kembali ke larik yang sama.
 *
 * Murni hitungan, tanpa kelas Android.
 */
object PenggeserNadaLagu {
    const val MAKS = 6

    private const val N = 2_048            // panjang potongan WSOLA (sampel)
    private const val HS = N / 2            // loncatan keluaran
    private const val DEC = 8               // pengecilan untuk pencarian kasar
    private const val CARI = 256            // pencarian kasar: plus minus sampel
    private const val CARI_HALUS = 8        // pencarian halus pada laju penuh: plus minus sampel
    private const val PANJANG_HALUS = 512   // panjang pembanding pencarian halus

    /**
     * Menggeser nada [pcm] (stereo bergantian) sebanyak [setengahNada]. Mengembalikan true bila berhasil.
     * Bila false karena dibatalkan atau lagu terlalu pendek, isi [pcm] tidak boleh dipakai bila dibatalkan
     * di tengah jalan (pemanggil membuang hasilnya); bila lagu terlalu pendek, isinya tidak diubah.
     */
    fun proses(pcm: ShortArray, setengahNada: Int, batal: () -> Boolean): Boolean {
        val n = setengahNada.coerceIn(-MAKS, MAKS)
        if (n == 0) return true
        val frame = pcm.size / 2
        if (frame < N * 8) return false
        val r = Math.pow(2.0, n / 12.0)
        val frameTengah = max(N * 2, Math.round(frame / max(r, 1.0 / r)).toInt())
        val tengah = ShortArray(frameTengah * 2)
        return if (r > 1.0) {
            ubahKecepatan(pcm, tengah)          // lebih pendek, nada naik
            regang(tengah, pcm, batal)          // kembali ke panjang asli, nada dipertahankan
        } else {
            if (!regang(pcm, tengah, batal)) return false   // lebih pendek, nada tetap
            ubahKecepatan(tengah, pcm)          // kembali ke panjang asli, nada turun
            true
        }
    }

    /** Membaca [src] dengan kecepatan srcFrame/dstFrame lalu menulis ke seluruh [dst] (interpolasi linear). */
    private fun ubahKecepatan(src: ShortArray, dst: ShortArray) {
        val fs = src.size / 2
        val fd = dst.size / 2
        val kec = fs.toDouble() / fd
        for (i in 0 until fd) {
            val pos = i * kec
            val a = min(pos.toInt(), fs - 1)
            val b = min(a + 1, fs - 1)
            val t = (pos - a).toFloat()
            for (c in 0..1) {
                val x = src[a * 2 + c] * (1f - t) + src[b * 2 + c] * t
                dst[i * 2 + c] = Math.round(x).toShort()
            }
        }
    }

    /**
     * Meregang atau memampatkan waktu [src] menjadi tepat selebar [dst] tanpa mengubah nada (WSOLA).
     * Mengembalikan false bila dibatalkan atau terlalu pendek (sebelum [dst] disentuh).
     */
    private fun regang(src: ShortArray, dst: ShortArray, batal: () -> Boolean): Boolean {
        val fs = src.size / 2
        val fd = dst.size / 2
        if (fs < N * 2 || fd < N * 2) return false

        // Mono kasar: rata-rata DEC frame, untuk mencari titik sambung dengan cepat.
        val nd = fs / DEC
        val d = FloatArray(nd)
        for (i in 0 until nd) {
            var s = 0
            val j = i * DEC * 2
            for (k in 0 until DEC * 2) s += src[j + k]
            d[i] = s / (DEC * 2f)
        }
        val jendela = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / N)).toFloat() }
        java.util.Arrays.fill(dst, 0.toShort())

        val ha = HS * fs.toDouble() / fd      // loncatan masukan nominal
        val maksPos = fs - N
        val lebarKasar = N / DEC
        var posSebelum = 0
        var k = 0
        while (true) {
            val awalKeluar = k * HS
            if (awalKeluar >= fd) break
            if (k % 128 == 0 && batal()) return false
            val pos: Int
            if (k == 0) {
                pos = 0
            } else {
                val nominal = (k * ha).toInt().coerceIn(0, maksPos)
                val target = posSebelum + HS
                pos = if (target > maksPos) nominal else cariTitik(src, d, nd, nominal, target, lebarKasar, maksPos)
            }
            // Tumpang-tindih berjendela Hann (jumlah dua jendela 50 persen = 1). Potongan pertama utuh di separuh awal.
            val batas = min(N, fd - awalKeluar)
            for (i in 0 until batas) {
                val w = if (k == 0 && i < HS) 1f else jendela[i]
                val o = (awalKeluar + i) * 2
                val s = (pos + i) * 2
                for (c in 0..1) {
                    val v = dst[o + c] + Math.round(src[s + c] * w)
                    dst[o + c] = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
                }
            }
            posSebelum = pos
            k++
        }
        return true
    }

    /** Mencari awal potongan di sekitar [nominal] yang paling mirip dengan lanjutan alami di [target]. */
    private fun cariTitik(src: ShortArray, d: FloatArray, nd: Int, nominal: Int, target: Int, lebar: Int, maksPos: Int): Int {
        // Kasar: korelasi ternormalisasi pada mono yang dikecilkan.
        val t0 = target / DEC
        val dariC = max(0, nominal - CARI)
        val sampaiC = min(maksPos, nominal + CARI)
        var terbaik = nominal.coerceIn(dariC, sampaiC)
        var skorTerbaik = -Float.MAX_VALUE
        var c = dariC
        while (c <= sampaiC) {
            val c0 = c / DEC
            if (c0 + lebar <= nd && t0 + lebar <= nd) {
                var dot = 0f
                var en = 0f
                for (i in 0 until lebar) {
                    val x = d[c0 + i]
                    dot += x * d[t0 + i]
                    en += x * x
                }
                val skor = dot / sqrt(en + 1f)
                if (skor > skorTerbaik) {
                    skorTerbaik = skor
                    terbaik = c
                }
            }
            c += DEC
        }
        // Halus: laju penuh, plus minus CARI_HALUS sampel.
        var hasil = terbaik
        skorTerbaik = -Float.MAX_VALUE
        val dari = max(0, terbaik - CARI_HALUS)
        val sampai = min(maksPos, terbaik + CARI_HALUS)
        for (p in dari..sampai) {
            var dot = 0f
            var en = 0f
            for (i in 0 until PANJANG_HALUS) {
                val x = (src[(p + i) * 2] + src[(p + i) * 2 + 1]).toFloat()
                val y = (src[(target + i) * 2] + src[(target + i) * 2 + 1]).toFloat()
                dot += x * y
                en += x * x
            }
            val skor = dot / sqrt(en + 1f)
            if (skor > skorTerbaik) {
                skorTerbaik = skor
                hasil = p
            }
        }
        return hasil
    }
}
