package com.novan.adbshell;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.PowerManager;

/** Mode tanpa Wi-Fi (ADB lewat 127.0.0.1:5555) dan pembebasan pembatasan baterai latar belakang. */
public class Latar {
    static final int PORT_LOKAL = 5555;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("adb", Context.MODE_PRIVATE);
    }

    static boolean modeTanpaWifiAktif(Context c) { return prefs(c).getBoolean("tcp", false); }
    static boolean otomatisAktif(Context c) { return prefs(c).getBoolean("otomatis", true); }

    static boolean bebasBateraiSistem(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    static boolean punyaIzinPengaturan(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Nyalakan Opsi pengembang, Debugging USB, Debugging nirkabel, dan matikan waktu tunggu
     * otorisasi adb (agar izin pairing tidak dicabut setelah beberapa hari).
     * Perlu izin WRITE_SECURE_SETTINGS. Aman dipanggil berulang, mis. setelah HP restart.
     */
    static boolean aktifkanDebugging(Context c) {
        if (!punyaIzinPengaturan(c)) return false;
        boolean ok = false;
        android.content.ContentResolver r = c.getContentResolver();
        try { Settings.Global.putInt(r, "development_settings_enabled", 1); ok = true; } catch (Throwable ignored) {}
        try { Settings.Global.putInt(r, "adb_enabled", 1); ok = true; } catch (Throwable ignored) {}
        try { Settings.Global.putInt(r, "adb_wifi_enabled", 1); } catch (Throwable ignored) {}
        try { Settings.Global.putLong(r, "adb_allowed_connection_time", 0L); } catch (Throwable ignored) {}
        return ok;
    }

    /** Sambung lewat loopback (tidak butuh Wi-Fi). Hanya berhasil bila adbd sedang dalam mode TCP. */
    static volatile boolean viaLokal = false;

    static boolean sambungLokal(Adb a) {
        try { a.connect("127.0.0.1", PORT_LOKAL); } catch (Throwable ignored) {}
        viaLokal = a.isConnected();
        return viaLokal;
    }

    /**
     * Pindahkan adbd ke mode TCP port 5555 supaya ADB tetap bisa dipakai tanpa Wi-Fi.
     * Harus dipanggil saat sudah tersambung lewat Wireless debugging (perlu Wi-Fi satu kali).
     * Mode ini hilang setelah HP restart.
     */
    static String aktifkanModeTanpaWifi(Context c, Adb a) {
        try {
            if (!a.isConnected()) return "Sambungkan dulu lewat Wireless debugging (Wi-Fi perlu aktif satu kali).";
            try { Shell.run(a, "tcpip:" + PORT_LOKAL, null); } catch (Throwable ignored) {}
            try { a.disconnect(); } catch (Throwable ignored) {}
            for (int k = 0; k < 10; k++) {
                try { Thread.sleep(1500); } catch (InterruptedException e) { break; }
                if (sambungLokal(a)) {
                    prefs(c).edit().putBoolean("tcp", true).apply();
                    return "Mode tanpa Wi-Fi aktif. ADB tersambung lewat 127.0.0.1:" + PORT_LOKAL
                            + ". Berlaku sampai HP restart.";
                }
            }
            try { a.sambungTls(c, 8000L); } catch (Throwable ignored) {}
            return "Gagal menyambung ke 127.0.0.1:" + PORT_LOKAL
                    + ". Coba sambungkan ulang lewat Wireless debugging lalu ulangi.";
        } catch (Throwable e) {
            return "Gagal mengaktifkan mode tanpa Wi-Fi: " + e;
        }
    }

    /** Bebaskan aplikasi dari penghematan baterai dan pembatasan latar belakang lewat ADB. */
    static String bebaskanBaterai(Context c, Adb a) {
        if (!a.isConnected()) return "Belum tersambung.";
        String p = c.getPackageName();
        String[] perintah = {
                "shell:cmd deviceidle whitelist +" + p,
                "shell:cmd appops set " + p + " RUN_IN_BACKGROUND allow",
                "shell:cmd appops set " + p + " RUN_ANY_IN_BACKGROUND allow",
                "shell:am set-standby-bucket " + p + " active",
        };
        for (String s : perintah) {
            try { Shell.run(a, s, null); } catch (Throwable ignored) {}
        }
        return bebasBateraiSistem(c)
                ? "Aplikasi sudah dibebaskan dari pembatasan baterai."
                : "Perintah dikirim, tetapi sistem belum mencatat pengecualian baterai. Pakai tombol pengaturan baterai sebagai cadangan.";
    }

    /**
     * Dipanggil tiap kali berhasil tersambung lewat Wi-Fi: langsung pindah ke jalur lokal
     * agar tetap bisa dipakai saat Wi-Fi dimatikan. Bebas baterai ikut diterapkan bila otomatis menyala.
     */
    static void terapkanOtomatis(Context c, Adb a) {
        if (!a.isConnected()) return;
        if (!punyaIzinPengaturan(c)) {
            // Beri izin sendiri saat pertama kali tersambung, tanpa menekan tombol apa pun.
            try { Shell.run(a, "shell:pm grant " + c.getPackageName()
                    + " android.permission.WRITE_SECURE_SETTINGS", null); } catch (Throwable ignored) {}
            if (punyaIzinPengaturan(c))
                PairHelper.say(c, "Izin sambung otomatis diberikan sendiri. Debugging USB akan menyala otomatis setelah HP restart.", false);
        }
        if (!aktifkanDebugging(c)) {
            try { Shell.run(a, "shell:settings put global adb_allowed_connection_time 0", null); } catch (Throwable ignored) {}
        }
        if (otomatisAktif(c) && !bebasBateraiSistem(c)) PairHelper.say(c, bebaskanBaterai(c, a), false);
        if (!viaLokal) PairHelper.say(c, aktifkanModeTanpaWifi(c, a), false);
    }
}
