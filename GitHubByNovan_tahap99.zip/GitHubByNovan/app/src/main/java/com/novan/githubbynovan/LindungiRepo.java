package com.novan.githubbynovan;

import android.app.Activity;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Memasang perlindungan tanda tangan ulang ke repositori yang sudah ada:
 * menambah TTGuard.java, mendaftarkannya di AndroidManifest.xml, dan memastikan alur kerja
 * sudah memiliki langkah penyemat sidik jari.
 */
public class LindungiRepo {
    private static final String SKIP = " [skip ci]";
    private static final String[] AKAR = {"/src/main/java/", "/src/main/kotlin/"};

    public static void mulai(final Activity a, final String full, final String token, final Runnable back) {
        String msg = "Proyek: " + full
                + "\n\nAplikasi menambahkan penjaga (TTGuard.java) ke proyek dan manifest, "
                + "lalu memperbarui alur kerja bila perlu."
                + "\n\nAPK dengan tanda tangan pribadi akan menutup sendiri bila ditandatangani ulang orang lain. "
                + "Tidak aktif untuk tanda tangan bawaan GitHub."
                + "\n\nSyarat: ada MainActivity.java atau .kt di src/main/java atau src/main/kotlin.";
        ApkTools.dialog(a, "Lindungi dari tanda tangan ulang", msg, ApkTools.list(
                ApkTools.b("pasang perlindungan", () -> cari(a, full, token, back))), "batal", back);
    }

    /** Langkah 1: cari lokasi MainActivity dari pohon repo. */
    private static void cari(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
            if (!ok) {
                TandaTanganRepo.gagal(a, "Gagal membaca repositori", full, res, back);
                return;
            }
            String branch = Api.parse(res).optString("default_branch", "main");
            Api.request("GET", Api.BASE + "/repos/" + full + "/git/trees/" + branch + "?recursive=1", token, null,
                    (ok2, r2) -> {
                        if (!ok2) {
                            TandaTanganRepo.gagal(a, "Gagal memeriksa daftar berkas", full, r2, back);
                            return;
                        }
                        JSONArray tree = Api.parse(r2).optJSONArray("tree");
                        String main = null;
                        for (int i = 0; tree != null && i < tree.length(); i++) {
                            JSONObject it = tree.optJSONObject(i);
                            String p = it == null ? "" : it.optString("path", "");
                            if (p.startsWith("build/") || p.contains("/build/")) continue;
                            if (!(p.endsWith("/MainActivity.java") || p.endsWith("/MainActivity.kt"))) continue;
                            if (p.contains(AKAR[0]) || p.contains(AKAR[1])) { main = p; break; }
                        }
                        if (main == null) {
                            a.runOnUiThread(() -> ApkTools.error(a, "MainActivity tidak ditemukan",
                                    "Proyek: " + full + "\n\nMainActivity.java atau .kt tidak ditemukan di src/main/java atau src/main/kotlin.", back));
                            return;
                        }
                        pasang(a, full, token, main, back);
                    });
        });
    }

    /** Langkah 2: tulis TTGuard.java, ubah manifest, lalu perbarui alur kerja. */
    private static void pasang(final Activity a, final String full, final String token, final String main,
                               final Runnable back) {
        int idx = -1, len = 0;
        for (String k : AKAR) {
            int i = main.indexOf(k);
            if (i >= 0) { idx = i; len = k.length(); break; }
        }
        String modul = main.substring(0, idx);
        String sesudah = main.substring(idx + len);
        int slash = sesudah.lastIndexOf('/');
        if (slash <= 0) {
            a.runOnUiThread(() -> ApkTools.error(a, "Nama paket tidak terbaca",
                    "MainActivity tidak berada dalam paket.", back));
            return;
        }
        final String dir = sesudah.substring(0, slash);
        final String paket = dir.replace('/', '.');
        final String guardPath = modul + "/src/main/java/" + dir + "/TTGuard.java";
        final String manifestPath = modul + "/src/main/AndroidManifest.xml";

        final byte[] guard;
        try {
            Map<String, String> m = new HashMap<>();
            m.put("PAKET", paket);
            guard = ProjectBuilder.fill(ProjectBuilder.asset(a, "ttGuard"), m).getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            a.runOnUiThread(() -> ApkTools.error(a, "Templat penjaga tidak terbaca", String.valueOf(e.getMessage()), back));
            return;
        }

        final String urlManifest = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(manifestPath);
        Api.request("GET", urlManifest, token, null, (ok, res) -> {
            if (!ok) {
                TandaTanganRepo.gagal(a, "AndroidManifest.xml tidak terbaca", full,
                        manifestPath + "\n\n" + res, back);
                return;
            }
            String xml;
            try {
                xml = new String(Base64.decode(Api.parse(res).optString("content", ""), Base64.DEFAULT),
                        StandardCharsets.UTF_8);
            } catch (Exception e) {
                TandaTanganRepo.gagal(a, "AndroidManifest.xml tidak terbaca", full, String.valueOf(e.getMessage()), back);
                return;
            }
            final boolean manifestSudah = xml.contains("TTGuard");
            final String xmlBaru;
            if (manifestSudah) {
                xmlBaru = xml;
            } else {
                int akhir = xml.lastIndexOf("</application>");
                if (akhir < 0) {
                    a.runOnUiThread(() -> ApkTools.error(a, "Manifest tidak dikenali",
                            "Tag </application> tidak ditemukan di " + manifestPath, back));
                    return;
                }
                String provider = "        <provider android:name=\"" + paket + ".TTGuard\""
                        + " android:authorities=\"${applicationId}.ttguard\""
                        + " android:exported=\"false\" android:initOrder=\"2147483647\" />\n    ";
                xmlBaru = xml.substring(0, akhir) + provider + xml.substring(akhir);
            }
            // Penjaga ditulis lebih dulu agar manifest tidak pernah menunjuk kelas yang belum ada.
            TandaTanganRepo.tulis(a, full, token, guardPath, guard,
                    "Tambah penjaga tanda tangan" + SKIP, back, () -> {
                        final boolean[] mainOk = {false};
                        Runnable lanjut = () -> panggilMain(a, full, token, main, back, mainOk,
                                () -> TandaTanganRepo.pastikanAlurKerja(a, full, token, back,
                                        () -> a.runOnUiThread(() -> selesai(a, full, guardPath, mainOk[0], back))));
                        if (manifestSudah) {
                            lanjut.run();
                        } else {
                            TandaTanganRepo.tulis(a, full, token, manifestPath,
                                    xmlBaru.getBytes(StandardCharsets.UTF_8),
                                    "Daftarkan penjaga tanda tangan di manifest" + SKIP, back, lanjut);
                        }
                    });
        });
    }

    /** Sisipkan TTGuard.periksa(this) setelah super.onCreate(...) di MainActivity; gagal = dilewati tanpa error. */
    private static void panggilMain(final Activity a, final String full, final String token, final String main,
                                    final Runnable back, final boolean[] ok, final Runnable next) {
        final String url = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(main);
        Api.request("GET", url, token, null, (found, res) -> {
            if (!found) { next.run(); return; }
            String src;
            try {
                src = new String(Base64.decode(Api.parse(res).optString("content", ""), Base64.DEFAULT),
                        StandardCharsets.UTF_8);
            } catch (Exception e) {
                next.run();
                return;
            }
            if (src.contains("TTGuard.periksa")) { ok[0] = true; next.run(); return; }
            Matcher m = Pattern.compile("super\\.onCreate\\([^)]*\\);?").matcher(src);
            if (!m.find()) { next.run(); return; }
            String baru = src.substring(0, m.end()) + "\n        TTGuard.periksa(this);" + src.substring(m.end());
            TandaTanganRepo.tulis(a, full, token, main, baru.getBytes(StandardCharsets.UTF_8),
                    "Panggil penjaga tanda tangan dari MainActivity" + SKIP, back, () -> {
                        ok[0] = true;
                        next.run();
                    });
        });
    }

    private static void selesai(Activity a, String full, String guardPath, boolean mainOk, Runnable back) {
        String cek = mainOk
                ? "MainActivity juga memanggil penjaga."
                : "MainActivity tidak diubah karena onCreate tidak ditemukan. Penjaga tetap berjalan.";
        ApkTools.dialog(a, "Perlindungan terpasang",
                "Proyek: " + full + "\n\nPenjaga ditambahkan di " + guardPath + " dan terdaftar di manifest. "
                        + cek
                        + "\n\nLangkah berikutnya: pilih Mulai pembangunan APK dengan tanda tangan pribadi.",
                ApkTools.list(), "tutup", back);
    }
}
