package com.novan.filemanagermax

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object ThemeManager {
    const val SYSTEM = 0
    const val LIGHT = 1
    const val DARK = 2
    private const val PREF = "settings"
    private const val KEY = "theme"

    fun get(c: Context): Int = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(KEY, SYSTEM)

    fun set(c: Context, value: Int) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY, value).apply()
        apply(value)
    }

    fun apply(value: Int) {
        AppCompatDelegate.setDefaultNightMode(
            when (value) {
                LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                DARK -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
