package com.novan.talkbacknovan;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;

/** Gestur tambahan yang bisa diberi aksi bebas di Pengaturan. */
final class Gestur {
    private static final String AWAL = "gx_";

    // {nomor gestur, kunci pengaturan, nama, aksi bawaan}
    private static final Object[][] T = {
            {AccessibilityService.GESTURE_SWIPE_UP_AND_LEFT, "atas_kiri", "Usap atas lalu kiri", Aksi.BERANDA},
            {AccessibilityService.GESTURE_SWIPE_UP_AND_DOWN, "atas_bawah", "Usap atas lalu bawah", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_UP_AND_RIGHT, "atas_kanan", "Usap atas lalu kanan", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_DOWN_AND_LEFT, "bawah_kiri", "Usap bawah lalu kiri", Aksi.KEMBALI},
            {AccessibilityService.GESTURE_SWIPE_DOWN_AND_UP, "bawah_atas", "Usap bawah lalu atas", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_DOWN_AND_RIGHT, "bawah_kanan", "Usap bawah lalu kanan", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_LEFT_AND_UP, "kiri_atas", "Usap kiri lalu atas", Aksi.TERBARU},
            {AccessibilityService.GESTURE_SWIPE_LEFT_AND_DOWN, "kiri_bawah", "Usap kiri lalu bawah", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_LEFT_AND_RIGHT, "kiri_kanan", "Usap kiri lalu kanan", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_RIGHT_AND_UP, "kanan_atas", "Usap kanan lalu atas", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_SWIPE_RIGHT_AND_DOWN, "kanan_bawah", "Usap kanan lalu bawah", Aksi.NOTIFIKASI},
            {AccessibilityService.GESTURE_SWIPE_RIGHT_AND_LEFT, "kanan_kiri", "Usap kanan lalu kiri", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_2_FINGER_TRIPLE_TAP, "d2_ketuk3", "Ketuk tiga kali dua jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_3_FINGER_TRIPLE_TAP, "d3_ketuk3", "Ketuk tiga kali tiga jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_SINGLE_TAP, "d4_ketuk", "Ketuk empat jari", Aksi.PERINTAH_SUARA},
            {AccessibilityService.GESTURE_4_FINGER_DOUBLE_TAP, "d4_ketuk2", "Ketuk dua kali empat jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_TRIPLE_TAP, "d4_ketuk3", "Ketuk tiga kali empat jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_SWIPE_UP, "d4_atas", "Usap atas empat jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_SWIPE_DOWN, "d4_bawah", "Usap bawah empat jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_SWIPE_LEFT, "d4_kiri", "Usap kiri empat jari", Aksi.TIDAK_ADA},
            {AccessibilityService.GESTURE_4_FINGER_SWIPE_RIGHT, "d4_kanan", "Usap kanan empat jari", Aksi.TIDAK_ADA},
    };

    /** Jumlah gestur satu jari (kombinasi dua usapan) di awal tabel. */
    static final int JUMLAH_SATU_JARI = 12;

    private Gestur() {}

    static int jumlah() {
        return T.length;
    }

    static String nama(int i) {
        return (String) T[i][2];
    }

    static String kunciPref(int i) {
        return AWAL + T[i][1];
    }

    static int aksi(Context c, int idGestur) {
        for (Object[] b : T) {
            if (((Integer) b[0]) == idGestur) return Prefs.aksi(c, AWAL + b[1]);
        }
        return Aksi.TIDAK_ADA;
    }

    static int bawaan(String kunci) {
        for (Object[] b : T) {
            if ((AWAL + b[1]).equals(kunci)) return (Integer) b[3];
        }
        return Aksi.TIDAK_ADA;
    }
}
