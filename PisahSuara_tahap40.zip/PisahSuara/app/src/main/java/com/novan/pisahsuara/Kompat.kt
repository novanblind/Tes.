package com.novan.pisahsuara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build

/** Penyesuaian untuk Android 7 sampai 16 (minSdk 24): saluran notifikasi dan layanan latar depan baru ada sejak Android 8. */
object Kompat {
    /** Jalur resmi (Wireless debugging) baru ada di Android 11 (API 30) ke atas. Di bawah itu dipakai USB komputer / kabel OTG. */
    @JvmStatic fun adaNirkabel(): Boolean = Build.VERSION.SDK_INT >= 30

    @JvmStatic fun mulaiLayanan(c: Context, i: Intent) {
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
    }

    @JvmStatic fun pembuat(c: Context, id: String, nama: String, penting: Int): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(id, nama, penting))
            Notification.Builder(c, id)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(c).setPriority(
                if (penting >= NotificationManager.IMPORTANCE_HIGH) Notification.PRIORITY_HIGH else Notification.PRIORITY_LOW)
        }
    }
}
