# Termux Data Novan, tahap 101: panduan singkat

## Tombol di layar utama (10 tombol)
- **Jalankan**: menjalankan perintah di kolom perintah.
- **Hentikan**: menghentikan perintah yang sedang berjalan.
- **Salin hasil**: menyalin hasil perintah terakhir (atau isi layar program interaktif) ke papan klip. Membacakan ada di Menu lainnya, Bacakan hasil terakhir.
- **Bersihkan layar**: menghapus semua keluaran yang tampil. Daftar simbol sudah dihapus.
- **Bangun APK**: lihat bagian di bawah.
- **Menu lainnya**: bongkar APK jadi zip, pengaturan tanda tangan dan keamanan APK,
  kemajuan proses, izin penyimpanan, dan bantuan.

## Bangun APK dari file manager
Di file manager, tekan tahan berkas zip proyek, pilih **Bagikan** atau **Buka dengan**, lalu pilih Termux Novan.
Zip langsung diekstrak dan dibangun, tanpa menekan tombol apa pun. Tanda tangan dan keamanan mengikuti pengaturan.
Bila masih ada proses bangun yang berjalan, tunggu sampai selesai lalu bagikan lagi.

## Bangun APK: otomatis
1. **Pilih proyek**: folder kerja (bila berisi proyek) atau salah satu berkas .zip di folder Download
   (terbaru di atas). Zip diekstrak otomatis ke folder proyek di home.
2. **Tanda tangan dan keamanan berjalan otomatis**, tanpa dialog tambahan:
   - Bila belum pernah memilih: tanda tangan pribadi terbaru dipakai bila ada, kalau tidak ada dipakai tanda tangan bawaan.
   - Keamanan penjaga tanda tangan bawaannya aktif (berlaku untuk tanda tangan pribadi).
   - Tidak ada dialog pilihan saat membangun. Membuat baru, mengimpor berkas p12, atau mengganti pilihan lewat
     Menu lainnya, Pengaturan tanda tangan dan keamanan APK.
3. **Mengubah tanda tangan atau keamanan**: Menu lainnya, **Pengaturan tanda tangan dan keamanan APK**
   (ganti tanda tangan, buat, impor, ekspor cadangan, hapus, dan hidupkan atau matikan keamanan penjaga).

4. **Setelah selesai**, pilihan "Buka dengan" (pemasang paket atau aplikasi lain yang bisa memasang APK) muncul
   otomatis. Tombol Pasang APK, Pilih pemasang..., dan Tutup tetap ada di dialog.

**Perintah ditempel di kolom perintah**: perintah bangun Gradle seperti `./gradlew assembleDebug`, `gradle assembleRelease`,
atau `cd folder && ./gradlew assembleDebug`, bila ditempel lalu ditekan Jalankan, otomatis memakai alur Bangun APK yang sama
(tanda tangan dan keamanan otomatis, dialog persen, salinan ke Download, pilihan aplikasi pemasang). Opsi tambahan seperti
`--stacktrace` tidak dipakai di alur ini. Perintah lain dijalankan seperti biasa.

Proyek Gradle apa pun (Java, Kotlin, Compose, NDK, banyak modul, banyak flavor atau pecahan ABI) memakai alur ini.
Bila hasilnya beberapa APK, semuanya ditandatangani dan disalin ke Download; yang dibuka di dialog adalah APK universal
atau arm64 bila ada, kalau tidak yang terbesar. Proyek tanpa Gradle (AndroidManifest.xml + src) juga didukung. Dengan tanda tangan
pribadi, penjaga dipasang ke proyek sebelum dibangun, lalu APK hasil Gradle ditandatangani ulang dengan tanda
tangan pilihan Anda (berkas bernama <nama>-<tanda tangan>.apk).
Dengan Bawaan, proyek memakai tanda tangan bawaannya sendiri.

Semua perintah ketikan lama tetap berlaku (bangun-apk, buat-ttd, pilih-ttd, bangun-gradle, dan seterusnya).
Ketik **bantuan** untuk daftar lengkap.

## Layar menyala, pemasang APK, salin error
- Layar tetap menyala selama Terminal terbuka (bisa dimatikan di Menu lainnya).
- Tema tampilan ada di Menu lainnya, **Tema tampilan**: Ikuti sistem (bawaan), Terang, atau Gelap.
- Setelah APK selesai dibangun muncul dialog: **Pasang APK**, **Pilih pemasang...**, **Tutup**.
  Pertama kali, Android meminta izin "pasang aplikasi dari sumber ini".
- Bila perintah gagal muncul dialog dengan tombol **Salin error**. Pembangunan yang gagal punya
  tombol **Salin keterangan error** di dialog kemajuan.

## Perintah yang menunggu jawaban: lewat dialog, tanpa mengetik
Bila sebuah perintah bertanya (termasuk saat Jalankan atau Bangun APK), muncul dialog berisi jawaban yang tinggal ditekan.
Pilihan disesuaikan dengan pertanyaannya:
- **y/n**, misalnya "Continue? [Y/n]": Ya, Tidak (jawaban bawaan ditandai).
- **Pilihan lain**, misalnya [y/n/a] atau (yes/no): tiap pilihan jadi satu tombol.
- **Menu bernomor**, misalnya "1) JDK 17  2) JDK 21": tiap nomor jadi satu tombol dengan namanya.
- **Tekan Enter untuk lanjut**: tombol Tekan Enter.
- **Sandi**: kolom ketik sandi (terlihat, supaya bisa diperiksa dengan pembaca layar).
- Selalu ada: **Tekan Enter saja**, **Ketik jawaban lain**, **Tutup, biarkan menunggu**.
- Pertanyaan yang tidak tampil di layar dikenali dari perintah yang diam cukup lama (8 detik, atau 20 detik untuk perintah bangun).
- Pertanyaan yang sudah ditutup tidak muncul lagi selama 1 menit.
- `termux-setup-storage` dijawab y otomatis; izin penyimpanan juga ada di Menu lainnya, Izin penyimpanan.

## bangun-gradle yang diketik = sama dengan tombol Bangun APK
`bangun-gradle /sdcard/Download/NamaProyek.zip` (atau folder proyek, boleh ditambah nama tugas) memakai alur Bangun APK:
tanda tangan pribadi dan keamanan penjaga otomatis, dialog persen, salinan ke Download, lalu Buka dengan.
Tanpa lokasi: folder kerja bila proyek Gradle, kalau tidak zip terbaru di Download.

## Bila gagal: keterangan error di dialog
Bila pembangunan atau proses bangun gagal, dialog langsung menampilkan inti error-nya (misalnya bagian
"What went wrong" dari Gradle), lengkap dengan tombol **Salin error** (menyalin seluruh keluaran) dan **Coba lagi**.

## Android SDK
Bila folder android-sdk sudah ada di home (hasil perintah **siap**), ANDROID_HOME terisi otomatis untuk semua perintah.
Cara termudah membangun dari zip: `bangun-gradle /sdcard/Download/NamaProyek.zip`.

## Perintah bangun yang dipipa atau digabung
Perintah seperti `unzip ... && cd proyek && ./gradlew assembleDebug 2>&1 | tee log.txt` ikut memakai dialog proses.
Bila ada tulisan BUILD FAILED, proses dianggap gagal walaupun ada pipa. Bila berhasil, APK baru di folder build
dicari otomatis, lalu pilihan Buka dengan terbuka sendiri.

## Perintah bangun tampil di dialog proses
Perintah yang berisi bangun, gradlew, assemble, atau skrip build (misalnya `bash bangun-termux.sh`) ditampilkan di dialog
proses seperti Bangun APK: persen perkiraan, keterangan baris terakhir, dan waktu. Bila keluarannya menyebut berkas .apk yang
ada, dialog akhir menawarkan Pasang APK dan Buka dengan..., dan pilihan Buka dengan terbuka otomatis.


## Tahap 48: ingat pilihan pemasang
- Setelah APK selesai dibangun, pilihan pemasang muncul sekali dengan kotak **Jangan tanyakan lagi**.
- Kalau kotak dicentang lalu Anda memilih pemasang paket, pilihan itu diingat. Berikutnya APK langsung terbuka di pemasang tersebut (tombol Pasang / Batal), tanpa memilih aplikasi lagi.
- Untuk mengganti pilihan tersimpan, tekan **Pilih pemasang...** di dialog akhir.

## Tahap 49: proyek Gradle tanpa gradlew
- Bila proyek tidak punya berkas `gradlew` (misalnya NovanTel yang hanya membawa `gradle-wrapper.properties`), **Bangun Gradle** tidak lagi berhenti dengan kode 2.
- Terminal mengunduh Gradle sesuai versi di `gradle-wrapper.properties` (cadangan: 8.10.2) sekali saja ke `~/.gradle-dist`, lalu membangun dengan Gradle itu.
- Folder proyek di dalam zip (misalnya `NovanTel/`) dicari otomatis.

## Tahap 50: tombol Bersihkan layar
- Tombol **Simbol** di baris riwayat diganti **Bersihkan layar**.
- Daftar simbol dihapus sepenuhnya (tidak ada lagi di Menu lainnya); butir Bersihkan layar di Menu lainnya juga diganti karena sudah ada tombolnya.

## Tahap 51
- Sisipkan simbol dihapus dari Menu lainnya dan kodenya dibuang, karena tidak dipakai.

## Tahap 52
- Tombol **Tombol khusus** (Esc, panah, Ctrl, dan lainnya) dihapus dari layar utama; baris bawah kini hanya Bangun APK dan Menu lainnya. Tombol Tab dan Hentikan tetap ada.

## Tahap 53
- Tombol **Lengkapi otomatis**, **Perintah sebelumnya**, dan **Perintah berikutnya** dihapus dari layar utama.
- Susunan tombol sekarang: Hentikan, Salin hasil, Bersihkan layar; lalu Bangun APK dan Menu lainnya.

## Tahap 55: target SDK dinaikkan ke 35
- Peringatan "dibangun untuk versi lama Android" tidak muncul lagi karena targetSdk naik dari 28 ke 35 (compileSdk 35, AGP 8.7.3, Gradle 8.9).
- Android 10 ke atas melarang menjalankan berkas langsung dari folder aplikasi bila targetSdk 29 atau lebih. Karena itu program yang dijalankan aplikasi sendiri (bash, aapt2, dan lain-lain) kini dijalankan lewat /system/bin/linker64. Program yang dijalankan dari dalam shell ditangani libtermux-exec lewat LD_PRELOAD.
- Tampilan penuh layar (edge-to-edge) diberi ruang untuk bilah sistem dan keyboard. Library pty memakai perataan halaman 16 KB.
- Setelah memasang tahap 55, ketik **uji-eksekusi**, lalu **siap**, lalu coba **java -version** dan satu kali Bangun APK. Bila ada yang gagal dengan "Permission denied", kirim keluarannya.

## Tahap 56: penyadap exec sendiri
- Tahap 55 gagal menyiapkan alat dengan "Permission denied" pada id, grep, find: libtermux-exec bawaan bootstrap tidak menjalankan biner lewat linker pada targetSdk 35.
- Kini aplikasi membawa libnovanexec.so (LD_PRELOAD) yang menyadap execve, execv, execvp, execl*, posix_spawn dan posix_spawnp. Biner ELF dijalankan lewat /system/bin/linker64, skrip yang interpreternya di folder aplikasi juga.
- Bila penyiapan masih gagal, ketik **uji-eksekusi** dan kirim keluaran lengkap dari bagian yang gagal.

## Tahap 57: penyiapan alat lebih tahan galat paket
- Penyiapan sebelumnya berhenti dengan "Unmet dependencies" (apksigner butuh openjdk-21) karena daftar paket cermin acak tidak sinkron.
- Bila pemasangan paket gagal, penyiapan kini mencoba berurutan: apt --fix-broken install, pembaruan paket terpasang, lalu beralih ke cermin resmi packages.termux.dev dan memasang ulang.

## Tahap 58: cadangan bila dpkg menolak menjalankan skrip paket
- Tahap 57 gagal memasang openjdk-21: "unable to execute new openjdk-21 package pre-installation script ... Permission denied". Hanya paket yang punya skrip preinst/postinst yang terkena.
- Kini bila keluaran apt memuat galat itu, penyiapan langsung memakai jalur cadangan: paket .deb di cache apt dikemas ulang tanpa skrip (preinst, postinst, prerm, postrm), preinst dijalankan lewat `sh`, dipasang dengan dpkg -i, lalu postinst dijalankan lewat `sh`, dan `dpkg --configure -a`.
- Log juga mencetak nilai LD_PRELOAD agar penyebab aslinya bisa dilacak bila masih gagal. Catatan: skrip prerm/postrm paket tersebut tidak ikut dipasang.

## Tahap 59: skrip berawalan /usr/bin/env dan /bin/sh
- Bangun-gradle gagal saat memasang Android SDK: `error: unable to open file "/usr/bin/env"`. Skrip sdkmanager (dan banyak skrip lain) berawalan `#!/usr/bin/env sh`, padahal Android tidak punya /usr/bin dan /bin.
- Penyadap exec (libnovanexec.so) dan Env.wrap kini memetakan /usr/bin/X, /bin/X dan /usr/local/bin/X ke $PREFIX/bin/X bila berkas aslinya tidak ada, baik untuk program langsung maupun interpreter skrip.

## Tahap 64: proyek Node (React Native, Capacitor, Ionic, Cordova)
- Zip proyek yang punya package.json dan folder android (atau config.xml untuk Cordova) kini dikenali.
- Alurnya otomatis: pasang Node.js bila belum ada, npm install, lalu bangun dengan Gradle di folder android.
- Capacitor: dijalankan cap sync android. Cordova: platform Android ditambahkan bila belum ada.
- Bagikan zip dari file manager atau tekan Bangun APK, sama seperti proyek biasa.
- Belum didukung: Flutter, Unity, Godot, Xamarin/MAUI.
- Catatan: React Native mode release butuh program Hermes buatan komputer biasa, yang bisa gagal di HP. Debug lebih aman dicoba dulu.

## Tahap 65: Gradle memakai alat milik HP
- Program aapt2 bawaan Gradle dibuat untuk komputer biasa dan tidak jalan di HP. Kini Gradle diarahkan ke aapt2 yang terpasang di HP (lewat ~/.gradle/gradle.properties).
- Memori Gradle diatur 1,5 GB bila proyek belum mengaturnya.
- Proyek dengan kode C/C++ memakai cmake milik HP (cmake.dir di local.properties).
- Berlaku untuk semua proyek Gradle, termasuk proyek Node.
- Keterbatasan: proyek yang meminta versi NDK lain dari yang terpasang (r29) atau JDK khusus belum bisa.

## Tahap 66: proyek apktool dan perbaikan Node
- Folder atau zip hasil bongkar apktool (ada apktool.yml) kini bisa dibangun di HP: apktool dipasang otomatis, APK dirakit, dirapikan bila zipalign ada, lalu ditandatangani.
- Tanpa tanda tangan pribadi, dipakai tanda tangan bawaan ~/.novan-debug.jks. Dengan tanda tangan pribadi, APK ditandatangani ulang seperti biasa.
- Proyek Node (Cordova, React Native, Capacitor) kini juga lolos dari pemeriksaan awal Bangun APK. Sebelumnya tertolak "Tidak ada proyek".
- Bila proyek meminta versi NDK lain, dipakai NDK yang terpasang di HP.

## Tahap 67: membaca berkas workflow GitHub
- Bila proyek punya folder .github/workflows, isinya dipakai sebagai petunjuk (workflow tidak dijalankan langsung).
- Proyek tanpa gradlew memakai versi Gradle dari baris gradle-version di workflow. Dulu selalu 8.10.2, dan itu terlalu lama untuk AGP 8.9.
- Tugas bawaan mengikuti workflow, misalnya assembleRelease. Tanpa workflow tetap assembleDebug.
- Platform dan build-tools yang diminta lewat sdkmanager di workflow dipasang lebih dulu.
- Kunci debug ~/.android/debug.keystore dibuat otomatis, seperti langkah keytool di workflow.
- APK hasil yang belum bertanda tangan (misalnya release tanpa kunci) ditandatangani dengan kunci itu, jadi bisa dipasang. Namanya berakhiran -kunci-bawaan.
- Kotlin dikompilasi di dalam proses Gradle supaya hemat memori HP.

## Tahap 68: mengikuti cara GitHub by Novan memilih Gradle
- Tanpa gradlew dan tanpa versi di workflow, versi Gradle dipilih dari versi AGP proyek: AGP 8.0-8.2 pakai 8.5, 8.3-8.5 pakai 8.7, 8.6-8.8 pakai 8.10.2, 8.9 ke atas pakai 8.13, AGP 9 pakai 9.3.1, AGP 7 pakai 7.6.4.
- Bila workflow memuat beberapa tugas (misalnya assembleRelease dan assembleDebug), dipakai assembleDebug, karena kunci rahasia GitHub tidak ada di HP.
- Bila workflow memakai -x lint, lint dan tes juga dilewati di HP supaya lebih cepat dan hemat memori.

## Tahap 69: proyek apktool dari Apktool M (apktool.json)
- Folder atau zip hasil bongkar Apktool M (ada apktool.json, tanpa apktool.yml) kini dikenali.
- Berkas apktool.json diubah ke apktool.yml pada salinan sementara. Folder asli Anda tidak diubah.
- Lalu dibangun seperti proyek apktool biasa: rakit, rapikan, tandatangani, salin ke Download.

## Bundel offline (tahap 74)
- `ekspor-alat` (atau Menu lainnya, Ekspor peralatan): mengumpulkan bootstrap Termux, paket apt, NDK, Android SDK, Gradle dan pustaka Gradle menjadi satu zip `TerminalNovan-bundel-TANGGAL.zip` di folder Download. Bagian yang belum ada di HP diunduh sekali. Tambahkan `--tanpa-pustaka` untuk melewatkan pustaka Gradle proyek.
- `impor-alat` (atau Menu lainnya, Impor peralatan): memasang semuanya dari bundel tanpa internet.
- Alat tidak diunduh saat aplikasi dibuka. Unduhan baru mulai saat pertama kali membangun APK. Bila bundel ada di folder Download, alat dipasang dari bundel (tanpa internet), kalau tidak diunduh dari internet.
- Bundel paling lengkap dibuat setelah minimal satu proyek pernah dibangun, karena Gradle dan pustakanya baru ada saat itu.

## Tahap 78: impor bundel lewat Bagikan
- Di file manager, tekan tahan berkas `TerminalNovan-bundel-....zip`, pilih Bagikan (atau Buka dengan) lalu pilih Termux Novan. Bundel dikenali dari isinya (bukan dari namanya), disalin, lalu alat dipasang otomatis tanpa internet, sama seperti `impor-alat`.
- Zip proyek biasa tetap dibangun seperti sebelumnya.
- Salinan bundel dihapus otomatis setelah alat selesai terpasang. Bila gagal, salinan disimpan supaya bisa diulang dengan `siap`/`impor-alat`.
- Butuh ruang kosong sekitar 3 GB untuk salinan.

## Tahap 81: dasar tahap 73 dengan mekanisme tahap 78
- Mekanisme bundel sama seperti tahap 78: alat tidak diunduh saat aplikasi dibuka; baru disiapkan saat Bangun APK pertama kali atau saat zip dibagikan. Bundel di Download atau yang dibagikan dipasang tanpa internet.
- Setelah alat siap, proyek yang dipilih dibangun otomatis (lokasi proyek dan tugas tidak hilang lagi).
- Perbaikan macet: pembangunan otomatis kini menunggu proses penyiapan benar-benar selesai sebelum mulai, sehingga tidak tertahan di "menyiapkan alat".

## Tahap 82: bongkar APK jadi zip (seperti Apktool M)
- **Bongkar**: Menu lainnya, **Bongkar APK jadi zip**, lalu pilih APK di folder Download. Setelah memilih APK muncul kotak centang **Kode program (smali)** dan **Sumber daya**; keduanya tercentang dari awal, jadi cukup tekan **Bongkar** untuk membongkar semuanya. Hilangkan centang bila ingin melewatkan salah satunya.
  Atau ketik `bongkar-apk <lokasi.apk>` (tambahkan `--tanpa-kode` atau `--tanpa-res` bila perlu). Tanpa lokasi, pilihan APK muncul.
  Dari file manager: tekan tahan APK, pilih **Bagikan**, lalu pilih Termux Novan. Langsung dibongkar.
- **Hasil**: satu berkas `NamaApk_src.zip` di folder Download (format Apktool M, lihat tahap 84). Folder aslinya juga disimpan di `~/bongkar/NamaApk` supaya bisa disunting dengan terminal.
- **Sunting**: ekstrak zip di file manager atau HP, ubah berkas di dalamnya (smali, res, AndroidManifest.xml), lalu zip lagi (isi zip rata, `apktool.json` ada di paling luar).
- **Bangun lagi jadi APK**: bagikan zip itu ke Termux Novan, atau tekan **Bangun APK** lalu pilih zip itu. Alurnya sama dengan proyek apktool (tahap 66): dirakit, dirapikan, ditandatangani, disalin ke Download.
- Alat (Java, apktool) disiapkan otomatis bila belum ada, sama seperti Bangun APK. apktool dipasang sekali saja.
- Catatan: APK sistem atau yang memakai framework khusus produsen mungkin gagal dibongkar. APK yang dilindungi (pengacak kode atau pemeriksa tanda tangan) bisa dibongkar tetapi hasil rakitannya belum tentu jalan.

## Tahap 83: bongkar aplikasi yang sudah terpasang, dan contoh Apktool M
- **Bongkar APK jadi zip** kini bertanya sumbernya: **Aplikasi yang sudah terpasang di HP** atau **Berkas APK di folder Download**. Perintah `bongkar-apk` tanpa lokasi juga menampilkan pilihan yang sama.
- Daftar aplikasi terpasang punya kolom cari (nama atau nama paket). Aplikasi sistem disembunyikan; tombol **Tampilkan aplikasi sistem** memunculkannya. Yang tampil adalah aplikasi berikon peluncur, tanpa izin tambahan.
- APK-nya disalin ke `~/masuk/<nama aplikasi>.apk`, jadi zip hasilnya bernama `<nama aplikasi>_src.zip`.
- Aplikasi dengan split APK (bundle) hanya bagian base.apk yang dibongkar; ada catatan di layar bila itu terjadi.
- Hasil bongkar Apktool M (zip rata, ada `apktool.json`) sudah diuji dengan konverter yang ada: menghasilkan `apktool.yml` yang sah, jadi bisa dibangun lagi di sini.

## Tahap 84: format sama dengan Apktool M, dan jelajah semua folder
- **Hasil bongkar disamakan dengan Apktool M** (dibandingkan dengan contoh hasil Apktool M):
  - zip rata, bernama `<nama APK>_src.zip` (tidak ada folder pembungkus);
  - `apktool.json` dengan susunan dan kolom yang sama (apkFileName `<nama>_src.apk`, PackageInfo, doNotCompress, VersionInfo, UsesFramework, unknownFiles, apkFilePath, sdkInfo, dan seterusnya), tanpa `apktool.yml`;
  - `original/AndroidManifest.xml`, `original/META-INF` dan `original/signature.data` (blok tanda tangan APK, diambil dari APK asli; dilewati bila APK hanya bertanda tangan v1).
  Zip ini bisa dibangun di Apktool M dan di sini. Isi smali, res, dan AndroidManifest.xml dihasilkan apktool versi Termux, jadi penulisannya bisa sedikit berbeda dari versi apktool di Apktool M.
- **Jelajah folder (Menu lainnya, Bongkar APK jadi zip)**: pilihan **Cari berkas APK di penyimpanan (semua folder)**. Ketuk folder untuk masuk, **Naik ke folder atas** untuk kembali, **Lokasi cepat** untuk lompat ke Download, Dokumen, penyimpanan internal, kartu SD atau USB, dan folder rumah aplikasi. Folder terakhir diingat.
- **Jelajah folder (tombol Bangun APK)**: pilihan **Jelajahi folder lain**. Bisa memilih zip proyek, atau menekan **Pilih folder ini** untuk membangun folder proyek. Folder proyek di penyimpanan disalin dulu ke `~/proyek` supaya bisa dibangun. Daftar zip di Download tetap muncul di bawahnya (15 terbaru).

## Tahap 85: bongkar semuanya sebagai bawaan
- Dialog pilihan APK yang akan dibongkar kini berisi dua kotak centang, **Kode program (smali)** dan **Sumber daya**, keduanya sudah tercentang. Tekan **Bongkar** dan semuanya dibongkar. Menghilangkan centang sama dengan `--tanpa-kode` atau `--tanpa-res`.

## Tahap 86: Menu lainnya dirapikan
- Dihapus beserta kodenya: **Simpan perintah ke favorit**, **Buka daftar favorit**, **Salin hasil terakhir**, **Lompat ke hasil perintah sebelumnya**, dan **Lompat ke hasil perintah berikutnya**. Tombol **Salin hasil** di layar utama tetap ada.
- **Bongkar APK jadi zip** dipindah ke urutan paling atas. Urutan sekarang: Bongkar APK jadi zip, Pengaturan tanda tangan dan keamanan APK, Lihat kemajuan proses, Izin penyimpanan, Layar tetap menyala, Bacakan hasil, Ekspor alat, Impor alat, Bantuan.

## Tahap 87-88: disamakan dengan tahap 86
- Dasar: tahap 81. Fitur bongkar APK jadi zip (tahap 82-85), jelajah folder, bagikan APK dari file manager, dan Menu lainnya yang dirapikan (tahap 86) sudah disamakan. Alur kerja bongkar dan bangun memakai mekanisme yang sama.
- Versi naik ke 1.56.

## Tahap 89: penyiapan alat tidak lagi terlihat macet
- Sebab macet: keluaran apt (daftar, unduh, pasang paket) sebelumnya ditahan sampai perintahnya selesai, jadi dialog diam di satu persen dan satu teks selama berpuluh menit walau unduhan sebenarnya jalan.
- Sekarang keluaran apt tampil langsung. Persen dan baris keterangan di dialog bergerak mengikuti paket yang sedang diunduh dan dipasang.
- Unduhan yang benar-benar tersangkut kini dibatasi 30 detik lalu diulang sampai 3 kali (berkas `apt.conf.d/99novan`), jadi tidak menggantung selamanya.
- Bila aplikasi harus dihapus lalu dipasang ulang setiap kali versi baru, data di dalamnya ikut hilang dan semua alat diunduh ulang. Sebelum menghapus, pakai Menu lainnya, Ekspor alat; setelah dipasang ulang, pakai Impor alat.

## Tahap 90: otomatis memilih cermin unduhan tercepat
- Kode unduhan tahap 78 dan tahap 89 sama. Bedanya kecepatan, bukan program: cermin (server) bawaan bisa lambat di waktu atau jaringan tertentu.
- Sebelum menyiapkan alat, aplikasi kini menguji kecepatan beberapa cermin (500 KB pertama daftar paket, maksimal 8 detik per cermin), lalu memakai yang tercepat. Hasil ujinya tampil di layar utama, misalnya "Cermin ...: 3417 KB/detik".
- Bila cermin terpilih gagal saat memperbarui daftar, alur lama tetap mencoba cermin lain otomatis.
- Tidak dipakai pada mode bundel offline.

## Tahap 91: tanda tangan pribadi langsung, tanpa tanda tangan ulang
- Bila ada tanda tangan pribadi yang aktif, semua hasil Bangun APK langsung ditandatangani dengan tanda tangan itu satu kali. Tidak ada lagi APK bertanda tangan debug yang kemudian ditandatangani ulang.
  - **Proyek sederhana**: sudah langsung sejak dulu.
  - **Proyek apktool (termasuk zip hasil bongkar)**: apksigner memakai tanda tangan pribadi langsung. Hasil: `<nama>-apktool-<tanda tangan>.apk`.
  - **Proyek Gradle (termasuk Capacitor dan Cordova)**: tanda tangan pribadi dipasang ke Gradle lewat skrip init (semua build type dan flavor), jadi APK keluar dari Gradle sudah bertanda tangan pribadi. Hasil di Download: `<nama>-<tanda tangan>.apk`.
- Penjaga tanda tangan tetap bekerja seperti sebelumnya: dipasang ke proyek sebelum dibangun, dan APK hasil bertanda tangan sama dengan sidik jari yang dikunci.
- Pengaman: setelah Gradle selesai, sidik jari tanda tangan tiap APK dibandingkan dengan tanda tangan pribadi. Hanya bila Gradle ternyata tidak menerapkannya (jarang), APK itu ditandatangani sekali dengan tanda tangan pribadi dan layar menyebutnya. Berkas bertanda tangan debug tidak lagi disalin ke Download.
- Tanpa tanda tangan pribadi (pilihan "bawaan"), alurnya sama seperti sebelumnya.
- Sandi tanda tangan diteruskan lewat berkas sementara `~/.novan-ttd` yang dihapus begitu proses selesai.

## Tahap 92: nama berkas APK berisi nama aplikasi dan versi
- Kata "debug" di nama berkas hanya bawaan Gradle (`app-debug.apk`), bukan tanda tangan. Tanda tangannya tetap pribadi.
- Semua hasil bangun APK (sederhana, apktool, Gradle) kini diberi nama dari isi APK-nya: `<Nama aplikasi>_v<versi>.apk`, contoh `Pembaca_Uang_Novan_v2.3.apk`.
  - Nama aplikasi dan versi dibaca dari APK hasil dengan aapt2 (label aplikasi dan versionName). Spasi dan tanda baca diganti garis bawah.
  - Bila label aplikasi kosong atau bukan huruf Latin, dipakai nama paket. Bila tidak ada versionName, dipakai `_kode<versionCode>`.
  - Bila Gradle menghasilkan beberapa APK (pecahan ABI atau flavor), varian ditambahkan di akhir, contoh `..._v2.3_arm64-v8a.apk`. Kata debug, release, dan unsigned dibuang dari varian.
  - Bila APK tidak bisa dibaca, nama lama dipakai.
- Nama tanda tangan tidak lagi ditambahkan ke nama berkas.

## Tahap 93: tema tampilan
- Tampilan kini mengikuti tema sistem HP (terang atau gelap), termasuk semua dialog.
- Menu lainnya, **Tema tampilan**: pilih Ikuti sistem, Terang, atau Gelap. Pilihan disimpan dan langsung berlaku.
- Saat tema sistem berubah, tampilan ikut berganti otomatis (bila memilih Ikuti sistem).
- Versi naik jadi 1.61 (kode 62).

## Tahap 94: cermin unduhan lebih stabil
- Tema tampilan tidak menyentuh kode penyiapan alat. Lambatnya penyiapan datang dari cermin (server) unduhan yang dipakai.
- Uji kecepatan cermin kini memakai contoh 2 MB (sebelumnya 500 KB), jadi tidak mudah tertipu kecepatan sesaat. Cermin yang unduhannya terlalu kecil dianggap gagal.
- Cermin tercepat dikunci. Bila berganti sendiri setelah daftar paket diperbarui, dikembalikan lagi.
- Pemasangan alat memakai apt-get langsung, bukan pkg.
- Versi naik jadi 1.62 (kode 63).

## Tahap 95: cermin resmi diutamakan
- Cermin acak bawaan Termux (misalnya di Tiongkok atau Rusia) tidak dipakai lagi.
- Yang diuji: packages.termux.dev, packages-cf.termux.dev, dan tiga cermin Asia. Cermin resmi dihitung 2 kali lebih diutamakan karena lebih stabil.
- Bila semua uji gagal, dipakai cermin resmi.
- Daftar paket diperbarui dengan apt-get langsung, jadi cermin tidak diganti pkg.
- Cermin yang dipakai tampil di layar utama: "Memakai cermin: ...".
- Versi naik jadi 1.63 (kode 64).

## Tahap 96: unduhan alat lebih cepat
- Penyiapan alat tetap lambat walau memakai cermin resmi, jadi penyebabnya bukan hanya cermin.
- Paket kini diunduh paralel (sampai 6 sekaligus), dan file besar seperti Java dipotong 4 bagian. Dulu apt mengunduh satu per satu.
- Setiap file dicek ukuran dan sidik jarinya (SHA256) sebelum dipakai. Bila gagal, apt mengunduh seperti biasa.
- Java tidak lagi terunduh dua kali: bila openjdk-21 atau openjdk-17 sudah terpasang, tahap Java dilewati.
- Dialog menampilkan "Terunduh X dari Y MB".
- Versi naik jadi 1.64 (kode 65).

## Tahap 97: bundel alat diunduh dari tautan
- Bila belum ada bundel di folder Download, saat Bangun APK pertama kali (atau perintah `siap`) alat diunduh dari tautan bundel: https://github.com/novanblind/Peralatantermux/releases/download/v2/TerminalNovan-bundel-20261118.zip
- Unduhan disimpan di penyimpanan aplikasi, bisa dilanjutkan bila terputus (3 percobaan), lalu dicek isinya (format dan arsitektur) sebelum dipasang. Berkas unduhan dihapus otomatis setelah alat selesai terpasang.
- Bundel di folder Download tetap diutamakan dibanding tautan.
- Alat yang kurang di dalam bundel (paket apt, NDK, Android SDK, Gradle) diunduh dari sumber aslinya: paket dari packages.termux.dev, bootstrap dari rilis termux-packages. Bila tautan gagal total, semua alat memakai sumber asli Termux seperti sebelumnya.
- Versi naik jadi 1.65 (kode 66).

## Tahap 98: persen unduhan bundel berjalan
- Sebelumnya persen di dialog diam di 0 saat bundel diunduh, karena seluruh unduhan hanya dipetakan ke 0 sampai 5 persen. Kini unduhan memakai 0 sampai 50 persen, sisanya untuk memasang alat.
- Dialog menampilkan "Terunduh X MB dari Y MB" di bawah persen.
- Versi naik jadi 1.66 (kode 67).

## Tahap 99: Termux Data Novan, perbaikan proyek native digabung
- Nama aplikasi kini Termux Data Novan (data alat diunduh dari tautan bundel milik sendiri). Nama paket tetap com.termux. Versi 1.67 (kode 68).
- Digabung dari jalur lain: bangun-gradle memakai cmake dan ninja milik HP untuk proyek dengan kode native (dipasang otomatis bila belum ada), `cmake.dir` di `local.properties` diisi ulang, dan versi CMake proyek disamakan dengan cmake HP. Di log tampil: `CMake proyek 3.22.1 diganti CMake HP ...`.
- Digabung juga: bila clang NDK berjenis ET_EXEC (`clang-21 has unexpected e_type: 2`), clang NDK diganti pembungkus yang memanggil clang milik HP; berkas asli disimpan berakhiran .asli. Di log tampil: `Memeriksa clang milik NDK: ... (jenis ELF 2)`.
- Alat clang, lld, cmake dan ninja dipasang dari repositori Termux saat proyek native pertama dibangun, jadi butuh internet pada saat itu.
- Untuk memastikan skrip baru terpakai: `grep -c "Memeriksa clang" $PREFIX/bin/bangun-gradle` harus 1.

## Tahap 100: cari tanda tangan di folder lain
- Impor tanda tangan: bila berkas .p12 tidak ada di folder Download, di dialog impor ada tombol "Cari di folder lain". Tombol itu membuka penjelajah folder (naik ke folder atas, Lokasi cepat, kartu SD atau USB) untuk memilih berkas .p12 atau .pfx di mana saja. Folder terakhir yang dibuka diingat.
- Perintah baru `jelajah-ttd`: membuka penjelajah yang sama dari terminal, lalu ketik `impor-ttd 1 <sandi>`. Pesan `cari-ttd` yang tidak menemukan berkas kini menyebut perintah ini.
- Berkas .pfx ikut dikenali, dan berkas info sandi di sebelah .p12 atau .pfx tetap dibaca otomatis.
- Versi 1.68 (kode 69).

## Tahap 101: tanda tangan di subfolder Download ikut terdeteksi
- Pencarian tanda tangan kini masuk ke semua subfolder di dalam Download (sampai 6 tingkat), jadi berkas .p12 atau .pfx yang disimpan di folder dalam folder tetap ketemu. Di daftar, tiap berkas ditulis dengan lokasi foldernya, misalnya "Download/ttd".
- Versi 1.70 (kode 71).
