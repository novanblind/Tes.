package com.novan.filemanagerpro

import java.io.File
import java.util.TreeMap

/**
 * Pembaca lembar kerja Excel lama (.xls, BIFF8: Excel 97 sampai 2003) tanpa library tambahan.
 * Hasilnya blok yang sama dengan penampil .xlsx: satu judul per lembar, baris dibacakan
 * dengan nama kolom bila baris pertama berisi judul kolom.
 */
object LegacyXls {

    private class Sheet(val name: String, val pos: Long, val hidden: Boolean, val isWorksheet: Boolean)

    private fun u16(b: ByteArray, o: Int): Int =
        if (o < 0 || o + 2 > b.size) 0 else (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long =
        if (o < 0 || o + 4 > b.size) 0 else
            (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
                ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private fun f64(b: ByteArray, o: Int): Double =
        if (o < 0 || o + 8 > b.size) 0.0 else
            java.lang.Double.longBitsToDouble(u32(b, o) or (u32(b, o + 4) shl 32))

    /** Satu rekaman BIFF: id, awal data, panjang data. */
    private class Rec(val id: Int, val off: Int, val len: Int)

    private class Records(val b: ByteArray) {
        var pos = 0
        fun next(): Rec? {
            if (pos + 4 > b.size) return null
            val id = u16(b, pos)
            val len = u16(b, pos + 2)
            val r = Rec(id, pos + 4, len)
            pos += 4 + len
            if (pos > b.size) { pos = b.size; return Rec(id, r.off, maxOf(0, b.size - r.off)) }
            return r
        }
    }

    fun parse(f: File): OfficeReader.Doc {
        OleFile(f).use { ole ->
            val wb = ole.readStream("Workbook") ?: ole.readStream("Book")
                ?: throw IllegalStateException("bukan lembar kerja Excel")
            return parseStream(wb)
        }
    }

    internal fun parseStream(wb: ByteArray): OfficeReader.Doc {
        val sheets = ArrayList<Sheet>()
        val sst = ArrayList<String>()
        val xfFmt = ArrayList<Int>()
        val customDate = HashMap<Int, Boolean>()
        var date1904 = false

        // ---- bagian global buku kerja
        val rr = Records(wb)
        var first = true
        while (true) {
            val r = rr.next() ?: break
            if (first) {
                first = false
                if (r.id != 0x809 && r.id != 0x09) throw IllegalStateException("bukan lembar kerja Excel")
                if (r.id == 0x09 || u16(wb, r.off) < 0x600) {
                    throw IllegalStateException("Format Excel 5/95 yang sangat lama belum didukung. Gunakan Buka dengan aplikasi lain.")
                }
                continue
            }
            when (r.id) {
                0x2F -> throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
                0x22 -> date1904 = u16(wb, r.off) == 1
                0x85 -> {
                    val pos = u32(wb, r.off)
                    val state = wb[r.off + 4].toInt() and 3
                    val type = wb[r.off + 5].toInt() and 0xFF
                    val cch = wb[r.off + 6].toInt() and 0xFF
                    val hi = (wb[r.off + 7].toInt() and 1) != 0
                    val name = readChars(wb, r.off + 8, cch, hi, r.off + r.len)
                    sheets.add(Sheet(name, pos, state != 0, type == 0))
                }
                0xE0 -> xfFmt.add(u16(wb, r.off + 2))
                0x41E -> {
                    val id = u16(wb, r.off)
                    val cch = u16(wb, r.off + 2)
                    val hi = (wb[r.off + 4].toInt() and 1) != 0
                    customDate[id] = OfficeReader.isDateCode(readChars(wb, r.off + 5, cch, hi, r.off + r.len))
                }
                0xFC -> {
                    // gabungkan rekaman CONTINUE (0x3C) berikutnya
                    val chunks = ArrayList<Rec>()
                    chunks.add(r)
                    while (rr.pos + 4 <= wb.size && u16(wb, rr.pos) == 0x3C) chunks.add(rr.next()!!)
                    readSst(wb, chunks, sst)
                }
                0x0A -> break
            }
        }
        val dateXf = xfFmt.map { id -> customDate[id] ?: (id in OfficeReader.BUILTIN_DATE) }

        val doc = OfficeReader.Doc()
        doc.format = "xls"
        doc.kind = "sheet"
        doc.typeName = "Lembar kerja Excel format lama"
        val visible = sheets.filter { it.isWorksheet && !it.hidden }
        val total = visible.size
        if (total == 0) {
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Buku kerja ini tidak berisi lembar yang bisa dibaca."))
            return doc
        }
        for ((i, sh) in visible.withIndex()) {
            doc.sheets++
            val rows = SheetReader(wb, sst, dateXf, date1904).read(sh.pos.toInt())
            val sr = OfficeReader.SheetRows()
            for ((rowNum, cells) in rows) {
                cells.sortBy { it.col }
                sr.addRow(rowNum, cells)
            }
            if (doc.blocks.size + sr.out.size + 2 > OfficeReader.MAX_BLOCKS) doc.truncated = true
            doc.headings++
            doc.blocks.add(OfficeReader.Block(OfficeReader.K_HEADING, 1, "Lembar ${i + 1} dari $total: ${sh.name}"))
            if (sr.out.isEmpty()) {
                doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Lembar ini kosong."))
            } else {
                val range = if (sr.minCol == sr.maxCol) "kolom ${OfficeReader.colLetters(sr.minCol)}"
                else "kolom ${OfficeReader.colLetters(sr.minCol)} sampai ${OfficeReader.colLetters(sr.maxCol)}"
                doc.tables++
                doc.blocks.add(OfficeReader.Block(OfficeReader.K_TABLE, 0, "${sr.out.size} baris berisi data, $range"))
                for (b in sr.out) {
                    if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) { doc.truncated = true; break }
                    doc.blocks.add(b)
                    doc.rows++
                }
            }
            if (doc.truncated) break
        }
        return doc
    }

    private fun readChars(b: ByteArray, off: Int, cch: Int, hi: Boolean, limit: Int): String {
        val bytes = if (hi) cch * 2 else cch
        val end = minOf(off + bytes, limit, b.size)
        if (off < 0 || end <= off) return ""
        return if (hi) String(b, off, (end - off) and 1.inv(), Charsets.UTF_16LE)
        else String(b, off, end - off, Charsets.ISO_8859_1)
    }

    // ---- tabel string bersama (SST) dengan rekaman lanjutan

    private fun readSst(b: ByteArray, chunks: List<Rec>, out: ArrayList<String>) {
        var ci = 0
        var pos = chunks[0].off + 8 // lewati jumlah total dan unik
        var end = chunks[0].off + chunks[0].len
        val unique = u32(b, chunks[0].off + 4).toInt().coerceIn(0, 5_000_000)

        fun nextChunk(): Boolean {
            ci++
            if (ci >= chunks.size) return false
            pos = chunks[ci].off
            end = pos + chunks[ci].len
            return true
        }

        for (n in 0 until unique) {
            if (pos + 3 > end && !nextChunk()) return
            if (pos + 3 > end) return
            val cch = u16(b, pos)
            val flags = b[pos + 2].toInt() and 0xFF
            pos += 3
            var runs = 0
            var ext = 0
            if (flags and 0x08 != 0) { runs = u16(b, pos); pos += 2 }
            if (flags and 0x04 != 0) { ext = u32(b, pos).toInt().coerceIn(0, 100_000_000); pos += 4 }
            var hi = flags and 0x01 != 0
            val sb = StringBuilder(minOf(cch, 4096))
            var left = cch
            while (left > 0) {
                if (pos >= end) {
                    if (!nextChunk()) { out.add(sb.toString()); return }
                    hi = (b[pos].toInt() and 1) != 0
                    pos += 1
                    continue
                }
                val unit = if (hi) 2 else 1
                if (pos + unit > end) {
                    // pecah di tengah karakter: abaikan sisa
                    pos = end
                    continue
                }
                val ch = if (hi) u16(b, pos).toChar() else (b[pos].toInt() and 0xFF).toChar()
                if (sb.length < OfficeReader.MAX_BLOCK_CHARS) sb.append(ch)
                pos += unit
                left--
            }
            var skip = runs * 4 + ext
            while (skip > 0) {
                if (pos >= end) {
                    if (!nextChunk()) break
                    continue
                }
                val k = minOf(skip, end - pos)
                pos += k
                skip -= k
            }
            out.add(sb.toString())
        }
    }

    // ---- isi lembar

    private class SheetReader(
        val b: ByteArray,
        val sst: List<String>,
        val dateXf: List<Boolean>,
        val date1904: Boolean
    ) {
        private val rows = TreeMap<Int, ArrayList<OfficeReader.Cell>>()
        private var cellCount = 0
        private var pendingFormula: IntArray? = null // row, col, ixfe

        fun read(start: Int): TreeMap<Int, ArrayList<OfficeReader.Cell>> {
            if (start < 0 || start + 4 > b.size) return rows
            val rr = Records(b)
            rr.pos = start
            var depth = 0
            while (true) {
                val r = rr.next() ?: break
                when (r.id) {
                    0x809, 0x09 -> depth++
                    0x0A -> { depth--; if (depth <= 0) break }
                    else -> if (depth == 1) cell(r, rr)
                }
                if (cellCount > 1_500_000) break
            }
            return rows
        }

        private fun put(row: Int, col: Int, ixfe: Int, text: String, isText: Boolean) {
            if (text.isBlank()) return
            val t = if (text.length > OfficeReader.MAX_BLOCK_CHARS) text.substring(0, OfficeReader.MAX_BLOCK_CHARS) + "…" else text.trim()
            rows.getOrPut(row + 1) { ArrayList() }
                .add(OfficeReader.Cell(col + 1, t, isText && t.toDoubleOrNull() == null))
            cellCount++
        }

        private fun num(v: Double, ixfe: Int): String {
            val s = if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()
            return if (dateXf.getOrNull(ixfe) == true) OfficeReader.formatDate(v.toString(), date1904)
            else OfficeReader.formatNumber(s)
        }

        private fun rk(v: Long): Double {
            var d: Double = if (v and 2L != 0L) ((v and 0xFFFFFFFCL).toInt() shr 2).toDouble()
            else java.lang.Double.longBitsToDouble((v and 0xFFFFFFFCL) shl 32)
            if (v and 1L != 0L) d /= 100.0
            return d
        }

        private fun errText(c: Int): String = when (c) {
            0x00 -> "#NULL!"; 0x07 -> "#DIV/0!"; 0x0F -> "#VALUE!"; 0x17 -> "#REF!"
            0x1D -> "#NAME?"; 0x24 -> "#NUM!"; 0x2A -> "#N/A"; else -> "#ERR"
        }

        private fun xlString(off: Int, limit: Int): String {
            val cch = u16(b, off)
            val flags = b[off + 2].toInt() and 0xFF
            var p = off + 3
            if (flags and 0x08 != 0) p += 2
            if (flags and 0x04 != 0) p += 4
            return readChars(b, p, cch, flags and 1 != 0, limit)
        }

        private fun cell(r: Rec, rr: Records) {
            val o = r.off
            when (r.id) {
                0xFD -> { // LABELSST
                    pendingFormula = null
                    val s = sst.getOrNull(u32(b, o + 6).toInt()) ?: ""
                    put(u16(b, o), u16(b, o + 2), u16(b, o + 4), s, true)
                }
                0x204 -> { // LABEL
                    pendingFormula = null
                    put(u16(b, o), u16(b, o + 2), u16(b, o + 4), xlString(o + 6, o + r.len), true)
                }
                0x203 -> { // NUMBER
                    pendingFormula = null
                    val ix = u16(b, o + 4)
                    put(u16(b, o), u16(b, o + 2), ix, num(f64(b, o + 6), ix), false)
                }
                0x27E -> { // RK
                    pendingFormula = null
                    val ix = u16(b, o + 4)
                    put(u16(b, o), u16(b, o + 2), ix, num(rk(u32(b, o + 6)), ix), false)
                }
                0xBD -> { // MULRK
                    pendingFormula = null
                    val row = u16(b, o)
                    val c0 = u16(b, o + 2)
                    val n = (r.len - 6) / 6
                    for (k in 0 until n) {
                        val ix = u16(b, o + 4 + k * 6)
                        put(row, c0 + k, ix, num(rk(u32(b, o + 6 + k * 6)), ix), false)
                    }
                }
                0x205 -> { // BOOLERR
                    pendingFormula = null
                    val v = b[o + 6].toInt() and 0xFF
                    val isErr = (b[o + 7].toInt() and 0xFF) != 0
                    val t = if (isErr) "Galat " + errText(v) else if (v != 0) "Benar" else "Salah"
                    put(u16(b, o), u16(b, o + 2), u16(b, o + 4), t, false)
                }
                0x06, 0x406 -> { // FORMULA
                    val row = u16(b, o)
                    val col = u16(b, o + 2)
                    val ix = u16(b, o + 4)
                    pendingFormula = null
                    if (u16(b, o + 12) == 0xFFFF) {
                        when (b[o + 6].toInt() and 0xFF) {
                            0 -> pendingFormula = intArrayOf(row, col, ix)
                            1 -> put(row, col, ix, if ((b[o + 8].toInt() and 0xFF) != 0) "Benar" else "Salah", false)
                            2 -> put(row, col, ix, "Galat " + errText(b[o + 8].toInt() and 0xFF), false)
                        }
                    } else {
                        put(row, col, ix, num(f64(b, o + 6), ix), false)
                    }
                }
                0x207 -> { // STRING (hasil rumus teks)
                    val pf = pendingFormula
                    pendingFormula = null
                    if (pf != null && r.len >= 3) {
                        var end = o + r.len
                        // gabungkan lanjutan sederhana: abaikan, cukup bagian pertama
                        put(pf[0], pf[1], pf[2], xlString(o, end), true)
                    }
                }
            }
        }
    }
}
