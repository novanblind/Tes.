package com.novan.talkbacknovan;

import android.content.Context;
import android.content.SharedPreferences;

/** Akses ke pengaturan aplikasi. */
public final class Prefs {
    public static final String NAMA = "pengaturan";

    public static final String K_LAJU = "laju";          // 50..300 (persen)
    public static final String K_NADA = "nada";          // 50..200 (persen)
    public static final String K_MESIN = "mesin";        // nama paket mesin TTS, kosong = bawaan
    public static final String K_NOTIF = "notifikasi";   // ucapkan notifikasi dan toast
    public static final String K_GEMA = "gema_ketik";    // 0 tidak, 1 karakter, 2 kata, 3 keduanya
    public static final String K_GETAR = "getar";        // getar singkat saat fokus berpindah
    public static final String K_PERAN = "ucap_peran";   // ucapkan jenis kontrol dan status
    public static final String K_JENDELA = "ucap_jendela"; // ucapkan judul jendela/dialog

    // Tahap 2
    public static final String K_VOLUME = "tombol_volume";  // tekan lama tombol volume = aksi
    public static final String K_GULIR_INFO = "info_gulir"; // ucapkan "item x sampai y dari z"

    // Tahap 3
    public static final String K_NOTIF_APP = "notif_nama_app";     // sebut nama aplikasi
    public static final String K_HITAM_NOTIF = "hitam_notif";       // paket yang notifikasinya diam
    public static final String K_HITAM_OTOMATIS = "hitam_otomatis"; // paket yang bacaan otomatisnya diam
    public static final String K_NAMA = "aturan_nama";              // aturan ganti nama elemen

    // Tahap 5
    public static final String K_OCR_MESIN = "ocr_mesin";        // 0 Gemini, 1 Groq
    public static final String K_GEMINI_KUNCI = "gemini_kunci";
    public static final String K_GEMINI_MODEL = "gemini_model";
    public static final String K_GROQ_KUNCI = "groq_kunci";
    public static final String K_GROQ_MODEL = "groq_model";
    public static final String K_OCR_BUKA = "ocr_buka_baca";      // tampilkan hasil di halaman baca

    // Tahap 7
    public static final String K_EFEK = "efek_suara";          // efek suara
    public static final String K_EFEK_VOL = "efek_volume";     // 0..100
    public static final String K_DUCK = "kecilkan_audio";      // kecilkan audio lain saat bicara
    public static final String K_JARAK = "sensor_jarak";       // berhenti bicara bila sensor jarak tertutup
    public static final String K_SENTUH_DIAM = "sentuh_diam";  // sentuh layar menghentikan ucapan
    public static final String K_VOL_TTS = "volume_tts";       // 0..100
    public static final String K_GETAR_KUAT = "getar_kuat";    // 1..255
    public static final String K_GETAR_LAMA = "getar_lama";    // ms

    // Tahap 8
    public static final String VA_KLIK2 = "vol_atas_2x";
    public static final String VA_KLIK3 = "vol_atas_3x";
    public static final String VB_KLIK2 = "vol_bawah_2x";
    public static final String VB_KLIK3 = "vol_bawah_3x";
    public static final String K_HEADSET = "tombol_headset";
    public static final String HS_KLIK = "headset_klik";
    public static final String HS_KLIK2 = "headset_klik2";
    public static final String HS_LAMA = "headset_lama";

    // Tahap 9
    public static final String K_USAP_NAV = "usap_kiri_kanan_navigasi"; // kiri/kanan = pindah fokus, atas/bawah = fungsi pintas
    public static final String K_NAV_JENIS = "navigasi_menurut_jenis"; // atas/bawah = jenis navigasi, kiri/kanan = item, di semua tampilan
    public static final String K_EMOJI = "baca_emoji";   // bacakan emoji dengan nama Indonesia (emoji_id.txt)

    public static final String G2_ATAS = "g2_atas";
    public static final String G2_BAWAH = "g2_bawah";
    public static final String G2_KIRI = "g2_kiri";
    public static final String G2_KANAN = "g2_kanan";
    public static final String G2_KETUK2 = "g2_ketuk2";
    public static final String G3_KETUK = "g3_ketuk";
    public static final String G3_KETUK2 = "g3_ketuk2";
    public static final String G3_ATAS = "g3_atas";
    public static final String G3_BAWAH = "g3_bawah";
    public static final String G3_KIRI = "g3_kiri";
    public static final String G3_KANAN = "g3_kanan";
    public static final String VOL_ATAS = "vol_atas_lama";
    public static final String VOL_BAWAH = "vol_bawah_lama";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAMA, Context.MODE_PRIVATE);
    }

    /** Aksi bawaan untuk tiap gestur/tombol. */
    public static int aksiBawaan(String kunci) {
        switch (kunci) {
            case G2_ATAS: return Aksi.TIDAK_ADA;
            case G2_BAWAH: return Aksi.TIDAK_ADA;
            case G2_KIRI: return Aksi.TIDAK_ADA;
            case G2_KANAN: return Aksi.TIDAK_ADA;
            case G2_KETUK2: return Aksi.MEDIA;
            case G3_KETUK: return Aksi.INFO;
            case G3_KETUK2: return Aksi.BACA_DARI_SINI;
            case G3_ATAS: return Aksi.BERANDA;
            case G3_BAWAH: return Aksi.NOTIFIKASI;
            case G3_KIRI: return Aksi.TERBARU;
            case G3_KANAN: return Aksi.PENGATURAN_CEPAT;
            case VOL_ATAS: return Aksi.KETUK;
            case VOL_BAWAH: return Aksi.BACA_DARI_SINI;
            case HS_KLIK: return Aksi.ITEM_MAJU;
            case HS_KLIK2: return Aksi.ITEM_MUNDUR;
            case HS_LAMA: return Aksi.KETUK;
            default: return Gestur.bawaan(kunci);
        }
    }

    public static java.util.Set<String> daftar(Context c, String kunci) {
        return new java.util.HashSet<>(get(c).getStringSet(kunci, new java.util.HashSet<String>()));
    }

    public static int aksi(Context c, String kunci) {
        if (get(c).getBoolean(K_NAV_JENIS, true)) {
            switch (kunci) {
                case "gx_atas": return Aksi.GRAN_SEBELUM;
                case "gx_bawah": return Aksi.GRAN_BERIKUT;
                case "gx_kiri": return Aksi.ITEM_MUNDUR;
                case "gx_kanan": return Aksi.ITEM_MAJU;
                default: break;
            }
        }
        int dasar = aksiBawaan(kunci);
        if (get(c).getBoolean(K_USAP_NAV, true)) {
            switch (kunci) {
                case "gx_atas": dasar = Aksi.GRAN_SEBELUM; break;
                case "gx_bawah": dasar = Aksi.GRAN_BERIKUT; break;
                case "gx_kiri": dasar = Aksi.ITEM_MUNDUR; break;
                case "gx_kanan": dasar = Aksi.ITEM_MAJU; break;
                default: break;
            }
        }
        int v = get(c).getInt(kunci, dasar);
        return (v < 0 || v >= Aksi.NAMA.length) ? Aksi.TIDAK_ADA : v;
    }
}
