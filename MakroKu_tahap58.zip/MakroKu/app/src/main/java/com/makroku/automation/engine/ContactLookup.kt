package com.makroku.automation.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone

/** Mencari nama kontak dari nomor telepon. Mengembalikan teks kosong bila izin Kontak belum diberi atau nomor tidak tersimpan. */
object ContactLookup {
    fun name(ctx: Context, number: String): String {
        val n = number.trim()
        if (n.isEmpty()) return ""
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0).orEmpty() else ""
            }.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }

    /** Mencari nomor dari nama kontak (sebagian nama boleh; nama persis didahulukan). Kosong bila tidak ada atau izin belum diberi. */
    fun numberOf(ctx: Context, name: String): String {
        val n = name.trim()
        if (n.isEmpty()) return ""
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        return try {
            var terbaik = ""
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.NUMBER, Phone.DISPLAY_NAME),
                "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$n%"), null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val num = c.getString(0).orEmpty()
                    val nama = c.getString(1).orEmpty()
                    if (terbaik.isEmpty()) terbaik = num
                    if (nama.equals(n, ignoreCase = true)) { terbaik = num; break }
                }
            }
            terbaik
        } catch (e: Exception) {
            ""
        }
    }
}
