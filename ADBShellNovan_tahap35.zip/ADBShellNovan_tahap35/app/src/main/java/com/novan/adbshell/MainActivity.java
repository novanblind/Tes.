package com.novan.adbshell;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.github.muntashirakon.adb.AdbStream;

public class MainActivity extends Activity {
    private EditText etPort, etCode, etCmd;
    private TextView tvStatus, tvOut;
    private ScrollView scroll;
    private View[] viewSetup, viewTerhubung;
    private boolean sedangTersambung;
    private boolean statusPernahDiperiksa;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("adb", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        int pad = (int) (12 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView help = new TextView(this);
        help.setText("Pairing pertama kali, cukup 3 langkah:\n"
                + "1) Pastikan Wi-Fi tersambung, lalu ketuk Mulai pairing. Opsi pengembang terbuka sendiri.\n"
                + "2) Di sana nyalakan Wireless debugging, lalu pilih Pasangkan perangkat dengan kode pairing.\n"
                + "3) Tarik bilah notifikasi dan ketik kode 6 angka di kolom balasan notifikasi. Selesai.\n"
                + "Pairing cukup sekali. Setelah itu aplikasi tersambung sendiri, termasuk setelah HP restart, dan Wi-Fi boleh dimatikan.");

        Button btnStart = button("Mulai pairing (sekalian buka Opsi pengembang)", v -> {
            PairHelper.startDiscovery(this);
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (Exception e) { status("Buka manual: Pengaturan > Opsi pengembang > Wireless debugging"); }
        });
        etPort = field("Port pairing (terisi otomatis atau ketik manual)", "", InputType.TYPE_CLASS_NUMBER);
        etCode = field("Kode pairing 6 angka (cara manual)", "", InputType.TYPE_CLASS_NUMBER);
        Button btnPair = button("Pasangkan manual", v -> manualPair());
        Button btnConnect = button("Sambungkan", v -> io.execute(() -> PairHelper.connect(this)));
        Button btnDisc = button("Putuskan", v -> io.execute(() -> {
            try { Adb.get(this).disconnect(); status("Terputus"); } catch (Throwable e) { status("Gagal memutus: " + e); }
        }));
        // Mode tanpa Wi-Fi, bebas baterai, dan izin sambung otomatis berjalan sendiri saat tersambung,
        // jadi tombolnya tidak ditampilkan (lihat Latar.terapkanOtomatis).
        Button btnAuto = button("Aktifkan sambung otomatis setelah restart", v -> enableAuto());
        Button btnTanpaWifi = button("Aktifkan mode tanpa Wi-Fi (port 5555)", v -> io.execute(() -> status(Latar.aktifkanModeTanpaWifi(this, adbAman()))));
        Button btnBaterai = button("Bebaskan dari pembatasan baterai latar belakang", v -> bebaskanBaterai());
        Button btnOtomatis = button(Latar.otomatisAktif(this) ? "Bebas baterai otomatis: AKTIF (ketuk untuk matikan)" : "Bebas baterai otomatis: MATI (ketuk untuk aktifkan)", null);
        btnOtomatis.setOnClickListener(v -> {
            boolean baru = !Latar.otomatisAktif(this);
            Latar.prefs(this).edit().putBoolean("otomatis", baru).apply();
            btnOtomatis.setText(baru ? "Bebas baterai otomatis: AKTIF (ketuk untuk matikan)" : "Bebas baterai otomatis: MATI (ketuk untuk aktifkan)");
            status(baru ? "Bebas baterai akan diterapkan sendiri setiap tersambung, juga setelah HP restart."
                        : "Otomatis dimatikan.");
        });
        Button btnUcapan = button(TtsHelper.aktif(this) ? "Ucapan status ADB: AKTIF (ketuk untuk matikan)" : "Ucapan status ADB: MATI (ketuk untuk aktifkan)", null);
        btnUcapan.setOnClickListener(v -> {
            boolean baru = !TtsHelper.aktif(this);
            prefs.edit().putBoolean("ucapan", baru).apply();
            btnUcapan.setText(baru ? "Ucapan status ADB: AKTIF (ketuk untuk matikan)" : "Ucapan status ADB: MATI (ketuk untuk aktifkan)");
            status(baru ? "Ucapan status ADB diaktifkan." : "Ucapan status ADB dimatikan.");
        });
        Button btnInstall = button("Pasang APK, APKS, APKM, XAPK (tercatat dari Google Play Store)", v -> pickApk());
        Button btnApps = button("Kelola aplikasi (nonaktifkan, hapus instalan, kembalikan)",
                v -> startActivity(new Intent(this, AppManagerActivity.class)));
        Button btnRam = button("Aplikasi berjalan dan pemakaian RAM",
                v -> startActivity(new Intent(this, RamActivity.class)));
        Button btnLogcat = button("Log aplikasi (cari tahu kenapa aplikasi bermasalah)",
                v -> startActivity(new Intent(this, LogcatActivity.class)));
        Button btnPantauLangsung = button("Pantau log langsung (pilih aplikasi, langsung dibuka dan dipantau)",
                v -> startActivity(new Intent(this, LogcatActivity.class).putExtra("langsung", true)));
        Button btnSampah = button("Bersihkan sampah aplikasi (cache semua aplikasi sekaligus)",
                v -> bersihkanSampah());
        Button btnOpsiPengembang = button("Buka Opsi pengembang", v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (Exception e) { status("Buka manual: Pengaturan > Opsi pengembang"); }
        });
        tvStatus = new TextView(this);
        tvStatus.setText("Belum tersambung");
        tvStatus.setPadding(0, pad / 2, 0, pad / 2);

        prefs.edit().remove("cmd").apply(); // riwayat perintah lama dihapus; kolom selalu mulai kosong
        etCmd = field("Perintah shell, contoh: pm list packages", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        etCmd.setImeOptions(EditorInfo.IME_ACTION_SEND);
        etCmd.setOnEditorActionListener((v, a, e) -> { runCommand(); return true; });
        Button btnRun = button("Jalankan", v -> runCommand());
        Button btnClear = button("Bersihkan keluaran", v -> tvOut.setText(""));
        Button btnCopy = button("Salin keluaran", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("adb", tvOut.getText()));
            Toast.makeText(this, "Tersalin", Toast.LENGTH_SHORT).show();
        });

        tvOut = new TextView(this);
        tvOut.setTextIsSelectable(true);
        tvOut.setContentDescription("Keluaran perintah");
        tvOut.setPadding(0, pad / 2, 0, pad);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        viewSetup = new View[]{help, btnStart, etPort, etCode, btnPair, btnConnect, btnAuto};
        viewTerhubung = new View[]{btnDisc, btnOpsiPengembang, btnInstall, btnApps, btnRam, btnLogcat, btnPantauLangsung, btnSampah,
                etCmd, btnRun, btnClear, btnCopy, tvOut};
        for (View v : new View[]{help, btnStart, etPort, etCode, btnPair, btnConnect, btnAuto, btnDisc,
                btnOpsiPengembang, btnUcapan, btnInstall, btnApps, btnRam, btnLogcat, btnPantauLangsung, btnSampah, tvStatus, etCmd, btnRun, btnClear, btnCopy, tvOut}) top.addView(v);
        // Satu ScrollView untuk semuanya: tombol di atas, keluaran tepat di bawahnya, memenuhi layar.
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(top, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
        perbaruiTampilan();

        PairHelper.sink = s -> status(s);
        if (prefs.getBoolean("paired", false)) io.execute(() -> PairHelper.connect(this, true));
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    /** Berkas yang dibuka lewat "Buka dengan" atau "Bagikan" dari pengelola berkas. */
    private void handleIntent(Intent i) {
        if (i == null) return;
        String act = i.getAction();
        List<Uri> daftar = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) {
            daftar.add(i.getData());
        } else if (Intent.ACTION_SEND.equals(act)) {
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) daftar.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(act)) {
            ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) daftar.addAll(l);
        }
        if (daftar.isEmpty()) return;
        i.setAction(Intent.ACTION_MAIN); // jangan diproses ulang saat layar diputar
        pasang(daftar);
    }

    @Override protected void onResume() {
        super.onResume();
        PairHelper.sink = s -> status(s);
        perbaruiTampilan();
        pantau.run();
    }

    // Periksa status koneksi tiap 2 detik agar tampilan ikut berubah saat tersambung atau terputus.
    private final Runnable pantau = new Runnable() {
        @Override public void run() {
            perbaruiTampilan();
            if (tvStatus != null) tvStatus.postDelayed(this, 2000);
        }
    };

    @Override protected void onPause() {
        super.onPause();
        if (tvStatus != null) tvStatus.removeCallbacks(pantau);
    }

    /** Setelah tersambung, sembunyikan panduan, kolom port/kode, dan tombol pairing agar layar ringkas. */
    private void perbaruiTampilan() {
        boolean ok;
        try { ok = Adb.get(this).isConnected(); } catch (Throwable e) { ok = false; }
        // Ucapkan lewat TTS hanya saat statusnya benar-benar berubah (bukan saat aplikasi baru dibuka),
        // supaya tahu tersambung/terputus tanpa perlu mengecek layar.
        if (statusPernahDiperiksa && ok != sedangTersambung) {
            TtsHelper.speak(this, ok ? "ADB tersambung" : "ADB terputus");
        }
        statusPernahDiperiksa = true;
        sedangTersambung = ok;
        if (viewSetup == null) return;
        for (View v : viewSetup) v.setVisibility(ok ? View.GONE : View.VISIBLE);
        for (View v : viewTerhubung) v.setVisibility(ok ? View.VISIBLE : View.GONE);
    }

    private EditText field(String hint, String text, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setContentDescription(hint);
        e.setText(text);
        e.setInputType(type);
        e.setSingleLine(true);
        return e;
    }

    private Button button(String label, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(label);
        x.setOnClickListener(l);
        return x;
    }

    private void status(final String s) {
        runOnUiThread(() -> {
            tvStatus.setText(s);
            tvStatus.announceForAccessibility(s);
            perbaruiTampilan();
            if (PairHelper.pairPort > 0 && etPort.getText().length() == 0)
                etPort.setText(String.valueOf(PairHelper.pairPort));
        });
    }

    private void append(final String s) {
        runOnUiThread(() -> { tvOut.append(s); scroll.post(() -> scroll.scrollTo(0, Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight()))); });
    }

    private void manualPair() {
        final String p = etPort.getText().toString().trim();
        final String code = etCode.getText().toString().trim();
        if (p.isEmpty() || code.isEmpty()) { status("Isi port dan kode pairing"); return; }
        io.execute(() -> PairHelper.pairAndConnect(this, Integer.parseInt(p), code));
    }

    private void enableAuto() {
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) { status("Sambungkan dulu"); return; }
                String r = Shell.run(a, "shell:pm grant " + getPackageName()
                        + " android.permission.WRITE_SECURE_SETTINGS", null);
                boolean ok = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                        == PackageManager.PERMISSION_GRANTED;
                if (ok) Latar.aktifkanDebugging(this);
                status(ok ? "Sambung otomatis aktif. Setelah HP restart, Debugging USB dan nirkabel dinyalakan sendiri, dan waktu tunggu otorisasi adb dimatikan. Izinkan juga mulai otomatis untuk aplikasi ini."
                        : "Gagal memberi izin: " + r);
            } catch (Throwable e) { status("Gagal: " + e); }
        });
    }

    /**
     * Bersihkan sampah (cache) SEMUA aplikasi sekaligus lewat satu perintah ADB (pm trim-caches),
     * jadi tidak perlu dilakukan satu per satu per aplikasi. Hanya cache yang dihapus,
     * bukan data/akun/login aplikasi, jadi aman untuk YouTube, aplikasi ojek online, dan lainnya.
     */
    private void bersihkanSampah() {
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) { status("Sambungkan dulu"); return; }
                status("Membersihkan sampah (cache) semua aplikasi...");
                long sebelum = ruangTersediaKb(Shell.run(a, "shell:df /data", null));
                Shell.run(a, "shell:pm trim-caches 999999999999", null);
                long sesudah = ruangTersediaKb(Shell.run(a, "shell:df /data", null));
                if (sebelum >= 0 && sesudah > sebelum) {
                    status("Selesai. Sekitar " + ((sesudah - sebelum) / 1024) + " MB ruang dibebaskan dari sampah aplikasi.");
                } else {
                    status("Selesai membersihkan sampah aplikasi.");
                }
            } catch (Throwable e) { status("Gagal membersihkan sampah: " + e); }
        });
    }

    /** Ambil kolom "Available" (dalam KB) untuk baris /data dari keluaran "df /data". */
    private static long ruangTersediaKb(String df) {
        if (df == null) return -1;
        for (String baris : df.split("\\r?\\n")) {
            baris = baris.trim();
            if (baris.endsWith("/data")) {
                String[] t = baris.split("\\s+");
                if (t.length >= 4) { try { return Long.parseLong(t[3]); } catch (Throwable ignored) {} }
            }
        }
        return -1;
    }

    private Adb adbAman() {
        try { return Adb.get(this); } catch (Exception e) { throw new RuntimeException(e); }
    }

    private void bebaskanBaterai() {
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                String hasil = a.isConnected() ? Latar.bebaskanBaterai(this, a) : "Belum tersambung ADB, membuka pengaturan baterai.";
                status(hasil);
                if (!Latar.bebasBateraiSistem(this)) {
                    runOnUiThread(() -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
                            catch (Exception e2) { status("Buka manual: Pengaturan > Baterai > aplikasi ini > Tanpa batasan"); }
                        }
                    });
                }
            } catch (Throwable e) { status("Gagal: " + e); }
        });
    }

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, 10);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 10 || res != RESULT_OK || data == null) return;
        List<Uri> daftar = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int k = 0; k < data.getClipData().getItemCount(); k++)
                daftar.add(data.getClipData().getItemAt(k).getUri());
        } else if (data.getData() != null) {
            daftar.add(data.getData());
        }
        if (!daftar.isEmpty()) pasang(daftar);
    }

    private static String nama(Context c, Uri u) {
        try (Cursor cur = c.getContentResolver().query(u, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int k = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (k >= 0 && !cur.isNull(k)) return cur.getString(k);
            }
        } catch (Throwable ignored) {}
        String l = u.getLastPathSegment();
        return l == null ? "berkas" : l;
    }

    /** Pasang berkas satu per satu (APK tunggal atau paket bundel). */
    private void pasang(final List<Uri> daftar) {
        io.execute(() -> {
            int sukses = 0;
            for (int k = 0; k < daftar.size(); k++) {
                Uri u = daftar.get(k);
                String nm = nama(this, u);
                String awal = daftar.size() > 1 ? "(" + (k + 1) + " dari " + daftar.size() + ") " : "";
                append("Memasang " + nm + "\n");
                status(awal + "Memasang " + nm + "...");
                try {
                    Adb a = Adb.get(this);
                    if (!a.isConnected()) PairHelper.connect(this, true);
                    if (!a.isConnected()) { status("Belum tersambung. Sambungkan dulu, lalu coba lagi."); return; }
                    String r = Shell.installApk(this, a, u, p -> status(awal + p));
                    append(r + "\n");
                    if (r.startsWith("Success")) {
                        sukses++;
                        status(awal + nm + " berhasil dipasang. Tercatat terinstal dari Google Play Store.");
                    } else {
                        status(awal + "Gagal memasang " + nm + ": " + r.trim());
                    }
                } catch (Throwable e) {
                    append("[galat] " + e + "\n");
                    status(awal + "Gagal memasang " + nm + ": " + e);
                }
            }
            if (daftar.size() > 1) status("Selesai: " + sukses + " dari " + daftar.size() + " berkas berhasil dipasang.");
        });
    }

    private void runCommand() {
        final String cmd = etCmd.getText().toString().trim();
        if (cmd.isEmpty()) return;
        etCmd.setText(""); // kosongkan kolom setelah dijalankan, tanpa riwayat
        append("$ " + cmd + "\n");
        status("Menjalankan...");
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) PairHelper.connect(this, true);
                if (!a.isConnected()) { status("Belum tersambung"); return; }
                // Shell.run menganggap "Stream closed" sebagai akhir data (normal untuk perintah berpipa).
                Shell.run(a, "shell:" + cmd, t -> append(t));
                append("\n");
                status("Selesai");
            } catch (Throwable e) {
                append("\n[galat] " + e + "\n");
                status("Galat: " + e);
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        PairHelper.sink = null;
        PairHelper.stopDiscovery(this);
        io.shutdownNow();
    }
}
