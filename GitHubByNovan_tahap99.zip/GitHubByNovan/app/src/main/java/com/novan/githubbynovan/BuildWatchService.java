package com.novan.githubbynovan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Memantau pembangunan APK di GitHub Actions sebagai layanan latar depan, sehingga pemantauan
 * tetap berjalan walaupun pengguna pindah ke aplikasi lain atau layar mati. Saat selesai,
 * hasilnya disimpan dan diberitahukan lewat notifikasi; dialog hasil muncul begitu aplikasi dibuka.
 */
public class BuildWatchService extends Service {
    public static final int KIND_DONE = 0, KIND_NO_RUN = 1, KIND_TIMEOUT = 2, KIND_FAILS = 3;

    /** Hasil akhir pemantauan, menunggu ditampilkan. */
    public static class Result {
        int kind;
        String full, token, detail = "";
        long idAwal;
        JSONObject run;
    }

    public interface Listener {
        void onStatus(String text);
        void onFinished();
    }

    private static final String ACTION_STOP = "com.novan.githubbynovan.STOP_WATCH";
    private static final String CH_WATCH = "pantau_apk";
    private static final String CH_RESULT = "hasil_apk";
    private static final int ID_WATCH = 41, ID_RESULT = 42;
    private static final long JEDA = 10000, MAX_MUNCUL = 120, MAX_TOTAL = 10800;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static volatile Listener listener;
    static volatile String lastText = "";
    static volatile boolean running;
    private static Result pending;

    static synchronized void setPending(Result r) { pending = r; }
    static synchronized Result takePending() { Result r = pending; pending = null; return r; }
    static synchronized boolean hasPending() { return pending != null; }

    private Thread worker;
    private PowerManager.WakeLock lock;

    // ---------- pintu masuk ----------

    public static boolean start(Context c, String full, String token, long idAwal) {
        setPending(null);
        lastText = "";
        cancelResultNotification(c);
        Intent i = new Intent(c, BuildWatchService.class)
                .putExtra("full", full).putExtra("token", token).putExtra("idAwal", idAwal);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void stop(Context c) {
        c.stopService(new Intent(c, BuildWatchService.class));
        running = false;
    }

    public static void cancelResultNotification(Context c) {
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_RESULT);
        } catch (Exception ignored) { }
    }

    // ---------- siklus layanan ----------

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopWorker();
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        final String full = intent.getStringExtra("full");
        final String token = intent.getStringExtra("token");
        final long idAwal = intent.getLongExtra("idAwal", 0);
        if (full == null || token == null) { stopSelf(); return START_NOT_STICKY; }

        stopWorker();
        running = true;
        Notification n = watchNotification(full, "Menunggu GitHub memulai pembangunan APK...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_WATCH, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_WATCH, n);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (lock == null) lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "githubbynovan:build");
            if (!lock.isHeld()) lock.acquire(190 * 60 * 1000L);
        } catch (Exception ignored) { }

        worker = new Thread(() -> watch(full, token, idAwal), "pantau-apk");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopWorker();
        running = false;
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void stopWorker() {
        Thread t = worker;
        worker = null;
        if (t != null) t.interrupt();
    }

    // ---------- pemantauan ----------

    private static JSONObject firstRun(String res) {
        JSONArray arr = Api.parse(res).optJSONArray("workflow_runs");
        return arr != null && arr.length() > 0 ? arr.optJSONObject(0) : null;
    }

    private void watch(String full, String token, long idAwal) {
        final String endpoint = Api.BASE + "/repos/" + full + "/actions/runs?per_page=1";
        final long start = System.currentTimeMillis();
        int fails = 0;
        String lastStatus = "";
        final Thread me = Thread.currentThread();
        try {
            while (worker == me) {
                long elapsed = (System.currentTimeMillis() - start) / 1000;
                if (elapsed > MAX_TOTAL) {
                    finish(KIND_TIMEOUT, full, token, idAwal, null,
                            "Pemantauan lebih dari 3 jam tanpa hasil.\nProyek: " + full);
                    return;
                }
                final boolean[] ok = {false};
                final String[] res = {""};
                final CountDownLatch latch = new CountDownLatch(1);
                Api.request("GET", endpoint, token, null, (o, r) -> {
                    ok[0] = o;
                    res[0] = r;
                    latch.countDown();
                });
                if (!latch.await(120, TimeUnit.SECONDS)) { ok[0] = false; res[0] = "Koneksi terlalu lama."; }
                if (worker != me) return;

                JSONObject run = null;
                if (ok[0]) {
                    fails = 0;
                    run = firstRun(res[0]);
                } else if (++fails >= 5) {
                    finish(KIND_FAILS, full, token, idAwal, null, "Proyek: " + full + "\n\n" + res[0]);
                    return;
                }
                elapsed = (System.currentTimeMillis() - start) / 1000;
                String text;
                if (run != null && run.optLong("id", 0) > idAwal) {
                    String status = run.optString("status", "");
                    if ("completed".equals(status)) {
                        finish(KIND_DONE, full, token, idAwal, run, "");
                        return;
                    }
                    String st = ApkTools.statusText(status, "");
                    text = "Status: " + st + "\nWaktu pemantauan: " + (elapsed / 60) + " menit "
                            + (elapsed % 60) + " detik\n\nHasil muncul otomatis saat selesai.";
                    if (!status.equals(lastStatus)) lastStatus = status;
                    updateOngoing(full, st + " (" + (elapsed / 60) + " mnt " + (elapsed % 60) + " dtk)");
                } else if (elapsed > MAX_MUNCUL) {
                    finish(KIND_NO_RUN, full, token, idAwal, null, "");
                    return;
                } else {
                    text = "Menunggu GitHub memulai pembangunan... (" + elapsed + " detik)";
                    updateOngoing(full, "Menunggu GitHub memulai pembangunan");
                }
                lastText = text;
                final String t = text;
                MAIN.post(() -> {
                    Listener l = listener;
                    if (l != null) l.onStatus(t);
                });
                Thread.sleep(JEDA);
            }
        } catch (InterruptedException ignored) {
            // dihentikan pengguna
        }
    }

    private void finish(int kind, String full, String token, long idAwal, JSONObject run, String detail) {
        Result r = new Result();
        r.kind = kind;
        r.full = full;
        r.token = token;
        r.idAwal = idAwal;
        r.run = run;
        r.detail = detail;
        setPending(r);
        running = false;
        postResultNotification(r);
        MAIN.post(() -> {
            Listener l = listener;
            if (l != null) l.onFinished();
        });
        stopForeground(true);
        stopSelf();
    }

    // ---------- notifikasi ----------

    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_WATCH, "Pemantauan pembangunan APK",
                NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_RESULT, "Hasil pembangunan APK",
                NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, 0, i, f);
    }

    private Notification.Builder builder(String channel) {
        ensureChannels();
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification watchNotification(String full, String text) {
        Intent stop = new Intent(this, BuildWatchService.class).setAction(ACTION_STOP);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, f);
        Notification.Builder b = builder(CH_WATCH)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Membangun APK: " + full)
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(openApp())
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti memantau", stopPi);
        return b.build();
    }

    private void updateOngoing(String full, String text) {
        try {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .notify(ID_WATCH, watchNotification(full, text));
        } catch (Exception ignored) { }
    }

    private void postResultNotification(Result r) {
        String title, text;
        if (r.kind == KIND_DONE) {
            String concl = Api.str(r.run, "conclusion");
            String st = ApkTools.statusText("completed", concl);
            title = "Pembangunan APK: " + st;
            text = r.full + ". Ketuk untuk melihat hasil.";
        } else if (r.kind == KIND_NO_RUN) {
            title = "Belum ada pembangunan baru";
            text = r.full + ". Ketuk untuk melihat pilihan.";
        } else if (r.kind == KIND_TIMEOUT) {
            title = "Pemantauan dihentikan";
            text = r.full + ". Lebih dari 3 jam tanpa hasil.";
        } else {
            title = "Gagal memantau pembangunan";
            text = r.full + ". Ketuk untuk melihat rincian.";
        }
        try {
            Notification n = builder(CH_RESULT)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setAutoCancel(true)
                    .setContentIntent(openApp())
                    .build();
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_RESULT, n);
        } catch (Exception ignored) { }
    }
}
