package com.novan.audiolabnovan

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.projection.MediaProjectionManager
import androidx.core.content.ContextCompat
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import java.io.File
import java.math.BigInteger
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread

/** Satu berkas masukan: alamat dan nama tampilannya. */
private data class Item(val uri: Uri, val name: String) {
    val base: String get() = name.substringBeforeLast('.', name)
}

// Tahap 34: nama folder otomatis di dalam folder Musik bawaan ponsel.
private const val AUTO_DIR = "AudioLab Novan"
private const val SRC_INTERNAL = -2   // tahap 33: sumber rekaman "suara internal ponsel"
private const val SRC_FX = -3         // tahap 47: mikrofon dengan efek langsung

class MainActivity : AppCompatActivity() {
    private val bitrates = listOf(64, 96, 128, 192, 256, 320)
    private val speeds = listOf(0.5, 0.75, 1.0, 1.25, 1.5, 2.0)
    private val gains = listOf(-12, -9, -6, -3, 0, 3, 6, 9, 12)
    private val pitches = (-6..6).toList()
    private val channelOpts = listOf(0, 1, 2)   // 0 = ikut sumber
    private val noiseOpts = listOf(0, 1, 2, 3)   // 0 = mati
    private val echoOpts = (0..8).toList()   // 0 = mati
    private val echoLevelOpts = listOf(100, 75, 50, 25) // persen
    private val loopOpts = (1..10).toList()      // 1 = tanpa ulang
    private val compOpts = listOf(0, 1, 2, 3)    // 0 = mati
    private val loudOpts = listOf(100, 150, 200, 250, 300, 400) // persen pengeras volume aman, 100 = mati
    private val splitOpts = listOf(0, 1, 2, 5, 10, 15, 30) // menit, 0 = tidak dibagi
    // Tahap 32: pilihan perekam. Nilai sumber mengikuti MediaRecorder.AudioSource.
    private val recSources = listOf(
        MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.CAMCORDER,
        MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.UNPROCESSED,
        MediaRecorder.AudioSource.VOICE_COMMUNICATION, SRC_INTERNAL, SRC_FX)
    private val recDirs = listOf(-1, 1, 2)    // -1 = otomatis, 1 = ke arah pengguna, 2 = menjauh dari pengguna
    private val recChannels = listOf(1, 2)
    private var micDevices: List<AudioDeviceInfo> = emptyList()
    private var micLabels: List<String> = emptyList()
    private val micCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) { refreshMics() }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) { refreshMics() }
    }
    private var coverUri: Uri? = null   // tahap 31: gambar sampul terpilih
    private var recRequested = false   // tahap 28/30: perekam suara (layanan latar depan RecordService)
    private var pendingRing = 0   // tahap 27: 0 = tidak, 1 = nada dering, 2 = notifikasi, 3 = alarm
    private var splitDir: File? = null
    private var splitBase = "hasil"
    private val midOpts = listOf(0, 1, 2, 3)     // tahap 41: 0 = mati
    private val duckOpts = listOf(0, 1, 2, 3)    // tahap 40: 0 = mati, 1 ringan, 2 sedang, 3 kuat
    private val mixBgOpts = listOf(100, 75, 50, 35, 25, 15, 10) // persen volume berkas kedua dst
    private val voiceOpts = listOf(0, 1, 2, 3, 4, 5)   // 0 = mati
    private val hpOpts = listOf(0, 80, 120, 200)   // 0 = mati, Hz
    private val rateOpts = listOf(0, 22050, 44100, 48000) // 0 = ikut sumber
    private var items: List<Item> = emptyList()
    private var tempOut: File? = null
    private var pendingFmt = OutFmt.MP3
    private var pendingKbps = 192
    private var pendingOpts = Opts()
    @Volatile private var session: FFmpegSession? = null
    @Volatile private var cancelled = false

    private lateinit var tvInput: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvProgress: TextView
    private var lastAnnounced = -1
    // Tahap 35: hasil konversi terakhir untuk dialog menu (putar, bagikan, hapus, ubah nama).
    private class Res(var uri: Uri, var name: String)
    // Tahap 55: dialog hasil bersama (putar, jeda, lanjutkan, bagikan, ubah nama, hapus).
    private val dialogHasil by lazy { DialogHasil(this) }
    private lateinit var spFormat: Spinner
    private lateinit var spBitrate: Spinner
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var spSpeed: Spinner
    private lateinit var cbNormalize: CheckBox
    private lateinit var spGain: Spinner
    private lateinit var spPitch: Spinner
    private lateinit var spBass: Spinner
    private lateinit var spTreble: Spinner
    private lateinit var spNoise: Spinner
    private lateinit var spHighpass: Spinner
    private lateinit var spEcho: Spinner
    private lateinit var spCompressor: Spinner
    private lateinit var spLoud: Spinner
    private lateinit var spSplit: Spinner
    private lateinit var eqSpinners: List<Spinner>
    private lateinit var spLoops: Spinner
    private lateinit var cbReverse: CheckBox
    private lateinit var spChannels: Spinner
    private lateinit var spRate: Spinner
    private lateinit var etFadeIn: EditText
    private lateinit var etFadeOut: EditText
    private lateinit var etTitle: EditText
    private lateinit var etArtist: EditText
    private lateinit var etAlbum: EditText
    private lateinit var cbMerge: CheckBox
    private lateinit var cbMix: CheckBox
    private lateinit var layoutMix: View
    private lateinit var spMixBg: Spinner
    private lateinit var spDuck: Spinner
    private lateinit var spMid: Spinner
    private lateinit var spVoice: Spinner
    private lateinit var spRing: Spinner
    private lateinit var btnRecord: Button
    private lateinit var btnPause: Button
    private var uiPaused = false
    private lateinit var spEchoLevel: Spinner
    private lateinit var cbEchoVoice: CheckBox
    private lateinit var cbVocalCut: CheckBox
    private lateinit var etCutFrom: EditText
    private lateinit var etCutTo: EditText
    private lateinit var etYear: EditText
    private lateinit var etGenre: EditText
    private lateinit var etTrack: EditText
    private lateinit var etComment: EditText
    private lateinit var btnCover: Button
    private lateinit var spRecSource: Spinner
    private lateinit var spMic: Spinner
    private lateinit var spMicDir: Spinner
    private lateinit var spRecCh: Spinner
    private lateinit var btnCoverClear: Button
    private lateinit var cbSilence: CheckBox
    private lateinit var cbEqualize: CheckBox
    private lateinit var cbMixFirst: CheckBox
    private lateinit var cbShare: CheckBox
    private lateinit var layoutOrder: View
    private lateinit var spOrder: Spinner
    private lateinit var btnUp: Button
    private lateinit var btnDown: Button
    private lateinit var btnSortName: Button
    private lateinit var btnPick: Button
    private lateinit var btnAdd: Button
    private lateinit var btnClear: Button
    private lateinit var btnResetSettings: Button
    private lateinit var cbLoopBg: CheckBox
    private lateinit var btnInfo: Button
    private lateinit var btnHistory: Button
    private lateinit var btnHistoryClear: Button
    private lateinit var btnPreview: Button
    private var player: MediaPlayer? = null
    private var previewFile: File? = null
    private lateinit var btnConvert: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar

    // Tahap 4: boleh memilih banyak berkas sekaligus.
    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onPicked(uris)
    }
    // Tahap 73: tambah berkas ke daftar yang sudah ada (tanpa menimpa).
    private val addFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onAdded(uris)
    }

    // Tahap 52: potong sambil mendengarkan; hasilnya diisikan ke kolom waktu.
    private val potongDengar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val mode = d.getStringExtra(com.novan.audiolabnovan.potong.PemotongActivity.HASIL_MODE)
            val dari = d.getStringExtra(com.novan.audiolabnovan.potong.PemotongActivity.HASIL_DARI).orEmpty()
            val sampai = d.getStringExtra(com.novan.audiolabnovan.potong.PemotongActivity.HASIL_SAMPAI).orEmpty()
            if (mode == com.novan.audiolabnovan.potong.PemotongActivity.MODE_BUANG) {
                etStart.setText(""); etEnd.setText("")
                etCutFrom.setText(dari); etCutTo.setText(sampai)
                setStatus("Bagian dari $dari sampai $sampai detik akan dibuang, sisanya disambung. Tekan Mulai konversi.")
            } else {
                etStart.setText(dari); etEnd.setText(sampai)
                etCutFrom.setText(""); etCutTo.setText("")
                setStatus("Bagian yang disimpan: dari $dari detik" + (if (sampai.isEmpty()) " sampai akhir berkas" else " sampai $sampai detik") + ". Tekan Mulai konversi.")
            }
        }
    }

    // Tahap 31: pilih gambar sampul.
    private val pickCover = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            coverUri = uri
            setStatus("Gambar sampul dipilih: ${displayName(uri)}. Dipasang pada hasil MP3, M4A, atau FLAC (tidak pada WAV).")
        }
    }

    // Tahap 33: izin rekam suara internal (dialog sistem "mulai merekam atau menyiarkan").
    private val askProjection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) startInternalRecording(r.resultCode, data)
        else setStatus("Izin merekam suara internal tidak diberikan, jadi rekaman dibatalkan.")
    }

    // Tahap 28/30: izin mikrofon (wajib) dan notifikasi (Android 13 ke atas, agar tombol Berhenti terlihat).
    private val askMic = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val mic = r[Manifest.permission.RECORD_AUDIO]
            ?: (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        if (mic) startRecording() else setStatus("Izin mikrofon ditolak, jadi rekam suara tidak bisa dipakai.")
    }

    // Satu berkas: pilih nama dan lokasi simpan seperti sebelumnya.
    private val saveFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val src = tempOut
        if (r.resultCode == Activity.RESULT_OK && uri != null && src != null) {
            thread {
                val err = try { Converter.copyTo(this, src, uri); null } catch (e: Exception) { e.message ?: "galat" }
                val ringMsg = if (err == null && pendingRing > 0) setAsTone(src, uri, pendingRing) else ""
                runOnUiThread {
                    setStatus(if (err == null) "Selesai. Berkas tersimpan.$ringMsg" else "Gagal menyimpan: $err")
                    if (err == null) addHistory("${displayName(uri)} (${pendingFmt.label})")
                    src.delete()
                    setBusy(false)
                    if (err == null && cbShare.isChecked) shareResult(uri)
                    if (err == null) finishWith(listOf(Res(uri, displayName(uri))))
                }
            }
        } else {
            src?.delete()
            setStatus("Penyimpanan dibatalkan.")
            setBusy(false)
        }
    }

    // Banyak berkas: pilih satu folder tujuan, semua hasil ditulis ke sana.
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) runBatch(tree) else {
            setStatus("Konversi massal dibatalkan: folder tujuan belum dipilih.")
            setBusy(false)
        }
    }

    // Tahap 22: folder tujuan untuk bagian-bagian hasil pembagian.
    private val pickSplitFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) saveParts(tree) else {
            cleanSplit()
            setStatus("Penyimpanan dibatalkan: folder tujuan belum dipilih.")
            setBusy(false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvInput = findViewById(R.id.tvInput)
        tvStatus = findViewById(R.id.tvStatus)
        tvProgress = findViewById(R.id.tvProgress)
        spFormat = findViewById(R.id.spFormat)
        spBitrate = findViewById(R.id.spBitrate)
        etStart = findViewById(R.id.etStart)
        etEnd = findViewById(R.id.etEnd)
        spSpeed = findViewById(R.id.spSpeed)
        cbNormalize = findViewById(R.id.cbNormalize)
        spGain = findViewById(R.id.spGain)
        spPitch = findViewById(R.id.spPitch)
        spBass = findViewById(R.id.spBass)
        spTreble = findViewById(R.id.spTreble)
        spNoise = findViewById(R.id.spNoise)
        spHighpass = findViewById(R.id.spHighpass)
        spEcho = findViewById(R.id.spEcho)
        spCompressor = findViewById(R.id.spCompressor)
        spLoud = findViewById(R.id.spLoud)
        spSplit = findViewById(R.id.spSplit)
        spLoops = findViewById(R.id.spLoops)
        cbReverse = findViewById(R.id.cbReverse)
        spChannels = findViewById(R.id.spChannels)
        spRate = findViewById(R.id.spRate)
        etFadeIn = findViewById(R.id.etFadeIn)
        etFadeOut = findViewById(R.id.etFadeOut)
        etTitle = findViewById(R.id.etTitle)
        etArtist = findViewById(R.id.etArtist)
        etAlbum = findViewById(R.id.etAlbum)
        cbMerge = findViewById(R.id.cbMerge)
        cbMix = findViewById(R.id.cbMix)
        layoutMix = findViewById(R.id.layoutMix)
        spMixBg = findViewById(R.id.spMixBg)
        spDuck = findViewById(R.id.spDuck)
        spMid = findViewById(R.id.spMid)
        spVoice = findViewById(R.id.spVoice)
        spRing = findViewById(R.id.spRing)
        btnRecord = findViewById(R.id.btnRecord)
        btnPause = findViewById(R.id.btnPause)
        spEchoLevel = findViewById(R.id.spEchoLevel)
        cbEchoVoice = findViewById(R.id.cbEchoVoice)
        cbVocalCut = findViewById(R.id.cbVocalCut)
        etCutFrom = findViewById(R.id.etCutFrom)
        etCutTo = findViewById(R.id.etCutTo)
        etYear = findViewById(R.id.etYear)
        etGenre = findViewById(R.id.etGenre)
        etTrack = findViewById(R.id.etTrack)
        etComment = findViewById(R.id.etComment)
        btnCover = findViewById(R.id.btnCover)
        spRecSource = findViewById(R.id.spRecSource)
        spMic = findViewById(R.id.spMic)
        spMicDir = findViewById(R.id.spMicDir)
        spRecCh = findViewById(R.id.spRecCh)
        btnCoverClear = findViewById(R.id.btnCoverClear)
        cbSilence = findViewById(R.id.cbSilence)
        cbEqualize = findViewById(R.id.cbEqualize)
        cbMixFirst = findViewById(R.id.cbMixFirst)
        cbShare = findViewById(R.id.cbShare)
        layoutOrder = findViewById(R.id.layoutOrder)
        spOrder = findViewById(R.id.spOrder)
        btnUp = findViewById(R.id.btnUp)
        btnDown = findViewById(R.id.btnDown)
        btnSortName = findViewById(R.id.btnSortName)
        btnPick = findViewById(R.id.btnPick)
        btnAdd = findViewById(R.id.btnAdd)
        btnClear = findViewById(R.id.btnClear)
        btnResetSettings = findViewById(R.id.btnResetSettings)
        cbLoopBg = findViewById(R.id.cbLoopBg)
        btnInfo = findViewById(R.id.btnInfo)
        btnHistory = findViewById(R.id.btnHistory)
        btnHistoryClear = findViewById(R.id.btnHistoryClear)
        btnPreview = findViewById(R.id.btnPreview)
        btnConvert = findViewById(R.id.btnConvert)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)

        spFormat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, OutFmt.values().map { it.label })
        spBitrate.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bitrates.map { "$it kbps" })
        spBitrate.setSelection(bitrates.indexOf(192))
        spSpeed.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, speeds.map { "${it}x" })
        spSpeed.setSelection(speeds.indexOf(1.0))

        spGain.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            gains.map { if (it == 0) "0 dB (tanpa perubahan)" else if (it > 0) "+$it dB (lebih keras)" else "$it dB (lebih pelan)" })
        spGain.setSelection(gains.indexOf(0))

        spPitch.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            pitches.map { if (it == 0) "0 (tanpa perubahan)" else if (it > 0) "+$it (lebih tinggi)" else "$it (lebih rendah)" })
        spPitch.setSelection(pitches.indexOf(0))

        val eqLabels = gains.map { if (it == 0) "0 dB (tanpa perubahan)" else if (it > 0) "+$it dB (dinaikkan)" else "$it dB (diturunkan)" }
        spBass.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eqLabels)
        spBass.setSelection(gains.indexOf(0))
        spTreble.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eqLabels)
        spTreble.setSelection(gains.indexOf(0))

        eqSpinners = listOf(R.id.spEq1, R.id.spEq2, R.id.spEq3, R.id.spEq4, R.id.spEq5).map { findViewById<Spinner>(it) }
        eqSpinners.forEach {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eqLabels)
            it.setSelection(gains.indexOf(0))
        }
        spNoise.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            noiseOpts.map { when (it) { 1 -> "Ringan"; 2 -> "Sedang"; 3 -> "Kuat (bisa membuat suara agak teredam)"; else -> "Mati" } })
        spHighpass.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            hpOpts.map { if (it == 0) "Mati" else "Buang di bawah $it Hz" })
        spEcho.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            echoOpts.map { when (it) { 1 -> "Ruang kecil"; 2 -> "Aula (gema panjang berlapis)"; 3 -> "Gema tunggal"; 4 -> "Studio vokal (ruang rapat, halus)"; 5 -> "Karaoke (gema hangat)"; 6 -> "Katedral (sangat panjang)"; 7 -> "Kamar mandi (rapat dan nyaring)"; 8 -> "Panggung konser"; else -> "Mati" } })
        spLoud.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            loudOpts.map { if (it == 100) "Mati" else "$it persen" })
        spCompressor.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            compOpts.map { when (it) { 1 -> "Ringan (volume lebih rata)"; 2 -> "Sedang (cocok untuk ucapan)"; 3 -> "Kuat (sangat rata, dinamika berkurang)"; else -> "Mati" } })
        spSplit.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            splitOpts.map { if (it == 0) "Tidak dibagi" else "Bagi tiap $it menit" })
        spRecSource.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf(
            "Mikrofon standar (disarankan)",
            "Mikrofon kamera (searah, cocok untuk merekam sumber di depan)",
            "Pengenalan suara (bersih, sedikit pemrosesan)",
            "Mentah tanpa pemrosesan (kualitas alami, jika didukung)",
            "Panggilan suara (peredam gema dan derau bawaan)",
            "Suara internal ponsel (suara dari aplikasi lain; Android 10 ke atas; tidak memakai pilihan mikrofon, arah, dan kanal)",
            "Mikrofon dengan efek langsung (gema, pengolah vokal, bass, penjernih; hasil WAV; atur di tombol di bawah)"))
        spMicDir.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Otomatis", "Ke arah pengguna (mikrofon depan)", "Menjauh dari pengguna (mikrofon belakang)"))
        spRecCh.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Mono (disarankan)", "Stereo (bila didukung perangkat)"))
        refreshMics()
        spEchoLevel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            echoLevelOpts.map { if (it == 100) "100% (penuh)" else "$it%" })
        spRing.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Tidak (hanya simpan)", "Nada dering telepon", "Nada notifikasi", "Nada alarm"))
        spVoice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            voiceOpts.map { when (it) { 1 -> "Tupai (suara tinggi)"; 2 -> "Raksasa (suara berat)"; 3 -> "Robot"; 4 -> "Radio telepon"; 5 -> "Bergetar"; else -> "Mati" } })
        spMixBg.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            mixBgOpts.map { if (it == 100) "100% (sama keras)" else "$it%" })
        spMixBg.setSelection(mixBgOpts.indexOf(35))
        spMid.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            midOpts.map { when (it) { 1 -> "Jeda lebih dari 1 detik dipendekkan jadi 1 detik"; 2 -> "Jeda lebih dari 0,6 detik dipendekkan jadi 0,6 detik"; 3 -> "Jeda lebih dari 0,3 detik dipendekkan jadi 0,3 detik"; else -> "Mati" } })
        spDuck.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            duckOpts.map { when (it) { 1 -> "Ringan (musik turun sedikit)"; 2 -> "Sedang (musik turun jelas)"; 3 -> "Kuat (musik hampir hilang saat bicara)"; else -> "Mati" } })
        spLoops.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            loopOpts.map { if (it == 1) "1 kali (tanpa ulang)" else "$it kali (hasil diulang)" })

        spChannels.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            channelOpts.map { when (it) { 1 -> "Mono"; 2 -> "Stereo"; else -> "Ikut berkas sumber" } })
        spRate.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            rateOpts.map { when (it) { 22050 -> "22,05 kHz"; 44100 -> "44,1 kHz"; 48000 -> "48 kHz"; else -> "Ikut berkas sumber" } })

        loadPrefs()
        setupSections()

        // Pulihkan daftar berkas setelah layar diputar (sebelumnya daftar hilang).
        if (savedInstanceState != null) {
            val uris = savedInstanceState.getStringArrayList("uris")?.map { Uri.parse(it) }.orEmpty()
            val names = savedInstanceState.getStringArrayList("names").orEmpty()
            if (uris.isNotEmpty() && uris.size == names.size) {
                items = uris.indices.map { Item(uris[it], names[it]) }
                showItems()
                btnConvert.isEnabled = true
            }
        }

        btnPick.setOnClickListener { pickFiles.launch(arrayOf("audio/*", "video/*")) }
        btnAdd.setOnClickListener { addFiles.launch(arrayOf("audio/*", "video/*")) }
        btnClear.setOnClickListener { clearItems() }
        btnResetSettings.setOnClickListener { confirmResetSettings() }
        cbMixFirst.setOnCheckedChangeListener { _, on -> cbLoopBg.isEnabled = on && btnPick.isEnabled }
        btnRecord.setOnClickListener { toggleRecord() }
        // Tahap 46: Studio Karaoke. Mikrofon tidak bisa dipakai dua tempat sekaligus, jadi ditolak saat perekam jalan.
        findViewById<Button>(R.id.btnFxSettings).setOnClickListener {
            startActivity(Intent(this, com.novan.audiolabnovan.karaoke.EfekRekamActivity::class.java))
        }
        findViewById<Button>(R.id.btnKaraoke).setOnClickListener {
            if (RecState.recording) {
                setStatus("Perekam suara sedang berjalan. Hentikan dulu sebelum membuka Studio Karaoke.")
            } else {
                stopPreview()
                startActivity(Intent(this, com.novan.audiolabnovan.karaoke.KaraokeActivity::class.java))
            }
        }
        // Tahap 51: Teks ke Suara memakai mesin Text-to-Speech bawaan HP.
        findViewById<Button>(R.id.btnTts).setOnClickListener {
            stopPreview()
            startActivity(Intent(this, com.novan.audiolabnovan.tts.TeksKeSuaraActivity::class.java))
        }
        // Tahap 59: Voice note Gemini (suara Gemini dengan efek).
        findViewById<Button>(R.id.btnGemini).setOnClickListener {
            stopPreview()
            startActivity(Intent(this, com.novan.audiolabnovan.gemini.GeminiSuaraActivity::class.java))
        }
        findViewById<Button>(R.id.btnPotongDengar).setOnClickListener {
            val it0 = items.firstOrNull()
            if (it0 == null) {
                setStatus("Pilih berkas audio dulu, lalu buka Potong sambil mendengarkan.")
            } else {
                stopPreview()
                potongDengar.launch(Intent(this, com.novan.audiolabnovan.potong.PemotongActivity::class.java)
                    .putExtra(com.novan.audiolabnovan.potong.PemotongActivity.EXTRA_URI, it0.uri.toString())
                    .putExtra(com.novan.audiolabnovan.potong.PemotongActivity.EXTRA_NAMA, it0.name))
            }
        }
        // Tahap 53: Pengubah Suara. Memakai berkas yang sedang dipilih bila ada.
        findViewById<Button>(R.id.btnUbahSuara).setOnClickListener {
            stopPreview()
            val i = Intent(this, com.novan.audiolabnovan.ubah.PengubahSuaraActivity::class.java)
            items.firstOrNull()?.let {
                i.putExtra(com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_URI, it.uri.toString())
                i.putExtra(com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_NAMA, it.name)
            }
            startActivity(i)
        }
        // Tahap 67: Audio ke Video. Memakai berkas yang sedang dipilih bila ada.
        findViewById<Button>(R.id.btnAudioVideo).setOnClickListener {
            stopPreview()
            val i = Intent(this, com.novan.audiolabnovan.video.AudioKeVideoActivity::class.java)
            items.firstOrNull()?.let {
                i.putExtra(com.novan.audiolabnovan.video.AudioKeVideoActivity.EXTRA_URI, it.uri.toString())
                i.putExtra(com.novan.audiolabnovan.video.AudioKeVideoActivity.EXTRA_NAMA, it.name)
            }
            startActivity(i)
        }
        btnPause.setOnClickListener { togglePause() }
        btnCover.setOnClickListener { pickCover.launch(arrayOf("image/jpeg", "image/png")) }
        btnCoverClear.setOnClickListener {
            setStatus(if (coverUri != null) "Gambar sampul dihapus dari pilihan." else "Belum ada gambar sampul dipilih.")
            coverUri = null
        }
        btnConvert.setOnClickListener { startConvert() }
        btnInfo.setOnClickListener { showInfo() }
        btnHistory.setOnClickListener { showHistory() }
        btnHistoryClear.setOnClickListener { confirmClearHistory() }
        btnPreview.setOnClickListener { togglePreview() }
        cbMerge.setOnCheckedChangeListener { _, on -> if (on) cbMix.isChecked = false; updateOrderVisibility() }
        cbMix.setOnCheckedChangeListener { _, on -> if (on) cbMerge.isChecked = false; updateOrderVisibility() }
        btnUp.setOnClickListener { moveSelected(-1) }
        btnDown.setOnClickListener { moveSelected(1) }
        btnSortName.setOnClickListener { sortByName() }
        btnCancel.setOnClickListener {
            cancelled = true
            session?.let { FFmpegKit.cancel(it.sessionId) }
        }

        // Hanya saat pertama dibuat; setelah layar diputar, berkas pilihan jangan diganti lagi.
        if (savedInstanceState == null) handleIncoming(intent)
    }

    // ---------- Tahap 40: submenu ringkas (buka satu, yang lain menutup) ----------

    private val sections = listOf(
        Triple(R.id.btnSecFiles, R.id.secFiles, "Berkas, gabung, dan campur"),
        Triple(R.id.btnSecFmt, R.id.secFmt, "Format dan kualitas hasil"),
        Triple(R.id.btnSecCut, R.id.secCut, "Potong dan kecepatan"),
        Triple(R.id.btnSecVol, R.id.secVol, "Volume dan ekualiser"),
        Triple(R.id.btnSecClean, R.id.secClean, "Pembersih suara"),
        Triple(R.id.btnSecFx, R.id.secFx, "Efek suara, gema, dan karaoke"),
        Triple(R.id.btnSecFade, R.id.secFade, "Fade dan bagi hasil"),
        Triple(R.id.btnSecTag, R.id.secTag, "Tag lagu dan sampul"),
        Triple(R.id.btnSecSave, R.id.secSave, "Setelan sesudah tersimpan"),
        Triple(R.id.btnSecRec, R.id.secRec, "Pengaturan perekam suara"),
        Triple(R.id.btnSecHist, R.id.secHist, "Riwayat konversi")
    )

    private fun setupSections() {
        for ((b, _, _) in sections) {
            findViewById<Button>(b).setOnClickListener { toggleSection(b) }
        }
        applySections(-1)
    }

    private fun toggleSection(openBtn: Int) {
        val body = sections.first { it.first == openBtn }.second
        val wasOpen = findViewById<View>(body).visibility == View.VISIBLE
        applySections(if (wasOpen) -1 else openBtn)
        val title = sections.first { it.first == openBtn }.third
        val btn = findViewById<Button>(openBtn)
        btn.announceForAccessibility(if (wasOpen) "$title ditutup" else "$title dibuka")
        if (!wasOpen) {
            btn.post { (btn.parent.parent as? android.widget.ScrollView)?.smoothScrollTo(0, btn.top) }
        }
    }

    private fun applySections(openBtn: Int) {
        for ((b, s, title) in sections) {
            val open = b == openBtn
            findViewById<View>(s).visibility = if (open) View.VISIBLE else View.GONE
            val btn = findViewById<Button>(b)
            btn.text = (if (open) "\u25BE " else "\u25B8 ") + title
            btn.contentDescription = title + if (open) ", terbuka. Ketuk untuk menutup." else ", tertutup. Ketuk untuk membuka."
        }
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("pengaturan", MODE_PRIVATE)
        spFormat.setSelection(p.getInt("format", 0).coerceIn(0, OutFmt.values().size - 1))
        spBitrate.setSelection(p.getInt("bitrate", bitrates.indexOf(192)).coerceIn(0, bitrates.size - 1))
        spSpeed.setSelection(p.getInt("speed", speeds.indexOf(1.0)).coerceIn(0, speeds.size - 1))
        spGain.setSelection(p.getInt("gain", gains.indexOf(0)).coerceIn(0, gains.size - 1))
        spPitch.setSelection(p.getInt("pitch", pitches.indexOf(0)).coerceIn(0, pitches.size - 1))
        spBass.setSelection(p.getInt("bass", gains.indexOf(0)).coerceIn(0, gains.size - 1))
        spTreble.setSelection(p.getInt("treble", gains.indexOf(0)).coerceIn(0, gains.size - 1))
        spNoise.setSelection(p.getInt("noise", 0).coerceIn(0, noiseOpts.size - 1))
        spHighpass.setSelection(p.getInt("highpass", 0).coerceIn(0, hpOpts.size - 1))
        spEcho.setSelection(p.getInt("echo", 0).coerceIn(0, echoOpts.size - 1))
        spCompressor.setSelection(p.getInt("compressor", 0).coerceIn(0, compOpts.size - 1))
        spLoud.setSelection(p.getInt("loud", 0).coerceIn(0, loudOpts.size - 1))
        spSplit.setSelection(p.getInt("split", 0).coerceIn(0, splitOpts.size - 1))
        eqSpinners.forEachIndexed { i, sp -> sp.setSelection(p.getInt("eq$i", gains.indexOf(0)).coerceIn(0, gains.size - 1)) }
        spRecSource.setSelection(p.getInt("recsource", 0).coerceIn(0, recSources.size - 1))
        spMicDir.setSelection(p.getInt("micdir", 0).coerceIn(0, recDirs.size - 1))
        spRecCh.setSelection(p.getInt("recch", 0).coerceIn(0, recChannels.size - 1))
        spEchoLevel.setSelection(p.getInt("echolevel", 0).coerceIn(0, echoLevelOpts.size - 1))
        cbEchoVoice.isChecked = p.getBoolean("echovoice", false)
        cbVocalCut.isChecked = p.getBoolean("vocalcut", false)
        spVoice.setSelection(p.getInt("voice", 0).coerceIn(0, voiceOpts.size - 1))
        spMixBg.setSelection(p.getInt("mixbg", mixBgOpts.indexOf(35)).coerceIn(0, mixBgOpts.size - 1))
        spDuck.setSelection(p.getInt("duck", 0).coerceIn(0, duckOpts.size - 1))
        spMid.setSelection(p.getInt("midsil", 0).coerceIn(0, midOpts.size - 1))
        spLoops.setSelection(p.getInt("loops", 0).coerceIn(0, loopOpts.size - 1))
        cbReverse.isChecked = p.getBoolean("reverse", false)
        spChannels.setSelection(p.getInt("channels", 0).coerceIn(0, channelOpts.size - 1))
        spRate.setSelection(p.getInt("rate", 0).coerceIn(0, rateOpts.size - 1))
        cbNormalize.isChecked = p.getBoolean("normalize", false)
        cbSilence.isChecked = p.getBoolean("silence", false)
        cbEqualize.isChecked = p.getBoolean("equalize", false)
        cbMixFirst.isChecked = p.getBoolean("mixfirst", true)
        cbLoopBg.isChecked = p.getBoolean("loopbg", true)
        cbShare.isChecked = p.getBoolean("share", false)
        etFadeIn.setText(p.getString("fadeIn", ""))
        etFadeOut.setText(p.getString("fadeOut", ""))
        etArtist.setText(p.getString("artist", ""))
        etAlbum.setText(p.getString("album", ""))
    }

    private fun savePrefs() {
        getSharedPreferences("pengaturan", MODE_PRIVATE).edit()
            .putInt("format", spFormat.selectedItemPosition)
            .putInt("bitrate", spBitrate.selectedItemPosition)
            .putInt("speed", spSpeed.selectedItemPosition)
            .putInt("gain", spGain.selectedItemPosition)
            .putInt("pitch", spPitch.selectedItemPosition)
            .putInt("bass", spBass.selectedItemPosition)
            .putInt("treble", spTreble.selectedItemPosition)
            .putInt("noise", spNoise.selectedItemPosition)
            .putInt("highpass", spHighpass.selectedItemPosition)
            .putInt("echo", spEcho.selectedItemPosition)
            .putInt("compressor", spCompressor.selectedItemPosition)
            .putInt("loud", spLoud.selectedItemPosition)
            .putInt("split", spSplit.selectedItemPosition)
            .putInt("voice", spVoice.selectedItemPosition)
            .putInt("recsource", spRecSource.selectedItemPosition)
            .putInt("micdir", spMicDir.selectedItemPosition)
            .putInt("recch", spRecCh.selectedItemPosition)
            .putInt("echolevel", spEchoLevel.selectedItemPosition)
            .putBoolean("echovoice", cbEchoVoice.isChecked)
            .putBoolean("vocalcut", cbVocalCut.isChecked)
            .putInt("mixbg", spMixBg.selectedItemPosition)
            .putInt("duck", spDuck.selectedItemPosition)
            .putInt("midsil", spMid.selectedItemPosition)
            .putInt("loops", spLoops.selectedItemPosition)
            .putBoolean("reverse", cbReverse.isChecked)
            .putInt("channels", spChannels.selectedItemPosition)
            .putInt("rate", spRate.selectedItemPosition)
            .putBoolean("normalize", cbNormalize.isChecked)
            .putBoolean("silence", cbSilence.isChecked)
            .putBoolean("equalize", cbEqualize.isChecked)
            .putBoolean("mixfirst", cbMixFirst.isChecked)
            .putBoolean("loopbg", cbLoopBg.isChecked)
            .putBoolean("share", cbShare.isChecked)
            .putString("fadeIn", etFadeIn.text.toString())
            .putString("fadeOut", etFadeOut.text.toString())
            .putString("artist", etArtist.text.toString())
            .putString("album", etAlbum.text.toString())
            .apply()
    }

    override fun onPause() {
        super.onPause()
        savePrefs()
        getSharedPreferences("pengaturan", MODE_PRIVATE).edit().apply {
            eqSpinners.forEachIndexed { i, sp -> putInt("eq$i", sp.selectedItemPosition) }
        }.apply()
        stopPreview()
    }

    override fun onStart() {
        super.onStart()
        RecState.listener = { handleRecordEvent() }
        (getSystemService(AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(micCallback, null)
        refreshMics()
    }

    override fun onStop() {
        RecState.listener = null
        (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(micCallback)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        applyRecordUi()
        handleRecordEvent()
    }

    override fun onDestroy() {
        stopPreview()
        dialogHasil.lepas()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList("uris", ArrayList(items.map { it.uri.toString() }))
        outState.putStringArrayList("names", ArrayList(items.map { it.name }))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    /** Terima berkas dari menu Bagikan (SEND, SEND_MULTIPLE) atau Buka dengan (VIEW). Diabaikan saat sedang memproses. */
    private fun handleIncoming(i: Intent?) {
        if (i == null || !btnPick.isEnabled) return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND ->
                listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList<Uri>()
            Intent.ACTION_VIEW -> listOfNotNull(i.data)
            else -> emptyList()
        }
        // Tahap 73: berkas dari Bagikan ditambahkan ke daftar yang sudah ada, supaya suara dan backsound
        // bisa dibagikan satu per satu dari pengelola berkas. Untuk mulai baru, pakai "Kosongkan daftar berkas".
        if (uris.isNotEmpty()) { if (items.isEmpty()) onPicked(uris) else onAdded(uris) }
    }

    private fun displayName(uri: Uri): String {
        var name = "berkas"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: name
                }
            }
        } catch (_: Exception) {
        }
        return name
    }

    private fun onPicked(uris: List<Uri>) {
        items = uris.map { Item(it, displayName(it)) }
        showItems()
        btnConvert.isEnabled = true
        setStatus(if (items.size == 1) "Siap dikonversi." else "Siap dikonversi. Hasil semua berkas disimpan ke satu folder.")
    }

    /** Tahap 73: tambahkan berkas ke akhir daftar; berkas yang sudah ada dilewati. */
    private fun onAdded(uris: List<Uri>) {
        if (items.isEmpty()) { onPicked(uris); return }
        val have = items.map { it.uri.toString() }.toSet()
        val fresh = uris.filter { it.toString() !in have }.distinct().map { Item(it, displayName(it)) }
        if (fresh.isEmpty()) { setStatus("Berkas itu sudah ada di daftar."); return }
        items = items + fresh
        showItems()
        refreshOrder(items.size - 1)
        btnConvert.isEnabled = true
        setStatus("Ditambahkan: ${fresh.joinToString(", ") { it.name }}. Sekarang ada ${items.size} berkas. " +
            "Urutan: " + items.withIndex().joinToString("; ") { "${it.index + 1}. ${it.value.name}" } +
            ". Berkas pertama jadi suara utama, sisanya musik latar bila Campur dicentang.")
    }

    private fun confirmResetSettings() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Kembalikan pengaturan")
            .setMessage("Semua pengaturan (efek, kualitas, volume, dan lainnya) dikembalikan ke bawaan. Riwayat dan berkas tidak terhapus.")
            .setPositiveButton("Kembalikan") { _, _ ->
                val p = getSharedPreferences("pengaturan", MODE_PRIVATE)
                p.edit().apply { p.all.keys.filter { it != "riwayat" }.forEach { remove(it) } }.apply()
                loadPrefs()
                setStatus("Semua pengaturan dikembalikan ke bawaan. Efek gema, pengubah suara, dan efek lain sekarang mati.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun clearItems() {
        items = emptyList()
        showItems()
        btnConvert.isEnabled = false
        setStatus("Daftar berkas dikosongkan.")
    }

    private fun showItems() {
        tvInput.text = if (items.size == 1) {
            "Berkas: ${items[0].name}"
        } else {
            "${items.size} berkas dipilih: " + items.take(3).joinToString(", ") { it.name } +
                if (items.size > 3) ", dan ${items.size - 3} lainnya" else ""
        }
        stopPreview()
        btnInfo.isEnabled = items.isNotEmpty()
        btnClear.isEnabled = items.isNotEmpty() && btnPick.isEnabled
        btnPreview.isEnabled = items.isNotEmpty()
        cbMerge.isEnabled = items.size > 1
        cbMix.isEnabled = items.size > 1
        if (items.size <= 1) { cbMerge.isChecked = false; cbMix.isChecked = false }
        refreshOrder(0)
        updateOrderVisibility()
    }

    /** Daftar urutan hanya tampil bila gabung dicentang dan ada lebih dari satu berkas. */
    private fun updateOrderVisibility() {
        layoutOrder.visibility = if ((cbMerge.isChecked || cbMix.isChecked) && items.size > 1) View.VISIBLE else View.GONE
        layoutMix.visibility = if (cbMix.isChecked && items.size > 1) View.VISIBLE else View.GONE
    }

    private fun refreshOrder(selected: Int) {
        spOrder.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            items.mapIndexed { i, item -> "${i + 1}. ${item.name}" })
        if (items.isNotEmpty()) spOrder.setSelection(selected.coerceIn(0, items.size - 1))
    }

    /** Geser berkas terpilih satu posisi (delta -1 = naik, +1 = turun) dan umumkan posisi barunya. */
    private fun moveSelected(delta: Int) {
        val pos = spOrder.selectedItemPosition
        if (pos < 0 || pos >= items.size) return
        val to = pos + delta
        if (to < 0) { setStatus("${items[pos].name} sudah di urutan pertama."); return }
        if (to >= items.size) { setStatus("${items[pos].name} sudah di urutan terakhir."); return }
        val m = items.toMutableList()
        val moved = m.removeAt(pos)
        m.add(to, moved)
        items = m
        refreshOrder(to)
        setStatus("${moved.name} dipindah ke urutan ${to + 1} dari ${items.size}.")
    }

    private fun sortByName() {
        items = items.sortedWith { a, b -> naturalCompare(a.name, b.name) }
        refreshOrder(0)
        setStatus("Diurutkan menurut nama. Urutan: " +
            items.withIndex().joinToString("; ") { "${it.index + 1}. ${it.value.name}" })
    }

    /** Urut alami: "lagu2" sebelum "lagu10". */
    private fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ta = re.findAll(a.lowercase()).map { it.value }.toList()
        val tb = re.findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ta.size, tb.size)) {
            val x = ta[i]
            val y = tb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) BigInteger(x).compareTo(BigInteger(y)) else x.compareTo(y)
            if (c != 0) return c
        }
        return ta.size - tb.size
    }

    private fun startConvert() {
        if (items.isEmpty()) return
        stopPreview()
        val fmt = OutFmt.values()[spFormat.selectedItemPosition]
        val kbps = bitrates[spBitrate.selectedItemPosition]
        var o = readOpts() ?: return
        // Tahap 29: mode karaoke hanya berarti saat campur; pengurang vokal pindah ke berkas kedua dst.
        val mixing = cbMix.isChecked && items.size > 1
        if (mixing) o = o.copy(echoVoiceOnly = cbEchoVoice.isChecked, vocalCut = if (o.vocalCut == 1) 2 else 0)
        val singleSave = items.size == 1 || cbMerge.isChecked || cbMix.isChecked
        pendingRing = if (singleSave && o.splitMin == 0) spRing.selectedItemPosition else 0
        if (pendingRing > 0) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                setStatus("Menyetel nada dering butuh Android 10 ke atas. Ubah pilihan menjadi Tidak.")
                return
            }
            if (!Settings.System.canWrite(this)) {
                setStatus("Izin mengubah setelan sistem belum diberikan. Layar izin dibuka: nyalakan untuk AudioLab novan, kembali, lalu tekan Mulai konversi lagi.")
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    setStatus("Layar izin tidak bisa dibuka. Buka Setelan, Aplikasi, AudioLab novan, Ubah setelan sistem.")
                }
                return
            }
        }
        pendingFmt = fmt
        pendingKbps = kbps
        pendingOpts = o
        cancelled = false
        updateProgress(0)
        setBusy(true)
        if (items.size == 1) {
            runSingle(items[0])
        } else if (cbMix.isChecked) {
            runMerge(mix = true)
        } else if (cbMerge.isChecked) {
            runMerge()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            setStatus("Memproses ${items.size} berkas...")
            runBatch(null)
        } else {
            setStatus("Pilih folder tujuan untuk ${items.size} berkas.")
            pickFolder.launch(null)
        }
    }

    private fun runSingle(item: Item) {
        val out = File(cacheDir, "out_${System.currentTimeMillis()}.${pendingFmt.ext}")
        tempOut = out
        setStatus("Memproses...")
        thread {
            val dur = Converter.probeDurationMs(this, item.uri)
            session = Converter.convert(this, item.uri, out, pendingFmt, pendingKbps, dur, pendingOpts,
                onProgress = { p -> runOnUiThread { updateProgress(p) } },
                onDone = { err -> runOnUiThread { onConverted(err, item.base) } })
        }
    }

    private fun onConverted(err: String?, base: String) {
        if (err != null) {
            tempOut?.delete()
            setStatus(err)
            setBusy(false)
            return
        }
        updateProgress(100)
        if (pendingOpts.splitMin > 0) {
            startSplit(base)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveSingleAuto(base)
            return
        }
        setStatus("Konversi selesai. Pilih lokasi simpan.")
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = pendingFmt.mime
            putExtra(Intent.EXTRA_TITLE, "$base.${pendingFmt.ext}")
        }
        saveFile.launch(i)
    }

    /** Tahap 34: simpan satu hasil otomatis ke Musik/AudioLab Novan (Android 10 ke atas), tanpa memilih folder. */
    private fun saveSingleAuto(base: String) {
        val src = tempOut
        if (src == null) { setBusy(false); return }
        val fmt = pendingFmt
        setStatus("Menyimpan ke folder Musik, AudioLab Novan...")
        thread {
            val r = runCatching { saveAuto(src, "$base.${fmt.ext}", fmt) }
            val uri = r.getOrNull()
            val err = r.exceptionOrNull()?.let { it.message ?: "galat" }
            val ringMsg = if (uri != null && pendingRing > 0) setAsTone(src, uri, pendingRing) else ""
            val savedName = if (uri != null) displayName(uri) else ""
            runOnUiThread {
                setStatus(if (uri != null) "Selesai. Berkas tersimpan di folder Musik, AudioLab Novan, dengan nama $savedName.$ringMsg"
                    else "Gagal menyimpan: $err")
                if (uri != null) addHistory("$savedName (${fmt.label})")
                src.delete()
                setBusy(false)
                if (uri != null && cbShare.isChecked) shareResult(uri)
                if (uri != null) finishWith(listOf(Res(uri, savedName)))
            }
        }
    }

    /**
     * Tahap 34: tulis berkas ke Musik/AudioLab Novan lewat MediaStore (Android 10 ke atas, tanpa izin tambahan).
     * Nama kembar otomatis diberi angka oleh sistem. [sub] = subfolder opsional di dalam AudioLab Novan.
     */
    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun saveAuto(src: File, name: String, fmt: OutFmt, sub: String = ""): Uri {
        val bad = Regex("[\\\\/:*?\"<>|]")
        val rel = "Music/$AUTO_DIR" + if (sub.isNotEmpty()) "/" + sub.replace(bad, "_") else ""
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name.replace(bad, "_"))
            put(MediaStore.Audio.Media.MIME_TYPE, fmt.mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, rel)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val coll = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = contentResolver.insert(coll, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            contentResolver.update(u, done, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    /** Tahap 22: bagi hasil (berkas sementara) per N menit, lalu minta folder tujuan. */
    private fun startSplit(base: String) {
        val src = tempOut
        if (src == null) { setBusy(false); return }
        val dir = File(cacheDir, "split_${System.currentTimeMillis()}")
        dir.mkdirs()
        splitDir = dir
        splitBase = base
        setStatus("Membagi hasil tiap ${pendingOpts.splitMin} menit...")
        session = Converter.split(src, dir, pendingFmt.ext, pendingOpts.splitMin) { err ->
            runOnUiThread { onSplit(err) }
        }
    }

    private fun onSplit(err: String?) {
        tempOut?.delete()
        val n = splitDir?.listFiles()?.size ?: 0
        if (err != null || n == 0) {
            cleanSplit()
            setStatus(err ?: "Pembagian gagal: tidak ada bagian yang dihasilkan.")
            setBusy(false)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            setStatus("Hasil dibagi jadi $n bagian. Menyimpan...")
            saveParts(null)
            return
        }
        setStatus("Hasil dibagi jadi $n bagian. Pilih folder tujuan.")
        pickSplitFolder.launch(null)
    }

    private fun saveParts(tree: Uri?) {
        val parts = splitDir?.listFiles()?.sortedBy { it.name }.orEmpty()
        val base = splitBase
        val fmt = pendingFmt
        val parent = tree?.let { DocumentsContract.buildDocumentUriUsingTree(it, DocumentsContract.getTreeDocumentId(it)) }
        setStatus("Menyimpan ${parts.size} bagian...")
        thread {
            var ok = 0
            var lastErr: String? = null
            val saved = ArrayList<Res>()
            for ((i, f) in parts.withIndex()) {
                try {
                    val name = String.format(java.util.Locale.US, "%s_bagian%02d.%s", base, i + 1, fmt.ext)
                    val u = if (parent == null) {
                        saveAuto(f, name, fmt, base)
                    } else {
                        val doc = DocumentsContract.createDocument(contentResolver, parent, fmt.mime, name)
                            ?: throw java.io.IOException("folder tujuan menolak berkas baru")
                        Converter.copyTo(this, f, doc)
                        doc
                    }
                    saved += Res(u, displayName(u))
                    ok++
                } catch (e: Exception) {
                    lastErr = e.message ?: "galat"
                }
                runOnUiThread { updateProgress((i + 1) * 100 / parts.size) }
            }
            runOnUiThread {
                cleanSplit()
                setStatus(if (ok == parts.size) "Selesai. $ok bagian tersimpan" +
                    (if (parent == null) " di folder Musik, AudioLab Novan, subfolder $base." else ".")
                    else "$ok dari ${parts.size} bagian tersimpan. Galat terakhir: $lastErr")
                if (ok > 0) addHistory("$base dibagi $ok bagian (${fmt.label})")
                setBusy(false)
                finishWith(saved)
            }
        }
    }

    private fun cleanSplit() {
        splitDir?.deleteRecursively()
        splitDir = null
    }

    /** Tahap 5: gabung semua berkas terpilih (urut sesuai daftar) menjadi satu berkas. */
    private fun runMerge(mix: Boolean = false) {
        val list = items
        val out = File(cacheDir, "merge_${System.currentTimeMillis()}.${pendingFmt.ext}")
        tempOut = out
        val bg = mixBgOpts[spMixBg.selectedItemPosition] / 100.0
        setStatus((if (mix) "Mencampur" else "Menggabungkan") + " ${list.size} berkas, urutan: " +
            list.withIndex().joinToString("; ") { "${it.index + 1}. ${it.value.name}" })
        thread {
            val durs = list.map { Converter.probeDurationMs(this, it.uri) }
            // Gabung: durasi dijumlah. Campur: berkas terpanjang menentukan panjang hasil,
            // kecuali "durasi mengikuti berkas pertama" dicentang (tahap 72).
            val total = if (mix) (if (cbMixFirst.isChecked) (durs.firstOrNull() ?: 0L) else (durs.maxOrNull() ?: 0L)) else durs.sum()
            session = Converter.merge(this, list.map { it.uri }, out, pendingFmt, pendingKbps, total, pendingOpts,
                onProgress = { p -> runOnUiThread { updateProgress(p) } },
                onDone = { err -> runOnUiThread { onConverted(err, list[0].base + if (mix) "_campuran" else "_gabungan") } },
                mix = mix, bgVolume = bg)
        }
    }

    /** Konversi berurutan satu per satu; hasil langsung ditulis ke folder pilihan. */
    private fun runBatch(tree: Uri?) {
        val list = items
        val fmt = pendingFmt
        val kbps = pendingKbps
        // Judul sama untuk banyak berkas tidak masuk akal; judul bawaan tiap berkas dipertahankan.
        val opts = pendingOpts.copy(title = "", track = "")
        val parent = tree?.let { DocumentsContract.buildDocumentUriUsingTree(it, DocumentsContract.getTreeDocumentId(it)) }
        thread {
            var ok = 0
            val failed = ArrayList<String>()
            val saved = ArrayList<Res>()
            for ((idx, item) in list.withIndex()) {
                if (cancelled) break
                runOnUiThread {
                    setStatus("Berkas ${idx + 1} dari ${list.size}: ${item.name}")
                    updateProgress(idx * 100 / list.size)
                }
                val out = File(cacheDir, "batch_${System.currentTimeMillis()}_$idx.${fmt.ext}")
                val latch = CountDownLatch(1)
                var err: String? = null
                val dur = Converter.probeDurationMs(this, item.uri)
                session = Converter.convert(this, item.uri, out, fmt, kbps, dur, opts,
                    onProgress = { p -> runOnUiThread { updateProgress((idx * 100 + p) / list.size) } },
                    onDone = { e -> err = e; latch.countDown() })
                latch.await()
                if (err == null) {
                    err = try {
                        val u = if (parent == null) {
                            saveAuto(out, "${item.base}.${fmt.ext}", fmt)
                        } else {
                            val doc = DocumentsContract.createDocument(contentResolver, parent, fmt.mime, "${item.base}.${fmt.ext}")
                                ?: throw java.io.IOException("folder tujuan menolak berkas baru")
                            Converter.copyTo(this, out, doc)
                            doc
                        }
                        saved += Res(u, displayName(u))
                        null
                    } catch (e: Exception) {
                        "gagal menyimpan: ${e.message}"
                    }
                }
                out.delete()
                if (err == null) ok++ else if (err != "Dibatalkan") failed += item.name
            }
            runOnUiThread {
                if (!cancelled) updateProgress(100)
                val sb = StringBuilder()
                sb.append(if (cancelled) "Dibatalkan. " else "Selesai. ")
                sb.append("$ok dari ${list.size} berkas berhasil disimpan.")
                if (ok > 0 && parent == null) sb.append(" Hasil ada di folder Musik, AudioLab Novan.")
                if (failed.isNotEmpty()) sb.append(" Gagal: ").append(failed.joinToString(", ")).append('.')
                setStatus(sb.toString())
                if (ok > 0) addHistory("Massal: $ok dari ${list.size} berkas (${fmt.label})")
                setBusy(false)
                finishWith(saved, signal = !cancelled)
            }
        }
    }

    /** Tahap 12: bacakan info tiap berkas terpilih (maksimal 10 berkas agar tidak terlalu panjang). */
    private fun showInfo() {
        val list = items.take(10)
        if (list.isEmpty()) return
        btnInfo.isEnabled = false
        setStatus("Membaca info berkas...")
        thread {
            val lines = list.mapIndexed { i, it ->
                val prefix = if (items.size > 1) "${i + 1}. ${it.name}: " else "${it.name}: "
                prefix + Converter.probeInfo(this, it.uri)
            }
            runOnUiThread {
                val extra = if (items.size > list.size) "\n(${items.size - list.size} berkas lainnya tidak ditampilkan)" else ""
                setStatus(lines.joinToString("\n") + extra)
                btnInfo.isEnabled = items.isNotEmpty() && btnPick.isEnabled
            }
        }
    }

    /** Tahap 15: baca dan periksa pengaturan dari layar. Null (dengan pesan di status) bila tidak valid. */
    private fun readOpts(): Opts? {
        val start = Converter.parseTime(etStart.text.toString())
        val end = Converter.parseTime(etEnd.text.toString())
        if (start == null || end == null) {
            applySections(R.id.btnSecCut)
            setStatus("Waktu tidak valid. Pakai detik (90) atau menit:detik (1:30). Menu Potong dan kecepatan dibuka.")
            return null
        }
        if (end > 0 && end <= start) {
            applySections(R.id.btnSecCut)
            setStatus("Waktu 'Sampai' harus lebih besar dari 'Mulai dari'. Menu Potong dan kecepatan dibuka.")
            return null
        }
        val fadeIn = Converter.parseTime(etFadeIn.text.toString())
        val fadeOut = Converter.parseTime(etFadeOut.text.toString())
        if (fadeIn == null || fadeOut == null || fadeIn < 0 || fadeOut < 0) {
            applySections(R.id.btnSecFade)
            setStatus("Lama fade tidak valid. Pakai detik, contoh 3 atau 2,5 (pakai titik: 2.5). Menu Fade dan bagi hasil dibuka.")
            return null
        }
        val cutFrom = Converter.parseTime(etCutFrom.text.toString())
        val cutTo = Converter.parseTime(etCutTo.text.toString())
        if (cutFrom == null || cutTo == null) {
            applySections(R.id.btnSecCut)
            setStatus("Waktu hapus bagian tengah tidak valid. Pakai detik (90) atau menit:detik (1:30). Menu Potong dan kecepatan dibuka.")
            return null
        }
        if ((cutFrom > 0 || cutTo > 0) && cutTo <= cutFrom) {
            applySections(R.id.btnSecCut)
            setStatus("Hapus bagian tengah: isi 'dari' dan 'sampai', dan 'sampai' harus lebih besar dari 'dari'. Menu Potong dan kecepatan dibuka.")
            return null
        }
        return Opts(start, end, speeds[spSpeed.selectedItemPosition], cbNormalize.isChecked,
            gains[spGain.selectedItemPosition], fadeIn, fadeOut,
            etTitle.text.toString(), etArtist.text.toString(), etAlbum.text.toString(), cbSilence.isChecked,
            channelOpts[spChannels.selectedItemPosition], rateOpts[spRate.selectedItemPosition],
            pitches[spPitch.selectedItemPosition],
            gains[spBass.selectedItemPosition], gains[spTreble.selectedItemPosition],
            noiseOpts[spNoise.selectedItemPosition], hpOpts[spHighpass.selectedItemPosition],
            echoOpts[spEcho.selectedItemPosition], cbReverse.isChecked, loopOpts[spLoops.selectedItemPosition],
            compOpts[spCompressor.selectedItemPosition], splitOpts[spSplit.selectedItemPosition],
            eqSpinners.map { gains[it.selectedItemPosition] }, voiceOpts[spVoice.selectedItemPosition],
            echoLevelOpts[spEchoLevel.selectedItemPosition], if (cbVocalCut.isChecked) 1 else 0,
            cutFrom = cutFrom, cutTo = cutTo,
            year = etYear.text.toString(), genre = etGenre.text.toString(),
            track = etTrack.text.toString(), comment = etComment.text.toString(), cover = coverUri,
            loudPct = loudOpts[spLoud.selectedItemPosition], duck = duckOpts[spDuck.selectedItemPosition],
            equalize = cbEqualize.isChecked, mixFollowFirst = cbMixFirst.isChecked, loopBg = cbLoopBg.isChecked, midSilence = midOpts[spMid.selectedItemPosition])
    }

    /** Tahap 15: pratinjau 10 detik pertama (mulai dari waktu "Mulai dari") berkas pertama, dengan semua pengaturan. */
    private fun togglePreview() {
        if (player != null) {
            stopPreview("Pratinjau dihentikan.")
            return
        }
        if (items.isEmpty()) return
        val o = readOpts() ?: return
        val end = if (o.endSec > o.startSec) minOf(o.endSec, o.startSec + 10.0) else o.startSec + 10.0
        val po = o.copy(endSec = end, title = "", cover = null)
        val item = items[0]
        val out = File(cacheDir, "preview_${System.currentTimeMillis()}.wav")
        previewFile = out
        cancelled = false
        updateProgress(0)
        setBusy(true)
        setStatus("Membuat pratinjau...")
        thread {
            val dur = Converter.probeDurationMs(this, item.uri)
            session = Converter.convert(this, item.uri, out, OutFmt.WAV, 192, dur, po,
                onProgress = { p -> runOnUiThread { updateProgress(p) } },
                onDone = { err -> runOnUiThread { onPreviewReady(err) } })
        }
    }

    private fun onPreviewReady(err: String?) {
        setBusy(false)
        val f = previewFile
        if (err != null || f == null) {
            f?.delete()
            previewFile = null
            setStatus(err ?: "Pratinjau gagal dibuat.")
            return
        }
        val mp = MediaPlayer()
        try {
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { stopPreview("Pratinjau selesai.") }
            mp.setOnErrorListener { _, _, _ -> stopPreview("Pratinjau gagal diputar."); true }
            mp.prepare()
            mp.start()
            player = mp
            updateProgress(100)
            btnPreview.setText(R.string.preview_stop)
            setStatus("Memutar pratinjau 10 detik pertama. Tekan tombol pratinjau lagi untuk menghentikan.")
        } catch (e: Exception) {
            mp.release()
            f.delete()
            previewFile = null
            setStatus("Pratinjau gagal diputar: ${e.message}")
        }
    }

    private fun stopPreview(msg: String? = null) {
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        player = null
        previewFile?.delete()
        previewFile = null
        btnPreview.setText(R.string.preview)
        if (msg != null) setStatus(msg)
    }

    /** Tahap 20: riwayat konversi (20 terakhir) disimpan di pengaturan, terbaru paling atas. */
    private fun historyList(): List<String> {
        val raw = getSharedPreferences("pengaturan", MODE_PRIVATE).getString("riwayat", "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split("\n")
    }

    private fun addHistory(text: String) {
        val stamp = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale("id", "ID")).format(java.util.Date())
        val line = "$stamp, " + text.replace('\n', ' ')
        val list = (listOf(line) + historyList()).take(20)
        getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putString("riwayat", list.joinToString("\n")).apply()
    }

    private fun showHistory() {
        val list = historyList()
        if (list.isEmpty()) {
            setStatus("Riwayat masih kosong.")
            return
        }
        setStatus("Riwayat konversi, ${list.size} terakhir:\n" +
            list.withIndex().joinToString("\n") { "${it.index + 1}. ${it.value}" })
    }

    private fun confirmClearHistory() {
        if (historyList().isEmpty()) {
            setStatus("Riwayat masih kosong.")
            return
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Hapus riwayat")
            .setMessage("Hapus seluruh riwayat konversi? Berkas hasil tidak ikut terhapus.")
            .setPositiveButton("Hapus") { _, _ ->
                getSharedPreferences("pengaturan", MODE_PRIVATE).edit().remove("riwayat").apply()
                setStatus("Riwayat dihapus.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /**
     * Tahap 27: salin hasil ke MediaStore (Ringtones/Notifications/Alarms) lalu setel sebagai nada bawaan.
     * Dipanggil dari thread latar; mengembalikan kalimat untuk ditambahkan ke status.
     */
    private fun setAsTone(src: File, saved: Uri, kind: Int): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return " Penyetelan nada butuh Android 10 ke atas."
        return try {
            val name = displayName(saved)
            val (dir, type, label) = when (kind) {
                1 -> Triple("Ringtones", RingtoneManager.TYPE_RINGTONE, "nada dering telepon")
                2 -> Triple("Notifications", RingtoneManager.TYPE_NOTIFICATION, "nada notifikasi")
                else -> Triple("Alarms", RingtoneManager.TYPE_ALARM, "nada alarm")
            }
            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.TITLE, name.substringBeforeLast('.', name))
                put(MediaStore.Audio.Media.MIME_TYPE, pendingFmt.mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, dir)
                put(MediaStore.Audio.Media.IS_RINGTONE, kind == 1)
                put(MediaStore.Audio.Media.IS_NOTIFICATION, kind == 2)
                put(MediaStore.Audio.Media.IS_ALARM, kind == 3)
                put(MediaStore.Audio.Media.IS_MUSIC, false)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val coll = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val u = contentResolver.insert(coll, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
            contentResolver.openOutputStream(u)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            contentResolver.update(u, done, null, null)
            RingtoneManager.setActualDefaultRingtoneUri(this, type, u)
            " Sudah disetel sebagai $label."
        } catch (e: Exception) {
            " Berkas tersimpan, tetapi gagal menyetel nada: ${e.message}"
        }
    }

    /** Tahap 28/30: tombol rekam, dipakai bergantian untuk mulai dan berhenti. Rekaman dijalankan RecordService. */
    private fun toggleRecord() {
        if (RecState.recording || recRequested) { stopRecording(); return }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty()) { askMic.launch(need.toTypedArray()); return }
        startRecording()
    }

    private fun startRecording() {
        stopPreview()
        if (recSources[spRecSource.selectedItemPosition] == SRC_INTERNAL) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                setStatus("Merekam suara internal butuh Android 10 ke atas. Pilih sumber rekaman lain.")
                return
            }
            setStatus("Sistem akan menampilkan dialog izin. Pilih Mulai sekarang untuk merekam suara internal.")
            askProjection.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
            return
        }
        if (recSources[spRecSource.selectedItemPosition] == SRC_FX) {
            recRequested = true
            ContextCompat.startForegroundService(this,
                Intent(this, RecordService::class.java).setAction(RecordService.ACTION_START)
                    .putExtra(RecordService.EXTRA_FX, true))
            applyRecordUi()
            setStatus("Mulai merekam dengan efek langsung. Pakai headset supaya suara tidak berdengung. " +
                "Tombol Jeda rekaman ada tepat di bawah tombol ini. Tekan Berhenti merekam di sini atau tombol Berhenti di notifikasi untuk selesai.")
            return
        }
        recRequested = true
        ContextCompat.startForegroundService(this,
            Intent(this, RecordService::class.java).setAction(RecordService.ACTION_START)
                .putExtra(RecordService.EXTRA_SOURCE, recSources[spRecSource.selectedItemPosition])
                .putExtra(RecordService.EXTRA_DEVICE, micDevices.getOrNull(spMic.selectedItemPosition - 1)?.id ?: -1)
                .putExtra(RecordService.EXTRA_DIR, recDirs[spMicDir.selectedItemPosition])
                .putExtra(RecordService.EXTRA_CH, recChannels[spRecCh.selectedItemPosition]))
        applyRecordUi()
        setStatus("Mulai merekam. Rekaman tetap berjalan walau layar mati atau aplikasi ditinggalkan. " +
            "Tombol Jeda rekaman ada tepat di bawah tombol ini. Tekan Berhenti merekam di sini atau tombol Berhenti di notifikasi untuk selesai.")
    }

    private fun startInternalRecording(code: Int, data: Intent) {
        recRequested = true
        ContextCompat.startForegroundService(this,
            Intent(this, RecordService::class.java).setAction(RecordService.ACTION_START)
                .putExtra(RecordService.EXTRA_INTERNAL, true)
                .putExtra(RecordService.EXTRA_PROJ_CODE, code)
                .putExtra(RecordService.EXTRA_PROJ_DATA, data))
        applyRecordUi()
        setStatus("Merekam suara internal. Putar suara di aplikasi lain, lalu kembali ke sini atau pakai tombol Berhenti di notifikasi. " +
            "Panggilan telepon dan sebagian aplikasi musik atau streaming tidak bisa direkam.")
    }

    /** Tahap 36: jeda atau lanjutkan rekaman. Keadaan baru diumumkan lewat handleRecordEvent setelah layanan menjawab. */
    private fun togglePause() {
        if (!RecState.recording) {
            setStatus("Rekaman belum dimulai, jadi belum bisa dijeda.")
            return
        }
        startService(Intent(this, RecordService::class.java)
            .setAction(if (RecState.paused) RecordService.ACTION_RESUME else RecordService.ACTION_PAUSE))
    }

    private fun stopRecording() {
        setStatus("Menghentikan rekaman...")
        startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
    }

    /** Samakan tampilan dengan keadaan perekam (juga dipanggil saat layar dibuka kembali atau diputar). */
    private fun applyRecordUi() {
        val active = RecState.recording || recRequested
        btnRecord.setText(if (active) R.string.record_stop else R.string.record)
        btnPause.visibility = if (active) View.VISIBLE else View.GONE
        btnPause.setText(if (RecState.paused) R.string.record_resume else R.string.record_pause)
        if (active) {
            btnRecord.isEnabled = true
            btnPick.isEnabled = false
            btnConvert.isEnabled = false
            btnPreview.isEnabled = false
            btnInfo.isEnabled = false
            spRecSource.isEnabled = false
            spMic.isEnabled = false
            spMicDir.isEnabled = false
            spRecCh.isEnabled = false
        }
    }

    /** Tahap 32: daftar mikrofon yang tersambung (bawaan, headset berkabel, USB). Mikrofon Bluetooth belum didukung. */
    private fun refreshMics() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val ok = setOf(AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET)
        val devs = am.getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in ok }
        val labels = listOf("Otomatis (pilihan sistem)") + devs.map { micLabel(it) }
        if (labels == micLabels) return
        val keepId = micDevices.getOrNull(spMic.selectedItemPosition - 1)?.id
        micDevices = devs
        micLabels = labels
        spMic.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = devs.indexOfFirst { it.id == keepId }
        spMic.setSelection(if (idx >= 0) idx + 1 else 0)
    }

    private fun micLabel(d: AudioDeviceInfo): String {
        val name = d.productName?.toString().orEmpty()
        return when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> {
                val pos = if (Build.VERSION.SDK_INT >= 28) d.address.orEmpty() else ""
                "Mikrofon bawaan ponsel" + if (pos.isNotBlank()) " ($pos)" else ""
            }
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Mikrofon headset berkabel"
            else -> "Mikrofon USB" + if (name.isNotBlank()) " ($name)" else ""
        }
    }

    private fun handleRecordEvent() {
        if (RecState.recording || recRequested) {
            applyRecordUi()
            if (RecState.recording && RecState.paused != uiPaused) {
                uiPaused = RecState.paused
                setStatus(if (uiPaused) "Rekaman dijeda. Tekan Lanjutkan rekaman untuk meneruskan, atau Berhenti merekam untuk menyelesaikan."
                    else "Rekaman dilanjutkan.")
            }
        }
        val r = RecState.consume() ?: return
        recRequested = false
        uiPaused = false
        btnPause.visibility = View.GONE
        btnRecord.setText(R.string.record)
        setBusy(false)
        if (r.file != null && r.error == null) {
            items = listOf(Item(Uri.fromFile(r.file), r.file.name))
            showItems()
            btnConvert.isEnabled = true
            val note = RecState.note
            setStatus("Rekaman selesai, durasi sekitar ${Converter.durasiTeks(r.sec)}. Berkas ${r.file.name} sudah terpilih dan siap diolah." +
                if (note.isNotBlank()) " Catatan: $note" else "")
            if (!isFinishing && !isDestroyed) {
                signalDone()
                val mimeRek = if (r.file.name.endsWith(".wav", true)) "audio/x-wav" else "audio/mp4"
                dialogHasil.saatDiubah = { h ->
                    items = listOf(Item(h.uri, h.nama))
                    showItems()
                }
                dialogHasil.saatDihapus = {
                    items = emptyList()
                    tvInput.setText(R.string.no_file)
                    btnInfo.isEnabled = false
                    btnPreview.isEnabled = false
                    btnConvert.isEnabled = false
                    setStatus("Rekaman dihapus.")
                }
                dialogHasil.tampilkan(Uri.fromFile(r.file), r.file.name, mimeRek)
            }
        } else {
            setStatus(r.error ?: "Rekaman gagal.")
        }
    }

    /** Tahap 14: buka menu Bagikan untuk berkas hasil yang baru disimpan. */
    private fun shareResult(uri: Uri) {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = pendingFmt.mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            setStatus("Berkas tersimpan, tetapi menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    /** Tahap 35: isi bilah progres dan umumkan tiap kelipatan 10 persen lewat teks live region (TalkBack). */
    private fun updateProgress(p: Int) {
        val v = p.coerceIn(0, 100)
        progress.progress = v
        if (v == 0) {
            lastAnnounced = -1
            tvProgress.text = ""
            return
        }
        val step = v / 10 * 10
        if (step != lastAnnounced) {
            lastAnnounced = step
            tvProgress.text = "Progres $step persen"
        }
    }

    /** Tahap 35: tanda selesai berupa nada pendek dan getar. */
    @Suppress("DEPRECATION")
    private fun signalDone() {
        try {
            val tg = android.media.ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 250)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try { tg.release() } catch (_: Exception) { }
            }, 700)
        } catch (_: Exception) { }
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v?.vibrate(android.os.VibrationEffect.createOneShot(250, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v?.vibrate(250)
            }
        } catch (_: Exception) { }
    }

    /** Tahap 35/55: dipanggil di thread utama saat hasil sudah tersimpan: beri tanda, lalu tampilkan dialog menu hasil. */
    private fun finishWith(list: List<Res>, signal: Boolean = true) {
        if (signal) signalDone()
        if (list.isEmpty() || isFinishing || isDestroyed) return
        val mime = pendingFmt.mime
        dialogHasil.saatDiubah = null
        dialogHasil.saatDihapus = null
        dialogHasil.tampilkan(list.map { DialogHasil.Hasil(it.uri, it.name, mime) }, "Konversi selesai")
    }

    private fun setBusy(busy: Boolean) {

        btnRecord.isEnabled = !busy
        btnPick.isEnabled = !busy
        btnAdd.isEnabled = !busy
        btnResetSettings.isEnabled = !busy
        btnClear.isEnabled = !busy && items.isNotEmpty()
        cbLoopBg.isEnabled = !busy && cbMixFirst.isChecked
        btnInfo.isEnabled = !busy && items.isNotEmpty()
        btnPreview.isEnabled = !busy && items.isNotEmpty()
        btnConvert.isEnabled = !busy && items.isNotEmpty()
        btnCancel.isEnabled = busy
        spFormat.isEnabled = !busy
        spBitrate.isEnabled = !busy
        spSpeed.isEnabled = !busy
        etStart.isEnabled = !busy
        etEnd.isEnabled = !busy
        cbNormalize.isEnabled = !busy
        cbSilence.isEnabled = !busy
        cbEqualize.isEnabled = !busy
        cbMixFirst.isEnabled = !busy
        cbShare.isEnabled = !busy
        spGain.isEnabled = !busy
        spChannels.isEnabled = !busy
        spPitch.isEnabled = !busy
        spBass.isEnabled = !busy
        spTreble.isEnabled = !busy
        spNoise.isEnabled = !busy
        spHighpass.isEnabled = !busy
        spEcho.isEnabled = !busy
        spCompressor.isEnabled = !busy
        spLoud.isEnabled = !busy
        spSplit.isEnabled = !busy
        eqSpinners.forEach { it.isEnabled = !busy }
        spLoops.isEnabled = !busy
        cbReverse.isEnabled = !busy
        spRate.isEnabled = !busy
        etFadeIn.isEnabled = !busy
        etFadeOut.isEnabled = !busy
        etTitle.isEnabled = !busy
        etArtist.isEnabled = !busy
        etAlbum.isEnabled = !busy
        cbMerge.isEnabled = !busy && items.size > 1
        cbMix.isEnabled = !busy && items.size > 1
        spMixBg.isEnabled = !busy
        spDuck.isEnabled = !busy
        spMid.isEnabled = !busy
        spVoice.isEnabled = !busy
        spEchoLevel.isEnabled = !busy
        spRecSource.isEnabled = !busy
        spMic.isEnabled = !busy
        spMicDir.isEnabled = !busy
        spRecCh.isEnabled = !busy
        etCutFrom.isEnabled = !busy
        etCutTo.isEnabled = !busy
        etYear.isEnabled = !busy
        etGenre.isEnabled = !busy
        etTrack.isEnabled = !busy
        etComment.isEnabled = !busy
        btnCover.isEnabled = !busy
        btnCoverClear.isEnabled = !busy
        cbEchoVoice.isEnabled = !busy
        cbVocalCut.isEnabled = !busy
        spRing.isEnabled = !busy
        spOrder.isEnabled = !busy
        btnUp.isEnabled = !busy
        btnDown.isEnabled = !busy
        btnSortName.isEnabled = !busy
    }

    private fun setStatus(s: String) {
        tvStatus.text = s
    }
}
