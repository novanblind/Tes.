package com.novan.filemanagermax

import android.app.Application

class FileManagerMaxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ThemeManager.apply(ThemeManager.get(this))
    }
}
