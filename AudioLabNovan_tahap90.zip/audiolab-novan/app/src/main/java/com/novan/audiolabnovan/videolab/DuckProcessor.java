package com.novan.audiolabnovan.videolab;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;
import androidx.media3.common.util.UnstableApi;

import java.nio.ByteBuffer;

/** Menurunkan volume musik otomatis pada bagian yang ada suara bicara, lalu menaikkannya lagi saat jeda. Menerima PCM 16 bit dan PCM float. */
@UnstableApi
public final class DuckProcessor extends BaseAudioProcessor {
    private static final long LEAD_MS = 120;     // turun sedikit lebih awal agar kata pertama tidak tertutup
    private final long[][] segs;
    private final float duckGain;
    private final double attackTc;               // detik; tetapan waktu musik turun (tahap 51: 0,03 supaya langsung turun)
    private final double releaseTc;              // detik; tetapan waktu musik naik lagi
    private long framePos = 0;
    private int idx = 0;
    private double g = 1.0;

    public DuckProcessor(long[][] segs, float duckGain) {
        this(segs, duckGain, 0.03, 0.20);
    }

    public DuckProcessor(long[][] segs, float duckGain, double attackTc, double releaseTc) {
        this.segs = segs;
        this.duckGain = duckGain;
        this.attackTc = Math.max(0.001, attackTc);
        this.releaseTc = Math.max(0.001, releaseTc);
    }

    @Override
    protected AudioProcessor.AudioFormat onConfigure(AudioProcessor.AudioFormat in)
            throws AudioProcessor.UnhandledAudioFormatException {
        if (in.encoding != C.ENCODING_PCM_16BIT && in.encoding != C.ENCODING_PCM_FLOAT) {
            // Format lain dilewatkan apa adanya supaya ekspor tidak gagal.
            return AudioProcessor.AudioFormat.NOT_SET;
        }
        return in;
    }

    @Override
    protected void onFlush() {
        framePos = 0;
        idx = 0;
        g = 1.0;
    }

    @Override
    public void queueInput(ByteBuffer inputBuffer) {
        int remaining = inputBuffer.remaining();
        if (remaining == 0) return;
        ByteBuffer out = replaceOutputBuffer(remaining);
        int channels = inputAudioFormat.channelCount;
        int rate = inputAudioFormat.sampleRate;
        double attack = 1.0 - Math.exp(-1.0 / (rate * attackTc));
        double release = 1.0 - Math.exp(-1.0 / (rate * releaseTc));
        final boolean isFloat = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT;
        final int frameBytes = channels * (isFloat ? 4 : 2);
        while (inputBuffer.remaining() >= frameBytes) {
            long tMs = framePos * 1000L / rate;
            while (idx < segs.length && segs[idx][1] <= tMs) idx++;
            boolean talking = idx < segs.length && tMs >= segs[idx][0] - LEAD_MS;
            double target = talking ? duckGain : 1.0;
            g += (target - g) * (target < g ? attack : release);
            for (int ch = 0; ch < channels; ch++) {
                if (isFloat) {
                    double x = inputBuffer.getFloat() * g;
                    out.putFloat((float) Math.max(-1.0, Math.min(1.0, x)));
                } else {
                    int v = (int) Math.round(inputBuffer.getShort() * g);
                    if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
                    if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
                    out.putShort((short) v);
                }
            }
            framePos++;
        }
        out.flip();
    }
}
