package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.view.View;
import android.view.WindowInsetsController;

/** Tema tampilan: ikuti sistem, terang, atau gelap. Pilihan disimpan dan berlaku di semua dialog. */
final class Tema {
    static final String KUNCI = "tema";
    static final String SISTEM = "sistem", TERANG = "terang", GELAP = "gelap";
    static final String[] NILAI = {SISTEM, TERANG, GELAP};
    static final String[] NAMA = {"Ikuti sistem", "Terang", "Gelap"};

    private Tema() { }

    static String pilihan(Context c) {
        String s = c.getSharedPreferences("term", Context.MODE_PRIVATE).getString(KUNCI, SISTEM);
        return TERANG.equals(s) || GELAP.equals(s) ? s : SISTEM;
    }

    static String nama(Context c) {
        String p = pilihan(c);
        for (int i = 0; i < NILAI.length; i++) if (NILAI[i].equals(p)) return NAMA[i];
        return NAMA[0];
    }

    static boolean gelap(Activity a) {
        String p = pilihan(a);
        if (GELAP.equals(p)) return true;
        if (TERANG.equals(p)) return false;
        int m = a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return m == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Panggil sebelum super.onCreate. Memasang tema aktivitas, sehingga semua dialog ikut. */
    static void pasang(Activity a) {
        a.setTheme(gelap(a) ? android.R.style.Theme_DeviceDefault : android.R.style.Theme_DeviceDefault_Light);
    }

    /** Panggil setelah setContentView. Menyesuaikan warna ikon dan latar bilah status dan navigasi. */
    @SuppressWarnings("deprecation")
    static void bilah(Activity a) {
        boolean g = gelap(a);
        if (Build.VERSION.SDK_INT < 35) {
            int warna = g ? 0xFF000000 : 0xFFF5F5F5;
            a.getWindow().setStatusBarColor(warna);
            a.getWindow().setNavigationBarColor(warna);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = a.getWindow().getInsetsController();
            if (c != null) {
                int m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(g ? 0 : m, m);
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            View v = a.getWindow().getDecorView();
            int f = v.getSystemUiVisibility();
            int m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
            v.setSystemUiVisibility(g ? (f & ~m) : (f | m));
        }
    }

    /** Dialog pilihan tema. Begitu dipilih, tampilan langsung berganti. */
    static void pilih(final Activity a) {
        String p = pilihan(a);
        int sel = 0;
        for (int i = 0; i < NILAI.length; i++) if (NILAI[i].equals(p)) sel = i;
        new AlertDialog.Builder(a).setTitle("Tema tampilan")
            .setSingleChoiceItems(NAMA, sel, (d, i) -> {
                a.getSharedPreferences("term", Context.MODE_PRIVATE).edit().putString(KUNCI, NILAI[i]).apply();
                d.dismiss();
                a.recreate();
            })
            .setNegativeButton("Tutup", null).show();
    }
}
