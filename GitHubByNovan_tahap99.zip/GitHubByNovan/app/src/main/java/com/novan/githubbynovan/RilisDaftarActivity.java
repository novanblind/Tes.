package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Daftar rilis (Releases) sebuah repositori, lengkap dengan penghapusan satu rilis atau banyak rilis sekaligus.
 * Ketuk dua kali dan tahan (tekan tahan) sebuah rilis: rilis itu otomatis tercentang dan mode centang aktif,
 * lalu centang rilis lain dan hapus terpilih. Ketuk biasa: rincian (berkas lampiran) dan hapus. Tanpa browser. Penghapusan rilis tidak menghapus tag Git-nya, kecuali kotak "hapus juga tag" dicentang.
 */
public class RilisDaftarActivity extends Activity {
    public static Intent of(Context c, String full, String name) {
        return new Intent(c, RilisDaftarActivity.class).putExtra("full", full).putExtra("name", name);
    }

    /** Terima 'user/repo' atau tautan github.com/user/repo/...; null bila tidak sah. */
    public static String parseRepo(String t) {
        if (t == null) return null;
        t = t.trim();
        t = t.replaceFirst("^(https?://)?(www\\.)?github\\.com/", "");
        String[] a = t.split("[/?#]");
        if (a.length < 2) return null;
        String u = a[0], r = a[1];
        if (r.endsWith(".git")) r = r.substring(0, r.length() - 4);
        if (!u.matches("[A-Za-z0-9-_.]+") || !r.matches("[A-Za-z0-9-_.]+")) return null;
        return u + "/" + r;
    }

    private static final int MAX_HALAMAN = 10; // 10 x 100 = 1000 rilis

    private Ui ui;
    private String token, full, name, galat = "";
    private JSONArray all = new JSONArray();
    private boolean loaded, multi, busy;
    private int jenis; // 0 semua, 1 rilis biasa, 2 pra-rilis, 3 draf
    private String cari = "";
    private static final String[] NAMA_JENIS = {"Semua", "Rilis biasa", "Pra-rilis", "Draf"};
    private boolean baca; // hanya lihat dan unduh (repo orang lain)
    private boolean edit; // layar ubah rilis untuk 'cur'
    private JSONObject cur; // rilis yang sedang dibuka rinciannya (null = tampil daftar)
    private final Set<Long> picked = new LinkedHashSet<>();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        full = getIntent().getStringExtra("full");
        name = getIntent().getStringExtra("name");
        if (name == null) name = full;
        baca = getIntent().getBooleanExtra("baca", false);
        load();
    }

    // ---------- memuat ----------

    private void load() {
        loaded = false;
        galat = "";
        all = new JSONArray();
        picked.clear();
        render();
        page(1);
    }

    private void page(final int p) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/releases?per_page=100&page=" + p, token, null,
                (ok, res) -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (!ok) {
                        galat = res + petunjuk(res);
                        loaded = true;
                        render();
                        ui.say("Gagal memuat daftar rilis. " + galat);
                        return;
                    }
                    JSONArray a = Api.parseArr(res);
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.optJSONObject(i);
                        if (o != null) all.put(o);
                    }
                    ui.progress("Memuat rilis... " + all.length() + " rilis sejauh ini.");
                    if (a.length() >= 100 && p < MAX_HALAMAN) {
                        page(p + 1);
                    } else {
                        loaded = true;
                        segarkanCur();
                        render();
                        ui.say(all.length() == 0 ? "Repositori ini belum punya rilis."
                                : all.length() + " rilis dimuat.");
                    }
                });
    }

    private static String petunjuk(String t) {
        if (t.contains("403") || t.contains("404")) {
            return "\n(Token perlu izin 'repo' atau 'Contents: read and write'.)";
        }
        return "";
    }

    // ---------- tampilan ----------

    private List<JSONObject> daftar() {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null) out.add(o);
        }
        return out;
    }

    /** Daftar setelah filter jenis dan kata cari (tag, judul, nama berkas). */
    private List<JSONObject> tampil() {
        List<JSONObject> out = new ArrayList<>();
        String q = cari.toLowerCase();
        for (JSONObject r : daftar()) {
            boolean d = r.optBoolean("draft", false), p = r.optBoolean("prerelease", false);
            if (jenis == 1 && (d || p)) continue;
            if (jenis == 2 && !p) continue;
            if (jenis == 3 && !d) continue;
            if (!q.isEmpty()) {
                StringBuilder h = new StringBuilder(Api.str(r, "tag_name") + " " + Api.str(r, "name"));
                JSONArray a = r.optJSONArray("assets");
                for (int i = 0; a != null && i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null) h.append(' ').append(Api.str(o, "name"));
                }
                if (!h.toString().toLowerCase().contains(q)) continue;
            }
            out.add(r);
        }
        return out;
    }

    private long totalUnduhan() {
        long n = 0;
        for (JSONObject r : daftar()) {
            JSONArray a = r.optJSONArray("assets");
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) n += o.optLong("download_count");
            }
        }
        return n;
    }

    private static String teks(JSONObject r, int no) {
        String tag = Api.str(r, "tag_name");
        String judul = Api.str(r, "name");
        StringBuilder sb = new StringBuilder();
        if (no > 0) sb.append(no).append(". ");
        if (tag.isEmpty() && judul.isEmpty()) sb.append("(tanpa nama)");
        else if (judul.isEmpty() || judul.equals(tag)) sb.append(tag);
        else if (tag.isEmpty()) sb.append(judul);
        else sb.append(tag).append(" - ").append(judul);
        if (r.optBoolean("draft", false)) sb.append(" [draf]");
        if (r.optBoolean("prerelease", false)) sb.append(" [pra-rilis]");
        JSONArray a = r.optJSONArray("assets");
        sb.append(", ").append(a == null ? 0 : a.length()).append(" berkas");
        String tgl = Api.str(r, "published_at");
        if (tgl.isEmpty()) tgl = Api.str(r, "created_at");
        if (tgl.length() >= 10) sb.append(", ").append(tgl, 0, 10);
        return sb.toString();
    }

    private void render() {
        ui = new Ui(this, multi ? "Pilih banyak rilis" : "Rilis: " + name);
        if (!loaded) {
            ui.label("Memuat daftar rilis...");
            ui.button("Kembali", v -> finish());
            return;
        }
        if (!galat.isEmpty()) {
            ui.label(galat);
            ui.button("Coba lagi", v -> load());
            ui.button("Kembali", v -> finish());
            return;
        }
        if (cur != null && edit) {
            renderEdit();
            return;
        }
        if (cur != null) {
            renderDetail();
            return;
        }
        if (multi) {
            renderMulti();
            return;
        }
        List<JSONObject> list = tampil();
        if (!daftar().isEmpty()) {
            ui.label("Total " + daftar().size() + " rilis, " + totalUnduhan() + " kali diunduh.");
            ui.button("Filter jenis: " + NAMA_JENIS[jenis] + " (ketuk untuk ganti)", v -> {
                jenis = (jenis + 1) % NAMA_JENIS.length;
                render();
                ui.say("Filter: " + NAMA_JENIS[jenis] + ". " + tampil().size() + " rilis tampil.");
            });
            ui.button(cari.isEmpty() ? "Cari rilis (tag, judul, nama berkas)" : "Cari: " + cari + " (ketuk untuk ubah)",
                    v -> ui.prompt("Cari rilis", "kata kunci, kosong = semua", cari, t -> {
                        cari = t;
                        render();
                        ui.say(tampil().size() + " rilis cocok.");
                    }));
        }
        if (list.isEmpty()) {
            ui.label(daftar().isEmpty() ? "Repositori ini belum punya rilis." : "Tidak ada rilis yang cocok dengan filter.");
        } else {
            if (baca) {
                ui.label(list.size() + " rilis. Ketuk untuk rincian, unduh, dan tautan.");
            } else {
                ui.label(list.size() + " rilis. Ketuk untuk rincian dan hapus. Tekan tahan untuk memilih banyak.");
                ui.button("Pilih banyak (multi-select)", v -> {
                    multi = true;
                    picked.clear();
                    render();
                });
            }
        }
        int i = 1;
        for (final JSONObject r : list) {
            final long id = r.optLong("id");
            Button b = ui.button(teks(r, i++), v -> rincian(r));
            if (!baca) b.setOnLongClickListener(v -> {
                multi = true;
                picked.clear();
                picked.add(id);
                render();
                ui.say("Mode pilih aktif. " + teks(r, 0) + " tercentang. "
                        + "Ketuk rilis lain untuk mengubah centang.");
                return true;
            });
        }
        // Daftar rilis paling atas; tombol segarkan dan tautan (salin, bagikan, dan lain-lain) di bawahnya.
        ui.button("Segarkan daftar", v -> load());
        renderTautanUmum();
        ui.button("Kembali", v -> finish());
    }

    private void renderMulti() {
        final TextView cnt = ui.label(picked.size() + " rilis terpilih.");
        ui.button("Hapus terpilih", Ui.DANGER, v -> hapusTerpilih());
        ui.button("Centang semua", v -> {
            for (JSONObject r : tampil()) picked.add(r.optLong("id"));
            render();
            ui.say(picked.size() + " rilis terpilih.");
        });
        ui.button("Batalkan semua centang", v -> {
            picked.clear();
            render();
            ui.say("Semua centang dibatalkan.");
        });
        for (final JSONObject r : tampil()) {
            final long id = r.optLong("id");
            CheckBox c = ui.check(teks(r, 0), picked.contains(id));
            c.setOnCheckedChangeListener((btn, on) -> {
                if (on) picked.add(id); else picked.remove(id);
                cnt.setText(picked.size() + " rilis terpilih.");
            });
        }
        ui.button("Selesai memilih", v -> {
            multi = false;
            picked.clear();
            render();
        });
    }

    @Override
    public void onBackPressed() {
        if (busy) {
            ui.say("Sedang menghapus rilis. Tunggu sampai selesai.");
            return;
        }
        if (cur != null && edit) {
            edit = false;
            render();
            ui.say("Ubah rilis dibatalkan.");
            return;
        }
        if (cur != null) {
            cur = null;
            render();
            ui.say("Kembali ke daftar rilis.");
            return;
        }
        // Dalam mode pilih, Kembali keluar dari mode pilih dulu, bukan menutup layar.
        if (multi) {
            multi = false;
            picked.clear();
            render();
            ui.say("Mode pilih ditutup.");
            return;
        }
        super.onBackPressed();
    }

    // ---------- rincian satu rilis ----------

    private void rincian(final JSONObject r) {
        cur = r;
        render();
        ui.say("Rincian rilis " + teks(r, 0));
    }

    // ---------- tautan ----------

    private String halamanRilis() { return "https://github.com/" + full + "/releases"; }

    private String tautanApi() { return Api.BASE + "/repos/" + full + "/releases"; }

    private String tautanRilis(JSONObject r) {
        String u = Api.str(r, "html_url");
        if (!u.isEmpty()) return u;
        return halamanRilis() + "/tag/" + Api.enc(Api.str(r, "tag_name"));
    }

    /** Tautan unduhan langsung berpola tetap: /releases/download/TAG/NAMA-FILE. */
    private String tautanLangsung(JSONObject r, JSONObject a) {
        String u = Api.str(a, "browser_download_url");
        if (!u.isEmpty()) return u;
        return halamanRilis() + "/download/" + Api.enc(Api.str(r, "tag_name")) + "/" + Api.enc(Api.str(a, "name"));
    }

    /** Rilis terbaru versi GitHub: yang terbaru dan bukan draf atau pra-rilis. */
    private long idTerbaru() {
        long best = 0;
        String bestTgl = "";
        for (JSONObject r : daftar()) {
            if (r.optBoolean("draft", false) || r.optBoolean("prerelease", false)) continue;
            String t = Api.str(r, "created_at");
            if (best == 0 || t.compareTo(bestTgl) > 0) {
                best = r.optLong("id");
                bestTgl = t;
            }
        }
        return best;
    }

    private String tautanTerbaru(JSONObject a) {
        return halamanRilis() + "/latest/download/" + Api.enc(Api.str(a, "name"));
    }

    /** Semua tautan unduhan langsung dari semua rilis dimuat, sebagai teks siap salin atau bagikan. */
    private String semuaTautan() {
        StringBuilder sb = new StringBuilder();
        sb.append("Halaman rilis: ").append(halamanRilis()).append('\n');
        sb.append("Daftar via API: ").append(tautanApi()).append("\n");
        long term = idTerbaru();
        for (JSONObject r : daftar()) {
            if (r.optBoolean("draft", false)) continue;
            JSONArray a = r.optJSONArray("assets");
            sb.append("\n").append(Api.str(r, "tag_name"));
            if (r.optLong("id") == term) sb.append(" (terbaru)");
            sb.append('\n');
            if (a == null || a.length() == 0) { sb.append("  (tanpa berkas)\n"); continue; }
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                sb.append("  ").append(Api.str(o, "name")).append(": ").append(tautanLangsung(r, o)).append('\n');
            }
        }
        return sb.toString();
    }

    private String terbaruTeks() {
        long term = idTerbaru();
        StringBuilder sb = new StringBuilder();
        for (JSONObject r : daftar()) {
            if (r.optLong("id") != term) continue;
            sb.append("Rilis terbaru: ").append(Api.str(r, "tag_name")).append('\n');
            JSONArray a = r.optJSONArray("assets");
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) sb.append(Api.str(o, "name")).append(": ").append(tautanTerbaru(o)).append('\n');
            }
        }
        return sb.toString();
    }

    /** Teks Markdown siap tempel ke README: tautan selalu-terbaru tiap berkas dan tautan semua versi. */
    private String teksReadme() {
        StringBuilder sb = new StringBuilder();
        sb.append("## Unduh\n\n");
        long term = idTerbaru();
        for (JSONObject r : daftar()) {
            if (r.optLong("id") != term) continue;
            sb.append("Versi terbaru: **").append(Api.str(r, "tag_name")).append("**\n\n");
            JSONArray a = r.optJSONArray("assets");
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                sb.append("- [").append(Api.str(o, "name")).append("](").append(tautanTerbaru(o)).append(") (")
                        .append(Ui.size(o.optLong("size"))).append(")\n");
            }
        }
        sb.append("\nSemua versi sebelumnya: [Releases](").append(halamanRilis()).append(")\n");
        return sb.toString();
    }

    private void renderTautanUmum() {
        ui.section("TAUTAN RILIS");
        ui.label("Tidak perlu menyimpan tautan satu per satu: GitHub menyimpan semua riwayat rilis di satu halaman. "
                + "Repositori harus Public agar orang lain bisa mengunduh.");
        ui.button("Salin tautan halaman Releases", v -> Ui.copy(this, "Tautan halaman Releases", halamanRilis()));
        ui.button("Bagikan tautan halaman Releases", v -> Ui.share(this, "Rilis " + name, halamanRilis()));
        ui.button("Salin tautan API daftar rilis", v -> Ui.copy(this, "Tautan API", tautanApi()));
        ui.button("Salin tautan umpan rilis (Atom, untuk pembaca RSS)", v -> Ui.copy(this, "Tautan umpan rilis", halamanRilis() + ".atom"));
        if (!baca) ui.button("Cari tag tanpa rilis (tag yatim)", v -> cariTagYatim());
        if (!daftar().isEmpty()) {
            ui.button("Salin semua tautan unduhan (semua versi)", v -> Ui.copy(this, "Semua tautan unduhan", semuaTautan()));
            ui.button("Bagikan semua tautan unduhan", v -> Ui.share(this, "Tautan unduhan " + name, semuaTautan()));
            if (idTerbaru() != 0) {
                ui.button("Salin teks siap tempel untuk README (Markdown)", v -> Ui.copy(this, "Teks README", teksReadme()));
                ui.button("Salin tautan selalu-terbaru (semua berkas rilis terbaru)", v -> Ui.copy(this, "Tautan terbaru", terbaruTeks()));
            }
        }
    }

    // ---------- rincian satu rilis (layar) ----------

    private void renderDetail() {
        final JSONObject r = cur;
        ui = new Ui(this, "Rilis: " + Api.str(r, "tag_name"));
        StringBuilder m = new StringBuilder();
        m.append("Tag: ").append(Api.str(r, "tag_name")).append('\n');
        m.append("Judul: ").append(Api.str(r, "name")).append('\n');
        String tgl = Api.str(r, "published_at");
        if (tgl.isEmpty()) tgl = Api.str(r, "created_at");
        if (!tgl.isEmpty()) m.append("Tanggal: ").append(tgl.replace('T', ' ').replace("Z", " UTC")).append('\n');
        if (r.optBoolean("draft", false)) m.append("Status: draf (belum diterbitkan)\n");
        if (r.optBoolean("prerelease", false)) m.append("Status: pra-rilis\n");
        final boolean terbaru = r.optLong("id") == idTerbaru();
        if (terbaru) m.append("Ini rilis terbaru.\n");
        String cat = Api.str(r, "body").trim();
        if (!cat.isEmpty()) {
            if (cat.length() > 500) cat = cat.substring(0, 500) + "...";
            m.append("\nCatatan:\n").append(cat);
        }
        ui.label(m.toString());

        if (!Api.str(r, "body").trim().isEmpty()) {
            ui.button("Salin catatan rilis lengkap", v -> Ui.copy(this, "Catatan rilis", Api.str(r, "body")));
        }
        ui.button("Salin tautan halaman rilis ini", v -> Ui.copy(this, "Tautan rilis", tautanRilis(r)));
        ui.button("Bagikan tautan halaman rilis ini", v -> Ui.share(this, Api.str(r, "tag_name"), tautanRilis(r)));

        JSONArray a = r.optJSONArray("assets");
        int n = a == null ? 0 : a.length();
        if (n > 1) {
            ui.button("Pilih berkas lalu salin tautannya (centang)", v -> pilihTautan(r, terbaru));
            ui.button("Unduh semua berkas rilis ini (" + n + ")", v -> unduhSemua(r, 0));
        }
        final String tagR = Api.str(r, "tag_name");
        if (!tagR.isEmpty()) {
            ui.button("Salin tautan kode sumber (.zip)", v -> Ui.copy(this, "Tautan kode sumber",
                    "https://github.com/" + full + "/archive/refs/tags/" + Api.enc(tagR) + ".zip"));
            ui.button("Salin tautan kode sumber (.tar.gz)", v -> Ui.copy(this, "Tautan kode sumber",
                    "https://github.com/" + full + "/archive/refs/tags/" + Api.enc(tagR) + ".tar.gz"));
        }
        ui.section("BERKAS LAMPIRAN: " + n);
        for (int i = 0; i < n; i++) {
            final JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final String nama = Api.str(o, "name");
            ui.label(nama + " (" + Ui.size(o.optLong("size")) + ", diunduh " + o.optInt("download_count") + " kali)");
            ui.button("Unduh " + nama, v -> {
                String api = Api.str(o, "url");
                String link = tautanLangsung(r, o);
                ApkTools.download(this, api.isEmpty() ? link : api, nama, token, false, true, link, () -> render());
            });
            final String dg = Api.str(o, "digest");
            if (dg.startsWith("sha256:")) {
                ui.button("Salin SHA-256 " + nama, v -> Ui.copy(this, "SHA-256", dg.substring(7)));
            }
            ui.button("Salin tautan unduhan langsung " + nama, v -> Ui.copy(this, "Tautan unduhan", tautanLangsung(r, o)));
            ui.button("Bagikan tautan unduhan " + nama, v -> Ui.share(this, nama, tautanLangsung(r, o)));
            if (terbaru) {
                ui.button("Salin tautan selalu-terbaru " + nama, v -> Ui.copy(this, "Tautan terbaru", tautanTerbaru(o)));
            }
            if (!baca) ui.button("Ganti nama berkas " + nama, v -> gantiNamaAset(o));
            if (!baca) ui.button("Ubah label berkas " + nama, v -> ubahLabelAset(o));
            if (!baca) ui.button("Hapus berkas " + nama + " dari rilis", Ui.DANGER, v -> hapusAset(o));
        }
        if (n == 0) ui.label("Rilis ini tidak punya berkas lampiran.");

        if (!baca) {
        ui.button("Tambah berkas lampiran ke rilis ini", v -> startActivity(
                new Intent(this, RepoActivity.class).putExtra("full", full).putExtra("name", name)
                        .putExtra("private", getIntent().getBooleanExtra("private", false))
                        .putExtra("html", "https://github.com/" + full)
                        .putExtra("rilisTag", Api.str(r, "tag_name"))));
        ui.button("Duplikat rilis ini ke tag baru (judul dan catatan saja)", v -> duplikat(r));
        ui.button("Ubah judul, catatan, dan status rilis", v -> {
            edit = true;
            render();
        });
        if (!terbaru && !r.optBoolean("draft", false) && !r.optBoolean("prerelease", false)) {
            ui.button("Jadikan rilis terbaru", v -> ubah(Api.o("make_latest", "true"),
                    "Rilis " + Api.str(r, "tag_name") + " dijadikan rilis terbaru."));
        }
        ui.button("Hapus rilis ini", Ui.DANGER, v -> {
            List<JSONObject> one = new ArrayList<>();
            one.add(r);
            tanyaHapus(one);
        });
        }
        ui.button("Kembali ke daftar rilis", v -> {
            cur = null;
            render();
        });
    }

    private void segarkanCur() {
        if (cur == null) return;
        long id = cur.optLong("id");
        cur = null;
        for (JSONObject r : daftar()) if (r.optLong("id") == id) cur = r;
        if (cur == null) edit = false;
    }

    private void renderEdit() {
        final JSONObject r = cur;
        ui = new Ui(this, "Ubah rilis: " + Api.str(r, "tag_name"));
        ui.label("Tag tidak bisa diubah di sini. Judul kosong berarti sama dengan tag.");
        final EditText eJudul = ui.edit("Judul rilis:", "", false, Api.str(r, "name"));
        final EditText eCat = ui.edit("Catatan rilis:", "", true, Api.str(r, "body"));
        eCat.setMinLines(3);
        final boolean draf = r.optBoolean("draft", false);
        final CheckBox cPra = ui.check("Pra-rilis (tidak dihitung sebagai rilis terbaru)", r.optBoolean("prerelease", false));
        final CheckBox cDraf = ui.check("Draf (belum diterbitkan)", draf);
        ui.button("Simpan perubahan", v -> {
            String judul = eJudul.getText().toString().trim();
            String tag = Api.str(r, "tag_name");
            JSONObject f = Api.o("name", judul.isEmpty() ? tag : judul, "body", eCat.getText().toString(),
                    "prerelease", cPra.isChecked(), "draft", cDraf.isChecked());
            ubah(f, "Perubahan rilis " + tag + " disimpan.");
        });
        ui.button("Batal", v -> {
            edit = false;
            render();
        });
    }

    private void ubah(JSONObject fields, final String pesanOk) {
        if (cur == null || busy) return;
        busy = true;
        ui.progress("Menyimpan perubahan rilis...");
        Api.request("PATCH", Api.BASE + "/repos/" + full + "/releases/" + cur.optLong("id"), token,
                fields.toString(), (ok, res) -> {
                    busy = false;
                    if (isFinishing() || isDestroyed()) return;
                    if (!ok) {
                        ui.say("Gagal menyimpan. " + res + petunjuk(res));
                        return;
                    }
                    edit = false;
                    load();
                    ui.say(pesanOk);
                });
    }

    /** Dialog centang: pilih berkas mana saja yang tautan unduhannya mau disalin atau dibagikan. */
    private void pilihTautan(final JSONObject r, final boolean terbaru) {
        final JSONArray a = r.optJSONArray("assets");
        if (a == null || a.length() == 0) return;
        final int n = a.length();
        final String[] items = new String[n];
        final boolean[] on = new boolean[n];
        for (int i = 0; i < n; i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o == null ? "?" : Api.str(o, "name") + " (" + Ui.size(o.optLong("size")) + ")";
            on[i] = true;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Pilih berkas")
                .setMultiChoiceItems(items, on, (d, w, c) -> on[w] = c)
                .setPositiveButton("salin tautan", (d, w) -> keluarkan(r, a, on, false, false))
                .setNeutralButton("bagikan", (d, w) -> keluarkan(r, a, on, false, true))
                .setNegativeButton("batal", null);
        ui.fix(b.show());
    }

    private void keluarkan(JSONObject r, JSONArray a, boolean[] on, boolean pakaiTerbaru, boolean bagikan) {
        StringBuilder sb = new StringBuilder();
        int c = 0;
        for (int i = 0; i < a.length(); i++) {
            if (!on[i]) continue;
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(Api.str(o, "name")).append(": ").append(pakaiTerbaru ? tautanTerbaru(o) : tautanLangsung(r, o));
            c++;
        }
        if (c == 0) {
            ui.say("Belum ada berkas dicentang.");
            return;
        }
        if (bagikan) Ui.share(this, Api.str(r, "tag_name"), sb.toString());
        else Ui.copy(this, c + " tautan unduhan", sb.toString());
    }

    /** Antrean unduh: berkas berikutnya mulai setelah dialog hasil berkas sebelumnya ditutup. */
    private void unduhSemua(final JSONObject r, final int i) {
        JSONArray a = r.optJSONArray("assets");
        if (a == null || i >= a.length() || isFinishing() || isDestroyed() || cur == null) return;
        if (i == 0 && DownloadService.busy()) {
            ui.say("Unduhan lain masih berjalan. Tunggu sampai selesai.");
            return;
        }
        final JSONObject o = a.optJSONObject(i);
        if (o == null) {
            unduhSemua(r, i + 1);
            return;
        }
        final String nama = Api.str(o, "name");
        String api = Api.str(o, "url");
        String link = tautanLangsung(r, o);
        ui.say("Unduhan " + (i + 1) + " dari " + a.length() + ": " + nama
                + ". Berkas berikutnya mulai setelah dialog hasil ditutup. Tombol Kembali menghentikan antrean.");
        ApkTools.download(this, api.isEmpty() ? link : api, nama, token, false, true, link, () -> unduhSemua(r, i + 1));
    }

    private void ubahLabelAset(final JSONObject o) {
        final String nama = Api.str(o, "name");
        ui.ask("Ubah label berkas", "Label adalah teks keterangan yang tampil di GitHub di samping berkas. "
                + "Kosongkan untuk menghapus label. Isi berkas tidak diunggah ulang.",
                "Label:", Api.str(o, "label"), "simpan", baru -> {
                    Api.request("PATCH", Api.BASE + "/repos/" + full + "/releases/assets/" + o.optLong("id"),
                            token, Api.o("label", baru).toString(), (ok, res) -> {
                                if (isFinishing() || isDestroyed()) return;
                                if (!ok) {
                                    ui.say("Gagal mengubah label. " + res + petunjuk(res));
                                    return;
                                }
                                load();
                                ui.say("Label berkas " + nama + " disimpan.");
                            });
                });
    }

    private void duplikat(final JSONObject r) {
        final String lama = Api.str(r, "tag_name");
        String saran = lama;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.*?)(\\d+)(\\D*)$").matcher(lama);
        if (m.matches()) {
            try { saran = m.group(1) + (Long.parseLong(m.group(2)) + 1) + m.group(3); } catch (Exception ignored) { }
        }
        ui.ask("Duplikat rilis", "Dibuat rilis baru dengan judul, catatan, dan status yang sama, tanpa berkas "
                        + "(berkas tidak disalin supaya tidak memakai kuota). Tag baru dibuat dari cabang bawaan repo.",
                "Nama tag baru:", saran, "buat", baru -> {
                    if (baru.isEmpty() || baru.matches(".*\\s.*")) {
                        ui.say("Nama tag wajib diisi dan tidak boleh memuat spasi.");
                        return;
                    }
                    if (baru.equals(lama)) {
                        ui.say("Tag baru harus berbeda dari tag asal.");
                        return;
                    }
                    String judul = Api.str(r, "name");
                    JSONObject b = Api.o("tag_name", baru, "name", judul.isEmpty() || judul.equals(lama) ? baru : judul,
                            "body", Api.str(r, "body"), "draft", r.optBoolean("draft", false),
                            "prerelease", r.optBoolean("prerelease", false));
                    ui.progress("Membuat rilis " + baru + "...");
                    Api.request("POST", Api.BASE + "/repos/" + full + "/releases", token, b.toString(), (ok, res) -> {
                        if (isFinishing() || isDestroyed()) return;
                        if (!ok) {
                            ui.say("Gagal menduplikat. " + res + (res.contains("422")
                                    ? "\n(Tag " + baru + " mungkin sudah punya rilis, atau repo belum punya komit.)" : petunjuk(res)));
                            return;
                        }
                        cur = null;
                        load();
                        ui.say("Rilis " + baru + " dibuat. Tambah berkas lewat rincian rilis itu.");
                    });
                });
    }

    // ---------- tag tanpa rilis ----------

    private void cariTagYatim() {
        if (busy) return;
        ui.progress("Memuat daftar tag...");
        muatTag(1, new ArrayList<String>());
    }

    private void muatTag(final int p, final List<String> acc) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/tags?per_page=100&page=" + p, token, null, (ok, res) -> {
            if (isFinishing() || isDestroyed()) return;
            if (!ok) {
                ui.say("Gagal memuat tag. " + res + petunjuk(res));
                return;
            }
            JSONArray a = Api.parseArr(res);
            for (int i = 0; i < a.length(); i++) {
                String t = Api.str(a.optJSONObject(i), "name");
                if (!t.isEmpty()) acc.add(t);
            }
            if (a.length() >= 100 && p < 10) {
                ui.progress("Memuat tag... " + acc.size());
                muatTag(p + 1, acc);
                return;
            }
            Set<String> dipakai = new LinkedHashSet<>();
            for (JSONObject r : daftar()) dipakai.add(Api.str(r, "tag_name"));
            final List<String> yatim = new ArrayList<>();
            for (String t : acc) if (!dipakai.contains(t)) yatim.add(t);
            if (yatim.isEmpty()) {
                ui.say("Tidak ada tag yatim. Dari " + acc.size() + " tag, semuanya punya rilis.");
                return;
            }
            tampilTagYatim(yatim, acc.size());
        });
    }

    private void tampilTagYatim(final List<String> yatim, int total) {
        final String[] items = yatim.toArray(new String[0]);
        final boolean[] on = new boolean[items.length];
        ui.say(yatim.size() + " tag tanpa rilis dari " + total + " tag.");
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(yatim.size() + " tag tanpa rilis")
                .setMultiChoiceItems(items, on, (d, w, c) -> on[w] = c)
                .setPositiveButton("hapus yang dicentang", (d, w) -> {
                    final List<String> pilih = new ArrayList<>();
                    for (int i = 0; i < items.length; i++) if (on[i]) pilih.add(items[i]);
                    if (pilih.isEmpty()) {
                        ui.say("Belum ada tag dicentang.");
                        return;
                    }
                    ui.confirm("Hapus " + pilih.size() + " tag?",
                            "Tag dihapus permanen dari repositori (komit tidak ikut terhapus):\n\n" + gabung(pilih),
                            "hapus", () -> {
                                busy = true;
                                hapusTagStep(0, pilih, new ArrayList<String>(), new ArrayList<String>());
                            });
                })
                .setNegativeButton("tutup", null);
        ui.fix(b.show());
    }

    private void hapusTagStep(final int i, final List<String> l, final List<String> okL, final List<String> failL) {
        if (isFinishing() || isDestroyed()) {
            busy = false;
            return;
        }
        if (i >= l.size()) {
            busy = false;
            String pesan = "Berhasil: " + okL.size() + "\nGagal: " + failL.size();
            if (!failL.isEmpty()) pesan += "\n\nDetail gagal:\n" + gabung(failL);
            ui.say("Hapus tag selesai. Berhasil " + okL.size() + ", gagal " + failL.size() + ".");
            ui.info("Hapus tag selesai", pesan, "oke", null);
            return;
        }
        final String t = l.get(i);
        ui.progress("Menghapus tag (" + (i + 1) + " dari " + l.size() + "): " + t);
        Api.request("DELETE", Api.BASE + "/repos/" + full + "/git/refs/tags/" + Api.enc(t), token, null, (ok, res) -> {
            if (ok) okL.add(t); else failL.add(t + " (" + res + ")");
            hapusTagStep(i + 1, l, okL, failL);
        });
    }

    /** Ganti nama berkas lampiran langsung di GitHub, tanpa mengunggah ulang (tidak memakai kuota data). */
    private void gantiNamaAset(final JSONObject o) {
        final String lama = Api.str(o, "name");
        ui.ask("Ganti nama berkas",
                "Hanya nama yang berubah, isi berkas tidak diunggah ulang. Tautan unduh lama tidak berlaku lagi, "
                        + "tautan baru memakai nama baru.",
                "Nama baru:", lama, "ganti nama", baru -> {
                    if (baru.isEmpty() || baru.contains("/") || baru.matches(".*\\s.*")) {
                        ui.say("Nama tidak boleh kosong, memuat spasi, atau garis miring.");
                        return;
                    }
                    if (baru.equals(lama)) {
                        ui.say("Nama sama dengan yang lama.");
                        return;
                    }
                    ui.progress("Mengganti nama berkas...");
                    Api.request("PATCH", Api.BASE + "/repos/" + full + "/releases/assets/" + o.optLong("id"),
                            token, Api.o("name", baru).toString(), (ok, res) -> {
                                if (isFinishing() || isDestroyed()) return;
                                if (!ok) {
                                    ui.say("Gagal mengganti nama. " + res + (res.contains("422")
                                            ? "\n(Sudah ada berkas bernama sama di rilis ini.)" : petunjuk(res)));
                                    return;
                                }
                                load();
                                ui.say("Nama berkas diganti menjadi " + baru + ".");
                            });
                });
    }

    private void hapusAset(final JSONObject o) {
        final String nama = Api.str(o, "name");
        ui.confirm("Hapus berkas lampiran?",
                nama + " dihapus permanen dari rilis ini. Tautan unduhnya tidak berlaku lagi.", "hapus", () -> {
                    ui.progress("Menghapus berkas " + nama + "...");
                    Api.request("DELETE", Api.BASE + "/repos/" + full + "/releases/assets/" + o.optLong("id"),
                            token, null, (ok, res) -> {
                                if (isFinishing() || isDestroyed()) return;
                                if (!ok) {
                                    ui.say("Gagal menghapus berkas. " + res + petunjuk(res));
                                    return;
                                }
                                cur = null;
                                load();
                                ui.say("Berkas " + nama + " terhapus.");
                            });
                });
    }

    // ---------- hapus ----------

    private void hapusTerpilih() {
        List<JSONObject> l = new ArrayList<>();
        for (JSONObject r : daftar()) if (picked.contains(r.optLong("id"))) l.add(r);
        if (l.isEmpty()) {
            ui.say("Belum ada rilis dipilih.");
            return;
        }
        tanyaHapus(l);
    }

    private void tanyaHapus(final List<JSONObject> l) {
        if (busy) return;
        if (RilisService.untuk(full)) {
            ui.say("Rilis sedang dibuat. Tunggu sampai selesai.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (JSONObject r : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(teks(r, 0));
        }
        ui.confirmCheck("Hapus " + l.size() + " rilis?",
                "Rilis ini dihapus permanen beserta lampirannya "
                        + "(tautan unduh tidak berlaku lagi):\n\n" + sb,
                "Hapus juga tag dari rilis yang dipilih", true, "hapus",
                hapusTag -> {
                    busy = true;
                    step(0, l, hapusTag, new ArrayList<String>(), new ArrayList<String>());
                });
    }

    private void step(final int i, final List<JSONObject> l, final boolean hapusTag,
                      final List<String> okL, final List<String> failL) {
        if (isFinishing() || isDestroyed()) {
            busy = false;
            return;
        }
        if (i >= l.size()) {
            selesai(okL, failL);
            return;
        }
        final JSONObject r = l.get(i);
        final long id = r.optLong("id");
        final String tag = Api.str(r, "tag_name");
        final String nama = tag.isEmpty() ? teks(r, 0) : tag;
        ui.progress("Menghapus rilis (" + (i + 1) + " dari " + l.size() + "): " + nama);
        Api.request("DELETE", Api.BASE + "/repos/" + full + "/releases/" + id, token, null, (ok, res) -> {
            if (!ok) {
                failL.add(nama + " (" + res + petunjuk(res) + ")");
                step(i + 1, l, hapusTag, okL, failL);
                return;
            }
            if (hapusTag && !tag.isEmpty()) {
                Api.request("DELETE", Api.BASE + "/repos/" + full + "/git/refs/tags/" + Api.enc(tag), token,
                        null, (ok2, res2) -> {
                            okL.add(ok2 ? nama : nama + " (rilis terhapus, tag tidak terhapus: " + res2 + ")");
                            step(i + 1, l, hapusTag, okL, failL);
                        });
            } else {
                okL.add(nama);
                step(i + 1, l, hapusTag, okL, failL);
            }
        });
    }

    private static String gabung(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }

    private void selesai(List<String> okL, List<String> failL) {
        busy = false;
        String pesan = "Berhasil: " + okL.size() + "\nGagal: " + failL.size();
        if (!okL.isEmpty()) pesan += "\n\nTerhapus:\n" + gabung(okL);
        if (!failL.isEmpty()) pesan += "\n\nDetail gagal:\n" + gabung(failL);
        ui.say("Hapus rilis selesai. Berhasil " + okL.size() + ", gagal " + failL.size() + ".");
        ui.info("Hapus rilis selesai", pesan, "oke", () -> {
            multi = false;
            load();
        });
    }
}
