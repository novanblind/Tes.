#!/usr/bin/env bash
# Membangun libytmp3.so: FFmpeg ramping (hanya yang perlu untuk konversi ke MP3) + LAME + JNI.
#   bash native/build-native.sh arm64-v8a   -> app/src/main/jniLibs/arm64-v8a/libytmp3.so (butuh Android NDK)
#   bash native/build-native.sh armeabi-v7a -> app/src/main/jniLibs/armeabi-v7a/libytmp3.so (HP 32-bit; kedua ABI dipakai dalam satu APK)
#   bash native/build-native.sh host        -> uji di komputer Linux (hasil di $WORK/host/libytmp3.so)
# Variabel: ANDROID_NDK_HOME (atau ANDROID_HOME/ndk/<versi>), WORK (folder kerja), API (default 24).
set -euo pipefail
ABI="${1:-arm64-v8a}"
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(dirname "$HERE")"
WORK="${WORK:-${HOME:-$ROOT}/.cache/ytp-native}"   # di luar proyek: sumber FFmpeg dan hasil kompilasi dipakai ulang antarversi
API="${API:-24}"
FFMPEG_REPO=https://github.com/FFmpeg/FFmpeg.git
FFMPEG_COMMIT=ce9c7b53714b64a1b1d5d6c9765d95cf070c9ca1   # release/6.1
OUT="$ROOT/app/src/main/jniLibs/$ABI/libytmp3.so"
[ "$ABI" = host ] && OUT="$WORK/host/libytmp3.so"
if [ "$ABI" != host ] && [ -s "$OUT" ] && [ -z "${FORCE:-}" ]; then echo "sudah ada: $OUT"; exit 0; fi

JOBS="$(nproc 2>/dev/null || echo 2)"
mkdir -p "$WORK/$ABI" "$(dirname "$OUT")"
B="$WORK/$ABI"; PFX="$B/prefix"; mkdir -p "$PFX/include/lame" "$PFX/lib"

if [ "$ABI" = host ]; then
  CC=${CC:-gcc}; AR=ar; RANLIB=ranlib; STRIP=strip
  JH="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(which javac)")")")}"
  JNI_INC="-I$JH/include -I$JH/include/linux"
  CFG_CROSS=(); LDX="-lm -lpthread"
else
  case "$ABI" in
    arm64-v8a)   TRIPLE=aarch64-linux-android;   FARCH=aarch64; XCFG=(); XCF="" ;;
    armeabi-v7a) TRIPLE=armv7a-linux-androideabi; FARCH=arm
                 XCFG=(--cpu=armv7-a --disable-asm); XCF="-march=armv7-a -mfpu=neon -mfloat-abi=softfp" ;;
    *) echo "ABI tidak didukung: $ABI"; exit 1 ;;
  esac
  NDK="${ANDROID_NDK_HOME:-}"
  [ -z "$NDK" ] && NDK="$(ls -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"/ndk/* 2>/dev/null | sort -V | tail -1)"
  [ -d "$NDK" ] || { echo "Android NDK tidak ditemukan (set ANDROID_NDK_HOME)"; exit 1; }
  PRE="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
  TC="$PRE/bin"
  T="$WORK/uji-kompiler"; mkdir -p "$T"; echo "int main(void){return 0;}" > "$T/t.c"; rm -f "$T/t.o"
  "$TC/$TRIPLE$API-clang" -c "$T/t.c" -o "$T/t.o" >/dev/null 2>&1 || true
  if [ -s "$T/t.o" ]; then
    # Cara biasa (GitHub Actions / PC): kompiler bawaan NDK
    CC="$TC/$TRIPLE$API-clang $XCF"; AR="$TC/llvm-ar"; RANLIB="$TC/llvm-ranlib"; STRIP="$TC/llvm-strip"; NM="$TC/llvm-nm"
  else
    # Biner kompiler NDK tidak bisa jalan (misal NDK di HP, "unexpected e_type: 2"):
    # pakai clang/lld/llvm-* milik Termux, dengan header dan pustaka dari sysroot NDK.
    command -v clang >/dev/null && command -v ld.lld >/dev/null && command -v llvm-ar >/dev/null \
      || { echo "Kompiler NDK tak bisa jalan. Jalankan: pkg install clang lld llvm"; exit 1; }
    SYS="$PRE/sysroot"; [ -d "$SYS" ] || { echo "sysroot NDK tidak ditemukan: $SYS"; exit 1; }
    RES="$(ls -d "$PRE"/lib/clang/* 2>/dev/null | sort -V | tail -1)"
    echo "Memakai clang Termux dengan sysroot NDK ($SYS)"
    CC="clang --target=$TRIPLE$API --sysroot=$SYS -fuse-ld=lld -no-canonical-prefixes ${RES:+-resource-dir=$RES} $XCF"
    AR=llvm-ar; RANLIB=llvm-ranlib; STRIP=llvm-strip; NM=llvm-nm
  fi
  JNI_INC=""
  CFG_CROSS=(--enable-cross-compile --target-os=android --arch=$FARCH "${XCFG[@]}" --cc="$CC" --ar="$AR" --ranlib="$RANLIB" --strip="$STRIP" --nm="$NM")
  LDX="-lm -llog"
fi

# 1. LAME (hanya encoder), statis
L="$HERE/lame"
mkdir -p "$B/lame" "$B/lamecfg"
cp "$L/config.h" "$B/lamecfg/config.h"
if [ "$ABI" = armeabi-v7a ]; then  # 32-bit: long = 4 byte, long double = 8 byte
  sed -i 's/#define SIZEOF_LONG 8/#define SIZEOF_LONG 4/; s/#define SIZEOF_LONG_DOUBLE 16/#define SIZEOF_LONG_DOUBLE 8/; s/#define SIZEOF_UNSIGNED_LONG 8/#define SIZEOF_UNSIGNED_LONG 4/' "$B/lamecfg/config.h"
fi
for f in VbrTag bitstream encoder fft gain_analysis id3tag lame newmdct presets psymodel quantize quantize_pvt reservoir set_get tables takehiro util vbrquantize version; do
  $CC -c -O2 -fPIC -w -DHAVE_CONFIG_H -I"$B/lamecfg" -I"$L" -I"$L/include" -I"$L/libmp3lame" "$L/libmp3lame/$f.c" -o "$B/lame/$f.o"
done
rm -f "$PFX/lib/libmp3lame.a"; $AR rcs "$PFX/lib/libmp3lame.a" "$B"/lame/*.o; $RANLIB "$PFX/lib/libmp3lame.a"
cp "$L/include/lame.h" "$PFX/include/lame/lame.h"

# 2. FFmpeg ramping
SRC="$WORK/ffmpeg-src"
if [ ! -f "$SRC/configure" ]; then
  rm -rf "$SRC"; git init -q "$SRC"
  git -C "$SRC" fetch -q --depth 1 "$FFMPEG_REPO" "$FFMPEG_COMMIT"
  git -C "$SRC" checkout -q FETCH_HEAD
fi
mkdir -p "$B/ff" && cd "$B/ff"
"$SRC/configure" --prefix="$PFX" "${CFG_CROSS[@]}" \
  --disable-everything --disable-programs --disable-doc --disable-debug --disable-network \
  --disable-autodetect --disable-avdevice --disable-avfilter --disable-swscale \
  --enable-small --enable-static --disable-shared --enable-pic --enable-libmp3lame \
  --enable-decoder=aac,opus,vorbis --enable-parser=aac,opus,vorbis \
  --enable-demuxer=mov,matroska,ogg --enable-encoder=libmp3lame --enable-muxer=mp3 \
  --enable-protocol=file --extra-cflags="-Os -I$PFX/include" --extra-ldflags="-L$PFX/lib"
make -j"$JOBS" >/dev/null
make install >/dev/null

# 3. Satukan jadi libytmp3.so (hanya simbol JNI yang diekspor, kode tak terpakai dibuang)
$CC -shared -fPIC -Os -ffunction-sections -fdata-sections -I"$PFX/include" $JNI_INC \
  "$HERE/ytmp3.c" -o "$OUT" \
  -Wl,--start-group "$PFX/lib/libavformat.a" "$PFX/lib/libavcodec.a" "$PFX/lib/libswresample.a" \
  "$PFX/lib/libavutil.a" "$PFX/lib/libmp3lame.a" -Wl,--end-group \
  -Wl,--gc-sections -Wl,--exclude-libs,ALL -Wl,-z,max-page-size=16384 $LDX
"$STRIP" --strip-unneeded "$OUT"
ls -la "$OUT"
