#include <jni.h>
#include <stdint.h>
#include "lame.h"

#define FN(n) Java_com_novan_penghilangvokal_LameEncoder_##n

JNIEXPORT jlong JNICALL FN(nativeInit)(JNIEnv *env, jclass cls, jint rate, jint vbrQ, jint quality) {
    (void) env; (void) cls;
    lame_t g = lame_init();
    if (!g) return 0;
    lame_set_in_samplerate(g, rate);
    lame_set_out_samplerate(g, rate);
    lame_set_num_channels(g, 2);
    lame_set_mode(g, JOINT_STEREO);
    lame_set_VBR(g, vbr_mtrh);
    lame_set_VBR_q(g, vbrQ);
    lame_set_bWriteVbrTag(g, 1);
    lame_set_quality(g, quality);
    if (lame_init_params(g) < 0) {
        lame_close(g);
        return 0;
    }
    return (jlong) (intptr_t) g;
}

JNIEXPORT jint JNICALL FN(nativeEncode)(JNIEnv *env, jclass cls, jlong h, jshortArray pcm,
                                        jint frames, jbyteArray out) {
    (void) cls;
    lame_t g = (lame_t) (intptr_t) h;
    jshort *p = (*env)->GetShortArrayElements(env, pcm, NULL);
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    if (!p || !o) {
        if (p) (*env)->ReleaseShortArrayElements(env, pcm, p, JNI_ABORT);
        if (o) (*env)->ReleaseByteArrayElements(env, out, o, JNI_ABORT);
        return -100;
    }
    jsize cap = (*env)->GetArrayLength(env, out);
    int n = lame_encode_buffer_interleaved(g, (short *) p, frames, (unsigned char *) o, cap);
    (*env)->ReleaseShortArrayElements(env, pcm, p, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

JNIEXPORT jint JNICALL FN(nativeFlush)(JNIEnv *env, jclass cls, jlong h, jbyteArray out) {
    (void) cls;
    lame_t g = (lame_t) (intptr_t) h;
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    if (!o) return -100;
    jsize cap = (*env)->GetArrayLength(env, out);
    int n = lame_encode_flush(g, (unsigned char *) o, cap);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

/* Bingkai Xing/LAME penutup untuk VBR; ditulis ke awal berkas setelah nativeFlush. */
JNIEXPORT jint JNICALL FN(nativeLameTag)(JNIEnv *env, jclass cls, jlong h, jbyteArray out) {
    (void) cls;
    lame_t g = (lame_t) (intptr_t) h;
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    if (!o) return -100;
    jsize cap = (*env)->GetArrayLength(env, out);
    size_t n = lame_get_lametag_frame(g, (unsigned char *) o, (size_t) cap);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    if (n > (size_t) cap) return -1;
    return (jint) n;
}

JNIEXPORT void JNICALL FN(nativeClose)(JNIEnv *env, jclass cls, jlong h) {
    (void) env; (void) cls;
    if (h != 0) lame_close((lame_t) (intptr_t) h);
}
