package id.ytplayer

import android.net.Uri

/** Mengenali tautan video YouTube (watch, youtu.be, shorts, live, embed, music) dan menyeragamkannya. */
object YtLink {
    private val urlRe = Regex("https?://\\S+")
    private val idRe = Regex("^[A-Za-z0-9_-]{11}$")

    /** Mengembalikan tautan baku https://www.youtube.com/watch?v=ID, atau null bila tidak ada. */
    fun extract(text: String?): String? {
        if (text.isNullOrBlank()) return null
        for (m in urlRe.findAll(text)) {
            parse(m.value)?.let { return it }
        }
        return null
    }

    private fun parse(raw: String): String? {
        val u = try {
            Uri.parse(raw.trimEnd('.', ',', ')', '"', '\''))
        } catch (e: Exception) {
            return null
        }
        val host = u.host?.lowercase()?.removePrefix("www.")?.removePrefix("m.") ?: return null
        val seg = u.pathSegments
        val id: String? = when (host) {
            "youtu.be" -> seg.firstOrNull()
            "youtube.com", "music.youtube.com", "youtube-nocookie.com" -> when {
                seg.firstOrNull() == "watch" -> u.getQueryParameter("v")
                seg.size >= 2 && seg[0] in setOf("shorts", "live", "embed", "v") -> seg[1]
                else -> null
            }
            else -> null
        }
        return if (id != null && idRe.matches(id)) "https://www.youtube.com/watch?v=$id" else null
    }

    private val listRe = Regex("^[A-Za-z0-9_-]{10,64}$")

    /**
     * Mengembalikan tautan baku https://www.youtube.com/playlist?list=ID bila teks memuat tautan
     * playlist (halaman playlist, atau video yang dibuka dari dalam playlist), atau null.
     * Daftar putar otomatis "Mix" (kode RD...) dilewati karena isinya tidak tetap.
     */
    fun extractPlaylist(text: String?): String? {
        if (text.isNullOrBlank()) return null
        for (m in urlRe.findAll(text)) {
            parsePlaylist(m.value)?.let { return it }
        }
        return null
    }

    /** True bila teks berisi tautan halaman playlist (bukan tautan satu video). */
    fun isPlaylistPage(text: String?): Boolean = extract(text) == null && extractPlaylist(text) != null

    private fun parsePlaylist(raw: String): String? {
        val u = try {
            Uri.parse(raw.trimEnd('.', ',', ')', '"', '\''))
        } catch (e: Exception) {
            return null
        }
        val host = u.host?.lowercase()?.removePrefix("www.")?.removePrefix("m.") ?: return null
        if (host != "youtube.com" && host != "music.youtube.com" && host != "youtu.be") return null
        val list = u.getQueryParameter("list") ?: return null
        if (!listRe.matches(list) || list.startsWith("RD")) return null
        val seg = u.pathSegments
        val ok = host == "youtu.be" || seg.firstOrNull() == "playlist" || seg.firstOrNull() == "watch"
        return if (ok) "https://www.youtube.com/playlist?list=$list" else null
    }
}
