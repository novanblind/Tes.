package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Mengurangi suara penyanyi asli pada lagu stereo, supaya lagu apa pun bisa jadi pengiring karaoke.
 *
 * Suara penyanyi hampir selalu ada persis di tengah (kiri sama dengan kanan). Caranya: ambil bagian tengah
 * (kiri + kanan) / 2, saring hanya pita suara manusia (sekitar 150 Hz sampai 6 kHz, penyaring orde empat di
 * tiap sisi), lalu kurangkan dari kiri dan kanan. Bass dan tendangan drum di bawah 150 Hz serta desis simbal di
 * atas 6 kHz tetap utuh, dan alat musik yang ditaruh di kiri atau kanan hanya sedikit terpengaruh. Hasilnya
 * tidak sebersih pemisah berbasis kecerdasan buatan: alat yang ikut di tengah (misalnya snare) ikut menipis dan
 * sisa gema penyanyi bisa masih terdengar tipis.
 *
 * Murni hitungan, tanpa kelas Android.
 */
object PengurangVokal {

    /** Kekuatan pengurangan (persen) untuk tiap pilihan di pengaturan: mati, sedang, kuat. */
    val KEKUATAN = intArrayOf(0, 70, 100)

    private const val BATAS_BAWAH_HZ = 150.0
    private const val BATAS_ATAS_HZ = 6_000.0

    /** Satu penyaring biquad (bentuk langsung I). */
    private class Biquad(private val b0: Double, private val b1: Double, private val b2: Double,
                         private val a1: Double, private val a2: Double) {
        private var x1 = 0.0
        private var x2 = 0.0
        private var y1 = 0.0
        private var y2 = 0.0

        fun proses(x: Double): Double {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            return y
        }
    }

    private fun lolosTinggi(sr: Int, hz: Double): Biquad {
        val w = 2.0 * PI * hz / sr
        val alfa = sin(w) / (2.0 * 0.7071)
        val c = cos(w)
        val a0 = 1.0 + alfa
        return Biquad((1.0 + c) / 2.0 / a0, -(1.0 + c) / a0, (1.0 + c) / 2.0 / a0, -2.0 * c / a0, (1.0 - alfa) / a0)
    }

    private fun lolosRendah(sr: Int, hz: Double): Biquad {
        val w = 2.0 * PI * hz / sr
        val alfa = sin(w) / (2.0 * 0.7071)
        val c = cos(w)
        val a0 = 1.0 + alfa
        return Biquad((1.0 - c) / 2.0 / a0, (1.0 - c) / a0, (1.0 - c) / 2.0 / a0, -2.0 * c / a0, (1.0 - alfa) / a0)
    }

    /**
     * Mengubah [pcm] (stereo bergantian kiri, kanan, ...) di tempat dengan kekuatan [persen] (1..100).
     * Mengembalikan false tanpa mengubah apa pun bila lagunya praktis mono (kiri sama dengan kanan di seluruh
     * lagu, jadi pengurangan akan membisukan semuanya) atau dibatalkan lewat [batal]; true bila berhasil.
     */
    fun proses(pcm: ShortArray, sr: Int, persen: Int, batal: () -> Boolean): Boolean {
        val frame = pcm.size / 2
        if (frame < sr || persen <= 0) return false

        // Cek mono: bandingkan tenaga sisi (kiri - kanan) dengan tenaga tengah pada sampel yang tersebar.
        var tengahE = 0.0
        var sisiE = 0.0
        val langkah = maxOf(1, frame / 200_000)
        var i = 0
        while (i < frame) {
            val l = pcm[i * 2].toDouble()
            val r = pcm[i * 2 + 1].toDouble()
            val m = (l + r) / 2.0
            val s = (l - r) / 2.0
            tengahE += m * m
            sisiE += s * s
            i += langkah
        }
        if (tengahE <= 0.0 || sqrt(sisiE / tengahE) < 0.02) return false

        val a = persen.coerceIn(1, 100) / 100.0

        // Penyaringan maju lalu mundur (tanpa pergeseran fase) per blok dengan tepi tambahan [TEPI] sampel supaya
        // sambungan antarblok mulus. Tanpa pergeseran fase, suara tengah benar-benar saling meniadakan; satu arah
        // saja akan menyisakan sebagian suara penyanyi karena fasenya miring.
        val blok = 65_536
        val panjang = blok + 2 * TEPI
        val tengah = DoubleArray(panjang)
        val keluar = ShortArray(pcm.size)
        var f = 0
        while (f < frame) {
            if (batal()) return false
            val akhir = minOf(frame, f + blok)
            val dari = maxOf(0, f - TEPI)
            val sampai = minOf(frame, akhir + TEPI)
            val n = sampai - dari
            for (k in 0 until n) tengah[k] = (pcm[(dari + k) * 2].toDouble() + pcm[(dari + k) * 2 + 1].toDouble()) / 2.0
            saringPita(tengah, n, sr)
            for (k in f until akhir) {
                val suara = tengah[k - dari] * a
                keluar[k * 2] = pangkas(pcm[k * 2] - suara)
                keluar[k * 2 + 1] = pangkas(pcm[k * 2 + 1] - suara)
            }
            f = akhir
        }
        System.arraycopy(keluar, 0, pcm, 0, pcm.size)
        return true
    }

    /** Sampel tambahan di tiap tepi blok untuk meredam gejala awal penyaring (sekitar 93 milidetik). */
    private const val TEPI = 4_096

    /** Menyaring [x] (n sampel) ke pita suara, maju lalu mundur, di tempat. */
    private fun saringPita(x: DoubleArray, n: Int, sr: Int) {
        for (arah in 0 until 2) {
            val hp1 = lolosTinggi(sr, BATAS_BAWAH_HZ)
            val hp2 = lolosTinggi(sr, BATAS_BAWAH_HZ)
            val lp1 = lolosRendah(sr, BATAS_ATAS_HZ)
            val lp2 = lolosRendah(sr, BATAS_ATAS_HZ)
            for (k in 0 until n) x[k] = lp2.proses(lp1.proses(hp2.proses(hp1.proses(x[k]))))
            // Balik urutan supaya putaran berikutnya berjalan mundur (dan setelah putaran kedua kembali normal).
            var i = 0
            var j = n - 1
            while (i < j) {
                val t = x[i]
                x[i] = x[j]
                x[j] = t
                i++
                j--
            }
        }
    }

    private fun pangkas(v: Double): Short =
        (if (v > 32767.0) 32767.0 else if (v < -32768.0) -32768.0 else v).toInt().toShort()
}
