package com.novan.audiolabnovan.videolab;

import android.graphics.Bitmap;
import android.graphics.Color;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlaySettings;

/** Memudarkan gambar ke warna polos (misalnya putih) di awal dan akhir klip. */
@UnstableApi
public final class FadeColorOverlay extends BitmapOverlay {
    private static final OverlaySettings HIDDEN =
            new OverlaySettings.Builder().setAlphaScale(0f).build();

    private final Bitmap bitmap;
    private final long totalUs, inUs, outUs;

    public FadeColorOverlay(int color, long totalUs, long inUs, long outUs) {
        Bitmap b = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
        b.eraseColor(color == 0 ? Color.WHITE : color);
        this.bitmap = b;
        this.totalUs = totalUs;
        this.inUs = inUs;
        this.outUs = outUs;
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        return bitmap;
    }

    @Override
    public OverlaySettings getOverlaySettings(long t) {
        float g = 1f;
        if (inUs > 0 && t < inUs) g = Math.max(0f, t / (float) inUs);
        long left = totalUs - t;
        if (outUs > 0 && left < outUs) g = Math.min(g, Math.max(0f, left / (float) outUs));
        float alpha = 1f - g;
        if (alpha <= 0.001f) return HIDDEN;
        return new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(0f, 0f)
                .setOverlayFrameAnchor(0f, 0f)
                .setScale(8f, 8f)
                .setAlphaScale(alpha)
                .build();
    }
}
