package com.novan.filemanagermax

import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** Dipakai aplikasi lain untuk memilih berkas (GET_CONTENT, OPEN_DOCUMENT, PICK). */
class PickerActivity : AppCompatActivity() {

    private val launcher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) {
                val uri = Util.uriOf(this, File(p))
                val data = Intent().apply {
                    setData(uri)
                    clipData = ClipData.newRawUri("", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                setResult(RESULT_OK, data)
            } else {
                setResult(RESULT_CANCELED)
            }
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Access.hasAccess(this)) {
            Toast.makeText(this, R.string.permission_needed, Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED)
            finish()
            return
        }
        if (savedInstanceState == null) {
            launcher.launch(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.pick_file_title))
                    .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FILE)
            )
        }
    }
}
