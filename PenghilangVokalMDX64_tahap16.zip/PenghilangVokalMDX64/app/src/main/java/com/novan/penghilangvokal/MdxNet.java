package com.novan.penghilangvokal;

/**
 * Pemisah musik dengan model MDX-Net (UVR-MDX-NET-Inst_HQ_3). Masukan: PCM stereo 44100 Hz
 * (interleaved). Keluaran: musik tanpa vokal (instrumental), panjang sama.
 *
 * Alur tiap potongan (sama dengan UVR): STFT (n_fft 6144, hop 1024) -> model (masukan 1x4x3072x256)
 * -> iSTFT, lalu 3072 sampel di tiap ujung dibuang dan potongan disambung berurutan.
 */
final class MdxNet {

    /** Mesin inferensi; satu panggilan = satu potongan spektrogram. */
    interface Motor {
        void jalankan(float[] masuk, float[] keluar) throws Exception;
    }

    interface Cek {
        void cek() throws java.io.IOException;
    }

    /** Penguat keluaran instrumental (nilai "compensate" milik UVR untuk model Inst HQ). */
    static final float KOMPENSASI = 1.035f;

    private final Motor motor;
    private final MdxDsp dsp = new MdxDsp();
    private final float[] spec = new float[4 * MdxDsp.DIM_F * MdxDsp.DIM_T];
    private final float[] keluar = new float[4 * MdxDsp.DIM_F * MdxDsp.DIM_T];
    private final float[] l = new float[MdxDsp.CHUNK];
    private final float[] r = new float[MdxDsp.CHUNK];

    MdxNet(Motor motor) {
        this.motor = motor;
    }

    /** @param x PCM stereo interleaved sepanjang n frame; @return instrumental sepanjang n frame */
    float[] pisah(float[] x, int n, Cek cek) throws Exception {
        final float[] res = new float[n * 2];
        final int gen = MdxDsp.GEN;
        final int jumlah = (n + gen - 1) / gen;
        for (int c = 0; c < jumlah; c++) {
            if (cek != null) cek.cek();
            final int mulai = c * gen - MdxDsp.TRIM;
            for (int i = 0; i < MdxDsp.CHUNK; i++) {
                int p = mulai + i;
                if (p >= 0 && p < n) {
                    l[i] = x[p * 2];
                    r[i] = x[p * 2 + 1];
                } else {
                    l[i] = 0f;
                    r[i] = 0f;
                }
            }
            dsp.stft(l, r, spec);
            motor.jalankan(spec, keluar);
            dsp.istft(keluar, l, r);
            for (int j = 0; j < gen; j++) {
                int p = c * gen + j;
                if (p >= n) break;
                res[p * 2] = l[MdxDsp.TRIM + j] * KOMPENSASI;
                res[p * 2 + 1] = r[MdxDsp.TRIM + j] * KOMPENSASI;
            }
        }
        return res;
    }
}
