package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.view.ViewCompat
import id.ytplayer.music.NovanEngineActivity
import id.ytplayer.music.Prefs

/**
 * Satu halaman pengaturan untuk YT Player dan YouTube Music (keduanya memakai pemutar dan pengaturan yang
 * sama), termasuk jalan masuk ke Mesin audio Novan, dan jalan masuk ke pengaturan Music Player.
 */
class AppSettingsActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnAudioQ: Button
    private lateinit var btnSeekBack: Button
    private lateinit var btnSeekFwd: Button
    private lateinit var btnPrevSec: Button
    private lateinit var btnAudioOnly: Button
    private lateinit var btnAudioFocus: Button
    private lateinit var btnLoudness: Button
    private lateinit var btnNovan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_settings)
        ViewCompat.setAccessibilityHeading(findViewById(R.id.setTitle), true)
        status = findViewById(R.id.setStatus)
        btnAudioQ = findViewById(R.id.setAudioQ)
        btnSeekBack = findViewById(R.id.setSeekBack)
        btnSeekFwd = findViewById(R.id.setSeekFwd)
        btnPrevSec = findViewById(R.id.setPrevSec)
        btnAudioOnly = findViewById(R.id.setAudioOnly)
        btnAudioFocus = findViewById(R.id.setAudioFocus)
        btnLoudness = findViewById(R.id.setLoudness)
        btnNovan = findViewById(R.id.setNovan)
        val btnMusic = findViewById<Button>(R.id.setMusic)
        btnMusic.text = "Pengaturan Music Player"
        findViewById<Button>(R.id.setClose).apply {
            text = "Kembali"
            setOnClickListener { finish() }
        }

        btnAudioQ.setOnClickListener { chooseAudioQ() }
        btnSeekBack.setOnClickListener { chooseSeek(true) }
        btnSeekFwd.setOnClickListener { chooseSeek(false) }
        btnPrevSec.setOnClickListener { choosePrevSec() }
        btnAudioOnly.setOnClickListener {
            Store.setAudioOnly(this, !Store.audioOnly(this))
            refresh()
            status.text = btnAudioOnly.text
        }
        btnAudioFocus.setOnClickListener {
            Store.setAudioFocus(this, !Store.audioFocus(this))
            refresh()
            status.text = btnAudioFocus.text.toString() + if (Store.audioFocus(this))
                ". Pemutaran dijeda saat aplikasi lain bersuara." else ". Pemutaran jalan terus bersama suara aplikasi lain."
        }
        btnLoudness.setOnClickListener {
            Store.setLoudness(this, !Store.loudness(this))
            refresh()
            status.text = btnLoudness.text.toString() + if (Store.loudness(this))
                ". Suara diperkuat dan dirata-ratakan agar lebih jelas." else ". Suara apa adanya."
        }
        // Mesin audio Novan: satu pengaturan yang sama untuk YT Player, YouTube Music, dan Music Player.
        btnNovan.setOnClickListener {
            startActivity(Intent(this, NovanEngineActivity::class.java))
        }
        btnMusic.setOnClickListener {
            startActivity(Intent(this, id.ytplayer.music.SettingsActivity::class.java))
        }
        status.text = "Pengaturan di halaman ini berlaku sama untuk YT Player dan YouTube Music. Pengaturan Music Player ada di tombol paling bawah."
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh() // status Mesin audio Novan bisa berubah di layarnya sendiri
    }

    private fun audioQName(level: Int) = when (level) {
        Store.AUDIO_HEMAT -> "Hemat"
        Store.AUDIO_TERBAIK -> "Terbaik"
        else -> "Normal"
    }

    private fun refresh() {
        btnAudioQ.text = "Kualitas audio pemutaran: ${audioQName(Store.audioQuality(this))}"
        btnSeekBack.text = "Lompat mundur: ${Store.seekBackSec(this)} detik"
        btnSeekFwd.text = "Lompat maju: ${Store.seekFwdSec(this)} detik"
        btnPrevSec.text = "Tombol sebelumnya mengulang setelah: ${Prefs.prevRestartSec(this)} detik"
        btnAudioOnly.text = "Mode audio saja: " + if (Store.audioOnly(this)) "hidup" else "mati"
        btnAudioFocus.text = "Fokus suara YT Player dan YouTube Music: " + if (Store.audioFocus(this)) "hidup" else "mati"
        btnLoudness.text = "Volume stabil: " + if (Store.loudness(this)) "hidup" else "mati"
        val novanOn = Prefs.of(this).getBoolean(id.ytplayer.music.NovanEngine.K_ON, false)
        btnNovan.text = "Mesin audio Novan: " + (if (novanOn) "menyala" else "mati") + ". Buka"
        btnNovan.contentDescription = "Mesin audio Novan, pemrosesan suara 64-bit untuk YT Player, YouTube Music, dan Music Player. " +
            "Sekarang " + (if (novanOn) "menyala" else "mati") + ". Buka pengaturannya"
        // Kualitas audio hanya tampil saat mode audio saja aktif.
        btnAudioQ.visibility = if (Store.audioOnly(this)) View.VISIBLE else View.GONE
    }

    private fun chooseAudioQ() {
        val labels = arrayOf("Hemat", "Normal", "Terbaik")
        AlertDialog.Builder(this)
            .setTitle("Kualitas audio (mode audio saja)")
            .setSingleChoiceItems(labels, Store.audioQuality(this)) { d, which ->
                Store.setAudioQuality(this, which)
                refresh()
                status.text = "Kualitas audio: ${audioQName(which)}. Berlaku di mode audio saja."
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Batas waktu tombol "sebelumnya"; pengaturan yang sama dipakai Music Player dan YouTube Music. */
    private fun choosePrevSec() {
        val choices = Prefs.PREV_RESTART_CHOICES
        AlertDialog.Builder(this)
            .setTitle("Tombol sebelumnya mengulang setelah")
            .setSingleChoiceItems(
                choices.map { "$it detik" }.toTypedArray(),
                choices.indexOf(Prefs.prevRestartSec(this)).coerceAtLeast(0)
            ) { d, which ->
                Prefs.setPrevRestartSec(this, choices[which])
                refresh()
                status.text = "Sebelumnya: lewat ${choices[which]} detik, lagu diulang dari awal; sebelum itu pindah ke item sebelumnya."
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun chooseSeek(back: Boolean) {
        val choices = Store.SEEK_CHOICES
        val cur = if (back) Store.seekBackSec(this) else Store.seekFwdSec(this)
        AlertDialog.Builder(this)
            .setTitle(if (back) "Lompat mundur" else "Lompat maju")
            .setSingleChoiceItems(choices.map { "$it detik" }.toTypedArray(), choices.indexOf(cur).coerceAtLeast(0)) { d, which ->
                if (back) Store.setSeekBackSec(this, choices[which]) else Store.setSeekFwdSec(this, choices[which])
                refresh()
                status.text = (if (back) "Mundur " else "Maju ") + "${choices[which]} detik"
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
