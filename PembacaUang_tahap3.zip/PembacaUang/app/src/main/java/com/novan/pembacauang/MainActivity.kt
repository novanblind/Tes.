package com.novan.pembacauang

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.SurfaceHolder
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.novan.pembacauang.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recognizer: MoneyRecognizer
    private lateinit var cameraSource: CameraSource
    private val gate = SpeechGate()

    private var surfaceReady = false
    private var permissionRequested = false
    private var permissionDenied = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionRequested = false
            if (granted) {
                startCameraSafe()
            } else {
                permissionDenied = true
                Speaker.say(
                    this,
                    "Izin kamera diperlukan agar aplikasi bisa membaca uang. " +
                        "Aktifkan izin kamera di pengaturan aplikasi.",
                    Toast.LENGTH_LONG,
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vibrate()

        // Siapkan mesin suara sejak aplikasi dibuka, tidak menunggu nominal pertama.
        Speaker.init(this)

        // Peringatan senter, sama seperti aplikasi acuan (berdasarkan fitur perangkat).
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            Toast.makeText(this, "Perangkat ini tidak mendukung LED Flash", Toast.LENGTH_SHORT).show()
        }

        recognizer = MoneyRecognizer()
        cameraSource = CameraSource(this) { data, w, h, rotation, release ->
            recognizer.process(
                data, w, h, rotation,
                onText = { text -> onOcrText(text) },
                onDone = release,
            )
        }
        binding.surfaceView.holder.addCallback(this)

        // Tombol kembali: ucapkan terima kasih, getar sebentar, lalu keluar.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Speaker.say(this@MainActivity, "Terima kasih")
                vibrate()
                finish()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        Beeper.start(this)
        startCameraSafe()
        Speaker.setAnnounceView(window.decorView)
        if (!hasCameraPermission() && !permissionRequested && !permissionDenied) {
            // Jeda singkat agar layar tampil lebih dulu sebelum dialog izin (300 ms).
            window.decorView.postDelayed({ askCameraPermission() }, 300)
        }
    }

    override fun onPause() {
        super.onPause()
        Beeper.stop()
    }

    // Kamera dihentikan oleh surfaceDestroyed, seperti aplikasi acuan.
    override fun onDestroy() {
        recognizer.close()
        super.onDestroy()
    }

    // ---- SurfaceHolder.Callback -------------------------------------------

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        if (hasCameraPermission()) startCameraSafe() else askCameraPermission()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        cameraSource.stop()
    }

    // ---- Izin & kamera ----------------------------------------------------

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun askCameraPermission() {
        if (!permissionRequested && !permissionDenied && !hasCameraPermission()) {
            permissionRequested = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCameraSafe() {
        if (!surfaceReady || !hasCameraPermission() || cameraSource.isStarted) return
        try {
            cameraSource.start(binding.surfaceView.holder)
        } catch (_: Exception) {
        }
    }

    // ---- Hasil OCR -> nominal -> suara ------------------------------------

    private fun onOcrText(text: String) {
        val denom = CurrencyParser.parse(text) ?: return
        if (!gate.shouldSpeak(denom.value)) return
        Speaker.sayNominal(this, denom.spoken)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long = 60) {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (v == null || !v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(ms)
        }
    }
}
