package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pengaturan rantai pengolah vokal ala aplikasi karaoke.
 * [dengungHz] = batas bawah penyaring dengung dalam Hz; 0 berarti mati.
 * [gerbangDb] = ambang gerbang desis dalam dB (negatif); 0 berarti mati.
 * [nadaSemiton] = pergeseran nada dalam semiton (negatif turun, positif naik); 0 berarti mati.
 * [kompresor] = kekuatan kompresor 0 (mati) sampai 3 (kuat).
 * [pembatas] = pembatas puncak di ujung rantai (setelah echo dan gema).
 * [deEsser] = kekuatan penghilang desis huruf "s" dan "sy" 0 (mati) sampai 3 (kuat); berjalan setelah kompresor.
 */
class KonfigVokal(
    val dengungHz: Int,
    val gerbangDb: Int,
    val nadaSemiton: Int,
    val kompresor: Int,
    val pembatas: Boolean,
    val deEsser: Int = 0
) {
    /** Ada tahap yang berjalan sebelum echo dan gema? */
    val awalAktif: Boolean get() = dengungHz > 0 || gerbangDb < 0 || nadaSemiton != 0 || kompresor > 0 || deEsser > 0
    val aktif: Boolean get() = awalAktif || pembatas

    companion object {
        val MATI = KonfigVokal(0, 0, 0, 0, false)

        /** Rantai rapikan vokal untuk studio karaoke: dengung 70 Hz, gerbang peka, kompresor sedang, desis sedang, pembatas. */
        val KARAOKE = KonfigVokal(70, -52, 0, 2, true, 2)
    }
}

/**
 * Tahap vokal sebelum echo dan gema, berurutan: penyaring dengung, gerbang desis, penyetel nada, kompresor.
 * (Pembatas ada di kelas [Pembatas] karena harus berada paling akhir, setelah echo dan gema ditambahkan.)
 *
 * Murni hitungan, tanpa kelas Android, dan hanya dipakai satu utas. Sampel PCM 16 bit bergantian antar saluran.
 * Penyetel nada memakai dua kepala baca bertunda dengan peralihan halus; jedanya rata-rata sekitar 15 milidetik,
 * dan hanya ada bila nada digeser.
 */
class PengolahVokal(private val sr: Int, private val kanal: Int, private val k: KonfigVokal) {

    // ---------- Penyaring dengung: lolos-tinggi Butterworth orde dua ----------
    private val pakaiDengung = k.dengungHz > 0
    private var hb0 = 0.0
    private var hb1 = 0.0
    private var hb2 = 0.0
    private var ha1 = 0.0
    private var ha2 = 0.0
    private val hx1 = DoubleArray(kanal)
    private val hx2 = DoubleArray(kanal)
    private val hy1 = DoubleArray(kanal)
    private val hy2 = DoubleArray(kanal)

    // ---------- Gerbang desis ----------
    private val pakaiGerbang = k.gerbangDb < 0
    private val ambang = 10.0.pow(k.gerbangDb / 20.0)
    private val aNaik = exp(-1.0 / (0.002 * sr))
    private val aTurun = exp(-1.0 / (0.05 * sr))
    private val aBuka = 1.0 - exp(-1.0 / (0.003 * sr))
    private val aTutup = 1.0 - exp(-1.0 / (0.12 * sr))
    private val tahanMaks = (0.08 * sr).roundToInt()
    private val lantai = 0.07 // sekitar minus 23 dB: desis dikecilkan, bukan dihilangkan mendadak
    private var env = 0.0
    private var tahan = 0
    private var gGerbang = 1.0

    // ---------- Penyetel nada ----------
    private val nada: PenggeserNada? = if (k.nadaSemiton != 0) PenggeserNada(sr, kanal, k.nadaSemiton) else null

    // ---------- Kompresor ----------
    private val pakaiKompresor = k.kompresor > 0
    private val kompAmbangDb: Double
    private val kompRasio: Double
    private val kompMakeupDb: Double
    private val kNaik = exp(-1.0 / (0.01 * sr))
    private val kTurun = exp(-1.0 / (0.2 * sr))
    private var kEnv = 0.0

    // ---------- Penghilang desis (de-esser) ----------
    // Pita desis (di atas sekitar 5,5 kHz) dipisah dengan lolos-tinggi; bila tenaganya melewati ambang, hanya pita itu
    // yang dikecilkan, jadi bagian suara lainnya tidak ikut redup. Dilewati bila laju sampel terlalu rendah.
    private val pakaiDeEsser = k.deEsser > 0 && sr >= 16_000
    private val deAmbang: Double
    private val deLantai: Double
    private var db0 = 0.0
    private var db1 = 0.0
    private var db2 = 0.0
    private var da1 = 0.0
    private var da2 = 0.0
    private val dx1 = DoubleArray(kanal)
    private val dx2 = DoubleArray(kanal)
    private val dy1 = DoubleArray(kanal)
    private val dy2 = DoubleArray(kanal)
    private val deNaik = exp(-1.0 / (0.001 * sr))
    private val deTurun = exp(-1.0 / (0.03 * sr))
    private var deEnv = 0.0
    private var deGain = 1.0
    private val sib = DoubleArray(kanal)

    private val fr = DoubleArray(kanal)

    init {
        when (k.deEsser) {
            1 -> { deAmbang = 0.06; deLantai = 0.5 }
            2 -> { deAmbang = 0.04; deLantai = 0.35 }
            else -> { deAmbang = 0.025; deLantai = 0.25 }
        }
        if (pakaiDeEsser) {
            val w = 2.0 * PI * minOf(5_500.0, sr * 0.35) / sr
            val c = cos(w)
            val alfa = sin(w) / (2.0 * 0.7071)
            val a0 = 1.0 + alfa
            db0 = (1.0 + c) / 2.0 / a0
            db1 = -(1.0 + c) / a0
            db2 = db0
            da1 = -2.0 * c / a0
            da2 = (1.0 - alfa) / a0
        }
        if (pakaiDengung) {
            val w = 2.0 * PI * k.dengungHz / sr
            val c = cos(w)
            val alfa = sin(w) / (2.0 * 0.7071)
            val a0 = 1.0 + alfa
            hb0 = (1.0 + c) / 2.0 / a0
            hb1 = -(1.0 + c) / a0
            hb2 = hb0
            ha1 = -2.0 * c / a0
            ha2 = (1.0 - alfa) / a0
        }
        when (k.kompresor) {
            1 -> { kompAmbangDb = -18.0; kompRasio = 2.0 }
            2 -> { kompAmbangDb = -22.0; kompRasio = 3.0 }
            else -> { kompAmbangDb = -26.0; kompRasio = 4.0 }
        }
        // Penguatan susulan sebagian saja, supaya suara tidak naik terlalu keras dan desis ikut terangkat.
        kompMakeupDb = -kompAmbangDb * (1.0 - 1.0 / kompRasio) * 0.4
    }

    /** Membuang sisa keadaan (dipanggil saat rekaman dijeda). */
    fun kosongkan() {
        hx1.fill(0.0); hx2.fill(0.0); hy1.fill(0.0); hy2.fill(0.0)
        env = 0.0
        tahan = 0
        gGerbang = 1.0
        kEnv = 0.0
        dx1.fill(0.0); dx2.fill(0.0); dy1.fill(0.0); dy2.fill(0.0)
        deEnv = 0.0
        deGain = 1.0
        nada?.kosongkan()
    }

    /** Memproses [n] nilai sampel (bergantian antar saluran) di tempat. */
    fun proses(b: ShortArray, n: Int) {
        val bingkai = n / kanal
        var p = 0
        for (f in 0 until bingkai) {
            var puncak = 0.0
            for (c in 0 until kanal) {
                var x = b[p + c] / 32_768.0
                if (pakaiDengung) {
                    val y = hb0 * x + hb1 * hx1[c] + hb2 * hx2[c] - ha1 * hy1[c] - ha2 * hy2[c]
                    hx2[c] = hx1[c]; hx1[c] = x
                    hy2[c] = hy1[c]; hy1[c] = y
                    x = y
                }
                fr[c] = x
                val a = if (x < 0) -x else x
                if (a > puncak) puncak = a
            }

            if (pakaiGerbang) {
                env = if (puncak > env) puncak + aNaik * (env - puncak) else puncak + aTurun * (env - puncak)
                val sasaran: Double
                if (env > ambang) {
                    tahan = tahanMaks
                    sasaran = 1.0
                } else if (tahan > 0) {
                    tahan--
                    sasaran = 1.0
                } else {
                    sasaran = lantai
                }
                gGerbang += (sasaran - gGerbang) * (if (sasaran > gGerbang) aBuka else aTutup)
                for (c in 0 until kanal) fr[c] *= gGerbang
            }

            nada?.proses(fr)

            if (pakaiKompresor) {
                var pk = 0.0
                for (c in 0 until kanal) {
                    val a = if (fr[c] < 0) -fr[c] else fr[c]
                    if (a > pk) pk = a
                }
                kEnv = if (pk > kEnv) pk + kNaik * (kEnv - pk) else pk + kTurun * (kEnv - pk)
                val db = 20.0 * log10(max(kEnv, 1e-6))
                val lebih = db - kompAmbangDb
                val kurang = if (lebih > 0) lebih * (1.0 - 1.0 / kompRasio) else 0.0
                val g = 10.0.pow((kompMakeupDb - kurang) / 20.0)
                for (c in 0 until kanal) fr[c] *= g
            }

            if (pakaiDeEsser) {
                var pd = 0.0
                for (c in 0 until kanal) {
                    val x = fr[c]
                    val y = db0 * x + db1 * dx1[c] + db2 * dx2[c] - da1 * dy1[c] - da2 * dy2[c]
                    dx2[c] = dx1[c]; dx1[c] = x
                    dy2[c] = dy1[c]; dy1[c] = y
                    sib[c] = y
                    val a = if (y < 0) -y else y
                    if (a > pd) pd = a
                }
                deEnv = if (pd > deEnv) pd + deNaik * (deEnv - pd) else pd + deTurun * (deEnv - pd)
                val sasaranDe = if (deEnv > deAmbang) max(deLantai, deAmbang / deEnv) else 1.0
                deGain += (sasaranDe - deGain) * (if (sasaranDe < deGain) 0.3 else 0.01)
                // Hanya pita desis yang dikurangi: hasil = suara asli dikurangi bagian desis yang dikecilkan.
                for (c in 0 until kanal) fr[c] -= sib[c] * (1.0 - deGain)
            }

            for (c in 0 until kanal) b[p + c] = batasiLembut(fr[c] * 32_768.0)
            p += kanal
        }
    }
}

/**
 * Penyetel nada tanpa mengubah kecepatan: sampel masuk ditulis ke penyangga melingkar, lalu dibaca oleh dua kepala
 * yang bergerak dengan laju 2^(semiton/12) dibanding penulisan. Tiap kepala diredam di tepi jendelanya (bentuk
 * Hann) dan keduanya berjarak setengah jendela, jadi jumlah bobotnya selalu satu dan tidak ada klik.
 */
internal class PenggeserNada(sr: Int, private val kanal: Int, semiton: Int) {
    private val lebar = max(64, (sr * 0.03).roundToInt()).toDouble()
    private val ukuran = lebar.toInt() * 2 + 4
    private val buf = Array(kanal) { DoubleArray(ukuran) }
    private var tulis = 0
    private var d1 = 0.0
    private val langkah = 1.0 - 2.0.pow(semiton / 12.0)

    fun kosongkan() {
        for (b in buf) b.fill(0.0)
        tulis = 0
        d1 = 0.0
    }

    /** [fr] berisi satu bingkai (satu nilai per saluran); hasilnya ditulis kembali ke larik yang sama. */
    fun proses(fr: DoubleArray) {
        for (c in 0 until kanal) buf[c][tulis] = fr[c]
        var d2 = d1 + lebar / 2.0
        if (d2 >= lebar) d2 -= lebar
        val g1 = 0.5 * (1.0 - cos(2.0 * PI * d1 / lebar))
        val g2 = 0.5 * (1.0 - cos(2.0 * PI * d2 / lebar))
        for (c in 0 until kanal) fr[c] = baca(buf[c], d1) * g1 + baca(buf[c], d2) * g2
        tulis = if (tulis + 1 == ukuran) 0 else tulis + 1
        d1 += langkah
        if (d1 >= lebar) d1 -= lebar else if (d1 < 0) d1 += lebar
    }

    private fun baca(b: DoubleArray, d: Double): Double {
        var pos = tulis - d
        if (pos < 0) pos += ukuran
        val i0 = floor(pos).toInt()
        val t = pos - i0
        val a = b[if (i0 >= ukuran) i0 - ukuran else i0]
        val i1 = if (i0 + 1 >= ukuran) i0 + 1 - ukuran else i0 + 1
        return a * (1.0 - t) + b[i1] * t
    }
}

/**
 * Pembatas puncak di ujung rantai: puncak yang melewati langit-langit langsung ditekan (tanpa menunggu), lalu
 * penguatan kembali pelan-pelan. Langit-langitnya sengaja di bawah titik mulai [batasiLembut], jadi hasilnya
 * tidak pernah terpotong atau pecah, termasuk setelah echo dan gema menambah puncak.
 */
class Pembatas(sr: Int, private val kanal: Int) {
    private val langit = 21_500.0
    private val aPulih = 1.0 - exp(-1.0 / (0.08 * sr))
    private var g = 1.0

    fun kosongkan() {
        g = 1.0
    }

    /** Memproses [n] nilai sampel (bergantian antar saluran) di tempat. */
    fun proses(b: ShortArray, n: Int) {
        val bingkai = n / kanal
        var p = 0
        for (f in 0 until bingkai) {
            var puncak = 0.0
            for (c in 0 until kanal) {
                val a = Math.abs(b[p + c].toDouble())
                if (a > puncak) puncak = a
            }
            val sasaran = if (puncak * g > langit) langit / puncak else 1.0
            if (sasaran < g) g = sasaran else g += (1.0 - g) * aPulih
            if (g < 1.0) {
                for (c in 0 until kanal) b[p + c] = batasiLembut(b[p + c] * g)
            }
            p += kanal
        }
    }
}
