package com.novan.githubbynovan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Membuat rilis GitHub (Releases) lalu mengunggah satu berkas (biasanya APK) sebagai aset rilis.
 * Berjalan sebagai layanan latar depan dengan notifikasi kemajuan dan tombol Batalkan, jadi unggahan besar
 * (batas GitHub 2 GB per berkas) tetap jalan walaupun pengguna pindah aplikasi atau layar mati.
 * Berkas dikirim langsung dari HP ke uploads.github.com tanpa disalin ke memori (streaming).
 * Bila rilis dengan tag yang sama sudah ada, rilis itu dipakai dan aset bernama sama diganti.
 */
public class RilisService extends Service {

    /** Hasil akhir, menunggu ditampilkan di layar repo. */
    public static class Hasil {
        public boolean ok, batal;
        public String pesan = "", full = "", tag = "", nama = "", urlRilis = "", urlTerbaru = "", urlTag = "";
    }

    public interface Listener {
        void onStatus(String text);   // thread utama
        void onFinished();            // thread utama
    }

    private static class Fatal extends Exception {
        Fatal(String m) { super(m); }
    }

    private static class Batal extends Exception { }

    private static final String ACTION_STOP = "com.novan.githubbynovan.STOP_RILIS";
    private static final String CH_PROGRESS = "rilis_progres";
    private static final String CH_RESULT = "rilis_hasil";
    private static final int ID_PROGRESS = 57, ID_RESULT = 58;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static volatile Listener listener;
    static volatile String lastText = "";
    static volatile boolean running;
    static volatile String repo = "";
    private static volatile boolean batalkan;
    // Pilihan pembuatan rilis baru (diabaikan bila tag sudah punya rilis).
    private static volatile boolean optPra, optDraf, optAuto, optTerbaru = true;
    private static volatile String awalan = "";
    static volatile String optTarget = "";

    public static void pilihan(boolean pra, boolean draf, boolean auto, boolean terbaru) {
        optPra = pra;
        optDraf = draf;
        optAuto = auto;
        optTerbaru = terbaru;
    }

    private static Hasil pending;

    static synchronized void setPending(Hasil h) { pending = h; }
    static synchronized Hasil takePending() { Hasil h = pending; pending = null; return h; }
    static synchronized boolean hasPending() { return pending != null; }

    private PowerManager.WakeLock lock;
    private WifiManager.WifiLock wifi;
    private Thread worker;
    private long notifTerakhir;

    public static boolean busy() { return running; }
    public static boolean untuk(String full) { return running && full != null && full.equals(repo); }

    public static boolean start(Context c, String full, String token, String tag, String judul,
                                String catatan, String nama, Uri uri) {
        List<String> n = new ArrayList<>();
        List<Uri> u = new ArrayList<>();
        n.add(nama);
        u.add(uri);
        return startBanyak(c, full, token, tag, judul, catatan, n, u);
    }

    /** Satu atau banyak berkas sekaligus ke satu rilis. */
    public static boolean startBanyak(Context c, String full, String token, String tag, String judul,
                                      String catatan, List<String> nama, List<Uri> uri) {
        if (running) return false;
        setPending(null);
        lastText = "";
        awalan = "";
        batalkan = false;
        Intent i = new Intent(c, RilisService.class)
                .putExtra("full", full).putExtra("token", token).putExtra("tag", tag)
                .putExtra("judul", judul).putExtra("catatan", catatan)
                .putExtra("namaList", nama.toArray(new String[0]));
        ClipData cd = null;
        for (Uri u : uri) {
            try { c.getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
            if (cd == null) cd = ClipData.newRawUri("berkas", u);
            else cd.addItem(new ClipData.Item(u));
        }
        i.setClipData(cd);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            running = true;
            repo = full;
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            running = false;
            repo = "";
            return false;
        }
    }

    public static void cancel(Context c) {
        batalkan = true;
        try { c.startService(new Intent(c, RilisService.class).setAction(ACTION_STOP)); }
        catch (Exception ignored) { }
    }

    public static void cancelResultNotification(Context c) {
        try { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_RESULT); }
        catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            batalkan = true;
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        final String full = intent == null ? null : intent.getStringExtra("full");
        final String token = intent == null ? null : intent.getStringExtra("token");
        final ClipData cd = intent == null ? null : intent.getClipData();
        if (full == null || token == null || cd == null || cd.getItemCount() == 0 || cd.getItemAt(0).getUri() == null) {
            running = false;
            repo = "";
            stopSelf();
            return START_NOT_STICKY;
        }
        if (worker != null && worker.isAlive()) return START_NOT_STICKY;
        final List<Uri> uris = new ArrayList<>();
        for (int k = 0; k < cd.getItemCount(); k++) if (cd.getItemAt(k).getUri() != null) uris.add(cd.getItemAt(k).getUri());
        String[] nl = intent.getStringArrayExtra("namaList");
        final List<String> namas = new ArrayList<>();
        for (int k = 0; k < uris.size(); k++) {
            String nm = nl != null && k < nl.length ? nl[k] : null;
            if (nm == null || nm.isEmpty()) {
                String ps = uris.get(k).getLastPathSegment();
                nm = ps == null ? "berkas" + (k + 1) : ps.substring(ps.lastIndexOf('/') + 1);
            }
            namas.add(nm);
        }
        final String tag = intent.getStringExtra("tag");
        final String judul = intent.getStringExtra("judul");
        final String catatan = intent.getStringExtra("catatan");
        running = true;
        repo = full;
        Notification n = progressNotification(full, "Menyiapkan rilis...", -1);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_PROGRESS, n);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (lock == null) lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "githubbynovan:rilis");
            if (!lock.isHeld()) lock.acquire(3 * 60 * 60 * 1000L);
        } catch (Exception ignored) { }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi == null && wm != null) wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "githubbynovan:rilis");
            if (wifi != null && !wifi.isHeld()) wifi.acquire();
        } catch (Exception ignored) { }
        worker = new Thread(() -> kerja(full, token, tag, judul, catatan, namas, uris), "rilis");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ---------- pekerjaan ----------

    private void status(String full, final String t, int persen) {
        lastText = t;
        long now = System.currentTimeMillis();
        if (now - notifTerakhir >= 800) {
            notifTerakhir = now;
            try {
                ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                        .notify(ID_PROGRESS, progressNotification(full, t, persen));
            } catch (Exception ignored) { }
        }
        final Listener l = listener;
        if (l != null) MAIN.post(() -> l.onStatus(t));
    }

    private void kerja(String full, String token, String tag, String judul, String catatan,
                       List<String> namas, List<Uri> uris) {
        Hasil h = new Hasil();
        h.full = full;
        h.tag = tag;
        StringBuilder nm = new StringBuilder();
        for (String n : namas) {
            if (nm.length() > 0) nm.append(", ");
            nm.append(n);
        }
        h.nama = nm.toString();
        File tmp = null;
        try {
            for (int a = 0; a < namas.size(); a++)
                for (int b = a + 1; b < namas.size(); b++)
                    if (namas.get(a).equals(namas.get(b)))
                        throw new Fatal("Ada dua berkas bernama sama (" + namas.get(a)
                                + "). Ubah nama salah satunya, atau unggah terpisah.");
            if (batalkan) throw new Batal();
            status(full, "Memeriksa rilis " + tag + "...", -1);
            JSONObject rel = ambilAtauBuat(full, token, tag, judul, catatan);
            long id = rel.getLong("id");
            h.urlRilis = rel.optString("html_url", "");
            StringBuilder terbaru = new StringBuilder(), langsung = new StringBuilder();
            long total = 0;
            int sukses = 0;
            for (int idx = 0; idx < uris.size(); idx++) {
                Uri uri = uris.get(idx);
                String nama = namas.get(idx);
                awalan = uris.size() > 1 ? "Berkas " + (idx + 1) + " dari " + uris.size() + ". " : "";
                tmp = null;
                try {
                    long size = ukuran(uri);
                    if (size <= 0) {
                        status(full, awalan + "Menyalin " + nama + " ke penyimpanan sementara...", -1);
                        tmp = salinKeCache(uri);
                        size = tmp.length();
                    }
                    if (size <= 0) throw new Fatal("Berkas " + nama + " kosong atau tidak bisa dibaca.");
                    if (batalkan) throw new Batal();
                    String url = "https://uploads.github.com/repos/" + full + "/releases/" + id + "/assets?name="
                            + URLEncoder.encode(nama, "UTF-8").replace("+", "%20");
                    JSONObject aset = null;
                    String galatSementara = "";
                    for (int k = 1; k <= 3 && aset == null; k++) {
                        if (batalkan) throw new Batal();
                        hapusAsetSama(full, token, id, nama);
                        try {
                            aset = unggah(full, token, url, uri, tmp, size, nama);
                        } catch (Fatal | Batal e) {
                            throw e;
                        } catch (IOException e) {
                            galatSementara = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                            status(full, awalan + "Koneksi terputus, mengulang (" + k + " dari 3)...", -1);
                            try { Thread.sleep(2500L * k); } catch (Exception ignored) { }
                        }
                    }
                    if (aset == null) throw new Fatal("Unggahan " + nama + " gagal setelah 3 percobaan. " + galatSementara);
                    total += size;
                    sukses++;
                    String enc = URLEncoder.encode(nama, "UTF-8").replace("+", "%20");
                    if (terbaru.length() > 0) { terbaru.append('\n'); langsung.append('\n'); }
                    terbaru.append(nama).append(": https://github.com/").append(full).append("/releases/latest/download/").append(enc);
                    langsung.append(nama).append(": https://github.com/").append(full).append("/releases/download/")
                            .append(URLEncoder.encode(tag, "UTF-8").replace("+", "%20")).append('/').append(enc);
                } finally {
                    if (tmp != null) { tmp.delete(); tmp = null; }
                }
            }
            h.ok = true;
            h.urlTerbaru = terbaru.toString();
            h.urlTag = langsung.toString();
            h.pesan = "Rilis " + tag + " berhasil. " + (sukses == 1 ? "Berkas " + h.nama + " (" + Ui.size(total) + ") terunggah."
                    : sukses + " berkas (" + Ui.size(total) + ") terunggah: " + h.nama + ".");
        } catch (Batal e) {
            h.batal = true;
            h.pesan = "Pembuatan rilis dibatalkan. Rilis dan berkas yang sudah terunggah tetap ada.";
        } catch (Throwable e) {
            h.pesan = e instanceof Fatal ? e.getMessage()
                    : "Galat tak terduga: " + e;
        } finally {
            if (tmp != null) tmp.delete();
            awalan = "";
            for (Uri u : uris) {
                try { getContentResolver().releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) { }
            }
        }
        selesai(h);
    }

    private long ukuran(Uri uri) {
        long size = -1;
        try {
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } finally { c.close(); }
            }
        } catch (Exception ignored) { }
        if (size <= 0) {
            try {
                android.content.res.AssetFileDescriptor fd = getContentResolver().openAssetFileDescriptor(uri, "r");
                if (fd != null) { size = fd.getLength(); fd.close(); }
            } catch (Exception ignored) { }
        }
        return size;
    }

    private File salinKeCache(Uri uri) throws Exception {
        File f = new File(getCacheDir(), "rilis-" + System.currentTimeMillis() + ".tmp");
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Fatal("Berkas tidak bisa dibuka.");
        OutputStream os = new FileOutputStream(f);
        try {
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) {
                if (batalkan) throw new Batal();
                os.write(b, 0, n);
            }
        } finally {
            try { in.close(); } catch (Exception ignored) { }
            try { os.close(); } catch (Exception ignored) { }
        }
        return f;
    }

    private JSONObject ambilAtauBuat(String full, String token, String tag, String judul, String catatan) throws Exception {
        Api.Result g = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/releases/tags/" + Api.enc(tag), token, null);
        if (g.ok) return new JSONObject(g.text);
        if (!g.text.contains("Kode: 404")) throw new Fatal(g.text + petunjuk(g.text));
        boolean biasa = !optPra && !optDraf;
        JSONObject body = Api.o("tag_name", tag, "name", judul.isEmpty() ? tag : judul, "body", catatan,
                "draft", optDraf, "prerelease", optPra,
                "make_latest", (biasa && optTerbaru) ? "true" : "false");
        if (optAuto) body.put("generate_notes", true);
        if (!optTarget.isEmpty()) body.put("target_commitish", optTarget);
        Api.Result p = Api.requestSync("POST", Api.BASE + "/repos/" + full + "/releases", token, body.toString());
        if (!p.ok && p.text.contains("Kode: 5")) {
            // GitHub error 5xx: rilis mungkin sudah terbentuk. Periksa dulu supaya tidak dobel.
            try { Thread.sleep(2000L); } catch (Exception ignored) { }
            Api.Result g2 = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/releases/tags/" + Api.enc(tag), token, null);
            if (g2.ok) return new JSONObject(g2.text);
        }
        if (!p.ok) throw new Fatal(p.text + petunjuk(p.text));
        return new JSONObject(p.text);
    }

    private static String petunjuk(String t) {
        if (t.contains("Kode: 500") || t.contains("Kode: 502") || t.contains("Kode: 503") || t.contains("Kode: 504")) {
            return "\n(GitHub sedang gangguan. Tunggu sebentar, lalu coba lagi.)";
        }
        if (t.contains("403") || t.contains("404")) {
            return "\n(Token perlu izin 'repo' atau 'Contents: read and write'.)";
        }
        if (t.contains("422")) {
            return "\n(Pastikan repo sudah punya satu komit dan nama tag valid, tanpa spasi.)";
        }
        return "";
    }

    private void hapusAsetSama(String full, String token, long relId, String nama) {
        Api.Result r = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/releases/" + relId
                + "/assets?per_page=100", token, null);
        if (!r.ok) return;
        JSONArray a = Api.parseArr(r.text);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && nama.equals(o.optString("name"))) {
                Api.requestSync("DELETE", Api.BASE + "/repos/" + full + "/releases/assets/" + o.optLong("id"), token, null);
            }
        }
    }

    private JSONObject unggah(String full, String token, String url, Uri uri, File tmp, long size, String nama)
            throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        InputStream in = null;
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(180000);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("User-Agent", "GitHub-by-novan");
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("Content-Type", nama.toLowerCase(java.util.Locale.ROOT).endsWith(".apk")
                    ? "application/vnd.android.package-archive" : "application/octet-stream");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(size);
            in = tmp != null ? new FileInputStream(tmp) : getContentResolver().openInputStream(uri);
            if (in == null) throw new Fatal("Berkas tidak bisa dibuka.");
            OutputStream os = c.getOutputStream();
            byte[] b = new byte[65536];
            long kirim = 0;
            int terakhir = -1;
            int n;
            while ((n = in.read(b)) > 0) {
                if (batalkan) throw new Batal();
                os.write(b, 0, n);
                kirim += n;
                int p = (int) (kirim * 100 / size);
                if (p != terakhir) {
                    terakhir = p;
                    status(full, awalan + "Mengunggah " + nama + ": " + p + "% (" + Ui.size(kirim) + " dari " + Ui.size(size) + ")", p);
                }
            }
            os.flush();
            os.close();
            status(full, awalan + "Menunggu GitHub memproses " + nama + "...", 100);
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            String text = "";
            if (is != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] bb = new byte[8192];
                int m;
                while ((m = is.read(bb)) != -1) bos.write(bb, 0, m);
                is.close();
                text = bos.toString("UTF-8");
            }
            if (code >= 200 && code < 300) return new JSONObject(text);
            String msg = Api.str(Api.parse(text), "message");
            String d = "Gagal mengunggah berkas. Kode: " + code + (msg.isEmpty() ? "" : " (" + msg + ")");
            if (code >= 500 || code == 408 || code == 429) throw new IOException(d);
            if (code == 422) d += "\n(Nama berkas sudah ada atau tidak valid.)";
            throw new Fatal(d);
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
            c.disconnect();
        }
    }

    private void selesai(Hasil h) {
        running = false;
        repo = "";
        setPending(h);
        postResultNotification(h);
        final Listener l = listener;
        if (l != null) MAIN.post(l::onFinished);
        stopForeground(true);
        stopSelf();
    }

    // ---------- notifikasi ----------

    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_PROGRESS, "Unggah rilis", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_RESULT, "Hasil rilis", NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, 16, i, f);
    }

    private Notification.Builder builder(String channel) {
        ensureChannels();
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification progressNotification(String full, String text, int persen) {
        Intent stop = new Intent(this, RilisService.class).setAction(ACTION_STOP);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPi = PendingIntent.getService(this, 17, stop, f);
        Notification.Builder b = builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Rilis ke " + full)
                .setContentText(text.replace('\n', ' '))
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setContentIntent(openApp())
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Batalkan", stopPi);
        if (persen >= 0) b.setProgress(100, persen, false); else b.setProgress(0, 0, true);
        return b.build();
    }

    private void postResultNotification(Hasil h) {
        try {
            String judul = h.ok ? "Rilis selesai" : h.batal ? "Rilis dibatalkan" : "Rilis gagal";
            String isi = h.pesan.length() > 300 ? h.pesan.substring(0, 300) + "..." : h.pesan;
            Notification n = builder(CH_RESULT)
                    .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                    .setContentTitle(judul)
                    .setContentText(isi)
                    .setStyle(new Notification.BigTextStyle().bigText(isi + "\n\nKetuk untuk melihat rincian."))
                    .setAutoCancel(true)
                    .setContentIntent(openApp())
                    .build();
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_RESULT, n);
        } catch (Exception ignored) { }
    }
}
