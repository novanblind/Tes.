#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Novan Tel - pembangun APK Telegram editan.

Alur:
  1. baca konfigurasi (api_id, api_hash, nama, dll.)
  2. unduh kode resmi Telegram Android (DrKLO/Telegram) ke folder sementara DI LUAR proyek
  3. terapkan editan (tools/terapkan.py + overlay/)
  4. siapkan tanda tangan, komponen Android SDK/NDK
  5. bangun APK dengan Gradle milik Telegram
  6. tandatangani ulang dan taruh di build/outputs/apk/release/NovanTel.apk
Dipanggil oleh `gradle assembleDebug` / `assembleRelease` (lihat build.gradle).
"""
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import terapkan  # noqa: E402

PENANDA_GAGAL = ROOT / "build" / ".novan-gagal"
KELUAR_APK = ROOT / "build" / "outputs" / "apk" / "release" / "NovanTel.apk"
PRABANGUN = ROOT / "prabangun" / "arm64-v8a"   # pustaka native hasil build lama (libtmessages.NN.so)

BAWAAN = {
    "api_id": "31016382",
    "api_hash": "",
    "nama_aplikasi": "Novan Tel",
    "application_id": "com.novan.novantel",
    "upstream_url": "https://github.com/DrKLO/Telegram.git",
    "upstream_ref": "",
    "hantu_baca": "true",
    "hantu_mengetik": "true",
    "hantu_online": "true",
    "hantu_cerita": "true",
    "hantu_konten": "true",
    "blokir_iklan": "true",
    "hanya_arm": "true",
    "arsitektur": "semua",
    "so_jadi": "true",
    "so_kompres": "true",
    "kualitas_suara": "hemat",
    "efek_suara": "true",
    "anti_hapus": "true",
    "ikon_pengaturan": "false",
    "menu_pengaturan": "true",
}


def log(*a):
    print(*a, flush=True)


def judul(t):
    log("\n==================== %s ====================" % t)


class Berhenti(Exception):
    pass


# ------------------------------------------------------------------ konfigurasi
def baca_properties(p):
    """Baca key=value (juga key: value), abaikan komentar, tanda kutip, dan spasi."""
    hasil = {}
    for baris in Path(p).read_text(encoding="utf-8-sig", errors="replace").splitlines():
        b = baris.strip()
        if not b or b.startswith("#"):
            continue
        m = re.match(r"^([\w.\-]+)\s*[=:]\s*(.*)$", b)
        if m:
            hasil[m.group(1).strip()] = m.group(2).strip().strip("\"'").strip()
    return hasil


def folder_konfigurasi():
    """Urutan dari prioritas rendah ke tinggi: folder proyek, induknya (akar repo), GITHUB_WORKSPACE."""
    hasil = []
    for d in (ROOT, ROOT.parent, Path(os.environ.get("GITHUB_WORKSPACE", str(ROOT)))):
        if d not in hasil:
            hasil.append(d)
    return hasil


def berkas_konfigurasi(nama_dasar):
    """Cari berkas konfigurasi; toleran terhadap akhiran .txt dan huruf besar/kecil."""
    hasil = []
    for d in folder_konfigurasi():
        if not d.is_dir():
            continue
        for p in sorted(d.iterdir()):
            n = p.name.lower()
            if p.is_file() and n.startswith(nama_dasar) and not n.endswith(".contoh"):
                hasil.append(p)
    return hasil


def kumpulkan_konfig():
    cfg = dict(BAWAAN)
    sumber = []
    for nama in ("novan-mod", "konfigurasi-telegram"):
        for p in berkas_konfigurasi(nama):
            for k, v in baca_properties(p).items():
                if v != "":
                    cfg[k] = v
            sumber.append(str(p))
    for env, k in (("TG_API_ID", "api_id"), ("TG_API_HASH", "api_hash")):
        if os.environ.get(env, "").strip():
            cfg[k] = os.environ[env].strip()
            sumber.append("env " + env)
    log("Sumber konfigurasi: " + (", ".join(sumber) if sumber else "(hanya bawaan)"))
    return cfg


def periksa_kredensial(cfg):
    if not re.fullmatch(r"\d{4,10}", cfg["api_id"]):
        raise Berhenti("api_id tidak valid: harus angka (contoh 31016382).")
    if not re.fullmatch(r"[0-9a-fA-F]{32}", cfg["api_hash"]):
        for d in folder_konfigurasi():
            try:
                log("Isi folder %s: %s" % (d, ", ".join(sorted(p.name for p in d.iterdir())[:40])))
            except OSError:
                pass
        raise Berhenti(
            "api_hash belum diisi atau tidak valid (harus 32 karakter huruf a-f dan angka).\n"
            "Cara mengisi: di akar repo GitHub Anda (di luar zip), buat berkas bernama\n"
            "konfigurasi-telegram.properties berisi:\n"
            "api_id=%s\napi_hash=ISI_DENGAN_API_HASH_DARI_my.telegram.org\n"
            "Pakai repo PRIVAT supaya api_hash tidak terlihat orang lain." % cfg["api_id"]
        )
    log("api_id: %s | api_hash: terbaca (%d karakter, tidak ditampilkan)" % (cfg["api_id"], len(cfg["api_hash"])))


# ------------------------------------------------------------------ utilitas proses
def _samarkan(cmd):
    """Sembunyikan nilai sandi pada baris log perintah."""
    hasil, sembunyi = [], False
    for c in map(str, cmd):
        hasil.append("********" if sembunyi else c)
        sembunyi = c in ("-storepass", "-keypass")
    return " ".join(hasil)


def jalankan(cmd, cwd=None, cek=True, tangkap=False, env=None, batas=None):
    log("$ " + _samarkan(cmd))
    e = dict(os.environ)
    if env:
        e.update(env)
    if tangkap:
        r = subprocess.run(cmd, cwd=cwd, env=e, text=True, errors="replace",
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=batas)
    else:
        r = subprocess.run(cmd, cwd=cwd, env=e, text=True, errors="replace", timeout=batas)
    if cek and r.returncode != 0:
        raise Berhenti("Perintah gagal (kode %d): %s" % (r.returncode, _samarkan(cmd)))
    return r


def sdk_dir():
    for k in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        v = os.environ.get(k)
        if v and Path(v).is_dir():
            return Path(v)
    for v in ("/usr/local/lib/android/sdk", str(Path.home() / "Android/Sdk")):
        if Path(v).is_dir():
            return Path(v)
    return None


def versi_tuple(s):
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", s))


# ------------------------------------------------------------------ langkah
def bersihkan_disk():
    if os.environ.get("GITHUB_ACTIONS") != "true":
        return
    judul("Lega-kan ruang disk runner")
    jalankan(["df", "-h", "/"], cek=False)
    for d in ("/usr/share/dotnet", "/opt/ghc", "/usr/local/share/boost", "/opt/hostedtoolcache/CodeQL",
              "/usr/local/.ghcup", "/usr/share/swift", "/usr/local/lib/node_modules"):
        if os.path.exists(d):
            subprocess.run(["sudo", "-n", "rm", "-rf", d], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    jalankan(["df", "-h", "/"], cek=False)


def unduh_upstream(cfg):
    judul("Mengunduh kode resmi Telegram Android")
    induk = Path(os.environ.get("RUNNER_TEMP") or tempfile.gettempdir())
    tujuan = induk / "novantel-upstream"
    if tujuan.exists():
        shutil.rmtree(tujuan, ignore_errors=True)
    cmd = ["git", "clone", "--depth", "1"]
    if cfg["upstream_ref"]:
        cmd += ["--branch", cfg["upstream_ref"]]
    cmd += [cfg["upstream_url"], str(tujuan)]
    terakhir = None
    for pk in range(1, 4):
        try:
            jalankan(cmd, env={"GIT_TERMINAL_PROMPT": "0"})
            terakhir = None
            break
        except Berhenti as e:
            terakhir = e
            log("Percobaan %d gagal, mengulang..." % pk)
            shutil.rmtree(tujuan, ignore_errors=True)
            time.sleep(8 * pk)
    if terakhir:
        raise Berhenti("Gagal mengunduh kode Telegram dari %s setelah 3 percobaan." % cfg["upstream_url"])
    gm = tujuan / ".gitmodules"
    if gm.is_file():
        log("Submodul ditemukan di .gitmodules:\n" + gm.read_text(encoding="utf-8", errors="replace").strip())
        ok = False
        for pk in range(1, 4):
            r = jalankan(["git", "submodule", "update", "--init", "--recursive", "--depth", "1"],
                         cwd=tujuan, cek=False, env={"GIT_TERMINAL_PROMPT": "0"})
            if r.returncode == 0:
                ok = True
                break
            log("Unduh submodul percobaan %d gagal, mengulang..." % pk)
            time.sleep(8 * pk)
        if not ok:
            raise Berhenti("Gagal mengunduh submodul kode Telegram (lihat log di atas).")
    else:
        log("Tidak ada .gitmodules (tanpa submodul).")
    r = jalankan(["git", "rev-parse", "--short", "HEAD"], cwd=tujuan, tangkap=True, cek=False)
    log("Versi kode Telegram (commit): " + (r.stdout or "?").strip())
    log("Isi folder utama: " + ", ".join(sorted(p.name for p in tujuan.iterdir() if p.name != ".git")))
    return tujuan


# ------------------------------------------------------------------ pustaka native jadi (build cepat)
def _hapus_blok(teks, pola):
    """Hapus semua blok 'nama { ... }' (kurung kurawal seimbang) yang cocok dengan pola."""
    jumlah = 0
    while True:
        m = re.search(pola, teks)
        if not m:
            return teks, jumlah
        dalam, akhir = 0, -1
        for i in range(m.end() - 1, len(teks)):
            if teks[i] == "{":
                dalam += 1
            elif teks[i] == "}":
                dalam -= 1
                if dalam == 0:
                    akhir = i
                    break
        if akhir < 0:
            return teks, jumlah
        teks = teks[:m.start()] + teks[akhir + 1:]
        jumlah += 1


def pakai_so_jadi(up, cfg):
    """Bila ada libtmessages.NN.so hasil build lama di prabangun/arm64-v8a, pakai itu dan matikan
    kompilasi C/C++ (CMake/NDK) Telegram. Ini bagian terlama build (puluhan menit sampai berjam-jam).
    Bila ada yang tidak cocok, kembali ke build native biasa (lebih lambat tetapi aman)."""
    judul("Pustaka native jadi (pengganti kompilasi NDK)")
    if terapkan.bool_str(cfg.get("so_jadi", "true")) != "true":
        log("so_jadi=false: kode native dikompilasi ulang seperti biasa.")
        return False
    if cfg.get("arsitektur", "semua").strip().lower() != "arm64":
        log("LEWAT: pustaka jadi hanya untuk arm64; arsitektur=%s dibangun native biasa." % cfg.get("arsitektur"))
        return False
    daftar = sorted(PRABANGUN.glob("libtmessages.*.so")) if PRABANGUN.is_dir() else []
    if not daftar:
        log("LEWAT: tidak ada %s/libtmessages.*.so; kode native dikompilasi biasa." % PRABANGUN.relative_to(ROOT))
        return False
    so = daftar[0]
    data = so.read_bytes()
    if data[:4] != b"\x7fELF" or data[4] != 2 or int.from_bytes(data[18:20], "little") != 183:
        log("LEWAT: %s bukan pustaka ELF arm64; dikompilasi biasa." % so.name)
        return False
    ver_so = re.fullmatch(r"libtmessages\.(\d+)\.so", so.name)
    # 1) nomor versi pustaka harus sama dengan yang diminta kode Telegram (NativeLoader.LIB_VERSION)
    ver_up = None
    for nl in terapkan.cari(up, r"NativeLoader\.java"):
        m = re.search(r"\bLIB_VERSION\s*=\s*(\d+)", terapkan.baca(nl))
        if m:
            ver_up = m.group(1)
            break
    if not ver_so or ver_up != ver_so.group(1):
        log("LEWAT: versi pustaka tidak cocok (berkas: %s, kode Telegram sekarang: %s). Kode Telegram sudah "
            "berubah sejak pustaka dibangun; dikompilasi biasa. Ambil libtmessages baru dari APK terbaru, "
            "atau isi upstream_ref= dengan versi lama." % (so.name, ver_up or "tidak terbaca"))
        return False
    # 2) semua fungsi native_* yang dideklarasikan di Java harus ada di dalam pustaka
    perlu = set()
    for j in terapkan.cari(up, r".*\.java"):
        if "org" not in j.parts or "telegram" not in j.parts:
            continue
        t = terapkan.baca(j)
        if " native " in t:
            perlu.update(re.findall(r"\bnative\s+[\w<>\[\]]+\s+(native_\w+)\s*\(", t))
    hilang = sorted(n for n in perlu if n.replace("_", "_1").encode() not in data and n.encode() not in data)
    log("Fungsi native_* di Java: %d, tidak ada di pustaka: %d" % (len(perlu), len(hilang)))
    if hilang:
        log("LEWAT: pustaka jadi tidak punya: %s. Dikompilasi biasa." % ", ".join(hilang[:10]))
        return False
    # 3) matikan build native di modul yang memilikinya, lalu taruh pustaka di jniLibs
    modul = None
    for g in terapkan.cari(up, r"build\.gradle(\.kts)?"):
        t = terapkan.baca(g)
        if "externalNativeBuild" not in t:
            continue
        t, n = _hapus_blok(t, r"externalNativeBuild\s*\{")
        t = re.sub(r"(?m)^[ \t]*ndkVersion\b[^\n]*\n", "", t)
        terapkan.tulis(g, t)
        log("externalNativeBuild dimatikan (%d blok) di %s" % (n, g.relative_to(up)))
        modul = modul or g.parent
    if not modul:
        log("LEWAT: blok externalNativeBuild tidak ditemukan; tidak ada yang perlu dimatikan, dikompilasi biasa.")
        return False
    tujuan = modul / "src" / "main" / "jniLibs" / "arm64-v8a"
    tujuan.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(so, tujuan / so.name)
    log("Dipakai: %s (%.1f MB) -> %s. Tanpa kompilasi C/C++ dan tanpa pemasangan NDK." %
        (so.name, so.stat().st_size / 1048576, tujuan.relative_to(up)))
    return True


def cari_kunci_pribadi():
    for d in reversed(folder_konfigurasi()):
        p12 = d / ".tanda-tangan" / "kunci.p12"
        prop = d / ".tanda-tangan" / "sandi.properties"
        if p12.is_file() and prop.is_file():
            pr = baca_properties(prop)
            if pr.get("alias") and pr.get("sandi"):
                return p12, pr["alias"], pr["sandi"]
    return None


def siapkan_kunci(up):
    """Kembalikan (path_keystore, alias, sandi). Pakai kunci pribadi bila ada, kalau tidak buat sementara."""
    judul("Menyiapkan tanda tangan")
    pribadi = cari_kunci_pribadi()
    if pribadi:
        log("Memakai tanda tangan pribadi dari .tanda-tangan/kunci.p12")
        return pribadi
    log("Tanda tangan pribadi tidak ditemukan: membuat kunci SEMENTARA.")
    log("PERINGATAN: kunci sementara berganti tiap build; update tidak bisa menimpa APK lama.")
    log("Pilih 'tanda tangan pribadi' di GitHub by novan agar APK bisa diperbarui tanpa dicopot.")
    kunci = ROOT / "build" / "kunci-sementara.p12"
    kunci.parent.mkdir(parents=True, exist_ok=True)
    if kunci.exists():
        kunci.unlink()
    sandi = secrets.token_hex(12)
    jalankan(["keytool", "-genkeypair", "-alias", "novantel", "-keyalg", "RSA", "-keysize", "2048",
              "-validity", "10000", "-storetype", "PKCS12", "-keystore", str(kunci),
              "-storepass", sandi, "-keypass", sandi, "-dname", "CN=Novan Tel, O=Novan"],
             tangkap=True)
    return kunci, "novantel", sandi


def pasang_penandatanganan_upstream(up, kunci):
    p12, alias, sandi = kunci
    # keystore di tempat yang dirujuk berkas gradle Telegram (config/release.keystore)
    tujuan = {up / "TMessagesProj" / "config" / "release.keystore"}
    for g in terapkan.cari(up, r"build\.gradle(\.kts)?"):
        s = terapkan.baca(g)
        for m in re.finditer(r"""storeFile\s*=?\s*file\(\s*["']([^"']+)["']\s*\)""", s):
            tujuan.add((g.parent / m.group(1)).resolve())
    for t in tujuan:
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p12, t)
    gh = Path.home() / ".gradle"
    gh.mkdir(parents=True, exist_ok=True)
    with open(gh / "gradle.properties", "a", encoding="utf-8") as f:
        f.write("\nRELEASE_KEY_PASSWORD=%s\nRELEASE_KEY_ALIAS=%s\nRELEASE_STORE_PASSWORD=%s\n" % (sandi, alias, sandi))
        f.write("org.gradle.jvmargs=-Xmx5g -XX:MaxMetaspaceSize=1g -Dfile.encoding=UTF-8\n")
        f.write("org.gradle.daemon=false\n")
    init = gh / "init.d"
    init.mkdir(parents=True, exist_ok=True)
    (init / "novan.gradle").write_text(
        "allprojects { tasks.configureEach { t -> if (t.name.startsWith('lintVital') || t.name.startsWith('lintAnalyze')) { t.enabled = false } } }\n",
        encoding="utf-8")
    log("Kunci dipasang di %d lokasi keystore Telegram; lint rilis dimatikan." % len(tujuan))


def pasang_komponen_sdk(up):
    judul("Memasang komponen Android SDK/NDK yang diminta Telegram")
    sd = sdk_dir()
    if not sd:
        log("ANDROID_HOME tidak ditemukan; dilewati (Gradle akan mencoba sendiri).")
        return
    (up / "local.properties").write_text("sdk.dir=%s\n" % sd, encoding="utf-8")
    teks = "\n".join(terapkan.baca(g) for g in terapkan.cari(up, r"build\.gradle(\.kts)?"))
    paket = []
    for v in sorted(set(re.findall(r"compileSdk(?:Version)?\s*=?\s*(\d+)", teks))):
        paket.append("platforms;android-" + v)
    for v in sorted(set(re.findall(r"""buildToolsVersion\s*=?\s*["']([\d.]+)["']""", teks))):
        paket.append("build-tools;" + v)
    for v in sorted(set(re.findall(r"""ndkVersion\s*=?\s*["']([\d.]+)["']""", teks))):
        paket.append("ndk;" + v)
    for v in sorted(set(re.findall(r"""cmake\s*\{[^}]*?version\s*=?\s*["']([\d.]+)["']""", teks, re.S))):
        paket.append("cmake;" + v)
    paket.append("platform-tools")
    sm = shutil.which("sdkmanager")
    if not sm:
        cand = sorted((sd / "cmdline-tools").glob("*/bin/sdkmanager"), reverse=True)
        sm = str(cand[0]) if cand else None
    if not sm:
        log("sdkmanager tidak ditemukan; dilewati. Diminta: " + ", ".join(paket))
        return
    log("Paket diminta: " + ", ".join(paket))
    subprocess.run("yes | %s --licenses > /dev/null 2>&1" % sm, shell=True)
    r = subprocess.run([sm, "--install"] + paket, text=True, errors="replace",
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log((r.stdout or "")[-1500:])
    if r.returncode != 0:
        log("PERINGATAN: sdkmanager mengembalikan kode %d; Gradle akan mencoba mengunduh sendiri." % r.returncode)


def cari_modul_aplikasi(up):
    if (up / "TMessagesProj_App").is_dir():
        return "TMessagesProj_App"
    for g in terapkan.cari(up, r"build\.gradle(\.kts)?"):
        if "com.android.application" in terapkan.baca(g) and g.parent != up:
            return g.parent.name
    raise Berhenti("Modul aplikasi Android tidak ditemukan di kode Telegram.")


def pilih_tugas(daftar):
    kandidat = []
    for t in daftar:
        if re.search(r"Debug|AndroidTest|UnitTest|Bundle|HA_|Hockey|Private|Public|Hardcore|Beta", t, re.I):
            continue
        if not (t.endswith("Release") or t.endswith("Standalone")):
            continue
        skor = 0
        if re.search(r"Afat|Universal", t, re.I):
            skor += 10
        if t.endswith("Standalone"):
            skor += 3
        if t.endswith("Release"):
            skor += 4
        kandidat.append((-skor, len(t), t))
    kandidat.sort()
    return [k[2] for k in kandidat]


def kompres_so(up, modul, cfg):
    """Paksa pustaka native (.so) dikompresi di dalam APK (useLegacyPackaging = true) supaya APK jauh lebih kecil.
    AGP ikut menulis extractNativeLibs=true di manifest, jadi Android mengekstrak pustaka saat pemasangan.
    Tidak fatal: bila build.gradle modul tidak cocok, cukup dicatat LEWAT dan build jalan seperti biasa."""
    judul("Kompresi pustaka native (.so) di APK")
    if terapkan.bool_str(cfg.get("so_kompres", "true")) != "true":
        log("so_kompres=false: pengaturan kompresi .so bawaan Telegram tidak diubah.")
        return
    g = None
    for nama in ("build.gradle", "build.gradle.kts"):
        if (up / modul / nama).is_file():
            g = up / modul / nama
            break
    if g is None:
        log("LEWAT: build.gradle modul %s tidak ditemukan." % modul)
        return
    t = terapkan.baca(g)
    kts = g.suffix == ".kts"
    asli = t
    if re.search(r"useLegacyPackaging", t):
        t = re.sub(r"(useLegacyPackaging\s*(?:=|\())\s*false", r"\1 true", t)
        t = re.sub(r"(useLegacyPackaging\s*=\s*)false", r"\1true", t)
        log("useLegacyPackaging sudah ada di %s; dipastikan bernilai true." % g.name)
    else:
        isi = "jniLibs { useLegacyPackaging = true }"
        # versi plugin Android: dari build.gradle akar (com.android.tools.build:gradle:X) atau blok plugins
        major = 8
        for bg in (up / "build.gradle", up / "build.gradle.kts", up / "settings.gradle", up / "settings.gradle.kts"):
            if bg.is_file():
                m = re.search(r"com\.android\.(?:tools\.build:gradle:|application['\"]?\)?\s*(?:version\s*)?['\"]?)(\d+)\.", terapkan.baca(bg))
                if m:
                    major = int(m.group(1))
                    break
        kunci = "packaging" if major >= 9 else "packagingOptions"
        m = re.search(r"(?m)^([ \t]*)(?:packagingOptions|packaging)\s*\{[ \t]*\n", t)
        if m:
            ind = m.group(1) + "    "
            t = t[:m.end()] + ind + isi + "\n" + t[m.end():]
            log("jniLibs { useLegacyPackaging = true } disisipkan ke blok packaging yang sudah ada di %s." % g.name)
        else:
            m = re.search(r"(?m)^([ \t]*)android\s*\{[ \t]*\n", t)
            if not m:
                log("LEWAT: blok android { } tidak ditemukan di %s; pengaturan kompresi .so tidak diubah." % g.name)
                return
            ind = m.group(1) + "    "
            blok = "%s%s {\n%s    %s\n%s}\n" % (ind, kunci, ind, isi, ind)
            t = t[:m.end()] + blok + t[m.end():]
            log("Blok %s { %s } ditambahkan ke %s (plugin Android mayor %d)." % (kunci, isi, g.name, major))
    if t != asli:
        terapkan.tulis(g, t)


def rincian_apk(apk):
    """Cetak rincian isi APK (ukuran di dalam APK, setelah kompresi) supaya jelas apa yang paling besar."""
    import zipfile
    try:
        with zipfile.ZipFile(apk) as z:
            info = z.infolist()
    except Exception as e:  # noqa: BLE001
        log("Tidak bisa membaca APK untuk rincian: %s" % e)
        return
    def grup(n):
        if n.startswith("lib/"):
            return "lib/ (pustaka native)"
        if n.startswith("classes") and n.endswith(".dex"):
            return "classes*.dex (kode Java)"
        if n.startswith("res/"):
            return "res/ (gambar, layout, dll)"
        if n == "resources.arsc":
            return "resources.arsc (teks/bahasa)"
        if n.startswith("assets/"):
            return "assets/"
        if n.startswith("META-INF/"):
            return "META-INF/"
        return "lainnya"
    total = {}
    for i in info:
        g = grup(i.filename)
        a, b = total.get(g, (0, 0))
        total[g] = (a + i.compress_size, b + i.file_size)
    log("--- RINCIAN ISI APK (ukuran di dalam APK / ukuran asli) ---")
    for g, (c, o) in sorted(total.items(), key=lambda x: -x[1][0]):
        log("  %-34s %7.2f MB / %7.2f MB" % (g, c / 1048576, o / 1048576))
    log("--- 25 BERKAS TERBESAR (di dalam APK / asli / metode) ---")
    for i in sorted(info, key=lambda x: -x.compress_size)[:25]:
        log("  %7.2f MB / %7.2f MB  %-9s %s" % (i.compress_size / 1048576, i.file_size / 1048576,
            "disimpan" if i.compress_type == 0 else "dikompres", i.filename))
    log("--- AKHIR RINCIAN APK ---")


def laporkan_so_apk(apk):
    """Catat apakah .so di APK terkompresi dan berapa ukurannya (hanya informasi)."""
    import zipfile
    try:
        with zipfile.ZipFile(apk) as z:
            besar = [i for i in z.infolist() if i.filename.endswith(".so")]
            if not besar:
                return
            asal = sum(i.file_size for i in besar)
            simpan = sum(i.compress_size for i in besar)
            tersimpan = sum(1 for i in besar if i.compress_type == 0)
            log("Pustaka .so di APK: %d berkas, %.1f MB -> %.1f MB di dalam APK; %d berkas tanpa kompresi."
                % (len(besar), asal / 1048576, simpan / 1048576, tersimpan))
            if tersimpan:
                log("PERINGATAN: masih ada .so tanpa kompresi; periksa log 'Kompresi pustaka native' di atas.")
    except Exception as e:  # noqa: BLE001
        log("Tidak bisa memeriksa isi APK: %s" % e)


def bangun_gradle(up, modul, arsitektur="semua"):
    judul("Membangun APK dengan Gradle Telegram (bisa 40-90 menit)")
    gw = up / "gradlew"
    if gw.is_file():
        gw.chmod(0o755)
        gradle = str(gw)
    else:
        gradle = "gradle"
    dasar = [gradle, "--no-daemon", "--console=plain"]
    r = jalankan(dasar + ["-q", ":%s:tasks" % modul, "--all"], cwd=up, tangkap=True, cek=False)
    keluaran = r.stdout or ""
    if r.returncode != 0:
        log(keluaran[-6000:])
        raise Berhenti("Gradle gagal membaca daftar tugas modul %s (lihat log di atas)." % modul)
    semua = sorted(set(re.findall(r"^(assemble\w+)\b", keluaran, re.M)))
    log("Tugas assemble yang tersedia: " + ", ".join(semua))
    urut = pilih_tugas(semua)
    tugas = urut[0] if urut else "assembleRelease"
    log("Tugas yang dipilih: " + tugas + ("  (cadangan: %s)" % ", ".join(urut[1:4]) if len(urut) > 1 else ""))
    antrean = urut[:3] if urut else ["assembleRelease"]
    terakhir = None
    for i, tugas in enumerate(antrean):
        cmd = dasar + [":%s:%s" % (modul, tugas), "--stacktrace",
                       "-Dorg.gradle.jvmargs=-Xmx5g -XX:MaxMetaspaceSize=1g -Dfile.encoding=UTF-8"]
        # Jangan pakai -Pandroid.injected.* untuk ABI: AGP menganggapnya build dari IDE dan menandai APK
        # android:testOnly (INSTALL_FAILED_TEST_ONLY). Pemilihan ABI sudah dilakukan lewat abiFilters.
        cmd.append("-Pandroid.injected.testOnly=false")
        mulai = time.time()
        r = jalankan(cmd, cwd=up, cek=False)
        if r.returncode == 0:
            return tugas
        lama = time.time() - mulai
        terakhir = tugas
        if i + 1 < len(antrean) and lama < 900:
            log("\nPERINGATAN: %s gagal dalam %d detik (kemungkinan masalah varian/konfigurasi). "
                "Mencoba tugas cadangan: %s" % (tugas, lama, antrean[i + 1]))
            continue
        break
    raise Berhenti("Gradle gagal pada tugas %s (lihat galat di atas)." % terakhir)


def cari_apk(up):
    """Cari APK hasil Gradle dengan beberapa cara, karena Telegram bisa mengalihkan folder keluaran."""
    ditemukan = {}

    def tambah(p):
        p = Path(p)
        if p.is_file() and p.suffix.lower() == ".apk" and "androidTest" not in str(p):
            ditemukan[p.resolve()] = p

    # 1. lokasi standar
    for p in up.glob("**/build/outputs/apk/**/*.apk"):
        tambah(p)
    # 2. berkas pengalihan yang ditulis Android Gradle Plugin (menunjuk ke folder keluaran sebenarnya)
    for r in up.glob("**/build/intermediates/apk_ide_redirect_file/**/redirect.txt"):
        try:
            for b in r.read_text(encoding="utf-8", errors="replace").splitlines():
                if b.startswith("listingFile="):
                    folder = (r.parent / b.split("=", 1)[1].strip()).resolve().parent
                    log("Pengalihan keluaran APK: %s -> %s" % (r.name, folder))
                    if folder.is_dir():
                        for p in folder.glob("*.apk"):
                            tambah(p)
        except OSError:
            pass
    # 3. seluruh pohon kode Telegram (termasuk folder build)
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d != ".git"]
        for f in fn:
            if f.lower().endswith(".apk"):
                tambah(Path(dp) / f)
    # 4. cadangan: folder induk (RUNNER_TEMP) bila Gradle memindahkan build ke luar
    if not ditemukan:
        induk = up.parent
        for dp, dn, fn in os.walk(induk):
            dn[:] = [d for d in dn if d not in (".git", ".gradle-actions", "node_modules")]
            for f in fn:
                if f.lower().endswith(".apk"):
                    tambah(Path(dp) / f)
    return list(ditemukan.values())


def diagnosa_keluaran(up):
    """Cetak apa saja yang ada di folder keluaran, supaya jelas ke mana Gradle menaruh hasilnya."""
    log("--- DIAGNOSA KELUARAN GRADLE ---")
    n = 0
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in (".git", "src", "jni", "node_modules")]
        rel = Path(dp).relative_to(up)
        if rel.parts and "outputs" in rel.parts and len(rel.parts) <= 8:
            log("  %s/: %s" % (rel, ", ".join(sorted(fn)[:12])))
            n += 1
        if n > 60:
            break
    for pat in ("**/*.aab", "**/output-metadata.json", "**/redirect.txt"):
        for p in list(up.glob(pat))[:10]:
            log("  ditemukan: %s (%d bita)" % (p.relative_to(up), p.stat().st_size))
    for g in terapkan.cari(up, r"build\.gradle(\.kts)?")[:12]:
        for i, b in enumerate(terapkan.baca(g).splitlines(), 1):
            if re.search(r"buildDir|layout\.buildDirectory|outputFileName|archivesBaseName|outputDirectory", b):
                log("  %s:%d: %s" % (g.relative_to(up), i, b.strip()[:160]))


def tandatangani(up, kunci):
    judul("Menandatangani APK")
    apk = cari_apk(up)
    if not apk:
        diagnosa_keluaran(up)
        raise Berhenti("Gradle selesai tetapi berkas APK tidak ditemukan di build/outputs/apk.")
    apk.sort(key=lambda p: p.stat().st_size, reverse=True)
    for p in apk:
        try:
            nama = p.relative_to(up)
        except ValueError:
            nama = p
        log("APK ditemukan: %s (%.1f MB)" % (nama, p.stat().st_size / 1048576))
    pilih = apk[0]
    log("Dipilih (terbesar, biasanya universal): " + pilih.name)
    sd = sdk_dir()
    bt = sorted((sd / "build-tools").iterdir(), key=lambda p: versi_tuple(p.name))[-1] if sd else None
    KELUAR_APK.parent.mkdir(parents=True, exist_ok=True)
    if KELUAR_APK.exists():
        KELUAR_APK.unlink()
    if not bt:
        log("PERINGATAN: build-tools tidak ditemukan, APK disalin tanpa tanda tangan ulang.")
        shutil.copyfile(pilih, KELUAR_APK)
        return
    p12, alias, sandi = kunci
    selaras = KELUAR_APK.with_suffix(".aligned")
    jalankan([str(bt / "zipalign"), "-p", "-f", "4", str(pilih), str(selaras)])
    env = {"NOVAN_KS_PASS": sandi}
    jalankan([str(bt / "apksigner"), "sign", "--ks", str(p12), "--ks-type", "PKCS12", "--ks-key-alias", alias,
              "--ks-pass", "env:NOVAN_KS_PASS", "--key-pass", "env:NOVAN_KS_PASS",
              "--out", str(KELUAR_APK), str(selaras)], env=env)
    selaras.unlink(missing_ok=True)
    Path(str(KELUAR_APK) + ".idsig").unlink(missing_ok=True)
    jalankan([str(bt / "apksigner"), "verify", "--print-certs", str(KELUAR_APK)], cek=False)
    log("APK akhir: %s (%.1f MB)" % (KELUAR_APK, KELUAR_APK.stat().st_size / 1048576))
    laporkan_so_apk(KELUAR_APK)
    rincian_apk(KELUAR_APK)
    aapt = bt / "aapt2"
    if aapt.is_file():
        r = jalankan([str(aapt), "dump", "badging", str(KELUAR_APK)], cek=False, tangkap=True)
        if "testOnly" in (r.stdout or ""):
            raise Berhenti("APK bertanda testOnly (tidak bisa dipasang biasa). Periksa flag -Pandroid.injected.* dan manifest.")
        log("Pemeriksaan: APK bukan testOnly.")


class DiagnosaKode(Exception):
    """Berhenti sengaja setelah mencetak cuplikan kode Telegram (mode_diagnosa_kode=true)."""


def diagnosa_kode(up):
    """Cetak cuplikan kode Telegram yang dibutuhkan untuk menyesuaikan tambalan, lalu berhenti sebelum Gradle.
    Pengguna cukup menyalin log ini (tanpa menunggu build 40 menit)."""
    up = Path(up)
    judul("DIAGNOSA KODE TELEGRAM (salin dari baris ini sampai akhir diagnosa)")

    def berkas(nama, ciri):
        h = [p for p in terapkan.cari(up, nama) if ciri in p.parts]
        return h[0] if h else None

    def garis(p, pola, maks=40, konteks=0):
        if not p:
            log("  (berkas tidak ditemukan)")
            return
        baris = terapkan.baca(p).splitlines()
        n = 0
        for i, b in enumerate(baris):
            if re.search(pola, b):
                for k in range(max(0, i - konteks), min(len(baris), i + konteks + 1)):
                    log("  %d: %s" % (k + 1, baris[k].rstrip()[:170]))
                if konteks:
                    log("  --")
                n += 1
                if n >= maks:
                    log("  ... (dipotong)")
                    break
        if not n:
            log("  (tidak ada baris cocok)")

    def blok(p, pola, jumlah):
        """Mulai dari baris pertama yang cocok, cetak 'jumlah' baris."""
        if not p:
            log("  (berkas tidak ditemukan)")
            return
        baris = terapkan.baca(p).splitlines()
        for i, b in enumerate(baris):
            if re.search(pola, b):
                for k in range(i, min(len(baris), i + jumlah)):
                    log("  %d: %s" % (k + 1, baris[k].rstrip()[:170]))
                return
        log("  (pola tidak ditemukan)")

    try:
        ca = berkas(r"ChatActivity\.java", "ui")
        log("--- ChatActivity: %s" % (ca.relative_to(up) if ca else "-"))
        log("[A6] menu tekan-tahan pesan: awal createMenu (12 baris)")
        blok(ca, r"void\s+createMenu\s*\(", 12)
        log("[A6b] sekitar options.isEmpty() di createMenu")
        garis(ca, r"options\.isEmpty\(\)", 4, 2)
        log("[A6c] awal processSelectedOption (8 baris)")
        blok(ca, r"void\s+processSelectedOption", 8)
        log("[A7] pengenal pesan suara dan video bulat (ChatActivity)")
        garis(ca, r"isRoundVideoMessage|isVoiceMessage|\.isRoundVideo\(\)|\.isVoice\(\)", 8)

        log("[T1] tanda tangan semua createMenu")
        garis(ca, r"\bcreateMenu\s*\(", 6, 1)
        try:
            tx = terapkan.baca(ca)
            ov = terapkan._semua_createmenu(tx)
            log("[T2] jumlah overload createMenu: %d" % len(ov))
            for k, (aw, ak, bd) in enumerate(ov):
                log("  overload #%d: panjang %d, items.add=%d options.add=%d icons.add=%d selectedObject=%d isEmpty=%d" % (
                    k, len(bd), bd.count("items.add("), bd.count("options.add("), bd.count("icons.add("), bd.count("selectedObject"), bd.count("options.isEmpty()")))
            log("[T2b] overload utama terpilih: %s" % ("ya" if terapkan._createmenu_utama(tx) else "TIDAK"))
            if len(ov) > 1 and not terapkan._createmenu_utama(tx):
                bd = max(ov, key=lambda t: len(t[2]))[2]
                bl = bd.splitlines()
                log("[T3] 12 baris pertama overload terpanjang")
                for l in bl[:12]:
                    log("  | " + l.rstrip()[:170])
                log("[T4] baris yang memuat .add( / isEmpty / selectedObject (maks 25)")
                n = 0
                for l in bl:
                    if re.search(r"\.add\(|isEmpty\(\)|selectedObject", l):
                        log("  | " + l.strip()[:170])
                        n += 1
                        if n >= 25:
                            break
        except Exception as e:  # noqa: BLE001
            log("(T2-T4 gagal: %s)" % e)
        log("[T5] konstanta OPTION_ di ChatActivity")
        garis(ca, r"int\s+OPTION_(RETRY|COPY|DELETE)\b", 4)
        log("[T6] uji coba tambalan Transkripsi pada salinan kode ini")
        try:
            terapkan.terapkan_transkripsi(up, {"transkripsi": "true"})
            log("[T7] hasil sisipan (sekitar OPSI_TRANSKRIP)")
            garis(ca, r"OPSI_TRANSKRIP", 4, 1)
        except Exception as e:  # noqa: BLE001
            log("(uji tambalan gagal: %s)" % e)

        log("[V1] awal processRowSelect (30 baris)")
        blok(ca, r"void\s+processRowSelect\s*\(", 30)
        log("[V2] getItem(copy/forward/delete/reply) di ChatActivity (konteks 2 baris)")
        garis(ca, r"getItem\(\s*(copy|forward|delete|reply|star)\s*\)", 10, 2)
        log("[V3] setVisibility pada item action mode")
        garis(ca, r"(copyItem|forwardItem|deleteItem|replyItem|starItem|saveItem)\w*\.setVisibility\(", 14, 1)
        log("[V4] penghitung pilihan")
        garis(ca, r"void\s+updateActionModeTitle|void\s+updateSelectedMessagesCount|selectedMessagesCanCopyIds\s*\[", 8, 1)
        log("[B1] semua pemanggil dan deklarasi updateActionModeTitle (konteks 2)")
        garis(ca, r"updateActionModeTitle\s*\(", 12, 2)
        log("[B2] isi updateActionModeTitle (25 baris)")
        blok(ca, r"void\s+updateActionModeTitle\s*\(", 25)
        log("[B3] semua deklarasi addToSelectedMessages")
        garis(ca, r"void\s+addToSelectedMessages\s*\(", 6)
        log("[B3b] isi addToSelectedMessages (70 baris)")
        blok(ca, r"void\s+addToSelectedMessages\s*\(", 70)
        log("[B4] addItemWithWidth di ChatActivity (konteks 2)")
        garis(ca, r"addItemWithWidth\s*\(", 12, 2)
        log("[B5] actionModeViews (maks 25)")
        garis(ca, r"actionModeViews", 25)
        log("[B6] showActionMode( (konteks 3)")
        garis(ca, r"showActionMode\s*\(", 6, 3)
        log("[B7] deklarasi selectedMessagesIds")
        garis(ca, r"SparseArray.*selectedMessagesIds\b", 4)
        log("[B8] uji coba tambalan bilah atas pada salinan kode ini (baca baris [OK]/[LEWAT]/[INFO] di atasnya)")
        try:
            terapkan.terapkan_simpan_banyak(up, {"simpan_banyak": "true", "transkripsi": "true"})
            log("[B9] hasil sisipan (OPSI_TRANSKRIP_ATAS, jadwalPerbaruiTranskripsi, daftarItemTranskripsi, perbaruiTranskripsiAtas; konteks 1)")
            garis(ca, r"OPSI_TRANSKRIP_ATAS|jadwalPerbaruiTranskripsi|daftarItemTranskripsi|perbaruiTranskripsiAtas", 12, 1)
        except Exception as e:  # noqa: BLE001
            log("(uji tambalan bilah atas gagal: %s)" % e)
        mo = berkas(r"MessageObject\.java", "messenger")
        log("--- MessageObject")
        garis(mo, r"public\s+int\s+type\b|public\s+long\s+getDialogId|public\s+int\s+getId\(|static\s+final\s+int\s+TYPE_TEXT\b|CharSequence\s+messageText\b", 8)

        log("--- MessageObject: pengenal pesan suara / video bulat")
        garis(mo, r"static\s+boolean\s+isRoundVideoMessage|static\s+boolean\s+isVoiceMessage|boolean\s+isRoundVideo\(|boolean\s+isVoice\(", 8)
        fl = berkas(r"FileLoader\.java", "messenger")
        log("--- FileLoader: lokasi berkas pesan")
        garis(fl, r"File\s+getPathToMessage\(|File\s+getPathToAttach\(", 6)

        cu = berkas(r"BuildVars\.java", "messenger")
        log("--- BuildVars")
        garis(cu, r"BUILD_VERSION|APP_ID", 4)
    except Exception as e:  # noqa: BLE001
        log("(diagnosa kode gagal sebagian: %s)" % e)
    judul("AKHIR DIAGNOSA KODE TELEGRAM")
    raise DiagnosaKode("Mode diagnosa kode (mode_diagnosa_kode=true): build dihentikan sengaja sebelum Gradle. "
                       "Salin log di antara 'DIAGNOSA KODE TELEGRAM' dan 'AKHIR DIAGNOSA KODE TELEGRAM', lalu kirim ke Claude.")


def diagnosa_bilah_atas(up):
    """Diagnosa khusus bilah atas mode pilih (ikon Transkripsi tidak muncul). Hanya mencetak, lalu berhenti sebelum Gradle."""
    up = Path(up)
    judul("DIAGNOSA KODE TELEGRAM (salin dari baris ini sampai akhir diagnosa)")

    def berkas(nama, ciri):
        h = [q for q in terapkan.cari(up, nama) if ciri in q.parts]
        return h[0] if h else None

    def mulai(q, pola, sebelum, jumlah):
        if not q:
            log("  (berkas tidak ditemukan)")
            return
        baris = terapkan.baca(q).splitlines()
        for i, b in enumerate(baris):
            if re.search(pola, b):
                for k in range(max(0, i - sebelum), min(len(baris), i - sebelum + jumlah)):
                    log("  %d: %s" % (k + 1, baris[k].rstrip()[:150]))
                return
        log("  (pola tidak ditemukan: %s)" % pola)

    try:
        ca = berkas(r"ChatActivity\.java", "ui")
        abm = berkas(r"ActionBarMenu\.java", "ActionBar")
        abi = berkas(r"ActionBarMenuItem\.java", "ActionBar")
        ab = berkas(r"ActionBar\.java", "ActionBar")
        log("[C1] berkas di folder ActionBar")
        if ab:
            log("  " + ", ".join(sorted(q.name for q in ab.parent.iterdir() if q.suffix == ".java")))
        log("[C2] ActionBarMenu: addItemWithWidth (22 baris)")
        mulai(abm, r"ActionBarMenuItem\s+addItemWithWidth\s*\(", 0, 22)
        log("[C2b] ActionBarMenu: getItem(int) (8 baris)")
        mulai(abm, r"\bgetItem\s*\(\s*int", 0, 8)
        log("[C2c] ActionBarMenu: setItemVisibility (8 baris)")
        mulai(abm, r"void\s+setItemVisibility\s*\(", 0, 8)
        log("[C2d] ActionBarMenu: onMeasure/onLayout/dispatchDraw (10 baris tiap)")
        mulai(abm, r"void\s+onMeasure\s*\(", 0, 10)
        mulai(abm, r"void\s+onLayout\s*\(", 0, 10)
        log("[C3] ActionBarMenuItem: setVisibility / override (konteks 3)")
        if abi:
            bl = terapkan.baca(abi).splitlines()
            n = 0
            for i, b in enumerate(bl):
                if re.search(r"void\s+setVisibility\s*\(", b):
                    for k in range(i, min(len(bl), i + 8)):
                        log("  %d: %s" % (k + 1, bl[k].rstrip()[:150]))
                    n += 1
                    if n >= 2:
                        break
            if not n:
                log("  (tidak ada override setVisibility)")
        log("[C4] ActionBar: createActionMode (22 baris)")
        mulai(ab, r"ActionBarMenu\s+createActionMode\s*\(\s*boolean", 0, 22)
        log("[C4b] ActionBar: showActionMode (60 baris)")
        mulai(ab, r"void\s+showActionMode\s*\(", 0, 60)
        log("[C5] ChatActivity: sebelum dan sekitar pembuatan item action mode (45 baris)")
        mulai(ca, r"actionModeViews\.add\(actionMode\.addItemWithWidth\(save_to", 18, 45)
        log("[C6] ChatActivity: penentu tampil item action mode saat memilih (85 baris)")
        mulai(ca, r"ActionBarMenuItem\s+saveItem\s*=\s*actionBar\.createActionMode\(\)\.getItem\(save_to\)", 12, 85)
        log("[C7] ChatActivity: loop actionModeViews di showActionMode (30 baris)")
        mulai(ca, r"for\s*\(int a = 0; a < actionModeViews\.size\(\); a\+\+\)", 14, 30)
        log("[C8] ChatActivity: pemanggil selectedMessagesIds.clear terdekat hideActionMode? (hanya nama metode)")
        if ca:
            bl = terapkan.baca(ca).splitlines()
            for i, b in enumerate(bl):
                if re.search(r"actionBar\.hideActionMode\(|actionBar\.showActionMode\(|void\s+clearSelectionMode\(", b):
                    log("  %d: %s" % (i + 1, b.strip()[:150]))
    except Exception as e:  # noqa: BLE001
        log("(diagnosa bilah atas gagal sebagian: %s)" % e)
    judul("AKHIR DIAGNOSA KODE TELEGRAM")
    raise DiagnosaKode("Mode diagnosa bilah atas (mode_diagnosa_bilah=true): build dihentikan sengaja sebelum Gradle. "
                       "Salin log di antara 'DIAGNOSA KODE TELEGRAM' dan 'AKHIR DIAGNOSA KODE TELEGRAM', lalu kirim ke Claude.")


def diagnosa(up):
    judul("DIAGNOSA (salin bagian ini bila meminta bantuan)")
    try:
        if up and Path(up).is_dir():
            up = Path(up)
            log("Folder utama kode Telegram: " + ", ".join(sorted(p.name for p in up.iterdir() if p.name != ".git")))
            for g in terapkan.cari(up, r"build\.gradle(\.kts)?")[:12]:
                for i, b in enumerate(terapkan.baca(g).splitlines(), 1):
                    if re.search(r"productFlavors|flavorDimensions|applicationId|abiFilters|signingConfig|storeFile|"
                                 r"google-services|compileSdk|ndkVersion|checkVisibility|getProps", b):
                        log("  %s:%d: %s" % (g.relative_to(up), i, b.strip()[:160]))
    except Exception as e:  # noqa: BLE001
        log("(diagnosa gagal: %s)" % e)


def diagnosa_ukuran(up):
    """Cetak pengaturan build dan ukuran isi kode Telegram yang memengaruhi ukuran APK, lalu berhenti
    sebelum Gradle (mode_diagnosa_ukuran=true). Cukup salin log ini; tidak perlu menunggu build penuh."""
    up = Path(up)
    judul("DIAGNOSA UKURAN APK (salin dari baris ini sampai akhir diagnosa)")
    pola = (r"com\.android\.(application|tools\.build)|compileSdk|minSdk|targetSdk|packaging|jniLibs|useLegacyPackaging|"
            r"extractNativeLibs|minifyEnabled|isMinifyEnabled|shrinkResources|proguardFiles|resConfig|resourceConfigurations|"
            r"abiFilters|splits|abi\s|universalApk|bundle\s*\{|language|aaptOptions|androidResources|noCompress|"
            r"externalNativeBuild|ndkVersion|ndk\s*\{|flavorDimensions|productFlavors|buildTypes|debuggable|"
            r"implementation|api\s|compileOnly|fileTree|distributionUrl")
    try:
        try:
            ref = jalankan(["git", "-C", str(up), "log", "-1", "--format=%H %cd"], tangkap=True, cek=False)
            log("Versi kode Telegram: " + (ref.stdout or "").strip())
        except Exception:  # noqa: BLE001
            pass
        log("[U1] berkas gradle dan manifest yang relevan")
        calon = []
        for dp, dn, fn in os.walk(up):
            dn[:] = [d for d in dn if d not in (".git", "build", ".gradle", "node_modules", "jni", "java")]
            for f in fn:
                if f in ("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                         "gradle-wrapper.properties", "AndroidManifest.xml", "gradle.properties"):
                    calon.append(Path(dp) / f)
        for g in sorted(calon):
            rel = g.relative_to(up)
            if len(rel.parts) > 4:
                continue
            baris = terapkan.baca(g).splitlines()
            if g.name == "AndroidManifest.xml":
                hit = [(i, b) for i, b in enumerate(baris, 1) if re.search(r"extractNativeLibs|android:minSdk|uses-sdk|largeHeap|<application", b)]
            else:
                hit = [(i, b) for i, b in enumerate(baris, 1) if re.search(pola, b)]
            if not hit:
                continue
            log("--- %s (%d baris)" % (rel, len(baris)))
            for i, b in hit[:120]:
                log("  %d: %s" % (i, b.rstrip()[:170]))
        log("[U2] ukuran isi tiap modul (MB), berdasarkan jenis")
        def ukuran(d):
            t = 0
            for dp, dn, fn in os.walk(d):
                for f in fn:
                    try:
                        t += (Path(dp) / f).stat().st_size
                    except OSError:
                        pass
            return t
        for mod in sorted(p for p in up.iterdir() if p.is_dir() and (p / "build.gradle").is_file() or (p / "build.gradle.kts").is_file()):
            main = mod / "src" / "main"
            if not main.is_dir():
                continue
            log("--- modul %s" % mod.name)
            for sub in ("res", "assets", "jniLibs", "java", "jni"):
                d = main / sub
                if d.is_dir():
                    log("  %-8s %8.2f MB" % (sub, ukuran(d) / 1048576))
            res = main / "res"
            if res.is_dir():
                kel = {}
                for d in res.iterdir():
                    if d.is_dir():
                        k = re.split(r"[-]", d.name)[0]
                        kel[k] = kel.get(k, 0) + ukuran(d)
                log("  res per jenis: " + ", ".join("%s=%.2f" % (k, v / 1048576) for k, v in sorted(kel.items(), key=lambda x: -x[1])[:12]))
                bahasa = [d.name for d in res.iterdir() if d.is_dir() and d.name.startswith("values-") and
                          re.fullmatch(r"values-[a-z]{2,3}(-r[A-Z]{2})?", d.name)]
                lb = sum(ukuran(res / n) for n in bahasa)
                log("  folder bahasa (values-xx): %d buah, total %.2f MB" % (len(bahasa), lb / 1048576))
                dens = {}
                for d in res.iterdir():
                    m = re.search(r"-(ldpi|mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi|nodpi|anydpi)", d.name)
                    if d.is_dir() and m:
                        dens[m.group(1)] = dens.get(m.group(1), 0) + ukuran(d)
                log("  gambar per kepadatan: " + ", ".join("%s=%.2f" % (k, v / 1048576) for k, v in sorted(dens.items(), key=lambda x: -x[1])))
            besar = []
            for sub in ("res", "assets", "jniLibs", "libs"):
                for dp, dn, fn in os.walk(mod / "src" / "main" / sub if sub != "libs" else mod / "libs"):
                    for f in fn:
                        fp = Path(dp) / f
                        try:
                            besar.append((fp.stat().st_size, fp))
                        except OSError:
                            pass
            besar.sort(key=lambda x: -x[0])
            log("  20 berkas terbesar (res/assets/jniLibs/libs):")
            for sz, fp in besar[:20]:
                log("    %7.2f MB  %s" % (sz / 1048576, fp.relative_to(up)))
        log("[U3] pustaka .aar/.jar/.so di repo (ukuran)")
        for dp, dn, fn in os.walk(up):
            dn[:] = [d for d in dn if d not in (".git", "build", ".gradle", "res")]
            for f in fn:
                if f.endswith((".aar", ".jar", ".so")):
                    fp = Path(dp) / f
                    log("  %7.2f MB  %s" % (fp.stat().st_size / 1048576, fp.relative_to(up)))
    except Exception as e:  # noqa: BLE001
        log("(diagnosa ukuran gagal sebagian: %s)" % e)
    log("--- AKHIR DIAGNOSA UKURAN ---")
    raise DiagnosaKode("Mode diagnosa ukuran (mode_diagnosa_ukuran=true): build dihentikan sengaja sebelum Gradle. "
                       "Salin log dari baris DIAGNOSA UKURAN APK sampai AKHIR DIAGNOSA UKURAN, lalu set mode_diagnosa_ukuran=false.")


def main():
    up = None
    try:
        if PENANDA_GAGAL.is_file() and time.time() - PENANDA_GAGAL.stat().st_mtime < 12 * 3600:
            raise Berhenti("Pembangunan sebelumnya di mesin ini sudah gagal; tidak diulang. "
                           "Lihat log langkah pertama yang gagal.")
        judul("Novan Tel - Telegram editan (tahap 22)")
        cfg = kumpulkan_konfig()
        periksa_kredensial(cfg)
        bersihkan_disk()
        up = unduh_upstream(cfg)
        if terapkan.bool_str(cfg.get("mode_diagnosa_ukuran", "false")) == "true":
            diagnosa_ukuran(up)
        if terapkan.bool_str(cfg.get("mode_diagnosa_kode", "false")) == "true":
            diagnosa_kode(up)
        if terapkan.bool_str(cfg.get("mode_diagnosa_bilah", "false")) == "true":
            diagnosa_bilah_atas(up)
        judul("Menerapkan editan Novan Tel")
        terapkan.jalankan(up, cfg, ROOT / "overlay")
        pakai_so_jadi(up, cfg)
        kunci = siapkan_kunci(up)
        pasang_penandatanganan_upstream(up, kunci)
        pasang_komponen_sdk(up)
        modul = cari_modul_aplikasi(up)
        kompres_so(up, modul, cfg)
        bangun_gradle(up, modul, cfg.get("arsitektur", "semua").strip().lower())
        tandatangani(up, kunci)
        judul("SELESAI")
        log("APK Novan Tel siap: build/outputs/apk/release/NovanTel.apk")
    except DiagnosaKode as e:
        log("\n::error::%s" % e)
        sys.exit(1)
    except (Berhenti, terapkan.Fatal) as e:
        log("\n::error::%s" % e)
        diagnosa(up)
        PENANDA_GAGAL.parent.mkdir(parents=True, exist_ok=True)
        PENANDA_GAGAL.write_text(str(e), encoding="utf-8")
        sys.exit(1)
    except Exception:  # noqa: BLE001
        log("\n::error::Galat tak terduga di tools/bangun.py")
        traceback.print_exc()
        diagnosa(up)
        PENANDA_GAGAL.parent.mkdir(parents=True, exist_ok=True)
        PENANDA_GAGAL.write_text("galat tak terduga", encoding="utf-8")
        sys.exit(1)


if __name__ == "__main__":
    main()
