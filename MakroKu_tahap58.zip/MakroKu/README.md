# MakroKu — Aplikasi Otomatisasi Android (Pemicu · Batasan · Aksi)

Aplikasi otomatisasi bergaya "makro": setiap **makro** = satu/lebih **pemicu** + **batasan** (opsional) + daftar **aksi**.
Ditulis dengan Kotlin + Jetpack Compose, tanpa library pihak ketiga selain AndroidX, coroutines, dan kotlinx.serialization.

> Catatan jujur: ini implementasi orisinal dengan konsep yang setara, bukan salinan kode/merek aplikasi mana pun.
> MacroDroid memiliki ratusan pemicu/aksi dan sebagian memakai root/ADB/izin sistem; di sini disediakan inti mesin
> yang lengkap + katalog yang mudah diperluas.

## Fitur

**Pemicu awal (42; total kini 89):** jadwal waktu (hari+jam) · interval berkala · level baterai (melewati ambang) · pengisi daya ·
boot · layar hidup/mati · Wi-Fi on/off · Bluetooth on/off · mode pesawat · headphone · SMS masuk (filter pengirim/isi) ·
panggilan masuk · notifikasi (filter paket/teks) · aplikasi dibuka (Aksesibilitas) · intent/broadcast kustom · manual/pintasan · layar dibuka · aplikasi dipasang/dihapus · perangkat Bluetooth tersambung/terputus · panggilan berakhir · guncang (shake) · Wi-Fi tersambung/terputus (SSID) · lokasi masuk/keluar area (geofence) · variabel berubah.

**Batasan awal (21; total kini 40):** rentang waktu (lintas tengah malam) · hari · level baterai · mengisi daya · status layar · Wi-Fi · nilai variabel · variabel dibanding (>, <, mengandung…) · mode pesawat · Bluetooth · mode dering · tanggal dalam bulan · headphone · ada internet · layar terkunci.

**Aksi awal (78; total kini 173, sebagian adalah percabangan dan ulangan):** toast · notifikasi · getar · buka aplikasi · buka URL · Wi-Fi · Bluetooth · volume · mode dering · DND ·
senter · kirim SMS · telepon · TTS · putar suara · papan klip · kecerahan · jeda · variabel (set/tambah/gabung/hapus) ·
HTTP request · kirim intent · **Perintah shell via ADB** · **If/Else** berdasarkan variabel (bersarang) · If/Else perbandingan · ulangi (loop) · hentikan makro · jalankan makro lain · variabel acak · tulis log · data seluler / mode pesawat / NFC / paksa berhenti / aktifkan-nonaktifkan aplikasi / ketuk / geser / tombol / ketik / tangkapan layar (via ADB) · aksi sistem Aksesibilitas (back, home, recents, notifikasi, pengaturan cepat, kunci layar, screenshot) · kontrol media · volume naik/turun/bisu · speaker telepon · bisukan mikrofon · nyalakan layar · rotasi · waktu layar mati · buka halaman pengaturan · alarm · timer · email · hapus notifikasi.

**Lainnya:** variabel global · placeholder teks (`{var:x} {time} {date} {battery} {sms_sender} {sms_body} {notif_title}
{notif_text} {call_number}`) · 10 templat siap pakai · log aktivitas · ekspor/impor JSON · pintasan layar utama ·
layanan latar depan + mulai otomatis saat boot · UI terang/gelap.

## Cara membangun lewat GitHub Actions

Unggah isi folder ini ke repo GitHub (termasuk `.github/workflows/build.yml`). Setiap push, atau tombol Run workflow di tab Actions, membangun APK debug. Unduh dari Artifacts → `MakroKu-debug`. Bila gagal, kirim log langkah yang merah.

## Cara membangun (Android Studio, opsional)

1. Buka folder `MakroKu` di **Android Studio** (Koala atau lebih baru, JDK 17), tunggu sinkronisasi Gradle.
2. Jalankan ke perangkat/emulator (minSdk 30, targetSdk 34), atau `./gradlew assembleDebug`.
3. Di aplikasi: **⋮ → Pengaturan & izin**, lalu berikan izin yang dibutuhkan makro Anda.

> Proyek ini dibuat tanpa Android SDK di lingkungan penyusunnya, jadi **belum pernah dikompilasi di sini**.
> Jika Android Studio menampilkan galat kompilasi kecil, kirimkan pesannya agar bisa diperbaiki.

## Tahap 2 — Izin lewat ADB (pm grant / appops / settings)

Menu ⋮ → **Izin via ADB** menampilkan 9 langkah, status ✓/✗ tiap izin, tombol salin perintah, dan tombol
**Aktifkan otomatis** untuk Aksesibilitas & Akses Notifikasi. Dari PC cukup jalankan sekali:

```
sh scripts/setup_permissions.sh      # Linux/macOS
scripts\setup_permissions.bat        # Windows
```

Kunci utamanya `adb shell pm grant com.makroku.automation android.permission.WRITE_SECURE_SETTINGS`.
Setelah itu aksi baru **Ubah pengaturan sistem (settings put)** bisa menulis namespace `secure`/`global`
(dan `system` bila WRITE_SETTINGS aktif), mis. `global` `stay_on_while_plugged_in` = `3`.
Izin hilang jika aplikasi dipasang ulang. Aplikasi tidak bisa memberi izin ke aplikasi lain (itu butuh shell, bukan app biasa).

## Tahap 3 — ADB Wi-Fi bawaan tanpa Shizuku (meniru PisahSuara)

Menu ⋮ → **Izin via ADB** kini punya kartu **ADB Wi-Fi bawaan**: tanpa PC dan tanpa Shizuku.

1. Nyalakan Wi-Fi dan Opsi pengembang → Debugging nirkabel.
2. Ketuk **Mulai pairing**, buka "Pasangkan perangkat dengan kode pairing", ketik kode 6 angka di notifikasi MakroKu (kolom balasan).
3. Setelah berhasil, MakroKu menyambung sendiri, memberi diri WRITE_SECURE_SETTINGS, lalu pindah ke 127.0.0.1:5555 sehingga Wi-Fi boleh dimatikan.
4. Ketuk **Beri semua izin otomatis** untuk memberi seluruh izin (pm grant, appops, DND, baterai, Aksesibilitas, Akses Notifikasi) sekaligus.
5. Aksi baru **Perintah shell via ADB** menjalankan perintah apa pun (tanpa awalan `adb shell`), keluarannya bisa disimpan ke variabel.

Setelah HP restart: bila Wi-Fi menyala, MakroKu menyambung dan pindah ke mode lokal lagi sendiri (lewat penerima boot).
Kode ADB ada di paket `adb/` (Adb, PairHelper, PairReceiver, AdbBackend, Lokal) — disalin dan disederhanakan dari PisahSuara.
Dependensi baru: libadb-android, sun-security-android, conscrypt-android (via jitpack.io). minSdk naik ke 30 (Debugging nirkabel butuh Android 11+).
Belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 4 — Fitur ala MacroDroid

- Pemicu, aksi, dan batasan baru (daftar di bagian Fitur). Aksi Wi-Fi dan Bluetooth kini memakai ADB bawaan bila sudah dipasangkan (benar-benar menyala/mati di Android 10+), dan kembali ke cara lama bila tidak.
- Aksi bertanda (ADB) butuh pairing sekali di menu Izin via ADB. Aksi "Aksi sistem" butuh layanan Aksesibilitas MakroKu aktif. "Hapus notifikasi" butuh Akses Notifikasi.
- Geofence butuh izin lokasi (termasuk lokasi latar belakang); "Beri semua izin otomatis" memberikannya lewat ADB. Pengecekan tiap ±60 detik atau 30 meter.
- Pemicu Guncang dan Geofence hanya mengaktifkan sensor/lokasi bila ada makro aktif yang memakainya.
- 8 templat baru (guncang senter, musik headphone, geofence, loop, dll).
- Baru, belum diuji di perangkat.

## Tahap 33 — Keep Device Awake dan pemicu/aksi baru

- Aksi **Jaga perangkat tetap terjaga (Keep Device Awake)** disamakan dengan MacroDroid: nyalakan atau matikan, mode **Layar tetap menyala** atau **Hanya CPU** (layar boleh mati), lama dalam detik (0 = sampai dimatikan). Mengaktifkan lagi menggantikan penjagaan sebelumnya; satu aksi dengan Aktifkan mati menghentikannya. Penjaga makro otomatis di mesin (maks 30 menit selama makro berjalan) tetap ada.
- Pemicu baru (9): GPS menyala/mati, panggilan tersambung, screensaver, Doze, bahasa berubah, dok, hotspot, NFC, musik diputar.
- Aksi baru (13): ucapkan jam, ucapkan baterai, buka riwayat panggilan, buka telepon dengan nomor, copot aplikasi, info aplikasi, cari di peta, tambah acara kalender, getar dengan pola, kosongkan papan klip, jawab panggilan, akhiri panggilan.
- Jawab/akhiri panggilan butuh izin ANSWER_PHONE_CALLS (ikut diberikan oleh \"Beri semua izin otomatis\"). Pemicu Hotspot bergantung pada siaran sistem yang tidak sama di semua perangkat.
- 2 templat baru (layar menyala saat mengisi daya, matikan penjagaan saat dicabut).
- Baru, belum pernah dikompilasi dan belum diuji di perangkat.

## Tahap 34 — Sensor dan aksi jaringan

- Pemicu baru (2): **Sensor cahaya melewati batas** (lux, lebih gelap atau lebih terang) dan **Layar berputar mendatar atau tegak**. Keduanya hanya mengaktifkan sensor bila ada makro aktif yang memakainya.
- Aksi baru (6): hapus riwayat panggilan (izin WRITE_CALL_LOG, ikut diberikan oleh "Beri semua izin otomatis"), jeda acak, kirim paket UDP, Wake-on-LAN, simpan info perangkat ke variabel, simpan lokasi terakhir ke variabel (nama, nama_lat, nama_lon).
- Belum ada: ambil foto, perubahan papan klip, panggilan keluar (Android membatasi atau butuh izin khusus).
- Baru, belum pernah dikompilasi dan belum diuji di perangkat.

## Tahap 35 — Pemicu dan aksi tambahan ala MacroDroid

**Pemicu baru (10):** volume suara berubah (per aliran) · panggilan keluar dimulai · tema gelap nyala atau mati · VPN tersambung atau terputus · internet tersedia atau hilang · alarm berikutnya di jam berubah · kecerahan layar diubah · tombol pada notifikasi MakroKu diketuk · aplikasi diperbarui · satu kali pada tanggal dan jam tertentu (format 2026-12-31).
VPN, internet, dan kecerahan hanya dipantau bila ada makro aktif yang memakainya. Kejadian VPN dan internet dalam 1,5 detik pertama setelah pemantauan mulai hanya dicatat, tidak memicu.

**Aksi baru (18):** keluar dari ulangan (break) · lompat ke putaran berikutnya (continue) · stopwatch bernama · matikan atau mulai ulang ponsel (ADB) · hentikan proses latar aplikasi (ADB) · rekam layar (ADB, maks 180 detik) · buka asisten suara · kirim kode USSD · aktifkan atau nonaktifkan satu kategori makro · unduh berkas · ping atau uji port TCP · simpan info jaringan ke variabel (SSID, IP, sinyal, jenis, operator) · simpan papan klip ke variabel · dialog isian teks ke variabel · ukuran font · warna layar (normal, terbalik, abu-abu) · operasi berkas (salin, pindah, ada, ukuran) · hentikan suara.

**Aksi yang diperluas:** Tampilkan notifikasi kini bisa punya 2 tombol (isi Tombol 1 dan 2, lalu pakai pemicu Tombol notifikasi) · Permintaan HTTP punya kolom header (satu per baris, `Nama: nilai`) · Olah teks punya 9 operasi baru (kode URL, Base64, MD5, SHA 256, balik, huruf besar awal kata, hitung kemunculan).

**Batasan baru (4):** tema gelap · musik sedang diputar · keadaan telepon (siaga, berdering, bicara) · VPN tersambung.

**Templat baru (6):** kirim lokasi lewat SMS · ping server tiap 15 menit · notifikasi tombol Ya atau Tidak (dua makro) · ucapkan saat VPN tersambung · contoh break di ulangan.

Catatan jujur tentang batas Android:
- Panggilan keluar tidak membawa nomor tujuan (butuh izin PROCESS_OUTGOING_CALLS yang dibatasi Play Store).
- Papan klip di Android 10 ke atas sering kosong bila dibaca dari latar belakang; aksi mencatat peringatan di Log.
- Stopwatch hidup di memori, jadi hilang bila proses dimatikan sistem.
- Pemicu Alarm berikutnya berubah memicu saat alarm dibuat, diubah, dihapus, atau baru berbunyi; tidak bisa membedakan "berbunyi" dari "dimatikan".
- Daya, rekam layar, dan hentikan proses latar butuh pairing ADB bawaan. Font butuh izin Ubah pengaturan sistem atau ADB. Warna layar butuh WRITE_SECURE_SETTINGS atau ADB.
- Belum ada (butuh izin atau layanan yang tidak tersedia untuk aplikasi biasa): ambil foto, rekam suara, perubahan papan klip, SMS terkirim, cuaca, pengenalan aktivitas, menara seluler, kirim email lewat SMTP.
- Versi 1.19.0. Baru, belum pernah dikompilasi penuh dan belum diuji di perangkat; hanya diperiksa sintaksnya.

## Tahap 37 — Pemicu, aksi, dan batasan baru lewat ADB bawaan

Total kini 82 pemicu, 173 aksi, 40 batasan. Versi 1.21.0. Semua yang bertanda "butuh ADB" memakai pairing ADB bawaan (tanpa PC).

**Pemicu baru (4):**
- **Aplikasi mulai atau berhenti berjalan:** isi nama paket. Dicek tiap 10 detik dengan `pidof`. Bacaan pertama hanya acuan.
- **Aplikasi di depan berubah, tanpa Aksesibilitas:** dicek tiap 4 detik saat layar menyala. Nama paket kosong = aplikasi apa pun. Tersedia `{app_pkg}` dan `{app_activity}`.
- **Berkas baru muncul di folder:** folder harus di `/sdcard`, `/storage/emulated/0`, atau `/data/local/tmp`. Dicek tiap 10 detik. Boleh disaring dengan teks nama. Tersedia `{file_name}` dan `{file_path}`. Paling banyak 5 berkas baru per pemeriksaan. Berkas tersembunyi (awalan titik, mis. unduhan yang belum selesai) tidak dihitung.
- **Aplikasi berhenti sendiri karena galat:** dibaca dari log crash tiap 15 detik. Tersedia `{app_pkg}`. Hanya galat Java, bukan crash native.

**Aksi baru (14):**
- Aplikasi: bekukan atau lepaskan (`pm suspend`) · atur bucket siaga (`am set-standby-bucket`) · mulai ulang (hentikan paksa lalu buka lagi) · simpan daftar aplikasi terpasang ke variabel · cek izin aplikasi ke variabel (true atau false).
- Sistem: jadikan peluncur layar utama bawaan · Penghemat Data nyala atau mati (bisa ganti otomatis) · layar tetap menyala saat dicolok · mode USB (transfer berkas, foto, MIDI, tethering, hanya mengisi daya) · bersihkan cache semua aplikasi.
- Informasi ke variabel: baca penyedia konten (mis. SMS terakhir, kontak) · suhu perangkat dari sensor termal (CPU, baterai, tertinggi) · baris log sistem terbaru dengan saringan teks · info memori RAM (tanpa ADB).

**Batasan baru (3):** aplikasi sedang berjalan · memori RAM tersedia (tanpa ADB) · aplikasi diberi izin tertentu.

**Templat baru (3):** ucapkan nama berkas baru di Download · ucapkan saat aplikasi berhenti sendiri · buka lagi aplikasi yang berhenti sendiri (ganti nama paket dulu).

Pengaman dan catatan jujur:
- Bekukan aplikasi menolak: sistem inti, MakroKu, aplikasi yang sedang jadi layanan Aksesibilitas (pembaca layar), dan keyboard aktif. Ini supaya pembaca layar atau keyboard tidak ikut terkunci. Bucket Jarang dan Terbatas juga menolak paket yang sama.
- Baca penyedia konten hanya menerima alamat `content://...` dan nama kolom sederhana. Hasilnya baris pertama; nilai yang punya beberapa baris tetap utuh. Jangan taruh `{sms_body}` atau teks dari luar di kolom Syarat pencarian.
- Bersihkan cache hanya bekerja bila ruang kosong lebih kecil dari angka yang diisi.
- `pm suspend`, bucket siaga, Penghemat Data, mode USB, dan sensor termal bisa berbeda atau ditolak di sebagian perangkat; galatnya dicatat di Log.
- Buka lagi aplikasi yang berhenti sendiri bisa berputar terus bila aplikasi itu selalu berhenti. Makro templat menunggu 5 detik dulu.
- Pemantau ADB hanya jalan bila ada makro aktif yang memakainya dan ADB sudah dipasangkan.
- Baru, belum pernah dikompilasi dan belum diuji di perangkat; hanya diperiksa: semua cabang `when` ada, tidak ada nama ganda, kurung seimbang.

## Tahap 38 — Pilih kunci pengaturan dari daftar

- Di aksi Ubah pengaturan sistem, pemicu Pengaturan sistem berubah, dan aksi Simpan pengaturan ke variabel, kolom Kunci punya tombol **Pilih dari daftar**.
- Daftar mengikuti namespace yang dipilih (system, secure, global), diurutkan abjad, ada kolom Cari. Tiap baris membacakan nama dan nilai sekarang.
- Cara baca: lewat penyedia pengaturan dulu, lalu ADB (`settings list`), lalu daftar konstanta Settings.Global. Bila semua gagal, muncul pesan dan kunci bisa diketik sendiri.
- Ganti namespace dulu, baru ketuk Pilih dari daftar. Versi 1.22.0. Baru, belum pernah dikompilasi dan belum diuji di perangkat.

## Tahap 39 — Ubah pengaturan sistem lewat ADB, saklar Opsi pengembang

- Aksi **Ubah pengaturan sistem Android** kini bisa menulis lewat ADB bawaan bila izin WRITE_SECURE_SETTINGS belum ada (sebelumnya langsung gagal). Untuk namespace system bila izin Ubah pengaturan sistem belum ada, juga lewat ADB.
- Menu Izin via ADB: saklar **Jangan nyalakan Opsi pengembang otomatis**. Nyala = MakroKu tidak lagi mengisi development_settings_enabled kembali ke 1 saat ADB tersambung atau HP menyala. Debugging nirkabel tetap dinyalakan.
- Menu Pengaturan di HP biasanya baru berubah setelah aplikasi Pengaturan ditutup lalu dibuka lagi. Sebagian merek memakai kunci lain. Versi 1.23.0. Baru, belum pernah dikompilasi dan belum diuji di perangkat.

## Struktur

```
app/src/main/java/com/makroku/automation/
├── model/    Models.kt (Macro, pemicu/aksi/batasan), Catalog.kt (katalog, label, templat)
├── data/     MacroRepository.kt (JSON file + variabel + log)
├── engine/   MacroEngine, TriggerMatcher, ConstraintChecker, ActionExecutor (+Magic text), Scheduler (AlarmManager)
├── adb/      Adb, PairHelper, PairReceiver, AdbBackend, Lokal (ADB Wi-Fi mandiri)
├── service/  AutomationService (receiver sistem), Alarm/Boot receiver, NotificationListener, AccessibilityService
└── ui/       MainActivity, HomeScreen/Logs/Variables/Templates/Settings, EditorScreen (form generik), RunMacroActivity
```

## Menambah pemicu/aksi baru

1. Tambah `@Serializable @SerialName("...") data class` di `Models.kt`.
2. Daftarkan di `Catalog.kt` (label + nilai default) — form editor dibuat otomatis dari propertinya.
3. Pemicu: tambahkan cabang di `TriggerMatcher` (dan sumber kejadian di `SystemEventReceiver`).
   Aksi: tambahkan cabang di `ActionExecutor.exec`. Batasan: cabang di `ConstraintChecker.check`.

## Batasan platform Android (berlaku untuk semua aplikasi sejenis)

- Wi-Fi: Android 10+ hanya bisa membuka panel sistem, tidak bisa menyala/mati otomatis.
- Bluetooth: Android 13+ menolak `enable()/disable()` dari aplikasi biasa.
- Data seluler, mode pesawat, kunci layar, dan klik layar tak terjadwal memerlukan root/ADB/Device Admin (belum ada).
- Pemicu "Aplikasi dibuka" butuh layanan Aksesibilitas; "Notifikasi" butuh Akses Notifikasi.
- Nomor penelepon (`call_number`) bisa kosong di Android 9+ tanpa izin READ_CALL_LOG.
- Pabrikan tertentu (Xiaomi, Oppo, dll.) mematikan layanan latar belakang: aktifkan "Mulai otomatis" dan abaikan optimasi baterai.

## Belum ada (ide pengembangan)

Widget layar utama · pemicu lokasi/geofence, Wi-Fi SSID, gesture shake, NFC, sensor · loop/while · aksi layar & kunci ·
integrasi Tasker/Webhook · Room/DB untuk log skala besar.

## Tahap 5 — Sinkronisasi data otomatis + pemicu/aksi baru

**Jadwal sinkronisasi:** buat dua makro. Pemicu "Jadwal waktu" jam nyala + aksi "Sinkronisasi data otomatis" (aktif). Lalu satu lagi jam mati + aksi yang sama (mati). Sudah ada dua templat siap pakai: "Sinkron data nyala (pagi)" dan "Sinkron data mati (malam)".
Izin `WRITE_SYNC_SETTINGS` diberikan otomatis saat pemasangan, tanpa ADB.

**Pemicu baru (5):** mode dering berubah · hemat baterai nyala/mati · Jangan ganggu nyala/mati · sinkronisasi otomatis nyala/mati · data seluler tersedia/hilang.

**Aksi baru (6):** sinkronisasi data otomatis · kecerahan otomatis · hemat baterai · mode gelap (ADB) · aktifkan/nonaktifkan makro · bagikan teks.

**Batasan baru (3):** sinkronisasi nyala · hemat baterai nyala · Jangan ganggu nyala.

## Tahap 6 — Pemicu, aksi, batasan tambahan

**Pemicu baru (3):** jadwal bulanan (tanggal) · ganti hari (tengah malam) · USB tersambung/terputus (bergantung merek HP).

**Aksi baru (7):** buka kamera · tulis ke berkas teks · hapus log makro · bunyikan ponsel (cari HP) · hentikan ucapan (TTS) · If/Else jam · If/Else baterai.

**Batasan baru (1):** memakai data seluler.

Templat baru: "Pengingat awal bulan", "Cari HP lewat SMS" (ganti ISI_NOMOR dulu), "Catat tiap ganti hari".
Berkas dari aksi "Tulis ke berkas teks" ada di folder data aplikasi (Android/data/com.makroku.automation/files).

## Tahap 7 — Ganti otomatis (toggle) dan editor lebih lengkap

**Ganti otomatis:** aksi Sinkronisasi, Wi-Fi, Bluetooth, Senter, Data seluler, Mode pesawat, NFC, Lokasi, Kecerahan otomatis, Hemat baterai, Speaker telepon, dan Bisukan mikrofon punya saklar "Ganti otomatis". Bila nyala, aksi membalik kondisi sekarang (nyala jadi mati, mati jadi nyala) dan pilihan "Aktifkan" diabaikan. Mode gelap: pilih `toggle`.

**Banyak pemicu dan aksi dalam satu makro:** tambah sebanyak perlu. Pemicu: salah satu cukup. Aksi: berurutan. Tiap item bisa Naik, Turun, Gandakan, Ubah, Hapus (semuanya punya label untuk pembaca layar). Daftar pilihan punya kolom Cari.

**Batasan:** saklar "Batasan: salah satu cukup" (mati = semua harus terpenuhi).

Templat baru: "Ganti sinkronisasi (tombol)", "Ganti Wi-Fi (tombol)", "Contoh banyak pemicu dan aksi".

## Tahap 8 — Fitur baru + ramah pembaca layar

**Pemicu baru (3):** panggilan terlewat · notifikasi dihapus · beberapa jam sehari (daftar jam, mis. 06:00,12:00,18:00).
**Aksi baru (3):** buka chat WhatsApp (isi pesan; kirim tetap ketuk manual) · atur suara TTS (kecepatan, nada) · tunggu sampai variabel.
**Batasan baru (2):** Wi-Fi tertentu · aplikasi sedang dibuka (butuh Aksesibilitas).

**Pembaca layar (TalkBack):**
- Satu item = satu perhentian saat geser kanan: kartu makro, item pemicu/aksi/batasan, baris izin, baris log, variabel, templat.
- Tombol tambahan ada di menu Tindakan TalkBack: makro (matikan/nyalakan, jalankan, pintasan, hapus); item (naikkan, turunkan, gandakan, hapus). Ketuk dua kali pada item = ubah.
- Saklar punya nama dan status (nyala/mati) lewat satu ketukan pada barisnya.
- Judul bagian ditandai sebagai judul. Nama hari lengkap. Pilihan dropdown dibacakan "nama: nilai".
- Pengumuman suara setelah naik, turun, gandakan, hapus, dan simpan makro.

## Tahap 9 — Layar, sensor, teks/JSON/matematika

**Pemicu baru (3):** tombol volume ditekan (sebentar/tahan, bisa menahan perubahan volume) · sensor jarak dekat/jauh · ponsel dibalik (layar bawah/atas).
**Aksi baru (8):** ketuk teks/tombol di layar · gulir layar · isi kolom teks yang fokus · baca teks layar ke variabel · operasi teks (huruf besar/kecil, ganti, potong, regex, pisah, angka saja) · hitung matematika (+ - * / % dan kurung) · ambil nilai dari JSON (jalur seperti data.items.0.name) · selama variabel… (while).
**Templat baru (6):** tahan volume atas bacakan jam · balik ponsel senyap/normal · bacakan teks layar · ambil JSON dari web · hitung mundur.

**Perubahan penting izin:** layanan Aksesibilitas kini membaca isi layar (hanya saat aksi layar dijalankan) dan menangkap tombol volume.
Setelah memasang versi ini, matikan lalu nyalakan lagi layanan Aksesibilitas MakroKu di pengaturan, supaya izin barunya berlaku.
Respons HTTP yang disimpan di variabel http_response kini sampai 20.000 karakter (sebelumnya 2.000).
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 10 — Ubin Pengaturan Cepat dan Webhook lokal

**Pemicu baru (2):**
- **Ubin Pengaturan Cepat (1-3):** tambahkan ubin "MakroKu 1/2/3" lewat panel pengaturan cepat (ikon pensil, Edit). Mengetuk ubin menjalankan makro yang punya pemicu ini dengan nomor sama; nama makro jadi label ubin.
- **Webhook lokal (HTTP):** server kecil di port 8765 aktif hanya bila ada makro aktif yang memakainya. Contoh: `http://127.0.0.1:8765/ucap?teks=Halo`. Parameter menjadi placeholder `{wh_teks}`. Token kosong = hanya dari ponsel ini; token terisi (`?token=...`) = boleh dari perangkat lain di Wi-Fi yang sama. Tanpa enkripsi (HTTP biasa), jadi jangan pakai token yang juga Anda pakai di tempat lain.

**Templat baru (2):** Ubin 1 ganti senter · Webhook ucapkan pesan.
Belum ada: widget layar utama dan tombol melayang. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 11 — Widget layar utama

**Pemicu baru:** Widget layar utama (tombol 1-3). Tambahkan widget "MakroKu" ke layar utama (tekan lama layar utama, Widget). Widget punya 3 tombol; tiap tombol menampilkan nama makro yang memakai pemicu ini dengan nomor yang sama, dan mengetuknya menjalankan makro itu. Tombol kosong diberi nama "Tombol N (kosong)". Label diperbarui saat daftar makro berubah, dan tiap tombol punya deskripsi untuk pembaca layar.
**Templat baru:** Widget 1 bacakan baterai.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 12 — Tombol melayang

**Pemicu baru:** Tombol melayang. Tombol bulat kecil tampil di atas aplikasi lain, bisa digeser dengan jari, dan mengetuknya menjalankan makro. Satu makro = satu label (maksimal 3 label berbeda sekaligus). Tombol hanya muncul bila ada makro aktif yang memakainya dan izin "Tampil di atas aplikasi lain" aktif (menu Pengaturan & izin, atau lewat ADB bawaan). Tiap tombol punya deskripsi untuk pembaca layar.
**Templat baru:** Tombol melayang bacakan jam.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 13 — Daftar pilihan ramah pembaca layar

- **Pemilih pemicu/aksi/batasan** kini layar penuh (bukan kotak dialog kecil). Tiap pilihan = satu perhentian TalkBack yang langsung dibacakan namanya, ditambah urutan ("3 dari 40") dan peran tombol. Jumlah hasil pencarian diumumkan otomatis saat mengetik di kolom Cari.
- **Pilihan dropdown** di formulir (mode dering, perbandingan, tombol, dll.) memakai daftar layar penuh yang sama.
- **Nama pilihan berbahasa Indonesia**: mis. "Senyap" bukan `silent`, "Lebih besar dari" bukan `>`, "Ditahan" bukan `long`. Nilai yang tersimpan di makro tetap kode aslinya, jadi makro lama tetap berjalan.
- Ringkasan pemicu/aksi di daftar memakai "ya/tidak" dan nama pilihan Indonesia, bukan `true/false`.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 14 — Nama pilihan dan ringkasan item tanpa simbol

- **Nama pemicu, aksi, dan batasan** ditulis ulang sebagai kalimat Indonesia biasa tanpa simbol yang dieja aneh oleh pembaca layar: tanpa "…", garis miring, atau kurung, dan tanpa istilah teknis seperti If/Else, loop, while, settings put, boot, unlock. Contoh: "Percabangan: jika variabel sama dengan nilai", "Ulangi aksi beberapa kali", "Ketuk titik di layar, butuh ADB". Kebutuhan khusus ditulis di belakang nama ("butuh ADB", "butuh Aksesibilitas").
- **Ringkasan tiap item** di editor kini dibaca sebagai satu kalimat per parameter ("Jam: 8. Menit: 0. Hari: Senin, Selasa"), tanpa simbol "•" dan "=", dengan nama hari lengkap, dan diawali urutan ("2 dari 5").
- Nilai tersimpan di makro tidak berubah, jadi makro lama tetap berjalan.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.


## Tahap 19 — Magic Text, batasan bersarang

- Kolom teks punya tombol **Sisipkan variabel** (waktu, baterai, SMS, notifikasi, variabel global).
- Batasan **Gerbang logika** (AND, OR, XOR, NOT) bisa berisi batasan lain, bersarang berapa pun dalamnya.
- Batasan **Dijalankan oleh pemicu jenis tertentu** + gerbang logika = batasan per pemicu.
- Aksi **Jika batasan terpenuhi (Maka / Jika tidak)** = batasan per blok aksi.

## Tahap 21 — Menu tekan-tahan di mana-mana (ala MacroDroid)

**Tekan tahan (atau pilih "Buka menu" di Tindakan TalkBack, atau tombol ⋮ di tiap kartu):**

- **Pemicu / aksi / batasan di editor:** Ubah · Uji aksi ini sekarang (aksi saja, hasil di Log) · Nonaktifkan sementara / Aktifkan kembali · Balikkan batasan (NOT) / lepas NOT (batasan saja) · Salin · Potong · Tempel di atas / di bawah · Gandakan · Tambah baru di atas / di bawah · Naikkan / Turunkan satu langkah · Pindahkan ke paling atas / bawah · Hapus. Berlaku juga untuk item di dalam percabangan dan perulangan.
- **Makro di Beranda:** Jalankan sekarang · Ubah · Nyalakan/Matikan · Ganti nama · Pindahkan ke kategori lain · Gandakan (salinan nonaktif) · Bagikan atau salin JSON satu makro · Buat pintasan · Info lengkap · Hapus.
- **Kategori di Beranda:** makro dikelompokkan per kategori (ketuk untuk tutup/buka). Tekan tahan judul kategori: Nyalakan semua · Matikan semua · Ganti nama kategori.
- **Variabel:** Ubah nilai · Salin nama · Salin nilai · Salin penanda `{var:nama}` · Hapus.
- **Log:** Salin baris · Salin semua · Bagikan semua · Hapus semua.
- **Templat:** Tambahkan · Lihat isi templat (ketuk kartunya juga membuka isi).
- **Menu ⋮ di editor makro:** Simpan · Uji makro tersimpan · Gandakan · Bagikan · Hapus semua aksi.

**Item nonaktif:** disimpan sebagai pembungkus `off` di JSON makro (item aslinya utuh), tampil dicoret dan dibacakan "Dinonaktifkan", dilewati mesin: pemicu tidak memicu, aksi tidak jalan, batasan diabaikan. Makro lama tetap kompatibel.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 22 — Blok aksi dan mode pilih beberapa

- **Mode pilih beberapa:** tekan tahan item, pilih "Pilih beberapa, mulai dari ini". Ketuk item untuk memilih atau melepas, lalu: Pilih semua · Nonaktifkan · Aktifkan · Hapus · Simpan sebagai blok (aksi saja) · Selesai. TalkBack: tindakan "Pilih beberapa".
- **Blok aksi:** kumpulan aksi bernama yang dipakai ulang di banyak makro. Buat dari aksi terpilih (Simpan sebagai blok). Pakai lewat aksi baru "Jalankan blok aksi tersimpan" (isi nama blok). Kelola di menu ⋮ Beranda, Blok aksi: lihat isi, jalankan, ganti nama, hapus. Mengubah blok memengaruhi semua makro yang memakainya. Batas sarang 8 tingkat agar blok yang saling memanggil tidak berputar selamanya.
- Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 23 — Salin, potong, gandakan banyak item sekaligus

Di mode pilih beberapa, tombol baru **Salin**, **Potong**, dan **Gandakan** bekerja pada semua item terpilih. Hasil salinan bisa ditempel ke makro lain: tombol Tempel di judul bagian, atau menu tekan-tahan "Tempel N item di atas/di bawah" (urutan asli terjaga, termasuk item nonaktif). Hanya item yang jenisnya cocok dengan bagian tujuan yang ditempel.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 24 — Operasi variabel lebih lengkap

Aksi "Atur variabel" kini punya operasi: Atur nilai · Tambah · Kurangi · Kalikan · Bagi · Sisa bagi (angka) · Balik benar atau salah · Gabung teks di belakang atau di depan · Balik huruf besar dan kecil · Hapus. Pembagian dengan nol dicatat sebagai galat di Log. Variabel bertipe penuh dan variabel lokal per makro belum ada; sementara pakai awalan nama (mis. `kalkulator_hasil`) untuk memisahkan variabel antar makro.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 25 — Pemicu dan aksi baru

- **Pemicu:** Makro lain selesai dijalankan (isi nama makro; rantai maksimal 5 tingkat, makro tidak memicu dirinya sendiri).
- **Aksi:** Catatan di dalam makro (tidak melakukan apa-apa; tampil di daftar aksi) · Simpan tanggal atau jam ke variabel (format Java, mis. `EEEE` = nama hari) · Simpan level baterai ke variabel · Bunyikan bip pendek.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 26 — Baterai lebih lengkap dan pemicu shutdown

- **Pemicu:** Suhu baterai melewati batas (derajat Celsius, di atas atau di bawah) · Jenis pengisi daya saat dicolok (apa pun, adaptor dinding, USB, nirkabel) · Ponsel sedang dimatikan (siaran shutdown; aksi bisa terpotong saat HP mati).
- **Aksi:** Baca berkas teks ke variabel (pasangan aksi tulis berkas, maksimal 20.000 karakter) · Simpan volume suara ke variabel (persen) · Simpan info baterai ke variabel (suhu, tegangan, status pengisian, kesehatan, jenis pengisi daya).
- **Templat baru:** Peringatan baterai panas · Ucapkan jenis pengisi daya.
- Pemicu suhu hanya memicu saat suhu melintasi batas, bukan tiap perubahan. Pembacaan pertama setelah layanan mulai tidak memicu.
- Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 27 — Hanya 64-bit dan 32-bit, pemicu dan batasan baru

- **Arsitektur:** satu APK saja yang berisi 64-bit (`arm64-v8a`) dan 32-bit (`armeabi-v7a`), tanpa x86 dan tanpa pemisahan. Hasil build ada di Artifacts `MakroKu-debug`.
- **Pemicu baru:** Baterai penuh · Zona waktu berubah.
- **Aksi baru:** Hapus berkas teks · Simpan ruang penyimpanan kosong ke variabel (megabita).
- **Batasan baru:** Suhu baterai · Ruang penyimpanan kosong · Jenis pengisi daya.
- **Templat baru:** Baterai penuh, ucapkan.
- Versi 1.13.0. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 28 — Matahari terbit dan terbenam, aplikasi ditinggalkan

- **Pemicu:** Matahari terbit atau terbenam (isi lintang dan bujur kota Anda, mis. Jakarta -6.2 dan 106.8; selisih menit boleh negatif; dihitung di HP tanpa internet dan tanpa izin lokasi; di daerah kutub bisa tidak ada terbit atau terbenam) · Aplikasi ditinggalkan (nama paket kosong = aplikasi apa pun; butuh Aksesibilitas).
- **Templat baru:** Ucapkan saat matahari terbenam.
- Versi 1.14.0. Tetap satu APK berisi 64-bit dan 32-bit. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 29 — Aksi notifikasi: balas, ketuk, ambil isi

- **Aksi baru (butuh Akses Notifikasi):** Balas notifikasi chat (isi pesan balasan; nama paket kosong = aplikasi dari notifikasi pemicu; hanya notifikasi yang punya kolom balasan, seperti WhatsApp atau Telegram) · Ketuk notifikasi terbaru · Simpan isi, judul, atau keduanya dari notifikasi aktif ke variabel.
- **Templat baru:** Balas otomatis WhatsApp (ubah isi balasannya). Hati-hati: balasan otomatis ke semua pesan bisa mengganggu, tambahkan batasan bila perlu.
- Versi 1.15.0. Satu APK 64-bit dan 32-bit. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 30 — Pesan popup

- **Aksi baru:** Tampilkan pesan popup (judul, isi, tutup otomatis setelah beberapa detik, 0 = tetap sampai tombol OK ditekan). Isi boleh memakai placeholder seperti `{battery}` dan `{var:nama}`. Butuh izin Tampil di atas aplikasi lain (menu Pengaturan dan izin, atau lewat ADB bawaan) agar bisa muncul dari latar belakang.
- **Templat baru:** Popup saat baterai penuh.
- Versi 1.16.0. Satu APK 64-bit dan 32-bit. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 31 — Nada dering dan wallpaper

- **Aksi baru:** Atur nada dering bawaan (panggilan, notifikasi, atau alarm; isi alamat `content://...` nada, kosong = senyap; butuh izin Ubah pengaturan sistem) · Atur wallpaper dari berkas gambar (layar utama, layar kunci, atau keduanya; berkas ada di folder data aplikasi, `Android/data/com.makroku.automation/files`).
- **Templat baru:** Nada dering senyap saat tidur (22:00). Pulihkan dengan makro lain yang mengisi alamat nada asli.
- Izin baru `SET_WALLPAPER` (otomatis, tanpa dialog).
- Versi 1.17.0. Satu APK 64-bit dan 32-bit. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 32 — Jadwal akurat, meniru mekanisme BateraiBicara

Mekanisme waktu kini sama dengan aplikasi BateraiBicara v1.0.22:

- **Alarm-jam (`setAlarmClock`)** dipakai untuk semua pemicu waktu: Jadwal waktu, Beberapa jam sehari, Jadwal bulanan, Interval berkala, Matahari terbit atau terbenam. Alarm jenis ini dikecualikan dari Doze, penghemat baterai, dan penundaan pabrikan, serta tidak butuh izin alarm tepat waktu. Bila gagal, turun ke alarm tepat, lalu alarm biasa. Efek samping: ikon alarm muncul di bilah status dan waktu alarm berikutnya tampil di jam sistem.
- **Alarm berikutnya dipasang lebih dulu, baru makro dijalankan.** Sebelumnya alarm berikutnya baru dipasang setelah makro selesai, sehingga makro dengan jeda panjang (mis. Tunggu 600 detik) bisa kehilangan jadwal bila proses dimatikan sistem.
- **Selisih pengaman 2 detik:** jadwal berikutnya dihitung dari sekarang + 2 detik agar tidak bunyi dua kali.
- **Interval berkala sejajar kelipatan menit sejak 00.00** bila membagi sehari habis (mis. tiap 10 menit: :00, :10, :20; tiap 30 menit: :00 dan :30). Interval lain, mis. 45 menit, dihitung dari sekarang.
- **Jam atau zona waktu diubah:** semua jadwal dihitung ulang otomatis.
- **Penjaga CPU (wake lock) selama makro berjalan**, maksimal 30 menit, agar aksi Tunggu dan aksi berurutan tidak molor saat layar mati.
- Izin `USE_EXACT_ALARM` ditambahkan. Layanan latar depan dihidupkan lagi saat alarm bunyi bila sempat mati.
- Versi 1.18.0. Satu APK 64-bit dan 32-bit. Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 36 — Pemicu, aksi, dan batasan baru, banyak memakai ADB

Total kini 78 pemicu, 159 aksi, 37 batasan. Versi 1.20.0.

**Pemicu baru (7):**
- **Hasil perintah shell berubah atau mengandung teks (ADB):** menjalankan perintah shell tiap 10 detik atau lebih, memicu saat keluaran berubah, atau saat keluaran mulai mengandung teks yang dicari. Pembacaan pertama hanya menjadi acuan, tidak memicu. Keluaran tersedia sebagai `{shell_out}`. Contoh: `dumpsys battery | grep -m1 temperature`.
- **Pengaturan sistem berubah:** system, secure, atau global, dengan kunci tertentu (mis. `private_dns_mode`). Nilai baru tersedia sebagai `{setting_value}`. Tanpa ADB.
- **Mikrofon mulai atau berhenti dipakai** dan **Kamera mulai atau berhenti dipakai:** dari daftar rekaman aktif dan ketersediaan kamera di sistem. Tanpa izin khusus. Pada sebagian perangkat senter juga terhitung sebagai kamera dipakai.
- **Gambar baru di galeri:** tangkapan layar, foto kamera, atau apa pun. Butuh izin membaca gambar (ikut diberikan oleh Beri semua izin otomatis). Nama berkas tersedia sebagai `{media_name}`.
- **Tulisan muncul di layar:** dicek tiap 2 detik saat layar menyala, butuh Aksesibilitas. Memicu saat tulisan baru muncul, bukan untuk tulisan yang sudah ada saat pemantauan mulai. Nama paket kosong = aplikasi apa pun.
- **Sambungan ADB bawaan tersambung atau terputus:** dicek tiap 20 detik.

**Aksi baru (27), semua kecuali yang bertanda "tanpa ADB" butuh pairing ADB bawaan:**
- Layar dan input: buka atau tutup panel notifikasi dan pengaturan cepat · ketuk lama · ketuk dua kali · seret dan lepas · **ketuk elemen berdasarkan tulisan lewat uiautomator (tanpa Aksesibilitas)** · buka kunci layar dengan PIN · ubah ukuran atau kepadatan layar (wm) · atur kecepatan animasi sistem.
- Aplikasi: hapus data aplikasi · beri atau cabut izin runtime · atur izin khusus lewat appops · izinkan atau larang berjalan di latar · daftar putih penghemat baterai (Doze) · pasang APK diam-diam · copot aplikasi tanpa konfirmasi · jalankan activity, layanan, atau siaran lewat `am` dengan extra kunci=nilai.
- Informasi ke variabel: nama aplikasi di depan (tanpa ADB bila Aksesibilitas aktif) · info aplikasi (versi, terpasang, aktif, berjalan, lokasi APK) · properti sistem (getprop) · pengaturan sistem (tanpa ADB).
- Jaringan dan sistem: sambung ke Wi-Fi tertentu · hotspot nyala atau mati · DNS pribadi · operasi berkas di `/sdcard` lewat shell (salin, pindah, hapus, buat folder, cek ada, ukuran, daftar, baca).
- Khusus pengguna pembaca layar: pilih keyboard aktif · ganti mesin suara (TTS) bawaan dan kecepatannya · nyalakan atau matikan layanan Aksesibilitas tertentu (mis. berganti pembaca layar).

**Batasan baru (7):** sambungan ADB tersambung · aplikasi terpasang · keluaran perintah shell mengandung teks · level volume · layar mendatar · keyboard aktif tertentu · layanan Aksesibilitas tertentu aktif.

**Templat baru (5):** ucapkan saat tangkapan layar diambil · beri tahu saat kamera dipakai · matikan animasi sistem · ketuk Lewati otomatis · ucapkan saat ADB terputus.

Pengaman dan catatan jujur:
- Aksi berkas lewat shell hanya boleh menyentuh `/sdcard`, `/storage/emulated/0`, dan `/data/local/tmp`, menolak `..`, dan menolak menghapus folder induknya.
- Mematikan layanan Aksesibilitas ditolak bila itu layanan terakhir yang aktif, supaya pembaca layar tidak hilang. Tetap hati-hati memilih nama komponen.
- PIN di aksi Buka kunci disimpan apa adanya di data makro dan ikut terekspor. Jangan bagikan makro itu.
- Hapus data aplikasi, copot, dan hapus berkas tidak bisa dibatalkan.
- Hotspot dan sambung Wi-Fi memakai `cmd wifi` yang tidak ada atau berbeda di sebagian perangkat; galatnya dicatat di Log.
- `uiautomator dump` butuh layar menyala, dan sebagian aplikasi (mis. yang memblokir dump) tidak terbaca.
- Mic dan kamera dipakai tidak bisa membedakan aplikasi mana yang memakai.
- Baru, belum pernah dikompilasi dan belum diuji di perangkat; hanya diperiksa keseimbangan tanda kurung dan nama tipe ganda.

## Tahap 40 — Pemicu dan aksi tambahan

**3 pemicu baru (total 85):**
- **Tombol daya ditekan beberapa kali berturut-turut**: 2 sampai 6 kali, jeda antar tekan paling lama 3 detik.
- **Layar menyala atau mati terus-menerus selama sekian menit**: memakai alarm sehingga tetap jalan saat HP tidur; berjalan sekali setelah waktu terlewati.
- **Panggilan masuk dari kontak tertentu**: nama kontak jadi `{call_name}` (juga tersedia di panggilan terlewat, berakhir, dan tersambung). Butuh izin Kontak.

**5 aksi baru:**
- **Simpan nama kontak dari nomor telepon ke variabel** (bila tidak ada di kontak, yang disimpan nomornya). Cocok dengan `{call_number}` lalu aksi ucapkan.
- **Kedipkan senter beberapa kali** (jumlah, lama nyala, lama mati).
- **Tunggu sampai jam tertentu** (paling lama 30 menit; untuk jam lebih jauh pakai pemicu jadwal).
- **Hitung tanggal dan jam dari sekarang ke variabel** (menit, jam, hari, minggu, bulan, tahun; angka negatif = mundur).
- **Pilih satu baris acak dari daftar ke variabel**.

Izin baru: `READ_CONTACTS` (ikut di daftar izin aplikasi dan skrip `scripts/setup_permissions`).

## Tahap 41 — Pemicu dan aksi tambahan lagi

**4 pemicu baru (total 89):** senter menyala atau mati · pembaca layar (mode jelajah sentuh, mis. TalkBack) menyala atau mati · ponsel jatuh bebas atau dilempar · jaringan utama berpindah jenis (Wi-Fi, seluler, kabel, tidak ada).

**5 aksi baru:**
- **Ucapkan angka satu per satu**, cocok untuk nomor telepon (`{call_number}`).
- **Simpan nomor dan nama panggilan terakhir ke variabel** (jenis: apa saja, masuk, keluar, terlewat). Butuh izin Log Panggilan.
- **Buat teks acak ke variabel** (angka, huruf, campuran, heksadesimal).
- **Telepon kontak berdasarkan nama** (langsung menelepon atau hanya membuka pemanggil nomor).
- **Kirim SMS ke kontak berdasarkan nama**.

Tidak ada izin baru; memakai READ_CONTACTS dari tahap 40.

## Tahap 43 — Pemicu "Rentang waktu" (mulai sampai selesai, lalu kembali seperti semula)

Pemicu baru **Rentang waktu**: isi *Dari jam/menit* dan *Sampai jam/menit* (boleh lintas tengah malam, mis. 22:00 sampai 06:00) dan pilih hari.
Pada jam mulai, MakroKu menyimpan keadaan saat itu lalu menjalankan aksi makro. Pada jam selesai, keadaan dikembalikan persis seperti sebelum mulai.
Aksi yang dikembalikan otomatis (di daftar aksi utama): sinkron data, Wi-Fi, Bluetooth, mode pesawat, data seluler, NFC, lokasi, senter, speaker telepon,
hemat baterai, penghemat data, kecerahan (dan kecerahan otomatis), volume, mode dering, Jangan ganggu, waktu layar mati.
Bila HP baru menyala atau makro baru dibuat saat jam sudah di dalam rentang, rentang langsung dimulai; bila jam selesai terlewat (HP mati), keadaan dikembalikan saat MakroKu aktif lagi.
Templat siap pakai: "Sinkron data hanya jam 06:00 sampai 22:00".

## Tahap 44 — Pilihan Aktif / Tidak aktif / Otomatis

Aksi yang punya saklar nyala-mati (sinkron data, Wi-Fi, Bluetooth, mode pesawat, data seluler, NFC, lokasi, senter, speaker telepon, bisukan mikrofon,
hemat baterai, penghemat data, kecerahan otomatis) kini memakai satu pilihan tiga baris: **Aktif**, **Tidak aktif**, atau **Otomatis**
(yang tadinya aktif jadi tidak aktif, dan sebaliknya). Daftar aksi juga membacakannya dengan kata yang sama. Pemicu Rentang waktu dibacakan sebagai "Mulai 06:00. Selesai 22:00, lalu kembali seperti semula."

## Tahap 45 — Keterangan lebih ringkas

Nama pemicu/aksi/batasan, label kolom, keterangan templat, dan teks bantuan (Izin via ADB, blok aksi, variabel) dipersingkat dan disederhanakan.
Syarat izin ditulis seragam di akhir nama, mis. "(perlu ADB)", "(perlu Aksesibilitas)", "(perlu izin Kontak)".

## Tahap 47 — Pemicu dan aksi ala Tasker (bagian 1)

Tahap pertama dari rencana menambah pemicu dan aksi aplikasi Tasker. Total kini 93 pemicu. Versi 1.27.0.

**3 pemicu baru:**
- **Papan klip berubah (ada teks disalin):** kolom teks boleh kosong (semua salinan) atau diisi (hanya salinan yang mengandung teks itu). Isi salinan tersedia sebagai `{clip_text}`. Android 10 ke atas melarang aplikasi latar membaca papan klip, jadi `{clip_text}` bisa kosong. Pemicunya tetap jalan. Agar isinya terbaca, jalankan sekali lewat aksi shell ADB: `appops set com.makroku.automation READ_CLIPBOARD allow` (belum semua HP mengizinkannya).
- **Lagu berganti (perlu Akses Notifikasi):** dari pemutar musik mana pun yang punya sesi media. Memicu saat judul atau artis berganti, bukan tiap detik. Tersedia `{track_title}`, `{track_artist}`, `{track_album}`, `{track_app}`. Kolom teks boleh kosong (semua lagu) atau dicocokkan dengan judul dan artis. Bila Akses Notifikasi baru diberikan setelah makro dibuat, simpan ulang makronya agar pemantau terpasang.
- **Sensor tekanan, suhu, lembap, magnet melewati batas:** pilih jenis sensor, isi batas (bilangan bulat), pilih ke atas atau ke bawah. Memicu hanya saat nilai melintasi batas. Nilai terbaru tersedia sebagai `{sensor_value}`. Sensor tekanan (hPa), suhu sekitar (derajat C), kelembapan (persen), medan magnet (mikrotesla, besar gabungan tiga sumbu). Tidak semua HP punya sensor ini; yang tidak ada dilewati tanpa galat. Dicek paling cepat sekali per detik.

**1 aksi baru, setara Array Tasker: Daftar (array).** Satu variabel berisi satu butir per baris. Isi nama variabel daftar, pilih operasi, lalu nilai, pemisah, atau nomor butir sesuai kebutuhan. Nomor butir mulai 1; negatif dihitung dari belakang (-1 = terakhir). Hasil operasi baca disimpan ke variabel "Simpan ke".
- Ubah daftar: tambah di akhir, tambah di awal, sisipkan di nomor butir, ambil dan buang yang terakhir atau pertama, buang butir nomor sekian, buang butir bernilai tertentu, ganti butir nomor sekian, kosongkan, isi dari teks (dipisah pemisah), urutkan naik atau turun (angka diurutkan sebagai angka bila semua butir angka), balik urutan, buang kembar, acak.
- Baca (daftar tidak berubah): baca butir nomor sekian, hitung jumlah butir, gabung jadi satu teks, cek ada nilai, cari nomor butir (0 = tidak ada), jumlah, terkecil, terbesar, dan rata-rata angka.
- Daftar kosong pada "ambil dan buang" dicatat sebagai galat di Log. Butir tidak boleh berisi baris baru (diganti spasi). Pemisah `\n` berarti baris baru.

Rencana tahap berikutnya (belum dikerjakan): pemicu jadwal kalender, Wi-Fi terdeteksi di sekitar, kekuatan sinyal seluler, entri logcat (ADB); aksi pilihan dari daftar (menu dialog), dialog ya atau tidak, daftar berkas ke variabel, baca satu baris berkas, zip dan unzip.
Baru, belum diuji di perangkat dan belum pernah dikompilasi (di sini tidak ada Android SDK atau Kotlin).

## Tahap 48 — Pemicu dan aksi ala Tasker (bagian 2)

Total kini 95 pemicu. Versi 1.28.0.

**2 pemicu baru:**
- **Baris log sistem mengandung teks (perlu ADB):** membaca log sistem tiap 5 detik lewat ADB bawaan, memicu untuk baris baru yang mengandung teks yang Anda isi (teks wajib diisi). Tag log boleh diisi agar hanya tag itu. Tersedia `{log_line}` dan `{log_tag}`. Bacaan pertama hanya menjadi acuan. Paling banyak 10 pemicu per pembacaan.
- **Wi-Fi muncul atau hilang di sekitar (perlu izin Lokasi):** dari hasil pindai Wi-Fi. Nama kosong = jaringan apa pun. Pilih muncul atau menghilang. Wi-Fi harus menyala dan Lokasi aktif. Android membatasi pindai dari latar belakang, jadi perubahan bisa terlambat beberapa menit.

**4 aksi baru:**
- **Dialog pilihan:** mode Ya atau Tidak (jawaban `ya` atau `tidak`) atau menu dari daftar (satu pilihan per baris). Jawaban disimpan ke variabel. Dibatalkan atau waktu habis = makro berhenti, sama seperti dialog isian. Butuh izin Tampil di atas aplikasi lain.
- **Daftar berkas di folder data aplikasi ke variabel:** satu nama per baris, folder berakhiran `/`. Hasilnya bisa dipakai aksi Daftar (array) dan Ulangi.
- **Baca satu baris dari berkas teks:** nomor baris mulai 1, negatif dari belakang. Berkas maksimal 5 MB.
- **Zip atau unzip:** zip membungkus berkas atau folder jadi arsip; unzip mengekstrak ke folder. Entri zip yang mencoba keluar dari folder ditolak. Semua di `Android/data/com.makroku.automation/files`.

Rencana berikutnya: pemicu jadwal kalender, kekuatan sinyal seluler; aksi ambil foto, rekam suara, dan lainnya dari Tasker.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 49 — Pemicu dan aksi ala Tasker (bagian 3)

Total kini 97 pemicu. Versi 1.29.0. Izin baru: `READ_CALENDAR` (ikut di daftar izin aplikasi, tombol Beri semua izin otomatis, dan skrip `scripts/setup_permissions`).

**2 pemicu baru:**
- **Acara Kalender mulai atau selesai (perlu izin Kalender):** dicek tiap 30 detik, jadi bisa terlambat sampai sekitar setengah menit. Acara seharian dilewati. Kolom teks boleh kosong (semua acara) atau diisi (dicocokkan dengan judul). Tersedia `{cal_title}` dan `{cal_location}`. Acara yang sedang berlangsung saat pemantauan mulai hanya menjadi acuan.
- **Sinyal seluler melewati batas (perlu izin Telepon):** tingkat 0 sampai 4 batang, dicek tiap 20 detik, memicu hanya saat melintasi batas. Tersedia `{signal_level}`.

**2 aksi baru:**
- **Konversi tanggal:** teks tanggal ke detik epoch, detik epoch ke teks, dan selisih dua tanggal dalam detik, menit, jam, atau hari (tanggal kedua dikurangi tanggal pertama, dibulatkan ke arah nol). Format Java, mis. `yyyy-MM-dd HH:mm`. Tanggal yang tidak cocok dengan format dicatat sebagai galat di Log.
- **Kelola berkas:** buat folder, hapus berkas atau folder beserta isinya, ganti nama. Hanya di folder data aplikasi, nama tunggal tanpa garis miring.

Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 50 — Parameter makro dan variabel bernomor (ala Tasker)

Versi 1.30.0.

- **Jalankan makro lain kini punya Parameter 1, 2, dan 3** (setara Perform Task dengan par1, par2 di Tasker). Di makro tujuan, nilainya dipakai lewat `{par1}`, `{par2}`, `{par3}` (kolomnya boleh memakai placeholder lain, mis. `{var:nama}`). Makro lama tetap jalan karena parameter kosong secara bawaan.
- **Aksi baru: Pisah teks jadi variabel bernomor.** Teks dipisah oleh pemisah lalu disimpan sebagai `awalan1`, `awalan2`, dan seterusnya, plus `awalan_jumlah` berisi banyaknya bagian (maksimal 500). Variabel bernomor lama dengan awalan sama dibuang dulu. Pemisah `\n` berarti baris baru. Cocok dengan aksi Daftar (array): isi daftar, lalu pecah jadi variabel.
- **Aksi baru: Hapus variabel berawalan tertentu** (setara Variable Clear dengan wildcard di Tasker). Awalan wajib diisi agar tidak menghapus semua variabel.

Tidak dikerjakan, dengan alasan: **ambil foto** dan **rekam suara** dari latar belakang. Android 11 ke atas membatasi kamera dan mikrofon untuk aplikasi latar, dan Android 14 mewajibkan layanan latar depan jenis kamera atau mikrofon yang tidak boleh dimulai dari latar belakang. Hasilnya tidak bisa diandalkan tanpa layar menyala, jadi lebih jujur tidak dipasang.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 51 — Bagikan makro sebagai berkas, buka langsung di MakroKu (ala MacroDroid)

Versi 1.31.0.

- **Bagikan sebagai berkas `.makroku`:** tekan tahan makro (Beranda) atau menu makro (editor) lalu pilih "Bagikan makro sebagai berkas". Untuk semua makro sekaligus: Pengaturan, bagian Cadangan, "Bagikan semua makro sebagai berkas". Berkas bisa dikirim lewat WhatsApp, Telegram, Bluetooth, surel, dan lainnya.
- **Buka berkas langsung di MakroKu:** di HP penerima, ketuk berkas `.makroku` (atau pilih Buka dengan MakroKu, atau Bagikan ke MakroKu). Muncul kotak daftar nama makro dengan tombol Terapkan atau Batal. Setelah Terapkan, makro langsung masuk dengan setelan aslinya.
- Isi berkas sama dengan Ekspor makro (JSON), jadi berkas lama `makroku-backup.json` juga bisa dibuka dengan cara ini.
- Makro yang masuk tidak menimpa makro yang sudah ada (id baru). Berkas yang bukan makro MakroKu ditolak dengan pesan.
- Berkas dibuat lewat FileProvider (`cache/bagikan/`); izin baca hanya untuk aplikasi penerima.
- Catatan: WhatsApp kadang menyebut berkas dengan ekstensi asing sebagai "dokumen" tipe umum. MakroKu ikut mendaftar untuk tipe umum (octet-stream, json) selain pola nama `.makroku`, supaya muncul di daftar "Buka dengan". Bila WhatsApp tidak menawarkan MakroKu, simpan berkasnya lalu buka dari aplikasi Berkas.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 52 — Buka berkas `.macro` asli MacroDroid

Versi 1.32.0.

- **Berkas `.macro` dari MacroDroid kini bisa dibuka di MakroKu.** Ketuk berkasnya (dari WhatsApp, Berkas, dsb) lalu pilih MakroKu, atau pakai Impor makro di Pengaturan. Muncul kotak Terapkan atau Batal seperti berkas `.makroku`. Format dikenali dari isinya, bukan dari nama berkas.
- **Bagian yang diubah (sudah dicocokkan dengan contoh berkas asli):** nama, deskripsi, kategori, aktif atau tidak; pemicu Notifikasi (aplikasi, teks dengan tanda bintang); aksi Jeda, Ucapkan teks (`{not_title}` menjadi `{notif_title}`, `{not_text}` menjadi `{notif_text}`); ulangan "selama notifikasi ada"; batasan Notifikasi ada. Batasan pada aksi biasa dibungkus aksi "Jika batasan terpenuhi".
- **Yang tidak bisa dibawa:** jenis pemicu, aksi, dan batasan lain dilewati. Di dalam makro diberi aksi Catatan berisi nama jenis yang dilewati, dan kotak Terapkan menampilkan daftarnya. Kecepatan dan nada bicara MacroDroid juga tidak dibawa. Jenis lain bisa ditambah bila ada contoh berkas aslinya, karena nama kolomnya harus dicocokkan satu per satu.
- **Baru di MakroKu:** batasan **Notifikasi sedang ada** (perlu Akses Notifikasi; teks boleh memakai `*`) dan aksi **Ulangi selama batasan terpenuhi** (maksimal 300 putaran bawaan). Keduanya ada di daftar batasan dan aksi editor.
- Ekspor dari MakroKu ke format `.macro` MacroDroid tidak ada; MakroKu tetap memakai `.makroku`.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 53 — Impor `.macro` MacroDroid yang lebih lengkap + cadangan lengkap

Versi 1.33.0.

- **Empat berkas contoh kini bisa diimpor:** Jadwal Otomatis sinkronkan data aplikasi, Jadwal aktif non aktif data seluler, Menu 4 fungsi, Penelusuran suara toko online. Strukturnya sudah dicocokkan dengan isi berkas aslinya.
- **Pemicu yang dibaca:** Timer (jam, menit, hari; urutan hari dibaca mulai Minggu) dan Goyang perangkat, selain Notifikasi.
- **Aksi yang dibaca:** Jika / Jika lain / Lainnya / Akhir jika (bersarang, jadi rantai Jika di MakroKu), Sinkron otomatis, Data seluler, Pecah teks tetap + Dialog pilihan (menjadi satu Dialog pilihan), Isi variabel (termasuk tanya pengguna, jadi Dialog isian), Kirim intent (paket + kelas), Klik teks di layar, Buka halaman web, Input suara. Penanda `{lv=x}` dan `[lv=x]` menjadi `{var:x}`, `{macro_name}` menjadi nama makro.
- **Batasan yang dibaca:** "Pemicu yang menjalankan" (menjadi nomor pemicu), Variabel (angka, teks, ya/tidak; nomor pilihan dialog dibandingkan dengan teks butirnya).
- **Dibaca dengan asumsi:** nilai 0 pada Sinkron otomatis dan Data seluler dibaca "aktifkan", 1 "nonaktifkan", 2 "alih". Kotak Terapkan menampilkan catatan ini; periksa hasilnya di editor.
- **Baru di MakroKu:** aksi **Input suara ke variabel** (pengenalan suara Android, perlu izin Tampil di atas aplikasi lain), batasan **Dijalankan oleh pemicu nomor ke-N** (semua jenis pemicu kini membawa nomornya), **Kirim intent** bisa menyebut nama paket dan kelas.
- **Percabangan aman:** bila satu cabang memakai batasan yang tidak dikenal, seluruh percabangan dilewati (diganti Catatan) supaya aksi di dalamnya tidak jalan tanpa syarat.
- **Cadangan lengkap:** Ekspor cadangan dan Bagikan cadangan sekarang berisi semua makro dan semua variabel. Impor berkas di Pengaturan kini memakai kotak konfirmasi yang sama dengan membuka berkas dari luar. Cadangan lama (daftar makro saja) tetap terbaca.
- Belum ada: ekspor ke format `.macro` MacroDroid, dan jenis blok MacroDroid selain yang disebut di atas (tetap dilewati dengan catatan).
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 54 — Impor `.macro` MacroDroid: 20 berkas contoh asli

Versi 1.34.0.

- **Sudah dicocokkan dengan 20 berkas `.macro` asli** (Ad Skipper YouTube, Ada 6 menu, Ada empat/lima fungsi, Bagikan lokasi V1–V3, Bagikan link Play Store, Balas otomatis jam kerja, Balas otomatis panggilan tak terjawab, Aktif/nonaktif opsi pengembang, DNS AdGuard, Play Protect, skala animasi, speaker telepon, Ambil gambar layar, Aksesibilitas, dll).
- **Pemicu baru dibaca:** Intent diterima, Isi layar (hanya tulisan, bintang dibuang), Sensor jarak, Layar hidup/mati, Aplikasi dibuka/ditutup, Pemicu kosong (jadi Manual).
- **Batasan baru dibaca:** Waktu dalam sehari, Aplikasi aktif (di depan, atau berjalan lewat ADB; bisa dibalik), Musik aktif.
- **Aksi baru dibaca:** Toast, Papan klip, Dialog pesan (jadi Popup), Setelan sistem (system/secure/global), Balas notifikasi (dari pemicu notifikasi atau paket tertentu), Buka aplikasi, Buka layar aplikasi (intent berkomponen), Jalankan makro (`[This Macro]` = makro itu sendiri), Tulis ke berkas, Tangkapan layar, Getar, Atur volume Media.
- **Batasan yang menempel pada pemicu kini dibawa.** MacroDroid menaruh batasan di tiap pemicu; MakroKu mengubahnya menjadi batasan makro berbentuk "bukan pemicu ke-N ATAU batasannya", jadi hanya berlaku bila makro dijalankan oleh pemicu itu.
- **Penanda:** `{v=Nama}` (variabel sistem) dan penanda ajaib yang tidak ada di MakroKu (mis. `{last_loc_link}`, `{vol_music}`) kini disebut di daftar peringatan kotak Terapkan.
- **Masih dilewati (diberi catatan + peringatan):** Layanan aksesibilitas, Tunggu sampai pemicu, Buka log MacroDroid, Plugin Locale (TouchTask), pemicu isi layar berdasarkan ID tampilan atau "tulisan hilang", pola getar (diganti getar 500 md), volume aliran selain Media.
- **Dibaca dengan asumsi:** tabel setelan 0 = system, 1 = secure, 2 = global (hanya 2 yang ada di contoh); aliran volume urutan ke-2 = Media (cocok dengan makro Ad Skipper).
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 55 — Impor `.macro` MacroDroid: 20 berkas contoh tambahan

Versi 1.35.0.

- **Sudah dicocokkan dengan 20 berkas contoh lagi** (Baterai bicara, Baterai terisi penuh anti pencuri, Bersihkan pesan WA, Bom WA, Buka kunci layar PIN/sandi, Buka WhatsApp layar mati 10/60 menit, Cari HP saya, Catatan log, Cek pulsa dan kuota, Chat baru, Buka info aplikasi).
- **Pemicu baru dibaca:** Level baterai (naik ke / turun ke), Daya terhubung/terputus, Layar tidak terkunci, Balik perangkat.
- **Batasan baru dibaca:** Perangkat terkunci / tidak terkunci.
- **Aksi baru dibaca:** WhatsApp (nomor + pesan, biasa atau Business), Atur lama layar mati, Layar hidup, Mode senyap/getar mati (jadi Dering normal), Tombol Beranda dan Kembali, Catatan log, Putar suara, Hentikan ulangan (Break), Tempel teks ke kolom terpilih (isian diganti atau ditambah sesuai "hapus dulu").
- **Ulangi tiap butir daftar:** daftar dari Pecah teks tetap (mis. `1,2,3,4,5,6`) dibuka menjadi salinan aksi berurutan, dengan `{iterator_value}` diganti butirnya. Dipakai makro buka kunci PIN.
- **Ulangan tanpa henti** dibaca 300 putaran. **Batalkan makro aktif** (`[This Macro]`) menjadi Hentikan makro: hanya menghentikan jalannya makro itu sendiri, putaran lain yang sedang berjalan tidak ikut dibatalkan (MakroKu belum punya pembatalan lintas-jalan, jadi makro seperti "Bom WA" perlu diperiksa).
- **Penanda:** `[battery]`, `[not_title]`, `[notification]` menjadi `{battery}`, `{notif_title}`, `{notif_text}`.
- **Putar suara:** nama suara MacroDroid (mis. `notification_001`) bukan berkas, jadi dipakai nada notifikasi bawaan dan peringatan muncul; pilih berkasnya di editor.
- **Masih dilewati (diberi catatan + peringatan):** Klik lewat ID tampilan (tombol kirim, menu tiga titik WhatsApp), Android Shortcuts, Blok aksi + Ambil aplikasi terpasang + Bandingkan nilai (makro Buka info aplikasi), Layanan aksesibilitas, Plugin Locale.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 56 — Klik lewat ID tampilan (impor `.macro` MacroDroid)

Versi 1.36.0.

- **Aksi baru: Ketuk tombol berdasarkan ID tampilan** (perlu Aksesibilitas). Isi ID lengkap, mis. `com.whatsapp:id/send` atau `com.whatsapp:id/menuitem_overflow`, batas waktu mencari (detik), dan Ketuk lama. Mengulang pencarian tiap setengah detik sampai ketemu atau waktu habis.
- **Layanan Aksesibilitas** kini meminta bendera `flagReportViewIds` supaya ID elemen terbaca. Setelah memasang versi ini, matikan lalu nyalakan lagi layanan Aksesibilitas MakroKu di Setelan bila ID tidak ketemu.
- **Impor `.macro`:** klik dengan opsi "ID tampilan" kini menjadi aksi ini. Dengan begitu makro Bersihkan pesan di chat WhatsApp / WA Business / keduanya dan Bom WhatsApp / WA Business terbaca penuh (5 berkas contoh).
- ID tampilan tiap aplikasi bisa berubah saat aplikasinya diperbarui; bila tidak ketemu, pesan galat menyebut ID yang dicari.
- Belum: pemicu Isi layar berdasarkan ID, Android Shortcuts, Blok aksi + Tunggu pemicu (tahap berikutnya).
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 57 — Tunggu tulisan di layar + layanan aksesibilitas MacroDroid (impor `.macro`)

Versi 1.37.0.

- **Aksi baru: Tunggu sampai tulisan muncul di layar** (perlu Aksesibilitas). Isi tulisan, nama paket (kosong = aplikasi apa pun), batas waktu detik (0 = 120 detik), dan pilihan lanjut atau berhenti bila waktu habis. Dicek tiap setengah detik.
- **Impor `.macro`:** "Tunggu pemicu" dengan satu pemicu Isi layar (tulisan muncul) menjadi aksi ini, jadi makro Bagikan lokasi saya terbaca penuh. Tanda bintang pada tulisan dibuang.
- **Aksi "Layanan aksesibilitas" untuk MacroDroid** (hidupkan/matikan layanan MacroDroid) diabaikan dengan peringatan, karena MakroKu memakai layanan Aksesibilitasnya sendiri. Untuk aplikasi lain (mis. TouchTask) tetap dilewati dengan catatan.
- Belum: Android Shortcuts (nilai pilihan hanya angka, perlu dipastikan fungsinya), Blok aksi + Ambil aplikasi terpasang + Bandingkan nilai, pemicu Isi layar berdasarkan ID atau "tulisan hilang", Buka log MacroDroid, Plugin Locale.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.

## Tahap 58 — Balas otomatis WhatsApp dengan AI Gemini (impor `.macro`)

Versi 1.38.0. Dicocokkan dengan berkas contoh `Balas_otomatis_WhatsApp_AI_Gemini.macro`.

- **Batasan baru: Bandingkan dua teks.** Teks kiri dan kanan boleh memakai penanda (`{notif_title}`, `{var:x}`), dengan cara: sama, tidak sama, mengandung, tidak mengandung, diawali, diakhiri, cocok regex, tidak cocok regex. Impor `.macro` membaca "Bandingkan nilai" untuk teks: jenis 0 sama, 1 tidak sama, 4 mengandung, 5 tidak mengandung (dengan regex: cocok / tidak cocok).
- **Pemicu Notifikasi:** pilihan baru "Jalan bila teks TIDAK mengandung", "Abaikan notifikasi yang sedang berjalan", dan teks dibaca sebagai regex. Penanda baru: `{notif_big}` (teks besar), `{notif_full}` (setara `{notification}` MacroDroid), `{notif_key}`.
- **Aksi HTTP:** kolom baru Simpan respons ke variabel dan Batas waktu (detik). Impor `.macro` membaca jenis permintaan, header, isi teks, nama variabel respons, dan batas waktu.
- **Hapus notifikasi:** kolom baru "Hanya yang judulnya mengandung" (mis. `{notif_title}` = hanya pengirim itu), dan nama paket boleh lebih dari satu dipisah koma.
- **Balas notifikasi:** bila dijalankan oleh pemicu Notifikasi, balasan dikirim ke notifikasi pemicu itu sendiri (kunci sama), bukan notifikasi terbaru aplikasi, supaya tidak salah obrolan.
- **Impor `.macro`:** Ganti semua teks (jadi Olah teks: ganti), Urai JSON + rujukan `{lv=kamus[kunci][0]...}` (jadi Ambil nilai JSON), nilai baru pada Atur variabel (kolom `m_new...`), variabel global `{v=nama}` yang dideklarasikan di berkas tidak lagi diberi peringatan.
- **Perbaikan:** batasan yang menempel pada satu pemicu ("hanya berlaku bila dijalankan oleh pemicu ini") sebelumnya tidak pernah dinilai karena nomor pemicu tidak sampai ke pemeriksa batasan. Kini dinilai.
- **Yang harus Anda isi:** header `x-goog-api-key` di aksi HTTP masih berisi tulisan pengganti dari berkas; ganti dengan kunci API Gemini Anda. Akses Notifikasi MakroKu harus aktif.
- **Dibaca dengan asumsi:** jenis permintaan HTTP 0 GET, 1 POST, 2 PUT, 3 DELETE; opsi Hapus notifikasi 0 semua, 1 yang cocok teks. Variabel lokal MacroDroid dibaca sebagai variabel MakroKu biasa (menetap antar-jalan), jadi pengecekan "pesan sama dua kali" kini benar-benar bekerja.
Baru, belum diuji di perangkat dan belum pernah dikompilasi.
