package com.novan.githubbynovan;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Membuat keystore (tanda tangan APK) langsung di HP, tanpa pustaka tambahan:
 * pasangan kunci RSA 2048, sertifikat X.509 self-signed (SHA256withRSA), disimpan sebagai PKCS12 (.p12).
 */
public class KeystoreTools {
    public static class Hasil {
        public byte[] data;
        public String alias, sandi, sidikJari;
    }

    private static final String HURUF = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    /** Sandi acak 16 karakter tanpa huruf yang mudah tertukar (l, I, O, 0, 1). */
    public static String sandiAcak() {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) sb.append(HURUF.charAt(r.nextInt(HURUF.length())));
        return sb.toString();
    }

    /** Buat keystore. Lemparan Exception berisi pesan yang siap ditampilkan. */
    public static Hasil buat(String nama, String organisasi, String negara, String alias, String sandi,
                             int tahunBerlaku) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();

        byte[] der = sertifikat(kp, nama, organisasi, negara, tahunBerlaku);
        Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));

        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        char[] pw = sandi.toCharArray();
        ks.setKeyEntry(alias, kp.getPrivate(), pw, new Certificate[]{cert});
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ks.store(bos, pw);

        Hasil h = new Hasil();
        h.data = bos.toByteArray();
        h.alias = alias;
        h.sandi = sandi;
        h.sidikJari = sidikJari(der);
        return h;
    }

    /** Sidik jari SHA-256 sertifikat, huruf besar dipisah titik dua. */
    public static String sidikJari(byte[] der) throws Exception {
        byte[] d = java.security.MessageDigest.getInstance("SHA-256").digest(der);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format(Locale.US, "%02X", d[i] & 0xFF));
        }
        return sb.toString();
    }

    // ---------- DER ----------

    private static byte[] tlv(int tag, byte[]... isi) {
        ByteArrayOutputStream c = new ByteArrayOutputStream();
        for (byte[] b : isi) c.write(b, 0, b.length);
        byte[] body = c.toByteArray();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = body.length;
        if (n < 128) {
            o.write(n);
        } else if (n < 256) {
            o.write(0x81);
            o.write(n);
        } else if (n < 65536) {
            o.write(0x82);
            o.write(n >> 8);
            o.write(n & 0xFF);
        } else {
            o.write(0x83);
            o.write(n >> 16);
            o.write((n >> 8) & 0xFF);
            o.write(n & 0xFF);
        }
        o.write(body, 0, body.length);
        return o.toByteArray();
    }

    private static byte[] seq(byte[]... x) { return tlv(0x30, x); }
    private static byte[] set(byte[]... x) { return tlv(0x31, x); }

    private static byte[] oid(int... a) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(a[0] * 40 + a[1]);
        for (int i = 2; i < a.length; i++) {
            int v = a[i];
            if (v < 128) {
                o.write(v);
            } else {
                // semua OID yang dipakai di sini bernilai kecil kecuali 113549 (tiga bait)
                int[] part = new int[5];
                int k = 0;
                while (v > 0) { part[k++] = v & 0x7F; v >>= 7; }
                for (int j = k - 1; j >= 0; j--) o.write(part[j] | (j > 0 ? 0x80 : 0));
            }
        }
        return tlv(0x06, o.toByteArray());
    }

    private static byte[] waktu(Date d) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTime(d);
        boolean panjang = c.get(Calendar.YEAR) >= 2050;
        SimpleDateFormat f = new SimpleDateFormat(panjang ? "yyyyMMddHHmmss'Z'" : "yyMMddHHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return tlv(panjang ? 0x18 : 0x17, f.format(d).getBytes(StandardCharsets.US_ASCII));
    }

    private static byte[] atribut(byte[] oid, int tagTeks, String nilai) {
        return set(seq(oid, tlv(tagTeks, nilai.getBytes(StandardCharsets.UTF_8))));
    }

    private static byte[] namaX500(String cn, String o, String c) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[][] parts = new byte[3][];
        int n = 0;
        if (c != null && !c.isEmpty()) parts[n++] = atribut(oid(2, 5, 4, 6), 0x13, c);
        if (o != null && !o.isEmpty()) parts[n++] = atribut(oid(2, 5, 4, 10), 0x0C, o);
        parts[n++] = atribut(oid(2, 5, 4, 3), 0x0C, cn);
        for (int i = 0; i < n; i++) b.write(parts[i], 0, parts[i].length);
        return tlv(0x30, b.toByteArray());
    }

    private static byte[] sertifikat(KeyPair kp, String cn, String o, String c, int tahun) throws Exception {
        byte[] algo = seq(oid(1, 2, 840, 113549, 1, 1, 11), tlv(0x05, new byte[0]));
        byte[] sn = new byte[16];
        new SecureRandom().nextBytes(sn);
        sn[0] &= 0x7F;
        if (sn[0] == 0) sn[0] = 1;
        byte[] serial = tlv(0x02, sn);

        Calendar mulai = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        mulai.add(Calendar.DAY_OF_YEAR, -1);
        Calendar akhir = (Calendar) mulai.clone();
        akhir.add(Calendar.YEAR, tahun);

        byte[] nama = namaX500(cn, o, c);
        byte[] tbs = seq(
                tlv(0xA0, tlv(0x02, new byte[]{2})),
                serial, algo, nama,
                seq(waktu(mulai.getTime()), waktu(akhir.getTime())),
                nama,
                kp.getPublic().getEncoded());

        Signature sg = Signature.getInstance("SHA256withRSA");
        sg.initSign(kp.getPrivate());
        sg.update(tbs);
        byte[] sig = sg.sign();
        byte[] bits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bits, 1, sig.length);
        return seq(tbs, algo, tlv(0x03, bits));
    }
}
