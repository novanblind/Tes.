package com.novan.filemanagerpro

import java.io.File

object FileOps {

    /** Mengembalikan File tujuan yang belum dipakai, mis. "foto (1).jpg". */
    fun uniqueTarget(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    /**
     * Menyingkirkan [target] yang sudah ada ke nama sementara supaya tempatnya kosong untuk berkas baru.
     * Mengembalikan nama sementara itu, atau null bila gagal. Bila tidak ada [target], mengembalikan [target] sendiri.
     */
    fun setAside(target: File): File? {
        if (!target.exists() && !java.nio.file.Files.isSymbolicLink(target.toPath())) return target
        val parent = target.parentFile ?: return null
        val backup = uniqueTarget(parent, ".${target.name}.lama")
        return if (target.renameTo(backup)) backup else null
    }

    /** Mengembalikan hasil [setAside] ke tempat semula bila penggantian gagal. */
    fun putBack(backup: File, target: File) {
        if (backup == target) return
        target.deleteRecursively()
        backup.renameTo(target)
    }

    /** Menyalin isi [src] ke [dst] sambil melaporkan kemajuan. */
    fun pump(input: java.io.InputStream, output: java.io.OutputStream, p: Progress?) {
        val buf = ByteArray(128 * 1024)
        while (true) {
            val r = input.read(buf)
            if (r < 0) break
            output.write(buf, 0, r)
            p?.add(r.toLong())
        }
    }

    /**
     * Menyalin [src] ke [dstDir] dan menimpa berkas/folder bernama sama. Berkas lama baru dihapus
     * setelah salinan baru selesai; bila gagal atau dibatalkan, berkas lama dikembalikan.
     */
    fun copyReplace(src: File, dstDir: File, p: Progress? = null): File {
        return replacing(src, dstDir, p) { copy(src, dstDir, p) }
    }

    /** Memindahkan [src] ke [dstDir] dan menimpa berkas/folder bernama sama. */
    fun moveReplace(src: File, dstDir: File, p: Progress? = null): File? {
        return replacing(src, dstDir, p) { moveTo(src, dstDir, p) }
    }

    class MergeResult { var skipped = 0; var failed = 0 }

    /**
     * Menggabungkan isi folder [src] ke folder [target] yang sudah ada. Berkas yang namanya belum ada
     * langsung masuk; folder kembar digabung lagi ke dalam; berkas kembar mengikuti [actions]
     * (kunci: jalur berkas asal; bawaan "ganti nama"). Bila [cut], yang berhasil dipindah dibuang dari asal.
     */
    fun merge(src: File, target: File, actions: Map<String, ConflictAction>, cut: Boolean, p: Progress? = null): MergeResult {
        val r = MergeResult()
        mergeInto(src, target, actions, cut, p, r)
        return r
    }

    private fun mergeInto(
        src: File, target: File, actions: Map<String, ConflictAction>, cut: Boolean, p: Progress?, r: MergeResult
    ) {
        p?.check()
        val kids = src.listFiles()
        if (kids == null) { r.failed++; return }
        for (c in kids) {
            p?.check()
            val t = File(target, c.name)
            try {
                if (!t.exists() && !java.nio.file.Files.isSymbolicLink(t.toPath())) {
                    if (cut) { if (moveTo(c, target, p) == null) r.failed++ } else copy(c, target, p)
                } else if (c.isDirectory && t.isDirectory) {
                    mergeInto(c, t, actions, cut, p, r)
                } else {
                    when (actions[c.absolutePath] ?: ConflictAction.RENAME) {
                        ConflictAction.SKIP -> r.skipped++
                        ConflictAction.OVERWRITE ->
                            if (cut) { if (moveReplace(c, target, p) == null) r.failed++ } else copyReplace(c, target, p)
                        else ->
                            if (cut) { if (moveTo(c, target, p) == null) r.failed++ } else copy(c, target, p)
                    }
                }
            } catch (e: OpCancelled) {
                throw e
            } catch (e: Exception) {
                r.failed++
            }
        }
        // Folder asal hanya terhapus bila sudah kosong (tidak ada yang dilewati atau gagal).
        if (cut) src.delete()
    }

    /** Berkas sebesar ini ke atas dihapus tanpa persen (satu panggilan delete tidak bisa diukur). */
    const val BIG_FILE = 256L * 1024 * 1024

    /** Menjalankan [block] sambil menandai kemajuan sebagai langkah yang persennya tidak bisa dihitung. */
    private inline fun <T> quiet(p: Progress?, kind: Int, block: () -> T): T {
        p?.busy = kind
        try {
            return block()
        } finally {
            p?.busy = 0
        }
    }

    private fun <T : File?> replacing(src: File, dstDir: File, p: Progress?, block: () -> T): T {
        val target = File(dstDir, src.name)
        val srcPath = src.canonicalPath
        val tgtPath = target.canonicalPath
        // Tidak boleh menimpa dirinya sendiri atau folder yang memuat sumbernya.
        if (srcPath == tgtPath || srcPath.startsWith("$tgtPath/")) {
            throw java.io.IOException(target.absolutePath)
        }
        val backup = setAside(target) ?: throw java.io.IOException(target.absolutePath)
        try {
            val r = block()
            if (r == null) {
                // Pindah gagal di tengah jalan: bila hasil sudah ada, pertahankan; bila tidak, pulihkan.
                if (target.exists()) quiet(p, Progress.BUSY_FINISH) { backup.takeIf { it != target }?.deleteRecursively() }
                else putBack(backup, target)
            } else if (backup != target) {
                quiet(p, Progress.BUSY_FINISH) { backup.deleteRecursively() }
            }
            return r
        } catch (e: Throwable) {
            putBack(backup, target)
            throw e
        }
    }

    /** Menyalin berkas atau folder ke dalam [dstDir]. Bila dibatalkan, salinan setengah jadi dihapus. */
    fun copy(src: File, dstDir: File, p: Progress? = null): File {
        val target = uniqueTarget(dstDir, src.name)
        try {
            copyInto(src, target, p)
        } catch (e: Throwable) {
            // Dibatalkan atau gagal (mis. penyimpanan penuh): salinan setengah jadi tidak dibiarkan.
            target.deleteRecursively()
            throw e
        }
        return target
    }

    /** Menyalin [src] ke jalur persis [target] (bukan ke dalam folder), melapor kemajuan; sisa salinan dihapus bila gagal. */
    fun copyExact(src: File, target: File, p: Progress? = null) {
        try {
            copyInto(src, target, p)
        } catch (e: Throwable) {
            target.deleteRecursively()
            throw e
        }
    }

    private fun copyInto(src: File, target: File, p: Progress?) {
        p?.check()
        if (src.isDirectory) {
            if (!target.mkdirs()) throw java.io.IOException(target.absolutePath)
            src.listFiles()?.forEach { copyInto(it, File(target, it.name), p) }
        } else {
            p?.label = src.name
            src.inputStream().use { input ->
                target.outputStream().use { output -> pump(input, output, p) }
            }
            target.setLastModified(src.lastModified())
        }
    }

    /** Memindahkan; bila rename gagal (beda volume), salin lalu hapus asal. */
    fun move(src: File, dstDir: File): Boolean = moveTo(src, dstDir) != null

    /** Seperti [move] tetapi mengembalikan lokasi baru, atau null bila gagal. */
    fun moveTo(src: File, dstDir: File, p: Progress? = null): File? {
        val target = uniqueTarget(dstDir, src.name)
        p?.check()
        if (src.renameTo(target)) return target
        val copied = copy(src, dstDir, p)
        val gone = quiet(p, Progress.BUSY_FINISH) { src.deleteRecursively() }
        return if (gone) copied else null
    }

    /** Jumlah entri (berkas dan folder) di bawah [f], termasuk [f] sendiri. */
    fun countEntries(f: File): Long {
        var n = 1L
        if (f.isDirectory && !java.nio.file.Files.isSymbolicLink(f.toPath())) {
            f.listFiles()?.forEach { n += countEntries(it) }
        }
        return n
    }

    /** Bobot hapus [f]: 1 per entri ditambah ukuran tiap berkas biasa (tautan simbolik tidak diikuti). */
    fun weightOf(f: File): Long {
        var n = 1L
        if (java.nio.file.Files.isSymbolicLink(f.toPath())) return n
        if (f.isDirectory) f.listFiles()?.forEach { n += weightOf(it) }
        else if (f.isFile) n += f.length()
        return n
    }

    /** Menghapus [f] beserta isinya; kemajuan bertambah sebesar bobotnya ([weightOf]) setiap entri terhapus. */
    fun deleteWithProgress(f: File, p: Progress): Boolean {
        p.check()
        var ok = true
        val link = java.nio.file.Files.isSymbolicLink(f.toPath())
        val isDir = f.isDirectory && !link
        if (isDir) {
            f.listFiles()?.forEach { if (!deleteWithProgress(it, p)) ok = false }
        }
        p.label = f.name
        var rest = if (!isDir && !link && f.isFile) f.length() else 0L
        // Berkas besar dikecilkan bertahap dulu supaya persen akurat dan Batal bisa bekerja di tengah jalan.
        if (rest >= BIG_FILE) rest = shrinkForDelete(f, rest, p)
        val big = rest >= BIG_FILE
        if (big) p.busy = Progress.BUSY_BIG_DELETE
        val r = try { f.delete() } finally { if (big) p.busy = 0 }
        p.add(rest + 1)
        return ok && r
    }

    /** Besar tiap langkah pengecilan berkas besar sebelum dihapus. */
    private const val SHRINK_STEP = 64L * 1024 * 1024

    private fun hardLinked(f: File): Boolean = try {
        ((java.nio.file.Files.getAttribute(f.toPath(), "unix:nlink") as? Number)?.toInt() ?: 1) > 1
    } catch (e: Exception) {
        false
    }

    /**
     * Memotong [f] dari belakang per [SHRINK_STEP] sambil melapor kemajuan. Dibatalkan lewat Batal di antara dua langkah
     * (berkas yang tersisa tinggal sebagian). Mengembalikan ukuran yang belum terpotong; bila berkas tidak bisa
     * dipotong (mis. hanya-baca, atau punya tautan keras) nilainya tetap dan berkas dihapus langsung.
     */
    private fun shrinkForDelete(f: File, len: Long, p: Progress): Long {
        if (hardLinked(f)) return len
        var size = len
        try {
            java.io.RandomAccessFile(f, "rw").use { raf ->
                while (size > 0L) {
                    p.check()
                    val next = maxOf(0L, size - SHRINK_STEP)
                    raf.setLength(next)
                    p.add(size - next)
                    size = next
                }
            }
        } catch (e: OpCancelled) {
            throw e
        } catch (e: Exception) {
            // tidak bisa dipotong: sisanya dihapus langsung
        }
        return size
    }

    fun sizeOf(f: File): Long {
        if (f.isFile) return f.length()
        var total = 0L
        f.walkTopDown().forEach { if (it.isFile) total += it.length() }
        return total
    }

    fun search(
        dir: File,
        query: String,
        hidden: Boolean,
        out: MutableList<File>,
        limit: Int,
        active: () -> Boolean
    ) {
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (!active() || out.size >= limit) return
            if (!hidden && k.name.startsWith(".")) continue
            if (k.name.contains(query, ignoreCase = true)) out.add(k)
            if (k.isDirectory && !java.nio.file.Files.isSymbolicLink(k.toPath())) {
                search(k, query, hidden, out, limit, active)
            }
        }
    }
}
