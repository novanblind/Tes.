package com.novan.pembacauang

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * OCR ML Kit untuk frame NV21.
 *
 * Tahap 3 (dipercepat): frame NV21 langsung diberikan ke ML Kit lewat
 * [InputImage.fromByteArray]. Tidak ada lagi pembuatan bitmap abu-abu per frame
 * (sebelumnya: loop ~750 ribu piksel + bitmap baru + sampah memori tiap frame),
 * sehingga jeda antar-frame lebih pendek dan frame terbaru lebih cepat terbaca.
 *
 * Hasilnya satu teks utuh, dipakai bila tidak kosong setelah di-trim.
 * [onText] dipanggil di thread utama. [onDone] selalu dipanggil di akhir
 * agar frame berikutnya bisa diproses.
 */
class MoneyRecognizer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val worker = Executors.newSingleThreadExecutor()

    // Salinan berukuran pas (w*h*3/2). Buffer kamera lebih panjang 1 byte, dan hanya
    // satu frame diproses pada satu waktu, jadi salinan ini aman dipakai ulang.
    private var exact: ByteArray? = null

    fun process(
        nv21: ByteArray,
        width: Int,
        height: Int,
        rotationDegrees: Int,
        onText: (String) -> Unit,
        onDone: () -> Unit,
    ) {
        worker.execute {
            try {
                val size = width * height * 3 / 2
                var buf = exact
                if (buf == null || buf.size != size) {
                    buf = ByteArray(size)
                    exact = buf
                }
                System.arraycopy(nv21, 0, buf, 0, size)

                val image = InputImage.fromByteArray(
                    buf, width, height, rotationDegrees, InputImage.IMAGE_FORMAT_NV21,
                )
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val text = result.text
                        if (text.trim().isNotEmpty()) onText(text)
                    }
                    .addOnCompleteListener { onDone() }
            } catch (e: Throwable) {
                onDone()
            }
        }
    }

    fun close() {
        worker.shutdown()
        recognizer.close()
    }
}
