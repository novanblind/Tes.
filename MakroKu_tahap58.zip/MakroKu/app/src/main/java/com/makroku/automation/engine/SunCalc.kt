package com.makroku.automation.engine

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** Hitung waktu matahari terbit dan terbenam (algoritma almanak, akurat sekitar 1 sampai 2 menit). */
object SunCalc {
    private fun rad(d: Double) = d * Math.PI / 180.0
    private fun deg(r: Double) = r * 180.0 / Math.PI
    private fun norm(v: Double, r: Double): Double { var x = v % r; if (x < 0) x += r; return x }

    /** Waktu (ms epoch) pada tanggal lokal [dayMillis]; null bila matahari tidak terbit atau terbenam hari itu. */
    fun time(dayMillis: Long, lat: Double, lon: Double, sunrise: Boolean): Long? {
        val cal = Calendar.getInstance().apply { timeInMillis = dayMillis }
        val n = cal.get(Calendar.DAY_OF_YEAR)
        val lngHour = lon / 15.0
        val t = n + ((if (sunrise) 6.0 else 18.0) - lngHour) / 24.0
        val m = 0.9856 * t - 3.289
        val l = norm(m + 1.916 * sin(rad(m)) + 0.020 * sin(rad(2 * m)) + 282.634, 360.0)
        var ra = norm(deg(atan(0.91764 * tan(rad(l)))), 360.0)
        ra = (ra + (floor(l / 90) * 90 - floor(ra / 90) * 90)) / 15.0
        val sinDec = 0.39782 * sin(rad(l))
        val cosDec = cos(asin(sinDec))
        val cosH = (cos(rad(90.833)) - sinDec * sin(rad(lat))) / (cosDec * cos(rad(lat)))
        if (cosH > 1 || cosH < -1) return null
        val h = (if (sunrise) 360 - deg(acos(cosH)) else deg(acos(cosH))) / 15.0
        val ut = norm(h + ra - 0.06571 * t - 6.622 - lngHour, 24.0)
        val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
        }
        var cand = utc.timeInMillis + (ut * 3_600_000).toLong()
        val noon = Calendar.getInstance().apply {
            timeInMillis = dayMillis
            set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val hari = 24 * 3_600_000L
        while (cand - noon > hari / 2) cand -= hari
        while (cand - noon < -hari / 2) cand += hari
        return cand
    }
}
