# Novan Tel (Telegram editan) — tahap 36

Klien Telegram Android buatan sendiri: kode resmi Telegram (DrKLO/Telegram) diunduh otomatis saat build,
lalu diberi api_id Anda, nama **Novan Tel**, paket `com.novan.novantel`, dan editan Novan.
Zip ini kecil karena kode Telegram tidak disertakan; yang ada di sini hanya "resep" membangunnya.

## Cara membangun APK dengan GitHub by novan

1. Buat repositori **privat** baru (privat penting karena api_hash dan kunci tanda tangan bersifat rahasia).
2. api_hash sudah tertanam di zip ini (berkas konfigurasi-telegram.properties). Jangan bagikan zip ini; pakai repo privat. Berkas bernama sama di akar repo, bila ada, menimpa isi di zip.

3. Unggah `NovanTel_tahap38_arm32.zip / NovanTel_tahap38_arm64.zip` ke akar repo yang sama.
4. Di aplikasi, buka repo itu lalu **Mulai pembangunan APK**. Disarankan pilih **tanda tangan pribadi**
   supaya APK versi berikutnya bisa menimpa yang lama tanpa dicopot. Lewati penjaga tanda tangan dan
   enkripsi string untuk proyek ini (tidak ada MainActivity bawaan, jadi otomatis dilewati).
5. Tunggu 40–90 menit. Setelah berhasil, unduh dan pasang APK, lalu masuk dengan nomor HP Anda.

Repo privat memakai kuota gratis GitHub (sekitar 2000 menit per bulan), jadi satu build memakan sebagian kuota.

## Build cepat (pustaka native jadi, 32-bit)

Folder `prabangun/armeabi-v7a/` berisi `libtmessages.49.so` dari APK 32-bit hasil build sebelumnya. Saat build,
skrip mematikan kompilasi C/C++ (CMake/NDK) Telegram dan memakai berkas itu, jadi tinggal kompilasi Java/Kotlin
dan NDK tidak perlu dipasang. Pengaman:

- Berlaku untuk `arsitektur=arm32` (zip ini) dan `arm64`.
- Dicek otomatis: berkas harus ELF 32-bit ARM, nomor versi harus sama dengan `LIB_VERSION` di kode Telegram yang
  diunduh, dan semua fungsi `native_*` di Java harus ada di pustaka. Bila tidak cocok, log menulis LEWAT dan build
  native biasa jalan.
- Pustaka sudah memuat tambalan native (batas akun 10, pengode suara). Bila `maks_akun` diubah, set `so_jadi=false`.
- Memperbarui pustaka: ambil `lib/armeabi-v7a/libtmessages.NN.so` dari APK terbaru, timpa berkas di folder itu.

## Yang sudah ada di tahap 38

- **Versi 14.4.5 (tahap 38)**: keterangan \"belum dibaca\" tambahan pada nama tab dan pada baris obrolan DIMATIKAN (`ucapan_tab=false`); bacaan kembali persis seperti Telegram asli. Kodenya tetap ada; ubah ke `ucapan_tab=true` untuk menyalakan lagi. Pengaturan lain tidak diubah.

## Yang sudah ada di tahap 37

- **Versi 14.4.4 (tahap 37)**: penjagaan bacaan ganda (bila Telegram sudah menyebut \"pesan baru\"/belum dibaca pada baris itu, tidak ditambah lagi) dan pemeriksaan dini lebih ketat untuk `dialogs_dict` (build berhenti cepat dengan cuplikan kode bila tidak cocok). Log juga mencetak baris `[INFO UCAPAN OBROLAN]` berisi cuplikan kode Telegram terkait.

## Yang sudah ada di tahap 36

- **Versi 14.4.3 (tahap 36)**: tiap baris obrolan yang punya pesan belum dibaca kini dibacakan \"N belum dibaca\" di depan bacaannya (juga untuk channel/grup yang dibisukan); yang sudah dibaca tidak diubah. Dipasang di DialogCell dengan pemeriksaan dini (build berhenti cepat dengan baris `[DIAGNOSA UCAPAN OBROLAN]` bila kode Telegram tidak cocok). Hanya Java, `so_jadi=true` tetap berlaku.

## Yang sudah ada di tahap 35

- **Versi 14.4.2 (tahap 35)**: perubahan tunggal: keterangan belum dibaca pada nama tab kategori hanya diucapkan bila ADA yang belum dibaca, mis. \"Grup, 2 belum dibaca\", \"Pribadi, 3 belum dibaca\"; bila semua sudah dibaca, nama tab dibacakan polos tanpa keterangan. Kotak diagnosa urutan fokus dimatikan (`fokus_diagnosa=false`). Usap dua jari antar tab TIDAK ada di tahap ini. Hanya Java, `so_jadi=true` tetap berlaku.

## Yang sudah ada di tahap 32

- **Versi 14.3.8 (tahap 32, urutan fokus pembaca layar)**: `tab_intai=false` (mode intai selesai, build jalan penuh lagi). Di halaman utama, usap kanan kini bertemu: tab **Semua Obrolan**, **Grup**, **Pribadi**, **Channel**, lalu nama-nama obrolan dari atas ke bawah, dan **tombol-tombol bilah bawah layar paling akhir**. Memakai aturan urutan telusur bawaan Android (kelas baru `NovanFokus`, dipanggil dari `DialogsActivity` saat dibuka); tampilan layar tidak berubah. Bilah bawah dicari otomatis di layar (wadah tombol yang menempel dekat dasar layar). Bila kode Telegram tidak cocok, build berhenti cepat dengan baris `[DIAGNOSA FOKUS]`. Mau kembali ke urutan bawaan: `urutan_fokus=false`. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.

## Yang sudah ada di tahap 29

- **Versi 14.3.7 (tahap 29)**: tab **Grup = semua grup, Pribadi = semua obrolan pribadi, Channel = semua channel** yang Anda ikuti. Folder lama bernama Grup/Pribadi/Channel yang isinya hanya sebagian TIDAK dipakai dan disembunyikan dari tab supaya tidak kembar (tidak dihapus di Telegram). Folder buatan Anda yang isinya persis satu jenis tetap dipakai ulang; folder lain tetap tampil setelah tab kategori. `tab_intai=true` masih menyala (mode intai urutan fokus): build berhenti sengaja tanpa APK.

## Yang sudah ada di tahap 28

- **Versi 14.3.6 (tahap 28)**: tab kategori tidak lagi kembar. Folder yang sudah bernama Grup, Pribadi, atau Channel (misalnya folder Grup bawaan akun) dipakai sebagai tab itu, bukan dibuatkan lagi. `tab_intai=true` masih menyala (mode intai urutan fokus): build berhenti sengaja tanpa APK; setelah log `[INTAI TAB]` dikirim, `tab_intai=false`.

## Yang sudah ada di tahap 27

- **Versi 14.3.5 (tahap 27, MODE INTAI TAB)**: `tab_intai=true`. Tujuan berikutnya: saat aplikasi dibuka, kursor pembaca layar bertemu dulu tab Semua, lalu Grup, Pribadi, Channel, baru daftar obrolan. Build berhenti SENGAJA dalam beberapa menit, tanpa APK, dan mencetak kode Telegram terkait (baris `[INTAI TAB]`). Salin dan kirim; setelah tambalan benar, `tab_intai=false`. Fitur lain tidak diubah.

## Yang sudah ada di tahap 26

- **Versi 14.3.4 (tahap 26, perbaikan kategori)**: dari log intai terbukti proguard Telegram tidak menjaga nama di MessagesController, jadi R8 mengacak nama bidang `dialogFilters` dan refleksi gagal ("daftar folder Telegram tidak ditemukan"). `NovanKategori` kini memakai bidang publik Telegram **langsung** (satu paket, tanpa refleksi), sehingga tahan pengacakan nama. Hanya `sortDialogs` masih lewat refleksi dan dijaga aturan `-keep` di `TMessagesProj/proguard-rules.pro`. Sebelum kompilasi ada **pemeriksaan langsung** (beberapa menit): bila ada bidang yang kurang di kode Telegram, build berhenti dulu dengan baris `[DIAGNOSA KATEGORI] kurang: ...`. `kategori_intai=false`. Fitur lain tidak diubah.

## Yang sudah ada di tahap 25

- **Versi 14.3.3 (tahap 25, MODE INTAI)**: `kategori_intai=true`. Build berhenti SENGAJA dalam beberapa menit, tanpa APK, dan mencetak ke log aturan proguard, pengaturan minify, dan tempat Telegram mengisi daftar folder (baris `[INTAI KATEGORI]`). Salin baris itu dan kirim. Setelah tambalan benar, ubah jadi `kategori_intai=false`.

## Yang sudah ada di tahap 24

- **Versi 14.3.2 (tahap 24)**: perbaikan kategori yang berstatus "Gagal: daftar folder Telegram tidak ditemukan". Dugaan penyebab: R8 mengacak nama bidang `dialogFilters`. Kini aturan `-keep` untuk MessagesController, DialogFilter, dan NotificationCenter ditambahkan ke berkas proguard saat build; bila berkas proguard tidak ada, build gagal lebih awal dengan baris `[DIAGNOSA KATEGORI]`. Status di Pengaturan kini menyebut alasan gagal yang jelas. Fitur lain tidak diubah.

## Yang sudah ada di tahap 23

- **Versi 14.3.1 (tahap 23)**: tambalan kategori disesuaikan dengan kode Telegram asli hasil intai. Akun yang belum punya folder kini tidak lagi menunggu: folder bawaan Semua Obrolan dibuat lokal, sehingga tab Grup, Pribadi, Channel langsung muncul. `kategori_intai=false` (mode intai selesai). Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.

## Yang sudah ada di tahap 22

- **Versi 14.3.0 (tahap 22, kategori halaman utama)**: daftar obrolan mendapat tab **Semua Obrolan, Grup, Pribadi, Channel** (urutan itu). Pindah dengan mengetuk nama tab atau usap dua jari ke kiri/kanan, hitungan belum dibaca per tab ikut tampil: semuanya mesin folder obrolan bawaan Telegram. Tiga folder itu dipasang sebagai folder **lokal** (tidak dikirim ke server) oleh kelas baru `NovanKategori`, dan dipasang ulang setiap daftar folder diperbarui. Folder buatan Anda yang jenisnya sama persis (misalnya Grup yang hanya berisi grup, tanpa pengecualian) dipakai ulang, bukan digandakan; folder lain milik Anda tetap ada setelah tab kategori. Pribadi berisi kontak, bukan kontak, dan bot. Akun yang belum punya satu pun folder menunggu sampai dibuat satu folder. Nyala/mati di **Pengaturan Novan Tel > Kategori halaman utama** (baris itu juga menampilkan status terakhir, misalnya "Gagal: ..." bila Telegram mengubah nama bidangnya); `kategori_utama=false` mematikan dari awal. Jangan ubah atau hapus tab bawaan ini di Folder Obrolan Telegram. Akses ke bagian dalam Telegram lewat refleksi, dan sebelum membangun ada **pemeriksaan dini** (`kategori_cek=true`): bila MessagesController.dialogFilters, kelas DialogFilter (id, flags, name), atau NotificationCenter.dialogFiltersUpdated tidak ada di kode Telegram yang diunduh, build **sengaja gagal** dengan pesan jelas dan baris `[DIAGNOSA KATEGORI]` di log, supaya mudah disalin dan dikirim. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.

- **Mode intai (tahap 22)**: `kategori_intai=true` di `novan-mod.properties` membuat build berhenti SENGAJA di awal (sebelum tambalan dan kompilasi) dan mencetak ke log potongan kode Telegram yang dibutuhkan fitur kategori (baris `[INTAI KATEGORI]`). Salin baris itu dan kirim, supaya tambalan berikutnya ditulis tepat sesuai kode aslinya. Setelah itu ubah jadi `kategori_intai=false`.

## Yang sudah ada di tahap 21

- **Versi 14.2.4 (tahap 21)**: perbaikan baris **Transkripsi** di menu tekan-tahan yang tidak muncul. Penyebabnya: pemeriksaan "kait sudah ada" memakai pencocokan teks biasa, sehingga `OPSI_TRANSKRIP` dianggap sudah terpasang karena cocok dengan awal `OPSI_TRANSKRIP_ATAS` (tombol bilah atas, dipasang lebih dulu). Kini pemeriksaan memakai batas kata. Selain itu, bila baris Transkripsi tetap gagal dipasang, build **sengaja gagal** dengan pesan jelas dan baris DIAGNOSA di log, supaya mudah disalin. `transkripsi=false` melewati pemeriksaan ini. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.
- **Versi 14.2.3 (tahap 20)**: penyebab ikon Transkripsi tidak muncul sudah ketahuan lewat log diagnosa: saat masuk mode pilih lewat tekan-tahan, Telegram memanggil `addToSelectedMessages` langsung tanpa `updateActionModeTitle`, sehingga kait tahap 17 tidak berjalan untuk pesan pertama yang dipilih. Kini ikon dibuat **terlihat sejak awal**, lalu dipicu dari `addToSelectedMessages` (dan `updateActionModeTitle`): disembunyikan hanya bila yang terpilih bukan tepat satu pesan suara/video bulat. Bila kait gagal, ikon tetap terlihat. `transkripsi_atas_sembunyi=false` membuat ikon selalu terlihat. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.


- **Versi 14.2.2 (tahap 19)**: ikon **Transkripsi** di bilah atas mode pilih kini **selalu terlihat** (tidak lagi disembunyikan lewat kait), karena log diagnosa menunjukkan kait cocok tetapi ikon tetap tidak muncul pada tahap 17. Ketuk ikon dengan tepat satu pesan suara atau video bulat terpilih untuk transkripsi; bila pilihan lain muncul petunjuk, dan bila sakelar transkripsi mati muncul pesan itu. Ingin disembunyikan otomatis kembali: `transkripsi_atas_sembunyi=true`. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.


- **Versi 14.2.1 (tahap 18, ikon Transkripsi di bilah atas)**: tombol **Transkripsi** muncul di bilah atas saat tepat satu pesan suara atau video bulat dipilih (tekan-tahan, atau ketuk pesan saat mode pilih), di samping **Simpan ke Unduhan**; hilang lagi bila yang terpilih bukan satu pesan suara. Perbaikan dari tahap 17: pada tahap 17 ikon dipasang tetapi tetap tersembunyi karena hanya bergantung pada satu fungsi (updateActionModeTitle) yang tidak selalu dipanggil saat pilihan berubah. Kini pembaruan juga dipicu dari addToSelectedMessages (tiap pesan dipilih atau dilepas) dan ikon dipegang langsung, tidak dicari lewat tag. Bila kedua kait tidak ditemukan, ikon dibiarkan selalu terlihat (ketuk saat pilihan salah menampilkan petunjuk). Log build mencetak baris INFO 'Kait ikon Transkripsi: ...'. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.

- **Versi 14.1.0 (tahap 16, simpan banyak pesan dan Menuju ke pesan)**: (1) **Simpan ke Unduhan di bilah atas**: tekan-tahan satu pesan (suara, tulisan, dokumen, foto, apa pun), ketuk pesan lain bila mau memilih banyak, lalu di bilah atas muncul item **Simpan ke Unduhan** (dibaca pembaca layar dengan nama itu). Semua pesan terpilih disimpan ke Download/Telegram Novan, urut dari yang terlama; mode pilih ditutup setelahnya dan muncul pesan ringkasan, misalnya \"5 berkas tersimpan di folder Telegram Novan\". Pesan **tulisan** disimpan sebagai berkas **txt** (nama `pesan_TANGGAL_JAM_ID.txt`, isi teks pesannya); pesan berkas yang belum terunduh dilewati dan dihitung di ringkasan. Baris **Simpan ke Unduhan** di menu tekan-tahan satu pesan kini juga muncul untuk pesan tulisan (hasilnya txt), tombol **Salin** tetap ada. Sakelar Simpan ke Unduhan di Pengaturan Novan Tel berlaku juga untuk item bilah atas. (2) **Menuju ke pesan**: di info grup, kanal, atau profil, buka tab **Berkas** (juga Media dan Musik), tekan-tahan satu berkas; di bilah atas bertambah tombol **Menuju ke pesan** yang membuka obrolan tepat di pesan yang mengirim berkas itu. Bila yang terpilih lebih dari satu, muncul pesan agar memilih satu berkas saja. Dua fitur ini dipasang dengan kait pada ChatActivity dan SharedMediaLayout dari kode Telegram terbaru; bila pola kodenya tidak cocok, build tetap jalan dan log menulis LEWAT beserta baris [DIAGNOSA ...] yang menunjukkan bagian mana yang berbeda. Matikan lewat `simpan_banyak=false` dan `tombol_ke_pesan=false`. Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku.

- **Versi 14.0.0 (tahap 14, perbaikan mode hantu online/terakhir dilihat)**: baris **Status efek** di layar Efek pesan suara dan mode diagnosa build, semua log [DIAGNOSA ...], dan baris Status mode hantu dihapus; efek suara sudah terbukti bekerja. Penyebab mode hantu online (terbukti dari log diagnosa): di kode Telegram terbaru kelas ini bernama `TL_account.updateStatus` (berkas tgnet/tl/TL_account.java), jadi pencocokan lama `TL_account_updateStatus` tidak pernah cocok. Pemblokir permintaan kini mengenali permintaan status lewat nama yang diseragamkan, jadi tetap bekerja walau kode Telegram terbaru memindahkan kelas `TL_account_updateStatus` ke `TL_account.updateStatus`; sebelumnya pada tata letak baru nama tidak cocok sehingga status online tetap terkirim. Kait `sendRequest` diperluas ke varian generik (`sendRequestTyped`/`sendRequestTmp`). Penambah hitungan dilihat kini diatur lewat refleksi (tidak lagi bergantung pada nama kelas). Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku. Catatan: Telegram dapat menandai Anda online di sisi server saat Anda mengirim pesan; untuk menutupinya sepenuhnya atur juga Pengaturan > Privasi dan Keamanan > Terakhir dilihat dan online > Tidak ada.

- **Versi 13.2.8 (tahap 13)**: (1) Di **Pengaturan Novan Tel** ada bagian baru **Latar belakang dan baterai** di paling atas: tombol **Izin latar belakang (baterai tidak dibatasi)** membuka dialog sistem untuk mengecualikan Novan Tel dari penghematan baterai, dan tombol **Buka Info aplikasi** menuntun ke Penggunaan baterai (Tanpa batasan) dan Mulai otomatis, termasuk layar Mulai otomatis Oppo/ColorOS bila ada. Tanpa ini, HP (terutama Oppo/ColorOS) mematikan koneksi saat aplikasi di latar, sehingga setiap dibuka muncul "Menghubungkan...". Izin `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` dipastikan ada di manifest (log: terapkan_izin_baterai). (2) Baris **Pengaturan Novan Tel** di Pengaturan Telegram dipindah ke posisi paling atas di antara baris menu (dilakukan saat aplikasi berjalan, jadi tidak bergantung pola kode Telegram). Tidak ada perubahan kode C, jadi `so_jadi=true` tetap berlaku untuk build cepat.

- **Versi aplikasi 13.2.5** (kode 130205), di atas 13.2.4. Ganti lewat `versi_nama=` dan `versi_kode=` di `novan-mod.properties` (kode harus selalu naik agar APK baru bisa menimpa yang lama).

- **Efek pesan suara kini dipasang juga di kode C** (tahap 12): pada tahap 11, tombol Coba efek berhasil tetapi pesan suara asli tanpa efek, dan Status efek menyatakan perekam Java tidak pernah terpanggil. Jalur yang sama dipakai pengaturan kualitas pesan suara (audio.c) yang terbukti bekerja, jadi sekarang fungsi JNI `writeFrame` di audio.c memanggil `NovanEfek.prosesNative` tepat sebelum pengodean Opus, dan `startRecord` memanggil `mulaiNative`. Kait Java lama tetap ada; keduanya dijaga agar potongan suara tidak diolah dua kali. Karena kode C berubah, **`so_jadi=false`**: build memakai kompilasi native penuh (40 sampai 90 menit). Setelah APK berhasil dan efek terdengar, boleh timpa `prabangun/.../libtmessages.49.so` dengan pustaka dari APK baru itu dan kembalikan `so_jadi=true`. Baris Status efek kini menyebut kait mana yang bekerja (Java atau C). Ekor gema di akhir rekaman mungkin terpotong pada jalur C. Matikan dengan `efek_native=false`. Log build mencetak [DIAGNOSA efek native].

- **Pengaturan Novan Tel dirapikan untuk TalkBack** (tahap 11): layar utama hanya berisi daftar kategori berbentuk tombol, tiap tombol membacakan judul dan pilihan sekarang (misalnya "Gema: Mati", "Mode hantu: 5 dari 5 nyala"). Mengetuk tombol membuka dialog kecil: pilihan tunggal (radio, langsung tersimpan dan menutup) atau beberapa sakelar (centang, lalu **Selesai**). Kelompoknya: Mode hantu, Pesan suara (kualitas, unduh otomatis, simpan ke Unduhan), Efek pesan suara, Privasi akun (daftar pintasan), Konfirmasi, dan Fitur tambahan (anti hapus, blokir bersponsor, teruskan tanpa nama, salin sebagian, rapikan Pengaturan). Semua kunci pilihan lama tetap sama, jadi pilihan Anda sebelumnya tidak hilang.

- **Efek pesan suara** (v13, diperluas di tahap 11): di **Pengaturan Novan Tel > Efek pesan suara** ada lima kategori, masing-masing satu pilihan atau **Mati** (bawaan semuanya Mati, jadi pesan suara terkirim apa adanya):
  - **Gema**: ringan, sedang, panjang, gunung, ruangan kecil, kamar mandi, aula besar, katedral, gua.
  - **Pengubah suara**: anak-anak, tupai, lebih tinggi, lebih rendah, raksasa, monster, robot, alien, radio, megafon, berbisik, bawah air, bergetar.
  - **Kejernihan suara** (baru): ringan, sedang, kuat, dan suara siaran (buang dengung, tegaskan ucapan 2 sampai 5 kHz).
  - **Volume suara** (baru): naik sedikit, sedang, keras, maksimal (hingga sekitar 4, 8, 12, 16 desibel; pemampat suara agar yang pelan ikut terdengar, tanpa pecah).
  - **Bass suara** (baru): ringan, sedang, kuat, dalam (rak bass, dua yang terakhir ditambah harmonik supaya terdengar di speaker kecil).

  Kategori berbeda boleh dipakai bersamaan; urutan olahnya: pengubah suara, kejernihan, bass, gema, volume. Tombol **Matikan semua efek** mengembalikan semuanya ke Mati. Efek ikut tertanam di berkas suara yang terkirim dan berlaku untuk rekaman berikutnya. Dikerjakan di Java (kelas `NovanEfek`) pada rekaman sebelum dikodekan Opus, jadi pustaka native jadi tetap dipakai. Tidak berlaku untuk video bulat. Matikan dari awal dengan `efek_suara=false`.

  **Bila efek tidak terdengar** (perbaikan tahap 11): (1) tombol **Coba efek** merekam 4 detik dari mikrofon lalu memutar hasilnya dengan efek yang dipilih, tanpa melewati perekam Telegram. Bila di sini suara berubah, mesin efek sehat dan masalahnya di kait perekam. (2) Baris **Status efek** di bawah tombol itu menampilkan hasil rekaman pesan suara terakhir: berapa potongan suara lewat kait dan berapa yang diolah. Nilai 0 berarti kait di perekam Telegram tidak terpanggil. (3) Tambalan kait kini menerima `stopRecord` berparameter dan `startRecord` dengan parameter lain, serta mencetak baris [DIAGNOSA efek suara] "terpasang" di log build. Bila efek masih tidak bekerja, kirim bagian [DIAGNOSA efek suara] dari log build dan teks Status efek.

- api_id dan api_hash Anda dipasang di `BuildVars.java`.
- Nama aplikasi Novan Tel, `applicationId` com.novan.novantel (bisa berdampingan dengan Telegram resmi).
- `google-services.json` tiruan agar build tidak macet; notifikasi memakai koneksi latar Telegram
  (aktifkan "Layanan koneksi latar belakang" di Pengaturan > Notifikasi bila notifikasi telat).
- Hanya arsitektur ARM 32 dan 64-bit (x86 dibuang agar build lebih cepat).
- **Mode hantu**: tidak menandai terbaca di server, tidak tampil mengetik, tidak tampil online,
  cerita dan pesan suara dilihat tanpa jejak.
- **Blokir pesan bersponsor**.
- **Fitur ala TurboTel** (tahap 10):
  - **Teruskan tanpa nama pengirim**: bawaan layar teruskan jadi "sembunyikan nama pengirim" (Telegram resmi sudah punya pilihan ini, tetapi bawaannya mati). Masih bisa diubah per pesan di layar teruskan. Matikan dengan `teruskan_tanpa_kutipan=false`.
  - **Salin sebagian teks**: tekan-tahan pesan yang berteks, pilih **Salin sebagian teks**. Teks tampil di kotak yang bisa dipilih (ramah TalkBack); pilih bagian lalu **Salin pilihan**, atau **Salin semua**. Matikan dengan `salin_sebagian=false`.
  - **Lebih dari 3 akun**: batas akun dinaikkan lewat `maks_akun=10` (isi 3 sampai 16; 3 = bawaan).
  - Bila pola kode Telegram tidak cocok, log build menulis LEWAT dan bagian [DIAGNOSA TERUSKAN], [DIAGNOSA AKUN], atau [DIAGNOSA MENU PESAN].
- **Perbaikan build** (tahap 9b): galat C `static declaration of 'novan_bitrate_env' follows non-static declaration` di `audio.c` diperbaiki; fungsi pembantu kualitas suara kini ditaruh di paling atas berkas.
- **Notifikasi tanpa Google** (tahap 9): layanan koneksi latar belakang Telegram menyala sejak awal (`notifikasi_latar=true`), karena aplikasi ini memakai google-services tiruan dan tidak menerima notifikasi dorong Google. Pilihan Anda di Pengaturan > Notifikasi tetap menang. Di HP Oppo/ColorOS sebaiknya juga atur baterai Novan Tel ke tanpa batasan dan izinkan berjalan di latar.
- **Kunci peta sendiri** (tahap 9): isi `kunci_google_maps=` dengan kunci Google Maps SDK for Android milik Anda (batasi ke paket com.novan.novantel dan SHA-1 tanda tangan Anda) agar peta berbagi lokasi tampil. Kosong = peta bisa kosong, seperti semua tiruan Telegram.
- **Diagnosa TalkBack** (tahap 8): build mencetak bagian [DIAGNOSA TALKBACK] di log (hanya membaca, tidak mengubah aplikasi). Kirim bagian itu bersama daftar masalah TalkBack yang Anda alami, supaya perbaikannya tepat.
- **Simpan ke Unduhan** (tahap 6): tekan-tahan pesan yang berkasnya sudah terunduh (suara, musik, video, dokumen, foto), lalu pilih **Simpan ke Unduhan**. Berkas disalin ke folder **Telegram Novan** di dalam folder Download penyimpanan internal (folder dibuat otomatis; nama bisa diganti dengan `folder_unduhan=` di `novan-mod.properties`); berkas asli Telegram tidak berubah. Pesan suara disimpan sebagai `pesan_suara_<nomor>.ogg` (audio/ogg). Sakelar di Pengaturan Novan Tel (bawaan nyala); matikan dari awal dengan `simpan_unduhan=false`. Tambalan ini memakai pola longgar pada ChatActivity Telegram; bila tidak cocok, log build menulis LEWAT dan bagian [DIAGNOSA MENU PESAN], dan build tetap jalan tanpa fitur ini.
- **Pesan suara terunduh otomatis** (tahap 5): seperti WhatsApp, pesan suara masuk langsung terunduh sendiri lewat Wi-Fi, data seluler, dan roaming, di semua jenis obrolan (pribadi, grup, kanal). Sakelar di Pengaturan Novan Tel (bawaan nyala); matikan dari awal dengan `unduh_suara=false`. Bila kait tidak cocok dengan versi kode Telegram, log build menampilkan LEWAT dan bagian [DIAGNOSA UNDUH OTOMATIS].
- **Anti hapus** (tahap 4): bila lawan bicara menghapus pesan untuk semua orang, pesan tetap ada di HP Anda (sakelar di Pengaturan Novan Tel, bawaan nyala, `anti_hapus=false` untuk mematikan dari awal). Pesan yang Anda hapus sendiri tetap terhapus. Hanya pesan yang sudah masuk ke HP sebelum dihapus yang bisa dipertahankan.
- **Layar Pengaturan Novan Tel** (tahap 3): sakelar mode hantu (terbaca, mengetik, online/terakhir dilihat, cerita, pesan suara), blokir pesan bersponsor, dan pilihan kualitas pesan suara (terendah 18 kb/s, hemat, sedang, tinggi, asli). Berlaku langsung tanpa membangun ulang. Dibuka lewat baris **Pengaturan Novan Tel** di Pengaturan Telegram, atau lewat ikon **Pengaturan Novan Tel** di layar utama HP. Matikan ikon dengan `ikon_pengaturan=false`, matikan baris menu dengan `menu_pengaturan=false` di `novan-mod.properties`.
- **Kualitas pesan suara** (bawaan hemat): rekaman pesan suara berformat audio/ogg (Opus) dengan bitrate bawaan 32 kb/s, supaya file ringan dan cepat terkirim. Pilihan lain: terendah 18 kb/s (v13), sedang 48 kb/s, tinggi 64 kb/s. Ganti lewat `kualitas_suara=terendah|hemat|sedang|tinggi|asli` di `novan-mod.properties`. Kualitas bisa diganti kapan saja di **Pengaturan Novan Tel** (lihat di bawah).
- Semua fitur editan bisa dimatikan lewat `novan-mod.properties` (di dalam zip, atau berkas bernama sama
  di akar repo yang hanya berisi baris yang ingin diganti, misalnya `hantu_baca=false`).

## Belum ada (tahap berikutnya)

- Ikon aplikasi sendiri.
- Tahap 11 dan seterusnya: konfirmasi sebelum kirim/telepon, perbaikan TalkBack (label tombol, urutan fokus, pembacaan pesan), lalu permintaan lain.

## Bila build gagal

Di GitHub by novan, buka rincian error lalu pakai **salin log langkah yang gagal**, dan kirim ke saya.
Skrip selalu mencetak bagian DIAGNOSA (daftar tugas Gradle, baris penting build.gradle Telegram) yang
membantu memperbaiki dengan cepat. Karena kode Telegram selalu berubah, build pertama bisa butuh satu-dua
perbaikan kecil.

## Catatan ketentuan

- Ketentuan API Telegram meminta klien pihak ketiga tidak memakai nama dan logo resmi Telegram.
  Nama sudah diganti; **logo masih bawaan dan belum diganti**.
- Memblokir pesan bersponsor bisa dianggap melanggar ketentuan API dan berisiko membatasi api_id Anda.
  Matikan dengan `blokir_iklan=false` bila ingin aman.
- Berdasarkan lisensi GPL, bila APK dibagikan ke orang lain, kode editannya wajib dibagikan juga.

## Isi proyek

- `build.gradle`, `settings.gradle`: pembungkus agar `gradle assembleDebug/assembleRelease` memanggil skrip.
- `tools/bangun.py`: alur build (unduh, tambal, pasang SDK/NDK, bangun, tandatangani).
- `tools/terapkan.py`: semua tambalan pada kode Telegram.
- `overlay/NovanMod.java`: kelas editan (mode hantu, blokir iklan).
- `overlay/NovanEfek.java`: mesin efek pesan suara (gema, pengubah suara, kejernihan, volume, bass).
- `overlay/NovanPengaturanActivity.java`: layar Pengaturan Novan Tel.
- `overlay/NovanKategori.java`: tab kategori halaman utama (Grup, Pribadi, Channel).
