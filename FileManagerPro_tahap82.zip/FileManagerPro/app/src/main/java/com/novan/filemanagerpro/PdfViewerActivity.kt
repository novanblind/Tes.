package com.novan.filemanagerpro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.concurrent.Executors

/**
 * Penampil PDF bawaan (tahap 78). Dua tampilan:
 * - Teks: isi tiap halaman dibaca sebagai blok teks per paragraf, judul "Halaman N dari M"
 *   bertanda judul untuk TalkBack. Bawaan bila pembaca layar menyala.
 * - Halaman: halaman digambar seperti aslinya (PdfRenderer bawaan Android).
 * Ada pencarian teks, loncat ke halaman, salin semua teks, dan buka dengan aplikasi lain.
 */
class PdfViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        private const val MAX_COPY_BYTES = 300L * 1024 * 1024
        private const val MAX_TEXT_PAGES = 3000
        private const val MAX_BLOCK_CHARS = 3000
        private const val PARA_END = "\u2029"
        private const val K_INFO = 0
        private const val K_HEAD = 1
        private const val K_PARA = 2

        fun isSupported(f: File): Boolean = f.isFile && f.name.endsWith(".pdf", ignoreCase = true)
    }

    private class Item(val kind: Int, val page: Int, val text: String)

    private val textExec = Executors.newSingleThreadExecutor()
    private val renderExec = Executors.newSingleThreadExecutor()
    private val renderLock = Any()
    private val main = Handler(Looper.getMainLooper())

    private lateinit var list: RecyclerView
    private lateinit var progress: View
    private lateinit var bar: View
    private lateinit var lm: LinearLayoutManager

    private val items = ArrayList<Item>()
    private val pageStart = ArrayList<Int>()
    private val textAdapter = TextAdapter()
    private val pageAdapter = PageAdapter()

    private var file: File? = null
    private var srcUri: Uri? = null
    private var tmp: File? = null
    private var docName = ""
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var pageCount = 0
    private var textMode = true
    private var textScale = 1f
    private var curPos = 0
    private var touchScroll = false
    private var lastQuery = ""
    private var ready = false
    private var destroyed = false
    private var anyText = false
    private var textDone = false

    private fun prefs() = getSharedPreferences("pdfviewer", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_viewer)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        list = findViewById(R.id.pdfList)
        progress = findViewById(R.id.pdfProgress)
        bar = findViewById(R.id.pdfBar)
        bar.visibility = View.GONE

        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        textMode = prefs().getBoolean("text_mode", am.isTouchExplorationEnabled)
        textScale = prefs().getFloat("text_scale", 1f)

        lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.adapter = if (textMode) textAdapter else pageAdapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) touchScroll = true
                else if (newState == RecyclerView.SCROLL_STATE_IDLE) touchScroll = false
            }

            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (touchScroll) {
                    val p = lm.findFirstVisibleItemPosition()
                    if (p >= 0) curPos = p
                }
            }
        })
        findViewById<View>(R.id.btnPrevPage).setOnClickListener { goPage(-1) }
        findViewById<View>(R.id.btnNextPage).setOnClickListener { goPage(1) }

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path != null) {
            file = File(path)
        } else {
            val d = intent.data
            if (d != null && d.scheme == "file" && d.path != null) file = File(d.path!!) else srcUri = d
        }
        docName = file?.name ?: queryName(srcUri) ?: getString(R.string.pdf_viewer)
        title = docName
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        textExec.shutdownNow()
        renderExec.shutdownNow()
        synchronized(renderLock) {
            try { renderer?.close() } catch (e: Exception) { }
            try { pfd?.close() } catch (e: Exception) { }
            renderer = null
            pfd = null
        }
        tmp?.delete()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun queryName(u: Uri?): String? {
        if (u == null) return null
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: u.lastPathSegment
        } catch (e: Exception) {
            u.lastPathSegment
        }
    }

    // ------------------------------------------------------------------ memuat

    private fun load() {
        textExec.execute {
            var err: String? = null
            var f: File? = file
            try {
                if (f == null) {
                    val u = srcUri ?: throw IllegalStateException(getString(R.string.cannot_open))
                    val t = File(cacheDir, "pdf_view.tmp")
                    var total = 0L
                    contentResolver.openInputStream(u)?.use { ins ->
                        t.outputStream().use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                total += n
                                if (total > MAX_COPY_BYTES) throw IllegalStateException(getString(R.string.pdf_too_large))
                                out.write(buf, 0, n)
                            }
                        }
                    } ?: throw IllegalStateException(getString(R.string.cannot_open))
                    tmp = t
                    f = t
                }
                val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = try {
                    PdfRenderer(fd)
                } catch (e: SecurityException) {
                    try { fd.close() } catch (x: Exception) { }
                    throw IllegalStateException(getString(R.string.pdf_password))
                }
                pfd = fd
                renderer = r
                pageCount = r.pageCount
            } catch (e: IllegalStateException) {
                err = e.message
            } catch (e: Exception) {
                err = getString(R.string.pdf_unreadable)
            }
            val e2 = err
            main.post {
                if (destroyed) return@post
                progress.visibility = View.GONE
                if (e2 != null || pageCount == 0) fail(e2 ?: getString(R.string.pdf_unreadable))
                else onOpened()
            }
            if (e2 == null && pageCount > 0 && f != null) extractText(f)
        }
    }

    private fun onOpened() {
        ready = true
        val summary = getString(R.string.pdf_summary, docName, pageCount)
        items.add(Item(K_INFO, 0, summary))
        bar.visibility = View.VISIBLE
        textAdapter.notifyDataSetChanged()
        pageAdapter.notifyDataSetChanged()
        invalidateOptionsMenu()
        list.announceForAccessibility(summary)
        list.postDelayed({ focusItem(0) }, 400)
    }

    private fun extractText(f: File) {
        val chunk = ArrayList<Item>()
        val starts = ArrayList<Int>()
        var base = 1
        try {
            PDFBoxResourceLoader.init(applicationContext)
            val pd = PDDocument.load(f)
            pd.use { doc ->
                val total = minOf(doc.numberOfPages, MAX_TEXT_PAGES)
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                stripper.paragraphEnd = PARA_END
                var pendingFrom = 1
                for (p in 1..total) {
                    if (destroyed) return
                    var raw = ""
                    try {
                        stripper.startPage = p
                        stripper.endPage = p
                        raw = stripper.getText(doc)
                    } catch (e: Exception) {
                        raw = ""
                    }
                    starts.add(base + chunk.size)
                    chunk.add(Item(K_HEAD, p, getString(R.string.pdf_page_heading, p, pageCount)))
                    var n = 0
                    for (part in raw.split(PARA_END)) {
                        val t = part.replace("\r", "").trim()
                        if (t.isEmpty()) continue
                        for (piece in splitLong(t)) {
                            chunk.add(Item(K_PARA, p, piece))
                            n++
                        }
                    }
                    if (n == 0) {
                        chunk.add(Item(K_PARA, p, getString(R.string.pdf_page_empty)))
                    } else {
                        anyText = true
                    }
                    if (p - pendingFrom + 1 >= 5 || p == total) {
                        val c = ArrayList(chunk)
                        val s = ArrayList(starts)
                        chunk.clear()
                        starts.clear()
                        pendingFrom = p + 1
                        postChunk(c, s)
                        base += c.size
                    }
                }
                if (pageCount > total) {
                    val c = arrayListOf(Item(K_PARA, total, getString(R.string.pdf_text_truncated, total)))
                    postChunk(c, ArrayList())
                }
            }
        } catch (e: InvalidPasswordException) {
            main.post { if (!destroyed) say(getString(R.string.pdf_password)) }
        } catch (e: Throwable) {
            main.post {
                if (destroyed) return@post
                say(getString(R.string.pdf_text_failed))
                if (textMode) setMode(false)
            }
        }
        main.post {
            if (destroyed) return@post
            textDone = true
            if (!anyText && pageCount > 0) {
                say(getString(R.string.pdf_no_text))
                if (textMode) setMode(false)
            }
            invalidateOptionsMenu()
        }
    }

    private fun postChunk(c: ArrayList<Item>, s: ArrayList<Int>) {
        main.post {
            if (destroyed) return@post
            val from = items.size
            pageStart.addAll(s)
            items.addAll(c)
            textAdapter.notifyItemRangeInserted(from, c.size)
        }
    }

    private fun splitLong(t: String): List<String> {
        if (t.length <= MAX_BLOCK_CHARS) return listOf(t)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in t.split("\n")) {
            if (sb.length + line.length + 1 > MAX_BLOCK_CHARS && sb.isNotEmpty()) {
                out.add(sb.toString().trim())
                sb.setLength(0)
            }
            if (line.length > MAX_BLOCK_CHARS) {
                var i = 0
                while (i < line.length) {
                    out.add(line.substring(i, minOf(line.length, i + MAX_BLOCK_CHARS)))
                    i += MAX_BLOCK_CHARS
                }
            } else {
                sb.append(line).append('\n')
            }
        }
        if (sb.isNotBlank()) out.add(sb.toString().trim())
        return out
    }

    private fun fail(msg: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.pdf_error_title)
            .setMessage(msg)
            .setPositiveButton(R.string.office_open_other) { _, _ -> openExternal(); finish() }
            .setNegativeButton(R.string.close) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ------------------------------------------------------------------ navigasi

    private fun focusItem(pos: Int, retry: Int = 2) {
        val v = list.findViewHolderForAdapterPosition(pos)?.itemView
        if (v != null) {
            v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
            v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        } else if (retry > 0) {
            list.postDelayed({ focusItem(pos, retry - 1) }, 200)
        }
    }

    private fun jumpPos(pos: Int) {
        val n = if (textMode) items.size else pageCount
        if (pos !in 0 until n) return
        curPos = pos
        lm.scrollToPositionWithOffset(pos, 0)
        list.postDelayed({ focusItem(pos) }, 150)
    }

    private fun curPage(): Int =
        if (textMode) (items.getOrNull(curPos)?.page ?: 1).coerceAtLeast(1) else curPos + 1

    private fun jumpToPage(p: Int) {
        if (p < 1 || p > pageCount) {
            say(getString(R.string.pdf_page_range, pageCount)); return
        }
        if (textMode) {
            val pos = pageStart.getOrNull(p - 1)
            if (pos == null) { say(getString(R.string.pdf_page_loading)); return }
            jumpPos(pos)
        } else {
            jumpPos(p - 1)
        }
    }

    private fun goPage(dir: Int) {
        val t = curPage() + dir
        if (t < 1) { say(getString(R.string.pdf_first_page)); return }
        if (t > pageCount) { say(getString(R.string.pdf_last_page)); return }
        jumpToPage(t)
    }

    private fun setMode(text: Boolean) {
        if (text == textMode) return
        val page = curPage()
        textMode = text
        prefs().edit().putBoolean("text_mode", text).apply()
        list.adapter = if (text) textAdapter else pageAdapter
        invalidateOptionsMenu()
        list.postDelayed({
            curPos = 0
            jumpToPage(page)
        }, 100)
        say(getString(if (text) R.string.pdf_mode_text_on else R.string.pdf_mode_page_on))
    }

    private fun promptGoto() {
        val input = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.pdf_goto_hint, pageCount)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.pdf_goto)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ ->
                val n = input.text.toString().trim().toIntOrNull()
                if (n == null) say(getString(R.string.pdf_page_range, pageCount)) else jumpToPage(n)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------------------ cari

    private fun promptFind() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.office_search_hint)
            setText(lastQuery)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.editor_find)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> find(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun find(q: String) {
        if (q.isEmpty()) return
        if (!anyText && textDone) { say(getString(R.string.pdf_no_text)); return }
        lastQuery = q
        invalidateOptionsMenu()
        val n = items.size
        if (n < 2) { say(getString(R.string.editor_not_found)); return }
        val start = if (textMode) curPos else (pageStart.getOrNull(curPos) ?: 0)
        for (step in 1..n) {
            val i = (start + step) % n
            val it = items[i]
            if (it.kind == K_INFO) continue
            if (it.kind == K_PARA && it.text.contains(q, ignoreCase = true)) {
                if (textMode) jumpPos(i) else jumpPos(it.page - 1)
                say(getString(R.string.pdf_found, it.page, pageCount))
                return
            }
        }
        say(if (textDone) getString(R.string.editor_not_found) else getString(R.string.pdf_not_found_yet))
    }

    // ------------------------------------------------------------------ menu

    private fun copyAll() {
        val sb = StringBuilder()
        for (it in items) {
            if (it.kind == K_INFO) continue
            sb.append(it.text).append(if (it.kind == K_HEAD) "\n" else "\n\n")
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(docName, sb.toString().trim()))
        say(getString(R.string.office_copied))
    }

    private fun openExternal() {
        val f = file
        if (f != null) {
            if (!Util.openWith(this, f)) say(getString(R.string.cannot_open))
            return
        }
        val u = srcUri ?: return
        try {
            val base = Intent(Intent.ACTION_VIEW)
                .setDataAndType(u, "application/pdf")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(base, getString(R.string.open_with_title))
                .putExtra(
                    Intent.EXTRA_EXCLUDE_COMPONENTS,
                    arrayOf(ComponentName(this, PdfViewerActivity::class.java))
                )
            startActivity(chooser)
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    private fun changeScale(delta: Float) {
        val n = (textScale + delta).coerceIn(0.8f, 3.0f)
        if (n == textScale) { say(getString(R.string.pdf_scale_limit)); return }
        textScale = n
        prefs().edit().putFloat("text_scale", n).apply()
        textAdapter.notifyDataSetChanged()
        say(getString(R.string.pdf_scale_now, (n * 100).toInt()))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.pdf_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        for (id in listOf(R.id.action_pdf_find, R.id.action_pdf_goto, R.id.action_pdf_mode, R.id.action_pdf_copy)) {
            menu.findItem(id).isVisible = ready
        }
        menu.findItem(R.id.action_pdf_find_next).isVisible = ready && lastQuery.isNotEmpty()
        menu.findItem(R.id.action_pdf_bigger).isVisible = ready && textMode
        menu.findItem(R.id.action_pdf_smaller).isVisible = ready && textMode
        menu.findItem(R.id.action_pdf_mode).setTitle(
            if (textMode) R.string.pdf_mode_to_page else R.string.pdf_mode_to_text
        )
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_pdf_find -> promptFind()
            R.id.action_pdf_find_next -> find(lastQuery)
            R.id.action_pdf_goto -> promptGoto()
            R.id.action_pdf_mode -> setMode(!textMode)
            R.id.action_pdf_bigger -> changeScale(0.2f)
            R.id.action_pdf_smaller -> changeScale(-0.2f)
            R.id.action_pdf_copy -> copyAll()
            R.id.action_pdf_open_with -> openExternal()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ------------------------------------------------------------------ adapter teks

    private inner class TextAdapter : RecyclerView.Adapter<TextAdapter.VH>() {

        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv) {
            init {
                ViewCompat.setAccessibilityDelegate(tv, object : AccessibilityDelegateCompat() {
                    override fun sendAccessibilityEvent(host: View, eventType: Int) {
                        super.sendAccessibilityEvent(host, eventType)
                        if (eventType == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED) {
                            val p = bindingAdapterPosition
                            if (p >= 0) curPos = p
                        }
                    }
                })
            }
        }

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_office_block, parent, false) as TextView
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val b = items[position]
            val tv = h.tv
            val head = b.kind == K_HEAD
            tv.text = b.text
            tv.setTypeface(null, if (head || b.kind == K_INFO) Typeface.BOLD else Typeface.NORMAL)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, (if (head) 20f else 16f) * textScale)
            ViewCompat.setAccessibilityHeading(tv, head)
        }
    }

    // ------------------------------------------------------------------ adapter halaman

    private inner class PageAdapter : RecyclerView.Adapter<PageAdapter.VH>() {

        inner class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

        override fun getItemCount() = if (ready) pageCount else 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val iv = ImageView(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                isFocusable = true
                setBackgroundColor(Color.WHITE)
            }
            return VH(iv)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val iv = h.iv
            val dp = resources.displayMetrics.density
            iv.setImageBitmap(null)
            iv.contentDescription = getString(R.string.pdf_page_image, position + 1, pageCount)
            ViewCompat.setAccessibilityHeading(iv, true)
            val lp = iv.layoutParams as RecyclerView.LayoutParams
            lp.bottomMargin = (6 * dp).toInt()
            iv.layoutParams = lp
            val w = (if (list.width > 0) list.width else resources.displayMetrics.widthPixels)
            iv.minimumHeight = (w * 1.3f).toInt()
            val pos = position
            renderExec.execute {
                var bmp: Bitmap? = null
                try {
                    synchronized(renderLock) {
                        val r = renderer ?: return@execute
                        val page = r.openPage(pos)
                        try {
                            val ph = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                            val b = Bitmap.createBitmap(w, ph, Bitmap.Config.ARGB_8888)
                            b.eraseColor(Color.WHITE)
                            page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp = b
                        } finally {
                            page.close()
                        }
                    }
                } catch (e: Throwable) {
                    bmp = null
                }
                val result = bmp
                main.post {
                    if (destroyed) return@post
                    if (h.bindingAdapterPosition == pos && result != null) {
                        iv.minimumHeight = 0
                        iv.setImageBitmap(result)
                    }
                }
            }
        }

        override fun onViewRecycled(h: VH) {
            h.iv.setImageBitmap(null)
        }
    }
}
