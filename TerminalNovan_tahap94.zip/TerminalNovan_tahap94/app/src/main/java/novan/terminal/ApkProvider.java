package novan.terminal;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;

/** Menyajikan berkas .apk hasil bangun ke pemasang paket Android tanpa pustaka tambahan. Hanya berkas .apk yang dilayani. */
public class ApkProvider extends ContentProvider {
    static Uri uri(Context c, File f) {
        return new Uri.Builder().scheme("content").authority(c.getPackageName() + ".apk")
            .appendPath("apk").appendQueryParameter("p", f.getAbsolutePath()).build();
    }

    private File berkas(Uri u) throws FileNotFoundException {
        String p = u.getQueryParameter("p");
        if (p == null) throw new FileNotFoundException("tanpa lokasi");
        File f = new File(p);
        if (!f.getName().toLowerCase().endsWith(".apk") || !f.isFile()) throw new FileNotFoundException("bukan berkas apk");
        return f;
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(berkas(u), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public String getType(Uri u) { return "application/vnd.android.package-archive"; }

    @Override public Cursor query(Uri u, String[] proj, String sel, String[] args, String order) {
        try {
            File f = berkas(u);
            MatrixCursor c = new MatrixCursor(new String[]{"_display_name", "_size"});
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (FileNotFoundException e) { return null; }
    }

    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
