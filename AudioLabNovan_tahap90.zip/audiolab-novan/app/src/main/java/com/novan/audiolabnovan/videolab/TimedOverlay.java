package com.novan.audiolabnovan.videolab;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.TextOverlay;

/** Satu teks atau stiker yang tampil pada rentang waktu tertentu, dengan animasi masuk. */
@UnstableApi
public final class TimedOverlay extends TextOverlay {
    private static final long ANIM_US = 400_000L;
    private static final SpannableString IDLE_TEXT = new SpannableString(" ");
    private static final OverlaySettings IDLE_SETTINGS =
            new OverlaySettings.Builder().setAlphaScale(0f).build();

    private final long startUs;
    private final long endUs;
    private final SpannableString text;
    private final float bgX, bgY, ovX, ovY;
    private final int anim;

    public TimedOverlay(long startUs, long endUs, String content, int sizePx, int color,
                        boolean background, float bgX, float bgY, float ovX, float ovY, int anim) {
        this.startUs = startUs;
        this.endUs = endUs;
        SpannableString ss = new SpannableString(content);
        int len = ss.length();
        ss.setSpan(new AbsoluteSizeSpan(sizePx), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new ForegroundColorSpan(color), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (background) {
            ss.setSpan(new BackgroundColorSpan(0x99000000), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        this.text = ss;
        this.bgX = bgX;
        this.bgY = bgY;
        this.ovX = ovX;
        this.ovY = ovY;
        this.anim = anim;
    }

    private boolean active(long t) {
        return t >= startUs && t < endUs;
    }

    @Override
    public SpannableString getText(long presentationTimeUs) {
        // Objek yang sama dikembalikan terus supaya gambar teks tidak dibuat ulang tiap frame.
        return active(presentationTimeUs) ? text : IDLE_TEXT;
    }

    @Override
    public OverlaySettings getOverlaySettings(long presentationTimeUs) {
        if (!active(presentationTimeUs)) return IDLE_SETTINGS;
        float inP = Math.min(1f, (presentationTimeUs - startUs) / (float) ANIM_US);
        float alpha = 1f;
        float scale = 1f;
        float y = bgY;
        if (anim == 1) {
            float outP = Math.min(1f, (endUs - presentationTimeUs) / (float) ANIM_US);
            alpha = Math.max(0f, Math.min(inP, outP));
        } else if (anim == 2) {
            alpha = inP;
            y = bgY - (1f - inP) * 0.3f;
        } else if (anim == 3) {
            alpha = inP;
            scale = 0.3f + 0.7f * inP;
        }
        return new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(bgX, y)
                .setOverlayFrameAnchor(ovX, ovY)
                .setScale(scale, scale)
                .setAlphaScale(alpha)
                .build();
    }
}
