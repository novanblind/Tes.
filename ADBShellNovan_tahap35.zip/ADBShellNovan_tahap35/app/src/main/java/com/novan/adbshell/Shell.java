package com.novan.adbshell;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import io.github.muntashirakon.adb.AdbStream;

public class Shell {
    /** Jalankan layanan ADB (misal "shell:perintah") dan kembalikan keluarannya. */
    static String run(Adb a, String dest, Consumer<String> out) throws Exception {
        AdbStream s = a.openStream(dest);
        try {
            return bacaSemua(s, out);
        } finally {
            try { s.close(); } catch (Throwable ignored) {}
        }
    }

    /** Baca keluaran sampai stream ditutup; "Stream closed" dianggap akhir data. */
    private static String bacaSemua(AdbStream s, Consumer<String> out) throws Exception {
        StringBuilder sb = new StringBuilder();
        try {
            Reader r = new InputStreamReader(s.openInputStream(), StandardCharsets.UTF_8);
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0) {
                String t = new String(buf, 0, n);
                sb.append(t);
                if (out != null) out.accept(t);
            }
        } catch (java.io.IOException e) {
            String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
            if (!m.contains("closed") && sb.length() == 0) throw e;
        }
        return sb.toString();
    }

    static long sizeOf(Context c, Uri u) throws Exception {
        try (Cursor cur = c.getContentResolver().query(u, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !cur.isNull(i)) return cur.getLong(i);
            }
        }
        try (AssetFileDescriptor fd = c.getContentResolver().openAssetFileDescriptor(u, "r")) {
            if (fd != null && fd.getLength() >= 0) return fd.getLength();
        }
        throw new Exception("Ukuran berkas tidak diketahui");
    }

    private static final String INSTALLER = "com.android.vending";

    private static String namaBerkas(Context c, Uri u) {
        try (Cursor cur = c.getContentResolver().query(u, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !cur.isNull(i)) return cur.getString(i);
            }
        } catch (Throwable ignored) {}
        String l = u.getLastPathSegment();
        return l == null ? "berkas" : l;
    }

    /** Salin berkas pilihan ke cache supaya bisa dibaca sebagai ZIP (paket bundel perlu akses acak). */
    private static File salinKeCache(Context c, Uri u, Consumer<String> progress) throws Exception {
        long total = -1;
        try { total = sizeOf(c, u); } catch (Throwable ignored) {}
        File f = new File(c.getCacheDir(), "pasang_" + System.nanoTime() + ".tmp");
        try (InputStream in = c.getContentResolver().openInputStream(u);
             OutputStream o = new FileOutputStream(f)) {
            if (in == null) throw new Exception("Berkas tidak bisa dibuka");
            byte[] buf = new byte[64 * 1024];
            long n = 0, last = 0;
            int r;
            while ((r = in.read(buf)) > 0) {
                o.write(buf, 0, r);
                n += r;
                if (progress != null && n - last >= 20L * 1024 * 1024) {
                    last = n;
                    progress.accept("Menyiapkan berkas " + (total > 0 ? (n * 100 / total) + "%" : (n / 1048576) + " MB"));
                }
            }
        } catch (Throwable e) {
            f.delete();
            throw e;
        }
        return f;
    }

    // ---------- Pemilihan pecahan (split) sesuai HP ----------

    private static final String[] DENSITAS = {"ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"};
    private static final int[] DENSITAS_DPI = {120, 160, 213, 240, 320, 480, 640};

    private static String token(String nama) {
        String n = nama.toLowerCase(Locale.ROOT);
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        if (n.endsWith(".apk")) n = n.substring(0, n.length() - 4);
        int k = n.lastIndexOf("config.");
        String t = null;
        if (k >= 0) t = n.substring(k + 7);
        else if (n.startsWith("base-")) t = n.substring(5);
        else if (n.startsWith("split_")) t = n.substring(6);
        if (t == null) return null;
        return t.replace('-', '_');
    }

    private static boolean abi(String t) {
        return t.equals("arm64_v8a") || t.equals("armeabi_v7a") || t.equals("armeabi")
                || t.equals("x86") || t.equals("x86_64") || t.equals("mips") || t.equals("mips64");
    }

    private static int indeksDensitas(String t) {
        for (int i = 0; i < DENSITAS.length; i++) if (DENSITAS[i].equals(t)) return i;
        return -1;
    }

    /** Dari semua APK di dalam paket, ambil base + pecahan yang cocok untuk HP ini. */
    static List<ZipEntry> pilihSplit(Context c, List<ZipEntry> semua) {
        Set<String> abiHp = new HashSet<>();
        for (String a : Build.SUPPORTED_ABIS) abiHp.add(a.toLowerCase(Locale.ROOT).replace('-', '_'));
        int dpi = c.getResources().getDisplayMetrics().densityDpi;
        String bahasa = Locale.getDefault().getLanguage().toLowerCase(Locale.ROOT);

        // densitas yang tersedia dan paling dekat dengan HP
        int terbaik = -1, selisih = Integer.MAX_VALUE;
        for (ZipEntry e : semua) {
            String t = token(e.getName());
            int d = t == null ? -1 : indeksDensitas(t);
            if (d >= 0 && Math.abs(DENSITAS_DPI[d] - dpi) < selisih) {
                selisih = Math.abs(DENSITAS_DPI[d] - dpi);
                terbaik = d;
            }
        }
        List<ZipEntry> hasil = new ArrayList<>();
        for (ZipEntry e : semua) {
            String t = token(e.getName());
            if (t == null) { hasil.add(e); continue; }
            if (abi(t)) { if (abiHp.contains(t)) hasil.add(e); continue; }
            int d = indeksDensitas(t);
            if (d >= 0) { if (d == terbaik) hasil.add(e); continue; }
            if (t.matches("[a-z]{2,3}(_r[a-z]{2})?")) {
                int gb = t.indexOf('_');
                String bhs = gb > 0 ? t.substring(0, gb) : t;
                if (bhs.equals(bahasa) || bhs.equals("en")) hasil.add(e);
                continue;
            }
            hasil.add(e); // modul fitur atau pecahan lain: ikutkan
        }
        return hasil;
    }

    // ---------- Pemasangan ----------

    /** Kirim isi stream ke perintah ADB lewat stdin sebanyak size byte, kembalikan keluarannya. */
    private static String alirkan(Adb a, String dest, InputStream in, long size, long[] sent,
                                  long total, String label, Consumer<String> progress) throws Exception {
        AdbStream s = a.openStream(dest);
        try {
            java.io.IOException gagalTulis = null;
            try {
                OutputStream os = s.openOutputStream();
                byte[] buf = new byte[32 * 1024];
                int n;
                long lastReport = sent[1];
                while ((n = in.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    sent[0] += n;
                    if (progress != null && sent[0] - lastReport >= 5L * 1024 * 1024) {
                        lastReport = sent[0];
                        progress.accept(label + " " + (total > 0 ? (sent[0] * 100 / total) : 0) + "%");
                    }
                }
                sent[1] = lastReport;
                try { os.flush(); } catch (java.io.IOException ignored) {}
            } catch (java.io.IOException e) {
                gagalTulis = e;
            }
            String hasil = bacaSemua(s, null);
            if (gagalTulis != null && hasil.trim().isEmpty()) throw gagalTulis;
            if (gagalTulis != null && !hasil.contains("Success")) {
                return "Pengiriman terputus (" + gagalTulis.getMessage() + "): " + hasil;
            }
            return hasil;
        } finally {
            try { s.close(); } catch (Throwable ignored) {}
        }
    }

    /**
     * Pasang APK tunggal ATAU paket bundel (APKS, APKM, XAPK, APK+, atau ZIP berisi APK)
     * dengan pemasang tercatat com.android.vending (Google Play Store).
     * Hasil diawali "Success" jika berhasil.
     */
    static String installApk(Context c, Adb a, Uri uri, Consumer<String> progress) throws Exception {
        File tmp = salinKeCache(c, uri, progress);
        ZipFile zf = null;
        try {
            try { zf = new ZipFile(tmp); } catch (Throwable e) { zf = null; }
            if (zf == null) {
                return "Failure: berkas ini bukan APK atau paket bundel (APKS, APKM, XAPK) yang valid.";
            }
            List<ZipEntry> apk = new ArrayList<>();
            List<ZipEntry> extra = new ArrayList<>();
            boolean tunggal = zf.getEntry("AndroidManifest.xml") != null;
            if (!tunggal) {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    if (e.isDirectory()) continue;
                    String n = e.getName();
                    String low = n.toLowerCase(Locale.ROOT);
                    if (low.endsWith(".apk")) {
                        if (low.startsWith("standalones/") || low.startsWith("instant/")) continue;
                        apk.add(e);
                    } else if (low.startsWith("android/obb/") || low.startsWith("android/data/")) {
                        extra.add(e);
                    }
                }
                apk = pilihSplit(c, apk);
                if (apk.isEmpty()) return "Failure: tidak ada berkas APK di dalam paket ini.";
            }

            long total = 0;
            if (tunggal) total = tmp.length();
            else for (ZipEntry e : apk) {
                if (e.getSize() < 0) return "Failure: ukuran " + e.getName() + " tidak diketahui.";
                total += e.getSize();
            }

            progress.accept(tunggal ? "Membuat sesi pemasangan..."
                    : "Membuat sesi pemasangan untuk " + apk.size() + " berkas APK...");
            String out = run(a, "exec:cmd package install-create -S " + total + " -i " + INSTALLER + " -r", null);
            Matcher m = Pattern.compile("\\[(\\d+)\\]").matcher(out);
            if (!m.find()) return "Failure: gagal membuat sesi: " + out.trim();
            String sid = m.group(1);

            long[] sent = {0, 0};
            boolean ok = false;
            try {
                if (tunggal) {
                    try (InputStream in = new FileInputStream(tmp)) {
                        String r = alirkan(a, "exec:cmd package install-write -S " + total + " " + sid + " base.apk -",
                                in, total, sent, total, "Mengirim", progress);
                        if (!r.contains("Success")) return "Failure: " + r.trim();
                    }
                } else {
                    int i = 0;
                    for (ZipEntry e : apk) {
                        String nama = (i == 0 ? "base" : "split" + i) + ".apk";
                        progress.accept("Mengirim " + (i + 1) + " dari " + apk.size() + ": " + e.getName());
                        try (InputStream in = zf.getInputStream(e)) {
                            String r = alirkan(a, "exec:cmd package install-write -S " + e.getSize() + " " + sid + " " + nama + " -",
                                    in, e.getSize(), sent, total, "Mengirim " + (i + 1) + "/" + apk.size(), progress);
                            if (!r.contains("Success")) return "Failure: " + r.trim();
                        }
                        i++;
                    }
                }
                progress.accept("Menyelesaikan pemasangan...");
                String r = run(a, "exec:cmd package install-commit " + sid, null);
                if (!r.contains("Success")) return "Failure: " + r.trim();
                ok = true;
            } finally {
                if (!ok) {
                    try { run(a, "exec:cmd package install-abandon " + sid, null); } catch (Throwable ignored) {}
                }
            }

            StringBuilder hasil = new StringBuilder("Success");
            if (!extra.isEmpty()) {
                int berhasil = 0;
                for (ZipEntry e : extra) {
                    if (e.getSize() < 0) continue;
                    String path = "/sdcard/" + e.getName().replace("\\", "/");
                    path = path.replace("/sdcard/android/", "/sdcard/Android/");
                    String dir = path.substring(0, path.lastIndexOf('/'));
                    try {
                        progress.accept("Menyalin data tambahan: " + e.getName());
                        run(a, "exec:mkdir -p '" + dir + "'", null);
                        try (InputStream in = zf.getInputStream(e)) {
                            long[] s2 = {0, 0};
                            alirkan(a, "exec:head -c " + e.getSize() + " > '" + path + "'",
                                    in, e.getSize(), s2, e.getSize(), "Menyalin data", progress);
                        }
                        berhasil++;
                    } catch (Throwable t) {
                        hasil.append("\nGagal menyalin ").append(e.getName()).append(": ").append(t);
                    }
                }
                hasil.append("\nData tambahan (OBB/data) tersalin: ").append(berhasil)
                        .append(" dari ").append(extra.size()).append(".");
            }
            return hasil.toString();
        } finally {
            if (zf != null) { try { zf.close(); } catch (Throwable ignored) {} }
            tmp.delete();
        }
    }
}
