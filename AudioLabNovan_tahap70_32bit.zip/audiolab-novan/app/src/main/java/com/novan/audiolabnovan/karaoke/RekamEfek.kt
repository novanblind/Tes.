package com.novan.audiolabnovan.karaoke

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.os.Process
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.pow

/**
 * Tahap 47: perekam mikrofon dengan efek langsung. Mikrofon dibaca mentah (AudioRecord), dilewatkan rantai
 * penguat, bass dan penjernih, pengolah vokal, echo dan gema, lalu pembatas, dan ditulis ke berkas WAV 16 bit.
 * Bila pantauan menyala dan headset terpasang, suara hasil efek juga diputar ke headset.
 *
 * Rekaman mono; menjadi stereo hanya bila echo atau gema menyala (gema dihitung kiri dan kanan).
 * Jeda membuang data yang dibaca dan mengosongkan sisa gema supaya tidak terdengar sisa lama sesudah lanjut.
 */
class RekamEfek(private val ctx: Context, private val ep: EfekRekamPrefs) {

    @Volatile private var berjalan = false
    @Volatile var jeda = false
    /** Puncak suara terbesar yang pernah terekam (0..32767), untuk mendeteksi rekaman hening. */
    @Volatile var puncak = 0
        private set
    /** Catatan untuk pengguna (misalnya sumber diganti atau pantauan dilewati). */
    var catatan = ""
        private set

    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    private var berkas: File? = null
    private var sr = 44_100
    private var kanalKeluar = 1
    @Volatile private var total = 0L

    /** Membuka mikrofon dan mulai merekam ke [tujuan]. Mengembalikan pesan galat, atau null bila berhasil. */
    @SuppressLint("MissingPermission")
    fun mulai(tujuan: File): String? {
        val efek = ep.konfigEfek()
        val vokal = ep.konfigVokal()
        val headset = ep.pantau && KaraokeMesin.adaHeadset(ctx)
        if (ep.pantau && !headset) catatan += "Pantauan dilewati karena headset tidak terpasang. "
        // Dengan pantauan, laju asli HP (biasanya 48 kHz) dipakai supaya jalur cepat tanpa pengubahan laju aktif.
        if (headset) {
            val asli = try { AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC) } catch (e: Exception) { 44_100 }
            if (asli in 16_000..96_000) sr = asli
        }
        val blok = if (headset) sr / 100 else sr / 50
        val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return "Format mikrofon tidak didukung perangkat ini."
        val pilih = ep.sumber
        val urut = if (pilih == 4) listOf(EfekRekamPrefs.SUMBER[4], EfekRekamPrefs.SUMBER[0]) else listOf(EfekRekamPrefs.SUMBER[pilih])
        var r: AudioRecord? = null
        for ((i, s) in urut.withIndex()) {
            try {
                val c = AudioRecord(s, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 4, blok * 2 * 8))
                if (c.state == AudioRecord.STATE_INITIALIZED) {
                    r = c
                    if (i > 0) catatan += "Sumber mentah tidak didukung, dipakai mikrofon standar. "
                    break
                }
                c.release()
            } catch (e: Exception) { }
        }
        val ar = r ?: return "Mikrofon tidak bisa dibuka. Mungkin sedang dipakai aplikasi lain."
        kanalKeluar = if (efek.aktif) 2 else 1
        val out = try {
            BufferedOutputStream(FileOutputStream(tujuan), 1 shl 16).also { it.write(ByteArray(44)) }
        } catch (e: Exception) {
            ar.release()
            return "Berkas rekaman tidak bisa dibuat: ${e.message}"
        }
        try {
            ar.startRecording()
            if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                ar.release()
                out.close()
                return "Mikrofon tidak bisa dipakai. Mungkin sedang dipakai aplikasi lain."
            }
        } catch (e: Exception) {
            try { ar.release() } catch (x: Exception) { }
            try { out.close() } catch (x: Exception) { }
            return "Mikrofon tidak bisa dipakai."
        }
        rec = ar
        berkas = tujuan
        total = 0L
        puncak = 0
        berjalan = true
        val gainLin = 10.0.pow(EfekRekamPrefs.GAIN_DB[ep.gain] / 20.0)
        val bassDb = KaraokePrefs.BASS_DB[ep.bass]
        val jernihDb = KaraokePrefs.JERNIH_DB[ep.jernih]
        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val penyetel = PenyetelSuara(sr, 1, bassDb, jernihDb)
            val olah = if (vokal.awalAktif) PengolahVokal(sr, 1, vokal) else null
            val gema = if (efek.aktif) EfekKaraoke(sr, efek) else null
            val batas = if (vokal.pembatas) Pembatas(sr, kanalKeluar) else null
            val pantau = if (headset) PantauSuara.buat(sr, kanalKeluar) else null
            val mono = ShortArray(blok)
            val hasil = ShortArray(blok * kanalKeluar)
            val bb = ByteBuffer.allocate(hasil.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            var terjeda = false
            try {
                while (berjalan) {
                    val n = ar.read(mono, 0, mono.size)
                    if (n < 0) break
                    if (n == 0) continue
                    if (jeda) {
                        if (!terjeda) {
                            terjeda = true
                            gema?.kosongkan(); olah?.kosongkan(); batas?.kosongkan()
                        }
                        continue
                    }
                    terjeda = false
                    if (gainLin != 1.0) {
                        for (i in 0 until n) mono[i] = batasiLembut(mono[i] * gainLin)
                    }
                    penyetel.proses(mono, n)
                    olah?.proses(mono, n)
                    var jumlah = n
                    if (gema != null) {
                        jumlah = gema.proses(mono, n, 1, hasil, 2)
                    } else {
                        System.arraycopy(mono, 0, hasil, 0, n)
                    }
                    batas?.proses(hasil, jumlah)
                    pantau?.tulis(hasil, jumlah)
                    var p = puncak
                    bb.clear()
                    for (i in 0 until jumlah) {
                        val v = hasil[i].toInt()
                        val a = if (v < 0) -v else v
                        if (a > p) p = a
                        bb.putShort(hasil[i])
                    }
                    puncak = p
                    out.write(bb.array(), 0, jumlah * 2)
                    total += jumlah * 2L
                }
            } catch (e: Exception) {
            }
            pantau?.lepas()
            try { out.flush(); out.close() } catch (e: Exception) { }
            try { kepalaWav(tujuan, total, sr, kanalKeluar) } catch (e: Exception) { }
        }, "rekam-efek").also { it.start() }
        return null
    }

    /** Menghentikan rekaman dan mengembalikan berkas WAV-nya (null bila terlalu singkat). */
    fun berhenti(): File? {
        berjalan = false
        try { rec?.stop() } catch (e: Exception) { }
        try { thread?.join(3000) } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        thread = null
        val f = berkas
        berkas = null
        return if (f != null && f.length() > 44) f else { f?.delete(); null }
    }

    companion object {
        /** Menulis kepala WAV (PCM 16 bit) di awal [f] setelah jumlah data [total] byte diketahui. */
        fun kepalaWav(f: File, total: Long, rate: Int, ch: Int) {
            RandomAccessFile(f, "rw").use { raf ->
                fun intLE(v: Long): ByteArray = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
                fun shortLE(v: Int): ByteArray = byteArrayOf(v.toByte(), (v shr 8).toByte())
                raf.seek(0)
                raf.write("RIFF".toByteArray()); raf.write(intLE(36 + total)); raf.write("WAVE".toByteArray())
                raf.write("fmt ".toByteArray()); raf.write(intLE(16)); raf.write(shortLE(1)); raf.write(shortLE(ch))
                raf.write(intLE(rate.toLong())); raf.write(intLE(rate * 2L * ch)); raf.write(shortLE(2 * ch)); raf.write(shortLE(16))
                raf.write("data".toByteArray()); raf.write(intLE(total))
            }
        }
    }
}
