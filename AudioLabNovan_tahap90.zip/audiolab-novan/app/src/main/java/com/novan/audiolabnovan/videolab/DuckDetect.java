package com.novan.audiolabnovan.videolab;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Tahap 51: logika deteksi bicara untuk "musik turun otomatis" (Java murni, tanpa Android, supaya mudah diuji).
 * Kepekaan: 0 normal, 1 tinggi, 2 sangat tinggi. Kecepatan musik naik lagi: 0 cepat, 1 sedang, 2 pelan.
 */
final class DuckDetect {
    private DuckDetect() { }

    private static final float[] FLOOR_MULT = {3.0f, 2.0f, 1.5f};          // kelipatan lantai derau
    private static final float[] MIN_ABS = {0.006f, 0.004f, 0.0025f};      // batas bawah mutlak (RMS 0..1)
    private static final long[] MIN_SEG_MS = {100, 80, 80};                // bagian bersuara yang lebih pendek diabaikan
    private static final long[] GAP_MS = {200, 350, 600};                  // jeda lebih pendek dari ini dianggap masih bicara
    private static final double[] RELEASE_TC = {0.06, 0.20, 0.50};         // detik, tetapan waktu musik naik lagi

    static int clampSens(int s) { return Math.max(0, Math.min(2, s)); }
    static int clampRel(int r) { return Math.max(0, Math.min(2, r)); }
    static long gapMs(int rel) { return GAP_MS[clampRel(rel)]; }
    static long minSegMs(int sens) { return MIN_SEG_MS[clampSens(sens)]; }
    static double releaseTc(int rel) { return RELEASE_TC[clampRel(rel)]; }

    /**
     * Ambang bicara. Lantai derau = persentil ke-10 (bagian paling pelan klip). Ambang tidak boleh lebih dari 35 persen
     * tingkat bicara biasa (persentil ke-90), supaya klip yang bicara terus tanpa jeda tetap terdeteksi.
     */
    static float threshold(float[] rms, int sens) {
        int s = clampSens(sens);
        float[] sorted = rms.clone();
        Arrays.sort(sorted);
        int n = sorted.length;
        float floor = sorted[Math.min(n - 1, (int) (n * 0.10f))];
        float speech = sorted[Math.min(n - 1, (int) (n * 0.90f))];
        float thr = Math.max(MIN_ABS[s], floor * FLOOR_MULT[s]);
        thr = Math.min(thr, Math.max(MIN_ABS[s], speech * 0.35f));
        return thr;
    }

    /** Gabungkan potongan yang berdekatan (jarak sampai gapMs) dan buang yang lebih pendek dari minSegMs. */
    static long[][] merge(List<long[]> raw, long gapMs, long minSegMs) {
        List<long[]> out = new ArrayList<>();
        for (long[] s : raw) {
            if (out.isEmpty() || s[0] - out.get(out.size() - 1)[1] > gapMs) {
                out.add(new long[]{s[0], s[1]});
            } else {
                out.get(out.size() - 1)[1] = Math.max(out.get(out.size() - 1)[1], s[1]);
            }
        }
        List<long[]> fin = new ArrayList<>();
        for (long[] s : out) if (s[1] - s[0] >= minSegMs) fin.add(s);
        return fin.toArray(new long[0][]);
    }
}
