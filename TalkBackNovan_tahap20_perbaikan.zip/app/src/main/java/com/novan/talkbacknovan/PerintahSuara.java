package com.novan.talkbacknovan;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.Locale;

/** Mencocokkan kalimat yang diucapkan dengan aksi atau nama aplikasi. */
final class PerintahSuara {
    private PerintahSuara() {}

    // Urutan penting: yang lebih spesifik diletakkan lebih dulu.
    private static final Object[][] DAFTAR = {
            {Aksi.KETUK_LAMA, new String[]{"ketuk lama", "klik lama", "tekan lama"}},
            {Aksi.PENGATURAN_CEPAT, new String[]{"pengaturan cepat", "setelan cepat", "quick settings"}},
            {Aksi.KUNCI_LAYAR, new String[]{"kunci layar", "kunci ponsel", "kunci hp"}},
            {Aksi.TERBARU, new String[]{"aplikasi terbaru", "terbaru", "recent"}},
            {Aksi.NOTIFIKASI, new String[]{"notifikasi", "pemberitahuan"}},
            {Aksi.BERANDA, new String[]{"beranda", "layar utama", "home"}},
            {Aksi.KEMBALI, new String[]{"kembali", "back"}},
            {Aksi.BACA_DARI_SINI, new String[]{"baca dari sini", "baca dari item", "lanjut baca"}},
            {Aksi.BACA_LAYAR, new String[]{"baca layar", "baca semua", "baca seluruh"}},
            {Aksi.TAMPIL_TEKS, new String[]{"teks layar", "tampilkan teks"}},
            {Aksi.OCR_FOKUS, new String[]{"ocr elemen", "ocr fokus", "ocr item"}},
            {Aksi.OCR_LAYAR, new String[]{"ocr"}},
            {Aksi.GANTI_NAMA, new String[]{"ganti nama"}},
            {Aksi.PILIH_SEMUA, new String[]{"pilih semua"}},
            {Aksi.SALIN, new String[]{"salin", "copy"}},
            {Aksi.TEMPEL, new String[]{"tempel", "paste"}},
            {Aksi.POTONG, new String[]{"potong", "cut"}},
            {Aksi.KETUK, new String[]{"ketuk", "klik", "tekan"}},
            {Aksi.GULIR_MAJU, new String[]{"gulir bawah", "gulir ke bawah", "turun", "scroll down"}},
            {Aksi.GULIR_MUNDUR, new String[]{"gulir atas", "gulir ke atas", "naik", "scroll up"}},
            {Aksi.ITEM_MAJU, new String[]{"berikutnya", "selanjutnya", "maju"}},
            {Aksi.ITEM_MUNDUR, new String[]{"sebelumnya", "mundur"}},
            {Aksi.HENTIKAN_SUARA, new String[]{"diam", "berhenti", "stop", "hentikan"}},
            {Aksi.ULANGI, new String[]{"ulangi", "ulang"}},
            {Aksi.INFO, new String[]{"jam", "waktu", "baterai", "pukul", "tanggal"}},
            {Aksi.MENU, new String[]{"menu"}},
    };

    /** Nomor aksi yang cocok, atau -1 bila tidak dikenal. */
    static int cari(String ucapan) {
        String u = ucapan.toLowerCase(Locale.getDefault()).trim();
        for (Object[] b : DAFTAR) {
            for (String kata : (String[]) b[1]) {
                if (u.contains(kata)) return (Integer) b[0];
            }
        }
        return -1;
    }

    /** Nama aplikasi bila ucapan berbentuk "buka ...", selain itu null. */
    static String namaAplikasi(String ucapan) {
        String u = ucapan.toLowerCase(Locale.getDefault()).trim();
        String[] awalan = {"buka aplikasi ", "buka ", "jalankan ", "open "};
        for (String a : awalan) {
            if (u.startsWith(a) && u.length() > a.length()) return u.substring(a.length()).trim();
        }
        return null;
    }

    /** Buka aplikasi yang labelnya paling cocok; mengembalikan label aplikasi atau null. */
    static String bukaAplikasi(Context c, String nama) {
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        ResolveInfo terbaik = null;
        String labelTerbaik = null;
        int skorTerbaik = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
            String label = ri.loadLabel(pm).toString();
            String l = label.toLowerCase(Locale.getDefault());
            int skor = 0;
            if (l.equals(nama)) skor = 3;
            else if (l.startsWith(nama)) skor = 2;
            else if (l.contains(nama) || nama.contains(l)) skor = 1;
            if (skor > skorTerbaik) {
                skorTerbaik = skor;
                terbaik = ri;
                labelTerbaik = label;
            }
        }
        if (terbaik == null) return null;
        Intent buka = pm.getLaunchIntentForPackage(terbaik.activityInfo.packageName);
        if (buka == null) return null;
        buka.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(buka);
        return labelTerbaik;
    }
}
