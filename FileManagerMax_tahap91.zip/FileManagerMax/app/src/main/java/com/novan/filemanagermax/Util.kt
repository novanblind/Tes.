package com.novan.filemanagermax

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.media.RingtoneManager
import android.provider.MediaStore
import android.provider.Settings
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/** Fungsi bantu bersama untuk membuka dan membagikan berkas. */
object Util {

    /** Ikon yang sesuai jenis berkas atau folder. */
    fun iconFor(f: File): Int {
        if (f.isDirectory) return R.drawable.ic_folder
        if (ArchiveOps.isSupported(f)) return R.drawable.ic_archive
        if (isInstallerFile(f)) return R.drawable.ic_apk
        return when (kindOf(f)) {
            K_IMAGE -> R.drawable.ic_image
            K_AUDIO -> R.drawable.ic_audio
            K_VIDEO -> R.drawable.ic_video
            else -> R.drawable.ic_file
        }
    }

    /** Memformat ukuran berkas sesuai pilihan satuan di pengaturan. */
    fun formatSize(c: Context, bytes: Long): String {
        val unit = Prefs.sizeUnit(c)
        if (unit == 0) return android.text.format.Formatter.formatFileSize(c, bytes)
        val base = if (unit == 1) 1024.0 else 1000.0
        val names = if (unit == 1) arrayOf("B", "KiB", "MiB", "GiB", "TiB")
        else arrayOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= base && i < names.size - 1) { v /= base; i++ }
        return if (i == 0) "$bytes ${names[0]}" else String.format(java.util.Locale.getDefault(), "%.1f %s", v, names[i])
    }

    const val APK_MIME = "application/vnd.android.package-archive"
    private val INSTALLER_EXT = setOf("apk", "apk+", "apks", "xapk", "apkm")

    /** Berkas yang dipasang sebagai aplikasi (APK dan paket split). */
    fun isInstallerFile(f: File): Boolean = f.extension.lowercase() in INSTALLER_EXT

    /**
     * Jenis berkas dari ekstensi. Tidak memakai getFileExtensionFromUrl karena nama berkas
     * yang memuat spasi atau tanda plus menghasilkan ekstensi kosong, sehingga semua
     * aplikasi muncul di Buka dengan.
     */
    fun mimeOf(f: File): String {
        val ext = f.extension.lowercase()
        if (ext == "apk") return APK_MIME
        if (ext in INSTALLER_EXT) return "application/octet-stream"
        if (ext.isEmpty()) return "*/*"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    fun uriOf(c: Context, f: File): Uri =
        FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f)

    /** Mengembalikan false bila tidak ada aplikasi yang bisa membuka. */
    fun open(c: Context, f: File): Boolean = try {
        c.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriOf(c, f), mimeOf(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: IllegalArgumentException) {
        false
    }

    fun share(c: Context, f: File): Boolean = try {
        val intent = Intent(Intent.ACTION_SEND)
            .setType(mimeOf(f))
            .putExtra(Intent.EXTRA_STREAM, uriOf(c, f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(intent, c.getString(R.string.share_chooser)))
        true
    } catch (e: Exception) {
        false
    }

    /** Bagikan sebagai lampiran dokumen: penerima (mis. WhatsApp) menampilkannya sebagai dokumen. */
    fun shareAsDocument(c: Context, files: List<File>): Boolean = try {
        val uris = ArrayList<Uri>(files.map { uriOf(c, it).buildUpon().appendQueryParameter("doc", "1").build() })
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).setType("application/octet-stream").putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).setType("application/octet-stream")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(intent, c.getString(R.string.share_chooser)))
        true
    } catch (e: Exception) {
        false
    }

    /** Nama berkas asli dari content:// (mis. dari WhatsApp); lastPathSegment hanya berupa nomor. */
    fun displayName(c: Context, u: Uri): String {
        if (u.scheme == "content") {
            try {
                c.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0)?.let { n -> if (n.isNotEmpty()) return n }
                }
            } catch (e: Exception) {
                // abaikan
            }
        }
        return u.lastPathSegment ?: ""
    }

    /** Memindahkan [src] ke jalur persis [target], lintas volume bila perlu. */
    fun moveExact(src: File, target: File, p: Progress? = null): Boolean {
        target.parentFile?.mkdirs()
        if (src.renameTo(target)) return true
        return try {
            // Lintas penyimpanan: salin dengan laporan kemajuan, lalu hapus asal (tanpa persen).
            FileOps.copyExact(src, target, p)
            p?.busy = Progress.BUSY_FINISH
            try { src.deleteRecursively() } finally { p?.busy = 0 }
        } catch (e: OpCancelled) {
            throw e
        } catch (e: Exception) {
            target.deleteRecursively()
            false
        }
    }

    const val K_OTHER = 0
    const val K_TEXT = 1
    const val K_IMAGE = 2
    const val K_AUDIO = 3
    const val K_VIDEO = 4

    private val TEXT_EXT = setOf(
        "txt", "md", "markdown", "log", "json", "json5", "jsonc", "xml", "csv", "html", "htm", "xhtml", "js", "mjs", "cjs",
        "ts", "tsx", "jsx", "css", "scss", "sass", "less", "java", "kt", "kts", "py", "pyw", "lua", "rb", "pl", "pm", "php",
        "go", "rs", "swift", "cs", "vb", "vbs", "r", "m", "mm", "scala", "groovy", "dart", "c", "cc", "cpp", "cxx", "h", "hh",
        "hpp", "hxx", "asm", "s", "sh", "bash", "zsh", "fish", "ps1", "psm1", "cmd", "bat", "awk", "sed", "ini", "inf", "conf",
        "cfg", "config", "properties", "toml", "env", "reg", "yml", "yaml", "srt", "vtt", "lrc", "ass", "ssa", "sub",
        "gradle", "sql", "tsv", "rtf", "tex", "bib", "rst", "adoc", "org", "diff", "patch", "vue", "svelte", "jsp", "asp",
        "aspx", "ejs", "tpl", "tmpl", "mk", "cmake", "lock", "gitignore", "gitattributes", "editorconfig", "htaccess",
        "service", "desktop", "plist", "pro", "pri", "proto", "graphql", "gql", "tf", "hcl", "nfo", "text", "list", "map"
    )

    /** Nama berkas tanpa ekstensi yang pasti teks. */
    private val TEXT_NAMES = setOf(
        "makefile", "dockerfile", "readme", "license", "licence", "changelog", "authors", "copying", "notice",
        "procfile", "gemfile", "rakefile", "vagrantfile", "jenkinsfile", "cmakelists", "build", "todo", "contributing"
    )

    /**
     * Cek isi berkas: true bila tampak teks (tanpa byte NUL dan sedikit karakter kendali), atau kosong,
     * atau berawalan BOM UTF-16. Dipakai agar berkas berekstensi tak dikenal (mis. .lua, .cfg ganjil)
     * tetap bisa dibuka di editor teks. Hanya membaca 8 KB pertama.
     */
    fun looksLikeText(f: File): Boolean = try {
        if (!f.isFile) false
        else f.inputStream().use { ins ->
            val b = ByteArray(8192)
            val n = ins.read(b)
            if (n <= 0) true
            else if (n >= 2 && ((b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) ||
                        (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()))) true
            else {
                var ctrl = 0
                var ok = true
                for (i in 0 until n) {
                    val v = b[i].toInt() and 0xFF
                    if (v == 0) { ok = false; break }
                    if (v < 9 || (v in 14..31 && v != 27)) ctrl++
                }
                ok && ctrl <= n / 50
            }
        }
    } catch (e: Exception) { false }

    /** Buka berkas apa pun langsung di editor teks bawaan (editor sendiri menolak berkas biner). */
    fun openInEditor(c: Context, f: File): Boolean = try {
        c.startActivity(
            Intent(c, TextEditorActivity::class.java)
                .putExtra(TextEditorActivity.EXTRA_PATH, f.absolutePath)
        )
        true
    } catch (e: Exception) { false }

    fun kindOf(f: File): Int {
        val ext = f.extension.lowercase()
        val mime = mimeOf(f)
        return when {
            ext == "svg" -> if (ext in TEXT_EXT) K_TEXT else K_OTHER
            mime.startsWith("image/") -> K_IMAGE
            mime.startsWith("audio/") -> K_AUDIO
            mime.startsWith("video/") -> K_VIDEO
            ext in TEXT_EXT || mime.startsWith("text/") || (ext.isEmpty() && f.name.lowercase() in TEXT_NAMES) -> K_TEXT
            else -> K_OTHER
        }
    }

    private fun internalKey(kind: Int): String? = when (kind) {
        K_TEXT -> "text"
        K_IMAGE -> "image"
        K_AUDIO -> "audio"
        K_VIDEO -> "video"
        else -> null
    }

    /**
     * Membuka berkas dengan penampil bawaan bila jenisnya didukung dan diaktifkan di
     * pengaturan; selain itu memakai aplikasi lain. [siblings] dipakai sebagai daftar putar
     * atau daftar gambar.
     */
    fun openSmart(c: Context, f: File, siblings: List<File>): Boolean {
        if (SplitInstallActivity.isSplitPackage(f)) {
            return try {
                c.startActivity(
                    Intent(c, SplitInstallActivity::class.java)
                        .putExtra(SplitInstallActivity.EXTRA_PATH, f.absolutePath)
                )
                true
            } catch (e: Exception) {
                open(c, f)
            }
        }
        if (ArchiveOps.isSupported(f)) {
            return try {
                c.startActivity(
                    Intent(c, ArchiveActivity::class.java)
                        .putExtra(ArchiveActivity.EXTRA_PATH, f.absolutePath)
                )
                true
            } catch (e: Exception) {
                open(c, f)
            }
        }
        if (PdfViewerActivity.isSupported(f) && Prefs.usePdf(c)) {
            return try {
                c.startActivity(
                    Intent(c, PdfViewerActivity::class.java)
                        .putExtra(PdfViewerActivity.EXTRA_PATH, f.absolutePath)
                )
                true
            } catch (e: Exception) {
                open(c, f)
            }
        }
        if (OfficeReader.isSupported(f) && Prefs.useOffice(c)) {
            return try {
                c.startActivity(
                    Intent(c, OfficeViewerActivity::class.java)
                        .putExtra(OfficeViewerActivity.EXTRA_PATH, f.absolutePath)
                )
                true
            } catch (e: Exception) {
                open(c, f)
            }
        }
        var kind = kindOf(f)
        // Jenis tak dikenal tetapi isinya teks (mis. skrip dengan ekstensi aneh): buka di editor teks.
        if (kind == K_OTHER && Prefs.useInternal(c, "text") && !isInstallerFile(f) && looksLikeText(f)) kind = K_TEXT
        val key = internalKey(kind)
        if (key == null || !Prefs.useInternal(c, key)) return open(c, f)
        return try {
            when (kind) {
                K_TEXT -> c.startActivity(
                    Intent(c, TextEditorActivity::class.java)
                        .putExtra(TextEditorActivity.EXTRA_PATH, f.absolutePath)
                )
                K_VIDEO -> c.startActivity(
                    Intent(c, VideoPlayerActivity::class.java)
                        .putExtra(VideoPlayerActivity.EXTRA_PATH, f.absolutePath)
                )
                K_IMAGE, K_AUDIO -> {
                    val list = siblings.filter { it.isFile && kindOf(it) == kind }.take(500)
                    val idx = list.indexOfFirst { it.absolutePath == f.absolutePath }
                    val paths = if (idx >= 0) list.map { it.absolutePath } else listOf(f.absolutePath)
                    val cls = if (kind == K_IMAGE) ImageViewerActivity::class.java
                    else AudioPlayerActivity::class.java
                    c.startActivity(
                        Intent(c, cls)
                            .putExtra(EXTRA_PATHS, paths.toTypedArray())
                            .putExtra(EXTRA_INDEX, if (idx >= 0) idx else 0)
                    )
                }
            }
            true
        } catch (e: Exception) {
            open(c, f)
        }
    }

    const val EXTRA_PATHS = "paths"
    const val EXTRA_INDEX = "index"

    /** Buka dengan: tampilkan daftar aplikasi yang benar-benar sesuai dengan jenis berkas. */
    fun openWith(c: Context, f: File, mime: String = mimeOf(f)): Boolean {
        val act = c as? Activity ?: return openWithChooser(c, f, mime)
        return try {
            val pm = c.packageManager
            val base = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriOf(c, f), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            var found = pm.queryIntentActivities(base, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            val installer = isInstallerFile(f) && mime == mimeOf(f)
            found = if (installer) {
                found.filter { isInstallerApp(pm, it.activityInfo.packageName) }
            } else {
                dropWildcardOnly(found, mime)
            }
            val labels = ArrayList<String>()
            val intents = ArrayList<Intent>()
            if (installer) {
                labels.add(c.getString(R.string.open_with_self_install))
                intents.add(
                    Intent(c, SplitInstallActivity::class.java)
                        .putExtra(SplitInstallActivity.EXTRA_PATH, f.absolutePath)
                )
            }
            for (ri in found) {
                if (ri.activityInfo.packageName == c.packageName) continue
                labels.add(ri.loadLabel(pm).toString())
                intents.add(
                    Intent(base).setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                )
            }
            if (intents.isEmpty()) return false
            androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle(R.string.open_with_title)
                .setItems(labels.toTypedArray()) { _, which ->
                    try {
                        act.startActivity(intents[which])
                    } catch (e: Exception) {
                        // aplikasi tujuan tidak bisa dibuka
                    }
                }
                .show()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Aplikasi pemasang: sistem atau aplikasi yang meminta izin memasang paket. */
    @Suppress("DEPRECATION")
    private fun isInstallerApp(pm: android.content.pm.PackageManager, pkg: String): Boolean {
        if (pkg.contains("packageinstaller", ignoreCase = true)) return true
        return try {
            val pi = pm.getPackageInfo(pkg, android.content.pm.PackageManager.GET_PERMISSIONS)
            pi.requestedPermissions?.any {
                it == "android.permission.REQUEST_INSTALL_PACKAGES" || it == "android.permission.INSTALL_PACKAGES"
            } == true
        } catch (e: Exception) {
            false
        }
    }

    /** Buang aplikasi yang hanya cocok lewat jenis serba bisa (jenis wildcard) bila ada yang lebih tepat. */
    private fun dropWildcardOnly(
        list: List<android.content.pm.ResolveInfo>, mime: String
    ): List<android.content.pm.ResolveInfo> {
        if (mime == "*/*") return list
        fun wildcardOnly(ri: android.content.pm.ResolveInfo): Boolean {
            val f = ri.filter ?: return false
            val n = f.countDataTypes()
            if (n == 0) return false
            for (i in 0 until n) {
                val t = f.getDataType(i)
                if (t != "*/*" && t != "*") return false
            }
            return true
        }
        val precise = list.filter { !wildcardOnly(it) }
        return if (precise.isNotEmpty()) precise else list
    }

    private fun openWithChooser(c: Context, f: File, mime: String): Boolean = try {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriOf(c, f), mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(intent, c.getString(R.string.open_with_title)))
        true
    } catch (e: Exception) {
        false
    }

    /** Mengembalikan id string pesan hasil. */
    fun setRingtone(c: Context, f: File, type: Int): Int {
        if (!Settings.System.canWrite(c)) {
            try {
                c.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                        .setData(Uri.parse("package:${c.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                // abaikan
            }
            return R.string.ringtone_need_permission
        }
        var uri: Uri? = null
        try {
            c.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID),
                MediaStore.Audio.Media.DATA + "=?",
                arrayOf(f.absolutePath), null
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    uri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cur.getLong(0)
                    )
                }
            }
        } catch (e: Exception) {
            uri = null
        }
        val target = uri ?: return R.string.ringtone_not_indexed
        return try {
            RingtoneManager.setActualDefaultRingtoneUri(c, type, target)
            R.string.ringtone_done
        } catch (e: Exception) {
            R.string.ringtone_failed
        }
    }
}
