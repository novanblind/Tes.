package com.novan.talkbacknovan;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;

import java.util.ArrayList;

/** Activity tembus pandang yang menampilkan pengenal suara bawaan sistem lalu meneruskan hasilnya. */
public class SuaraActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan perintah");
        try {
            startActivityForResult(i, 1);
        } catch (ActivityNotFoundException e) {
            TalkBackNovanService.ucapkanAntre("Pengenalan suara tidak tersedia di ponsel ini");
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int hasil, Intent data) {
        super.onActivityResult(req, hasil, data);
        if (hasil == RESULT_OK && data != null) {
            ArrayList<String> daftar = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (daftar != null && !daftar.isEmpty()) {
                TalkBackNovanService.perintahSuara(daftar.get(0));
            }
        }
        finish();
    }
}
