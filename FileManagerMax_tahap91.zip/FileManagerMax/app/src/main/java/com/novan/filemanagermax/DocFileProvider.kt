package com.novan.filemanagermax

import android.net.Uri
import androidx.core.content.FileProvider

/**
 * FileProvider yang melaporkan jenis "application/octet-stream" bila URI memuat ?doc=1, supaya
 * WhatsApp dan aplikasi sejenis menganggap berkas sebagai lampiran dokumen (nama dan ukuran
 * tampil, tanpa batas 16 MB), bukan video, audio, atau gambar. Jenis asli sengaja tidak dilaporkan:
 * WhatsApp membacanya dan mengirim berkas sebagai media biasa.
 */
class DocFileProvider : FileProvider() {
    override fun getType(uri: Uri): String? =
        if (uri.getQueryParameter("doc") == "1") "application/octet-stream" else super.getType(uri)
}
