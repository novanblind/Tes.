package com.novan.audiolabnovan.karaoke

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Pendeteksi nada suara (algoritma YIN): tiap [HOP] sampel masuk, mengukur nada dasar dari jendela terakhir.
 * Laju sampel 32 kHz ke atas diturunkan setengahnya (rata-rata dua sampel) supaya hitungannya ringan.
 * Jangkauan 70 sampai 1100 Hz (suara pria rendah sampai wanita tinggi). Hasil 0 berarti tidak ada nada
 * (diam, napas, desis, atau suara tak berpola).
 *
 * Murni hitungan, tanpa kelas Android, dan hanya dipakai satu utas.
 */
class DeteksiNada(private val sr: Int) {

    companion object {
        /** Sampel masuk di antara dua pengukuran (sekitar 23 milidetik pada 44,1 kHz). */
        const val HOP = 1024
        const val MIN_HZ = 70.0
        const val MAX_HZ = 1100.0
        private const val AMBANG = 0.15f
        private const val AMBANG_LEMAH = 0.35f
        /** Tenaga (RMS, 0..1) di bawah ini dianggap diam: sekitar minus 38 dB. */
        private const val RMS_DIAM = 0.012
    }

    private val turun = if (sr >= 32_000) 2 else 1
    private val srA = sr / turun
    private val tauMin = max(2, (srA / MAX_HZ).toInt())
    private val tauMaks = (srA / MIN_HZ).toInt()
    private val jendela = tauMaks
    private val panjang = jendela + tauMaks + 2

    /** Jumlah sampel masuk yang dilihat tiap pengukuran. */
    val lebarMasuk: Int get() = turun * panjang

    private val ring = ShortArray(turun * panjang)
    private var tulis = 0
    private var terisi = 0
    private var baru = 0
    private val x = FloatArray(panjang)
    private val cm = FloatArray(tauMaks + 2)

    /** Memasukkan satu sampel; true bila sudah waktunya mengukur. */
    fun masukkan(s: Short): Boolean {
        ring[tulis] = s
        tulis = if (tulis + 1 == ring.size) 0 else tulis + 1
        if (terisi < ring.size) terisi++
        if (++baru >= HOP && terisi == ring.size) {
            baru = 0
            return true
        }
        return false
    }

    /** Mengukur nada dari jendela terakhir. */
    fun ukur(): Double {
        var jumlah = 0.0
        for (j in 0 until panjang) {
            var a = 0
            val dasar = tulis + j * turun
            for (k in 0 until turun) {
                var p = dasar + k
                if (p >= ring.size) p -= ring.size
                a += ring[p]
            }
            val v = a / (32_768f * turun)
            x[j] = v
            jumlah += v
        }
        val rata = (jumlah / panjang).toFloat()
        var tenaga = 0.0
        for (j in 0 until panjang) {
            x[j] -= rata
            tenaga += x[j] * x[j]
        }
        if (sqrt(tenaga / panjang) < RMS_DIAM) return 0.0

        // Fungsi selisih, lalu dinormalkan dengan rata-rata berjalan (langkah 2 dan 3 YIN).
        var jalan = 0f
        cm[0] = 1f
        for (tau in 1..tauMaks) {
            var s = 0f
            for (j in 0 until jendela) {
                val df = x[j] - x[j + tau]
                s += df * df
            }
            jalan += s
            cm[tau] = if (jalan > 0f) s * tau / jalan else 1f
        }

        var tau = -1
        var t = tauMin
        while (t < tauMaks) {
            if (cm[t] < AMBANG) {
                while (t + 1 < tauMaks && cm[t + 1] < cm[t]) t++
                tau = t
                break
            }
            t++
        }
        if (tau < 0) {
            var terbaik = tauMin
            for (u in tauMin until tauMaks) if (cm[u] < cm[terbaik]) terbaik = u
            if (cm[terbaik] > AMBANG_LEMAH) return 0.0
            tau = terbaik
        }
        // Interpolasi parabola supaya nadanya halus di antara dua sampel.
        var tb = tau.toDouble()
        if (tau in 2 until tauMaks) {
            val a = cm[tau - 1]
            val b = cm[tau]
            val c = cm[tau + 1]
            val peny = a - 2f * b + c
            if (abs(peny) > 1e-9f) tb = tau + (a - c) / (2.0 * peny)
        }
        val hz = srA / tb
        return if (hz < MIN_HZ || hz > MAX_HZ) 0.0 else hz
    }

    /** Sampel masuk dari awal jendela sampai pusat jendela: dipakai untuk menaksir waktu pengukuran. */
    val setengahJendela: Int get() = lebarMasuk / 2
}

/**
 * Menampung deretan nada yang terdeteksi selama menyanyi. Dipanggil dari utas mikrofon ([proses]); utas layar boleh
 * membaca kapan saja lewat [salin] dan [nadaTerakhir].
 *
 * Waktu tiap pengukuran dicatat sebagai nomor sampel mikrofon di pusat jendela, sama dengan nomor sampel di rekaman
 * vokal, jadi mudah dikaitkan dengan awal musik.
 */
class PemantauNada(sr: Int) {

    class Salinan(val hz: FloatArray, val pusat: LongArray, val jumlah: Int)

    private val deteksi = DeteksiNada(sr)
    private var hz = FloatArray(2048)
    private var pusat = LongArray(2048)
    private var jumlah = 0
    private var masuk = 0L
    private val lock = Any()

    /** Nada pengukuran terakhir (Hz, 0 = tidak ada nada). */
    @Volatile var nadaTerakhir = 0.0
        private set

    /** Berapa pengukuran bernada sejauh ini (untuk tahu mikrofon menangkap nyanyian). */
    @Volatile var jumlahBernada = 0
        private set

    fun proses(b: ShortArray, n: Int) {
        for (i in 0 until n) {
            masuk++
            if (deteksi.masukkan(b[i])) {
                val h = deteksi.ukur()
                simpan(h, masuk - deteksi.setengahJendela)
            }
        }
    }

    private fun simpan(h: Double, p: Long) {
        synchronized(lock) {
            if (jumlah == hz.size) {
                hz = hz.copyOf(jumlah * 2)
                pusat = pusat.copyOf(jumlah * 2)
            }
            hz[jumlah] = h.toFloat()
            pusat[jumlah] = p
            jumlah++
        }
        nadaTerakhir = h
        if (h > 0.0) jumlahBernada++
    }

    fun salin(): Salinan = synchronized(lock) { Salinan(hz.copyOf(jumlah), pusat.copyOf(jumlah), jumlah) }

    companion object {
        private val NAMA = arrayOf("C", "C kres", "D", "D kres", "E", "F", "F kres", "G", "G kres", "A", "A kres", "B")

        /** Nada MIDI pecahan dari frekuensi (A4 = 440 Hz = 69). */
        fun midi(hz: Double): Double = 69.0 + 12.0 * ln(hz / 440.0) / ln(2.0)

        /** Nama nada yang mudah dibacakan pembaca layar, misalnya "A 4" atau "C kres 5"; kosong bila [hz] <= 0. */
        fun nama(hz: Double): String {
            if (hz <= 0.0) return ""
            val m = midi(hz).roundToInt()
            val oktaf = Math.floorDiv(m, 12) - 1
            return NAMA[Math.floorMod(m, 12)] + " " + oktaf
        }

        /** Selisih nada dari not terdekat dalam sen (100 sen = satu semiton), -50..50. */
        fun selisihSen(hz: Double): Int {
            val m = midi(hz)
            return ((m - Math.round(m)) * 100.0).roundToInt()
        }
    }
}
