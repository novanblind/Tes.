package com.novan.talkbacknovan;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

/**
 * Tema suara. Memakai berkas suara yang sama dengan tema bawaan JieShuo Lite
 * (res/raw), diputar lewat SoundPool pada saluran aksesibilitas.
 */
final class Efek {
    static final int FOKUS0 = 0, FOKUS1 = 1, FOKUS2 = 2, FOKUS3 = 3, FOKUS4 = 4,
            KLIK = 5, KLIK_LAMA = 6, JENDELA = 7, GULIR_ATAS = 8, GULIR_BAWAH = 9,
            BATAS = 10, BATAL = 11, GERAK_MULAI = 12, GERAK_AKHIR = 13, TIK = 14, JAM = 15;

    private static final int[] BERKAS = {
            R.raw.focus0, R.raw.focus1, R.raw.focus2, R.raw.focus3, R.raw.focus4,
            R.raw.click, R.raw.long_clicked, R.raw.window_state, R.raw.scroll_up, R.raw.scroll_down,
            R.raw.beep, R.raw.cancel, R.raw.gesture_begin, R.raw.gesture_end, R.raw.tick, R.raw.clock,
    };

    private final Context context;
    private final SoundPool kolam;
    private final int[] id = new int[BERKAS.length];
    private final boolean[] siap = new boolean[BERKAS.length];

    Efek(Context c) {
        context = c.getApplicationContext();
        kolam = new SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .build();
        kolam.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool sp, int sampleId, int status) {
                if (status != 0) return;
                for (int i = 0; i < id.length; i++) {
                    if (id[i] == sampleId) siap[i] = true;
                }
            }
        });
        for (int i = 0; i < BERKAS.length; i++) {
            try {
                id[i] = kolam.load(context, BERKAS[i], 1);
            } catch (Exception ignored) {
            }
        }
    }

    /** Putar satu suara bila tema suara diaktifkan di pengaturan. */
    void putar(int jenis) {
        if (jenis < 0 || jenis >= id.length || !siap[jenis]) return;
        android.content.SharedPreferences sp = Prefs.get(context);
        if (!sp.getBoolean(Prefs.K_EFEK, true)) return;
        float v = sp.getInt(Prefs.K_EFEK_VOL, 100) / 100f;
        try {
            kolam.play(id[jenis], v, v, 1, 0, 1f);
        } catch (Exception ignored) {
        }
    }

    void tutup() {
        try {
            kolam.release();
        } catch (Exception ignored) {
        }
    }
}
