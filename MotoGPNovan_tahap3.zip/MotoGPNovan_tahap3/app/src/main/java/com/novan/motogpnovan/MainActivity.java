package com.novan.motogpnovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final String[] KELAS = {"MotoGP", "Moto2", "Moto3"};
    static final String[] MODE = {"Klasemen pembalap", "Klasemen tim", "Klasemen konstruktor", "Hasil balapan", "Jadwal"};
    // Sumber: API hasil resmi motogp.com. Alamat kedua dipakai bila alamat pertama gagal.
    static final String[] BASE = {
            "https://api.pulselive.motogp.com/motogp/v1/results/",
            "https://api.motogp.pulselive.com/motogp/v1/results/"};

    static class Galat extends Exception {
        final int kode;
        final String pesan;

        Galat(int kode, String pesan) {
            this.kode = kode;
            this.pesan = pesan;
        }
    }

    static class Musim {
        String id;
        int tahun;
        boolean berjalan;
    }

    SharedPreferences sp;
    int kelas, mode;
    int tahunPilihan; // 0 = musim berjalan
    Button btnKelas, btnMusim, btnMode, btnSegar;
    TextView status;
    ArrayAdapter<String> adapter;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newSingleThreadExecutor();
    int permintaan = 0;

    List<Musim> daftarMusim = new ArrayList<>();
    Musim musim;
    final Map<String, String> idKelas = new HashMap<>();

    // Isi daftar saat ini: ref kosong = tidak bisa diketuk.
    List<String> refs = new ArrayList<>();
    Map<String, String> detailTeks = new HashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("motogp", MODE_PRIVATE);
        kelas = Math.min(sp.getInt("kelas", 0), KELAS.length - 1);
        mode = Math.min(sp.getInt("mode3", 0), MODE.length - 1);
        // Setiap aplikasi dibuka, musim bawaan selalu musim yang sedang berjalan.
        tahunPilihan = 0;
        btnKelas = findViewById(R.id.btnLiga);
        btnMusim = findViewById(R.id.btnMusim);
        btnMode = findViewById(R.id.btnMode);
        btnSegar = findViewById(R.id.btnSegar);
        status = findViewById(R.id.status);
        ListView daftar = findViewById(R.id.daftar);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        daftar.setAdapter(adapter);
        daftar.setOnItemClickListener((p, v, pos, idb) -> {
            if (pos < refs.size() && !refs.get(pos).isEmpty()) ketuk(refs.get(pos));
        });
        labelTombol();

        btnKelas.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Pilih kelas")
                .setItems(KELAS, (d, i) -> {
                    kelas = i;
                    sp.edit().putInt("kelas", i).apply();
                    labelTombol();
                    muat();
                }).show());

        btnMode.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Pilih tampilan")
                .setItems(MODE, (d, i) -> {
                    mode = i;
                    sp.edit().putInt("mode3", i).apply();
                    labelTombol();
                    muat();
                }).show());

        btnMusim.setOnClickListener(v -> pilihMusim());
        btnSegar.setOnClickListener(v -> {
            synchronized (CACHE) { CACHE.clear(); }
            daftarMusim = new ArrayList<>();
            muat();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter.getCount() == 0) muat();
    }

    void labelTombol() {
        btnKelas.setText("Kelas: " + KELAS[kelas]);
        btnMode.setText("Tampilan: " + MODE[mode]);
        btnMusim.setText("Musim: " + (tahunPilihan == 0 ? "berjalan (bawaan)" : String.valueOf(tahunPilihan)));
    }

    void pilihMusim() {
        io.execute(() -> {
            try {
                muatMusim();
            } catch (Exception e) {
                ui.post(() -> status.setText("Gagal memuat daftar musim. Cek internet."));
                return;
            }
            ui.post(() -> {
                final List<String> nama = new ArrayList<>();
                final List<Integer> tahun = new ArrayList<>();
                nama.add("Musim berjalan (bawaan)");
                tahun.add(0);
                for (Musim m : daftarMusim) {
                    nama.add(String.valueOf(m.tahun));
                    tahun.add(m.tahun);
                }
                new AlertDialog.Builder(this).setTitle("Pilih musim")
                        .setItems(nama.toArray(new String[0]), (d, i) -> {
                            tahunPilihan = tahun.get(i);
                            labelTombol();
                            muat();
                        }).show();
            });
        });
    }

    // ---------- Muat daftar ----------

    void muat() {
        final int id = ++permintaan;
        final int m = mode;
        final int k = kelas;
        status.setText("Memuat...");
        refs = new ArrayList<>();
        detailTeks = new HashMap<>();
        adapter.clear();
        io.execute(() -> {
            try {
                muatMusim();
                final Musim ms = musimTerpilih();
                final String kid = idKelas(ms, k);
                final List<String> baris = new ArrayList<>();
                final List<String> r = new ArrayList<>();
                final Map<String, String> det = new HashMap<>();
                if (m == 0) klasemen(ms, kid, baris, r, det);
                else if (m == 1 || m == 2) klasemenGabung(ms, kid, m == 2, baris, r, det);
                else if (m == 3) daftarSeri(ms, kid, baris, r);
                else jadwal(ms, baris);
                final String judul = KELAS[k] + " " + ms.tahun + ", " + MODE[m];
                ui.post(() -> {
                    if (id != permintaan) return;
                    musim = ms;
                    refs = r;
                    detailTeks = det;
                    adapter.clear();
                    if (baris.isEmpty()) {
                        adapter.add(m == 3 ? "Belum ada balapan yang selesai." : m == 4 ? "Jadwal belum tersedia." : "Klasemen belum tersedia.");
                        refs = new ArrayList<>();
                    } else adapter.addAll(baris);
                    status.setText(judul);
                });
            } catch (Galat g) {
                final String p = g.pesan != null ? g.pesan
                        : g.kode == 429 ? "Terlalu sering. Tunggu satu menit."
                        : "Gagal memuat. Coba lagi.";
                ui.post(() -> {
                    if (id == permintaan) status.setText(p);
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (id == permintaan) status.setText("Gagal memuat. Cek internet.");
                });
            }
        });
    }

    // ---------- Musim dan kelas ----------

    synchronized void muatMusim() throws Exception {
        if (!daftarMusim.isEmpty()) return;
        JSONArray a = larik(ambil("seasons"), "seasons");
        List<Musim> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Musim m = new Musim();
            m.id = o.optString("id");
            m.tahun = o.optInt("year", 0);
            m.berjalan = o.optBoolean("current", false);
            if (m.id.isEmpty() || m.tahun == 0) continue;
            out.add(m);
        }
        // Urut dari tahun terbaru; hanya sampai tahun ini.
        java.util.Collections.sort(out, (x, y) -> y.tahun - x.tahun);
        daftarMusim = out;
        if (out.isEmpty()) throw new Galat(0, "Daftar musim kosong dari sumber data.");
    }

    Musim musimTerpilih() throws Exception {
        if (tahunPilihan != 0) {
            for (Musim m : daftarMusim) if (m.tahun == tahunPilihan) return m;
        }
        // Musim berjalan = musim tahun sekarang. Kalau belum ada, pakai yang ditandai berjalan, lalu yang terbaru.
        int tahunIni = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        for (Musim m : daftarMusim) if (m.tahun == tahunIni) return m;
        for (Musim m : daftarMusim) if (m.berjalan) return m;
        return daftarMusim.get(0);
    }

    String idKelas(Musim ms, int k) throws Exception {
        String kunci = ms.id + "|" + KELAS[k];
        String ada = idKelas.get(kunci);
        if (ada != null) return ada;
        JSONArray a = larik(ambil("categories?seasonUuid=" + ms.id), "categories");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String nama = (o.optString("name") + "").replace("\u2122", "").replace(" ", "").toLowerCase();
            String akr = (o.optString("acronym") + "").replace(" ", "").toLowerCase();
            String cari = KELAS[k].toLowerCase();
            if (nama.equals(cari) || akr.equals(cari)) {
                idKelas.put(kunci, o.optString("id"));
                return o.optString("id");
            }
        }
        throw new Galat(0, "Kelas " + KELAS[k] + " tidak ada di musim " + ms.tahun + ".");
    }

    // ---------- Klasemen ----------

    void klasemen(Musim ms, String kid, List<String> baris, List<String> r, Map<String, String> det) throws Exception {
        JSONArray a = larik(ambil("standings?seasonUuid=" + ms.id + "&categoryUuid=" + kid), "classification");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            int pos = o.optInt("position", i + 1);
            String nama = namaPembalap(o);
            String tim = namaTim(o);
            String poin = poin(o);
            String teks = pos + ". " + nama + (tim.isEmpty() ? "" : ", " + tim) + ", " + poin + " poin";
            baris.add(teks);
            String key = "K" + i;
            r.add(key);
            StringBuilder sb = new StringBuilder();
            sb.append("Posisi ").append(pos).append("\n").append(nama);
            if (!tim.isEmpty()) sb.append("\nTim: ").append(tim);
            String kon = o.optJSONObject("constructor") != null ? o.optJSONObject("constructor").optString("name") : "";
            if (!kon.isEmpty()) sb.append("\nMotor: ").append(kon);
            sb.append("\nPoin: ").append(poin);
            tambah(sb, o, "race_wins", "Menang balapan");
            tambah(sb, o, "podiums", "Podium");
            tambah(sb, o, "sprint_wins", "Menang sprint");
            tambah(sb, o, "sprint_podiums", "Podium sprint");
            det.put(key, sb.toString());
        }
    }

    void tambah(StringBuilder sb, JSONObject o, String f, String label) {
        if (o.has(f) && !o.isNull(f)) sb.append("\n").append(label).append(": ").append(o.optInt(f));
    }

    // ---------- Klasemen tim dan konstruktor (dijumlahkan dari poin pembalap) ----------

    static String angka(double d) {
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    void klasemenGabung(Musim ms, String kid, boolean konstruktor, List<String> baris, List<String> r,
                        Map<String, String> det) throws Exception {
        JSONArray a = larik(ambil("standings?seasonUuid=" + ms.id + "&categoryUuid=" + kid), "classification");
        java.util.LinkedHashMap<String, double[]> jml = new java.util.LinkedHashMap<>();
        Map<String, StringBuilder> pembalap = new HashMap<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String nama;
            if (konstruktor) {
                JSONObject c = o.optJSONObject("constructor");
                nama = c != null ? c.optString("name") : "";
            } else nama = namaTim(o);
            if (nama.isEmpty()) continue;
            double p = (!o.has("points") || o.isNull("points")) ? 0 : o.optDouble("points", 0);
            double[] t = jml.get(nama);
            if (t == null) {
                t = new double[]{0};
                jml.put(nama, t);
                pembalap.put(nama, new StringBuilder());
            }
            t[0] += p;
            pembalap.get(nama).append("\n").append(namaPembalap(o)).append(": ").append(angka(p)).append(" poin");
        }
        List<Map.Entry<String, double[]>> daftar = new ArrayList<>(jml.entrySet());
        java.util.Collections.sort(daftar, (x, y) -> Double.compare(y.getValue()[0], x.getValue()[0]));
        for (int i = 0; i < daftar.size(); i++) {
            String nama = daftar.get(i).getKey();
            String p = angka(daftar.get(i).getValue()[0]);
            baris.add((i + 1) + ". " + nama + ", " + p + " poin");
            String key = "G" + i;
            r.add(key);
            det.put(key, "Posisi " + (i + 1) + "\n" + nama + "\nPoin: " + p
                    + "\n\nPembalap:" + pembalap.get(nama));
        }
    }

    // ---------- Jadwal ----------

    void jadwal(Musim ms, List<String> baris) throws Exception {
        JSONArray a = larik(ambil("events?seasonUuid=" + ms.id), "events");
        List<JSONObject> ev = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            if (o.optBoolean("test", false)) continue;
            ev.add(o);
        }
        java.util.Collections.sort(ev, (x, y) -> x.optString("date_start").compareTo(y.optString("date_start")));
        int no = 0;
        for (JSONObject o : ev) {
            no++;
            String nama = o.optString("sponsored_name");
            if (nama.isEmpty()) nama = o.optString("name");
            JSONObject neg = o.optJSONObject("country");
            String negara = neg != null ? neg.optString("name") : "";
            JSONObject sir = o.optJSONObject("circuit");
            String sirkuit = sir != null ? sir.optString("name") : "";
            String mulai = tgl(o.optString("date_start"));
            String selesai = tgl(o.optString("date_end"));
            String waktu = mulai.equals(selesai) || selesai.isEmpty() ? mulai : mulai + " sampai " + selesai;
            String st = o.optString("status");
            boolean selesaiSudah = st.equalsIgnoreCase("FINISHED");
            baris.add(no + ". " + nama + (negara.isEmpty() ? "" : ", " + negara)
                    + (sirkuit.isEmpty() ? "" : ", " + sirkuit)
                    + (waktu.isEmpty() ? "" : ", " + waktu)
                    + (selesaiSudah ? ", sudah selesai" : ""));
        }
    }

    static String tgl(String s) {
        return s != null && s.length() >= 10 ? s.substring(0, 10) : (s == null ? "" : s);
    }

    // ---------- Hasil balapan ----------

    void daftarSeri(Musim ms, String kid, List<String> baris, List<String> r) throws Exception {
        JSONArray a = larik(ambil("events?seasonUuid=" + ms.id + "&isFinished=true"), "events");
        List<JSONObject> ev = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            // Tes pramusim tidak ikut.
            if (o.optBoolean("test", false)) continue;
            ev.add(o);
        }
        // Terbaru di atas.
        java.util.Collections.sort(ev, (x, y) -> y.optString("date_start").compareTo(x.optString("date_start")));
        for (JSONObject o : ev) {
            String nama = o.optString("sponsored_name");
            if (nama.isEmpty()) nama = o.optString("name");
            JSONObject neg = o.optJSONObject("country");
            String negara = neg != null ? neg.optString("name") : "";
            String tgl = o.optString("date_end");
            if (tgl.length() >= 10) tgl = tgl.substring(0, 10);
            baris.add(nama + (negara.isEmpty() ? "" : ", " + negara) + (tgl.isEmpty() ? "" : ", " + tgl));
            r.add("E:" + o.optString("id") + "|" + nama);
        }
    }

    void ketuk(final String ref) {
        if (ref.startsWith("K") || ref.startsWith("G")) {
            String t = detailTeks.get(ref);
            if (t != null) new AlertDialog.Builder(this).setTitle(ref.startsWith("K") ? "Detail pembalap" : "Detail")
                    .setMessage(t).setPositiveButton("Tutup", null).show();
            return;
        }
        if (ref.startsWith("E:")) {
            String sisa = ref.substring(2);
            int p = sisa.indexOf('|');
            pilihSesi(sisa.substring(0, p), sisa.substring(p + 1));
        }
    }

    void pilihSesi(final String eventId, final String namaSeri) {
        status.setText("Memuat sesi...");
        final int k = kelas;
        io.execute(() -> {
            try {
                final String kid = idKelas(musim, k);
                JSONArray a = larik(ambil("sessions?eventUuid=" + eventId + "&categoryUuid=" + kid), "sessions");
                final List<String> nama = new ArrayList<>();
                final List<String> idSesi = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String st = o.optString("status");
                    // Hanya sesi yang sudah punya hasil.
                    if (!st.isEmpty() && !st.equalsIgnoreCase("FINISHED") && !st.equalsIgnoreCase("OFFICIAL")) continue;
                    nama.add(namaSesi(o));
                    idSesi.add(o.optString("id"));
                }
                // Balapan dan sprint di atas, latihan di bawah.
                for (int i = 0; i < nama.size(); i++) {
                    for (int j = i + 1; j < nama.size(); j++) {
                        if (urutSesi(nama.get(j)) < urutSesi(nama.get(i))) {
                            String t = nama.get(i); nama.set(i, nama.get(j)); nama.set(j, t);
                            t = idSesi.get(i); idSesi.set(i, idSesi.get(j)); idSesi.set(j, t);
                        }
                    }
                }
                ui.post(() -> {
                    status.setText(namaSeri);
                    if (nama.isEmpty()) {
                        new AlertDialog.Builder(this).setTitle(namaSeri)
                                .setMessage("Belum ada hasil sesi untuk seri ini.")
                                .setPositiveButton("Tutup", null).show();
                        return;
                    }
                    new AlertDialog.Builder(this).setTitle(namaSeri + ", pilih sesi")
                            .setItems(nama.toArray(new String[0]),
                                    (d, i) -> tampilHasil(idSesi.get(i), namaSeri + ", " + nama.get(i)))
                            .show();
                });
            } catch (Galat g) {
                final String p = g.pesan != null ? g.pesan : "Gagal memuat sesi. Coba lagi.";
                ui.post(() -> status.setText(p));
            } catch (Exception e) {
                ui.post(() -> status.setText("Gagal memuat sesi. Cek internet."));
            }
        });
    }

    static int urutSesi(String n) {
        if (n.startsWith("Balapan")) return 0;
        if (n.startsWith("Sprint")) return 1;
        if (n.startsWith("Kualifikasi")) return 2;
        if (n.startsWith("Pemanasan")) return 4;
        return 3;
    }

    static String namaSesi(JSONObject o) {
        String tipe = o.optString("type").toUpperCase();
        String nama = o.optString("name");
        int no = o.optInt("number", 0);
        if (tipe.equals("RAC")) return "Balapan";
        if (tipe.equals("SPR")) return "Sprint";
        if (tipe.equals("Q1")) return "Kualifikasi 1";
        if (tipe.equals("Q2")) return "Kualifikasi 2";
        if (tipe.equals("WUP")) return "Pemanasan";
        if (tipe.equals("PR")) return "Latihan resmi" + (no > 0 ? " " + no : "");
        if (tipe.startsWith("FP")) return "Latihan bebas " + tipe.substring(2);
        if (tipe.equals("Q")) return "Kualifikasi";
        return nama.isEmpty() ? tipe : nama;
    }

    void tampilHasil(final String sesiId, final String judul) {
        status.setText("Memuat hasil...");
        io.execute(() -> {
            String isi;
            try {
                JSONArray a = larik(ambil("session/" + sesiId + "/classification?test=false"), "classification");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String pos = o.isNull("position") ? "-" : String.valueOf(o.optInt("position"));
                    sb.append(pos).append(". ").append(namaPembalap(o));
                    String tim = namaTim(o);
                    if (!tim.isEmpty()) sb.append(", ").append(tim);
                    String ket = keterangan(o);
                    if (!ket.isEmpty()) sb.append(", ").append(ket);
                    String poin = poin(o);
                    if (!poin.equals("0") && o.has("points") && !o.isNull("points")) sb.append(", ").append(poin).append(" poin");
                    sb.append("\n");
                }
                isi = sb.length() == 0 ? "Hasil belum tersedia." : sb.toString().trim();
            } catch (Galat g) {
                isi = g.pesan != null ? g.pesan : "Gagal memuat hasil. Coba lagi.";
            } catch (Exception e) {
                isi = "Gagal memuat hasil. Cek internet.";
            }
            final String tampil = isi;
            ui.post(() -> {
                status.setText(judul);
                new AlertDialog.Builder(this).setTitle(judul)
                        .setMessage(tampil).setPositiveButton("Tutup", null).show();
            });
        });
    }

    // Pemenang: waktu; lainnya: selisih; yang tidak finis: statusnya.
    String keterangan(JSONObject o) {
        String st = o.optString("status");
        if (!st.isEmpty() && !st.equalsIgnoreCase("OK") && !st.equalsIgnoreCase("INSTND")) {
            if (st.equalsIgnoreCase("DNF")) return "tidak finis";
            if (st.equalsIgnoreCase("DNS")) return "tidak start";
            if (st.equalsIgnoreCase("DSQ")) return "didiskualifikasi";
            return st;
        }
        JSONObject gap = o.optJSONObject("gap");
        String first = gap != null ? gap.optString("first") : "";
        int pos = o.optInt("position", 0);
        String waktu = o.optString("time");
        if (pos == 1 && !waktu.isEmpty()) return waktu;
        if (!first.isEmpty() && !first.equals("0") && !first.equals("null")) return "selisih " + first;
        if (!waktu.isEmpty() && !waktu.equals("null")) return waktu;
        return "";
    }

    String namaPembalap(JSONObject o) {
        JSONObject r = o.optJSONObject("rider");
        if (r != null) {
            String n = r.optString("full_name");
            if (n.isEmpty()) n = (r.optString("name") + " " + r.optString("surname")).trim();
            if (!n.isEmpty()) return n;
        }
        String n = o.optString("name");
        return n.isEmpty() ? "?" : n;
    }

    String namaTim(JSONObject o) {
        JSONObject t = o.optJSONObject("team");
        if (t != null) return t.optString("name");
        return "";
    }

    String poin(JSONObject o) {
        if (!o.has("points") || o.isNull("points")) return "0";
        double d = o.optDouble("points", 0);
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    // ---------- JSON ----------

    // Jawaban bisa berupa larik langsung atau objek berisi larik.
    JSONArray larik(String s, String kunci) throws Exception {
        String t = s.trim();
        if (t.startsWith("[")) return new JSONArray(t);
        JSONObject o = new JSONObject(t);
        JSONArray a = o.optJSONArray(kunci);
        if (a == null) a = o.optJSONArray("classification");
        if (a == null) a = o.optJSONArray("data");
        return a != null ? a : new JSONArray();
    }

    // ---------- HTTP ----------

    static final HashMap<String, Object[]> CACHE = new HashMap<>();
    static final long CACHE_MS = 90000;

    String ambil(String jalur) throws Exception {
        synchronized (CACHE) {
            Object[] t = CACHE.get(jalur);
            if (t != null && System.currentTimeMillis() - (Long) t[0] < CACHE_MS) return (String) t[1];
        }
        Exception terakhir = null;
        for (String basis : BASE) {
            try {
                String hasil = httpLangsung(basis + jalur);
                synchronized (CACHE) { CACHE.put(jalur, new Object[]{System.currentTimeMillis(), hasil}); }
                return hasil;
            } catch (Galat g) {
                // 429 dan sejenisnya langsung dilaporkan; alamat kedua hanya untuk gangguan jaringan.
                throw g;
            } catch (Exception e) {
                terakhir = e;
            }
        }
        throw terakhir != null ? terakhir : new Exception("gagal");
    }

    String httpLangsung(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) MotoGPNovan");
            c.setRequestProperty("Accept", "application/json");
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            int code = c.getResponseCode();
            if (code != 200) throw new Galat(code, null);
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }
}
