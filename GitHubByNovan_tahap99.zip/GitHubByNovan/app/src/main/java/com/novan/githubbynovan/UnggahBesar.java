package com.novan.githubbynovan;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Unggah satu berkas (sampai 100 MB) ke repositori lewat GitHub Contents API tanpa memuat seluruh berkas
 * ke memori: berkas disalin dulu ke penyimpanan sementara, lalu dikirim potongan demi potongan sambil
 * diubah ke Base64 langsung di aliran jaringan. Pemakaian memori tetap kecil berapa pun ukuran berkas.
 *
 * Catatan jujur soal "lanjut": Contents API GitHub menerima berkas dalam SATU permintaan utuh, jadi
 * unggahan yang terputus tidak bisa disambung dari tengah. Yang dilakukan di sini: menunggu internet
 * kembali, memeriksa apakah unggahan sebelumnya ternyata sudah masuk (dibandingkan lewat SHA git),
 * dan kalau belum, mengirim ulang otomatis sampai {@link #PERCOBAAN} kali.
 */
public final class UnggahBesar {
    public static final long MAX = 100L * 1024 * 1024;
    public static final int PERCOBAAN = 6;

    /** Jeda (detik) sebelum percobaan ke-2, ke-3, dst. Tidak final agar bisa dipercepat saat pengujian. */
    static int[] jeda = {3, 6, 12, 20, 30};

    /** Kelipatan 3 byte supaya Base64 per potongan tidak menyisakan "=" di tengah aliran. */
    private static final int POTONGAN = 3 * 16 * 1024;
    private static final long TUNGGU_JARINGAN_MS = 10L * 60 * 1000;

    private UnggahBesar() { }

    public interface Kemajuan {
        /** Dipanggil dari thread latar. Pemanggil yang memindahkannya ke thread utama. */
        void pesan(String teks);
    }

    public interface Batal {
        boolean sudahBatal();
    }

    public static final class Hasil {
        public boolean ok;
        public boolean dibatalkan;
        /** Berkas dengan nama sama sudah ada sebelum unggahan ini dan diganti. */
        public boolean diganti;
        /** Jumlah percobaan kirim yang dipakai (1 = langsung berhasil). */
        public int percobaan;
        public String galat = "";
        public String raw = "";
        public String web = "";
    }

    private static final class Sha {
        boolean pasti;
        String sha;
        String raw = "";
        String web = "";
    }

    private static final class Dibatalkan extends IOException {
        Dibatalkan() { super("dibatalkan"); }
    }

    private static final class HttpGagal extends IOException {
        final boolean bisaUlang;

        HttpGagal(int kode, String pesanGithub) {
            super("Gagal. Kode: " + kode + (pesanGithub.isEmpty() ? "" : " (" + pesanGithub + ")")
                    + (kode == 413 ? "\nBerkas terlalu besar untuk GitHub." : ""));
            String p = pesanGithub.toLowerCase(java.util.Locale.US);
            bisaUlang = kode == 408 || kode == 409 || kode == 429 || kode >= 500
                    || (kode == 403 && p.contains("rate limit"))
                    || (kode == 422 && p.contains("sha"));
        }
    }

    /**
     * Unggah satu berkas. Blokir sampai selesai, jadi HANYA boleh dipanggil dari thread latar.
     *
     * @param jalur  jalur tujuan di repo, mis. "app/data.zip"
     * @param label  nama pendek untuk pesan komit dan kemajuan
     */
    public static Hasil kirim(Context ctx, Uri uri, String full, String token, String jalur, String label,
                              Batal batal, Kemajuan k) {
        return kirim(ctx, uri, full, token, jalur, label, batal, k, false);
    }

    /**
     * @param tanpaPicu bila true, pesan komit diberi {@code [skip ci]} agar unggahan ini tidak memicu
     *                  pembangunan lewat push; pembangunan dipicu sekali oleh pemanggil setelah semua selesai
     */
    public static Hasil kirim(Context ctx, Uri uri, String full, String token, String jalur, String label,
                              Batal batal, Kemajuan k, boolean tanpaPicu) {
        Hasil h = new Hasil();
        Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        File tmp = null;
        try {
            bersihkanSisa(app);
            k.pesan("Menyiapkan " + label + "...");
            tmp = new File(app.getCacheDir(), "unggah-" + System.nanoTime() + ".tmp");
            long ukuran = salin(app, uri, tmp, batal, k, label);

            String blobSha = null;
            Boolean awalnyaAda = null;
            String terakhir = "";
            for (int ke = 1; ke <= PERCOBAAN; ke++) {
                cekBatal(batal);
                h.percobaan = ke;
                if (ke > 1) tunggu(app, ke, terakhir, batal, k);

                k.pesan(ke == 1 ? "Memeriksa berkas yang sudah ada di repositori..."
                        : "Memeriksa apakah unggahan sebelumnya sudah masuk...");
                Sha s = cariSha(full, token, jalur);
                if (!s.pasti) {
                    terakhir = "Repositori tidak bisa diperiksa. Cek koneksi.";
                    continue;
                }
                if (awalnyaAda == null) awalnyaAda = s.sha != null;

                if (ke > 1 && s.sha != null) {
                    if (blobSha == null) blobSha = shaBlob(tmp, ukuran);
                    if (blobSha.equalsIgnoreCase(s.sha)) {
                        // Unggahan sebelumnya ternyata sudah masuk walau jawaban GitHub tidak sampai.
                        h.ok = true;
                        h.diganti = awalnyaAda;
                        h.raw = s.raw;
                        h.web = s.web;
                        return h;
                    }
                }

                String pesanKomit = (s.sha != null ? "Perbarui " : "Unggah ") + label + " dari HP"
                        + (tanpaPicu ? " [skip ci]" : "");
                try {
                    String res = put(full, token, jalur, pesanKomit, s.sha, tmp, ukuran, batal, k, label, ke);
                    JSONObject c = Api.parse(res).optJSONObject("content");
                    h.ok = true;
                    h.diganti = awalnyaAda;
                    h.raw = Api.str(c, "download_url");
                    h.web = Api.str(c, "html_url");
                    return h;
                } catch (Dibatalkan e) {
                    throw e;
                } catch (HttpGagal e) {
                    terakhir = e.getMessage();
                    if (!e.bisaUlang) {
                        h.galat = terakhir;
                        return h;
                    }
                } catch (IOException e) {
                    terakhir = "Koneksi terputus saat mengirim"
                            + (e.getMessage() == null ? "." : " (" + e.getMessage() + ").");
                }
            }
            h.galat = "Gagal setelah " + PERCOBAAN + " percobaan. " + terakhir;
        } catch (Dibatalkan e) {
            h.dibatalkan = true;
            h.galat = "Unggahan dibatalkan.";
        } catch (IOException e) {
            h.galat = e.getMessage() == null ? "Gagal membaca berkas." : e.getMessage();
        } finally {
            if (tmp != null) tmp.delete();
        }
        return h;
    }

    // ------------------------------------------------------------------ penyalinan ke penyimpanan sementara

    private static long salin(Context ctx, Uri uri, File tmp, Batal batal, Kemajuan k, String label)
            throws IOException {
        InputStream in = ctx.getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Berkas tidak bisa dibuka.");
        long total = 0;
        long laporTerakhir = 0;
        java.io.FileOutputStream out = null;
        try {
            out = new java.io.FileOutputStream(tmp);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) {
                cekBatal(batal);
                total += n;
                if (total > MAX) throw new IOException("Berkas lebih dari 100 MB, terlalu besar.");
                out.write(buf, 0, n);
                if (total - laporTerakhir >= 8L * 1024 * 1024) {
                    laporTerakhir = total;
                    k.pesan("Menyiapkan " + label + ": " + Ui.size(total) + " dibaca...");
                }
            }
        } catch (Dibatalkan e) {
            throw e;
        } catch (IOException e) {
            String m = e.getMessage() == null ? "" : e.getMessage();
            if (m.contains("ENOSPC") || m.toLowerCase(java.util.Locale.US).contains("no space")) {
                throw new IOException("Penyimpanan HP penuh.");
            }
            if (m.startsWith("Berkas lebih dari")) throw e;
            throw new IOException("Gagal membaca berkas" + (m.isEmpty() ? "." : ": " + m));
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            if (out != null) {
                try { out.close(); } catch (IOException ignored) { }
            }
        }
        return total;
    }

    /** Hapus sisa berkas sementara dari proses yang dulu terhenti paksa. */
    private static void bersihkanSisa(Context ctx) {
        try {
            File[] fs = ctx.getCacheDir().listFiles();
            if (fs == null) return;
            long batas = System.currentTimeMillis() - 60L * 60 * 1000;
            for (File f : fs) {
                if (f.getName().startsWith("unggah-") && f.getName().endsWith(".tmp") && f.lastModified() < batas) {
                    f.delete();
                }
            }
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ pengiriman streaming

    private static String put(String full, String token, String jalur, String pesanKomit, String sha, File tmp,
                              long ukuran, Batal batal, Kemajuan k, String label, int ke) throws IOException {
        String pembuka = "{\"message\":" + JSONObject.quote(pesanKomit)
                + (sha != null ? ",\"sha\":" + JSONObject.quote(sha) : "") + ",\"content\":\"";
        String penutup = "\"}";
        byte[] pb = pembuka.getBytes("UTF-8");
        byte[] tb = penutup.getBytes("UTF-8");
        long panjangIsi = 4L * ((ukuran + 2) / 3);
        long panjangTotal = pb.length + panjangIsi + tb.length;

        String url = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(jalur);
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(20000);
            c.setReadTimeout(180000);
            c.setRequestMethod("PUT");
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("User-Agent", "GitHub-by-novan");
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(panjangTotal);

            String ket = ke > 1 ? "\nPercobaan ke " + ke + " dari " + PERCOBAAN : "";
            k.pesan("Mengunggah " + label + "\n0% (0 B dari " + Ui.size(ukuran) + ")" + ket);

            OutputStream os = c.getOutputStream();
            os.write(pb);
            long terkirim = 0;
            int pctBerikut = 5;
            FileInputStream in = new FileInputStream(tmp);
            try {
                byte[] buf = new byte[POTONGAN];
                while (true) {
                    cekBatal(batal);
                    int n = isi(in, buf);
                    if (n <= 0) break;
                    os.write(Base64.encode(buf, 0, n, Base64.NO_WRAP));
                    terkirim += n;
                    if (ukuran >= 256 * 1024) {
                        int pct = (int) (terkirim * 100 / ukuran);
                        if (pct >= pctBerikut && pct < 100) {
                            pctBerikut = (pct / 5 + 1) * 5;
                            k.pesan("Mengunggah " + label + "\n" + pct + "% (" + Ui.size(terkirim) + " dari "
                                    + Ui.size(ukuran) + ")" + ket);
                        }
                    }
                    if (n < POTONGAN) break;
                }
            } finally {
                in.close();
            }
            if (terkirim != ukuran) throw new IOException("ukuran berkas sementara berubah");
            os.write(tb);
            os.flush();
            os.close();

            k.pesan("Mengunggah " + label + "\n100%. Data terkirim, menunggu GitHub memproses..." + ket);
            int code = c.getResponseCode();
            InputStream rin = code < 400 ? c.getInputStream() : c.getErrorStream();
            String teks = baca(rin);
            if (code >= 200 && code < 300) return teks;
            String msg = "";
            try { msg = new JSONObject(teks).optString("message", ""); } catch (Exception ignored) { }
            throw new HttpGagal(code, msg);
        } catch (Dibatalkan e) {
            throw e;
        } finally {
            c.disconnect();
        }
    }

    private static int isi(InputStream in, byte[] buf) throws IOException {
        int n = 0;
        while (n < buf.length) {
            int r = in.read(buf, n, buf.length - n);
            if (r < 0) break;
            n += r;
        }
        return n;
    }

    private static String baca(InputStream in) throws IOException {
        if (in == null) return "";
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }

    // ------------------------------------------------------------------ cek berkas lama dan verifikasi

    /**
     * Cari SHA berkas yang sudah ada lewat daftar isi folder induknya. Daftar folder tidak membawa isi berkas,
     * jadi tetap bekerja untuk berkas di atas 1 MB (tempat GET berkas langsung ditolak GitHub).
     */
    private static Sha cariSha(String full, String token, String jalur) {
        int i = jalur.lastIndexOf('/');
        String dir = i < 0 ? "" : jalur.substring(0, i);
        String nama = jalur.substring(i + 1);
        String url = Api.BASE + "/repos/" + full + "/contents" + (dir.isEmpty() ? "" : "/" + Api.enc(dir));
        Sha s = new Sha();
        Api.Result r = Api.requestSync("GET", url, token, null);
        if (r.ok) {
            String t = r.text == null ? "" : r.text.trim();
            if (t.startsWith("[")) {
                JSONArray a = Api.parseArr(t);
                for (int j = 0; j < a.length(); j++) {
                    JSONObject it = a.optJSONObject(j);
                    if (it != null && nama.equals(it.optString("name")) && "file".equals(it.optString("type"))) {
                        s.sha = it.optString("sha");
                        s.raw = Api.str(it, "download_url");
                        s.web = Api.str(it, "html_url");
                        break;
                    }
                }
                s.pasti = true;
                if (s.sha == null && a.length() >= 1000) {
                    // Folder sangat besar: daftar GitHub terpotong 1000 item, cek berkasnya langsung.
                    Api.Result g = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/contents/" + Api.enc(jalur),
                            token, null);
                    if (g.ok) {
                        String sh = Api.str(Api.parse(g.text), "sha");
                        if (!sh.isEmpty()) s.sha = sh;
                    } else if (g.text == null || !g.text.contains("Kode: 404")) {
                        s.pasti = false;
                    }
                }
            } else {
                s.pasti = true; // jalur induk ternyata berkas, bukan folder: anggap berkas baru
            }
        } else if (r.text != null && r.text.contains("Kode: 404")) {
            s.pasti = true; // folder belum ada, berarti berkas baru
        }
        return s;
    }

    /** SHA-1 "blob" ala git: sama dengan sha yang dilaporkan GitHub untuk isi berkas yang sama. */
    private static String shaBlob(File f, long ukuran) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(("blob " + ukuran + "\0").getBytes("UTF-8"));
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
            } finally {
                in.close();
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format(java.util.Locale.US, "%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException("SHA-1 tidak tersedia");
        }
    }

    // ------------------------------------------------------------------ menunggu dan pembatalan

    private static void cekBatal(Batal b) throws Dibatalkan {
        if (b != null && b.sudahBatal()) throw new Dibatalkan();
    }

    private static void tidur(long ms) throws Dibatalkan {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new Dibatalkan();
        }
    }

    /** Hitung mundur sebelum percobaan berikutnya, lalu tunggu internet kembali bila sedang putus. */
    private static void tunggu(Context ctx, int ke, String sebab, Batal batal, Kemajuan k) throws Dibatalkan {
        int detik = jeda[Math.min(ke - 2, jeda.length - 1)];
        String awal = sebab == null || sebab.isEmpty() ? "Koneksi bermasalah." : sebab;
        for (int s = detik; s > 0; s--) {
            cekBatal(batal);
            k.pesan(awal + "\nMencoba lagi (percobaan " + ke + " dari " + PERCOBAAN + ") dalam " + s + " detik...");
            tidur(1000);
        }
        long mulai = System.currentTimeMillis();
        while (!adaJaringan(ctx)) {
            cekBatal(batal);
            if (System.currentTimeMillis() - mulai > TUNGGU_JARINGAN_MS) break;
            k.pesan("Internet terputus. Unggahan lanjut otomatis saat tersambung...");
            tidur(1000);
        }
    }

    private static boolean adaJaringan(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true;
        }
    }
}
