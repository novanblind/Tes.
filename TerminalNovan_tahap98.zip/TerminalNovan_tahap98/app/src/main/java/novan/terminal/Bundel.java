package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Environment;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/**
 * Bundel offline: mengumpulkan semua berkas unduhan alat pembangun APK (bootstrap Termux, paket apt,
 * NDK, Android SDK, Gradle, pustaka Gradle) menjadi satu berkas .zip di folder Download, dan memulihkannya
 * lagi tanpa internet saat aplikasi dipasang dari awal.
 *
 * Isi bundel (zip tanpa kompres, karena isinya sudah terkompres):
 *   manifest.txt, bootstrap/bootstrap.zip, apt/archives/*.deb, apt/lists/*, apt/sources.list,
 *   ndk/android-ndk-*.tar.xz, sdk/sdk-paket.tar.gz, gradle/gradle-*-bin.tar.gz,
 *   gradle/pembungkus.tar.gz, gradle/pustaka.tar.gz
 */
public class Bundel {
    static final String FORMAT = "1";
    /** Tautan bundel alat (rilis GitHub). Dipakai bila tidak ada bundel di Download; bagian yang kurang diunduh dari sumber asli Termux. */
    static final String TAUTAN = "https://github.com/novanblind/Peralatantermux/releases/download/v2/TerminalNovan-bundel-20261118.zip";
    /** Isi true bila unduhan tautan sudah gagal pada putaran penyiapan ini, supaya tidak diulang terus. */
    static boolean tautanGagal = false;

    static File staging() { return new File(Env.home, ".bundel"); }
    static File penanda() { return new File(Env.home, ".bundel-path"); }
    /** Folder salinan bundel yang diterima lewat Bagikan dari aplikasi lain (mis. file manager). */
    static File salinan() { return new File(Env.home, ".bundel-salinan"); }

    /**
     * Cek apakah aliran zip ini bundel alat: entri pertama bernama manifest.txt dan isinya memuat format= dan ndk=.
     * Dibaca berurutan, jadi hanya bagian awal berkas yang dibaca (bukan seluruh bundel).
     */
    static boolean adalahBundel(InputStream raw) {
        try (ZipInputStream zi = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e = zi.getNextEntry();
            if (e == null || !e.getName().equals("manifest.txt")) return false;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n, tot = 0;
            while ((n = zi.read(b)) > 0 && tot < 65536) { bo.write(b, 0, n); tot += n; }
            String m = bo.toString("UTF-8");
            return !nilai(m, "format").isEmpty() && m.contains("ndk=");
        } catch (Throwable t) { return false; }
    }

    static boolean cocok(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return f.isFile() && n.endsWith(".zip") && n.contains("bundel");
    }

    /** Semua berkas bundel di Download dan di akar penyimpanan, yang terbaru lebih dulu. */
    static List<File> semua() {
        List<File> r = new ArrayList<>();
        File root = Environment.getExternalStorageDirectory();
        for (File d : new File[]{new File(root, "Download"), root}) {
            File[] fs = d.listFiles();
            if (fs == null) continue;
            for (File f : fs) if (cocok(f)) r.add(f);
        }
        Collections.sort(r, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return r;
    }

    static File cari() {
        List<File> r = semua();
        return r.isEmpty() ? null : r.get(0);
    }

    static String mb(long b) { return (b / 1048576) + " MB"; }

    /** Hapus sisa pembukaan bundel (hanya setelah penyiapan berhasil). */
    static void bersihkan() {
        Builder.del(staging());
        Builder.del(salinan());
        penanda().delete();
        unduhan().delete();
        new File(unduhan().getPath() + ".part").delete();
    }

    // ------------------------------------------------------------------ unduh dari tautan

    static File unduhan() { return new File(Env.home, ".bundel-cache/bundel-unduhan.zip"); }

    /** Cek manifest bundel: format dikenali dan arsitekturnya cocok dengan HP ini. */
    static boolean layak(File f) {
        try (ZipFile z = new ZipFile(f)) {
            ZipEntry m = z.getEntry("manifest.txt");
            if (m == null) return false;
            String mf = baca(z, m);
            if (!FORMAT.equals(nilai(mf, "format"))) { Pkg.out("Format bundel tidak dikenali: " + nilai(mf, "format")); return false; }
            String ar = nilai(mf, "arsitektur");
            if (!ar.isEmpty() && !ar.equals(arsitektur())) { Pkg.out("Bundel dibuat untuk " + ar + ", sedangkan HP ini " + arsitektur()); return false; }
            return true;
        } catch (Throwable t) { return false; }
    }

    /**
     * Unduh bundel dari TAUTAN ke penyimpanan aplikasi (bisa dilanjutkan bila terputus). Mengembalikan berkasnya,
     * atau null bila gagal; pemanggil lalu memakai sumber asli Termux.
     */
    static File dariTautan() {
        if (tautanGagal) return null;
        File dest = unduhan(), part = new File(dest.getPath() + ".part");
        try {
            if (dest.isFile() && layak(dest)) { Pkg.out("Memakai bundel yang sudah terunduh"); return dest; }
            dest.delete();
            dest.getParentFile().mkdirs();
            Pkg.out("Mengunduh bundel alat dari tautan: " + TAUTAN);
            Pkg.say("Mengunduh bundel alat dari tautan");
            // Unduhan adalah bagian terbesar: separuh pertama dari persen total dipakai untuk unduhan.
            Progres.window(0, 50);
            Progres.tahap(0, 100, "Mengunduh bundel alat");
            IOException terakhir = null;
            boolean selesai = false;
            for (int coba = 1; coba <= 3 && !selesai; coba++) {
                try {
                    selesai = unduhSekali(part);
                } catch (IOException e) {
                    terakhir = e;
                    Pkg.out("Unduhan terputus (" + e.getMessage() + "). Percobaan " + coba + " dari 3");
                    try { Thread.sleep(3000); } catch (InterruptedException ie) { break; }
                }
            }
            if (!selesai) throw terakhir != null ? terakhir : new IOException("Unduhan belum lengkap");
            if (!part.renameTo(dest)) throw new IOException("Bundel gagal disimpan");
            if (!layak(dest)) { dest.delete(); throw new IOException("Isi berkas bukan bundel yang cocok untuk HP ini"); }
            Pkg.out("Bundel selesai diunduh: " + mb(dest.length()));
            Progres.window(50, 100);
            return dest;
        } catch (Throwable t) {
            tautanGagal = true;
            Progres.window(0, 100);
            String m = t instanceof java.net.UnknownHostException || t instanceof java.net.SocketTimeoutException
                ? "tidak ada koneksi internet atau sangat lambat" : String.valueOf(t.getMessage());
            Pkg.out("Bundel dari tautan tidak bisa dipakai: " + m);
            Pkg.out("Beralih ke sumber asli Termux untuk semua alat.");
            Pkg.say("Bundel dari tautan gagal. Beralih ke sumber asli Termux");
            return null;
        }
    }

    /** Satu putaran unduh, melanjutkan dari bagian yang sudah ada. true bila berkas lengkap. */
    static boolean unduhSekali(File part) throws IOException {
        long ada = part.isFile() ? part.length() : 0;
        java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL(TAUTAN).openConnection();
        h.setConnectTimeout(20000); h.setReadTimeout(30000);
        h.setRequestProperty("User-Agent", "TermuxNovan");
        if (ada > 0) h.setRequestProperty("Range", "bytes=" + ada + "-");
        int kode = h.getResponseCode();
        if (kode == 416 && ada > 0) return true;
        if (kode != 200 && kode != 206) throw new IOException("Server membalas kode " + kode);
        boolean lanjut = kode == 206 && ada > 0;
        long sisa = h.getContentLengthLong();
        long total = sisa > 0 ? (lanjut ? ada + sisa : sisa) : 0;
        if (!lanjut) ada = 0;
        if (sisa > 0 && part.getParentFile().getUsableSpace() < sisa + 300L * 1048576)
            throw new IOException("Ruang penyimpanan aplikasi kurang, butuh sekitar " + mb(sisa + 300L * 1048576));
        long got = ada;
        int lastPct = -10, infoPct = -1;
        try (InputStream in = h.getInputStream(); OutputStream o = new FileOutputStream(part, lanjut)) {
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) {
                o.write(b, 0, n); got += n;
                if (total > 0) {
                    int pct = (int) (got * 100 / total);
                    Progres.sub(pct);
                    if (pct != infoPct) { infoPct = pct; Progres.info("Terunduh " + mb(got) + " dari " + mb(total)); }
                    if (pct >= lastPct + 10) { lastPct = pct - pct % 10; Pkg.out("Terunduh " + lastPct + " persen, " + mb(got)); }
                }
            }
        }
        if (total > 0 && got < total) throw new IOException("Unduhan terpotong");
        return true;
    }

    // ------------------------------------------------------------------ impor

    static boolean perlu(String n) {
        if (n.endsWith("/")) return false;
        return n.equals("manifest.txt") || n.startsWith("bootstrap/") || n.startsWith("apt/");
    }

    static String baca(ZipFile z, ZipEntry e) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (InputStream in = z.getInputStream(e)) { Pkg.copy(in, bo); }
        return bo.toString("UTF-8");
    }

    static String nilai(String manifest, String kunci) {
        for (String l : manifest.split("\n")) {
            l = l.trim();
            if (l.startsWith(kunci + "=")) return l.substring(kunci.length() + 1).trim();
        }
        return "";
    }

    static String arsitektur() {
        String abi = Build.SUPPORTED_ABIS[0];
        return abi.startsWith("arm64") ? "aarch64" : abi.startsWith("armeabi") ? "arm" : abi.startsWith("x86_64") ? "x86_64" : "i686";
    }

    /**
     * Buka bagian kecil bundel yang dibutuhkan sebelum bash ada (bootstrap dan paket apt) ke folder sementara,
     * catat lokasi bundel, lalu jalankan penyiapan. Bagian besar (NDK, SDK, Gradle) dibaca langsung dari zip.
     */
    static void impor(File zip) throws Exception {
        if (!zip.isFile()) throw new IOException("Berkas tidak ditemukan: " + zip.getPath());
        Pkg.out("Membuka bundel: " + zip.getName() + " (" + mb(zip.length()) + ")");
        Pkg.say("Membuka bundel offline");
        File st = staging();
        Builder.del(st);
        st.mkdirs();
        try (ZipFile z = new ZipFile(zip)) {
            ZipEntry m = z.getEntry("manifest.txt");
            if (m == null) throw new IOException("Bukan bundel Termux Novan: manifest.txt tidak ada");
            String mf = baca(z, m);
            if (!FORMAT.equals(nilai(mf, "format"))) throw new IOException("Versi format bundel tidak dikenali: " + nilai(mf, "format"));
            String ar = nilai(mf, "arsitektur");
            if (!ar.isEmpty() && !ar.equals(arsitektur()))
                throw new IOException("Bundel dibuat untuk " + ar + ", sedangkan HP ini " + arsitektur());
            Pkg.out("Bundel dibuat: " + nilai(mf, "dibuat") + ", NDK: " + nilai(mf, "ndk"));
            int total = 0;
            for (Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements();) if (perlu(e.nextElement().getName())) total++;
            Progres.tahap(0, 5, "Membuka bundel offline");
            int n = 0;
            for (Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements();) {
                ZipEntry en = e.nextElement();
                String name = en.getName();
                if (!perlu(name)) continue;
                File o = Pkg.safe(st, name);
                o.getParentFile().mkdirs();
                try (InputStream in = z.getInputStream(en); OutputStream w = new FileOutputStream(o)) { Pkg.copy(in, w); }
                n++;
                if (total > 0) Progres.sub(n * 100 / total);
                if (n % 50 == 0) Pkg.out(n + " dari " + total + " berkas dibuka");
            }
            Pkg.out("Selesai membuka " + n + " berkas");
        }
        Builder.write(penanda(), zip.getPath());
        new File(Env.home, ".siap-selesai").delete();
        Pkg.out("Memasang alat dari bundel, tanpa internet");
        Pkg.say("Memasang alat dari bundel offline");
        Pkg.siap();
    }

    /** Dialog pilih bundel dari penyimpanan HP. */
    static void pilihImpor(Activity a) {
        if (a instanceof MainActivity && !((MainActivity) a).storageOk()) {
            MainActivity.add("Penyimpanan HP belum diizinkan. Izinkan dulu, lalu ulangi.");
            ((MainActivity) a).askStorage();
            return;
        }
        final List<File> ada = semua();
        if (ada.isEmpty()) {
            String t = "Tidak ada berkas bundel di folder Download. Salin berkas TerminalNovan-bundel-....zip ke folder Download lalu ulangi, atau ketik: impor-alat <lokasi berkas>";
            MainActivity.add(t); MainActivity.say(t);
            return;
        }
        final String[] n = new String[ada.size()];
        for (int i = 0; i < n.length; i++) n[i] = ada.get(i).getName() + ", " + mb(ada.get(i).length());
        new AlertDialog.Builder(a).setTitle("Pilih berkas bundel").setItems(n, (d, i) -> {
            MainActivity.add("$ impor-alat " + ada.get(i).getPath());
            Pkg.handle("impor " + ada.get(i).getPath());
        }).setNegativeButton("Batal", null).show();
    }

    // ------------------------------------------------------------------ ekspor

    /** arg: lokasi berkas atau folder tujuan (boleh kosong), boleh disertai --tanpa-pustaka. */
    static void ekspor(String arg) throws Exception {
        File bash = new File(Env.prefix, "bin/bash");
        if (!bash.exists() || !Pkg.sudahSiap())
            throw new IOException("Alat belum disiapkan. Bangun satu proyek dulu (atau ketik: siap), lalu ekspor");
        String pus = "ya";
        if (arg.contains("--tanpa-pustaka")) { pus = "tanpa"; arg = arg.replace("--tanpa-pustaka", "").trim(); }
        File dl = new File(Environment.getExternalStorageDirectory(), "Download");
        String nama = "TerminalNovan-bundel-" + new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()) + ".zip";
        File out;
        if (arg.isEmpty()) out = new File(dl, nama);
        else {
            File f = arg.startsWith("/") ? new File(arg) : new File(MainActivity.cwd, arg);
            out = f.isDirectory() ? new File(f, nama) : f;
            if (!out.getName().toLowerCase(Locale.ROOT).endsWith(".zip")) out = new File(out.getPath() + ".zip");
        }
        Progres.tahap(0, 3, "Menyiapkan bootstrap Termux");
        Pkg.out("Tujuan bundel: " + out.getPath());
        File bs = Pkg.bootstrapCache();
        File s = new File(Env.home, "ekspor-alat.sh");
        Builder.write(s, EKSPOR);
        int c = Builder.exec(Env.home, bash.getPath(), s.getPath(), out.getPath(), bs.getPath(), pus);
        if (c == 0 && out.isFile()) {
            String m = "Bundel selesai dibuat: " + out.getPath() + ", ukuran " + mb(out.length())
                + ". Simpan juga salinannya di tempat aman, misalnya komputer.";
            Pkg.out(m); Pkg.say("Bundel selesai dibuat, ukuran " + mb(out.length()));
            Progres.selesai(true, m);
            KeepAliveService.selesai(MainActivity.ctx, "Bundel selesai dibuat.");
        } else if (c == 2) {
            Pkg.gagal("Tempat penyimpanan tidak bisa ditulis atau ruangnya kurang (butuh sekitar 3 GB kosong)", "Ruang atau izin penyimpanan kurang");
        } else if (c == 3) {
            Pkg.gagal("NDK tidak bisa diunduh untuk bundel", "NDK tidak bisa diunduh");
        } else if (c == 4) {
            Pkg.gagal("Android SDK tidak bisa dikumpulkan untuk bundel", "Android SDK gagal");
        } else {
            Pkg.gagal("Pembuatan bundel belum selesai, kode " + c, "Pembuatan bundel belum selesai");
        }
    }

    static final String EKSPOR = """
#!/data/data/com.termux/files/usr/bin/bash
OUT="$1"; BS="$2"; PUSTAKA="$3"
export DEBIAN_FRONTEND=noninteractive
cd "$HOME" || exit 2
W="$HOME/.bundel-ekspor"
SDK="$HOME/android-sdk"
TMPZIP="${OUT%.zip}-sebagian.zip"
gagal() { echo "Gagal: $1"; rm -rf "$W" "$TMPZIP"; exit "${2:-1}"; }
unduh() {
  local tot sz pid
  tot=$(curl -fsSL -r 0-0 -D - -o /dev/null "$2" 2>/dev/null | grep -i '^content-range:' | tail -1 | sed 's|.*/||' | sed 's/[^0-9]//g')
  [ -n "$tot" ] || tot=0
  curl -fsSL -o "$1" "$2" &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    sz=$(stat -c %s "$1" 2>/dev/null || echo 0)
    if [ "$tot" -gt 0 ] 2>/dev/null; then echo "@@S $((sz*100/tot))"; fi
    echo "@@I Terunduh $((sz/1048576)) MB"
    sleep 1
  done
  wait "$pid"
}
bebas() { df -Pk "$1" 2>/dev/null | awk 'NR==2{print int($4/1024)}'; }

echo "@@P 0 3 Memeriksa tempat penyimpanan"
echo "Membuat bundel offline. Butuh internet sebentar untuk bagian yang belum ada di HP, dan ruang kosong sekitar 3 GB."
mkdir -p "$(dirname "$OUT")" 2>/dev/null
touch "$OUT.coba" 2>/dev/null || { echo "Tidak bisa menulis ke $(dirname "$OUT"). Ketik: izin"; exit 2; }
rm -f "$OUT.coba"
b1=$(bebas "$(dirname "$OUT")"); b2=$(bebas "$HOME")
echo "Ruang kosong: tujuan ${b1:-?} MB, penyimpanan aplikasi ${b2:-?} MB"
if [ -n "$b1" ] && [ "$b1" -lt 1500 ] 2>/dev/null; then echo "Ruang kosong di tujuan kurang dari 1500 MB"; exit 2; fi
if [ -n "$b2" ] && [ "$b2" -lt 1500 ] 2>/dev/null; then echo "Ruang kosong penyimpanan aplikasi kurang dari 1500 MB"; exit 2; fi
rm -rf "$W" "$TMPZIP"; mkdir -p "$W"
pkill -f GradleDaemon 2>/dev/null || true

echo "@@P 3 8 Memasukkan bootstrap Termux"
mkdir -p "$W/bootstrap"
ln -s "$BS" "$W/bootstrap/bootstrap.zip" || gagal "Bootstrap tidak bisa dimasukkan" 1

echo "@@P 8 12 Memperbarui daftar paket"
perbarui() {
  local k st
  k=$(pkg update -y 2>&1); st=$?
  echo "$k" | tail -3
  if [ $st -eq 0 ] && ! echo "$k" | grep -q '^E:'; then return 0; fi
  echo "Mencoba cermin resmi packages.termux.dev"
  rm -f "$PREFIX/etc/apt/sources.list"
  echo "deb https://packages.termux.dev/apt/termux-main stable main" > "$PREFIX/etc/apt/sources.list"
  rm -rf "$PREFIX/var/lib/apt/lists/"*
  apt-get update
}
perbarui || gagal "Daftar paket tidak bisa diperbarui. Periksa internet" 1

echo "@@P 12 38 Mengunduh paket apt untuk bundel"
PK="python git cmake ninja aapt2 apksigner unzip zip wget curl tar xz-utils"
if dpkg -s openjdk-21 >/dev/null 2>&1 && ! dpkg -s openjdk-17 >/dev/null 2>&1; then JDK=openjdk-21; else JDK=openjdk-17; fi
if dpkg -s apktool >/dev/null 2>&1; then PK="$PK apktool"; fi
DAFTAR=$(apt-cache depends --recurse --no-recommends --no-suggests --no-conflicts --no-breaks --no-replaces --no-enhances $PK $JDK 2>/dev/null | grep '^[a-z0-9]' | sort -u)
tot=$(echo "$DAFTAR" | wc -l)
echo "Paket yang dikumpulkan: $tot, termasuk $JDK"
mkdir -p "$W/apt/archives" "$W/apt/lists"
cd "$W/apt/archives" || gagal "Folder kerja tidak bisa dibuka" 1
n=0
for p in $DAFTAR; do
  n=$((n+1))
  echo "@@S $((n*100/tot))"
  echo "@@I Paket $n dari $tot: $p"
  apt-get download "$p" > /dev/null 2>&1 || echo "Dilewati: $p"
done
cd "$HOME"
ls "$W"/apt/archives/python_*.deb > /dev/null 2>&1 || gagal "Paket python tidak terunduh. Periksa internet lalu ulangi" 1
echo "Terkumpul $(ls "$W"/apt/archives/*.deb | wc -l) berkas paket"
eval "$(apt-config shell LS Dir::State::lists/d)"
if [ -z "$LS" ] || [ ! -d "$LS" ]; then LS="$PREFIX/var/lib/apt/lists/"; fi
find "$LS" -maxdepth 1 -type f ! -name lock -exec cp -L {} "$W/apt/lists/" ";"
cp -L "$PREFIX/etc/apt/sources.list" "$W/apt/sources.list"

echo "@@P 38 60 Mengumpulkan NDK"
mkdir -p "$W/ndk"
z=$(ls -t /sdcard/Download/android-ndk-*aarch64*.tar.xz 2>/dev/null | head -1)
NDKNAMA="android-ndk-r29-aarch64"
if [ -n "$z" ]; then
  echo "Memakai NDK dari Download: $z"
  ln -s "$z" "$W/ndk/$(basename "$z")"
  NDKNAMA=$(basename "$z" .tar.xz)
else
  base="https://github.com/lzhiyong/termux-ndk/releases/download/android-ndk"
  url=""; nf=""
  ada() { curl -fsSL --connect-timeout 8 -m 12 -r 0-0 -o /dev/null "$1" > /dev/null 2>&1; }
  for px in "" https://ghfast.top/ https://gh-proxy.com/; do
    [ -n "$px" ] && echo "Mencoba lewat cermin $px"
    if ada "$px$base/android-ndk-r29-aarch64.tar.xz"; then url="$px$base/android-ndk-r29-aarch64.tar.xz"; nf="android-ndk-r29-aarch64.tar.xz"; break; fi
  done
  if [ -z "$url" ]; then
    echo "NDK tidak ditemukan otomatis. Unduh android-ndk-r29-aarch64.tar.xz dari https://github.com/lzhiyong/termux-ndk/releases ke folder Download lalu ulangi."
    gagal "NDK tidak ditemukan" 3
  fi
  echo "Mengunduh NDK dari $url"
  unduh "$W/ndk/$nf" "$url" || gagal "NDK gagal diunduh" 3
fi

echo "@@P 60 78 Mengumpulkan Android SDK"
if [ ! -d "$SDK/build-tools" ] || [ ! -d "$SDK/platforms/android-34" ]; then
  echo "Android SDK belum ada di HP, dipasang dulu"
  mkdir -p "$SDK/cmdline-tools"
  if [ ! -d "$SDK/cmdline-tools/latest" ]; then
    unduh "$TMPDIR/cmdtools.zip" "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" || gagal "Android command line tools gagal diunduh" 4
    rm -rf "$TMPDIR/cmdtoolsx"; mkdir -p "$TMPDIR/cmdtoolsx"
    unzip -q -o "$TMPDIR/cmdtools.zip" -d "$TMPDIR/cmdtoolsx" || gagal "Command line tools rusak" 4
    mv "$TMPDIR/cmdtoolsx/cmdline-tools" "$SDK/cmdline-tools/latest"
    rm -f "$TMPDIR/cmdtools.zip"; rm -rf "$TMPDIR/cmdtoolsx"
  fi
  SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
  yes | "$SDKM" --sdk_root="$SDK" --licenses > /dev/null 2>&1 || true
  "$SDKM" --sdk_root="$SDK" "platform-tools" "platforms;android-34" "build-tools;34.0.0" || gagal "Android SDK gagal dipasang" 4
fi
mkdir -p "$W/sdk"
echo "Mengemas Android SDK"
tar -C "$SDK" --exclude=./ndk --exclude=./.temp -czf "$W/sdk/sdk-paket.tar.gz" . || gagal "SDK gagal dikemas" 4

echo "@@P 78 92 Mengumpulkan Gradle"
mkdir -p "$W/gradle"
for d in "$HOME/.gradle-dist"/gradle-*-bin; do
  [ -x "$d/bin/gradle" ] || continue
  nm=$(basename "$d")
  echo "Mengemas $nm"
  tar -C "$HOME/.gradle-dist" -czf "$W/gradle/$nm.tar.gz" "$nm" || gagal "$nm gagal dikemas" 1
done
if [ -d "$HOME/.gradle/wrapper/dists" ]; then
  echo "Mengemas Gradle dari gradlew proyek"
  tar -C "$HOME/.gradle" -czf "$W/gradle/pembungkus.tar.gz" wrapper/dists || echo "Peringatan: gradlew gagal dikemas"
fi
if [ "$PUSTAKA" != "tanpa" ] && [ -d "$HOME/.gradle/caches/modules-2" ]; then
  echo "Mengemas pustaka Gradle yang sudah diunduh proyek"
  tar -C "$HOME/.gradle" --exclude='*.lock' -czf "$W/gradle/pustaka.tar.gz" caches/modules-2 || echo "Peringatan: pustaka Gradle gagal dikemas"
fi

echo "@@P 92 99 Menyatukan semuanya menjadi satu zip"
{
  echo "format=1"
  echo "dibuat=$(date '+%Y-%m-%d %H:%M')"
  echo "arsitektur=$(uname -m)"
  echo "ndk=$NDKNAMA"
  echo "jdk=$JDK"
} > "$W/manifest.txt"
(cd "$W" && zip -0 -q -r "$TMPZIP" manifest.txt bootstrap apt ndk sdk gradle) || gagal "Gagal membuat zip. Ruang penyimpanan mungkin kurang" 2
rm -rf "$W"
mv -f "$TMPZIP" "$OUT" || gagal "Gagal memindahkan bundel ke $OUT" 2
echo "Bundel selesai: $OUT"
echo "@@P 99 100 Selesai"
exit 0
""";
}
