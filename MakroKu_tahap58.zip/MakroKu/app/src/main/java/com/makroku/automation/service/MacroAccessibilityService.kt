package com.makroku.automation.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.makroku.automation.MakroApp
import com.makroku.automation.model.TriggerEvent

/**
 * Mendeteksi aplikasi di depan (pemicu "Aplikasi dibuka"), tombol volume (pemicu "Tombol volume"),
 * dan menjalankan aksi layar: ketuk teks, gulir, isi kolom teks, baca teks layar.
 * Isi layar hanya dibaca saat aksi layar dijalankan; tidak disimpan atau dikirim ke mana pun.
 */
class MacroAccessibilityService : AccessibilityService() {
    private var lastPkg: String? = null
    private val downAt = HashMap<String, Long>()

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
        @Volatile var currentPkg: String = ""

        /** Tombol volume ("up"/"down") yang dipakai makro aktif, dan yang ditahan agar volume tidak berubah. */
        @Volatile var wantedKeys: Set<String> = emptySet()
        @Volatile var blockedKeys: Set<String> = emptySet()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPkg || pkg == packageName || pkg == "com.android.systemui") return
        val sebelumnya = lastPkg
        lastPkg = pkg
        currentPkg = pkg
        if (!sebelumnya.isNullOrBlank()) {
            (applicationContext as MakroApp).engine.dispatch(TriggerEvent("app_closed", mapOf("app_pkg" to sebelumnya)))
        }
        (applicationContext as MakroApp).engine.dispatch(TriggerEvent("app", mapOf("app_pkg" to pkg)))
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val name = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> "up"
            KeyEvent.KEYCODE_VOLUME_DOWN -> "down"
            else -> return false
        }
        if (name !in wantedKeys) return false
        val block = name in blockedKeys
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) downAt[name] = event.eventTime
        } else if (event.action == KeyEvent.ACTION_UP) {
            val start = downAt.remove(name) ?: return block
            val press = if (event.eventTime - start >= 600) "long" else "short"
            (applicationContext as MakroApp).engine.dispatch(
                TriggerEvent("volume_key", mapOf("key" to name, "press" to press)),
            )
        }
        return block
    }

    override fun onInterrupt() {}

    // ───────────── Aksi layar ─────────────

    /** Ketuk node yang teksnya/deskripsinya mengandung [text]; naik ke induk yang bisa diketuk. */
    fun clickByText(text: String, longClick: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = root.findAccessibilityNodeInfosByText(text) ?: return false
        for (n in found) {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 8) {
                val can = cur.isEnabled && (if (longClick) cur.isLongClickable else cur.isClickable)
                if (can) {
                    val act = if (longClick) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
                    if (cur.performAction(act)) return true
                    break
                }
                cur = cur.parent
                depth++
            }
        }
        return false
    }

    /** Ketuk elemen ber-ID [viewId] (bentuk lengkap "paket:id/nama"); naik ke induk yang bisa diketuk. */
    fun clickById(viewId: String, longClick: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = root.findAccessibilityNodeInfosByViewId(viewId) ?: return false
        for (n in found) {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 8) {
                val can = cur.isEnabled && (if (longClick) cur.isLongClickable else cur.isClickable)
                if (can) {
                    val act = if (longClick) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
                    if (cur.performAction(act)) return true
                    break
                }
                cur = cur.parent
                depth++
            }
        }
        return false
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, budget: IntArray): AccessibilityNodeInfo? {
        if (n == null || budget[0]-- <= 0) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i), budget)
            if (r != null) return r
        }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val node = findScrollable(rootInActiveWindow, intArrayOf(3000)) ?: return false
        val act = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return node.performAction(act)
    }

    fun setFocusedText(text: String, append: Boolean): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val base = if (append) node.text?.toString().orEmpty() else ""
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Semua teks yang terlihat di layar, satu baris per elemen. */
    fun screenText(max: Int): String {
        val sb = StringBuilder()
        val budget = intArrayOf(3000)
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || budget[0]-- <= 0 || sb.length >= max) return
            if (n.isVisibleToUser) {
                val s = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
                if (s.isNotEmpty()) sb.append(s).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().trim().take(max)
    }
}
