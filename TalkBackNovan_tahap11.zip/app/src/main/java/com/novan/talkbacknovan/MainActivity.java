package com.novan.talkbacknovan;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/** Layar utama: daftar menu pengaturan, seperti layar utama JieShuo. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("TalkBack Novan");
        if (getActionBar() != null) getActionBar().setSubtitle("Tahap 11");

        final String[][] menu = SettingsActivity.MENU_UTAMA;
        String[] nama = new String[menu.length];
        for (int i = 0; i < menu.length; i++) nama[i] = menu[i][1];

        final float d = getResources().getDisplayMetrics().density;
        ListView daftar = new ListView(this);
        daftar.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nama) {
            @Override
            public View getView(int posisi, View lama, ViewGroup induk) {
                TextView t = (TextView) super.getView(posisi, lama, induk);
                t.setTextSize(20);
                t.setMinHeight((int) (68 * d));
                t.setPadding((int) (16 * d), 0, (int) (16 * d), 0);
                return t;
            }
        });
        daftar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                String halaman = menu[pos][0];
                if (halaman.equals("ekstensi")) {
                    startActivity(new Intent(MainActivity.this, PluginActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class)
                            .putExtra(SettingsActivity.EXTRA_HALAMAN, halaman));
                }
            }
        });
        setContentView(daftar);
    }

    static boolean layananAktif(Context c) {
        String aktif = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (aktif == null) return false;
        ComponentName cn = new ComponentName(c, TalkBackNovanService.class);
        return aktif.contains(cn.flattenToString()) || aktif.contains(cn.flattenToShortString());
    }
}
