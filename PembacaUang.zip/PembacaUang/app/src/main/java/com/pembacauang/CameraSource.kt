package com.pembacauang

import android.app.Activity
import android.hardware.Camera
import android.view.Surface
import android.view.SurfaceHolder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Pembungkus Camera v1 (android.hardware.Camera).
 *
 * API ini lama (deprecated) tetapi masih didukung semua versi Android, dari
 * Android 5 sampai yang terbaru, termasuk HP lama yang tidak mendukung Camera2 penuh.
 *
 *  - kamera belakang, pratinjau mendekati 1152x648 (0x480 x 0x288), 30 fps;
 *  - fokus "continuous-picture" bila didukung;
 *  - senter (torch) menyala bila perangkat mendukung;
 *  - frame NV21 dikirim ke [onFrame] satu per satu (frame lain dibuang saat OCR masih berjalan).
 */
@Suppress("DEPRECATION")
class CameraSource(
    private val activity: Activity,
    private val useFlash: Boolean = true,
    private val onFrame: (data: ByteArray, width: Int, height: Int, rotation: Int, release: () -> Unit) -> Unit,
) {
    private companion object {
        const val REQUESTED_WIDTH = 0x480 // 1152
        const val REQUESTED_HEIGHT = 0x288 // 648
    }

    private var camera: Camera? = null
    var previewWidth = 0
        private set
    var previewHeight = 0
        private set
    private var rotation = 0
    private val busy = AtomicBoolean(false)
    /** true bila torch benar-benar dinyalakan. */
    var torchOn = false
        private set

    /** Buka kamera dan mulai pratinjau di [holder]. Melempar Exception bila gagal. */
    @Synchronized
    fun start(holder: SurfaceHolder) {
        if (camera != null) return
        val id = backCameraId()
        val cam = Camera.open(id)
        try {
            val params = cam.parameters
            val size = chooseSize(params.supportedPreviewSizes, REQUESTED_WIDTH, REQUESTED_HEIGHT)
            params.setPreviewSize(size.width, size.height)
            previewWidth = size.width
            previewHeight = size.height

            chooseFpsRange(params)?.let { params.setPreviewFpsRange(it[0], it[1]) }
            params.previewFormat = android.graphics.ImageFormat.NV21

            val focusModes = params.supportedFocusModes ?: emptyList<String>()
            if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                params.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
            }

            val flashModes = params.supportedFlashModes
            torchOn = useFlash && flashModes != null &&
                flashModes.contains(Camera.Parameters.FLASH_MODE_TORCH)
            if (torchOn) params.flashMode = Camera.Parameters.FLASH_MODE_TORCH

            cam.parameters = params

            val info = Camera.CameraInfo()
            Camera.getCameraInfo(id, info)
            val degrees = when (activity.windowManager.defaultDisplay.rotation) {
                Surface.ROTATION_90 -> 90
                Surface.ROTATION_180 -> 180
                Surface.ROTATION_270 -> 270
                else -> 0
            }
            // Kamera belakang
            rotation = (info.orientation - degrees + 360) % 360
            cam.setDisplayOrientation(rotation)

            // Dua buffer: satu dipakai OCR, satu menerima frame berikutnya.
            val bufferSize = previewWidth * previewHeight *
                android.graphics.ImageFormat.getBitsPerPixel(android.graphics.ImageFormat.NV21) / 8 + 1
            cam.addCallbackBuffer(ByteArray(bufferSize))
            cam.addCallbackBuffer(ByteArray(bufferSize))
            cam.setPreviewCallbackWithBuffer { data, c -> handleFrame(data, c) }

            cam.setPreviewDisplay(holder)
            // Wajib diisi sebelum startPreview: frame pertama bisa tiba segera setelahnya.
            camera = cam
            cam.startPreview()
        } catch (e: Exception) {
            camera = null
            try {
                cam.release()
            } catch (_: Exception) {
            }
            throw e
        }
    }

    private fun handleFrame(data: ByteArray?, cam: Camera) {
        if (data == null) return
        if (camera !== cam) return
        if (!busy.compareAndSet(false, true)) {
            returnBuffer(data, cam)
            return
        }
        onFrame(data, previewWidth, previewHeight, rotation) {
            returnBuffer(data, cam)
            busy.set(false)
        }
    }

    private fun returnBuffer(data: ByteArray, cam: Camera) {
        try {
            if (camera === cam) cam.addCallbackBuffer(data)
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun stop() {
        val cam = camera ?: return
        camera = null
        try {
            cam.setPreviewCallbackWithBuffer(null)
            cam.stopPreview()
        } catch (_: Exception) {
        }
        try {
            cam.release()
        } catch (_: Exception) {
        }
        busy.set(false)
        torchOn = false
    }

    val isStarted: Boolean get() = camera != null

    // ---- Pemilihan pengaturan ---------------------------------------------

    private fun backCameraId(): Int {
        val info = Camera.CameraInfo()
        for (i in 0 until Camera.getNumberOfCameras()) {
            Camera.getCameraInfo(i, info)
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) return i
        }
        return 0
    }

    /** Ukuran pratinjau dengan selisih lebar + tinggi terkecil terhadap yang diminta. */
    private fun chooseSize(sizes: List<Camera.Size>, reqW: Int, reqH: Int): Camera.Size =
        sizes.minByOrNull { abs(it.width - reqW) + abs(it.height - reqH) } ?: sizes.first()

    /** Rentang fps yang mencakup 30 fps (utamakan rentang tetap), atau null bila tidak ada. */
    private fun chooseFpsRange(params: Camera.Parameters): IntArray? {
        val target = 30_000
        var best: IntArray? = null
        var bestScore = Int.MAX_VALUE
        for (range in params.supportedPreviewFpsRange ?: return null) {
            val lo = range[Camera.Parameters.PREVIEW_FPS_MIN_INDEX]
            val hi = range[Camera.Parameters.PREVIEW_FPS_MAX_INDEX]
            if (target < lo || target > hi) continue
            val score = (hi - lo) + abs(hi - target)
            if (score < bestScore) {
                bestScore = score
                best = range
            }
        }
        return best
    }
}
