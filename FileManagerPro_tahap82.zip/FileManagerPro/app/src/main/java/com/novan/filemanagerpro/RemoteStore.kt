package com.novan.filemanagerpro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Lokasi jarak jauh tersimpan. [type]: ftp, sftp, smb, webdav, webdavs. Untuk smb, [path] berbentuk
 * "namaShare" atau "namaShare/subfolder". Untuk ftp dan sftp, [path] adalah folder awal.
 */
class RemoteConfig(
    val id: String,
    var name: String,
    var type: String,
    var host: String,
    var port: Int,
    var user: String,
    var pass: String,
    var path: String
) {
    fun typeLabel(): String = when (type) {
        "webdav" -> "WebDAV"
        "webdavs" -> "WebDAV (HTTPS)"
        else -> type.uppercase()
    }
}

object RemoteStore {
    private fun p(c: Context) = c.getSharedPreferences("remotes", Context.MODE_PRIVATE)

    fun newId(): String = UUID.randomUUID().toString()

    fun defaultPort(type: String) = when (type) {
        "sftp" -> 22
        "smb" -> 445
        "webdav" -> 80
        "webdavs" -> 443
        else -> 21
    }

    @Synchronized
    fun all(c: Context): MutableList<RemoteConfig> {
        val out = ArrayList<RemoteConfig>()
        try {
            val arr = JSONArray(p(c).getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    RemoteConfig(
                        o.getString("id"), o.getString("name"), o.getString("type"),
                        o.getString("host"), o.optInt("port", 0), o.optString("user"),
                        Secret.decrypt(o.optString("pass")) ?: "", o.optString("path", "/")
                    )
                )
            }
        } catch (e: Exception) {
            // data rusak: abaikan
        }
        return out
    }

    fun get(c: Context, id: String): RemoteConfig? = all(c).firstOrNull { it.id == id }

    @Synchronized
    fun save(c: Context, cfg: RemoteConfig) {
        val list = all(c)
        val idx = list.indexOfFirst { it.id == cfg.id }
        if (idx >= 0) list[idx] = cfg else list.add(cfg)
        write(c, list)
    }

    @Synchronized
    fun delete(c: Context, id: String) {
        write(c, all(c).filter { it.id != id })
    }

    private fun write(c: Context, list: List<RemoteConfig>) {
        val arr = JSONArray()
        for (r in list) {
            arr.put(
                JSONObject().put("id", r.id).put("name", r.name).put("type", r.type)
                    .put("host", r.host).put("port", r.port).put("user", r.user)
                    .put("pass", if (r.pass.isEmpty()) "" else Secret.encrypt(r.pass))
                    .put("path", r.path)
            )
        }
        p(c).edit().putString("list", arr.toString()).apply()
    }
}
