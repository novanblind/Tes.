package com.novan.filemanagerpro

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.navigation.NavigationView
import java.io.File

/**
 * Satu kotak di layar awal. [tint] bernilai 0 jika ikon sudah berwarna sendiri.
 * [boxed] true: ikon kecil di dalam kotak putih membulat; false: ikon besar tanpa kotak.
 */
class HomeItem(
    val iconRes: Int,
    val tint: Int,
    val boxed: Boolean,
    val name: String,
    val info: String,
    val spoken: String,
    val tag: String
)

class HomeAdapter(
    private val onClick: (HomeItem) -> Unit,
    private val onLong: (HomeItem) -> Unit = {}
) :
    RecyclerView.Adapter<HomeAdapter.VH>() {

    private var items: List<HomeItem> = emptyList()

    fun submit(list: List<HomeItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val box: FrameLayout = v.findViewById(R.id.iconBox)
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val info: TextView = v.findViewById(R.id.info)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_home, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val d = h.itemView.resources.displayMetrics.density
        h.icon.setImageResource(item.iconRes)
        if (item.tint != 0) h.icon.setColorFilter(item.tint) else h.icon.clearColorFilter()
        val size = ((if (item.boxed) 32 else 64) * d).toInt()
        h.icon.layoutParams.width = size
        h.icon.layoutParams.height = size
        h.box.setBackgroundResource(if (item.boxed) R.drawable.bg_home_icon else 0)
        h.name.text = item.name
        h.info.text = item.info
        h.info.visibility = if (item.info.isEmpty()) View.GONE else View.VISIBLE
        h.itemView.contentDescription =
            if (item.spoken.isEmpty()) item.name else "${item.name}, ${item.spoken}"
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnLongClickListener { onLong(item); true }
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var homeAdapter: HomeAdapter
    private lateinit var permissionBox: View
    private lateinit var drawer: DrawerLayout
    private lateinit var toggle: ActionBarDrawerToggle
    private val volumeLabels = LinkedHashMap<String, String>()

    /** Keterangan di bawah nama: tag -> (teks tampil, teks ucapan). */
    private val infos = HashMap<String, Pair<String, String>>()
    private var mini: MiniPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = getString(R.string.app_name)

        drawer = findViewById(R.id.drawer)
        toggle = ActionBarDrawerToggle(this, drawer, R.string.drawer_open, R.string.drawer_close)
        drawer.addDrawerListener(toggle)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<NavigationView>(R.id.nav).setNavigationItemSelectedListener { mi ->
            drawer.closeDrawer(GravityCompat.START)
            when (mi.itemId) {
                R.id.nav_system -> go("vol:/", getString(R.string.system_storage))
                R.id.nav_bookmarks -> go("bm")
                R.id.nav_trash -> go("trash")
                R.id.nav_search -> go("search")
                R.id.nav_dup -> go("dup")
                R.id.nav_clean -> go("clean")
                R.id.nav_analyze -> openAnalyze()
                R.id.nav_android_data -> go("androiddata")
                R.id.nav_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        permissionBox = findViewById(R.id.permissionBox)
        findViewById<Button>(R.id.btnGrant).setOnClickListener { requestAccess() }

        homeAdapter = HomeAdapter(onClick = { go(it.tag, it.name) }, onLong = { onHomeLong(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        val dp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        list.layoutManager = GridLayoutManager(this, (dp / 110).toInt().coerceAtLeast(3))
        list.adapter = homeAdapter
        val swipe = findViewById<SwipeRefreshLayout>(R.id.swipe)
        swipe.setOnRefreshListener {
            onResume()
            swipe.isRefreshing = false
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        toggle.syncState()
    }

    private val mediaReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (isFinishing || isDestroyed) return
            val act = intent?.action
            // Flashdisk baru dicolok: sistem butuh beberapa detik sebelum memasangnya,
            // jadi daftar disegarkan lagi sesudah jeda pendek.
            if (act == UsbManager.ACTION_USB_DEVICE_ATTACHED || act == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                if (!Prefs.usbConnect(this@MainActivity)) return
                for (delay in longArrayOf(1500, 4000, 8000)) {
                    window.decorView.postDelayed({ refreshVolumes() }, delay)
                }
                return
            }
            val msg = when (act) {
                Intent.ACTION_MEDIA_MOUNTED -> getString(R.string.usb_mounted)
                Intent.ACTION_MEDIA_REMOVED, Intent.ACTION_MEDIA_BAD_REMOVAL -> getString(R.string.usb_removed)
                else -> null
            }
            refreshVolumes()
            if (msg != null) {
                com.google.android.material.snackbar.Snackbar.make(
                    findViewById(android.R.id.content), msg, com.google.android.material.snackbar.Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun refreshVolumes() {
        if (isFinishing || isDestroyed) return
        if (!Access.hasAccess(this)) return
        val before = volumeLabels.keys.toList()
        loadVolumes()
        render()
        if (before != volumeLabels.keys.toList()) loadStats()
    }

    /** Tekan lama kotak penyimpanan eksternal (SD atau USB): tawarkan melepas dengan aman. */
    private fun onHomeLong(it: HomeItem) {
        if (!it.tag.startsWith("vol:")) return
        val path = it.tag.removePrefix("vol:")
        val first = volumeLabels.keys.firstOrNull()
        if (path == first || !volumeLabels.containsKey(path)) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(it.name)
            .setMessage(R.string.eject_message)
            .setPositiveButton(R.string.eject_open_settings) { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    override fun onStart() {
        super.onStart()
        val f = android.content.IntentFilter().apply {
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_REMOVED)
            addAction(Intent.ACTION_MEDIA_BAD_REMOVAL)
            addAction(Intent.ACTION_MEDIA_EJECT)
            addDataScheme("file")
        }
        val usbFilter = android.content.IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(mediaReceiver, f, android.content.Context.RECEIVER_EXPORTED)
                registerReceiver(mediaReceiver, usbFilter, android.content.Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(mediaReceiver, f)
                registerReceiver(mediaReceiver, usbFilter)
            }
        } catch (e: Exception) {
            // abaikan
        }
        val m = mini ?: MiniPlayer(this, findViewById(R.id.miniPlayer)).also { mini = it }
        m.start()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(mediaReceiver) } catch (e: Exception) { }
        mini?.stop()
    }

    override fun onResume() {
        super.onResume()
        findViewById<NavigationView>(R.id.nav).menu.findItem(R.id.nav_system)?.isVisible =
            Prefs.showSystem(this)
        val ok = Access.hasAccess(this)
        permissionBox.visibility = if (ok) View.GONE else View.VISIBLE
        if (ok) {
            loadVolumes()
            render()
            loadStats()
        } else {
            homeAdapter.submit(emptyList())
        }
    }

    // ---------- navigasi ----------

    private fun go(tag: String, name: String = "") {
        when {
            tag.startsWith("vol:") -> {
                val volPath = tag.removePrefix("vol:")
                val dlPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                startActivity(
                    Intent(this, BrowserActivity::class.java)
                        .putExtra(BrowserActivity.EXTRA_ROOT, volPath)
                        .putExtra(BrowserActivity.EXTRA_TITLE, name)
                        .putExtra(BrowserActivity.EXTRA_NEWEST, volPath == dlPath)
                )
            }
            tag.startsWith("lib:") -> startActivity(
                Intent(this, LibraryActivity::class.java)
                    .putExtra(LibraryActivity.EXTRA_KIND, tag.removePrefix("lib:"))
            )
            tag == "search" -> startActivity(Intent(this, SearchActivity::class.java))
            tag == "clean" -> startActivity(Intent(this, CleanActivity::class.java))
            tag == "remote" -> startActivity(Intent(this, RemotesActivity::class.java))
            tag == "net" -> startActivity(Intent(this, NetworkActivity::class.java))
            tag == "apps" -> startActivity(Intent(this, AppsActivity::class.java))
            tag == "sounds" -> startActivity(Intent(this, SystemSoundsActivity::class.java))
            tag == "bm" -> startActivity(Intent(this, BookmarksActivity::class.java))
            tag == "dup" -> startActivity(Intent(this, DuplicatesActivity::class.java))
            tag == "trash" -> startActivity(Intent(this, TrashActivity::class.java))
            tag == "androiddata" && Build.VERSION.SDK_INT < 30 -> startActivity(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, SystemFiles.androidData().absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.android_data_title))
            )
            tag == "androiddata" -> SystemFiles.openOrExplain(this, SystemFiles.androidData()) {
                com.google.android.material.snackbar.Snackbar.make(
                    findViewById(android.R.id.content), it,
                    com.google.android.material.snackbar.Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun openAnalyze() {
        if (volumeLabels.isEmpty()) return
        if (volumeLabels.size == 1) { startAnalyze(volumeLabels.keys.first()); return }
        // Ada kartu memori: pilih penyimpanan yang mau dianalisis.
        val paths = volumeLabels.keys.toList()
        val names = paths.map { volumeLabels[it] ?: it }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.analyze)
            .setItems(names) { _, i -> startAnalyze(paths[i]) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun startAnalyze(path: String) {
        startActivity(
            Intent(this, AnalyzeActivity::class.java)
                .putExtra(AnalyzeActivity.EXTRA_ROOT, path)
                .putExtra(AnalyzeActivity.EXTRA_TITLE, volumeLabels[path] ?: "")
        )
    }

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                1
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        onResume()
    }

    // ---------- isi kotak ----------

    private fun col(id: Int) = getColor(id)

    private fun loadVolumes() {
        volumeLabels.clear()
        for (v in Volumes.list(this)) volumeLabels[v.root.absolutePath] = v.label
    }

    private fun item(
        icon: Int, tint: Int, boxed: Boolean, name: String, tag: String
    ): HomeItem {
        val inf = infos[tag]
        return HomeItem(icon, tint, boxed, name, inf?.first ?: "", inf?.second ?: "", tag)
    }

    private fun render() {
        val out = ArrayList<HomeItem>()
        var first = true
        for ((path, label) in volumeLabels) {
            val root = File(path)
            val total = root.totalSpace
            val used = (total - root.freeSpace).coerceAtLeast(0)
            val u = Formatter.formatFileSize(this, used)
            val t = Formatter.formatFileSize(this, total)
            out.add(
                HomeItem(
                    if (first) R.drawable.ic_home_drive else R.drawable.ic_home_sd, 0, false,
                    label, getString(R.string.info_used_total, u, t),
                    getString(R.string.spoken_used_total, u, t), "vol:$path"
                )
            )
            first = false
        }
        if (Prefs.showSystem(this)) {
            val sys = File("/")
            val sTotal = sys.totalSpace
            val sUsed = (sTotal - sys.freeSpace).coerceAtLeast(0)
            val su = Formatter.formatFileSize(this, sUsed)
            val st = Formatter.formatFileSize(this, sTotal)
            out.add(
                HomeItem(
                    R.drawable.ic_home_system, 0, false,
                    getString(R.string.system_storage), getString(R.string.info_used_total, su, st),
                    getString(R.string.spoken_used_total, su, st), "vol:/"
                )
            )
        }
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (dl.exists()) {
            out.add(item(R.drawable.ic_home_downloads, 0, false,
                getString(R.string.home_downloads), "vol:" + dl.absolutePath))
        }
        out.add(item(R.drawable.ic_image, col(R.color.shape_image), true,
            getString(R.string.cat_images), "lib:${LibraryActivity.IMAGES}"))
        out.add(item(R.drawable.ic_audio, col(R.color.shape_music), true,
            getString(R.string.cat_audio), "lib:${LibraryActivity.AUDIO}"))
        out.add(item(R.drawable.ic_video, col(R.color.shape_video), true,
            getString(R.string.cat_video), "lib:${LibraryActivity.VIDEO}"))
        out.add(item(R.drawable.ic_file, col(R.color.shape_document), true,
            getString(R.string.home_docs), "lib:${LibraryActivity.DOCS}"))
        out.add(item(R.drawable.ic_archive, col(R.color.shape_archive), true,
            getString(R.string.home_zips), "lib:${LibraryActivity.ZIPS}"))
        out.add(item(R.drawable.ic_apk, col(R.color.shape_app), true,
            getString(R.string.home_apps), "apps"))
        out.add(item(R.drawable.ic_audio, col(R.color.shape_music), true,
            getString(R.string.snd_title), "sounds"))
        out.add(item(R.drawable.ic_clock, col(R.color.shape_new_files), true,
            getString(R.string.home_new_files), "lib:${LibraryActivity.RECENT}"))
        out.add(HomeItem(R.drawable.ic_folder, 0, true,
            getString(R.string.android_data_title), getString(R.string.android_data_detail),
            getString(R.string.android_data_detail), "androiddata"))
        out.add(item(R.drawable.ic_home_remote, 0, true,
            getString(R.string.home_remote), "remote"))
        out.add(item(R.drawable.ic_home_network, 0, true,
            getString(R.string.home_network), "net"))
        homeAdapter.submit(out)
    }

    /** Hitung ukuran dan jumlah berkas per jenis di latar belakang, lalu segarkan kotak. */
    private fun loadStats() {
        Thread {
            val map = HashMap<String, Pair<String, String>>()
            fun put(tag: String, size: Long, count: Int) {
                val s = Formatter.formatFileSize(this, size)
                map[tag] = getString(R.string.info_size_count, s, count) to
                    getString(R.string.spoken_size_count, s, count)
            }
            for (kind in listOf(
                LibraryActivity.IMAGES, LibraryActivity.AUDIO, LibraryActivity.VIDEO,
                LibraryActivity.DOCS, LibraryActivity.ZIPS, LibraryActivity.RECENT
            )) {
                val (sz, n) = LibraryActivity.stats(this, kind)
                put("lib:$kind", sz, n)
            }
            val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val (dsz, dn) = LibraryActivity.stats(this, LibraryActivity.DOWNLOADS)
            put("vol:" + dl.absolutePath, dsz, dn)
            try {
                var size = 0L
                var count = 0
                for (ai in packageManager.getInstalledApplications(0)) {
                    if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
                    size += File(ai.sourceDir).length()
                    count++
                }
                put("apps", size, count)
            } catch (e: Exception) {
                // abaikan
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                infos.clear()
                infos.putAll(map)
                render()
            }
        }.start()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (toggle.onOptionsItemSelected(item)) true else when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_analyze -> {
                openAnalyze()
                true
            }
            R.id.action_refresh -> {
                onResume()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
}
