package com.novan.audiolabnovan.gemini;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Tahap Gemini: meminta suara ke Gemini bagian demi bagian dan menulis hasilnya sebagai PCM 16-bit mono mentah.
 * Logikanya dipindahkan dari GenerateService aplikasi Voice note Suara Gemini (v1.0.12); penyandian dan efek
 * dikerjakan sesudahnya oleh FFmpeg di AudioLab.
 */
public final class GeminiJob {
    private GeminiJob() {}

    public interface Progress {
        /** Dipanggil dari thread kerja. [persen] 0 sampai 100. */
        void status(String msg, int persen);
    }

    public static final class Params {
        public String text = "";
        public boolean multi = false;
        public int voice1 = 0, voice2 = 1;
        public int logat1 = 0, logat2 = 0;
        public int vibe1 = 0, vibe2 = 0;
        public String name1 = "Suara1", name2 = "Suara2";
    }

    public static final class Result {
        public boolean ok = false;
        public boolean cancelled = false;
        public boolean allQuota = false;
        public String message = "";
        public int rate = 24000;
    }

    private static final class Cancelled extends Exception { }

    private static void sleepCancel(long ms, AtomicBoolean cancel) throws Cancelled, InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (cancel.get()) throw new Cancelled();
            Thread.sleep(Math.min(200, Math.max(1, end - System.currentTimeMillis())));
        }
    }

    public static Result run(Context c, Params p, File pcmOut, Progress prog, AtomicBoolean cancel) {
        Result res = new Result();
        boolean allQuota = false;
        try {
            String apiKey = GeminiStore.getKey(c);
            if (apiKey.isEmpty()) throw new IOException("Kunci API Gemini belum dimasukkan.");

            String text = p.text == null ? "" : p.text;
            boolean multi = p.multi;
            String name1 = p.name1 == null ? "Suara1" : p.name1;
            String name2 = p.name2 == null ? "Suara2" : p.name2;
            String voice1 = Data.VOICE_KEYS[Math.max(0, Math.min(p.voice1, Data.VOICE_KEYS.length - 1))];
            String voice2 = Data.VOICE_KEYS[Math.max(0, Math.min(p.voice2, Data.VOICE_KEYS.length - 1))];
            int l1 = p.logat1, l2 = p.logat2, e1 = p.vibe1, e2 = p.vibe2;

            final String style1 = GeminiClient.styleOf(l1, e1);
            final String style2 = GeminiClient.styleOf(l2, e2);
            List<String> modelList = Models.ordered(c);
            String chosen = GeminiStore.prefs(c).getString("last_model_name", "");
            if (!chosen.isEmpty() && modelList.contains(chosen)) {
                modelList = Collections.singletonList(chosen);
            }
            final List<String> models = modelList;

            String prefix;
            List<String> chunks;
            if (multi) {
                prefix = GeminiClient.buildMultiInstructionPrefix(name1, name2, l1, e1, l2, e2);
                List<GeminiClient.Item> items = GeminiClient.parseMultiScript(text, name1, name2);
                if (items.isEmpty()) throw new IOException("Naskah percakapan kosong.");
                chunks = GeminiClient.splitMultiChunks(items, GeminiClient.MAX_CHARS);
            } else {
                prefix = GeminiClient.buildInstructionPrefix(l1, e1);
                chunks = GeminiClient.splitTextIntoChunks(text, GeminiClient.MAX_CHARS);
            }
            if (chunks.isEmpty()) throw new IOException("Naskah kosong.");

            int rate = 0;
            int total = chunks.size();
            FileOutputStream fos = new FileOutputStream(pcmOut);
            try {
                for (int i = 0; i < total; i++) {
                    if (cancel.get()) throw new Cancelled();
                    if (i > 0) sleepCancel(1500, cancel);
                    prog.status("Gemini membuat suara, bagian " + (i + 1) + " dari " + total, i * 100 / total);

                    boolean ok = false;
                    String errMsg = "";
                    int quotaModels = 0;
                    boolean keyBad = false;

                    outer:
                    for (String model : models) {
                        boolean verbatim = GeminiClient.isVerbatimModel(model);
                        for (int attempt = 1; attempt <= 3; attempt++) {
                            if (cancel.get()) throw new Cancelled();
                            if (attempt > 1) sleepCancel(2500, cancel);
                            GeminiClient.Result r;
                            try {
                                r = GeminiClient.request(apiKey, model,
                                        GeminiClient.buildParts(model, chunks.get(i), multi, prefix, name1, name2, style1, style2),
                                        GeminiClient.buildSpeech(multi, verbatim, name1, voice1, name2, voice2));
                            } catch (Exception ex) {
                                r = new GeminiClient.Result();
                                r.status = GeminiClient.SKIP;
                                r.msg = "Gagal menyusun permintaan: " + ex;
                            }
                            if (r.status == GeminiClient.OK) {
                                byte[] part = r.pcm;
                                // Model 3.8 ke atas: buang desis/derau di ujung, lalu beri jeda hening 200 md antarbagian.
                                if (verbatim) part = PcmCleaner.cleanTail(part, r.sampleRate, 200);
                                if (rate == 0) rate = r.sampleRate;
                                fos.write(part);
                                ok = true;
                                break outer;
                            } else if (r.status == GeminiClient.QUOTA) {
                                quotaModels++;
                                errMsg = r.msg;
                                break; // lanjut ke model berikutnya
                            } else if (r.status == GeminiClient.BADKEY) {
                                keyBad = true;
                                errMsg = "Kunci API tidak valid. " + r.msg;
                                break outer;
                            } else if (r.status == GeminiClient.SKIP) {
                                errMsg = r.msg;
                                break; // model ini tidak mendukung permintaan: langsung model berikutnya
                            } else {
                                errMsg = r.msg;
                            }
                        }
                    }

                    if (!ok) {
                        if (quotaModels >= models.size() && !keyBad) allQuota = true;
                        throw new IOException(errMsg.isEmpty()
                                ? ("Gagal pada bagian ke-" + (i + 1) + " dari " + total)
                                : errMsg);
                    }
                }
                fos.flush();
            } finally {
                try { fos.close(); } catch (Exception ignored) { }
            }
            if (pcmOut.length() < 2) throw new IOException("Data audio kosong.");
            res.ok = true;
            res.rate = rate > 0 ? rate : 24000;
            prog.status("Suara Gemini selesai dibuat", 100);
        } catch (Cancelled e) {
            res.cancelled = true;
            res.message = "Dibatalkan.";
        } catch (Exception e) {
            if (allQuota) {
                res.allQuota = true;
                res.message = "Batas kuota harian untuk seluruh model Gemini yang dicoba pada kunci API Anda telah habis. Silakan ganti dengan kunci API baru.";
            } else {
                res.message = "Gagal menghasilkan suara: " + e.getMessage();
            }
        }
        if (!res.ok && pcmOut.exists()) {
            //noinspection ResultOfMethodCallIgnored
            pcmOut.delete();
        }
        return res;
    }
}
