package com.makroku.automation.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.makroku.automation.model.*
import com.makroku.automation.service.AlarmReceiver
import java.util.Calendar

/** Menjadwalkan pemicu waktu & interval lewat AlarmManager. */
class Scheduler(private val ctx: Context) {
    private val am = ctx.getSystemService(AlarmManager::class.java)
    private val prefs = ctx.getSharedPreferences("scheduler", Context.MODE_PRIVATE)

    private fun code(macroId: Long, idx: Int) = ((macroId % 100_000).toInt()) * 100 + idx

    private fun pi(macroId: Long, idx: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code(macroId, idx),
            Intent(ctx, AlarmReceiver::class.java).putExtra("macroId", macroId).putExtra("idx", idx),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    @Synchronized
    fun reschedule(macros: List<Macro>) {
        // batalkan semua alarm lama
        prefs.getStringSet("codes", emptySet())!!.forEach { c ->
            val rc = c.toInt()
            val p = PendingIntent.getBroadcast(
                ctx, rc, Intent(ctx, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
            )
            if (p != null) am.cancel(p)
        }
        val codes = mutableSetOf<String>()
        macros.filter { it.enabled }.forEach { m ->
            m.triggers.forEachIndexed { i, t ->
                if (scheduleOne(m, i, t)) {
                    codes += code(m.id, i).toString()
                    if (t is TimeWindowTrigger) codes += code(m.id, i + END_OFFSET).toString()
                }
            }
        }
        prefs.edit().putStringSet("codes", codes).apply()
    }

    fun scheduleOne(m: Macro, idx: Int): Boolean = m.triggers.getOrNull(idx)?.let { scheduleOne(m, idx, it) } ?: false

    private fun scheduleOne(m: Macro, idx: Int, t: MacroTrigger): Boolean {
        if (t is TimeWindowTrigger) {
            // Dua alarm: mulai (nomor idx) dan selesai (nomor idx + END_OFFSET).
            val mulai = nextWindowEdge(t, start = true) ?: return false
            val selesai = nextWindowEdge(t, start = false) ?: return false
            setAlarm(m.id, idx, mulai)
            setAlarm(m.id, idx + END_OFFSET, selesai)
            return true
        }
        val at = nextTime(t) ?: return false
        setAlarm(m.id, idx, at)
        return true
    }

    private fun setAlarm(macroId: Long, idx: Int, at: Long) {
        val p = pi(macroId, idx)
        // Sama seperti BateraiBicara: setAlarmClock dikecualikan dari Doze, penghemat baterai, dan penundaan pabrikan,
        // serta tidak butuh izin alarm tepat waktu. Bila gagal, turun ke alarm tepat, lalu alarm biasa.
        try {
            val tampil = PendingIntent.getActivity(
                ctx, 7, Intent(ctx, com.makroku.automation.ui.MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, tampil), p)
        } catch (e: Exception) {
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                }
            } catch (e2: Exception) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            }
        }
    }

    /** Waktu mulai berikutnya (hanya di hari terpilih) atau waktu selesai berikutnya (hari apa pun). Jam mulai = jam selesai dianggap tidak valid. */
    private fun nextWindowEdge(t: TimeWindowTrigger, start: Boolean): Long? {
        if (windowMinutes(t) == null) return null
        val hh = (if (start) t.fromHour else t.toHour).coerceIn(0, 23)
        val mm = (if (start) t.fromMinute else t.toMinute).coerceIn(0, 59)
        val now = System.currentTimeMillis() + 2000
        for (offset in 0..8) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis > now && (!start || cal.get(Calendar.DAY_OF_WEEK) in t.days)) return cal.timeInMillis
        }
        return null
    }

    companion object {
        /** Alarm selesai memakai nomor idx + 50 supaya tidak bentrok dengan alarm mulai. */
        const val END_OFFSET = 50

        /** (menit mulai, menit selesai) sejak 00.00, atau null bila jam sama (tidak valid). */
        fun windowMinutes(t: TimeWindowTrigger): Pair<Int, Int>? {
            val a = t.fromHour.coerceIn(0, 23) * 60 + t.fromMinute.coerceIn(0, 59)
            val b = t.toHour.coerceIn(0, 23) * 60 + t.toMinute.coerceIn(0, 59)
            return if (a == b) null else a to b
        }

        /** Apakah [nowMs] berada di dalam rentang (memperhitungkan lintas tengah malam dan hari mulai). */
        fun inWindow(t: TimeWindowTrigger, nowMs: Long = System.currentTimeMillis()): Boolean {
            val (a, b) = windowMinutes(t) ?: return false
            val c = Calendar.getInstance().apply { timeInMillis = nowMs }
            val cur = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val today = c.get(Calendar.DAY_OF_WEEK)
            val yesterday = if (today == 1) 7 else today - 1
            return if (a < b) cur in a until b && today in t.days
            else (cur >= a && today in t.days) || (cur < b && yesterday in t.days)
        }
    }

    private fun nextTime(t: MacroTrigger): Long? = when (t) {
        is TimeTrigger -> {
            val now = System.currentTimeMillis() + 2000
            var result: Long? = null
            for (offset in 0..7) {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, offset)
                    set(Calendar.HOUR_OF_DAY, t.hour.coerceIn(0, 23))
                    set(Calendar.MINUTE, t.minute.coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis > now && cal.get(Calendar.DAY_OF_WEEK) in t.days) {
                    result = cal.timeInMillis
                    break
                }
            }
            result
        }
        is MonthlyTrigger -> {
            val now = System.currentTimeMillis() + 2000
            var result: Long? = null
            for (m in 0..13) {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    add(Calendar.MONTH, m)
                    set(Calendar.DAY_OF_MONTH, t.day.coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
                    set(Calendar.HOUR_OF_DAY, t.hour.coerceIn(0, 23))
                    set(Calendar.MINUTE, t.minute.coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis > now) {
                    result = cal.timeInMillis
                    break
                }
            }
            result
        }
        is OnceTrigger -> {
            val p = t.date.trim().split("-")
            val y = p.getOrNull(0)?.trim()?.toIntOrNull()
            val mo = p.getOrNull(1)?.trim()?.toIntOrNull()
            val d = p.getOrNull(2)?.trim()?.toIntOrNull()
            if (y == null || mo == null || d == null || mo !in 1..12 || d !in 1..31) null else {
                val cal = Calendar.getInstance().apply {
                    set(y, mo - 1, d, t.hour.coerceIn(0, 23), t.minute.coerceIn(0, 59), 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis > System.currentTimeMillis() + 2000) cal.timeInMillis else null
            }
        }
        is TimesTrigger -> {
            val now = System.currentTimeMillis() + 2000
            val slots = t.hours.split(",", ";", " ").mapNotNull { x ->
                val p = x.trim().split(":")
                val hh = p.getOrNull(0)?.toIntOrNull()
                val mm = p.getOrNull(1)?.toIntOrNull() ?: 0
                if (hh != null && hh in 0..23 && mm in 0..59) hh to mm else null
            }
            var best = Long.MAX_VALUE
            for (offset in 0..7) {
                for ((hh, mm) in slots) {
                    val cal = Calendar.getInstance().apply {
                        add(Calendar.DAY_OF_YEAR, offset)
                        set(Calendar.HOUR_OF_DAY, hh)
                        set(Calendar.MINUTE, mm)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    if (cal.timeInMillis > now && cal.get(Calendar.DAY_OF_WEEK) in t.days && cal.timeInMillis < best) {
                        best = cal.timeInMillis
                    }
                }
            }
            if (best == Long.MAX_VALUE) null else best
        }
        is SunTrigger -> {
            val lat = t.lat.trim().toDoubleOrNull()
            val lon = t.lon.trim().toDoubleOrNull()
            if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) null else {
                val now = System.currentTimeMillis() + 2000
                var result: Long? = null
                for (offset in 0..3) {
                    val day = now + offset * 24L * 3_600_000L
                    val at = SunCalc.time(day, lat, lon, t.sunrise)?.plus(t.offsetMinutes * 60_000L)
                    if (at != null && at > now + 1000) { result = at; break }
                }
                result
            }
        }
        is PeriodicTrigger -> {
            // Sejajar kelipatan menit sejak 00.00 (mis. tiap 10 menit: :00, :10, :20) bila membagi sehari habis,
            // seperti jam bicara BateraiBicara. Bila tidak, hitung dari sekarang.
            val iv = t.minutes.coerceIn(1, 1440).toInt()
            val now = System.currentTimeMillis() + 2000
            if (1440 % iv == 0) {
                val c = Calendar.getInstance().apply { timeInMillis = now }
                val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
                val next = (m / iv + 1) * iv
                c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                c.add(Calendar.MINUTE, next)
                c.timeInMillis
            } else now + iv * 60_000L
        }
        else -> null
    }
}
