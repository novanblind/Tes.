package com.novan.filemanagerpro

import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Tempat sampah. Berkas dipindah ke folder tersembunyi di penyimpanan internal,
 * lokasi asalnya dicatat di index.json agar bisa dipulihkan.
 */
object TrashManager {

    class Entry(val id: String, val name: String, val orig: String, val time: Long, val size: Long)

    private fun dir(): File =
        File(Environment.getExternalStorageDirectory(), ".FileManagerProTrash").also { it.mkdirs() }

    private fun indexFile() = File(dir(), "index.json")

    fun isInTrash(f: File): Boolean = try {
        (f.canonicalPath + "/").startsWith(dir().canonicalPath + "/")
    } catch (e: Exception) {
        false
    }

    @Synchronized
    fun load(): MutableList<Entry> {
        val out = ArrayList<Entry>()
        val idx = indexFile()
        if (!idx.exists()) return out
        try {
            val arr = JSONArray(idx.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val e = Entry(
                    o.getString("id"), o.getString("name"), o.getString("orig"),
                    o.optLong("time"), o.optLong("size")
                )
                if (File(dir(), e.id).exists()) out.add(e)
            }
        } catch (e: Exception) {
            // indeks rusak: abaikan
        }
        return out
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(
                JSONObject().put("id", e.id).put("name", e.name).put("orig", e.orig)
                    .put("time", e.time).put("size", e.size)
            )
        }
        indexFile().writeText(arr.toString())
    }

    @Synchronized
    fun trash(f: File, p: Progress? = null, knownSize: Long? = null): Boolean {
        if (!f.exists()) return false
        val id = UUID.randomUUID().toString()
        val size = knownSize ?: FileOps.sizeOf(f)
        if (!Util.moveExact(f, File(dir(), id), p)) return false
        val list = load()
        list.add(Entry(id, f.name, f.absolutePath, System.currentTimeMillis(), size))
        save(list)
        return true
    }

    @Synchronized
    fun restore(e: Entry, p: Progress? = null): Boolean {
        val src = File(dir(), e.id)
        if (!src.exists()) return false
        val parent = File(e.orig).parentFile ?: return false
        parent.mkdirs()
        val target = FileOps.uniqueTarget(parent, e.name)
        if (!Util.moveExact(src, target, p)) return false
        save(load().filter { it.id != e.id })
        return true
    }

    /** Menghapus permanen; dengan [p], kemajuan dilaporkan dan Batal bisa bekerja. Kunci hanya dipegang saat menulis indeks. */
    fun deleteForever(e: Entry, p: Progress? = null): Boolean {
        val f = File(dir(), e.id)
        val ok = if (p == null) f.deleteRecursively() else FileOps.deleteWithProgress(f, p)
        if (ok) synchronized(this) { save(load().filter { it.id != e.id }) }
        return ok
    }

    @Synchronized
    fun empty(): Int {
        val list = load()
        var n = 0
        for (e in list) if (File(dir(), e.id).deleteRecursively()) n++
        save(load().filter { File(dir(), it.id).exists() })
        return n
    }

    fun fileOf(e: Entry): File = File(dir(), e.id)
}
