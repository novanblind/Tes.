package com.novan.audiolabnovan.videolab;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Mengirim audio ke Groq (Whisper) dan mengubah balasannya menjadi baris subtitle. */
public final class GroqTranscriber {
    public static final long MAX_BYTES = 24L * 1024 * 1024;
    private static final String ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions";
    private static final int MAX_CHARS = 40;
    private static final long MAX_LINE_MS = 4500;
    private static final long MAX_GAP_MS = 800;

    private GroqTranscriber() { }

    /** Kesalahan sementara (batas pemakaian, gangguan server atau jaringan) yang layak dicoba ulang. */
    static final class Retryable extends IOException {
        final long waitMs;
        Retryable(String msg, long waitMs) { super(msg); this.waitMs = waitMs; }
    }

    private static final int ATTEMPTS = 3;

    /** Waktu hasil memakai jalur waktu berkas audio, dalam milidetik. Mencoba ulang bila gangguan sementara. */
    public static List<SubtitleItem> transcribe(String apiKey, String model, String lang, File audio)
            throws IOException {
        IOException last = null;
        for (int i = 0; i < ATTEMPTS; i++) {
            try {
                return transcribeOnce(apiKey, model, lang, audio);
            } catch (Retryable e) {
                last = e;
                if (i == ATTEMPTS - 1) break;
                try { Thread.sleep(Math.max(e.waitMs, 3000L * (i + 1))); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        throw last != null ? last : new IOException("Gagal terhubung ke Groq.");
    }

    private static List<SubtitleItem> transcribeOnce(String apiKey, String model, String lang, File audio)
            throws IOException {
        try {
            return transcribeRaw(apiKey, model, lang, audio);
        } catch (Retryable e) {
            throw e;
        } catch (java.net.SocketTimeoutException | java.net.UnknownHostException
                 | java.net.SocketException e) {
            throw new Retryable("Gagal terhubung ke Groq. Periksa internet." , 0);
        }
    }

    private static List<SubtitleItem> transcribeRaw(String apiKey, String model, String lang, File audio)
            throws IOException {
        String boundary = "----VideoLab" + System.currentTimeMillis();
        HttpURLConnection con = (HttpURLConnection) new URL(ENDPOINT).openConnection();
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setConnectTimeout(30000);
        con.setReadTimeout(300000);
        con.setChunkedStreamingMode(64 * 1024);
        con.setRequestProperty("Authorization", "Bearer " + apiKey);
        con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (OutputStream os = con.getOutputStream()) {
            field(os, boundary, "model", model);
            field(os, boundary, "response_format", "verbose_json");
            field(os, boundary, "temperature", "0");
            if (lang != null && !lang.isEmpty()) field(os, boundary, "language", lang);
            field(os, boundary, "timestamp_granularities[]", "word");
            field(os, boundary, "timestamp_granularities[]", "segment");
            os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.m4a\"\r\n"
                    + "Content-Type: audio/mp4\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            try (InputStream is = new FileInputStream(audio)) {
                byte[] buf = new byte[32 * 1024];
                int n;
                while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            }
            os.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }
        int code = con.getResponseCode();
        String body = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        long retryAfter = 0;
        try { retryAfter = Math.min(30, Long.parseLong(con.getHeaderField("Retry-After").trim())) * 1000L; } catch (Exception ignored) { }
        con.disconnect();
        if (code == 429 || code >= 500) throw new Retryable(describeError(code, body), retryAfter);
        if (code >= 400) throw new IOException(describeError(code, body));
        try {
            return parse(new JSONObject(body));
        } catch (Exception e) {
            throw new IOException("Balasan Groq tidak bisa dibaca.");
        }
    }

    private static void field(OutputStream os, String boundary, String name, String value) throws IOException {
        os.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n"
                + value + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    private static String read(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String describeError(int code, String body) {
        String msg = "";
        try { msg = new JSONObject(body).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
        if (code == 401) return "Kunci API Groq tidak valid atau sudah dicabut. Periksa kunci di pengaturan.";
        if (code == 429) return "Batas pemakaian Groq tercapai. Coba lagi beberapa saat lagi." + (msg.isEmpty() ? "" : " " + msg);
        if (code == 413) return "Berkas audio terlalu besar untuk Groq. Potong video menjadi bagian yang lebih pendek.";
        if (code >= 500) return "Server Groq sedang bermasalah (kode " + code + "). Coba lagi nanti.";
        return "Groq menolak permintaan (kode " + code + ")." + (msg.isEmpty() ? "" : " " + msg);
    }

    static List<SubtitleItem> parse(JSONObject o) {
        JSONArray words = o.optJSONArray("words");
        if (words != null && words.length() > 0) return fromWords(words);
        List<SubtitleItem> out = new ArrayList<>();
        JSONArray segs = o.optJSONArray("segments");
        if (segs != null) {
            for (int i = 0; i < segs.length(); i++) {
                JSONObject s = segs.optJSONObject(i);
                if (s == null) continue;
                String text = s.optString("text", "").trim();
                if (text.isEmpty()) continue;
                long st = Math.round(s.optDouble("start", 0) * 1000);
                long en = Math.round(s.optDouble("end", 0) * 1000);
                splitEvenly(out, text, st, Math.max(en, st + 500));
            }
        } else {
            String text = o.optString("text", "").trim();
            if (!text.isEmpty()) splitEvenly(out, text, 0, Math.max(2000, text.length() * 60L));
        }
        return out;
    }

    private static List<SubtitleItem> fromWords(JSONArray words) {
        List<SubtitleItem> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        long ls = 0, le = 0;
        for (int i = 0; i < words.length(); i++) {
            JSONObject w = words.optJSONObject(i);
            if (w == null) continue;
            String t = w.optString("word", "").trim();
            if (t.isEmpty()) continue;
            long s = Math.round(w.optDouble("start", 0) * 1000);
            long e = Math.round(w.optDouble("end", 0) * 1000);
            if (line.length() > 0 && (s - le > MAX_GAP_MS
                    || line.length() + 1 + t.length() > MAX_CHARS || e - ls > MAX_LINE_MS)) {
                flush(out, line, ls, le);
            }
            if (line.length() == 0) ls = s;
            else line.append(' ');
            line.append(t);
            le = Math.max(e, s + 100);
            char last = t.charAt(t.length() - 1);
            if (last == '.' || last == '?' || last == '!') flush(out, line, ls, le);
        }
        flush(out, line, ls, le);
        return out;
    }

    private static void flush(List<SubtitleItem> out, StringBuilder line, long ls, long le) {
        if (line.length() == 0) return;
        out.add(new SubtitleItem(ls, Math.max(le, ls + 500), line.toString()));
        line.setLength(0);
    }

    private static void splitEvenly(List<SubtitleItem> out, String text, long st, long en) {
        String[] w = text.split("\\s+");
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String x : w) {
            if (cur.length() > 0 && cur.length() + 1 + x.length() > MAX_CHARS) {
                lines.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(x);
        }
        if (cur.length() > 0) lines.add(cur.toString());
        long span = en - st;
        int total = 0;
        for (String l : lines) total += l.length();
        long t = st;
        for (String l : lines) {
            long d = total == 0 ? span : span * l.length() / total;
            out.add(new SubtitleItem(t, t + Math.max(300, d), l));
            t += d;
        }
    }
}
