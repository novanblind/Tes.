package com.novan.filemanagerpro

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.MenuItem
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

/**
 * Layar pemutar musik. Pemutaran sebenarnya dijalankan [PlayerService] sehingga musik
 * tetap berbunyi saat layar ini ditutup; layar ini hanya mengendalikan dan menampilkan.
 */
class AudioPlayerActivity : AppCompatActivity() {

    private var svc: PlayerService? = null
    private var pendingOpen: Pair<List<String>, Int>? = null
    private val main = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastAnnounced = -1
    private var bound = false

    private lateinit var nameView: TextView
    private lateinit var timeView: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnShuffle: Button
    private lateinit var btnRepeat: Button
    private lateinit var btnSpeed: Button

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as PlayerService.LocalBinder).service
            svc = s
            s.onChange = { refresh() }
            pendingOpen?.let { s.open(it.first, it.second); pendingOpen = null }
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            svc = null
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val s = svc
            if (s != null && s.isPrepared() && !dragging) {
                seek.max = s.duration()
                seek.progress = s.position()
                timeView.text = fmt(s.position()) + " / " + fmt(s.duration())
            }
            main.postDelayed(this, 500)
        }
    }

    /**
     * Berkas dari aplikasi lain (mis. WhatsApp) berupa content://. Izin bacanya melekat pada layar ini,
     * jadi disalin dulu ke folder sementara lalu diputar dari sana; layanan pemutar tidak selalu
     * mendapat izin yang sama.
     */
    private fun copyContentThenOpen(u: android.net.Uri) {
        Thread {
            var out: File? = null
            try {
                var name: String? = null
                contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0)
                }
                val dir = File(cacheDir, "open_audio").also { it.deleteRecursively(); it.mkdirs() }
                val safe = (name ?: "audio.mp3").replace(Regex("[^A-Za-z0-9_.\\- ]"), "_")
                val f = File(dir, safe)
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                out = f
            } catch (e: Exception) {
                out = null
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                val f = out
                if (f == null) {
                    android.widget.Toast.makeText(this, R.string.cannot_open, android.widget.Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val s = svc
                if (s != null) s.open(listOf(f.absolutePath), 0) else pendingOpen = listOf(f.absolutePath) to 0
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_audio_player)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        nameView = findViewById(R.id.audioName)
        timeView = findViewById(R.id.audioTime)
        seek = findViewById(R.id.audioSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnSpeed = findViewById(R.id.btnSpeed)

        if (savedInstanceState == null) {
            val arr = intent.getStringArrayExtra(Util.EXTRA_PATHS)
            val d = intent.data
            if (arr != null && arr.isNotEmpty()) {
                pendingOpen = arr.toList() to intent.getIntExtra(Util.EXTRA_INDEX, 0)
            } else if (d != null && d.scheme == "content") {
                copyContentThenOpen(d)
            } else if (d != null) {
                val one = if (d.scheme == "file" && d.path != null) d.path!! else d.toString()
                pendingOpen = listOf(one) to 0
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val svcIntent = Intent(this, PlayerService::class.java)
        ContextCompat.startForegroundService(this, svcIntent)
        bound = bindService(svcIntent, conn, Context.BIND_AUTO_CREATE)

        btnPlay.setOnClickListener { svc?.toggle() }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { svc?.prev() }
        findViewById<Button>(R.id.btnNext).setOnClickListener { svc?.next() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { svc?.skip(-10000) }
        findViewById<Button>(R.id.btnFwd).setOnClickListener { svc?.skip(10000) }
        btnShuffle.setOnClickListener { svc?.let { it.setShuffle(!it.shuffle) } }
        btnRepeat.setOnClickListener { svc?.let { it.setRepeat((it.repeat + 1) % 3) } }
        btnSpeed.setOnClickListener { showSpeedDialog() }
        findViewById<Button>(R.id.btnList).setOnClickListener { showQueueDialog() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            svc?.stopAll()
            finish()
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) svc?.seekTo(p)
            }
            override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar) { dragging = false }
        })
        main.post(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacks(ticker)
        svc?.onChange = null
        if (bound) {
            unbindService(conn)
            bound = false
        }
        svc = null
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return String.format(Locale.getDefault(), "%d:%02d", s / 60, s % 60)
    }

    private fun refresh() {
        val s = svc ?: return
        val name = s.currentName()
        val label = if (s.queue.size > 1)
            getString(R.string.image_position, name, s.index + 1, s.queue.size)
        else name
        title = name.ifEmpty { getString(R.string.music_player) }
        if (s.failed) {
            nameView.text = getString(R.string.audio_failed)
        } else {
            nameView.text = label
            if (s.isPrepared() && s.index != lastAnnounced) {
                lastAnnounced = s.index
                nameView.announceForAccessibility(label)
            }
        }
        btnPlay.setText(if (s.isPlaying()) R.string.audio_pause else R.string.audio_play)
        btnShuffle.text = getString(
            R.string.audio_shuffle_state,
            getString(if (s.shuffle) R.string.state_on else R.string.state_off)
        )
        btnRepeat.text = getString(
            R.string.audio_repeat_state,
            getString(
                when (s.repeat) {
                    PlayerService.REPEAT_ALL -> R.string.repeat_all
                    PlayerService.REPEAT_ONE -> R.string.repeat_one
                    else -> R.string.state_off
                }
            )
        )
        btnSpeed.text = getString(R.string.audio_speed_state, speedLabel(s.speed))
    }

    private fun speedLabel(v: Float): String = String.format(Locale.US, "%.2fx", v)

    private fun showSpeedDialog() {
        val s = svc ?: return
        val values = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val labels = values.map { String.format(Locale.US, "%.2fx", it) }.toTypedArray()
        val checked = values.indexOfFirst { Math.abs(it - s.speed) < 0.01f }
        AlertDialog.Builder(this)
            .setTitle(R.string.audio_speed_title)
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                s.setSpeed(values[which])
                dialog.dismiss()
            }
            .show()
    }

    private fun showQueueDialog() {
        val s = svc ?: return
        if (s.queue.isEmpty()) return
        val names = s.queue.map {
            if (it.startsWith("content:")) android.net.Uri.parse(it).lastPathSegment ?: it else File(it).name
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.audio_queue)
            .setSingleChoiceItems(names, s.index) { dialog, which ->
                s.jump(which)
                dialog.dismiss()
            }
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) { finish(); true } else super.onOptionsItemSelected(item)
}
