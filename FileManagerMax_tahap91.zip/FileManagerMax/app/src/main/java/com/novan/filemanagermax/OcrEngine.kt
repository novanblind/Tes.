package com.novan.filemanagermax

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.InputStream

/**
 * OCR offline (tahap 79) memakai ML Kit Text Recognition versi model yang ikut di dalam aplikasi.
 * Tidak butuh internet. Pustaka native tersedia untuk HP 32 bit (armeabi-v7a) dan 64 bit (arm64-v8a).
 * Aksara Latin (termasuk bahasa Indonesia dan Inggris).
 *
 * Semua fungsi di sini memblokir sampai selesai, jadi jangan dipanggil dari utas utama.
 */
object OcrEngine {

    private var client: TextRecognizer? = null

    @Synchronized
    private fun recognizer(): TextRecognizer {
        val c = client ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        client = c
        return c
    }

    /**
     * Membaca tulisan di [bmp] (harus ARGB_8888). Hasilnya daftar paragraf yang sudah dirapikan
     * supaya enak didengar pembaca layar (lihat [tidy]). Halaman tanpa tulisan menghasilkan daftar kosong.
     * Melempar pengecualian bila mesin gagal.
     */
    fun paragraphs(bmp: Bitmap): List<String> {
        val result = Tasks.await(recognizer().process(InputImage.fromBitmap(bmp, 0)))
        val out = ArrayList<String>()
        for (b in result.textBlocks) out.addAll(tidy(b.lines.map { it.text }))
        return out
    }

    private val noiseRun = Regex("([._\\-=~*#|])\\1{2,}")
    private val spaces = Regex("\\s+")
    private val bulletStart = Regex("^[\\u2022\\u25CF\\u25AA\\u25A0\\u25E6\\u00B7*]+\\s*")
    private val listMarker =
        Regex("^(\\d{1,3}[.)]|[a-zA-Z][.)]|[-\\u2013\\u2014\\u2022\\u25CF\\u25AA\\u25A0\\u25E6\\u00B7*])\\s+\\S")

    /**
     * Merapikan baris-baris satu blok teks: baris disambung jadi kalimat utuh (kata yang terpotong
     * tanda hubung di ujung baris disatukan), titik-titik atau garis hiasan dibuang, simbol butir tidak
     * dibacakan, dan potongan tak berarti (nomor halaman, simbol sendirian) dilewati.
     */
    internal fun tidy(rawLines: List<String>): List<String> {
        val paras = ArrayList<StringBuilder>()
        var cur: StringBuilder? = null
        for (raw in rawLines) {
            var line = raw.replace(noiseRun, " ").replace(spaces, " ").trim()
            if (line.isEmpty()) continue
            val isItem = listMarker.containsMatchIn(line)
            line = line.replace(bulletStart, "").trim()
            if (line.isEmpty()) continue
            val c = cur
            if (c == null || isItem) {
                val nb = StringBuilder(line)
                cur = nb
                paras.add(nb)
            } else if (c.endsWith("-") && c.length > 1 && c[c.length - 2].isLetter() && line[0].isLowerCase()) {
                c.setLength(c.length - 1)
                c.append(line)
            } else {
                c.append(' ').append(line)
            }
        }
        val out = ArrayList<String>()
        for (sb in paras) {
            val t = sb.toString().trim()
            val signif = t.count { it.isLetterOrDigit() }
            if (signif < 2) continue
            if (signif <= 4 && t.all { it.isDigit() || it.isWhitespace() }) continue
            out.add(t)
        }
        return out
    }

    /**
     * Memuat gambar dari [path] atau [uri] dengan putaran EXIF sudah diterapkan. Sisi terpanjang dibatasi
     * [maxSide] piksel (resolusi cukup tinggi supaya tulisan kecil tetap terbaca). Bila memori habis,
     * gambar diperkecil lagi dan dicoba ulang.
     */
    fun loadImage(c: Context, path: String?, uri: Uri?, maxSide: Int = 4200): Bitmap? {
        val open: () -> InputStream? = {
            if (path != null) File(path).inputStream() else c.contentResolver.openInputStream(uri!!)
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2

        var bmp: Bitmap? = null
        var tries = 0
        while (bmp == null && tries < 4) {
            try {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                bmp = open()?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) return null
            } catch (e: OutOfMemoryError) {
                sample *= 2
                tries++
            }
        }
        var b = bmp ?: return null

        val orientation = try {
            if (path != null) ExifInterface(path).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            ) else open()?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        try {
            val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            if (r !== b) b.recycle()
            b = r
        } catch (e: OutOfMemoryError) {
            // pakai gambar tanpa putaran daripada gagal total
        }
        return b
    }
}
