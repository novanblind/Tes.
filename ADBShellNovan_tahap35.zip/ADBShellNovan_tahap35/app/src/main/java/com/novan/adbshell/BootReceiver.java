package com.novan.adbshell;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String act = i.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(act)
                && !"android.intent.action.QUICKBOOT_POWERON".equals(act)) return;
        // Langsung nyalakan Debugging USB (dan nirkabel) tanpa menunggu layanan.
        Latar.aktifkanDebugging(c);
        if (!c.getSharedPreferences("adb", Context.MODE_PRIVATE).getBoolean("paired", false)) return;
        try {
            c.startForegroundService(new Intent(c, AutoConnectService.class));
        } catch (Exception ignored) {}
    }
}
