package com.novan.talkbacknovan;

import android.accessibilityservice.AccessibilityGestureEvent;
import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.content.ClipData;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.BreakIterator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Layanan aksesibilitas utama TalkBack Novan. */
public class TalkBackNovanService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    static TalkBackNovanService instance;

    private Speaker speaker;
    private Efek efek;
    private SensorManager sensorMgr;
    private Sensor sensorJarak;
    private boolean jarakAktif;
    private final SensorEventListener pendengarJarak = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent ev) {
            if (speaker == null || sensorJarak == null) return;
            if (ev.values[0] < Math.min(sensorJarak.getMaximumRange(), 5f)) speaker.stop();
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long waktuTeksBerubah;
    private long waktuFokus;
    private long waktuJendela;

    // Tahap 2
    private int granularitas = Granularitas.ITEM;
    private int posisiSeg = -1;          // segmen teks terakhir yang dibaca (elemen non-isian)
    private long waktuGerakTeks;
    private long waktuInfoGulir;
    private int tombolVolume;            // kode tombol volume yang sedang ditahan, 0 = tidak ada
    private boolean volumeLama;
    private final Runnable tekanLama = new Runnable() {
        @Override
        public void run() {
            if (tombolVolume == 0) return;
            volumeLama = true;
            getarSingkat();
            jalankanAksi(Prefs.aksi(TalkBackNovanService.this,
                    tombolVolume == KeyEvent.KEYCODE_VOLUME_UP ? Prefs.VOL_ATAS : Prefs.VOL_BAWAH));
        }
    };

    // Tahap 4
    static volatile String teksLayar = "";
    static volatile List<String> daftarMenu = new ArrayList<>();
    private final ArrayList<int[]> kodeMenu = new ArrayList<>(); // {jenis, nomor aksi khusus}
    private AccessibilityNodeInfo sasaranMenu;
    private static final int M_KETUK = 1, M_KETUK_LAMA = 2, M_SALIN = 3, M_TEMPEL = 4, M_POTONG = 5,
            M_SEMUA = 6, M_KHUSUS = 7, M_GANTI = 8, M_TEKS = 9, M_BACA = 10, M_OCR = 11,
            M_AKSI = 12, M_FOKUS = 13;
    private final ArrayList<AccessibilityNodeInfo.AccessibilityAction> aksiKhusus = new ArrayList<>();

    static void pilihMenu(final int idx) {
        final TalkBackNovanService s = instance;
        if (s == null) return;
        // Beri waktu dialog menu menutup dan fokus kembali ke elemen semula.
        s.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                s.laksanakanMenu(idx);
            }
        }, 400);
    }

    static void ucapkanAntre(String teks) {
        TalkBackNovanService s = instance;
        if (s != null && s.speaker != null) s.speaker.ucapkan(teks, false);
    }

    private boolean dalamDaftar(String kunci, CharSequence paket) {
        return paket != null && !getPackageName().contentEquals(paket)
                && Prefs.daftar(this, kunci).contains(paket.toString());
    }

    static void ucapkanContoh(String teks) {
        TalkBackNovanService s = instance;
        if (s != null && s.speaker != null) s.speaker.ucapkan(teks, true);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        speaker = new Speaker(this);
        efek = new Efek(this);
        sensorMgr = getSystemService(SensorManager.class);
        sensorJarak = sensorMgr == null ? null : sensorMgr.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        aturSensorJarak();
        pasangPenerimaLayar();
        Prefs.get(this).registerOnSharedPreferenceChangeListener(this);
        speaker.ucapkan("TalkBack Novan aktif", true);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (instance == TalkBackNovanService.this) PluginManager.mulaiOtomatis(TalkBackNovanService.this);
            }
        }, 1500);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Prefs.K_JARAK.equals(key)) aturSensorJarak();
        if (speaker == null) return;
        if (Prefs.K_MESIN.equals(key)) {
            speaker.muatUlang();
        } else {
            speaker.terapkanPengaturan();
        }
    }

    private void aturSensorJarak() {
        if (sensorMgr == null || sensorJarak == null) return;
        boolean mau = Prefs.get(this).getBoolean(Prefs.K_JARAK, false);
        if (mau && !jarakAktif) {
            sensorMgr.registerListener(pendengarJarak, sensorJarak, SensorManager.SENSOR_DELAY_NORMAL);
            jarakAktif = true;
        } else if (!mau && jarakAktif) {
            sensorMgr.unregisterListener(pendengarJarak);
            jarakAktif = false;
        }
    }

    /** Pilih suara fokus seperti JieShuo: tombol/centang/isian = fokus1, papan ketik = fokus3, lainnya = fokus2. */
    private int jenisSuaraFokus(AccessibilityNodeInfo n) {
        try {
            android.view.accessibility.AccessibilityWindowInfo w = n.getWindow();
            if (w != null && w.getType() == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                return Efek.FOKUS3;
            }
        } catch (Exception ignored) {
        }
        if (n.isClickable() || n.isCheckable() || n.isEditable()) return Efek.FOKUS1;
        return Efek.FOKUS2;
    }

    private String paketAktif = "";

    private void efek(int jenis) {
        if (!paketAktif.isEmpty() && Prefs.daftar(this, Prefs.K_HITAM_EFEK).contains(paketAktif)) return;
        if (efek != null) efek.putar(jenis);
    }

    @Override
    public void onInterrupt() {
        if (speaker != null) speaker.stop();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        PluginManager.hentiSemua();
        lepasPenerimaLayar();
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(this);
        if (sensorMgr != null && jarakAktif) {
            sensorMgr.unregisterListener(pendengarJarak);
            jarakAktif = false;
        }
        if (efek != null) {
            efek.tutup();
            efek = null;
        }
        if (speaker != null) {
            speaker.tutup();
            speaker = null;
        }
        instance = null;
        return super.onUnbind(intent);
    }

    // ------------------------------------------------------------------ peristiwa

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || speaker == null) return;
        PluginManager.saatPeristiwa(e);
        int jenisPeristiwa = e.getEventType();
        if ((jenisPeristiwa == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || jenisPeristiwa == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED)
                && e.getPackageName() != null) {
            paketAktif = e.getPackageName().toString();
        }
        switch (e.getEventType()) {
            case AccessibilityEvent.TYPE_VIEW_HOVER_ENTER:
                saatJelajahSentuh(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED:
                saatFokusAksesibilitas(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                saatFokusMasukan(e);
                break;
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                saatJendelaBerubah(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                efek(Efek.KLIK);
                saatDiketuk(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_LONG_CLICKED:
                efek(Efek.KLIK_LAMA);
                break;
            case AccessibilityEvent.TYPE_TOUCH_INTERACTION_START:
                sedangMenyentuh = true;
                if (Prefs.get(this).getBoolean(Prefs.K_SENTUH_DIAM, false)) speaker.stop();
                break;
            case AccessibilityEvent.TYPE_TOUCH_INTERACTION_END:
                sedangMenyentuh = false;
                break;
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                saatTeksBerubah(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED:
                saatPilihanTeksBerubah(e);
                break;
            case AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED:
                if (!Prefs.get(this).getBoolean(Prefs.K_NOTIF, true)) break;
                if (dalamDaftar(Prefs.K_HITAM_NOTIF, e.getPackageName())) break;
                if (notifDiam(this, e.getPackageName() == null ? "" : e.getPackageName().toString())) break;
                // Notifikasi sungguhan dibacakan PendengarNotifikasi bila aktif; di sini sisanya (toast).
                if (e.getParcelableData() instanceof android.app.Notification
                        && PendengarNotifikasi.aktif) break;
                if (!(e.getParcelableData() instanceof android.app.Notification)
                        && !Prefs.get(this).getBoolean(Prefs.K_NOTIF_TOAST, true)) break;
                speaker.ucapkan(gabung(e.getText()), false);
                break;
            case AccessibilityEvent.TYPE_ANNOUNCEMENT:
                if (!Prefs.get(this).getBoolean(Prefs.K_NOTIF_UMUM, true)) break;
                if (dalamDaftar(Prefs.K_HITAM_OTOMATIS, e.getPackageName())) break;
                speaker.ucapkan(gabung(e.getText()), false);
                break;
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                if (dalamDaftar(Prefs.K_HITAM_OTOMATIS, e.getPackageName())) break;
                saatIsiBerubah(e);
                break;
            case AccessibilityEvent.TYPE_VIEW_SCROLLED:
                if (dalamDaftar(Prefs.K_HITAM_OTOMATIS, e.getPackageName())) break;
                saatDigulir(e);
                break;
            default:
                break;
        }
    }

    private void saatFokusAksesibilitas(AccessibilityEvent e) {
        AccessibilityNodeInfo s = e.getSource();
        if (s == null) return;
        long sekarang = SystemClock.uptimeMillis();
        waktuFokus = sekarang;
        posisiSeg = -1;
        // Tepat setelah judul jendela diucapkan, jangan memotongnya.
        boolean potong = sekarang - waktuJendela > 700;
        String ucap = NodeDescriber.describeFokus(this, s);
        if (dalamKeyboard(s)) {
            SharedPreferences sp = Prefs.get(this);
            if (!sp.getBoolean(Prefs.K_IME_BACA_TOMBOL, true)) {
                efek(jenisSuaraFokus(s));
                return;
            }
            CharSequence mentah = s.getText();
            if (mentah != null && mentah.length() == 1 && Character.isLetter(mentah.charAt(0))) {
                char huruf = mentah.charAt(0);
                if (Character.isUpperCase(huruf) && sp.getBoolean(Prefs.K_IME_KAPITAL, true)) {
                    ucap = "kapital " + ucap;
                }
                if (sp.getBoolean(Prefs.K_IME_CONTOH, false)) {
                    String contoh = contohKata(huruf);
                    if (contoh != null) ucap = ucap + ", " + contoh;
                }
            }
        }
        speaker.ucapkan(ucap, potong);
        efek(jenisSuaraFokus(s));
        getarSingkat();
    }

    private void saatFokusMasukan(AccessibilityEvent e) {
        AccessibilityNodeInfo s = e.getSource();
        if (s == null || !s.isEditable()) return;
        waktuFokus = SystemClock.uptimeMillis();
        speaker.ucapkan(NodeDescriber.describe(this, s), true);
    }

    private void saatJendelaBerubah(AccessibilityEvent e) {
        waktuJendela = SystemClock.uptimeMillis();
        if (!Prefs.get(this).getBoolean(Prefs.K_JENIS_TETAP, false)) {
            granularitas = Granularitas.ITEM;
            posisiSeg = -1;
        }
        efek(Efek.JENDELA);
        if (!Prefs.get(this).getBoolean(Prefs.K_JENDELA, true)) return;
        String judul = gabung(e.getText());
        if (TextUtils.isEmpty(judul)) judul = labelAplikasi(e.getPackageName());
        speaker.ucapkan(judul, true);
    }

    private void saatDiketuk(AccessibilityEvent e) {
        final AccessibilityNodeInfo s = e.getSource();
        if (s == null || !s.isCheckable()) return;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (speaker == null) return;
                s.refresh();
                speaker.ucapkan(NodeDescriber.teksStatus(s), true);
            }
        }, 150);
    }

    private void saatIsiBerubah(AccessibilityEvent e) {
        AccessibilityNodeInfo s = e.getSource();
        if (s == null) return;
        int live = s.getLiveRegion();
        if (live == View.ACCESSIBILITY_LIVE_REGION_NONE) return;
        speaker.ucapkan(NodeDescriber.describe(this, s),
                live == View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE);
    }

    // ------------------------------------------------------------------ gema ketikan

    private void saatTeksBerubah(AccessibilityEvent e) {
        waktuTeksBerubah = SystemClock.uptimeMillis();
        posisiSeg = -1;
        int mode = Prefs.get(this).getInt(Prefs.K_GEMA, 3);
        AccessibilityNodeInfo s = e.getSource();
        boolean sandi = e.isPassword() || (s != null && s.isPassword());

        int ditambah = e.getAddedCount();
        int dihapus = e.getRemovedCount();
        int dari = e.getFromIndex();
        String kini = (e.getText() == null || e.getText().isEmpty() || e.getText().get(0) == null)
                ? "" : e.getText().get(0).toString();
        CharSequence sebelumCs = e.getBeforeText();
        String sebelum = sebelumCs == null ? "" : sebelumCs.toString();

        if (sandi) {
            if (mode == 0) return;
            if (ditambah == 1 && dihapus == 0 && Prefs.get(this).getBoolean(Prefs.K_IME_SANDI, true)
                    && dari >= 0 && dari < kini.length()) {
                speaker.ucapkan(namaKarakter(kini.substring(dari, dari + 1)), true);
                return;
            }
            if (ditambah > dihapus) speaker.ucapkan("bintang", true);
            else if (dihapus > ditambah) speaker.ucapkan("dihapus", true);
            return;
        }
        if (mode == 0) return;

        if (ditambah > 0 && dari >= 0 && dari + ditambah <= kini.length()) {
            String sisip = kini.substring(dari, dari + ditambah);
            if (ditambah == 1) {
                char ch = sisip.charAt(0);
                boolean gemaKarakter = (mode == 1 || mode == 3);
                boolean gemaKata = (mode == 2 || mode == 3);
                if (gemaKarakter) speaker.ucapkan(namaKarakter(sisip), true);
                if (gemaKata && !Character.isLetterOrDigit(ch)) {
                    String kata = kataSebelum(kini, dari);
                    if (!kata.isEmpty()) speaker.ucapkan(kata, !gemaKarakter);
                }
            } else {
                speaker.ucapkan(sisip, true);
            }
        } else if (dihapus > 0 && ditambah == 0 && dari >= 0
                && dari + dihapus <= sebelum.length()) {
            speaker.ucapkan(namaKarakter(sebelum.substring(dari, dari + dihapus)), true);
        }
    }

    private void saatPilihanTeksBerubah(AccessibilityEvent e) {
        long sekarang = SystemClock.uptimeMillis();
        if (sekarang - waktuTeksBerubah < 250) return;
        if (sekarang - waktuGerakTeks < 500) return;
        if (sekarang - waktuFokus < 600) return;
        AccessibilityNodeInfo s = e.getSource();
        if (s == null || s.isPassword()) return;
        CharSequence teks = s.getText();
        int a = s.getTextSelectionStart();
        int b = s.getTextSelectionEnd();
        if (teks == null || a < 0 || b < 0 || a > teks.length() || b > teks.length()) return;
        if (a != b) {
            int awal = Math.min(a, b);
            int akhir = Math.max(a, b);
            speaker.ucapkan("dipilih " + teks.subSequence(awal, akhir), true);
        } else if (b >= teks.length()) {
            speaker.ucapkan("akhir teks", true);
        } else {
            speaker.ucapkan(namaKarakter(String.valueOf(teks.charAt(b))), true);
        }
    }

    private static String kataSebelum(String teks, int posisiPemisah) {
        int akhir = posisiPemisah;
        while (akhir > 0 && !Character.isLetterOrDigit(teks.charAt(akhir - 1))) akhir--;
        int awal = akhir;
        while (awal > 0 && Character.isLetterOrDigit(teks.charAt(awal - 1))) awal--;
        return teks.substring(awal, akhir);
    }

    private static String namaKarakter(String s) {
        if (s.length() != 1) return s;
        switch (s.charAt(0)) {
            case ' ': return "spasi";
            case '\n': return "baris baru";
            case '.': return "titik";
            case ',': return "koma";
            case '?': return "tanya";
            case '!': return "seru";
            case '-': return "strip";
            case '_': return "garis bawah";
            case '@': return "et";
            case '/': return "garis miring";
            case ':': return "titik dua";
            case ';': return "titik koma";
            case '(': return "kurung buka";
            case ')': return "kurung tutup";
            case '"': return "tanda kutip";
            case '#': return "pagar";
            case '*': return "bintang";
            case '+': return "tambah";
            case '=': return "sama dengan";
            default: return s;
        }
    }

    // ------------------------------------------------------------------ gestur

    private boolean modeHuruf;
    private final ArrayList<AccessibilityNodeInfo> daftarFokus = new ArrayList<>();

    private static boolean banyakJari(int id) {
        switch (id) {
            case GESTURE_2_FINGER_SINGLE_TAP: case GESTURE_2_FINGER_DOUBLE_TAP: case GESTURE_2_FINGER_TRIPLE_TAP:
            case GESTURE_2_FINGER_SWIPE_UP: case GESTURE_2_FINGER_SWIPE_DOWN:
            case GESTURE_2_FINGER_SWIPE_LEFT: case GESTURE_2_FINGER_SWIPE_RIGHT:
            case GESTURE_3_FINGER_SINGLE_TAP: case GESTURE_3_FINGER_DOUBLE_TAP: case GESTURE_3_FINGER_TRIPLE_TAP:
            case GESTURE_3_FINGER_SWIPE_UP: case GESTURE_3_FINGER_SWIPE_DOWN:
            case GESTURE_3_FINGER_SWIPE_LEFT: case GESTURE_3_FINGER_SWIPE_RIGHT:
            case GESTURE_4_FINGER_SINGLE_TAP: case GESTURE_4_FINGER_DOUBLE_TAP: case GESTURE_4_FINGER_TRIPLE_TAP:
            case GESTURE_4_FINGER_SWIPE_UP: case GESTURE_4_FINGER_SWIPE_DOWN:
            case GESTURE_4_FINGER_SWIPE_LEFT: case GESTURE_4_FINGER_SWIPE_RIGHT:
                return true;
            default:
                return false;
        }
    }

    /** Gestur saat mode jelajah per karakter aktif. Mengembalikan true bila ditangani. */
    private boolean gesturModeHuruf(int id) {
        switch (id) {
            case GESTURE_SWIPE_RIGHT:
                gerakTeksDengan(Granularitas.KARAKTER, true);
                return true;
            case GESTURE_SWIPE_LEFT:
                gerakTeksDengan(Granularitas.KARAKTER, false);
                return true;
            case GESTURE_SWIPE_DOWN:
                posisiSeg = -1;
                pindahFokus(true, Granularitas.ITEM, 0);
                return true;
            case GESTURE_SWIPE_UP:
                posisiSeg = -1;
                pindahFokus(false, Granularitas.ITEM, 0);
                return true;
            case GESTURE_SWIPE_LEFT_AND_DOWN:
                modeHuruf = false;
                posisiSeg = -1;
                efek(Efek.BATAL);
                speaker.ucapkan("keluar dari mode per karakter", true);
                return true;
            default:
                return false;
        }
    }

    private void gerakTeksDengan(int g, boolean maju) {
        int lama = granularitas;
        granularitas = g;
        try {
            gerakTeks(maju);
        } finally {
            granularitas = lama;
        }
    }

    /** Usap kiri/kanan menurut konteks, seperti JieShuo: kolom isian, penggeser, atau gulir daftar. */
    private void gerakKonteks(boolean kanan) {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        android.content.SharedPreferences sp = Prefs.get(this);
        if (f != null && f.isEditable() && sp.getBoolean(Prefs.K_GERAK_KURSOR, true)) {
            gerakTeksDengan(Granularitas.KARAKTER, kanan);
            return;
        }
        if (f != null && f.getRangeInfo() != null && sp.getBoolean(Prefs.K_GERAK_PENGGESER, true)) {
            f.performAction(kanan ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            return;
        }
        if (sp.getBoolean(Prefs.K_GERAK_GULIR, true)) gulirLayar(kanan, false);
    }

    private void keFokusUjung(boolean akhir) {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return;
        ArrayList<AccessibilityNodeInfo> daftar = new ArrayList<>();
        kumpulkan(akar, daftar);
        if (daftar.isEmpty()) {
            speaker.ucapkan("tidak ada item", true);
            return;
        }
        if (akhir) {
            for (int i = daftar.size() - 1; i >= 0; i--) {
                if (daftar.get(i).performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)) return;
            }
        } else {
            for (int i = 0; i < daftar.size(); i++) {
                if (daftar.get(i).performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)) return;
            }
        }
    }

    private void bukaMenuUtama() {
        daftarMenu = new ArrayList<>();
        kodeMenu.clear();
        int[][] butir = {
                {Aksi.BACA_LAYAR}, {Aksi.BACA_DARI_SINI}, {Aksi.NOTIFIKASI}, {Aksi.PENGATURAN_CEPAT},
                {Aksi.BERANDA}, {Aksi.TERBARU}, {Aksi.TAMPIL_TEKS}, {Aksi.OCR_LAYAR}, {Aksi.PERINTAH_SUARA},
                {Aksi.INFO}, {Aksi.ULANGI}, {Aksi.SALIN_UCAPAN}, {Aksi.BACA_KLIP}, {Aksi.SCREENSHOT},
                {Aksi.KUNCI_LAYAR}, {Aksi.DAYA}, {Aksi.BISU}
        };
        for (int[] b : butir) tambahMenu(Aksi.NAMA[b[0]], M_AKSI, b[0]);
        Intent i = new Intent(this, MenuActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void bukaDaftarElemen() {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return;
        ArrayList<AccessibilityNodeInfo> daftar = new ArrayList<>();
        kumpulkan(akar, daftar);
        daftarMenu = new ArrayList<>();
        kodeMenu.clear();
        daftarFokus.clear();
        for (AccessibilityNodeInfo n : daftar) {
            String nama = NodeDescriber.describe(this, n);
            if (TextUtils.isEmpty(nama)) continue;
            daftarFokus.add(n);
            tambahMenu(nama, M_FOKUS, daftarFokus.size() - 1);
        }
        if (daftarFokus.isEmpty()) {
            speaker.ucapkan("tidak ada item", true);
            return;
        }
        Intent i = new Intent(this, MenuActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void putarJedaMedia() {
        android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
        if (am == null) return;
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
    }

    @Override
    public boolean onGesture(AccessibilityGestureEvent gestureEvent) {
        int gid = gestureEvent.getGestureId();
        if (speaker != null && modeHuruf && gesturModeHuruf(gid)) return true;
        if (!Prefs.get(this).getBoolean(Prefs.K_MULTI_JARI, true) && banyakJari(gid)
                && gid != GESTURE_4_FINGER_SWIPE_LEFT) return true;
        switch (gid) {
            case GESTURE_2_FINGER_SINGLE_TAP:
                if (speaker != null) speaker.stop();
                return true;
            case GESTURE_2_FINGER_SWIPE_UP:
                return jalankanAksi(Prefs.aksi(this, Prefs.G2_ATAS));
            case GESTURE_2_FINGER_SWIPE_DOWN:
                return jalankanAksi(Prefs.aksi(this, Prefs.G2_BAWAH));
            case GESTURE_2_FINGER_SWIPE_LEFT:
                return jalankanAksi(Prefs.aksi(this, Prefs.G2_KIRI));
            case GESTURE_2_FINGER_SWIPE_RIGHT:
                return jalankanAksi(Prefs.aksi(this, Prefs.G2_KANAN));
            case GESTURE_2_FINGER_DOUBLE_TAP:
                return jalankanAksi(Prefs.aksi(this, Prefs.G2_KETUK2));
            case GESTURE_3_FINGER_SINGLE_TAP:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_KETUK));
            case GESTURE_3_FINGER_DOUBLE_TAP:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_KETUK2));
            case GESTURE_3_FINGER_SWIPE_UP:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_ATAS));
            case GESTURE_3_FINGER_SWIPE_DOWN:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_BAWAH));
            case GESTURE_3_FINGER_SWIPE_LEFT:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_KIRI));
            case GESTURE_3_FINGER_SWIPE_RIGHT:
                return jalankanAksi(Prefs.aksi(this, Prefs.G3_KANAN));
            default:
                // Gestur lain mengikuti tabel gestur di Pengaturan.
                return jalankanAksi(Gestur.aksi(this, gestureEvent.getGestureId()));
        }
    }

    /** Jalankan satu aksi. Mengembalikan false bila aksinya "tidak ada". */
    private boolean jalankanAksi(int id) {
        if (speaker == null) return false;
        switch (id) {
            case Aksi.TIDAK_ADA:
                return false;
            case Aksi.ITEM_MAJU:
                geser(true);
                return true;
            case Aksi.ITEM_MUNDUR:
                geser(false);
                return true;
            case Aksi.GULIR_MAJU:
                gulirLayar(true, false);
                return true;
            case Aksi.GULIR_MUNDUR:
                gulirLayar(false, false);
                return true;
            case Aksi.HALAMAN_BERIKUT:
                gulirLayar(true, true);
                return true;
            case Aksi.HALAMAN_SEBELUMNYA:
                gulirLayar(false, true);
                return true;
            case Aksi.KETUK:
                ketukFokus(false);
                return true;
            case Aksi.KETUK_LAMA:
                ketukFokus(true);
                return true;
            case Aksi.BACA_DARI_SINI:
                bacaLayar(true);
                return true;
            case Aksi.BACA_LAYAR:
                bacaLayar(false);
                return true;
            case Aksi.HENTIKAN_SUARA:
                speaker.stop();
                return true;
            case Aksi.ULANGI:
                speaker.ulangi();
                return true;
            case Aksi.INFO:
                ucapkanInfo();
                return true;
            case Aksi.GRAN_BERIKUT:
                ubahGranularitas(true);
                return true;
            case Aksi.GRAN_SEBELUM:
                ubahGranularitas(false);
                return true;
            case Aksi.BERANDA:
                performGlobalAction(GLOBAL_ACTION_HOME);
                return true;
            case Aksi.KEMBALI:
                efek(Efek.BATAL);
                performGlobalAction(GLOBAL_ACTION_BACK);
                return true;
            case Aksi.TERBARU:
                performGlobalAction(GLOBAL_ACTION_RECENTS);
                return true;
            case Aksi.NOTIFIKASI:
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
                return true;
            case Aksi.PENGATURAN_CEPAT:
                if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
                return true;
            case Aksi.GANTI_NAMA:
                gantiNamaFokus();
                return true;
            case Aksi.SALIN:
                salinNode(sasaranTeks());
                return true;
            case Aksi.TEMPEL:
                tempelNode(sasaranTeks());
                return true;
            case Aksi.POTONG:
                potongNode(sasaranTeks());
                return true;
            case Aksi.PILIH_SEMUA:
                pilihSemuaNode(sasaranTeks());
                return true;
            case Aksi.MENU:
                bukaMenu();
                return true;
            case Aksi.TAMPIL_TEKS:
                tampilkanTeksLayar(false);
                return true;
            case Aksi.PERINTAH_SUARA:
                mulaiPerintahSuara();
                return true;
            case Aksi.OCR_LAYAR:
                ocr(false);
                return true;
            case Aksi.OCR_FOKUS:
                ocr(true);
                return true;
            case Aksi.KUNCI_LAYAR:
                performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                return true;
            case Aksi.LAJU_NAIK:
                ubahLaju(10);
                return true;
            case Aksi.LAJU_TURUN:
                ubahLaju(-10);
                return true;
            case Aksi.SCREENSHOT:
                performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
                return true;
            case Aksi.DAYA:
                performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
                return true;
            case Aksi.BISU:
                if (speaker.bisu()) {
                    speaker.setBisu(false);
                    speaker.ucapkan("suara aktif", true);
                } else {
                    speaker.ucapkan("suara dibisukan", true);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (speaker != null) speaker.setBisu(true);
                        }
                    }, 1200);
                }
                return true;
            case Aksi.SALIN_UCAPAN:
                if (TextUtils.isEmpty(speaker.ucapanTerakhir())) return true;
                salinKeKlip(speaker.ucapanTerakhir());
                speaker.ucapkan("ucapan terakhir disalin", true);
                return true;
            case Aksi.BACA_KLIP:
                bacaKlip();
                return true;
            case Aksi.FOKUS_AKHIR:
                keFokusUjung(true);
                return true;
            case Aksi.FOKUS_AWAL:
                keFokusUjung(false);
                return true;
            case Aksi.KONTEKS_KIRI:
                gerakKonteks(false);
                return true;
            case Aksi.KONTEKS_KANAN:
                gerakKonteks(true);
                return true;
            case Aksi.MENU_UTAMA:
                bukaMenuUtama();
                return true;
            case Aksi.EKSTENSI: {
                Intent e = new Intent(this, PluginActivity.class);
                e.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(e);
                return true;
            }
            case Aksi.MODE_HURUF:
                modeHuruf = true;
                posisiSeg = -1;
                efek(Efek.FOKUS0);
                speaker.ucapkan("mode per karakter. Usap kiri dan kanan pindah karakter, atas dan bawah pindah item, "
                        + "kiri lalu bawah untuk keluar", true);
                return true;
            case Aksi.DAFTAR_ELEMEN:
                bukaDaftarElemen();
                return true;
            case Aksi.MEDIA:
                putarJedaMedia();
                return true;
            case Aksi.MULTI_JARI:
                boolean aktif = !Prefs.get(this).getBoolean(Prefs.K_MULTI_JARI, true);
                Prefs.get(this).edit().putBoolean(Prefs.K_MULTI_JARI, aktif).apply();
                speaker.ucapkan(aktif ? "gestur banyak jari dinyalakan" : "gestur banyak jari dimatikan", true);
                return true;
            default:
                return false;
        }
    }

    private void ubahLaju(int selisih) {
        android.content.SharedPreferences sp = Prefs.get(this);
        int baru = Math.max(50, Math.min(300, sp.getInt(Prefs.K_LAJU, 100) + selisih));
        sp.edit().putInt(Prefs.K_LAJU, baru).apply();
        speaker.terapkanPengaturan();
        speaker.ucapkan("kecepatan " + baru + " persen", true);
    }

    private void bacaKlip() {
        ClipboardManager cm = getSystemService(ClipboardManager.class);
        CharSequence t = null;
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        }
        speaker.ucapkan(TextUtils.isEmpty(t) ? "papan klip kosong" : t.toString(), true);
    }

    // ------------------------------------------------------------------ tombol volume

    // Klik beruntun tombol volume dan tombol headset
    private int jumlahKlik;
    private int kodeKlik;
    private boolean headsetLama;
    private final Runnable selesaiKlik = new Runnable() {
        @Override
        public void run() {
            int kode = kodeKlik, n = jumlahKlik;
            jumlahKlik = 0;
            kodeKlik = 0;
            if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                boolean naik = kode == KeyEvent.KEYCODE_VOLUME_UP;
                int aksi = Aksi.TIDAK_ADA;
                if (n == 2) aksi = Prefs.aksi(TalkBackNovanService.this, naik ? Prefs.VA_KLIK2 : Prefs.VB_KLIK2);
                if (n >= 3) aksi = Prefs.aksi(TalkBackNovanService.this, naik ? Prefs.VA_KLIK3 : Prefs.VB_KLIK3);
                if (aksi != Aksi.TIDAK_ADA) {
                    getarSingkat();
                    jalankanAksi(aksi);
                } else {
                    ubahVolumeMedia(naik, Math.max(1, n));
                }
            } else {
                int aksi = Prefs.aksi(TalkBackNovanService.this, n >= 2 ? Prefs.HS_KLIK2 : Prefs.HS_KLIK);
                jalankanAksi(aksi);
            }
        }
    };
    private final Runnable headsetTahan = new Runnable() {
        @Override
        public void run() {
            headsetLama = true;
            getarSingkat();
            jalankanAksi(Prefs.aksi(TalkBackNovanService.this, Prefs.HS_LAMA));
        }
    };

    private void ubahVolumeMedia(boolean naik, int kali) {
        AudioManager am = getSystemService(AudioManager.class);
        if (am == null) return;
        for (int i = 0; i < kali; i++) {
            am.adjustSuggestedStreamVolume(
                    naik ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                    AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
        }
    }

    private boolean adaAksiVolume(boolean naik) {
        return Prefs.aksi(this, naik ? Prefs.VOL_ATAS : Prefs.VOL_BAWAH) != Aksi.TIDAK_ADA
                || Prefs.aksi(this, naik ? Prefs.VA_KLIK2 : Prefs.VB_KLIK2) != Aksi.TIDAK_ADA
                || Prefs.aksi(this, naik ? Prefs.VA_KLIK3 : Prefs.VB_KLIK3) != Aksi.TIDAK_ADA;
    }

    @Override
    protected boolean onKeyEvent(KeyEvent ev) {
        int kode = ev.getKeyCode();
        if (speaker == null) return false;
        if (PluginManager.saatTombol(ev)) return true;
        if (kode == KeyEvent.KEYCODE_HEADSETHOOK || kode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            return tombolHeadset(ev);
        }
        if (kode != KeyEvent.KEYCODE_VOLUME_UP && kode != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        if (!Prefs.get(this).getBoolean(Prefs.K_VOLUME, true)) return false;
        boolean naik = kode == KeyEvent.KEYCODE_VOLUME_UP;
        String kunci = naik ? Prefs.VOL_ATAS : Prefs.VOL_BAWAH;
        // Bila tidak ada aksi terpasang pada tombol ini, biarkan sistem mengurus volume.
        if (!adaAksiVolume(naik)) return false;

        if (ev.getAction() == KeyEvent.ACTION_DOWN) {
            if (ev.getRepeatCount() == 0) {
                tombolVolume = kode;
                volumeLama = false;
                handler.removeCallbacks(tekanLama);
                if (Prefs.aksi(this, kunci) != Aksi.TIDAK_ADA) handler.postDelayed(tekanLama, 500);
            }
            return true;
        }
        if (ev.getAction() == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(tekanLama);
            boolean lama = volumeLama;
            boolean cocok = tombolVolume == kode;
            tombolVolume = 0;
            volumeLama = false;
            if (!lama && cocok) {
                // Tekan singkat: hitung klik beruntun. Tanpa aksi klik ganda, volume langsung diatur.
                boolean ganda = Prefs.aksi(this, naik ? Prefs.VA_KLIK2 : Prefs.VB_KLIK2) != Aksi.TIDAK_ADA
                        || Prefs.aksi(this, naik ? Prefs.VA_KLIK3 : Prefs.VB_KLIK3) != Aksi.TIDAK_ADA;
                if (!ganda) {
                    ubahVolumeMedia(naik, 1);
                } else {
                    if (kodeKlik != kode) jumlahKlik = 0;
                    kodeKlik = kode;
                    jumlahKlik++;
                    handler.removeCallbacks(selesaiKlik);
                    handler.postDelayed(selesaiKlik, 350);
                }
            }
            return true;
        }
        return true;
    }

    /** Tombol headset: klik = aksi 1, klik dua kali = aksi 2, tahan = aksi 3. */
    private boolean tombolHeadset(KeyEvent ev) {
        if (!Prefs.get(this).getBoolean(Prefs.K_HEADSET, false)) return false;
        if (ev.getAction() == KeyEvent.ACTION_DOWN) {
            if (ev.getRepeatCount() == 0) {
                headsetLama = false;
                handler.removeCallbacks(headsetTahan);
                handler.postDelayed(headsetTahan, 600);
            }
            return true;
        }
        if (ev.getAction() == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(headsetTahan);
            if (!headsetLama) {
                if (kodeKlik != KeyEvent.KEYCODE_HEADSETHOOK) jumlahKlik = 0;
                kodeKlik = KeyEvent.KEYCODE_HEADSETHOOK;
                jumlahKlik++;
                handler.removeCallbacks(selesaiKlik);
                handler.postDelayed(selesaiKlik, 350);
            }
            headsetLama = false;
        }
        return true;
    }

    // ------------------------------------------------------------------ granularitas

    private void ubahGranularitas(boolean maju) {
        int n = Granularitas.NAMA.length;
        int baru = granularitas;
        for (int i = 0; i < n; i++) {
            baru = (baru + (maju ? 1 : n - 1)) % n;
            if (Prefs.jenisAktif(this, baru)) break;
        }
        granularitas = baru;
        posisiSeg = -1;
        efek(Efek.FOKUS0);
        speaker.ucapkan(Granularitas.NAMA[granularitas], true);
    }

    /** Geser kanan/kiri: pindah menurut granularitas yang dipilih. */
    private void geser(boolean maju) {
        switch (granularitas) {
            case Granularitas.PENGGESER: geserPenggeser(maju); return;
            case Granularitas.VOLUME_MEDIA: ubahVolumeMedia(maju); return;
            case Granularitas.KECEPATAN: ubahKecepatan(maju); return;
            case Granularitas.OCR_TERJEMAH: ocr(maju, true); return;
            default: break;
        }
        if (Granularitas.teks(granularitas)) {
            gerakTeks(maju);
        } else {
            pindahFokus(maju, granularitas, 0);
        }
    }

    /** Usap kanan = naikkan nilai penggeser terfokus, kiri = turunkan. */
    private void geserPenggeser(boolean maju) {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        AccessibilityNodeInfo.RangeInfo r = f == null ? null : f.getRangeInfo();
        if (r == null) {
            speaker.ucapkan("elemen ini bukan penggeser", true);
            return;
        }
        float rentang = r.getMax() - r.getMin();
        float langkah = Math.max(1f, rentang / 20f);
        float baru = Math.max(r.getMin(), Math.min(r.getMax(), r.getCurrent() + (maju ? langkah : -langkah)));
        android.os.Bundle b = new android.os.Bundle();
        b.putFloat(AccessibilityNodeInfo.ACTION_ARGUMENT_PROGRESS_VALUE, baru);
        if (f.performAction(android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS.getId(), b)) {
            int persen = rentang > 0 ? Math.round((baru - r.getMin()) * 100f / rentang) : 0;
            speaker.ucapkan(persen + " persen", true);
        } else {
            speaker.ucapkan("penggeser tidak bisa diubah", true);
        }
    }

    private void ubahVolumeMedia(boolean maju) {
        AudioManager am = getSystemService(AudioManager.class);
        if (am == null) return;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                maju ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
        int maks = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        speaker.ucapkan("Volume media " + (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maks) + " persen", true);
    }

    private void ubahKecepatan(boolean maju) {
        SharedPreferences sp = Prefs.get(this);
        int baru = Math.max(50, Math.min(300, sp.getInt(Prefs.K_LAJU, 100) + (maju ? 10 : -10)));
        sp.edit().putInt(Prefs.K_LAJU, baru).apply();
        speaker.ucapkan("Kecepatan ucapan " + baru + " persen", true);
    }

    private static boolean cocok(AccessibilityNodeInfo n, int jenis) {
        String k = NodeDescriber.kelas(n);
        switch (jenis) {
            case Granularitas.JUDUL:
                return n.isHeading();
            case Granularitas.TAUTAN:
                return adaTautan(n.getText()) || k.contains("Link");
            case Granularitas.TOMBOL:
                return k.contains("Button") && !n.isCheckable();
            case Granularitas.KOLOM:
                return n.isEditable();
            case Granularitas.CENTANG:
                return n.isCheckable();
            case Granularitas.GAMBAR:
                return k.contains("Image");
            default:
                return true;
        }
    }

    private static boolean adaTautan(CharSequence cs) {
        if (!(cs instanceof android.text.Spanned)) return false;
        android.text.Spanned sp = (android.text.Spanned) cs;
        return sp.getSpans(0, sp.length(), android.text.style.ClickableSpan.class).length > 0;
    }

    private void pindahFokus(final boolean maju, final int jenis, final int percobaan) {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return;
        ArrayList<AccessibilityNodeInfo> daftar = new ArrayList<>();
        kumpulkan(akar, daftar);
        if (daftar.isEmpty()) {
            speaker.ucapkan("tidak ada item", true);
            return;
        }
        AccessibilityNodeInfo kini = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        int idx = kini == null ? -1 : cariIndeks(daftar, kini);
        int langkah = maju ? 1 : -1;
        int mulai = idx < 0 ? (maju ? 0 : daftar.size() - 1) : idx + langkah;
        for (int i = mulai; i >= 0 && i < daftar.size(); i += langkah) {
            AccessibilityNodeInfo n = daftar.get(i);
            if (!cocok(n, jenis)) continue;
            if (n.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)) return;
        }
        // Habis di layar ini: coba gulir, lalu cari lagi.
        int batas = jenis == Granularitas.ITEM ? 1 : 6;
        if (kini != null && percobaan < batas && gulir(kini, maju)) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (speaker != null) pindahFokus(maju, jenis, percobaan + 1);
                }
            }, 500);
            return;
        }
        efek(Efek.BATAS);
        if (jenis == Granularitas.ITEM) {
            speaker.ucapkan(maju ? "akhir layar" : "awal layar", true);
        } else {
            speaker.ucapkan("tidak ada "
                    + Granularitas.NAMA[jenis].toLowerCase(Locale.getDefault())
                    + (maju ? " berikutnya" : " sebelumnya"), true);
        }
    }

    // ------------------------------------------------------------------ gerak per teks

    private static List<int[]> segmen(String t, int g) {
        ArrayList<int[]> hasil = new ArrayList<>();
        if (g == Granularitas.BARIS || g == Granularitas.PARAGRAF) {
            // Paragraf dipisah baris kosong; bila tidak ada baris kosong, tiap baris dianggap paragraf.
            boolean pakaiKosong = g == Granularitas.PARAGRAF && t.contains("\n\n");
            int awal = 0;
            int i = 0;
            while (i <= t.length()) {
                boolean akhir = i == t.length();
                boolean pisah = !akhir && (pakaiKosong ? t.startsWith("\n\n", i) : t.charAt(i) == '\n');
                if (akhir || pisah) {
                    if (i > awal && !t.substring(awal, i).trim().isEmpty()) hasil.add(new int[]{awal, i});
                    int lompat = pisah ? (pakaiKosong ? 2 : 1) : 1;
                    while (pakaiKosong && pisah && i + lompat < t.length() && t.charAt(i + lompat) == '\n') lompat++;
                    awal = i + lompat;
                    i += lompat;
                    continue;
                }
                i++;
            }
            return hasil;
        }
        BreakIterator bi;
        if (g == Granularitas.KARAKTER) bi = BreakIterator.getCharacterInstance(Locale.getDefault());
        else if (g == Granularitas.KATA) bi = BreakIterator.getWordInstance(Locale.getDefault());
        else bi = BreakIterator.getSentenceInstance(Locale.getDefault());
        bi.setText(t);
        int awal = bi.first();
        for (int akhir = bi.next(); akhir != BreakIterator.DONE; awal = akhir, akhir = bi.next()) {
            String s = t.substring(awal, akhir);
            boolean ambil;
            if (g == Granularitas.KARAKTER) {
                ambil = true;
            } else if (g == Granularitas.KATA) {
                ambil = false;
                for (int i = 0; i < s.length(); i++) {
                    if (Character.isLetterOrDigit(s.charAt(i))) {
                        ambil = true;
                        break;
                    }
                }
            } else {
                ambil = !s.trim().isEmpty();
            }
            if (ambil) hasil.add(new int[]{awal, akhir});
        }
        return hasil;
    }

    private void gerakTeks(boolean maju) {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (f == null) {
            pindahFokus(maju, Granularitas.ITEM, 0);
            return;
        }
        if (f.isPassword()) {
            speaker.ucapkan("kolom kata sandi, isinya tidak dibacakan", true);
            return;
        }
        f.refresh();
        boolean isian = f.isEditable();
        CharSequence cs = f.getText();
        if (!isian && TextUtils.isEmpty(cs)) cs = f.getContentDescription();
        String teks = cs == null ? "" : cs.toString();
        if (teks.isEmpty()) {
            if (isian) speaker.ucapkan("kosong", true);
            else pindahFokus(maju, Granularitas.ITEM, 0);
            return;
        }
        List<int[]> sg = segmen(teks, granularitas);
        int idx = -1;
        if (isian) {
            int kursor = f.getTextSelectionEnd();
            if (kursor < 0 || kursor > teks.length()) kursor = maju ? 0 : teks.length();
            if (maju) {
                for (int i = 0; i < sg.size(); i++) {
                    if (sg.get(i)[0] >= kursor) {
                        idx = i;
                        break;
                    }
                }
            } else {
                for (int i = sg.size() - 1; i >= 0; i--) {
                    if (sg.get(i)[1] <= kursor) {
                        idx = i;
                        break;
                    }
                }
            }
        } else if (!sg.isEmpty()) {
            int baru = posisiSeg < 0 ? (maju ? 0 : sg.size() - 1) : (maju ? posisiSeg + 1 : posisiSeg - 1);
            if (baru >= 0 && baru < sg.size()) idx = baru;
        }
        if (idx < 0) {
            if (isian) {
                speaker.ucapkan(maju ? "akhir teks" : "awal teks", true);
            } else {
                // Teks pada elemen ini habis, lanjut ke elemen berikutnya.
                posisiSeg = -1;
                pindahFokus(maju, Granularitas.ITEM, 0);
            }
            return;
        }
        int[] s = sg.get(idx);
        posisiSeg = idx;
        if (isian) {
            int pos = maju ? s[1] : s[0];
            Bundle b = new Bundle();
            b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos);
            b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos);
            waktuGerakTeks = SystemClock.uptimeMillis();
            f.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b);
        }
        String bagian = teks.substring(s[0], s[1]);
        if (granularitas == Granularitas.KARAKTER) {
            speaker.ucapkan(namaKarakter(bagian), true);
        } else {
            speaker.ucapkan(bagian.trim(), true);
        }
    }

    // ------------------------------------------------------------------ gulir, ketuk, baca

    private boolean gulirDi(AccessibilityNodeInfo n, boolean maju, boolean mendatar) {
        if (n == null || !n.isScrollable()) return false;
        List<AccessibilityNodeInfo.AccessibilityAction> ak = n.getActionList();
        AccessibilityNodeInfo.AccessibilityAction arah = mendatar
                ? (maju ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT)
                : (maju ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP);
        if (ak.contains(arah)) return n.performAction(arah.getId());
        boolean punyaArah = ak.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP)
                || ak.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN)
                || ak.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT)
                || ak.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT);
        if (punyaArah) return false;
        return n.performAction(maju ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    private boolean cariGulir(AccessibilityNodeInfo n, boolean maju, boolean mendatar, int kedalaman) {
        if (n == null || kedalaman > 30) return false;
        if (n.isVisibleToUser() && gulirDi(n, maju, mendatar)) return true;
        for (int i = 0; i < n.getChildCount(); i++) {
            if (cariGulir(n.getChild(i), maju, mendatar, kedalaman + 1)) return true;
        }
        return false;
    }

    private void gulirLayar(boolean maju, boolean mendatar) {
        efek(maju ? Efek.GULIR_BAWAH : Efek.GULIR_ATAS);
        AccessibilityNodeInfo p = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        for (int i = 0; p != null && i < 25; i++) {
            if (gulirDi(p, maju, mendatar)) return;
            p = p.getParent();
        }
        if (cariGulir(getRootInActiveWindow(), maju, mendatar, 0)) return;
        speaker.ucapkan("tidak bisa digulir", true);
    }

    private void ketukFokus(boolean lama) {
        AccessibilityNodeInfo p = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (p == null) p = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (!klikNode(p, lama)) speaker.ucapkan("tidak ada yang bisa diketuk", true);
    }

    private boolean klikNode(AccessibilityNodeInfo p, boolean lama) {
        for (int i = 0; p != null && i < 25; i++) {
            if (lama ? p.isLongClickable() : p.isClickable()) {
                return p.performAction(lama ? AccessibilityNodeInfo.ACTION_LONG_CLICK
                        : AccessibilityNodeInfo.ACTION_CLICK);
            }
            p = p.getParent();
        }
        return false;
    }

    // ------------------------------------------------------------------ salin, tempel, menu

    /** Kolom isian yang sedang aktif, atau elemen yang difokuskan. */
    private AccessibilityNodeInfo sasaranTeks() {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null || !f.isEditable()) f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        return f;
    }

    private void salinKeKlip(String teks) {
        ClipboardManager cm = getSystemService(ClipboardManager.class);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("TalkBack Novan", teks));
    }

    private void salinNode(AccessibilityNodeInfo f) {
        if (f == null) {
            speaker.ucapkan("tidak ada elemen terfokus", true);
            return;
        }
        if (f.isPassword()) {
            speaker.ucapkan("kolom kata sandi tidak bisa disalin", true);
            return;
        }
        f.refresh();
        CharSequence cs = f.getText();
        if (TextUtils.isEmpty(cs)) cs = f.getContentDescription();
        if (f.isEditable() && f.getTextSelectionStart() != f.getTextSelectionEnd()
                && f.performAction(AccessibilityNodeInfo.ACTION_COPY)) {
            speaker.ucapkan("teks terpilih disalin", true);
        } else if (!TextUtils.isEmpty(cs)) {
            salinKeKlip(cs.toString());
            speaker.ucapkan("disalin", true);
        } else {
            speaker.ucapkan("tidak ada teks untuk disalin", true);
        }
    }

    private void tempelNode(AccessibilityNodeInfo f) {
        if (f == null || !f.isEditable()) {
            speaker.ucapkan("tidak ada kolom isian untuk menempel", true);
            return;
        }
        speaker.ucapkan(f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                ? "ditempel" : "gagal menempel", true);
    }

    private void potongNode(AccessibilityNodeInfo f) {
        if (f == null || !f.isEditable()) {
            speaker.ucapkan("tidak ada kolom isian", true);
            return;
        }
        f.refresh();
        if (f.getTextSelectionStart() == f.getTextSelectionEnd()) {
            speaker.ucapkan("tidak ada teks terpilih", true);
            return;
        }
        speaker.ucapkan(f.performAction(AccessibilityNodeInfo.ACTION_CUT)
                ? "dipotong" : "gagal memotong", true);
    }

    private void pilihSemuaNode(AccessibilityNodeInfo f) {
        if (f == null || !f.isEditable()) {
            speaker.ucapkan("tidak ada kolom isian", true);
            return;
        }
        f.refresh();
        CharSequence cs = f.getText();
        if (TextUtils.isEmpty(cs) || f.isPassword()) {
            speaker.ucapkan("tidak ada teks", true);
            return;
        }
        Bundle b = new Bundle();
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0);
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cs.length());
        waktuGerakTeks = SystemClock.uptimeMillis();
        f.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b);
        speaker.ucapkan("semua teks dipilih", true);
    }

    /** Kumpulkan teks seluruh layar; salin ke papan klip atau tampilkan di mode baca. */
    private void tampilkanTeksLayar(boolean salin) {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return;
        ArrayList<AccessibilityNodeInfo> daftar = new ArrayList<>();
        kumpulkan(akar, daftar);
        StringBuilder sb = new StringBuilder();
        for (AccessibilityNodeInfo n : daftar) {
            String s = NodeDescriber.label(n);
            if (TextUtils.isEmpty(s)) s = NodeDescriber.describe(this, n);
            if (TextUtils.isEmpty(s)) continue;
            sb.append(s).append('\n');
            if (sb.length() > 100000) break;
        }
        teksLayar = sb.toString();
        if (salin) {
            if (teksLayar.isEmpty()) {
                speaker.ucapkan("tidak ada teks di layar", true);
            } else {
                salinKeKlip(teksLayar);
                speaker.ucapkan("teks layar disalin", true);
            }
            return;
        }
        Intent i = new Intent(this, BacaActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    // ------------------------------------------------------------------ perintah suara

    private void mulaiPerintahSuara() {
        speaker.stop();
        Intent i = new Intent(this, SuaraActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    static void perintahSuara(final String ucapan) {
        final TalkBackNovanService s = instance;
        if (s == null || ucapan == null) return;
        s.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                s.prosesPerintah(ucapan);
            }
        }, 400);
    }

    private void prosesPerintah(String ucapan) {
        if (speaker == null) return;
        String nama = PerintahSuara.namaAplikasi(ucapan);
        if (nama != null) {
            String label = PerintahSuara.bukaAplikasi(this, nama);
            speaker.ucapkan(label != null ? "membuka " + label : "aplikasi " + nama + " tidak ditemukan", true);
            return;
        }
        int aksi = PerintahSuara.cari(ucapan);
        if (aksi < 0) {
            speaker.ucapkan("perintah tidak dikenal: " + ucapan, true);
            return;
        }
        jalankanAksi(aksi);
    }

    // ------------------------------------------------------------------ OCR

    private void ocr(boolean hanyaFokus) {
        ocr(hanyaFokus, false);
    }

    private void ocr(boolean hanyaFokus, final boolean terjemah) {
        if (!OcrKlien.adaKunci(this)) {
            speaker.ucapkan("Kunci API Gemini atau Groq belum diisi di pengaturan", true);
            return;
        }
        Rect area = null;
        if (hanyaFokus) {
            AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
            if (f == null) {
                speaker.ucapkan("tidak ada elemen terfokus", true);
                return;
            }
            area = new Rect();
            f.getBoundsInScreen(area);
        }
        final Rect potong = area;
        speaker.ucapkan(terjemah ? "menerjemahkan teks" : "mengenali teks", true);
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(),
                new TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(ScreenshotResult hasil) {
                        Bitmap bmp = null;
                        try {
                            HardwareBuffer hb = hasil.getHardwareBuffer();
                            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, hasil.getColorSpace());
                            if (hw != null) bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hb.close();
                        } catch (Exception ignored) {
                        }
                        if (bmp == null) {
                            if (speaker != null) speaker.ucapkan("gagal membaca tangkapan layar", true);
                            return;
                        }
                        if (potong != null) {
                            int l = Math.max(0, potong.left);
                            int a = Math.max(0, potong.top);
                            int r = Math.min(bmp.getWidth(), potong.right);
                            int b = Math.min(bmp.getHeight(), potong.bottom);
                            if (r - l > 8 && b - a > 8) bmp = Bitmap.createBitmap(bmp, l, a, r - l, b - a);
                        }
                        OcrKlien.terjemahSekali = terjemah;
                        OcrKlien.kenali(TalkBackNovanService.this, bmp, new OcrKlien.Hasil() {
                            @Override
                            public void selesai(String teks, String galat) {
                                if (speaker == null) return;
                                if (teks == null) {
                                    speaker.ucapkan(galat, true);
                                    return;
                                }
                                teksLayar = teks;
                                speaker.ucapkan(teks, true);
                                if (Prefs.get(TalkBackNovanService.this).getBoolean(Prefs.K_OCR_BUKA, false)) {
                                    Intent i = new Intent(TalkBackNovanService.this, BacaActivity.class);
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(i);
                                }
                            }
                        });
                    }

                    @Override
                    public void onFailure(int kode) {
                        if (speaker != null) {
                            speaker.ucapkan(kode == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT
                                    ? "tunggu sebentar lalu coba lagi"
                                    : "gagal mengambil tangkapan layar", true);
                        }
                    }
                });
    }

    private void tambahMenu(String nama, int jenis, int nomor) {
        ArrayList<String> baru = new ArrayList<>(daftarMenu);
        baru.add(nama);
        daftarMenu = baru;
        kodeMenu.add(new int[]{jenis, nomor});
    }

    private void bukaMenu() {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (f == null) f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) {
            speaker.ucapkan("tidak ada elemen terfokus", true);
            return;
        }
        sasaranMenu = f;
        daftarMenu = new ArrayList<>();
        kodeMenu.clear();
        aksiKhusus.clear();
        boolean teks = !TextUtils.isEmpty(f.getText()) || !TextUtils.isEmpty(f.getContentDescription());
        AccessibilityNodeInfo p = f;
        boolean bisaKlik = false;
        boolean bisaKlikLama = false;
        for (int i = 0; p != null && i < 25; i++) {
            if (p.isClickable()) bisaKlik = true;
            if (p.isLongClickable()) bisaKlikLama = true;
            p = p.getParent();
        }
        if (bisaKlik) tambahMenu("Ketuk", M_KETUK, 0);
        if (bisaKlikLama) tambahMenu("Ketuk lama", M_KETUK_LAMA, 0);
        if (teks && !f.isPassword()) tambahMenu("Salin teks", M_SALIN, 0);
        if (f.isEditable()) {
            tambahMenu("Tempel", M_TEMPEL, 0);
            tambahMenu("Potong teks terpilih", M_POTONG, 0);
            tambahMenu("Pilih semua teks", M_SEMUA, 0);
        }
        for (AccessibilityNodeInfo.AccessibilityAction a : f.getActionList()) {
            if (a.getLabel() != null) {
                aksiKhusus.add(a);
                tambahMenu(a.getLabel().toString(), M_KHUSUS, aksiKhusus.size() - 1);
            }
        }
        tambahMenu("Baca dari item ini", M_BACA, 0);
        tambahMenu("OCR elemen ini", M_OCR, 0);
        tambahMenu("Ganti nama elemen", M_GANTI, 0);
        tambahMenu("Tampilkan teks layar", M_TEKS, 0);
        Intent i = new Intent(this, MenuActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void laksanakanMenu(int idx) {
        if (speaker == null || idx < 0 || idx >= kodeMenu.size()) return;
        AccessibilityNodeInfo f = sasaranMenu;
        if (f != null) f.refresh();
        int[] k = kodeMenu.get(idx);
        switch (k[0]) {
            case M_KETUK:
                klikNode(f, false);
                break;
            case M_KETUK_LAMA:
                klikNode(f, true);
                break;
            case M_SALIN:
                salinNode(f);
                break;
            case M_TEMPEL:
                tempelNode(f);
                break;
            case M_POTONG:
                potongNode(f);
                break;
            case M_SEMUA:
                pilihSemuaNode(f);
                break;
            case M_KHUSUS:
                if (f != null && k[1] < aksiKhusus.size()) f.performAction(aksiKhusus.get(k[1]).getId());
                break;
            case M_BACA:
                bacaLayar(true);
                break;
            case M_OCR:
                ocr(true);
                break;
            case M_GANTI:
                gantiNamaFokus();
                break;
            case M_TEKS:
                tampilkanTeksLayar(false);
                break;
            case M_AKSI:
                jalankanAksi(k[1]);
                break;
            case M_FOKUS:
                if (k[1] >= 0 && k[1] < daftarFokus.size()) {
                    daftarFokus.get(k[1]).performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
                }
                break;
            default:
                break;
        }
    }

    /** Baca terus-menerus: dari item terfokus (dariFokus) atau dari atas layar. */
    private void bacaLayar(boolean dariFokus) {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return;
        ArrayList<AccessibilityNodeInfo> daftar = new ArrayList<>();
        kumpulkan(akar, daftar);
        int mulai = 0;
        if (dariFokus) {
            AccessibilityNodeInfo kini = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
            int idx = kini == null ? -1 : cariIndeks(daftar, kini);
            if (idx > 0) mulai = idx;
        }
        boolean pertama = true;
        int jumlah = 0;
        for (int i = mulai; i < daftar.size() && jumlah < 200; i++) {
            String s = NodeDescriber.describe(this, daftar.get(i));
            if (TextUtils.isEmpty(s)) continue;
            speaker.ucapkan(s, pertama);
            pertama = false;
            jumlah++;
        }
        if (pertama) speaker.ucapkan("tidak ada yang bisa dibaca", true);
    }

    private void gantiNamaFokus() {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (f == null) {
            speaker.ucapkan("tidak ada elemen terfokus", true);
            return;
        }
        String label = NodeDescriber.label(f);
        if (TextUtils.isEmpty(label)) label = NodeDescriber.describe(this, f);
        String kunci = Rename.kunciUntuk(f, label);
        if (kunci.isEmpty()) {
            speaker.ucapkan("elemen ini tidak bisa diganti namanya", true);
            return;
        }
        Intent i = new Intent(this, GantiNamaActivity.class);
        i.putExtra("kunci", kunci);
        i.putExtra("label", label);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void ucapkanInfo() {
        Date kini = new Date();
        String jam = new SimpleDateFormat("HH.mm", Locale.getDefault()).format(kini);
        String tanggal = new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(kini);
        StringBuilder sb = new StringBuilder("Pukul ").append(jam).append(", ").append(tanggal);
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int skala = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            if (level >= 0 && skala > 0) {
                sb.append(", baterai ").append(level * 100 / skala).append(" persen");
                if (status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL) {
                    sb.append(", sedang mengisi daya");
                }
            }
        }
        speaker.ucapkan(sb.toString(), true);
    }

    private void saatDigulir(AccessibilityEvent e) {
        if (!Prefs.get(this).getBoolean(Prefs.K_GULIR_INFO, true)) return;
        int dari = e.getFromIndex();
        int ke = e.getToIndex();
        int total = e.getItemCount();
        if (dari < 0 || ke < dari || total <= 0) return;
        long sekarang = SystemClock.uptimeMillis();
        if (sekarang - waktuInfoGulir < 600) return;
        waktuInfoGulir = sekarang;
        efek(Efek.GULIR_BAWAH);
        speaker.ucapkan("item " + (dari + 1) + " sampai " + (ke + 1) + " dari " + total, false);
    }

    private boolean gulir(AccessibilityNodeInfo dari, boolean maju) {
        int aksi = maju ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
        AccessibilityNodeInfo p = dari;
        for (int i = 0; p != null && i < 25; i++) {
            if (p.isScrollable() && p.performAction(aksi)) return true;
            p = p.getParent();
        }
        return false;
    }

    private int cariIndeks(List<AccessibilityNodeInfo> daftar, AccessibilityNodeInfo kini) {
        AccessibilityNodeInfo p = kini;
        for (int i = 0; p != null && i < 25; i++) {
            for (int j = 0; j < daftar.size(); j++) {
                if (daftar.get(j).equals(p)) return j;
            }
            p = p.getParent();
        }
        return -1;
    }

    /** Kumpulkan elemen yang layak mendapat fokus, berurutan seperti pohon tampilan. */
    private void kumpulkan(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> keluar) {
        if (n == null || !n.isVisibleToUser()) return;
        boolean berlabel = !TextUtils.isEmpty(n.getText())
                || !TextUtils.isEmpty(n.getContentDescription());
        if (n.isScreenReaderFocusable() || n.isClickable() || n.isLongClickable()
                || n.isCheckable() || n.isEditable() || (n.isFocusable() && berlabel)) {
            keluar.add(n);
            return;
        }
        int jumlah = n.getChildCount();
        if (jumlah == 0) {
            if (berlabel) keluar.add(n);
            return;
        }
        if (!TextUtils.isEmpty(n.getContentDescription())) {
            keluar.add(n);
            return;
        }
        for (int i = 0; i < jumlah; i++) {
            kumpulkan(n.getChild(i), keluar);
        }
    }

    // ------------------------------------------------------------------ bantu

    private void getarSingkat() {
        if (!Prefs.get(this).getBoolean(Prefs.K_GETAR, true)) return;
        Vibrator v = getSystemService(Vibrator.class);
        if (v != null && v.hasVibrator()) {
            android.content.SharedPreferences sp = Prefs.get(this);
            v.vibrate(VibrationEffect.createOneShot(sp.getInt(Prefs.K_GETAR_LAMA, 15),
                    sp.getInt(Prefs.K_GETAR_KUAT, 32)));
        }
    }

    private static String gabung(List<CharSequence> daftar) {
        if (daftar == null || daftar.isEmpty()) return "";
        ArrayList<String> bagian = new ArrayList<>();
        for (CharSequence c : daftar) {
            if (!TextUtils.isEmpty(c)) bagian.add(c.toString());
        }
        return TextUtils.join(", ", bagian);
    }

    private String labelAplikasi(CharSequence paket) {
        if (paket == null) return "";
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(paket.toString(), 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception ex) {
            return "";
        }
    }

    // ------------------------------------------------------------------ API untuk plugin Lua
    // Nama metode mengikuti JieShuo agar skrip bisa memanggil service.speak(...) dan sejenisnya.

    public void speak(String teks) {
        if (speaker != null) speaker.ucapkan(teks, true);
    }

    public void rawSpeak(String teks) {
        speak(teks);
    }

    public void asyncSpeak(String teks) {
        speak(teks);
    }

    public void appendSpeak(String teks) {
        if (speaker != null) speaker.ucapkan(teks, false);
    }

    public void asyncAppendSpeak(String teks) {
        appendSpeak(teks);
    }

    public void stop() {
        if (speaker != null) speaker.stop();
    }

    public void asyncStop() {
        stop();
    }

    public void allStop() {
        stop();
    }

    public boolean isSpeaking() {
        return speaker != null && speaker.sedangBicara();
    }

    public String getLastSpeakText() {
        return speaker == null ? "" : speaker.ucapanTerakhir();
    }

    public boolean isScreenOn() {
        android.os.PowerManager pm = getSystemService(android.os.PowerManager.class);
        return pm != null && pm.isInteractive();
    }

    public int getBatteryLevel() {
        android.os.BatteryManager bm = getSystemService(android.os.BatteryManager.class);
        return bm == null ? -1 : bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
    }

    /** Seluruh teks yang terlihat di layar, satu baris per elemen. */
    public String getAllText() {
        AccessibilityNodeInfo akar = getRootInActiveWindow();
        if (akar == null) return "";
        StringBuilder sb = new StringBuilder();
        kumpulTeks(akar, sb, 0);
        return sb.toString().trim();
    }

    private void kumpulTeks(AccessibilityNodeInfo n, StringBuilder sb, int dalam) {
        if (n == null || dalam > 60 || !n.isVisibleToUser()) return;
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        if (t != null && t.length() > 0) sb.append(t).append('\n');
        for (int i = 0; i < n.getChildCount(); i++) kumpulTeks(n.getChild(i), sb, dalam + 1);
    }

    // ------------------------------------------------------------------ layar hidup/mati

    private android.content.BroadcastReceiver penerimaLayar;

    private void pasangPenerimaLayar() {
        if (penerimaLayar != null) return;
        penerimaLayar = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(android.content.Context c, Intent i) {
                if (speaker == null || i == null || i.getAction() == null) return;
                SharedPreferences sp = Prefs.get(TalkBackNovanService.this);
                if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                    if (!sp.getBoolean(Prefs.K_LAYAR_HIDUP, true)) return;
                    StringBuilder sb = new StringBuilder("Layar hidup, pukul ");
                    sb.append(new SimpleDateFormat("HH.mm", Locale.getDefault()).format(new Date()));
                    if (sp.getBoolean(Prefs.K_LAYAR_BATERAI, false)) {
                        int persen = getBatteryLevel();
                        if (persen >= 0) sb.append(", baterai ").append(persen).append(" persen");
                    }
                    speaker.ucapkan(sb.toString(), true);
                } else if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                    if (sp.getBoolean(Prefs.K_LAYAR_MATI, true)) speaker.ucapkan("Layar mati", true);
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(penerimaLayar, f);
    }

    private void lepasPenerimaLayar() {
        if (penerimaLayar == null) return;
        try {
            unregisterReceiver(penerimaLayar);
        } catch (Exception ignore) {
        }
        penerimaLayar = null;
    }

    // ------------------------------------------------------------------ aturan pemberitahuan

    static volatile boolean sedangMenyentuh;

    /** True bila pemberitahuan dari paket ini tidak boleh dibacakan sekarang (daftar putih, sentuh, telepon). */
    static boolean notifDiam(Context c, String paket) {
        SharedPreferences sp = Prefs.get(c);
        java.util.Set<String> putih = Prefs.daftar(c, Prefs.K_PUTIH_NOTIF);
        if (!putih.isEmpty() && !putih.contains(paket)) return true;
        if (sp.getBoolean(Prefs.K_NOTIF_DIAM_SENTUH, false) && sedangMenyentuh) return true;
        if (sp.getBoolean(Prefs.K_NOTIF_DIAM_TELEPON, false)) {
            AudioManager am = c.getSystemService(AudioManager.class);
            if (am != null) {
                int m = am.getMode();
                if (m == AudioManager.MODE_RINGTONE || m == AudioManager.MODE_IN_CALL
                        || m == AudioManager.MODE_IN_COMMUNICATION) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ jelajah sentuh dan keyboard

    private static boolean layakFokus(AccessibilityNodeInfo n) {
        if (n == null || !n.isVisibleToUser()) return false;
        boolean berlabel = !TextUtils.isEmpty(n.getText()) || !TextUtils.isEmpty(n.getContentDescription());
        if (n.isScreenReaderFocusable() || n.isClickable() || n.isLongClickable()
                || n.isCheckable() || n.isEditable() || (n.isFocusable() && berlabel)) return true;
        if (!TextUtils.isEmpty(n.getContentDescription())) return true;
        return n.getChildCount() == 0 && berlabel;
    }

    /**
     * Meraba layar: layanan jelajah sentuh wajib memindahkan fokus aksesibilitas ke elemen
     * di bawah jari (seperti TalkBack); sistem hanya mengirim peristiwa melayang (hover).
     */
    private void saatJelajahSentuh(AccessibilityEvent e) {
        AccessibilityNodeInfo sumber = e.getSource();
        if (sumber == null) return;
        AccessibilityNodeInfo terbaik = null;
        AccessibilityNodeInfo kini = sumber;
        for (int i = 0; kini != null && i < 12; i++) {
            if (layakFokus(kini)) terbaik = kini;
            AccessibilityNodeInfo induk = kini.getParent();
            if (induk == null || induk.isScrollable()) break;
            kini = induk;
        }
        if (terbaik == null || terbaik.isAccessibilityFocused()) return;
        terbaik.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
    }

    private static boolean dalamKeyboard(AccessibilityNodeInfo n) {
        android.view.accessibility.AccessibilityWindowInfo w = n.getWindow();
        return w != null && w.getType() == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD;
    }

    private static final String[] CONTOH_KATA = {
            "apel", "buku", "cacing", "domba", "elang", "foto", "gajah", "hari", "ikan", "jeruk",
            "kuda", "lampu", "mata", "nanas", "obat", "payung", "qari", "rumah", "sapi", "tikus",
            "ular", "vas", "waktu", "xilofon", "yoyo", "zebra"};

    private static String contohKata(char huruf) {
        char k = Character.toLowerCase(huruf);
        return (k >= 'a' && k <= 'z') ? CONTOH_KATA[k - 'a'] : null;
    }
}
