package id.ytplayer.music

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.extractor.metadata.id3.InternalFrame
import androidx.media3.extractor.metadata.id3.TextInformationFrame
import androidx.media3.extractor.metadata.vorbis.VorbisComment
import kotlin.math.abs

/**
 * ReplayGain: menyetarakan kekerasan suara antar lagu. Nilai dibaca dari tag lagu
 * (ID3 TXXX, komentar Vorbis/FLAC/Opus, dan tag bebas iTunes di M4A), lalu dikirim ke
 * mesin Novan sebagai penguatan 64-bit sebelum equalizer dan limiter.
 */
object ReplayGain {

    class Info(val trackDb: Double?, val albumDb: Double?)

    private val num = Regex("-?\\d+(?:[.,]\\d+)?")

    private fun parse(s: String?): Double? {
        val m = num.find(s ?: return null) ?: return null
        return m.value.replace(',', '.').toDoubleOrNull()
    }

    @OptIn(UnstableApi::class)
    fun read(tracks: Tracks): Info {
        var track: Double? = null
        var album: Double? = null
        var r128Track: Double? = null
        var r128Album: Double? = null

        fun put(key: String?, value: String?) {
            when (key?.trim()?.uppercase()) {
                "REPLAYGAIN_TRACK_GAIN" -> if (track == null) track = parse(value)
                "REPLAYGAIN_ALBUM_GAIN" -> if (album == null) album = parse(value)
                // Opus: Q7.8 dB terhadap -23 LUFS; +5 dB menyamakannya dengan acuan ReplayGain (-18 LUFS)
                "R128_TRACK_GAIN" -> if (r128Track == null) r128Track = parse(value)?.let { it / 256.0 + 5.0 }
                "R128_ALBUM_GAIN" -> if (r128Album == null) r128Album = parse(value)?.let { it / 256.0 + 5.0 }
            }
        }

        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                val md = g.getTrackFormat(i).metadata ?: continue
                for (k in 0 until md.length()) {
                    when (val e = md.get(k)) {
                        is TextInformationFrame -> if (e.id == "TXXX") put(e.description, e.values.firstOrNull())
                        is VorbisComment -> put(e.key, e.value)
                        is InternalFrame -> put(e.description, e.text)
                        else -> {}
                    }
                }
            }
        }
        return Info(track ?: r128Track, album ?: r128Album)
    }

    /** Penguatan (dB) untuk lagu ini menurut pengaturan; 0 bila ReplayGain mati. */
    fun gainDb(ctx: Context, info: Info?): Double {
        val p = Prefs.of(ctx)
        val mode = p.getString(Prefs.RG_MODE, "off") ?: "off"
        if (mode == "off") return 0.0
        val tagged = when (mode) {
            "album" -> info?.albumDb ?: info?.trackDb
            else -> info?.trackDb ?: info?.albumDb
        }
        val db = if (tagged != null) {
            tagged + (p.getString(Prefs.RG_PREAMP, "0")?.toDoubleOrNull() ?: 0.0)
        } else {
            p.getString(Prefs.RG_UNTAGGED, "0")?.toDoubleOrNull() ?: 0.0
        }
        return db.coerceIn(-24.0, 24.0).let { if (abs(it) < 0.01) 0.0 else it }
    }
}
