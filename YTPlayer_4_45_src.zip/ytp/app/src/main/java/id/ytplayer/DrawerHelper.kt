package id.ytplayer

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.CheckedTextView
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout

/**
 * Menu laci di pojok kiri atas, dipakai bersama oleh tampilan YT Player dan Music Player:
 * YT Player, YouTube Music, Music Player (yang aktif tercentang), Unduhan, dan Pengaturan.
 */
object DrawerHelper {

    fun setup(act: Activity, current: String) {
        val drawer = act.findViewById<DrawerLayout>(R.id.drawerLayout) ?: return
        val menu = act.findViewById<View>(R.id.btnMenu)
        val yt = act.findViewById<CheckedTextView>(R.id.drawerYt)
        val ytm = act.findViewById<CheckedTextView>(R.id.drawerYtm)
        val music = act.findViewById<CheckedTextView>(R.id.drawerMusic)
        val settings = act.findViewById<View>(R.id.drawerSettings)
        ViewCompat.setAccessibilityHeading(act.findViewById(R.id.drawerTitle), true)

        // Status centang dan posisi laci jangan dipulihkan sistem setelah recreate(): pemulihan itu
        // mengembalikan centang lama sehingga terlihat belum pindah dan harus klik dua kali.
        yt.isSaveEnabled = false
        ytm.isSaveEnabled = false
        music.isSaveEnabled = false
        drawer.isSaveEnabled = false

        fun refreshChecks(selected: String = current) {
            yt.isChecked = selected == Store.MODE_YT
            ytm.isChecked = selected == Store.MODE_YTM
            music.isChecked = selected == Store.MODE_MUSIC
        }
        refreshChecks()

        menu.setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        yt.setOnClickListener {
            if (current == Store.MODE_YT) {
                drawer.closeDrawers()
                return@setOnClickListener
            }
            refreshChecks(Store.MODE_YT)
            drawer.closeDrawers()
            switchTo(act, Store.MODE_YT)
        }
        ytm.setOnClickListener {
            if (current == Store.MODE_YTM) {
                drawer.closeDrawers()
                return@setOnClickListener
            }
            refreshChecks(Store.MODE_YTM)
            drawer.closeDrawers()
            switchTo(act, Store.MODE_YTM)
        }
        music.setOnClickListener {
            if (current == Store.MODE_MUSIC) {
                drawer.closeDrawers()
                return@setOnClickListener
            }
            refreshChecks(Store.MODE_MUSIC)
            drawer.closeDrawers()
            switchTo(act, Store.MODE_MUSIC)
        }
        settings.setOnClickListener {
            drawer.closeDrawers()
            act.startActivity(Intent(act, AppSettingsActivity::class.java))
            @Suppress("DEPRECATION")
            act.overridePendingTransition(0, 0)
        }
        act.findViewById<View>(R.id.drawerDownloads)?.setOnClickListener {
            drawer.closeDrawers()
            act.startActivity(Intent(act, DownloadsActivity::class.java))
            @Suppress("DEPRECATION")
            act.overridePendingTransition(0, 0)
        }
        registerBack(act, drawer)
    }

    /** Tombol kembali menutup laci lebih dulu bila sedang terbuka. */
    private fun registerBack(act: Activity, drawer: DrawerLayout) {
        if (act is ComponentActivity) {
            val cb = object : OnBackPressedCallback(false) {
                override fun handleOnBackPressed() { drawer.closeDrawers() }
            }
            act.onBackPressedDispatcher.addCallback(act, cb)
            drawer.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
                override fun onDrawerOpened(drawerView: View) { cb.isEnabled = true }
                override fun onDrawerClosed(drawerView: View) { cb.isEnabled = false }
            })
        } else if (Build.VERSION.SDK_INT >= 33) {
            val cb = OnBackInvokedCallback { drawer.closeDrawers() }
            val d = act.onBackInvokedDispatcher
            drawer.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
                override fun onDrawerOpened(drawerView: View) {
                    d.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
                }
                override fun onDrawerClosed(drawerView: View) { d.unregisterOnBackInvokedCallback(cb) }
            })
        }
    }

    /** Untuk Android di bawah 13: panggil dari onBackPressed(); true bila laci tertutup oleh tombol ini. */
    fun closeIfOpen(act: Activity): Boolean {
        val drawer = act.findViewById<DrawerLayout>(R.id.drawerLayout) ?: return false
        if (!drawer.isDrawerOpen(GravityCompat.START)) return false
        drawer.closeDrawers()
        return true
    }

    /** Tampilan lama yang menunggu untuk ditutup setelah tampilan tujuan benar-benar tampil. */
    private var leaving: Activity? = null

    /** True sesaat sebelum recreate() perpindahan mode: status tampilan lama tidak boleh dipulihkan. */
    @Volatile
    var switching = false

    private fun switchTo(act: Activity, mode: String) {
        Store.setAppMode(act, mode)
        // YT Player dan YouTube Music memakai layar yang sama: cukup dibuat ulang dengan mode baru.
        if (act is MainActivity) {
            if (mode != Store.MODE_MUSIC) {
                switching = true
                act.recreate()
                return
            }
        }
        // Satu pemutar saja yang aktif: hentikan layanan pemutar milik tampilan yang ditinggalkan.
        try {
            if (mode == Store.MODE_MUSIC) {
                act.stopService(Intent(act, PlaybackService::class.java))
            } else {
                act.stopService(Intent(act, id.ytplayer.music.PlaybackService::class.java))
            }
        } catch (_: Exception) {
        }
        // Tampilan lama TIDAK ditutup di sini. Menutupnya bersamaan dengan membuka tampilan baru
        // membuat sebagian HP sempat menampilkan layar utama. Ia ditutup sendiri di onStop()
        // (lihat finishIfLeaving), yaitu setelah tampilan tujuan sudah tampil di layar.
        leaving = act
        act.startActivity(launchIntent(act, mode))
        @Suppress("DEPRECATION")
        act.overridePendingTransition(0, 0)
    }

    /** Dipanggil dari onStop() tiap tampilan utama: tutup tampilan lama setelah tujuan tampil. */
    fun finishIfLeaving(act: Activity) {
        if (leaving === act) {
            leaving = null
            if (!act.isFinishing) {
                act.finish()
                @Suppress("DEPRECATION")
                act.overridePendingTransition(0, 0)
            }
        }
    }

    /** CLEAR_TOP + SINGLE_TOP: bila tampilan itu sudah ada di tumpukan, dipakai ulang (tidak dobel). */
    fun launchIntent(act: Activity, mode: String): Intent =
        (if (mode == Store.MODE_MUSIC) Intent(act, id.ytplayer.music.MainActivity::class.java)
        else Intent(act, MainActivity::class.java))
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
}
