package com.novan.audiolabnovan.karaoke

import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Pemformat teks yang enak dibacakan pembaca layar. */
object Teks {
    private val id: Locale = Locale.forLanguageTag("id-ID")

    fun durasi(ms: Long): String {
        val total = ms / 1000
        val j = total / 3600
        val m = (total % 3600) / 60
        val d = total % 60
        val sb = StringBuilder()
        if (j > 0) sb.append(j).append(" jam ")
        if (m > 0) sb.append(m).append(" menit ")
        if (d > 0 || sb.isEmpty()) sb.append(d).append(" detik")
        return sb.toString().trim()
    }

    fun ukuran(b: Long): String {
        val kb = b / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> String.format(id, "%.2f GB", gb)
            mb >= 1 -> String.format(id, "%.1f MB", mb)
            else -> String.format(id, "%.0f KB", kb)
        }
    }

    fun tanggal(ms: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, id).format(Date(ms))

    fun tingkat(puncak: Int): String {
        val persen = (puncak * 100L / 32767L).toInt().coerceIn(0, 100)
        val kata = when {
            persen < 3 -> "hampir tidak ada suara"
            persen < 20 -> "pelan"
            persen < 60 -> "sedang"
            persen < 90 -> "keras"
            else -> "sangat keras, mungkin terlalu dekat"
        }
        return "Tingkat suara $kata, $persen persen"
    }
}
