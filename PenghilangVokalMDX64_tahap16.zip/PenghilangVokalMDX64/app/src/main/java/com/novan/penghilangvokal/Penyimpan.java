package com.novan.penghilangvokal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Menyimpan, mengganti nama, dan menghapus berkas hasil di folder Music/Penghilang Vokal. */
final class Penyimpan {

    /** Satu berkas hasil: nama tampilan dan alamat (content://) untuk diputar, dibagikan, dll. */
    static final class Hasil {
        final String nama;
        final Uri uri;

        Hasil(String nama, Uri uri) {
            this.nama = nama;
            this.uri = uri;
        }
    }

    private Penyimpan() { }

    /** Panggil dari utas latar belakang (pada Android 9 ke bawah menunggu pemindaian media). */
    static Hasil simpan(Context ctx, File src, String originalName, String akhiran) throws Exception {
        String base = originalName;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        String outName = base + akhiran;

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Audio.Media.DISPLAY_NAME, outName);
            cv.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg");
            cv.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Penghilang Vokal");
            cv.put(MediaStore.Audio.Media.IS_PENDING, 1);
            Uri target = ctx.getContentResolver().insert(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv);
            if (target == null) throw new Exception("tidak bisa membuat berkas");
            try (InputStream in = new FileInputStream(src);
                 OutputStream out = ctx.getContentResolver().openOutputStream(target)) {
                salin(in, out);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            ctx.getContentResolver().update(target, done, null, null);
            return new Hasil(namaDari(ctx, target, outName), target);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_MUSIC), "Penghilang Vokal");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("tidak bisa membuat folder");
            File dest = new File(dir, outName);
            try (InputStream in = new FileInputStream(src);
                 OutputStream out = new FileOutputStream(dest)) {
                salin(in, out);
            }
            Uri u = pindai(ctx, dest.getAbsolutePath());
            return new Hasil(outName, u != null ? u : Uri.fromFile(dest));
        }
    }

    /** Mengganti nama berkas (tanpa/dengan .mp3). Panggil dari utas latar belakang. */
    static Hasil ubahNama(Context ctx, Hasil h, String namaBaru) throws Exception {
        String bersih = namaBaru.replaceAll("[\\\\/:*?\"<>|]", "").trim();
        if (bersih.isEmpty()) throw new Exception("nama kosong");
        String nama = bersih.toLowerCase().endsWith(".mp3") ? bersih : bersih + ".mp3";

        if ("file".equals(h.uri.getScheme())) {
            File lama = new File(h.uri.getPath());
            File baru = new File(lama.getParentFile(), nama);
            if (baru.exists()) throw new Exception("nama sudah dipakai");
            if (!lama.renameTo(baru)) throw new Exception("gagal mengganti nama");
            return new Hasil(nama, Uri.fromFile(baru));
        }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Audio.Media.DISPLAY_NAME, nama);
            int n = ctx.getContentResolver().update(h.uri, cv, null, null);
            if (n <= 0) throw new Exception("gagal mengganti nama");
            return new Hasil(namaDari(ctx, h.uri, nama), h.uri);
        }
        String path = kolom(ctx, h.uri, "_data");
        if (path == null) throw new Exception("berkas tidak ditemukan");
        File lama = new File(path);
        File baru = new File(lama.getParentFile(), nama);
        if (baru.exists()) throw new Exception("nama sudah dipakai");
        if (!lama.renameTo(baru)) throw new Exception("gagal mengganti nama");
        try {
            ctx.getContentResolver().delete(h.uri, null, null);
        } catch (Throwable ignored) { }
        Uri u = pindai(ctx, baru.getAbsolutePath());
        return new Hasil(nama, u != null ? u : Uri.fromFile(baru));
    }

    static void hapus(Context ctx, Hasil h) throws Exception {
        if ("file".equals(h.uri.getScheme())) {
            if (!new File(h.uri.getPath()).delete()) throw new Exception("tidak bisa menghapus");
            return;
        }
        int n = ctx.getContentResolver().delete(h.uri, null, null);
        if (n <= 0) throw new Exception("tidak bisa menghapus");
    }

    private static String namaDari(Context ctx, Uri uri, String cadangan) {
        String n = kolom(ctx, uri, MediaStore.Audio.Media.DISPLAY_NAME);
        return n != null ? n : cadangan;
    }

    private static String kolom(Context ctx, Uri uri, String kolom) {
        try (Cursor c = ctx.getContentResolver().query(uri, new String[]{kolom}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Throwable ignored) { }
        return null;
    }

    private static Uri pindai(Context ctx, String path) {
        final Uri[] hasil = new Uri[1];
        final CountDownLatch tunggu = new CountDownLatch(1);
        MediaScannerConnection.scanFile(ctx, new String[]{path}, new String[]{"audio/mpeg"},
                (p, u) -> {
                    hasil[0] = u;
                    tunggu.countDown();
                });
        try {
            tunggu.await(5, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) { }
        return hasil[0];
    }

    private static void salin(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }
}
