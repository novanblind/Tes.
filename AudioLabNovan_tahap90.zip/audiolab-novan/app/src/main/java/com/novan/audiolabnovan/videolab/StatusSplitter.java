package com.novan.audiolabnovan.videolab;

import android.app.Activity;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Memotong satu klip video menjadi beberapa bagian dengan durasi sama, satu per satu,
 * lalu menyimpan tiap bagian ke galeri dengan nama berurutan supaya bisa dibagikan ke
 * Status WhatsApp dengan urutan yang benar.
 *
 * Semua pemanggilan harus dari thread utama. Hanya rentang awal sampai akhir klip yang
 * dipakai; efek lain pada klip tidak ikut diterapkan.
 */
final class StatusSplitter {

    interface Callback {
        /** Satu bagian selesai dan sudah tersimpan. */
        void onPartSaved(int done, int total);

        /** Semua selesai, dibatalkan, atau berhenti karena galat (error tidak null). */
        void onFinished(List<Uri> saved, int total, boolean cancelled, String error);
    }

    /**
     * Kalau sisa di akhir lebih pendek dari ini, dua bagian terakhir dibagi rata supaya tidak ada
     * potongan yang terlalu pendek dan tidak ada bagian yang melewati durasi yang dipilih.
     */
    private static final long MIN_TAIL_MS = 2000;

    private final Activity act;
    private final Callback cb;
    private long[][] plan = new long[0][];
    private Clip src;
    private String stamp = "";
    private int index = 0;
    private final List<Uri> saved = new ArrayList<>();
    private Transformer transformer;
    private File tmp;
    private boolean running = false;
    private boolean cancelled = false;

    StatusSplitter(Activity act, Callback cb) {
        this.act = act;
        this.cb = cb;
    }

    /**
     * Menyusun rencana potong: tiap baris {awalMs, akhirMs} pada video sumber.
     * Tidak ada bagian yang lebih panjang dari pieceMs, supaya tetap muat di batas Status WhatsApp.
     */
    static long[][] plan(long startMs, long endMs, long pieceMs) {
        long len = endMs - startMs;
        if (pieceMs <= 0 || len <= pieceMs) return new long[][]{{startMs, endMs}};
        int n = (int) ((len + pieceMs - 1) / pieceMs);
        long rem = len - (n - 1) * pieceMs;
        long[] size = new long[n];
        for (int i = 0; i < n - 1; i++) size[i] = pieceMs;
        size[n - 1] = rem;
        if (rem < MIN_TAIL_MS && n >= 2) {
            long both = pieceMs + rem;
            size[n - 2] = both / 2;
            size[n - 1] = both - both / 2;
        }
        long[][] r = new long[n][2];
        long pos = startMs;
        for (int i = 0; i < n; i++) {
            r[i][0] = pos;
            pos += size[i];
            r[i][1] = (i == n - 1) ? endMs : pos;
        }
        return r;
    }

    boolean isRunning() { return running; }

    int totalParts() { return plan.length; }

    int currentPart() { return Math.min(index + 1, plan.length); }

    /** Kemajuan keseluruhan 0 sampai 100. */
    int overallPercent() {
        if (!running || plan.length == 0) return 0;
        int p = 0;
        Transformer t = transformer;
        if (t != null) {
            ProgressHolder ph = new ProgressHolder();
            if (t.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) p = ph.progress;
        }
        return Math.min(100, (index * 100 + p) / plan.length);
    }

    void start(Clip clip, long[][] plan, String stamp) {
        this.src = clip;
        this.plan = plan;
        this.stamp = stamp;
        this.index = 0;
        this.saved.clear();
        this.cancelled = false;
        this.running = true;
        runPart();
    }

    void cancel() {
        if (!running) return;
        cancelled = true;
        Transformer t = transformer;
        if (t != null) {
            transformer = null;
            try { t.cancel(); } catch (Exception ignored) { }
            if (tmp != null) tmp.delete();
            finish(null);
        }
        // kalau sedang menyimpan, selesai di runPart() setelah penyimpanan itu
    }

    private void runPart() {
        if (cancelled || index >= plan.length) { finish(null); return; }
        long[] r = plan[index];
        tmp = new File(act.getCacheDir(), "split_" + System.currentTimeMillis() + ".mp4");
        MediaItem mi = new MediaItem.Builder()
                .setUri(src.uri)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(r[0])
                        .setEndPositionMs(r[1])
                        .build())
                .build();
        EditedMediaItem emi = new EditedMediaItem.Builder(mi).build();
        final File out = tmp;
        Transformer t = new Transformer.Builder(act)
                .setVideoMimeType(MimeTypes.VIDEO_H264)   // paling kompatibel untuk WhatsApp
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult result) {
                        transformer = null;
                        savePart(out);
                    }

                    @Override
                    public void onError(Composition composition, ExportResult result, ExportException e) {
                        transformer = null;
                        out.delete();
                        finish("bagian " + (index + 1) + " gagal dipotong: " + e.getMessage());
                    }
                })
                .build();
        transformer = t;
        try {
            t.start(emi, out.getAbsolutePath());
        } catch (Exception e) {
            transformer = null;
            out.delete();
            finish("tidak bisa memulai pemotongan: " + e.getMessage());
        }
    }

    private void savePart(final File f) {
        final int part = index;
        new Thread(() -> {
            Uri u = null;
            String err = null;
            try {
                u = saveFile(f, nameFor(part));
            } catch (Exception e) {
                err = e.getMessage();
            }
            f.delete();
            final Uri fu = u;
            final String fe = err;
            act.runOnUiThread(() -> {
                if (fu == null) {
                    finish("bagian " + (part + 1) + " gagal disimpan: " + fe);
                    return;
                }
                saved.add(fu);
                cb.onPartSaved(saved.size(), plan.length);
                index++;
                runPart();
            });
        }).start();
    }

    private void finish(String error) {
        if (!running) return;
        running = false;
        transformer = null;
        cb.onFinished(new ArrayList<>(saved), plan.length, cancelled && error == null, error);
    }

    /** Nama berkas diawali "Bagian N", lalu jumlah bagian, tanggal, dan jam potongan. */
    private String nameFor(int part) {
        int w = String.valueOf(plan.length).length();
        return String.format(Locale.US, "Bagian %0" + w + "d dari %d - %s.mp4",
                part + 1, plan.length, stamp);
    }

    /** Tiap kali potong otomatis, hasilnya masuk ke subfolder sendiri bernama tanggal dan jam. */
    private String folderName() {
        return stamp.replaceAll("[\\\\/:*?\"<>|]", "-");
    }

    private Uri saveFile(File src, String name) throws Exception {
        final String mime = "video/mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/VideoLab/Status WhatsApp/" + folderName());
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = act.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("penyimpanan menolak berkas baru");
            try (OutputStream os = act.getContentResolver().openOutputStream(uri);
                 InputStream is = new FileInputStream(src)) {
                if (os == null) throw new IOException("berkas tujuan tidak bisa dibuka");
                copy(is, os);
            } catch (Exception e) {
                try { act.getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            act.getContentResolver().update(uri, done, null, null);
            return uri;
        }
        File base = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        File dir = new File(new File(new File(base, "VideoLab"), "Status WhatsApp"), folderName());
        dir.mkdirs();
        File dst = new File(dir, name);
        try (OutputStream os = new FileOutputStream(dst);
             InputStream is = new FileInputStream(src)) {
            copy(is, os);
        }
        final Uri[] result = new Uri[1];
        final CountDownLatch latch = new CountDownLatch(1);
        MediaScannerConnection.scanFile(act, new String[]{dst.getAbsolutePath()}, new String[]{mime},
                (path, scanned) -> {
                    result[0] = scanned;
                    latch.countDown();
                });
        latch.await(10, TimeUnit.SECONDS);
        if (result[0] == null) throw new IOException("berkas belum terdaftar di galeri");
        return result[0];
    }

    private static void copy(InputStream is, OutputStream os) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
    }
}
