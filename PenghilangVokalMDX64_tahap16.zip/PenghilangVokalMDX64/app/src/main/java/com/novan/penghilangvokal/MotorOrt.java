package com.novan.penghilangvokal;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.Collections;

/**
 * Menjalankan model MDX-Net (ONNX) dengan ONNX Runtime di CPU.
 *
 * Model ini memakai tensor antara yang sangat besar (puluhan kanal x 3072 x 256), jadi memori
 * adalah hambatan utama. Karena itu penampung memori (arena) dan pola memori dimatikan supaya
 * tiap tensor dilepas begitu selesai dipakai, dan tata letak memori khusus (NCHWc) tidak dibuat.
 * Bila memori tetap habis (std::bad_alloc), sesi dibuat ulang dengan pengaturan yang lebih hemat
 * (utas lebih sedikit, optimasi lebih ringan) lalu potongan yang sama diulang.
 */
final class MotorOrt implements MdxNet.Motor, AutoCloseable {

    private static final long[] BENTUK = {1, 4, MdxDsp.DIM_F, MdxDsp.DIM_T};
    /** Tingkat hemat memori terakhir: 0 normal, 1 hemat, 2 paling hemat. */
    private static final int TINGKAT_MAKS = 2;

    private final OrtEnvironment env;
    private final File model;
    private final int utasAwal;
    private OrtSession session;
    private String namaMasuk;
    private int tingkat = 0;
    private final FloatBuffer buf;

    MotorOrt(File model, int utas) throws Exception {
        this.model = model;
        this.utasAwal = Math.max(1, utas);
        env = OrtEnvironment.getEnvironment();
        buat(0);
        NodeInfo ni = session.getInputInfo().get(namaMasuk);
        if (ni != null && ni.getInfo() instanceof TensorInfo) {
            long[] sh = ((TensorInfo) ni.getInfo()).getShape();
            boolean cocok = sh.length == 4
                    && (sh[1] == 4 || sh[1] < 0)
                    && (sh[2] == MdxDsp.DIM_F || sh[2] < 0)
                    && (sh[3] == MdxDsp.DIM_T || sh[3] < 0);
            if (!cocok) {
                session.close();
                throw new IllegalStateException("bentuk masukan model " + Arrays.toString(sh)
                        + " tidak sama dengan 1x4x" + MdxDsp.DIM_F + "x" + MdxDsp.DIM_T);
            }
        }
        buf = ByteBuffer.allocateDirect(4 * MdxDsp.DIM_F * MdxDsp.DIM_T * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    /** Membuat (ulang) sesi untuk tingkat hemat memori tertentu. */
    private void buat(int t) throws Exception {
        if (session != null) {
            try {
                session.close();
            } catch (Exception ignored) {
                // sesi lama dibuang
            }
            session = null;
            System.gc();
        }
        tingkat = t;
        OrtSession.SessionOptions so = new OrtSession.SessionOptions();
        try {
            int utas = t == 0 ? utasAwal : (t == 1 ? Math.min(2, utasAwal) : 1);
            so.setIntraOpNumThreads(utas);
            so.setInterOpNumThreads(1);
            so.setOptimizationLevel(t == 0 ? OrtSession.SessionOptions.OptLevel.EXTENDED_OPT
                    : OrtSession.SessionOptions.OptLevel.BASIC_OPT);
            so.setCPUArenaAllocator(false);
            so.setMemoryPatternOptimization(false);
            session = env.createSession(model.getAbsolutePath(), so);
        } finally {
            so.close();
        }
        namaMasuk = session.getInputNames().iterator().next();
    }

    private static boolean memoriHabis(Throwable e) {
        String m = String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT);
        return m.contains("bad_alloc") || m.contains("alloc") || m.contains("out of memory");
    }

    @Override
    public void jalankan(float[] masuk, float[] keluar) throws Exception {
        while (true) {
            try {
                sekali(masuk, keluar);
                return;
            } catch (Exception e) {
                if (!memoriHabis(e) || tingkat >= TINGKAT_MAKS) throw e;
                buat(tingkat + 1);
            }
        }
    }

    private void sekali(float[] masuk, float[] keluar) throws Exception {
        buf.clear();
        buf.put(masuk);
        buf.rewind();
        try (OnnxTensor in = OnnxTensor.createTensor(env, buf, BENTUK);
             OrtSession.Result res = session.run(Collections.singletonMap(namaMasuk, in))) {
            FloatBuffer fb = ((OnnxTensor) res.get(0)).getFloatBuffer();
            fb.rewind();
            fb.get(keluar);
        }
    }

    @Override
    public void close() throws Exception {
        if (session != null) session.close();
    }
}
