package com.novan.talkbacknovan;

import android.util.Log;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaUserdata;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.OneArgFunction;
import org.luaj.vm2.lib.ThreeArgFunction;
import org.luaj.vm2.lib.TwoArgFunction;
import org.luaj.vm2.lib.VarArgFunction;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

/**
 * Jembatan Lua-Java bergaya AndroLua (ditulis sendiri di atas LuaJ).
 * Objek Java bisa dipanggil dengan titik (obj.metode(x)) maupun titik dua (obj:metode(x)),
 * properti dibaca/ditulis lewat getX/setX/isX, dan fungsi atau tabel Lua otomatis menjadi
 * antarmuka Java (pendengar). Semua kode Lua dijalankan di thread utama.
 */
public final class LuaJava {
    private LuaJava() {}

    static final LuaTable META_OBJ = new LuaTable();
    static final LuaTable META_CLASS = new LuaTable();
    private static final ClassLoader LOADER = LuaJava.class.getClassLoader();
    private static final int GAGAL = -1;

    static {
        META_OBJ.set("__index", new TwoArgFunction() {
            @Override
            public LuaValue call(LuaValue self, LuaValue key) {
                return objIndex(self.touserdata(), key);
            }
        });
        META_OBJ.set("__newindex", new ThreeArgFunction() {
            @Override
            public LuaValue call(LuaValue self, LuaValue key, LuaValue val) {
                objSet(self.touserdata(), key, val);
                return NIL;
            }
        });
        META_OBJ.set("__tostring", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue self) {
                return valueOf(String.valueOf(self.touserdata()));
            }
        });
        META_OBJ.set("__len", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue self) {
                Object o = self.touserdata();
                if (o != null && o.getClass().isArray()) return valueOf(Array.getLength(o));
                if (o instanceof java.util.Collection) return valueOf(((java.util.Collection<?>) o).size());
                if (o instanceof CharSequence) return valueOf(((CharSequence) o).length());
                throw new LuaError("objek ini tidak punya panjang");
            }
        });
        META_CLASS.set("__index", new TwoArgFunction() {
            @Override
            public LuaValue call(LuaValue self, LuaValue key) {
                return classIndex((Class<?>) self.touserdata(), key);
            }
        });
        META_CLASS.set("__newindex", new ThreeArgFunction() {
            @Override
            public LuaValue call(LuaValue self, LuaValue key, LuaValue val) {
                classSet((Class<?>) self.touserdata(), key, val);
                return NIL;
            }
        });
        META_CLASS.set("__call", new VarArgFunction() {
            @Override
            public Varargs invoke(Varargs args) {
                return construct((Class<?>) args.arg1().touserdata(), args.subargs(2));
            }
        });
        META_CLASS.set("__tostring", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue self) {
                return valueOf("class " + ((Class<?>) self.touserdata()).getName());
            }
        });
    }

    // ------------------------------------------------------------------ pembungkus

    public static LuaValue wrap(Object o) {
        if (o == null) return LuaValue.NIL;
        if (o instanceof LuaValue) return (LuaValue) o;
        if (o instanceof Boolean) return LuaValue.valueOf(((Boolean) o).booleanValue());
        if (o instanceof Integer || o instanceof Short || o instanceof Byte) {
            return LuaValue.valueOf(((Number) o).intValue());
        }
        if (o instanceof Long) {
            long l = (Long) o;
            if (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) return LuaValue.valueOf((int) l);
            return LuaValue.valueOf((double) l);
        }
        if (o instanceof Float || o instanceof Double) return LuaValue.valueOf(((Number) o).doubleValue());
        if (o instanceof Character) return LuaValue.valueOf(String.valueOf(o));
        if (o instanceof CharSequence) return LuaValue.valueOf(o.toString());
        return new LuaUserdata(o, META_OBJ);
    }

    public static LuaValue wrapClass(Class<?> c) {
        return new LuaUserdata(c, META_CLASS);
    }

    public static Class<?> bindClass(String nama) {
        try {
            return Class.forName(nama, true, LOADER);
        } catch (ClassNotFoundException e) {
            throw new LuaError("kelas tidak ditemukan: " + nama);
        }
    }

    /** Pasang tabel luajava (bindClass, new, newInstance, createProxy, astable, instanceof). */
    public static void pasang(Globals g) {
        LuaTable t = new LuaTable();
        t.set("bindClass", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue nama) {
                return wrapClass(bindClass(nama.tojstring()));
            }
        });
        t.set("new", new VarArgFunction() {
            @Override
            public Varargs invoke(Varargs a) {
                return construct(kelasDari(a.arg1()), a.subargs(2));
            }
        });
        t.set("newInstance", new VarArgFunction() {
            @Override
            public Varargs invoke(Varargs a) {
                return construct(kelasDari(a.arg1()), a.subargs(2));
            }
        });
        t.set("createProxy", new TwoArgFunction() {
            @Override
            public LuaValue call(LuaValue iface, LuaValue tabel) {
                return wrap(proxy(kelasDari(iface), tabel));
            }
        });
        t.set("astable", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue arr) {
                Object o = arr.touserdata();
                LuaTable r = new LuaTable();
                if (o != null && o.getClass().isArray()) {
                    int n = Array.getLength(o);
                    for (int i = 0; i < n; i++) r.set(i + 1, wrap(Array.get(o, i)));
                } else if (o instanceof Iterable) {
                    int i = 1;
                    for (Object x : (Iterable<?>) o) r.set(i++, wrap(x));
                }
                return r;
            }
        });
        t.set("instanceof", new TwoArgFunction() {
            @Override
            public LuaValue call(LuaValue obj, LuaValue cls) {
                Object o = obj.touserdata();
                return valueOf(o != null && kelasDari(cls).isInstance(o));
            }
        });
        t.set("clear", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue x) {
                return NIL;
            }
        });
        t.set("loaded", new LuaTable());
        t.set("imported", new LuaTable());
        g.set("luajava", t);
    }

    private static Class<?> kelasDari(LuaValue v) {
        if (v.type() == LuaValue.TSTRING) return bindClass(v.tojstring());
        Object o = v.touserdata();
        if (o instanceof Class) return (Class<?>) o;
        throw new LuaError("bukan kelas Java: " + v.tojstring());
    }

    // ------------------------------------------------------------------ indeks objek

    private static LuaValue objIndex(Object obj, LuaValue key) {
        if (obj == null) return LuaValue.NIL;
        Class<?> c = obj.getClass();
        if (c.isArray()) {
            if (key.type() == LuaValue.TNUMBER) {
                int i = key.toint();
                if (i < 0 || i >= Array.getLength(obj)) return LuaValue.NIL;
                return wrap(Array.get(obj, i));
            }
            if (key.type() == LuaValue.TSTRING && key.tojstring().equals("length")) {
                return LuaValue.valueOf(Array.getLength(obj));
            }
        }
        if (key.type() != LuaValue.TSTRING) return LuaValue.NIL;
        String nama = key.tojstring();
        try {
            Field f = c.getField(nama);
            return wrap(f.get(obj));
        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException ignored) {
        }
        List<Method> ms = metode(c, nama, false);
        if (!ms.isEmpty()) return new Bound(obj, nama, ms);
        Method g = pengambil(c, nama);
        if (g != null) return wrap(panggilMetode(g, obj, new Object[0]));
        return LuaValue.NIL;
    }

    private static void objSet(Object obj, LuaValue key, LuaValue val) {
        if (obj == null) return;
        Class<?> c = obj.getClass();
        if (c.isArray() && key.type() == LuaValue.TNUMBER) {
            Array.set(obj, key.toint(), toJava(val, c.getComponentType()));
            return;
        }
        String nama = key.tojstring();
        try {
            Field f = c.getField(nama);
            if (!Modifier.isFinal(f.getModifiers())) {
                f.set(obj, toJava(val, f.getType()));
                return;
            }
        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException ignored) {
        }
        List<Method> ms = metode(c, "set" + huruf(nama), false);
        Varargs a = LuaValue.varargsOf(new LuaValue[]{val});
        Match m = pilih(ms, a);
        if (m == null) throw new LuaError("properti tidak dapat diubah: " + nama);
        panggilMetode((Method) m.exec, obj, m.args);
    }

    private static LuaValue classIndex(Class<?> c, LuaValue key) {
        if (key.type() != LuaValue.TSTRING) return LuaValue.NIL;
        String nama = key.tojstring();
        if (nama.equals("class")) return new LuaUserdata(c, META_OBJ);
        try {
            Field f = c.getField(nama);
            if (Modifier.isStatic(f.getModifiers())) return wrap(f.get(null));
        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException ignored) {
        }
        List<Method> ms = metode(c, nama, true);
        if (!ms.isEmpty()) return new Bound(null, nama, ms);
        try {
            return wrapClass(Class.forName(c.getName() + "$" + nama, false, LOADER));
        } catch (ClassNotFoundException ignored) {
        }
        return LuaValue.NIL;
    }

    private static void classSet(Class<?> c, LuaValue key, LuaValue val) {
        String nama = key.tojstring();
        try {
            Field f = c.getField(nama);
            if (Modifier.isStatic(f.getModifiers()) && !Modifier.isFinal(f.getModifiers())) {
                f.set(null, toJava(val, f.getType()));
                return;
            }
        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException ignored) {
        }
        throw new LuaError("properti statis tidak dapat diubah: " + nama);
    }

    private static String huruf(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static Method pengambil(Class<?> c, String nama) {
        String[] calon = {"get" + huruf(nama), "is" + huruf(nama)};
        for (String n : calon) {
            for (Method m : metode(c, n, false)) {
                if (m.getParameterTypes().length == 0) return m;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ metode

    private static List<Method> metode(Class<?> c, String nama, boolean statis) {
        List<Method> hasil = new ArrayList<>();
        for (Method m : c.getMethods()) {
            if (!m.getName().equals(nama)) continue;
            if (statis && !Modifier.isStatic(m.getModifiers())) continue;
            hasil.add(dapatDiakses(m));
        }
        return hasil;
    }

    private static Method dapatDiakses(Method m) {
        Class<?> d = m.getDeclaringClass();
        if (Modifier.isPublic(d.getModifiers())) return m;
        Method r = cariPublik(d, m.getName(), m.getParameterTypes());
        return r != null ? r : m;
    }

    private static Method cariPublik(Class<?> c, String nama, Class<?>[] p) {
        if (c == null) return null;
        if (Modifier.isPublic(c.getModifiers())) {
            try {
                return c.getMethod(nama, p);
            } catch (NoSuchMethodException ignored) {
            }
        }
        for (Class<?> i : c.getInterfaces()) {
            Method r = cariPublik(i, nama, p);
            if (r != null) return r;
        }
        return cariPublik(c.getSuperclass(), nama, p);
    }

    private static Object panggilMetode(Method m, Object target, Object[] args) {
        try {
            try {
                return m.invoke(target, args);
            } catch (IllegalAccessException e) {
                m.setAccessible(true);
                return m.invoke(target, args);
            }
        } catch (InvocationTargetException e) {
            Throwable sebab = e.getCause() != null ? e.getCause() : e;
            if (sebab instanceof LuaError) throw (LuaError) sebab;
            throw new LuaError(sebab.toString());
        } catch (Exception e) {
            throw new LuaError(m.getName() + ": " + e);
        }
    }

    /** Fungsi terikat pada objek: dipanggil dengan titik atau titik dua. */
    static final class Bound extends VarArgFunction {
        private final Object obj;
        private final String nama;
        private final List<Method> ms;

        Bound(Object obj, String nama, List<Method> ms) {
            this.obj = obj;
            this.nama = nama;
            this.ms = ms;
        }

        @Override
        public Varargs invoke(Varargs args) {
            Varargs a = args;
            Match m = pilih(ms, a);
            if (m == null && obj != null && a.narg() > 0) {
                Object p = a.arg1().touserdata();
                if (p == obj) {
                    a = a.subargs(2);
                    m = pilih(ms, a);
                }
            }
            if (m == null) {
                throw new LuaError("tidak ada metode " + nama + " yang cocok dengan " + a.narg() + " argumen");
            }
            Method me = (Method) m.exec;
            Object r = panggilMetode(me, Modifier.isStatic(me.getModifiers()) ? null : obj, m.args);
            if (me.getReturnType() == void.class) return LuaValue.NONE;
            return wrap(r);
        }
    }

    // ------------------------------------------------------------------ konstruktor

    private static Varargs construct(Class<?> c, Varargs args) {
        if (c.isInterface()) {
            if (args.narg() == 1 && (args.arg1().istable() || args.arg1().isfunction())) {
                return wrap(proxy(c, args.arg1()));
            }
            throw new LuaError("antarmuka " + c.getName() + " perlu tabel atau fungsi");
        }
        List<Constructor<?>> ks = new ArrayList<>();
        for (Constructor<?> k : c.getConstructors()) ks.add(k);
        Match m = pilih(ks, args);
        if (m == null) throw new LuaError("tidak ada konstruktor " + c.getName() + " yang cocok dengan " + args.narg() + " argumen");
        try {
            return wrap(((Constructor<?>) m.exec).newInstance(m.args));
        } catch (InvocationTargetException e) {
            Throwable sebab = e.getCause() != null ? e.getCause() : e;
            if (sebab instanceof LuaError) throw (LuaError) sebab;
            throw new LuaError(sebab.toString());
        } catch (Exception e) {
            throw new LuaError(c.getName() + ": " + e);
        }
    }

    // ------------------------------------------------------------------ pemilihan overload

    static final class Match {
        final Executable exec;
        Object[] args;
        int biaya;

        Match(Executable exec, int biaya) {
            this.exec = exec;
            this.biaya = biaya;
        }
    }

    private static Match pilih(List<? extends Executable> daftar, Varargs a) {
        Match terbaik = null;
        int n = a.narg();
        for (Executable e : daftar) {
            Class<?>[] pt = e.getParameterTypes();
            int total = 0;
            boolean ok = true;
            if (pt.length == n) {
                for (int i = 0; i < n; i++) {
                    int c = biaya(a.arg(i + 1), pt[i]);
                    if (c == GAGAL) {
                        ok = false;
                        break;
                    }
                    total += c;
                }
                if (!ok && e.isVarArgs()) {
                    ok = true;
                    total = 0;
                    total = biayaVarargs(e, pt, a);
                    if (total == GAGAL) ok = false;
                }
            } else if (e.isVarArgs() && n >= pt.length - 1) {
                total = biayaVarargs(e, pt, a);
                if (total == GAGAL) ok = false;
            } else {
                continue;
            }
            if (!ok) continue;
            if (terbaik == null || total < terbaik.biaya) terbaik = new Match(e, total);
        }
        if (terbaik == null) return null;
        terbaik.args = ubah(terbaik.exec, a);
        return terbaik;
    }

    private static int biayaVarargs(Executable e, Class<?>[] pt, Varargs a) {
        int tetap = pt.length - 1;
        int total = 10;
        for (int i = 0; i < tetap; i++) {
            int c = biaya(a.arg(i + 1), pt[i]);
            if (c == GAGAL) return GAGAL;
            total += c;
        }
        Class<?> komp = pt[tetap].getComponentType();
        for (int i = tetap; i < a.narg(); i++) {
            int c = biaya(a.arg(i + 1), komp);
            if (c == GAGAL) return GAGAL;
            total += c;
        }
        return total;
    }

    private static Object[] ubah(Executable e, Varargs a) {
        Class<?>[] pt = e.getParameterTypes();
        int n = a.narg();
        Object[] hasil = new Object[pt.length];
        boolean langsung = pt.length == n;
        if (langsung) {
            for (int i = 0; i < n; i++) {
                if (biaya(a.arg(i + 1), pt[i]) == GAGAL) {
                    langsung = false;
                    break;
                }
            }
        }
        if (langsung) {
            for (int i = 0; i < n; i++) hasil[i] = toJava(a.arg(i + 1), pt[i]);
            return hasil;
        }
        int tetap = pt.length - 1;
        for (int i = 0; i < tetap; i++) hasil[i] = toJava(a.arg(i + 1), pt[i]);
        Class<?> komp = pt[tetap].getComponentType();
        int sisa = Math.max(0, n - tetap);
        Object arr = Array.newInstance(komp, sisa);
        for (int i = 0; i < sisa; i++) Array.set(arr, i, toJava(a.arg(tetap + i + 1), komp));
        hasil[tetap] = arr;
        return hasil;
    }

    // ------------------------------------------------------------------ konversi

    private static Class<?> kotak(Class<?> t) {
        if (!t.isPrimitive()) return t;
        if (t == int.class) return Integer.class;
        if (t == long.class) return Long.class;
        if (t == boolean.class) return Boolean.class;
        if (t == double.class) return Double.class;
        if (t == float.class) return Float.class;
        if (t == short.class) return Short.class;
        if (t == byte.class) return Byte.class;
        if (t == char.class) return Character.class;
        return t;
    }

    /** Biaya konversi nilai Lua ke tipe Java; GAGAL bila tidak mungkin. Makin kecil makin cocok. */
    static int biaya(LuaValue v, Class<?> t) {
        Class<?> w = kotak(t);
        if (v.isnil()) return t.isPrimitive() ? GAGAL : 1;
        if (w != Object.class && w.isInstance(v)) return 0;
        switch (v.type()) {
            case LuaValue.TBOOLEAN:
                if (w == Boolean.class) return 0;
                return w == Object.class ? 4 : GAGAL;
            case LuaValue.TNUMBER:
                if (w == Integer.class || w == Long.class || w == Short.class || w == Byte.class) {
                    return v.isint() ? 0 : 6;
                }
                if (w == Double.class || w == Float.class) return v.isint() ? 1 : 0;
                if (w == Character.class) return 7;
                if (w == Number.class || w == Object.class) return 4;
                return GAGAL;
            case LuaValue.TSTRING:
                if (w == String.class) return 0;
                if (w == CharSequence.class) return 1;
                if (w == Object.class) return 4;
                if (w == Character.class && v.tojstring().length() == 1) return 3;
                if (w.isEnum()) return 3;
                return GAGAL;
            case LuaValue.TUSERDATA: {
                Object o = v.touserdata();
                if (o == null) return t.isPrimitive() ? GAGAL : 1;
                if (!w.isInstance(o)) return GAGAL;
                if (w == Object.class) return 5;
                return o.getClass() == w ? 0 : 1;
            }
            case LuaValue.TTABLE:
                if (w.isInterface()) return 2;
                if (w.isArray()) return 2;
                return w == Object.class ? 8 : GAGAL;
            case LuaValue.TFUNCTION:
                if (w.isInterface()) return 2;
                return w == Object.class ? 8 : GAGAL;
            default:
                return GAGAL;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static Object toJava(LuaValue v, Class<?> t) {
        Class<?> w = kotak(t);
        if (v.isnil()) return null;
        if (w != Object.class && w.isInstance(v)) return v;
        switch (v.type()) {
            case LuaValue.TBOOLEAN:
                return v.toboolean();
            case LuaValue.TNUMBER:
                return angka(v, w);
            case LuaValue.TSTRING: {
                String s = v.tojstring();
                if (w == Character.class) return s.isEmpty() ? '\0' : s.charAt(0);
                if (w.isEnum()) return Enum.valueOf((Class<? extends Enum>) w, s);
                return s;
            }
            case LuaValue.TUSERDATA:
                return v.touserdata();
            case LuaValue.TTABLE:
                if (w.isInterface()) return proxy(w, v);
                if (w.isArray()) return tabelKeArray(v, w.getComponentType());
                return v;
            case LuaValue.TFUNCTION:
                if (w.isInterface()) return proxy(w, v);
                return v;
            default:
                return null;
        }
    }

    private static Object angka(LuaValue v, Class<?> w) {
        if (w == Integer.class) return v.toint();
        if (w == Long.class) return v.tolong();
        if (w == Short.class) return (short) v.toint();
        if (w == Byte.class) return (byte) v.toint();
        if (w == Float.class) return (float) v.todouble();
        if (w == Double.class) return v.todouble();
        if (w == Character.class) return (char) v.toint();
        double d = v.todouble();
        if (d == Math.rint(d) && Math.abs(d) < 2147483647d) return (int) d;
        if (d == Math.rint(d) && Math.abs(d) < 9.0e15) return (long) d;
        return d;
    }

    private static Object tabelKeArray(LuaValue t, Class<?> komp) {
        int n = t.length();
        Object arr = Array.newInstance(komp, n);
        for (int i = 0; i < n; i++) Array.set(arr, i, toJava(t.get(i + 1), komp));
        return arr;
    }

    // ------------------------------------------------------------------ antarmuka dari Lua

    static Object proxy(Class<?> iface, LuaValue target) {
        if (!iface.isInterface()) throw new LuaError(iface.getName() + " bukan antarmuka");
        return Proxy.newProxyInstance(LOADER, new Class<?>[]{iface}, new Penangan(target));
    }

    private static final class Penangan implements InvocationHandler {
        private final LuaValue target;

        Penangan(LuaValue target) {
            this.target = target;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) {
            String nama = method.getName();
            if (method.getDeclaringClass() == Object.class) {
                switch (nama) {
                    case "toString": return "LuaProxy@" + Integer.toHexString(System.identityHashCode(proxy));
                    case "hashCode": return System.identityHashCode(proxy);
                    case "equals": return args != null && args.length == 1 && proxy == args[0];
                    default: return null;
                }
            }
            LuaValue f = target.isfunction() ? target : target.get(nama);
            Class<?> r = method.getReturnType();
            if (!f.isfunction()) return nilaiAwal(r);
            try {
                int n = args == null ? 0 : args.length;
                LuaValue[] la = new LuaValue[n];
                for (int i = 0; i < n; i++) la[i] = wrap(args[i]);
                Varargs hasil = f.invoke(LuaValue.varargsOf(la));
                if (r == void.class) return null;
                LuaValue h = hasil.arg1();
                if (h.isnil() || biaya(h, r) == GAGAL) return nilaiAwal(r);
                return toJava(h, r);
            } catch (LuaError e) {
                catat("galat pada " + nama + ": " + e.getMessage());
                return nilaiAwal(r);
            }
        }
    }

    private static Object nilaiAwal(Class<?> r) {
        if (!r.isPrimitive() || r == void.class) return null;
        if (r == boolean.class) return false;
        if (r == int.class) return 0;
        if (r == long.class) return 0L;
        if (r == double.class) return 0d;
        if (r == float.class) return 0f;
        if (r == short.class) return (short) 0;
        if (r == byte.class) return (byte) 0;
        if (r == char.class) return '\0';
        return null;
    }

    /** Catat galat yang terjadi di luar pemanggilan langsung (misalnya pendengar). */
    static void catat(String pesan) {
        Log.e("TalkBackNovan-Lua", pesan);
        PluginManager.catatUmum(pesan);
    }
}
