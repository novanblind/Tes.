package com.novan.filemanagermax

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

/** Server FTP sederhana (pasif) dengan satu akun. Dibatasi pada folder [root]. */
class FtpServer(
    private val root: File,
    private val port: Int,
    private val user: String,
    private val pass: String
) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        running = true
        pool.execute {
            while (running) {
                try {
                    val c = s.accept()
                    pool.execute { Session(c).run() }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        pool.shutdownNow()
    }

    private inner class Session(private val sock: Socket) {
        private val out: OutputStream = sock.getOutputStream()
        private var cwd = "/"
        private var authed = false
        private var gotUser: String? = null
        private var pasv: ServerSocket? = null
        private var renameFrom: File? = null
        private var restPos = 0L

        private fun reply(line: String) {
            out.write((line + "\r\n").toByteArray(Charsets.UTF_8))
            out.flush()
        }

        fun run() {
            try {
                sock.soTimeout = 5 * 60 * 1000
                val reader = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.UTF_8))
                reply("220 File Manager Max")
                while (running) {
                    val line = reader.readLine() ?: break
                    val sp = line.indexOf(' ')
                    val cmd = (if (sp < 0) line else line.substring(0, sp)).uppercase()
                    val arg = if (sp < 0) "" else line.substring(sp + 1).trim()
                    if (!handle(cmd, arg)) break
                }
            } catch (e: Exception) {
                // koneksi putus
            } finally {
                closePasv()
                try { sock.close() } catch (e: Exception) { }
            }
        }

        private fun closePasv() {
            try { pasv?.close() } catch (e: Exception) { }
            pasv = null
        }

        private fun virt(arg: String) = ServerUtil.normalize(cwd, arg)
        private fun file(arg: String) = ServerUtil.fileOf(root, virt(arg))

        private fun dataSocket(): Socket? {
            val p = pasv ?: return null
            return try {
                p.soTimeout = 20000
                p.accept().also { it.soTimeout = 60000 }
            } catch (e: Exception) {
                null
            } finally {
                closePasv()
            }
        }

        private fun handle(cmd: String, arg: String): Boolean {
            when (cmd) {
                "USER" -> { gotUser = arg; reply("331 Password required"); return true }
                "PASS" -> {
                    if (gotUser == user && arg == pass) { authed = true; reply("230 Logged in") }
                    else reply("530 Login incorrect")
                    return true
                }
                "QUIT" -> { reply("221 Bye"); return false }
                "FEAT" -> { reply("211-Features:\r\n SIZE\r\n MDTM\r\n REST STREAM\r\n UTF8\r\n211 End"); return true }
                "OPTS" -> { reply("200 OK"); return true }
                "NOOP" -> { reply("200 OK"); return true }
                "SYST" -> { reply("215 UNIX Type: L8"); return true }
            }
            if (!authed) { reply("530 Please login"); return true }
            when (cmd) {
                "PWD", "XPWD" -> reply("257 \"$cwd\" is current directory")
                "TYPE", "MODE", "STRU" -> reply("200 OK")
                "CWD", "XCWD" -> {
                    val v = virt(arg)
                    if (ServerUtil.fileOf(root, v).isDirectory) { cwd = v; reply("250 OK") }
                    else reply("550 Not a directory")
                }
                "CDUP", "XCUP" -> { cwd = virt(".."); reply("250 OK") }
                "PASV" -> {
                    closePasv()
                    try {
                        val ps = ServerSocket(0)
                        pasv = ps
                        val ip = sock.localAddress.address
                        val p = ps.localPort
                        reply(
                            "227 Entering Passive Mode (" +
                                ip.joinToString(",") { (it.toInt() and 0xff).toString() } +
                                ",${p shr 8},${p and 0xff})"
                        )
                    } catch (e: Exception) {
                        reply("425 Cannot open passive port")
                    }
                }
                "EPSV" -> {
                    closePasv()
                    try {
                        val ps = ServerSocket(0)
                        pasv = ps
                        reply("229 Entering Extended Passive Mode (|||${ps.localPort}|)")
                    } catch (e: Exception) {
                        reply("425 Cannot open passive port")
                    }
                }
                "PORT", "EPRT" -> reply("502 Use passive mode")
                "LIST", "NLST", "MLSD" -> list(cmd, arg)
                "RETR" -> retr(arg)
                "STOR", "APPE" -> stor(arg, cmd == "APPE")
                "REST" -> { restPos = arg.toLongOrNull() ?: 0L; reply("350 Restarting at $restPos") }
                "SIZE" -> {
                    val f = file(arg)
                    if (f.isFile) reply("213 ${f.length()}") else reply("550 No such file")
                }
                "MDTM" -> {
                    val f = file(arg)
                    if (f.exists()) {
                        val fmt = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
                        fmt.timeZone = TimeZone.getTimeZone("UTC")
                        reply("213 " + fmt.format(Date(f.lastModified())))
                    } else reply("550 No such file")
                }
                "MKD", "XMKD" -> {
                    val f = file(arg)
                    if (f.mkdirs()) reply("257 \"${virt(arg)}\" created") else reply("550 Cannot create")
                }
                "RMD", "XRMD" -> {
                    val f = file(arg)
                    if (f.isDirectory && f.deleteRecursively()) reply("250 Removed") else reply("550 Cannot remove")
                }
                "DELE" -> {
                    val f = file(arg)
                    if (f.isFile && f.delete()) reply("250 Deleted") else reply("550 Cannot delete")
                }
                "RNFR" -> {
                    val f = file(arg)
                    if (f.exists()) { renameFrom = f; reply("350 Ready for RNTO") } else reply("550 No such file")
                }
                "RNTO" -> {
                    val from = renameFrom
                    renameFrom = null
                    val to = file(arg)
                    if (from != null && !to.exists() && Util.moveExact(from, to)) reply("250 Renamed")
                    else reply("550 Rename failed")
                }
                else -> reply("502 Command not implemented")
            }
            return true
        }

        private fun list(cmd: String, argRaw: String) {
            val arg = argRaw.split(" ").filter { !it.startsWith("-") }.joinToString(" ")
            val target = if (arg.isEmpty()) ServerUtil.fileOf(root, cwd) else file(arg)
            if (!target.exists()) { reply("550 No such file or directory"); closePasv(); return }
            if (pasv == null) { reply("425 Use PASV first"); return }
            reply("150 Opening data connection")
            val ds = dataSocket()
            if (ds == null) { reply("425 Cannot open data connection"); return }
            try {
                val w = ds.getOutputStream().bufferedWriter(Charsets.UTF_8)
                val kids = if (target.isDirectory) (target.listFiles()?.toList() ?: emptyList()) else listOf(target)
                val df = SimpleDateFormat("MMM dd HH:mm", Locale.US)
                for (k in kids.sortedBy { it.name.lowercase() }) {
                    if (cmd == "NLST") w.write(k.name + "\r\n")
                    else if (cmd == "MLSD") {
                        val t = if (k.isDirectory) "dir" else "file"
                        w.write("type=$t;size=${k.length()}; ${k.name}\r\n")
                    } else {
                        val perm = if (k.isDirectory) "drwxr-xr-x" else "-rw-r--r--"
                        w.write(
                            "$perm 1 owner group ${if (k.isDirectory) 4096 else k.length()} " +
                                "${df.format(Date(k.lastModified()))} ${k.name}\r\n"
                        )
                    }
                }
                w.flush()
                reply("226 Transfer complete")
            } catch (e: Exception) {
                reply("426 Transfer aborted")
            } finally {
                try { ds.close() } catch (e: Exception) { }
            }
        }

        private fun retr(arg: String) {
            val f = file(arg)
            val pos = restPos
            restPos = 0L
            if (!f.isFile) { reply("550 No such file"); closePasv(); return }
            if (pasv == null) { reply("425 Use PASV first"); return }
            reply("150 Opening data connection")
            val ds = dataSocket()
            if (ds == null) { reply("425 Cannot open data connection"); return }
            try {
                RandomAccessFile(f, "r").use { raf ->
                    raf.seek(pos)
                    val buf = ByteArray(64 * 1024)
                    val o = ds.getOutputStream()
                    while (true) {
                        val n = raf.read(buf)
                        if (n <= 0) break
                        o.write(buf, 0, n)
                    }
                    o.flush()
                }
                reply("226 Transfer complete")
            } catch (e: Exception) {
                reply("426 Transfer aborted")
            } finally {
                try { ds.close() } catch (e: Exception) { }
            }
        }

        private fun stor(arg: String, append: Boolean) {
            val f = file(arg)
            val pos = restPos
            restPos = 0L
            if (f.isDirectory || f.parentFile?.isDirectory != true) { reply("550 Cannot write"); closePasv(); return }
            if (pasv == null) { reply("425 Use PASV first"); return }
            reply("150 Ready to receive")
            val ds = dataSocket()
            if (ds == null) { reply("425 Cannot open data connection"); return }
            try {
                RandomAccessFile(f, "rw").use { raf ->
                    if (append) raf.seek(raf.length()) else if (pos > 0) raf.seek(pos) else raf.setLength(0)
                    val buf = ByteArray(64 * 1024)
                    val i = ds.getInputStream()
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                    }
                }
                reply("226 Transfer complete")
            } catch (e: Exception) {
                reply("426 Transfer aborted")
            } finally {
                try { ds.close() } catch (e: Exception) { }
            }
        }
    }
}
