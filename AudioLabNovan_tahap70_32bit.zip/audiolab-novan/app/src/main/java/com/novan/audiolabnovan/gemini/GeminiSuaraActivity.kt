package com.novan.audiolabnovan.gemini

import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import com.novan.audiolabnovan.wa.Say
import com.novan.audiolabnovan.wa.WaAccessibilityService
import com.novan.audiolabnovan.wa.WaKirim
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.Opts
import com.novan.audiolabnovan.OutFmt
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Tahap 59: Voice note Gemini di dalam AudioLab.
 *
 * Fitur aplikasi Voice note Suara Gemini dipindahkan ke sini: satu suara atau percakapan dua pembicara, 40 suara
 * Gemini dengan contoh suara, logat, gaya atau emosi, pilihan model, dan kunci API Gemini. Suara dari Gemini
 * (PCM 24 kHz) lalu diberi efek yang sama seperti di Teks ke Suara (pengubah suara, gema ruang, bass, volume,
 * ratakan volume) oleh FFmpeg dan disandi ke MP3, M4A, FLAC, atau WAV. Hasilnya muncul di dialog menu hasil,
 * yang sudah punya tombol Kirim ke WhatsApp sebagai pesan suara.
 *
 * Suara mentah dari Gemini disimpan sementara, jadi efek bisa diganti dan diterapkan ulang tanpa memanggil
 * Gemini lagi (hemat kuota).
 */
class GeminiSuaraActivity : AppCompatActivity() {

    private class Efek(val nama: String, val voice: Int = 0, val pitch: Int = 0, val ekstra: List<String> = emptyList())

    private val daftarEfek = listOf(
        Efek("Tanpa efek (suara asli Gemini)"),
        Efek("Tupai (nada tinggi)", voice = 1),
        Efek("Raksasa (nada rendah)", voice = 2),
        Efek("Robot", voice = 3),
        Efek("Radio atau telepon", voice = 4),
        Efek("Bergetar", voice = 5),
        Efek("Anak kecil", pitch = 4),
        Efek("Suara berat", pitch = -3),
        Efek("Paduan suara (chorus)", ekstra = listOf("chorus=0.7:0.9:55:0.4:0.25:2"))
    )
    private val daftarRuang = listOf(
        "Tanpa gema", "Ruang kecil", "Aula", "Gema (echo)", "Studio vokal",
        "Karaoke", "Katedral", "Kamar mandi", "Panggung konser"
    )
    private val daftarBass = listOf(0, 3, 6, 9, 12)
    private val daftarVolume = listOf(-6, -3, 0, 3, 6, 9)
    private val daftarKbps = listOf(64, 96, 128, 192, 256, 320)
    private val daftarFormat = OutFmt.values().toList()   // MP3 paling atas, jadi MP3 terpilih bawaan

    private val pref by lazy { GeminiStore.prefs(this) }

    // ----- Proses -----
    private val batal = AtomicBoolean(false)
    @Volatile private var sibuk = false
    @Volatile private var sesi: FFmpegSession? = null
    private var player: MediaPlayer? = null
    private var pemutarHasil: MediaPlayer? = null
    private var pemutarJeda = false
    private var hasilFile: File? = null
    private var hasilUri: Uri? = null
    private var hasilFmt: OutFmt = OutFmt.AAC
    private var hasilNama: String = ""
    private var judulTerakhir: String = ""
    private val dialogHasil by lazy { DialogHasil(this) }
    private var daftarModel: List<String> = emptyList()
    @Volatile private var memperbaruiModel = false
    private var terakhirUmum = -1

    // ----- Tampilan -----
    private lateinit var spMode: Spinner
    private lateinit var spSuara: Spinner
    private lateinit var spSuara2: Spinner
    private lateinit var spLogat: Spinner
    private lateinit var spVibe: Spinner
    private lateinit var spLogat2: Spinner
    private lateinit var spVibe2: Spinner
    private lateinit var spModel: Spinner
    private lateinit var etNama1: EditText
    private lateinit var etNama2: EditText
    private lateinit var etJudul: EditText
    private lateinit var etTeks: EditText
    private lateinit var tvHitung: TextView
    private val tampilanMulti = ArrayList<View>()
    private lateinit var btnContoh: Button
    private lateinit var btnContoh2: Button
    private lateinit var btnModel: Button
    private lateinit var btnKunci: Button
    private lateinit var btnBuka: Button
    private lateinit var btnHapusTeks: Button
    private lateinit var spEfek: Spinner
    private lateinit var spRuang: Spinner
    private lateinit var spBass: Spinner
    private lateinit var spVolume: Spinner
    private lateinit var cbRata: CheckBox
    private lateinit var spFormat: Spinner
    private lateinit var spKbps: Spinner
    private lateinit var btnBuat: Button
    private lateinit var btnUlang: Button
    private lateinit var btnBerhenti: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView
    private lateinit var panelHasil: LinearLayout
    private lateinit var tvHasil: TextView
    private lateinit var btnMenuHasil: Button
    private lateinit var btnBagikan: Button
    private lateinit var btnSimpan: Button
    private lateinit var etJeda: EditText
    private lateinit var btnKirimWa: Button
    private lateinit var btnStatusWa: Button
    private lateinit var btnPutarHasil: Button

    private val bukaBerkas = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) muatBerkasTeks(uri)
    }

    private val simpanSebagai = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val f = hasilFile
        if (r.resultCode == RESULT_OK && uri != null && f != null && f.exists()) {
            thread {
                val err = try { Converter.copyTo(this, f, uri); null } catch (e: Exception) { e.message ?: "galat" }
                runOnUiThread {
                    if (err == null) {
                        hasilUri = uri
                        btnBagikan.isEnabled = true
                        status("Berkas tersimpan.")
                    } else status("Gagal menyimpan: $err")
                }
            }
        } else status("Penyimpanan dibatalkan.")
    }

    // =====================================================================================
    //  Pembantu tampilan
    // =====================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun LinearLayout.tambah(v: View) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun judul(teks: String, untuk: View? = null): TextView = TextView(this).apply {
        text = teks
        textSize = 16f
        setPadding(0, dp(14), 0, dp(2))
        if (untuk != null) {
            if (untuk.id == View.NO_ID) untuk.id = View.generateViewId()
            labelFor = untuk.id
        }
    }

    private fun subjudul(teks: String): TextView = TextView(this).apply {
        text = teks
        textSize = 20f
        setPadding(0, dp(22), 0, dp(4))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun tombol(teks: String, aksi: () -> Unit): Button = Button(this).apply {
        text = teks
        minHeight = dp(48)
        isAllCaps = false
        setOnClickListener { aksi() }
    }

    private fun isiSpinner(sp: Spinner, items: List<String>, pilih: Int) {
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val t = super.getView(position, convertView, parent) as TextView
                t.isSingleLine = false
                t.ellipsize = null
                return t
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val t = super.getDropDownView(position, convertView, parent) as TextView
                t.isSingleLine = false
                t.ellipsize = null
                t.setPadding(dp(12), dp(10), dp(12), dp(10))
                return t
            }
        }
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        if (items.isNotEmpty()) sp.setSelection(pilih.coerceIn(0, items.size - 1), false)
    }

    private fun spinner(items: List<String>, awal: Int = 0, saatPilih: (Int) -> Unit = {}): Spinner {
        val sp = Spinner(this)
        sp.minimumHeight = dp(48)
        isiSpinner(sp, items, awal)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { saatPilih(position) }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    /** Spinner yang pilihan terakhirnya diingat di pengaturan dengan kunci [kunci]. */
    private fun spinnerIngat(items: List<String>, kunci: String, bawaan: Int, saatPilih: (Int) -> Unit = {}): Spinner =
        spinner(items, pref.getInt(kunci, bawaan)) { pref.edit().putInt(kunci, it).apply(); saatPilih(it) }

    private fun tambahMulti(v: View) { tampilanMulti += v }

    // =====================================================================================
    //  Membangun layar
    // =====================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Voice note Gemini"

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(akar) })

        // ----- Kunci API -----
        akar.tambah(subjudul("Kunci API Gemini"))
        btnKunci = tombol("Pengaturan kunci API Gemini") { dialogKunci() }
        akar.tambah(btnKunci)
        akar.tambah(tombol("Buka pengaturan aksesibilitas (aktifkan layanan pengirim WhatsApp)") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (_: Exception) { status("Tidak bisa membuka pengaturan aksesibilitas.") }
        })

        // ----- Suara -----
        akar.tambah(subjudul("Suara Gemini"))
        spMode = spinnerIngat(Data.MODE_LIST.toList(), "last_mode_index", 0) { perbaruiModeTampilan() }
        akar.tambah(judul("Mode suara", spMode))
        akar.tambah(spMode)

        spSuara = spinnerIngat(Data.VOICE_LIST.toList(), "last_voice_index", 0)
        akar.tambah(judul("Karakter suara Gemini (40 pilihan)", spSuara))
        akar.tambah(spSuara)
        btnContoh = tombol("Putar contoh suara terpilih") { putarContoh(spSuara.selectedItemPosition) }
        akar.tambah(btnContoh)

        val lSuara2 = judul("Karakter suara 2 (40 pilihan)")
        spSuara2 = spinnerIngat(Data.VOICE_LIST.toList(), "last_voice2_index", 1)
        lSuara2.labelFor = spSuara2.also { if (it.id == View.NO_ID) it.id = View.generateViewId() }.id
        akar.tambah(lSuara2); akar.tambah(spSuara2)
        btnContoh2 = tombol("Putar contoh suara 2 terpilih") { putarContoh(spSuara2.selectedItemPosition) }
        akar.tambah(btnContoh2)
        tambahMulti(lSuara2); tambahMulti(spSuara2); tambahMulti(btnContoh2)

        etNama1 = EditText(this).apply {
            setSingleLine(true)
            hint = "Suara1"
            setText(pref.getString("speaker1_name", "Suara1"))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        val lNama1 = judul("Nama pembicara 1 (label di naskah)", etNama1)
        akar.tambah(lNama1); akar.tambah(etNama1)
        etNama2 = EditText(this).apply {
            setSingleLine(true)
            hint = "Suara2"
            setText(pref.getString("speaker2_name", "Suara2"))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        val lNama2 = judul("Nama pembicara 2 (label di naskah)", etNama2)
        akar.tambah(lNama2); akar.tambah(etNama2)
        tambahMulti(lNama1); tambahMulti(etNama1); tambahMulti(lNama2); tambahMulti(etNama2)

        spLogat = spinnerIngat(Data.LOGAT_LIST.toList(), "last_logat_index", 0)
        akar.tambah(judul("Logat bicara atau bahasa daerah (38 pilihan)", spLogat))
        akar.tambah(spLogat)
        spVibe = spinnerIngat(Data.VIBE_LIST.toList(), "last_vibe_index", 0)
        akar.tambah(judul("Gaya atau emosi suara (50 pilihan)", spVibe))
        akar.tambah(spVibe)

        spLogat2 = spinnerIngat(Data.LOGAT_LIST.toList(), "last_logat2_index", 0)
        val lLogat2 = judul("Logat bicara pembicara 2", spLogat2)
        akar.tambah(lLogat2); akar.tambah(spLogat2)
        spVibe2 = spinnerIngat(Data.VIBE_LIST.toList(), "last_vibe2_index", 0)
        val lVibe2 = judul("Gaya atau emosi suara pembicara 2", spVibe2)
        akar.tambah(lVibe2); akar.tambah(spVibe2)
        tambahMulti(lLogat2); tambahMulti(spLogat2); tambahMulti(lVibe2); tambahMulti(spVibe2)

        // ----- Model -----
        spModel = Spinner(this).apply { minimumHeight = dp(48) }
        akar.tambah(judul("Model Gemini", spModel))
        akar.tambah(spModel)
        muatSpinnerModel()
        spModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val nama = if (position <= 0 || position > daftarModel.size) "" else daftarModel[position - 1]
                pref.edit().putString("last_model_name", nama).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        btnModel = tombol("Perbarui daftar model") { perbaruiModel() }
        akar.tambah(btnModel)

        // ----- Naskah -----
        akar.tambah(subjudul("Naskah"))
        etJudul = EditText(this).apply {
            setSingleLine(true)
            hint = "Boleh kosong: nama berkas otomatis"
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        akar.tambah(judul("Judul audio (nama berkas)", etJudul))
        akar.tambah(etJudul)

        etTeks = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            hint = "Tulis naskah pesan di sini. Mode multi suara: awali baris dengan nama pembicara dan titik dua."
            setHorizontallyScrolling(false)
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        akar.tambah(judul("Naskah yang akan dibacakan Gemini", etTeks))
        akar.tambah(etTeks)
        tvHitung = TextView(this).apply { setPadding(0, dp(4), 0, 0) }
        akar.tambah(tvHitung)
        etTeks.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { segarkanHitung() }
        })
        etJeda = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            hint = "500"
            setText(WaKirim.jedaMs(this@GeminiSuaraActivity).toString())
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    s.toString().trim().toIntOrNull()?.let { WaKirim.simpanJedaMs(this@GeminiSuaraActivity, it) }
                }
            })
        }
        akar.tambah(judul("Jeda sebelum audio dibunyikan setelah mulai merekam (milidetik)", etJeda))
        akar.tambah(etJeda)
        akar.tambah(tombol("TUTUP KEYBOARD") {
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0); it.clearFocus() }
            } catch (_: Exception) { }
            Say.say(this, "Keyboard ditutup.")
        })
        btnBuka = tombol("Buka naskah dari berkas (.txt)") { bukaBerkas.launch(arrayOf("text/*")) }
        akar.tambah(btnBuka)
        btnHapusTeks = tombol("Hapus semua tulisan") {
            etTeks.setText("")
            status("Tulisan dikosongkan.")
        }
        akar.tambah(btnHapusTeks)

        // ----- Efek -----
        akar.tambah(subjudul("Efek suara"))
        spEfek = spinnerIngat(daftarEfek.map { it.nama }, "fx_efek", 0)
        akar.tambah(judul("Pengubah suara", spEfek))
        akar.tambah(spEfek)
        spRuang = spinnerIngat(daftarRuang, "fx_ruang", 0)
        akar.tambah(judul("Efek ruang dan gema", spRuang))
        akar.tambah(spRuang)
        spBass = spinnerIngat(daftarBass.map { if (it == 0) "Mati" else "Plus $it dB" }, "fx_bass", 0)
        akar.tambah(judul("Penguat bass", spBass))
        akar.tambah(spBass)
        spVolume = spinnerIngat(
            daftarVolume.map { if (it == 0) "Normal" else if (it > 0) "Plus $it dB" else "Minus ${-it} dB" }, "fx_volume", 2
        )
        akar.tambah(judul("Volume hasil", spVolume))
        akar.tambah(spVolume)
        cbRata = CheckBox(this).apply {
            text = "Ratakan volume (normalisasi)"
            minHeight = dp(48)
            isChecked = pref.getBoolean("fx_rata", false)
            setOnCheckedChangeListener { _, c -> pref.edit().putBoolean("fx_rata", c).apply() }
        }
        akar.tambah(cbRata)

        // ----- Format -----
        akar.tambah(subjudul("Format audio"))
        spFormat = spinnerIngat(daftarFormat.map { it.label }, "fx_format_vn", daftarFormat.indexOf(OutFmt.AAC).coerceAtLeast(0)) {
            if (::spKbps.isInitialized) spKbps.isEnabled = daftarFormat[it].lossy && !sibuk
        }
        akar.tambah(judul("Format hasil (bawaan M4A, seperti aplikasi Voice note Gemini asli)", spFormat))
        akar.tambah(spFormat)
        spKbps = spinnerIngat(daftarKbps.map { "$it kbps" }, "fx_kbps_vn", daftarKbps.indexOf(96).coerceAtLeast(0))
        akar.tambah(judul("Kualitas (bitrate)", spKbps))
        akar.tambah(spKbps)
        spKbps.isEnabled = daftarFormat[spFormat.selectedItemPosition.coerceAtLeast(0)].lossy

        // ----- Buat -----
        akar.tambah(subjudul("Buat audio"))
        btnBuat = tombol("Buat suara Gemini") { buatAudio() }
        akar.tambah(btnBuat)
        btnUlang = tombol("Terapkan efek ulang pada suara Gemini terakhir (tanpa memanggil Gemini lagi)") { terapkanUlang() }
        akar.tambah(btnUlang)
        btnBerhenti = tombol("Hentikan") { hentikanSemua() }
        akar.tambah(btnBerhenti)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        akar.tambah(progress)
        tvProgress = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, dp(4), 0, 0)
        }
        akar.tambah(tvProgress)
        tvStatus = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            textSize = 16f
            setPadding(0, dp(8), 0, 0)
        }
        akar.tambah(tvStatus)

        // ----- Hasil -----
        panelHasil = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        panelHasil.tambah(subjudul("Hasil"))
        tvHasil = TextView(this).apply { textSize = 16f }
        panelHasil.tambah(tvHasil)
        btnKirimWa = tombol("Kirim ke WhatsApp (pilih WhatsApp atau WhatsApp Business)") { kirimWaLangsung() }
        panelHasil.tambah(btnKirimWa)
        btnStatusWa = tombol("Bagikan ke status WhatsApp (pesan suara, pilih WhatsApp atau WhatsApp Business)") { kirimStatusLangsung() }
        panelHasil.tambah(btnStatusWa)
        btnPutarHasil = tombol("Putar hasil audio") { putarJedaHasil() }
        panelHasil.tambah(btnPutarHasil)
        btnMenuHasil = tombol("Menu hasil lainnya: ubah nama, hapus") { bukaMenuHasil() }
        panelHasil.tambah(btnMenuHasil)
        btnBagikan = tombol("Bagikan") { bagikan() }
        panelHasil.tambah(btnBagikan)
        btnSimpan = tombol("Simpan sebagai…") { simpanKeLokasi() }
        panelHasil.tambah(btnSimpan)
        akar.tambah(panelHasil)

        segarkanHitung()
        perbaruiModeTampilan()
        segarkanTombol()

        // Teks yang dibagikan dari aplikasi lain.
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.let { etTeks.setText(it) }
        }
    }

    private fun perbaruiModeTampilan() {
        if (!::spMode.isInitialized) return
        val multi = spMode.selectedItemPosition == 1
        for (v in tampilanMulti) v.visibility = if (multi) View.VISIBLE else View.GONE
    }

    private fun segarkanHitung() {
        val n = etTeks.text.length
        val bagian = (n + 3999) / 4000
        tvHitung.text = if (n == 0) "Belum ada tulisan." else "%,d karakter, dipecah jadi kira-kira %,d permintaan ke Gemini.".format(Locale("id", "ID"), n, bagian)
    }

    private fun muatBerkasTeks(uri: Uri) {
        status("Membaca berkas teks…")
        thread {
            val isi = try {
                contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (isi.isNullOrBlank()) {
                    status("Berkas kosong atau tidak bisa dibaca sebagai teks.")
                } else {
                    etTeks.setText(isi)
                    status("Berkas dimuat: %,d karakter.".format(Locale("id", "ID"), isi.length))
                }
            }
        }
    }

    // =====================================================================================
    //  Kunci API dan model
    // =====================================================================================

    private fun dialogKunci() {
        val kotak = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
        }
        val et = EditText(this).apply {
            hint = "AIzaSy..."
            setText(GeminiStore.getKey(this@GeminiSuaraActivity))
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        kotak.addView(judul("Kunci API Gemini", et))
        kotak.addView(et)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Pengaturan kunci API Gemini")
            .setView(kotak)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .setNeutralButton("Reset kunci", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val k = GeminiStore.cleanKey(et.text)
            if (k.isEmpty()) {
                status("Kunci API tidak boleh kosong.")
            } else {
                GeminiStore.saveKey(this, k)
                status("Kunci API berhasil disimpan.")
                dlg.dismiss()
            }
        }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            GeminiStore.resetKey(this)
            et.setText("")
            status("Kunci API berhasil dihapus.")
        }
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { dlg.dismiss() }
    }

    /** Isi pilihan model: "Otomatis" lalu tiap model; pilihan tersimpan dipulihkan. */
    private fun muatSpinnerModel() {
        daftarModel = Models.ordered(this)
        val label = ArrayList<String>()
        label += "Otomatis (${daftarModel.size} model berurutan, pindah jika kuota habis)"
        for (m in daftarModel) label += if (GeminiClient.isVerbatimModel(m)) "$m (instruksi tidak ikut dibacakan)" else m
        val tersimpan = pref.getString("last_model_name", "") ?: ""
        val idx = if (tersimpan.isEmpty()) 0 else daftarModel.indexOf(tersimpan) + 1
        isiSpinner(spModel, label, idx.coerceAtLeast(0))
    }

    /** Ambil daftar model TTS terbaru dari Google di latar belakang. */
    private fun perbaruiModel() {
        if (memperbaruiModel) { status("Pembaruan daftar model sedang berjalan."); return }
        val kunci = GeminiStore.getKey(this)
        if (kunci.isEmpty()) { status("Kunci API belum dimasukkan, jadi daftar model tidak bisa diperbarui."); return }
        memperbaruiModel = true
        status("Memperbarui daftar model di latar belakang. Mohon tunggu.")
        val app = applicationContext
        thread {
            var pesan = ""
            try {
                val rr = ModelRefresher.refresh(kunci, Models.load(app))
                if (rr.error != null) {
                    pesan = rr.error
                } else {
                    Models.save(app, rr.models)
                    pesan = if (rr.added.isEmpty() && rr.removed.isEmpty()) {
                        "Tidak ada model baru. Daftar model sudah yang terbaru (${rr.models.size} model)."
                    } else {
                        val sb = StringBuilder()
                        if (rr.added.isNotEmpty()) sb.append("${rr.added.size} model baru ditambahkan: ${rr.added.joinToString(", ")}. ")
                        if (rr.removed.isNotEmpty()) sb.append("Dihapus karena sudah tidak aktif: ${rr.removed.joinToString(", ")}. ")
                        sb.append("Total sekarang ${rr.models.size} model.")
                        sb.toString()
                    }
                }
            } catch (t: Throwable) {
                pesan = "Gagal memperbarui daftar model: $t"
            }
            memperbaruiModel = false
            runOnUiThread {
                muatSpinnerModel()
                status(pesan)
            }
        }
    }

    // =====================================================================================
    //  Contoh suara
    // =====================================================================================

    private fun putarContoh(pos: Int) {
        val nama = Data.VOICE_KEYS.getOrNull(pos) ?: return
        val aset = String.format(Locale.US, "voice_cache/%02d_sample_%s.ogg", pos + 1, nama)
        try {
            hentikanContoh()
            dialogHasil.hentikanSuara()
            val f = File(cacheDir, "contoh_suara.ogg")
            assets.open(aset).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                hentikanContoh()
                status("Contoh suara selesai.")
            }
            mp.prepare()
            mp.start()
            player = mp
            status("Memutar contoh suara $nama.")
        } catch (e: Exception) {
            status("Berkas contoh suara $nama tidak ditemukan atau tidak bisa diputar.")
        }
        segarkanTombol()
    }

    private fun hentikanContoh() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }

    // =====================================================================================
    //  Proses: Gemini lalu efek
    // =====================================================================================

    private fun berkasMentah() = File(cacheDir, "gemini_mentah.pcm")

    private fun efekTerpilih() = daftarEfek[spEfek.selectedItemPosition.coerceIn(0, daftarEfek.size - 1)]

    private fun buatAudio() {
        if (sibuk) { status("Proses masih berjalan."); return }
        if (GeminiStore.getKey(this).isEmpty()) {
            status("Kunci API Gemini belum dimasukkan. Tekan Pengaturan kunci API Gemini.")
            dialogKunci()
            return
        }
        val naskah = etTeks.text.toString()
        if (naskah.none { it.isLetterOrDigit() }) { status("Tulis dulu naskah yang mau diubah jadi suara."); return }

        hentikanContoh()
        dialogHasil.hentikanSuara()

        val multi = spMode.selectedItemPosition == 1
        var nama1 = GeminiClient.cleanSpeakerName(etNama1.text, "Suara1")
        var nama2 = GeminiClient.cleanSpeakerName(etNama2.text, "Suara2")
        if (nama1.equals(nama2, ignoreCase = true)) { nama1 = "Suara1"; nama2 = "Suara2" }
        pref.edit().putString("speaker1_name", nama1).putString("speaker2_name", nama2).apply()

        val p = GeminiJob.Params().apply {
            text = naskah
            this.multi = multi
            voice1 = spSuara.selectedItemPosition
            voice2 = spSuara2.selectedItemPosition
            logat1 = spLogat.selectedItemPosition
            logat2 = spLogat2.selectedItemPosition
            vibe1 = spVibe.selectedItemPosition
            vibe2 = spVibe2.selectedItemPosition
            name1 = nama1
            name2 = nama2
        }
        judulTerakhir = judulBerkas(etJudul.text.toString())

        hapusHasil()
        batal.set(false)
        setSibuk(true)
        GeminiJagaService.mulai(applicationContext)
        progres(0, "Menyiapkan")
        status("Gemini sedang membuat suara. Biarkan aplikasi terbuka sampai selesai.")

        val app = applicationContext
        val pcm = berkasMentah()
        pcm.delete()
        thread {
            val res = GeminiJob.run(app, p, pcm, { msg, persen ->
                runOnUiThread { progres(persen * 6 / 10, msg) }
            }, batal)
            if (!res.ok) {
                runOnUiThread { selesaiGagal(if (res.cancelled) "Dibatalkan." else res.message) }
                return@thread
            }
            pref.edit().putInt("mentah_rate", res.rate).apply()
            runOnUiThread {
                segarkanTombol()
                olahEfek(pcm, res.rate)
            }
        }
    }

    /** Efek diganti lalu diterapkan lagi pada suara Gemini yang terakhir dibuat, tanpa memanggil Gemini. */
    private fun terapkanUlang() {
        if (sibuk) return
        val pcm = berkasMentah()
        val rate = pref.getInt("mentah_rate", 0)
        if (!pcm.exists() || pcm.length() < 2 || rate <= 0) {
            status("Belum ada suara Gemini tersimpan. Buat suara Gemini dulu.")
            segarkanTombol()
            return
        }
        hentikanContoh()
        dialogHasil.hentikanSuara()
        if (judulTerakhir.isEmpty()) judulTerakhir = judulBerkas(etJudul.text.toString())
        hapusHasil()
        batal.set(false)
        setSibuk(true)
        GeminiJagaService.mulai(applicationContext)
        status("Menerapkan efek pada suara Gemini terakhir…")
        olahEfek(pcm, rate)
    }

    /** Tahap FFmpeg (60 sampai 100 persen): PCM mentah diberi efek dan disandi ke format pilihan. */
    private fun olahEfek(pcm: File, rate: Int) {
        val fmt = daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val kbps = daftarKbps[spKbps.selectedItemPosition.coerceIn(0, daftarKbps.size - 1)]
        val e = efekTerpilih()
        val opts = Opts(
            normalize = cbRata.isChecked,
            gainDb = daftarVolume[spVolume.selectedItemPosition.coerceIn(0, daftarVolume.size - 1)],
            pitchSemi = e.pitch,
            bassDb = daftarBass[spBass.selectedItemPosition.coerceIn(0, daftarBass.size - 1)],
            echoMode = spRuang.selectedItemPosition.coerceIn(0, daftarRuang.size - 1),
            voice = e.voice,
            sampleRate = rate,   // 24 kHz mono, sama seperti proyek asli; efek tetap diolah internal di 44,1 kHz
            channels = 1,
            title = judulTerakhir.take(60),
            artist = "AudioLab novan",
            album = "Voice note Gemini"
        )
        val saringan = ArrayList<String>()
        saringan += Converter.pitchFilters(opts)
        saringan += Converter.voiceFilters(opts)
        saringan += e.ekstra
        saringan += Converter.tailFilters(opts, 0.0)

        val totalMs = pcm.length() / 2 * 1000L / rate
        val dest = File(cacheDir, "gemini_hasil_" + System.currentTimeMillis() + "." + fmt.ext)
        val args = ArrayList<String>()
        args += listOf("-y", "-nostdin", "-f", "s16le", "-ar", rate.toString(), "-ac", "1", "-i", pcm.absolutePath, "-vn")
        if (saringan.isNotEmpty()) args += listOf("-af", saringan.joinToString(","))
        args += opts.audioFormatArgs()
        args += fmt.codecArgs(kbps)
        args += opts.metadataArgs()
        args += dest.absolutePath

        runOnUiThread { progres(60, "Menerapkan efek dan menyandi ke ${fmt.label}") }
        sesi = FFmpegKit.executeWithArgumentsAsync(
            args.toTypedArray(),
            { s ->
                when {
                    ReturnCode.isCancel(s.returnCode) -> {
                        dest.delete()
                        runOnUiThread { selesaiGagal("Dibatalkan.") }
                    }
                    ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> simpanDanTampilkan(dest, fmt)
                    else -> {
                        dest.delete()
                        val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                        runOnUiThread { selesaiGagal("FFmpeg gagal (kode ${s.returnCode}): $log") }
                    }
                }
            },
            null,
            { st ->
                if (totalMs > 0) {
                    val p = 60 + (st.time.toLong() * 40L / totalMs).toInt().coerceIn(0, 39)
                    runOnUiThread { progres(p, "Menerapkan efek dan menyandi ke ${fmt.label}") }
                }
            }
        )
    }

    private fun judulBerkas(mentah: String): String {
        var t = mentah.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        t = t.replace(Regex("(?i)\\.(wav|m4a|mp3|flac)$"), "").trim()
        if (t.isEmpty()) {
            t = "VoiceNoteGemini_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        }
        return t
    }

    private fun selesaiGagal(pesan: String) {
        setSibuk(false)
        GeminiJagaService.henti(applicationContext)
        progres(0, "")
        status(pesan)
    }

    private fun simpanDanTampilkan(f: File, fmt: OutFmt) {
        val nama = "$judulTerakhir.${fmt.ext}"
        var uri: Uri? = null
        var galat: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { uri = simpanOtomatis(f, nama, fmt) } catch (e: Exception) { galat = e.message ?: "galat" }
        }
        val u = uri
        val g = galat
        runOnUiThread {
            GeminiJagaService.henti(applicationContext)
            hasilFile = f
            hasilUri = u
            hasilFmt = fmt
            setSibuk(false)
            progres(100, "Selesai")
            panelHasil.visibility = View.VISIBLE
            val lama = Converter.durasiTeks(lamaFile(f) / 1000.0)
            tvHasil.text = when {
                u != null -> "Selesai, lama $lama. Tersimpan di folder Musik, AudioLab Novan, Voice note Gemini, dengan nama $nama."
                g != null -> "Selesai, lama $lama, tetapi tidak bisa disimpan otomatis ($g). Tekan Simpan sebagai."
                else -> "Selesai, lama $lama. Tekan Simpan sebagai untuk memilih lokasi simpan."
            }
            status(tvHasil.text.toString())
            btnBagikan.isEnabled = u != null
            hasilNama = if (u != null) nama else f.name
            segarkanTombol()
            val umum = "Audio selesai: ${hasilNama}. Tekan Kirim ke WhatsApp, pilih WhatsApp atau WhatsApp Business, lalu buka obrolan tujuan."
            Say.say(applicationContext, umum)
            GeminiJagaService.selesai(applicationContext, "Audio siap: ${hasilNama}",
                "Buka AudioLab, tekan Kirim ke WhatsApp, pilih WhatsApp atau WhatsApp Business, lalu buka obrolan tujuan (kolom chat harus kosong).")
        }
    }

    private fun lamaFile(f: File): Long = try {
        val d = com.arthenica.ffmpegkit.FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation?.duration
        ((d?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
    } catch (_: Throwable) { 0L }

    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanOtomatis(src: File, nama: String, fmt: OutFmt): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, nama)
            put(MediaStore.Audio.Media.MIME_TYPE, fmt.mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioLab Novan/Voice note Gemini")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val koleksi = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            val selesai = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            contentResolver.update(u, selesai, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    // =====================================================================================
    //  Hasil: menu hasil, bagikan, simpan
    // =====================================================================================

    /** Dialog menu hasil: putar, jeda, lanjutkan, kirim ke WhatsApp, bagikan, ubah nama, hapus. */
    private fun bukaMenuHasil() {
        val f = hasilFile
        val u = hasilUri ?: f?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        if (u == null) { status("Belum ada hasil."); return }
        dialogHasil.tombolStatusWa = true
        dialogHasil.saatDiubah = { h ->
            if (h.uri.scheme == "file") hasilFile = File(h.uri.path ?: "") else hasilUri = h.uri
            hasilNama = h.nama
            tvHasil.text = "Nama berkas sekarang ${h.nama}."
        }
        dialogHasil.saatDihapus = {
            hasilUri = null
            hasilFile?.delete()
            hasilFile = null
            panelHasil.visibility = View.GONE
            status("Hasil sudah dihapus.")
        }
        dialogHasil.tampilkan(u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }, hasilFmt.mime)
    }

    private fun alamatHasil(): Uri? = hasilUri ?: hasilFile?.takeIf { it.exists() }?.let { Uri.fromFile(it) }

    private fun kirimWaLangsung() {
        val u = alamatHasil()
        if (u == null) { status("Belum ada hasil."); return }
        hentikanPemutarHasil()
        WaKirim.mulai(this, u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }) { status(it) }
    }

    /** Tahap 66: sama seperti kirimWaLangsung, tetapi untuk membuat status suara WhatsApp. */
    private fun kirimStatusLangsung() {
        val u = alamatHasil()
        if (u == null) { status("Belum ada hasil."); return }
        hentikanPemutarHasil()
        WaKirim.mulaiStatus(this, u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }) { status(it) }
    }

    private fun putarJedaHasil() {
        val mp = pemutarHasil
        if (mp != null) {
            try {
                if (pemutarJeda) { mp.start(); pemutarJeda = false; btnPutarHasil.text = "Jeda" }
                else if (mp.isPlaying) { mp.pause(); pemutarJeda = true; btnPutarHasil.text = "Lanjut" }
                else { mp.start(); btnPutarHasil.text = "Jeda" }
                return
            } catch (_: Exception) { hentikanPemutarHasil() }
        }
        val u = alamatHasil()
        if (u == null) { status("Belum ada hasil."); return }
        hentikanContoh()
        dialogHasil.hentikanSuara()
        try {
            val n = MediaPlayer()
            n.setDataSource(this, u)
            n.setOnCompletionListener { hentikanPemutarHasil(); status("Pemutaran selesai.") }
            n.prepare()
            n.start()
            pemutarHasil = n
            pemutarJeda = false
            btnPutarHasil.text = "Jeda"
        } catch (e: Exception) {
            hentikanPemutarHasil()
            status("Hasil audio tidak bisa diputar: ${e.message}")
        }
    }

    private fun hentikanPemutarHasil() {
        try { pemutarHasil?.stop() } catch (_: Exception) { }
        try { pemutarHasil?.release() } catch (_: Exception) { }
        pemutarHasil = null
        pemutarJeda = false
        if (::btnPutarHasil.isInitialized) btnPutarHasil.text = "Putar hasil audio"
    }

    private fun hapusHasil() {
        hentikanPemutarHasil()
        dialogHasil.hentikanSuara()
        hasilFile?.delete()
        hasilFile = null
        hasilUri = null
        panelHasil.visibility = View.GONE
    }

    private fun bagikan() {
        val u = hasilUri
        if (u == null) { status("Simpan dulu hasilnya dengan tombol Simpan sebagai."); return }
        try {
            val kirim = Intent(Intent.ACTION_SEND).apply {
                type = hasilFmt.mime
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(kirim, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            status("Menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    private fun simpanKeLokasi() {
        val f = hasilFile
        if (f == null || !f.exists()) { status("Belum ada hasil untuk disimpan."); return }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = hasilFmt.mime
            putExtra(Intent.EXTRA_TITLE, "$judulTerakhir.${hasilFmt.ext}")
        }
        simpanSebagai.launch(i)
    }

    // =====================================================================================
    //  Status, progres, tombol
    // =====================================================================================

    private fun status(t: String) { tvStatus.text = t }

    private fun progres(p: Int, teks: String) {
        progress.progress = p
        tvProgress.text = if (teks.isEmpty()) "" else "$teks, $p persen."
        // Umumkan ke pembaca layar tiap kelipatan 10 persen saja, agar tidak berisik.
        val kelompok = p / 10
        if (kelompok == terakhirUmum) tvProgress.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_NONE
        else tvProgress.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        terakhirUmum = kelompok
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        if (s) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        segarkanTombol()
    }

    private fun segarkanTombol() {
        if (!::btnBuat.isInitialized) return
        val bisa = !sibuk
        btnBuat.isEnabled = bisa
        val adaMentah = berkasMentah().let { it.exists() && it.length() > 1 } && pref.getInt("mentah_rate", 0) > 0
        btnUlang.isEnabled = bisa && adaMentah
        btnBerhenti.isEnabled = sibuk || player != null
        for (v in listOf<View>(spMode, spSuara, spSuara2, spLogat, spVibe, spLogat2, spVibe2, spModel, etNama1, etNama2, etJudul,
            btnKunci, btnModel, btnBuka, btnHapusTeks, etTeks, etJeda, spEfek, spRuang, spBass, spVolume, cbRata, spFormat, btnSimpan, btnContoh, btnContoh2)) {
            v.isEnabled = bisa
        }
        spKbps.isEnabled = bisa && daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)].lossy
    }

    private fun hentikanSemua() {
        if (sibuk) {
            batal.set(true)
            try { sesi?.cancel() } catch (_: Exception) { }
            status("Membatalkan…")
        } else if (player != null) {
            hentikanContoh()
            status("Contoh suara dihentikan.")
        }
        segarkanTombol()
    }

    override fun onStop() {
        super.onStop()
        // Contoh suara jangan berlanjut saat layar ditinggalkan; proses pembuatan audio dibiarkan jalan.
        if (!sibuk) {
            hentikanContoh()
            hentikanPemutarHasil()
            dialogHasil.hentikanSuara()
        }
    }

    override fun onDestroy() {
        if (sibuk && !isChangingConfigurations) {
            batal.set(true)
            try { sesi?.cancel() } catch (_: Exception) { }
        }
        dialogHasil.lepas()
        hentikanContoh()
        hentikanPemutarHasil()
        // Berkas sementara hasil yang belum disimpan ke Musik boleh dihapus; suara mentah Gemini sengaja disisakan
        // supaya efek bisa diterapkan ulang di lain waktu.
        if (!isChangingConfigurations) {
            hasilFile?.delete()
            if (!sibuk) GeminiJagaService.henti(applicationContext)
        }
        super.onDestroy()
    }
}
