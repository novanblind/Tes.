package id.ytplayer.music

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import java.util.Locale

/**
 * Mesin audio Novan: mode suara siap pakai, preamp, equalizer grafis 10 atau 32 pita, bass, treble, lebar stereo,
 * mono, keseimbangan kiri-kanan, reverb, keluaran Hi-Res, dan limiter. Semua penggeser memakai langkah bulat
 * supaya satu usapan pembaca layar menggeser tepat satu langkah.
 */
class NovanEngineActivity : AppCompatActivity() {

    private lateinit var box: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Mesin audio Novan"
        val scroll = ScrollView(this)
        scroll.fitsSystemWindows = true
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(32))
        scroll.addView(box)
        setContentView(scroll)
        build()
    }

    private fun build() {
        box.removeAllViews()
        val p = Prefs.of(this)
        heading("Mesin audio Novan")
        text("Pemrosesan suara 64-bit sendiri, terpisah dari efek bawaan Android. Satu pengaturan yang sama berlaku untuk Music Player, YT Player, dan YouTube Music.")

        switch("Aktifkan mesin audio", p.getBoolean(NovanEngine.K_ON, false)) {
            p.edit().putBoolean(NovanEngine.K_ON, it).apply()
            NovanEngine.reload(this)
        }

        heading("Pengaturan suara per perangkat")
        val devNow = NovanEngine.DEV_NAMES[NovanEngine.deviceCategory(this)] ?: "Speaker HP"
        text(
            "Pakai pengaturan suara yang berbeda untuk speaker HP, headphone kabel, Bluetooth, dan USB. " +
                "Caranya: nyalakan saklar ini, atur suara untuk perangkat yang sedang dipakai, lalu sambungkan " +
                "perangkat lain dan atur lagi. Setelah itu aplikasi berganti sendiri setiap perangkat berganti. " +
                "Perangkat yang sedang dipakai sekarang: $devNow."
        )
        switch("Atur suara per perangkat", NovanEngine.perDeviceEnabled(this)) {
            NovanEngine.setPerDevice(this, it)
        }

        heading("Mode suara")
        text("Pilih mode siap pakai, lalu bila perlu halus-kan sendiri di bawah. Memilih mode otomatis menyalakan mesin audio dan mengatur pita, bass, treble, lebar stereo, dan preamp.")
        val pIdx = p.getInt(NovanEngine.K_PRESET, -1)
        val pName = NovanEngine.PRESETS.getOrNull(pIdx)?.name ?: "Kustom"
        val pBtn = Button(this)
        pBtn.text = "Mode: $pName"
        pBtn.textSize = 16f
        pBtn.minHeight = dp(56)
        pBtn.contentDescription = "Pilih mode suara. Sekarang: $pName"
        pBtn.setOnClickListener {
            val labels = (NovanEngine.PRESETS.map { "${it.name}. ${it.desc}" } + "Kustom (atur sendiri)").toTypedArray()
            AlertDialog.Builder(this).setTitle("Mode suara").setItems(labels) { _, w ->
                if (w < NovanEngine.PRESETS.size) NovanEngine.applyPreset(this, w)
                else p.edit().putInt(NovanEngine.K_PRESET, -1).apply()
                build()
            }.show()
        }
        box.addView(pBtn)

        heading("Penguat awal")
        slider("Preamp", 24, p.getInt(NovanEngine.K_PREAMP, 0) + 12,
            { signedDb(it - 12) }, { spokenDb(it - 12) }) {
            put(NovanEngine.K_PREAMP, it - 12)
        }

        heading("Equalizer grafis")
        val mode = NovanEngine.mode(this)
        val modeBtn = Button(this)
        modeBtn.text = "Jumlah pita: $mode"
        modeBtn.textSize = 16f
        modeBtn.minHeight = dp(56)
        modeBtn.contentDescription = "Ganti jumlah pita equalizer. Sekarang $mode pita"
        modeBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Jumlah pita")
                .setItems(arrayOf("10 pita", "32 pita")) { _, w ->
                    p.edit().putString(NovanEngine.K_MODE, if (w == 1) "32" else "10").apply()
                    NovanEngine.reload(this)
                    build()
                }.show()
        }
        box.addView(modeBtn)

        val g = NovanEngine.gains(this, mode)
        val f = NovanEngine.hz(mode)
        for (i in g.indices) {
            slider(hzLabel(f[i]), 24, Math.round(g[i]).toInt() + 12,
                { signedDb(it - 12) }, { spokenDb(it - 12) }) {
                NovanEngine.setGain(this, mode, i, (it - 12).toDouble())
            }
        }

        heading("Nada")
        slider("Bass", 24, p.getInt(NovanEngine.K_BASS, 0) + 12,
            { signedDb(it - 12) }, { spokenDb(it - 12) }) { put(NovanEngine.K_BASS, it - 12) }
        slider("Treble", 24, p.getInt(NovanEngine.K_TREBLE, 0) + 12,
            { signedDb(it - 12) }, { spokenDb(it - 12) }) { put(NovanEngine.K_TREBLE, it - 12) }

        heading("Ruang suara")
        slider("Lebar stereo", 20, p.getInt(NovanEngine.K_WIDTH, 100) / 10,
            { "${it * 10} persen" }, { "${it * 10} persen, 100 persen normal" }) {
            put(NovanEngine.K_WIDTH, it * 10)
        }
        slider("Keseimbangan kiri kanan", 20, p.getInt(NovanEngine.K_BALANCE, 0) / 10 + 10,
            { balanceText(it - 10) }, { balanceText(it - 10) }) {
            put(NovanEngine.K_BALANCE, (it - 10) * 10)
        }
        switch("Campur ke mono", p.getBoolean(NovanEngine.K_MONO, false)) {
            p.edit().putBoolean(NovanEngine.K_MONO, it).apply()
            NovanEngine.reload(this)
        }

        heading("Reverb")
        text("Gema ruangan. Berlaku bila mesin audio aktif. Jumlah 0 persen berarti reverb mati.")
        val rIdx = p.getInt(NovanEngine.K_ROOM_PRESET, -1)
        val rName = NovanEngine.ROOMS.getOrNull(rIdx)?.name ?: "Kustom"
        val rBtn = Button(this)
        rBtn.text = "Mode ruang: $rName"
        rBtn.textSize = 16f
        rBtn.minHeight = dp(56)
        rBtn.contentDescription = "Pilih mode ruang reverb. Sekarang: $rName"
        rBtn.setOnClickListener {
            val labels = (NovanEngine.ROOMS.map { "${it.name}. ${it.desc}" } + "Kustom (atur sendiri)").toTypedArray()
            AlertDialog.Builder(this).setTitle("Mode ruang").setItems(labels) { _, w ->
                if (w < NovanEngine.ROOMS.size) NovanEngine.applyRoom(this, w)
                else p.edit().putInt(NovanEngine.K_ROOM_PRESET, -1).apply()
                build()
            }.show()
        }
        box.addView(rBtn)
        slider("Jumlah reverb", 20, p.getInt(NovanEngine.K_REV_MIX, 0) / 5,
            { "${it * 5} persen" }, { if (it == 0) "mati" else "${it * 5} persen" }) {
            put(NovanEngine.K_REV_MIX, it * 5)
        }
        slider("Ukuran ruang", 20, p.getInt(NovanEngine.K_REV_ROOM, 50) / 5,
            { "${it * 5} persen" }, { "${it * 5} persen" }) {
            put(NovanEngine.K_REV_ROOM, it * 5)
        }
        slider("Peredam nada tinggi", 20, p.getInt(NovanEngine.K_REV_DAMP, 50) / 5,
            { "${it * 5} persen" }, { "${it * 5} persen" }) {
            put(NovanEngine.K_REV_DAMP, it * 5)
        }

        heading("Keluaran Hi-Res")
        text("Mengirim suara ke perangkat sebagai float 32-bit tanpa dither, sehingga hasil equalizer dan reverb tidak dibulatkan ke 16-bit. Hi-Res, laju sampel keluaran, dan bit-perfect mengikuti mesin audio: bila \"Aktifkan mesin audio\" mati, ketiganya ikut mati; bila mesin audio menyala, ketiganya mengikuti pengaturan masing-masing di bawah ini. Perubahan berlaku mulai lagu berikutnya.")
        switch("Keluaran Hi-Res (float 32-bit)", p.getBoolean(NovanEngine.K_HIRES, true)) {
            p.edit().putBoolean(NovanEngine.K_HIRES, it).apply()
            NovanEngine.reload(this)
        }

        heading("Laju sampel keluaran")
        text(
            "Mesin Novan menaikkan laju sampel sendiri dengan hitungan 64-bit, sehingga pengubah laju bawaan Android " +
                "tidak perlu bekerja. Otomatis memilih yang terbaik untuk perangkat keluaran: laju mixer biasa, atau " +
                "96 dan 192 kHz bila DAC USB menerimanya langsung. Pada speaker dan headphone biasa, Android tetap " +
                "menyesuaikan ke laju mixernya, jadi 192 dan 384 kHz paling berguna di DAC USB. 384 kHz membebani " +
                "prosesor dan baterai. Laju tidak pernah diturunkan. Bila perangkat menolak laju pilihan, pemutar " +
                "otomatis kembali ke laju berkas lagu. Perubahan berlaku mulai lagu berikutnya."
        )
        val rateNames = listOf(
            "auto" to "Otomatis (disarankan)",
            "file" to "Ikuti berkas lagu",
            "48000" to "48 kHz",
            "96000" to "96 kHz",
            "192000" to "192 kHz",
            "384000" to "384 kHz"
        )
        val curRate = p.getString(NovanEngine.K_RATE, "auto") ?: "auto"
        val curName = rateNames.firstOrNull { it.first == curRate }?.second ?: rateNames[0].second
        val rateBtn = Button(this)
        rateBtn.text = "Laju keluaran: $curName"
        rateBtn.textSize = 16f
        rateBtn.minHeight = dp(56)
        rateBtn.contentDescription = "Pilih laju sampel keluaran. Sekarang: $curName"
        rateBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Laju keluaran")
                .setItems(rateNames.map { it.second }.toTypedArray()) { _, w ->
                    p.edit().putString(NovanEngine.K_RATE, rateNames[w].first).apply()
                    NovanEngine.reload(this)
                    build()
                }.show()
        }
        box.addView(rateBtn)

        heading("Lewati resampling Android")
        if (Build.VERSION.SDK_INT >= 34) {
            text(
                "Mode bit-perfect: mixer Android dikunci ke format perangkat keluaran dan suara dikirim tanpa " +
                    "resampling, pencampuran, atau pengaturan volume dari Android. Awas: volume sistem tidak berlaku, " +
                    "jadi atur volume di DAC atau ampli dan mulai dari yang rendah. Hanya bekerja bila keluaran " +
                    "mendukungnya, biasanya DAC USB. Bila tidak, pemutaran berjalan seperti biasa."
            )
            switch("Bit-perfect (Android 14 ke atas)", p.getBoolean(NovanEngine.K_BITPERFECT, false)) { on ->
                if (on) {
                    AlertDialog.Builder(this)
                        .setTitle("Aktifkan bit-perfect?")
                        .setMessage("Volume sistem tidak berlaku pada mode ini. Pastikan volume DAC atau ampli rendah sebelum memutar.")
                        .setPositiveButton("Aktifkan") { _, _ ->
                            p.edit().putBoolean(NovanEngine.K_BITPERFECT, true).apply()
                            NovanEngine.reload(this)
                            build()
                        }
                        .setNegativeButton("Batal") { _, _ -> build() }
                        .setOnCancelListener { build() }
                        .show()
                } else {
                    p.edit().putBoolean(NovanEngine.K_BITPERFECT, false).apply()
                    NovanEngine.reload(this)
                }
            }
        } else {
            text(
                "Bit-perfect memerlukan Android 14 ke atas. Di versi ini, pilih laju keluaran yang sama dengan " +
                    "laju mixer perangkat (Otomatis melakukannya) supaya pengubah laju bawaan Android tidak bekerja."
            )
        }
        text(NovanEngine.deviceInfo(this))

        heading("Pengaman")
        switch("Limiter (cegah suara pecah)", p.getBoolean(NovanEngine.K_LIMITER, true)) {
            p.edit().putBoolean(NovanEngine.K_LIMITER, it).apply()
            NovanEngine.reload(this)
        }

        val reset = Button(this)
        reset.text = "Atur ulang semua"
        reset.textSize = 16f
        reset.minHeight = dp(56)
        reset.setOnClickListener {
            NovanEngine.resetAll(this)
            build()
        }
        box.addView(reset)
    }

    private fun put(key: String, value: Int) {
        val e = Prefs.of(this).edit().putInt(key, value)
        when (key) {
            NovanEngine.K_REV_MIX, NovanEngine.K_REV_ROOM, NovanEngine.K_REV_DAMP -> e.putInt(NovanEngine.K_ROOM_PRESET, -1)
            else -> e.putInt(NovanEngine.K_PRESET, -1)
        }
        e.apply()
        NovanEngine.reload(this)
    }

    private fun switch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.text = label
        sw.textSize = 18f
        sw.minHeight = dp(56)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        box.addView(sw)
    }

    private fun slider(
        name: String,
        max: Int,
        start: Int,
        valueText: (Int) -> String,
        spokenText: (Int) -> String,
        onChange: (Int) -> Unit
    ) {
        val s0 = start.coerceIn(0, max)
        val label = TextView(this)
        label.textSize = 16f
        label.setPadding(0, dp(12), 0, 0)
        label.text = "$name: ${valueText(s0)}"
        label.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

        val sb = SeekBar(this)
        sb.max = max
        sb.progress = s0
        sb.minimumHeight = dp(48)
        sb.contentDescription = name
        ViewCompat.setStateDescription(sb, spokenText(s0))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                label.text = "$name: ${valueText(p)}"
                ViewCompat.setStateDescription(s, spokenText(p))
                if (fromUser) onChange(p)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(label)
        box.addView(sb)
    }

    private fun heading(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 22f
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(16), 0, dp(4))
        ViewCompat.setAccessibilityHeading(t, true)
        box.addView(t)
    }

    private fun text(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 16f
        box.addView(t)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hzLabel(hz: Double): String =
        if (hz >= 1000) String.format(Locale("id"), "%.2f kHz", hz / 1000.0).replace(",00", "")
        else "${hz.toInt()} Hz"

    private fun signedDb(v: Int): String = if (v > 0) "+$v dB" else "$v dB"

    private fun spokenDb(v: Int): String = when {
        v > 0 -> "naik $v desibel"
        v < 0 -> "turun ${-v} desibel"
        else -> "datar, 0 desibel"
    }

    private fun balanceText(v: Int): String = when {
        v > 0 -> "kanan ${v * 10} persen"
        v < 0 -> "kiri ${-v * 10} persen"
        else -> "tengah"
    }
}
