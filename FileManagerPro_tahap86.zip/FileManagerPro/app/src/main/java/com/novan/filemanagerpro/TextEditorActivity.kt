package com.novan.filemanagerpro

import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Button
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/**
 * Editor teks bawaan. Membuka berkas lokal apa pun yang isinya teks (skrip, konfigurasi, log, dan lain-lain) dan
 * menyimpannya kembali dengan pengodean aslinya (UTF-8, UTF-16 BOM, atau Windows-1252). Tombol Simpan selalu tampil.
 * Uri dari aplikasi lain: coba disimpan balik, bila tidak diizinkan hanya baca. Berkas biner ditolak.
 */
class TextEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
    }

    /** Tidak ada batas karakter buatan; satu-satunya batas adalah memori HP (teks di memori memakan beberapa kali ukuran berkas). */
    private fun maxBytes(): Long = (Runtime.getRuntime().maxMemory() / 8).coerceAtLeast(16L * 1024 * 1024)
    private fun maxMb(): Int = (maxBytes() / (1024 * 1024)).toInt()

    private var baseTitle = ""
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var edit: EditText
    private var file: File? = null
    private var uri: Uri? = null
    private var loaded = false
    private var dirty = false
    private var charset: Charset = Charsets.UTF_8
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_editor)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        edit = findViewById(R.id.editor)

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path != null) {
            file = File(path)
        } else {
            val d = intent.data
            if (d != null && d.scheme == "file" && d.path != null) file = File(d.path!!) else uri = d
        }
        baseTitle = file?.name ?: uri?.lastPathSegment ?: getString(R.string.text_editor)
        title = baseTitle
        btnSave = findViewById(R.id.btn_save)
        btnSave.setOnClickListener { save() }

        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loaded) { dirty = true; refreshTitle() }
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                confirmExit()
            }
        })
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun refreshTitle() {
        title = if (dirty) "* $baseTitle" else baseTitle
    }

    /** Terjemahkan byte jadi teks dan ingat pengodeannya supaya penyimpanan tidak merusak berkas. */
    private fun decode(bytes: ByteArray): String? {
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            charset = Charsets.UTF_16LE; return String(bytes, charset)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            charset = Charsets.UTF_16BE; return String(bytes, charset)
        }
        val head = minOf(bytes.size, 8192)
        var ctrl = 0
        for (i in 0 until head) {
            val v = bytes[i].toInt() and 0xFF
            if (v == 0) return null                       // biner
            if (v < 9 || (v in 14..31 && v != 27)) ctrl++
        }
        if (head > 0 && ctrl > head / 50) return null
        return try {
            val dec = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            charset = Charsets.UTF_8
            dec.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: Exception) {
            charset = try { Charset.forName("windows-1252") } catch (_: Exception) { Charsets.ISO_8859_1 }
            String(bytes, charset)
        }
    }

    private fun load() {
        executor.execute {
            var text: String? = null
            var err: String? = null
            try {
                val f = file
                var bytes: ByteArray? = null
                if (f != null) {
                    if (f.length() > maxBytes()) err = getString(R.string.editor_too_large, maxMb())
                    else bytes = f.readBytes()
                } else if (uri != null) {
                    contentResolver.openInputStream(uri!!)?.use { ins ->
                        val b = ins.readBytes()
                        if (b.size > maxBytes()) err = getString(R.string.editor_too_large, maxMb()) else bytes = b
                    }
                }
                val got = bytes
                if (got != null) {
                    text = decode(got)
                    if (text == null) err = getString(R.string.editor_binary)
                }
            } catch (e: OutOfMemoryError) {
                err = getString(R.string.editor_no_memory)
            } catch (e: Exception) {
                err = getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                if (text != null) {
                    edit.setText(text)
                    loaded = true
                    dirty = false
                    refreshTitle()
                    invalidateOptionsMenu()
                } else {
                    say(err ?: getString(R.string.cannot_open))
                    // berkas tidak bisa dibaca atau bukan teks: jangan biarkan layar kosong yang bisa "disimpan"
                    edit.isEnabled = false
                    btnSave.isEnabled = false
                }
            }
        }
    }

    private fun save(after: (() -> Unit)? = null) {
        if (!loaded) return
        val f = file
        val u = uri
        if (f == null && u == null) { say(getString(R.string.editor_readonly)); return }
        val text = edit.text.toString()
        btnSave.isEnabled = false
        executor.execute {
            var ok = false
            var cs = charset
            var upgraded = false
            val msg = try {
                if (!cs.newEncoder().canEncode(text)) { cs = Charsets.UTF_8; upgraded = true }
                val out = text.toByteArray(cs)
                if (f != null) {
                    f.writeBytes(out)
                } else {
                    val os = contentResolver.openOutputStream(u!!, "wt")
                        ?: throw SecurityException("read-only")
                    os.use { it.write(out) }
                }
                ok = true
                if (upgraded) getString(R.string.editor_saved_utf8) else getString(R.string.saved)
            } catch (e: SecurityException) {
                getString(R.string.editor_readonly)
            } catch (e: OutOfMemoryError) {
                getString(R.string.editor_no_memory)
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isDestroyed) return@post
                btnSave.isEnabled = true
                if (ok) {
                    charset = cs
                    // dianggap bersih hanya bila isi belum berubah lagi selama penyimpanan
                    if (edit.text.toString() == text) dirty = false
                    refreshTitle()
                }
                say(msg)
                if (ok && !dirty) after?.invoke()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_S && event.isCtrlPressed) { save(); return true }
        return super.onKeyDown(keyCode, event)
    }

    private fun confirmExit() {
        if (!dirty) { finish(); return }
        AlertDialog.Builder(this)
            .setTitle(R.string.unsaved_title)
            .setMessage(R.string.unsaved_message)
            .setPositiveButton(R.string.action_save) { _, _ -> save { finish() } }
            .setNegativeButton(R.string.discard) { _, _ -> dirty = false; finish() }
            .setNeutralButton(R.string.cancel, null)
            .show()
    }

    private fun promptFind() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.search_hint)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.editor_find)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> find(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private var lastQuery = ""

    private fun find(q: String) {
        if (q.isEmpty()) return
        lastQuery = q
        val text = edit.text.toString()
        var from = edit.selectionEnd.coerceAtLeast(0)
        var i = text.indexOf(q, from, ignoreCase = true)
        if (i < 0 && from > 0) i = text.indexOf(q, 0, ignoreCase = true)
        if (i < 0) { say(getString(R.string.editor_not_found)); return }
        edit.requestFocus()
        edit.setSelection(i, i + q.length)
        val line = text.substring(0, i).count { it == '\n' } + 1
        say(getString(R.string.editor_found_line, line))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.editor_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_save).isVisible = true
        menu.findItem(R.id.action_find_next).isVisible = lastQuery.isNotEmpty()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> confirmExit()
            R.id.action_save -> save()
            R.id.action_find -> promptFind()
            R.id.action_find_next -> find(lastQuery)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
