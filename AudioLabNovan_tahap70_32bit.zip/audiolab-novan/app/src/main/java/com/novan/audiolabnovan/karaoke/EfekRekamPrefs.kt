package com.novan.audiolabnovan.karaoke

import android.content.Context
import android.media.MediaRecorder

/**
 * Tahap 47: pengaturan efek langsung pada perekam suara (sumber "Mikrofon dengan efek langsung").
 * Disimpan di berkas pengaturan "efek_rekam". Nilai pilihan disimpan sebagai nomor urut daftarnya.
 * Bawaan = setelan bawaan karaoke: karaoke klasik, dengung 70 Hz, gerbang peka, kompresor sedang,
 * penghilang desis sedang, pembatas menyala, pantauan headset menyala.
 */
class EfekRekamPrefs(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences("efek_rekam", Context.MODE_PRIVATE)

    private fun idx(k: String, def: Int, n: Int) = sp.getInt(k, def).coerceIn(0, n - 1)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    /** Pilihan cepat gema dan echo: nomor urut dari [KaraokePrefs.EFEK_PRESET]. */
    var efek: Int
        get() = idx("efek", 2, KaraokePrefs.EFEK_PRESET.size)
        set(v) = put("efek", v)

    var dengung: Int
        get() = idx("dengung", 1, DENGUNG_HZ.size)
        set(v) = put("dengung", v)

    var gerbang: Int
        get() = idx("gerbang", 2, GERBANG_DB.size)
        set(v) = put("gerbang", v)

    var nada: Int
        get() = idx("nada", NADA_NOL, NADA_SEMITON.size)
        set(v) = put("nada", v)

    var kompresor: Int
        get() = idx("kompresor", 2, 4)
        set(v) = put("kompresor", v)

    var deEsser: Int
        get() = idx("deesser", 2, 4)
        set(v) = put("deesser", v)

    var pembatas: Boolean
        get() = sp.getBoolean("pembatas", true)
        set(v) = sp.edit().putBoolean("pembatas", v).apply()

    var bass: Int
        get() = idx("bass", 0, KaraokePrefs.BASS_DB.size)
        set(v) = put("bass", v)

    var jernih: Int
        get() = idx("jernih", 0, KaraokePrefs.JERNIH_DB.size)
        set(v) = put("jernih", v)

    /** Penguatan suara masuk: nomor urut dari [GAIN_DB], bawaan 0 dB. */
    var gain: Int
        get() = idx("gain", GAIN_NOL, GAIN_DB.size)
        set(v) = put("gain", v)

    /** Putar suara sendiri (dengan efek) ke headset selagi merekam; hanya bila headset terpasang. */
    var pantau: Boolean
        get() = sp.getBoolean("pantau", true)
        set(v) = sp.edit().putBoolean("pantau", v).apply()

    /** Sumber mikrofon: 0 mikrofon, 1 pengenalan suara, 2 komunikasi, 3 mikrofon kamera, 4 mentah. */
    var sumber: Int
        get() = idx("sumber", 0, SUMBER.size)
        set(v) = put("sumber", v)

    fun konfigEfek(): KonfigEfek = KaraokePrefs.efekPreset(efek)

    fun konfigVokal() = KonfigVokal(
        DENGUNG_HZ[dengung], GERBANG_DB[gerbang], NADA_SEMITON[nada], kompresor, pembatas, deEsser
    )

    /** Kembali ke setelan bawaan karaoke (kunci dihapus, nilai bawaan kelas ini berlaku). */
    fun setelBawaanKaraoke() {
        val e = sp.edit()
        for (k in arrayOf("efek", "dengung", "gerbang", "nada", "kompresor", "deesser", "pembatas", "bass", "jernih", "gain", "pantau", "sumber")) e.remove(k)
        e.apply()
    }

    /** Mematikan semua efek (suara mikrofon apa adanya); sumber dan pantauan tidak diubah. */
    fun matikanSemua() {
        efek = 0
        dengung = 0
        gerbang = 0
        nada = NADA_NOL
        kompresor = 0
        deEsser = 0
        pembatas = false
        bass = 0
        jernih = 0
        gain = GAIN_NOL
    }

    companion object {
        /** Batas bawah penyaring dengung (Hz); 0 = mati. */
        val DENGUNG_HZ = intArrayOf(0, 70, 100, 150)
        /** Ambang gerbang desis (dB); 0 = mati. */
        val GERBANG_DB = intArrayOf(0, -60, -52, -45, -38)
        /** Pergeseran nada dalam semiton; urutan sama dengan larik k_nada_suara. */
        val NADA_SEMITON = intArrayOf(-12, -6, -4, -2, -1, 0, 1, 2, 4, 6, 12)
        const val NADA_NOL = 5
        /** Penguatan suara masuk (dB); urutan sama dengan larik k_gain_suara. */
        val GAIN_DB = intArrayOf(-6, -3, 0, 3, 6, 9, 12, 15, 18, 24)
        const val GAIN_NOL = 2
        /** Sumber AudioRecord menurut nomor urut pilihan sumber. */
        val SUMBER = intArrayOf(
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.CAMCORDER,
            MediaRecorder.AudioSource.UNPROCESSED
        )
    }
}
