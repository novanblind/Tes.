package com.novan.talkbacknovan;

/** Cara pindah dengan geser kanan/kiri: per jenis elemen atau per bagian teks. */
public final class Granularitas {
    public static final int ITEM = 0;
    public static final int JUDUL = 1;
    public static final int TAUTAN = 2;
    public static final int TOMBOL = 3;
    public static final int KOLOM = 4;
    public static final int CENTANG = 5;
    public static final int GAMBAR = 6;
    public static final int KARAKTER = 7;
    public static final int KATA = 8;
    public static final int KALIMAT = 9;
    public static final int PARAGRAF = 10;

    public static final String[] NAMA = {
            "Item", "Judul", "Tautan", "Tombol", "Kolom isian",
            "Kotak centang dan sakelar", "Gambar",
            "Karakter", "Kata", "Kalimat", "Paragraf"
    };

    public static boolean teks(int g) {
        return g >= KARAKTER;
    }

    private Granularitas() {}
}
