package com.novan.filemanagermax

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.io.File

/**
 * Dialog hapus bersama untuk berkas dan folder: menampilkan jumlah item, rincian folder,
 * berkas, dan ukuran, serta kotak centang "Hapus secara permanen".
 * Tercentang = langsung dihapus permanen; tidak tercentang = dipindah ke tempat sampah.
 * Isi awal kotak mengikuti pengaturan "Gunakan tempat sampah saat menghapus".
 */
object DeleteDialog {

    private const val MAX_DEPTH = 64

    /** [folder, berkas, byte] */
    private fun scan(f: File, acc: LongArray, depth: Int = 0) {
        if (f.isDirectory) {
            acc[0]++
            if (depth >= MAX_DEPTH) return
            f.listFiles()?.forEach { scan(it, acc, depth + 1) }
        } else {
            acc[1]++
            acc[2] += f.length()
        }
    }

    fun show(act: Activity, files: List<File>, onConfirm: (toTrash: Boolean) -> Unit) {
        if (files.isEmpty()) return
        val inTrash = files.any { TrashManager.isInTrash(it) }
        val useTrash = Prefs.useTrash(act) && !inTrash
        // Pengaturan lama: tanpa tanya, langsung ke tempat sampah.
        if (useTrash && !Prefs.trashConfirm(act)) {
            onConfirm(true)
            return
        }

        val pad = (20 * act.resources.displayMetrics.density).toInt()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val msg = TextView(act).apply {
            text = act.getString(R.string.delete_dialog_message, files.size)
            textSize = 18f
        }
        val stats = TextView(act).apply {
            text = act.getString(R.string.delete_dialog_calculating)
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val permanent = CheckBox(act).apply {
            text = act.getString(R.string.delete_dialog_permanent)
            textSize = 16f
            isChecked = !useTrash
            if (inTrash) {
                // Isi tempat sampah tidak bisa dipindah lagi ke tempat sampah.
                isEnabled = false
            }
        }
        box.addView(msg)
        box.addView(stats)
        box.addView(permanent)

        val dlg = AlertDialog.Builder(act)
            .setTitle(R.string.delete_dialog_title)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> onConfirm(!permanent.isChecked) }
            .setNegativeButton(R.string.delete_dialog_cancel, null)
            .show()

        // Hitung rincian di thread latar agar folder besar tidak membekukan layar.
        val main = Handler(Looper.getMainLooper())
        Thread {
            val acc = LongArray(3)
            for (f in files) scan(f, acc)
            main.post {
                if (!dlg.isShowing || act.isDestroyed) return@post
                stats.text = act.getString(
                    R.string.delete_dialog_stats, acc[0], acc[1], Util.formatSize(act, acc[2])
                )
                stats.visibility = View.VISIBLE
            }
        }.start()
    }
}
