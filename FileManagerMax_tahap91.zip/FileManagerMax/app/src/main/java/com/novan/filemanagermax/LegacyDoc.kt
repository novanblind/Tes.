package com.novan.filemanagermax

import java.io.File
import java.nio.charset.Charset

/**
 * Pembaca dokumen Word lama (.doc, .dot; Word 97 sampai 2003) tanpa library tambahan.
 * Teks diambil dari tabel potongan (piece table) di aliran WordDocument; gaya paragraf
 * (judul, butir daftar, sel tabel) dibaca dari tabel PAPX. Hasilnya blok yang sama
 * seperti penampil .docx sehingga pembaca layar mendapat pengalaman yang sama.
 */
object LegacyDoc {

    private class Piece(val cpStart: Int, val cpEnd: Int, val fc: Long, val unicode: Boolean)

    private class ParaProps(
        val fcStart: Long,
        val fcEnd: Long,
        val istd: Int,
        val inTable: Boolean,
        val ttp: Boolean,
        val ilfo: Int,
        val ilvl: Int,
        val outline: Int
    )

    private val NO_PROPS = ParaProps(0, 0, 0, false, false, 0, 0, 9)
    private val CP1252: Charset = try { Charset.forName("windows-1252") } catch (e: Exception) { Charsets.ISO_8859_1 }

    private fun u16(b: ByteArray, o: Int): Int =
        if (o < 0 || o + 2 > b.size) 0 else (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long =
        if (o < 0 || o + 4 > b.size) 0 else
            (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
                ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    fun parse(f: File): OfficeReader.Doc {
        OleFile(f).use { ole ->
            val wd = ole.readStream("WordDocument") ?: throw IllegalStateException("bukan dokumen Word")
            if (u16(wd, 0) != 0xA5EC) throw IllegalStateException("bukan dokumen Word")
            val nFib = u16(wd, 2)
            if (nFib < 193) {
                throw IllegalStateException("Format Word 6/95 yang sangat lama belum didukung. Gunakan Buka dengan aplikasi lain.")
            }
            val flags = u16(wd, 0x0A)
            if (flags and 0x0100 != 0) {
                throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
            }
            val tableName = if (flags and 0x0200 != 0) "1Table" else "0Table"
            val tbl = ole.readStream(tableName) ?: throw IllegalStateException("rusak")

            val ccpText = u32(wd, 0x4C).toInt()
            val ccpFtn = u32(wd, 0x50).toInt()
            val ccpHdd = u32(wd, 0x54).toInt()
            val ccpAtn = u32(wd, 0x5C).toInt()
            val ccpEdn = u32(wd, 0x60).toInt()
            if (ccpText < 0) throw IllegalStateException("rusak")

            val fcClx = u32(wd, 0x1A2).toInt()
            val lcbClx = u32(wd, 0x1A6).toInt()
            if (fcClx < 0 || lcbClx <= 0 || fcClx + lcbClx > tbl.size) throw IllegalStateException("rusak")
            val pieces = readPieces(tbl, fcClx, lcbClx)
            if (pieces.isEmpty()) throw IllegalStateException("rusak")

            val props = readParaProps(wd, tbl)
            val text = readText(wd, pieces)

            val doc = OfficeReader.Doc()
            doc.format = "doc"
            doc.kind = "text"
            doc.typeName = "Dokumen Word format lama"

            val w = Walker(doc, text, pieces, props)
            var cp = 0
            w.story(cp, minOf(ccpText, text.length))
            cp += ccpText
            if (ccpFtn > 0) { w.storyWithTitle("Catatan kaki", cp, minOf(cp + ccpFtn, text.length)) }
            cp += ccpFtn + ccpHdd
            if (ccpAtn > 0) { w.storyWithTitle("Komentar", cp, minOf(cp + ccpAtn, text.length)) }
            cp += ccpAtn
            if (ccpEdn > 0) { w.storyWithTitle("Catatan akhir", cp, minOf(cp + ccpEdn, text.length)) }

            if (doc.blocks.isEmpty()) {
                doc.blocks.add(OfficeReader.Block(OfficeReader.K_PARA, 0, "Dokumen kosong atau tidak berisi teks."))
            }
            return doc
        }
    }

    // ------------------------------------------------------------ tabel potongan teks

    private fun readPieces(tbl: ByteArray, fc: Int, lcb: Int): List<Piece> {
        var pos = fc
        val end = fc + lcb
        while (pos < end && (tbl[pos].toInt() and 0xFF) == 1) {
            pos += 3 + u16(tbl, pos + 1)
        }
        if (pos >= end || (tbl[pos].toInt() and 0xFF) != 2) return emptyList()
        val plcLen = u32(tbl, pos + 1).toInt()
        val plc = pos + 5
        if (plcLen < 4 || plc + plcLen > tbl.size) return emptyList()
        val n = (plcLen - 4) / 12
        val out = ArrayList<Piece>(n)
        for (i in 0 until n) {
            val cs = u32(tbl, plc + i * 4).toInt()
            val ce = u32(tbl, plc + (i + 1) * 4).toInt()
            val raw = u32(tbl, plc + (n + 1) * 4 + i * 8 + 2)
            val compressed = raw and 0x40000000L != 0L
            val real = raw and 0x3FFFFFFFL
            if (ce < cs) return emptyList()
            out.add(Piece(cs, ce, if (compressed) real / 2 else real, !compressed))
        }
        return out
    }

    private fun readText(wd: ByteArray, pieces: List<Piece>): String {
        val total = pieces.last().cpEnd.coerceIn(0, 30_000_000)
        val sb = StringBuilder(total)
        for (p in pieces) {
            val len = p.cpEnd - p.cpStart
            if (len <= 0) continue
            val start = p.fc.toInt()
            val bytes = if (p.unicode) len * 2 else len
            if (start < 0 || start >= wd.size) {
                repeat(len) { sb.append(' ') }
                continue
            }
            val avail = minOf(bytes, wd.size - start)
            val s = if (p.unicode) String(wd, start, avail and 1.inv(), Charsets.UTF_16LE)
            else String(wd, start, avail, CP1252)
            sb.append(s)
            // jaga agar indeks CP tetap sejajar bila data terpotong
            val missing = len - s.length
            if (missing > 0) repeat(missing) { sb.append(' ') }
            if (sb.length > 30_000_000) break
        }
        return sb.toString()
    }

    // ------------------------------------------------------------ sifat paragraf (PAPX)

    private fun readParaProps(wd: ByteArray, tbl: ByteArray): List<ParaProps> {
        val fcPlc = u32(wd, 0x102).toInt()
        val lcb = u32(wd, 0x106).toInt()
        val out = ArrayList<ParaProps>()
        if (fcPlc < 0 || lcb < 12 || fcPlc + lcb > tbl.size) return out
        val n = (lcb - 4) / 8
        for (i in 0 until n) {
            val pn = (u32(tbl, fcPlc + (n + 1) * 4 + i * 4) and 0x3FFFFF).toInt()
            val page = pn * 512
            if (page < 0 || page + 512 > wd.size) continue
            val crun = wd[page + 511].toInt() and 0xFF
            if (crun == 0 || 4 * (crun + 1) + crun * 13 > 511) continue
            for (r in 0 until crun) {
                val fs = u32(wd, page + 4 * r)
                val fe = u32(wd, page + 4 * (r + 1))
                val bOff = wd[page + 4 * (crun + 1) + r * 13].toInt() and 0xFF
                if (bOff == 0) continue
                var p = page + bOff * 2
                if (p >= page + 511) continue
                var cb = wd[p].toInt() and 0xFF
                val len: Int
                if (cb == 0) {
                    cb = wd[p + 1].toInt() and 0xFF
                    len = cb * 2
                    p += 2
                } else {
                    len = cb * 2 - 1
                    p += 1
                }
                if (len < 2 || p + len > page + 512) continue
                out.add(parseGrpprl(wd, p, len, fs, fe))
            }
        }
        out.sortBy { it.fcStart }
        return out
    }

    private fun parseGrpprl(b: ByteArray, start: Int, len: Int, fs: Long, fe: Long): ParaProps {
        val istd = u16(b, start)
        var inTable = false
        var ttp = false
        var ilfo = 0
        var ilvl = 0
        var outline = 9
        var p = start + 2
        val end = start + len
        while (p + 2 <= end) {
            val op = u16(b, p)
            p += 2
            val spra = op shr 13
            val size = when (spra) {
                0, 1 -> 1
                2, 4, 5 -> 2
                3 -> 4
                7 -> 3
                else -> if (p < end) 1 + (b[p].toInt() and 0xFF) else 0
            }
            if (p + size > end) break
            when (op) {
                0x2416 -> inTable = b[p].toInt() != 0
                0x2417 -> ttp = b[p].toInt() != 0
                0x460B -> ilfo = u16(b, p).let { if (it >= 0x8000) it - 0x10000 else it }
                0x260A -> ilvl = b[p].toInt() and 0xFF
                0x2640 -> outline = b[p].toInt() and 0xFF
            }
            p += size
        }
        return ParaProps(fs, fe, istd, inTable, ttp, ilfo, ilvl, outline)
    }

    // ------------------------------------------------------------ penyusun blok

    private class Walker(
        val doc: OfficeReader.Doc,
        val text: String,
        val pieces: List<Piece>,
        val props: List<ParaProps>
    ) {
        private val rows = ArrayList<List<String>>()
        private val cells = ArrayList<String>()
        private val cellBuf = StringBuilder()
        private var lastPiece = 0

        fun storyWithTitle(title: String, from: Int, to: Int) {
            if (to <= from || text.substring(from, to).isBlank()) return
            add(OfficeReader.Block(OfficeReader.K_HEADING, 1, title))
            doc.headings++
            story(from, to)
        }

        private fun add(b: OfficeReader.Block) {
            if (doc.blocks.size >= OfficeReader.MAX_BLOCKS) {
                doc.truncated = true
                return
            }
            doc.blocks.add(b)
        }

        private fun fcOf(cp: Int): Long {
            var idx = lastPiece
            if (idx >= pieces.size || cp < pieces[idx].cpStart || cp >= pieces[idx].cpEnd) {
                var lo = 0
                var hi = pieces.size - 1
                idx = -1
                while (lo <= hi) {
                    val mid = (lo + hi) ushr 1
                    val p = pieces[mid]
                    if (cp < p.cpStart) hi = mid - 1
                    else if (cp >= p.cpEnd) lo = mid + 1
                    else { idx = mid; break }
                }
                if (idx < 0) return -1
                lastPiece = idx
            }
            val p = pieces[idx]
            return p.fc + (cp - p.cpStart).toLong() * (if (p.unicode) 2 else 1)
        }

        private fun propsAt(cp: Int): ParaProps {
            val fc = fcOf(cp)
            if (fc < 0) return NO_PROPS
            var lo = 0
            var hi = props.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1
                val p = props[mid]
                if (fc < p.fcStart) hi = mid - 1
                else if (fc >= p.fcEnd) lo = mid + 1
                else return p
            }
            return NO_PROPS
        }

        private fun flushTable() {
            if (cells.isNotEmpty()) {
                rows.add(ArrayList(cells))
                cells.clear()
            }
            if (rows.isNotEmpty()) {
                if (rows.any { r -> r.any { it.isNotBlank() } }) {
                    doc.tables++
                    for (b in OfficeReader.tableBlocks(rows, doc.tables)) add(b)
                }
                rows.clear()
            }
            cellBuf.setLength(0)
        }

        fun story(from: Int, to: Int) {
            val cur = StringBuilder()
            val fields = ArrayList<Boolean>()
            var pageAfter = false
            var cp = from
            while (cp < to) {
                if (doc.truncated) break
                val c = text[cp]
                val code = c.code
                when {
                    code == 0x13 -> fields.add(false)
                    code == 0x14 -> if (fields.isNotEmpty()) fields[fields.size - 1] = true
                    code == 0x15 -> if (fields.isNotEmpty()) fields.removeAt(fields.size - 1)
                    code == 0x0D || code == 0x07 -> {
                        val pp = propsAt(cp)
                        if (pp.inTable) {
                            if (code == 0x07) {
                                if (pp.ttp) {
                                    if (cells.isNotEmpty()) { rows.add(ArrayList(cells)); cells.clear() }
                                } else {
                                    cellBuf.append(cur.toString().trim())
                                    cells.add(cellBuf.toString().trim())
                                    cellBuf.setLength(0)
                                }
                            } else {
                                val t = cur.toString().trim()
                                if (t.isNotEmpty()) cellBuf.append(t).append(' ')
                            }
                            cur.setLength(0)
                        } else {
                            flushTable()
                            emitParagraph(cur.toString(), pp)
                            if (pageAfter) {
                                add(OfficeReader.Block(OfficeReader.K_PAGE, 0, "Pemisah halaman"))
                                pageAfter = false
                            }
                            cur.setLength(0)
                        }
                    }
                    code == 0x0C -> {
                        if (cur.isBlank() && rows.isEmpty()) {
                            if (doc.blocks.isNotEmpty() && doc.blocks.last().kind != OfficeReader.K_PAGE) {
                                add(OfficeReader.Block(OfficeReader.K_PAGE, 0, "Pemisah halaman"))
                            }
                        } else {
                            pageAfter = true
                        }
                    }
                    fields.all { it } -> when {
                        code == 0x01 -> { doc.images++; cur.append(" [Gambar] ") }
                        code == 0x0B -> cur.append(' ')
                        code == 0x1E -> cur.append('-')
                        code == 0xA0 -> cur.append(' ')
                        code == 0x09 -> cur.append(' ')
                        code < 0x20 -> {}
                        else -> if (cur.length < OfficeReader.MAX_BLOCK_CHARS) cur.append(c)
                    }
                }
                cp++
            }
            if (cur.isNotBlank() && !doc.truncated) emitParagraph(cur.toString(), NO_PROPS)
            flushTable()
        }

        private fun emitParagraph(raw: String, pp: ParaProps) {
            val t = raw.replace(Regex("\\s+"), " ").trim()
            if (t.isEmpty()) return
            val level = when {
                pp.istd in 1..9 -> pp.istd
                pp.outline in 0..8 -> pp.outline + 1
                else -> 0
            }
            when {
                level > 0 -> {
                    doc.headings++
                    add(OfficeReader.Block(OfficeReader.K_HEADING, level.coerceAtMost(6), t))
                }
                pp.ilfo in 1..2046 -> {
                    doc.paragraphs++
                    add(OfficeReader.Block(OfficeReader.K_LIST, pp.ilvl.coerceIn(0, 5), t))
                }
                else -> {
                    doc.paragraphs++
                    add(OfficeReader.Block(OfficeReader.K_PARA, 0, t))
                }
            }
        }
    }
}
