# Pembaca Uang

Aplikasi Android untuk membacakan nominal uang kertas rupiah lewat kamera, dibuat dengan
mekanisme dan alur yang sama seperti aplikasi acuan "Pembaca Uang Novan".

## Alur kerja

1. Aplikasi dibuka: getar singkat (60 ms), layar tetap menyala, bip dimulai.
2. Izin kamera diminta. Bila ditolak, aplikasi mengucapkan cara mengaktifkannya.
3. Kamera belakang dibuka dengan Camera v1 (`android.hardware.Camera`) dan senter (torch) menyala otomatis.
4. Tiap frame dianalisis OCR ML Kit (model Latin ikut di dalam aplikasi, jalan offline).
5. Seluruh teks digabung lalu dicocokkan ke pecahan (`CurrencyParser`):
   tulisan nominal, nama pahlawan pada uang, lalu pola angka dengan syarat jumlah angka 0 yang pas.
6. `SpeechGate` mencegah nominal yang sama diucapkan berulang selama uang masih terbaca.
7. Nominal diucapkan lewat Text-to-Speech (atau pengumuman TalkBack bila aktif).
8. Bip tiap 10 detik sebagai tanda aplikasi aktif.
9. Tombol kembali: ucapkan "Terima kasih", getar, keluar.

## Struktur

| Berkas | Fungsi |
|---|---|
| `MainActivity.kt` | Izin, siklus hidup kamera, alur deteksi → suara |
| `CameraSource.kt` | Camera v1: ukuran 1152x648, 30 fps, fokus kontinu + area tengah, senter, 4 buffer NV21 |
| `MoneyRecognizer.kt` | Frame NV21 → bitmap abu-abu → OCR ML Kit → teks |
| `CurrencyParser.kt`, `Denomination.kt` | Teks → pecahan |
| `SpeechGate.kt` | Anti-ulang 1 detik |
| `Speaker.kt` | TTS / TalkBack |
| `Beeper.kt` | Bip tiap 10 detik |

## Build

Buka folder ini di Android Studio (Koala atau lebih baru) lalu Run, atau `./gradlew assembleDebug`.
Tes parser: `./gradlew testDebugUnitTest`.
Ukuran APK dijaga kecil: hanya model OCR Latin ML Kit (`text-recognition`, tanpa model Mandarin/Jepang/Korea/Devanagari),
satu APK yang mendukung 64-bit (`arm64-v8a`) dan 32-bit (`armeabi-v7a`), bahasa `id` dan `en`, serta R8 + shrinkResources pada build rilis.
Versi 1.1 (versionCode 2).
Butuh JDK 17 dan Android SDK 34. Berjalan di Android 5.0 (API 21) sampai versi terbaru. Pecahan yang dikenali: 1.000, 2.000, 5.000, 10.000, 20.000, 50.000, 75.000, 100.000.
