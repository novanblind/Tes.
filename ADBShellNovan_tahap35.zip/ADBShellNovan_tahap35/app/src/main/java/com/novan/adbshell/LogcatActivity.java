package com.novan.adbshell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.github.muntashirakon.adb.AdbStream;

/**
 * Log aplikasi (logcat) lewat ADB, tanpa komputer.
 * Pilih aplikasi di daftar: catatan error (crash) terakhirnya otomatis dicari dan ditampilkan.
 * Pantau langsung: logcat dijalankan LEBIH DULU, baru aplikasi dibuka, jadi crash yang terjadi sangat cepat
 * saat aplikasi dibuka tetap tertangkap. Penyaringan per aplikasi dilakukan di sini (bukan --pid).
 */
public class LogcatActivity extends Activity {
    private static final Pattern BARIS_RUNTIME = Pattern.compile(
            "^(?:(\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+)\\s+)?[A-Z]/AndroidRuntime\\(\\s*(\\d+)\\):\\s?(.*)$");
    private static final Pattern ENTRI_DROPBOX = Pattern.compile(
            "(?m)^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}) (\\S+) \\((?:text|data|empty)[^\\n]*$");
    /** Format logcat -v threadtime: "MM-DD HH:MM:SS.mmm  PID  TID L TAG: pesan". */
    private static final Pattern BARIS_LOG = Pattern.compile(
            "^\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\d+)\\s+\\d+\\s+([VDIWEFA])\\s+(.+?)\\s*:\\s?(.*)$");

    static class Item {
        String pkg, label, tampil;
        String text() { return tampil != null ? tampil : (label.equals(pkg) ? pkg : label + " (" + pkg + ")"); }
    }

    /** Satu sesi pemantauan. */
    private static class Sesi {
        volatile boolean aktif = true;
        volatile AdbStream stream;
        volatile AdbStream stream2; // penjaga: buffer crash saja (volumenya kecil, tidak ikut kehilangan baris)
        final Set<String> pids = Collections.synchronizedSet(new HashSet<String>());
    }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private boolean pengguna = true; // awal: hanya aplikasi yang Anda pasang (paling relevan untuk debug)
    private Button btnPantau;
    private EditText etCari;
    private TextView tvStatus, tvOut;
    private ScrollView scrollOut;
    private LinearLayout panelDaftar, panelLog;
    private ListView list;
    private KompakAdapter adapter;
    private Item dipilih;
    private boolean modeLangsung; // ketuk aplikasi = langsung buka dan pantau
    private volatile int tingkat = 0; // 0 semua, 1 Warning ke atas, 2 Error saja
    private static final String[] NAMA_TINGKAT = {"Semua baris", "Peringatan (W) ke atas", "Error (E) saja"};
    private static final int[] MIN_PERINGKAT = {0, 3, 4};
    private static final int BATAS_TEKS = 60000;
    private volatile Sesi sesiAktif;
    private volatile boolean tambahkanKeLog;
    /** Catatan error lain (lebih lama / DropBox) dari pencarian terakhir, ikut disalin. */
    private volatile String tambahanLaporan = "";
    private final AtomicBoolean crashTerjadwal = new AtomicBoolean(false);
    /** Jam HP ("MM-dd HH:mm:ss") saat pemantauan dimulai; dipakai membedakan error baru dan error lama. */
    private volatile String mulaiStamp;
    /** True bila layar log berisi log langsung: hasil cari error ditambahkan di bawahnya, tidak menimpa. */
    private volatile boolean adaLogLangsung;
    private final StringBuilder antre = new StringBuilder();
    private final AtomicBoolean flushTerjadwal = new AtomicBoolean(false);

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private static LinearLayout.LayoutParams lp(int w, int h, float bobot) {
        return new LinearLayout.LayoutParams(w, h, bobot);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Log aplikasi (logcat)");
        modeLangsung = getIntent().getBooleanExtra("langsung", false);
        int pad = dp(8);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        // ---------- Layar 1: daftar aplikasi (memenuhi layar, barisnya rapat) ----------
        panelDaftar = new LinearLayout(this);
        panelDaftar.setOrientation(LinearLayout.VERTICAL);

        LinearLayout barisCari = new LinearLayout(this);
        etCari = new EditText(this);
        etCari.setHint("Cari nama atau paket aplikasi");
        etCari.setContentDescription("Cari nama atau paket aplikasi");
        etCari.setInputType(InputType.TYPE_CLASS_TEXT);
        etCari.setSingleLine(true);
        etCari.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void afterTextChanged(Editable e) { saring(); }
        });
        Button btnPengaturan = new Button(this);
        btnPengaturan.setText("Pengaturan");
        btnPengaturan.setOnClickListener(v -> dialogPengaturan());
        barisCari.addView(etCari, lp(0, -2, 1f));
        barisCari.addView(btnPengaturan, lp(-2, -2, 0f));
        panelDaftar.addView(barisCari);

        adapter = new KompakAdapter(this);
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < shown.size()) pilihAplikasi(shown.get(pos));
        });
        // Tekan lama: selalu langsung buka dan pantau, apa pun modenya.
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < shown.size()) { langsungPantau(shown.get(pos)); return true; }
            return false;
        });
        panelDaftar.addView(list, lp(-1, 0, 1f));
        root.addView(panelDaftar, lp(-1, 0, 1f));

        // ---------- Layar 2: hasil log (muncul setelah memilih aplikasi) ----------
        panelLog = new LinearLayout(this);
        panelLog.setOrientation(LinearLayout.VERTICAL);
        panelLog.setVisibility(View.GONE);

        Button btnKembali = new Button(this);
        btnKembali.setText("Kembali ke daftar aplikasi");
        btnKembali.setOnClickListener(v -> kembaliKeDaftar());
        btnPantau = new Button(this);
        btnPantau.setText("Pantau log langsung");
        btnPantau.setOnClickListener(v -> {
            if (dipilih == null) { status("Pilih aplikasi dulu di daftar."); return; }
            if (sesiAktif != null) {
                // Berhenti memantau: log langsung dipertahankan, catatan error terakhir dicari dan ditambahkan di bawahnya.
                tambahkanKeLog = true;
                hentikanPantau();
                final Item target = dipilih;
                // Beri jeda: stream logcat yang baru ditutup bisa mengganggu perintah berikutnya (hasil kosong).
                tvOut.postDelayed(() -> cariCrash(target), 700);
            } else mulaiPantau(dipilih, true);
        });
        Button btnMuatUlang = new Button(this);
        btnMuatUlang.setText("Cari ulang error");
        btnMuatUlang.setOnClickListener(v -> {
            if (dipilih != null) cariCrash(dipilih); else status("Pilih aplikasi dulu di daftar.");
        });
        Button btnSalin = new Button(this);
        btnSalin.setText("Salin semua keterangan");
        btnSalin.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", laporanSalin(dipilih, tvOut.getText().toString())));
            Toast.makeText(this, "Tersalin lengkap dengan tanggal dan jam", Toast.LENGTH_SHORT).show();
            status("Tersalin: semua catatan error dan tanggal jam HP sekarang.");
        });
        Button btnBersihkan = new Button(this);
        btnBersihkan.setText("Bersihkan");
        btnBersihkan.setOnClickListener(v -> { tvOut.setText(""); adaLogLangsung = false; });
        LinearLayout baris1 = new LinearLayout(this);
        // Tombol Pantau/Hentikan di urutan pertama supaya cepat ditemukan pembaca layar.
        baris1.addView(btnPantau, lp(0, -2, 1f));
        baris1.addView(btnKembali, lp(0, -2, 1f));
        LinearLayout baris2 = new LinearLayout(this);
        baris2.addView(btnMuatUlang, lp(0, -2, 1f));
        baris2.addView(btnSalin, lp(0, -2, 1f));
        baris2.addView(btnBersihkan, lp(0, -2, 1f));
        panelLog.addView(baris1);
        panelLog.addView(baris2);

        tvOut = new TextView(this);
        tvOut.setTextIsSelectable(true);
        tvOut.setContentDescription("Keterangan log");
        scrollOut = new ScrollView(this);
        scrollOut.addView(tvOut);
        panelLog.addView(scrollOut, lp(-1, 0, 1f));
        root.addView(panelLog, lp(-1, 0, 1f));

        tvStatus = new TextView(this);
        tvStatus.setPadding(0, pad / 2, 0, 0);
        root.addView(tvStatus, lp(-1, -2, 0f));

        setContentView(root);
        PairHelper.sink = s -> status(s);
        muatDaftarAplikasi();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        hentikanPantau();
    }

    @Override public void onBackPressed() {
        if (panelLog.getVisibility() == View.VISIBLE) kembaliKeDaftar();
        else super.onBackPressed();
    }

    private void kembaliKeDaftar() {
        hentikanPantau();
        tampilLog(false);
        status("Kembali ke daftar: " + shown.size() + " aplikasi.");
    }

    private void tampilLog(boolean ya) {
        panelLog.setVisibility(ya ? View.VISIBLE : View.GONE);
        panelDaftar.setVisibility(ya ? View.GONE : View.VISIBLE);
    }

    private void status(final String s) {
        runOnUiThread(() -> {
            tvStatus.setText(s);
            tvStatus.announceForAccessibility(s);
        });
    }

    private void append(final String s) {
        tvOut.append(s);
        CharSequence cur = tvOut.getText();
        if (cur.length() > BATAS_TEKS) { // jaga agar layar tidak berat
            tvOut.setText(cur.subSequence(cur.length() - BATAS_TEKS / 2, cur.length()));
        }
        // Gulir ke bawah TANPA memindahkan fokus (fullScroll(FOCUS_DOWN) mencuri fokus pembaca layar ke log).
        scrollOut.post(() -> {
            View isi = scrollOut.getChildAt(0);
            if (isi != null) scrollOut.scrollTo(0, Math.max(0, isi.getHeight() - scrollOut.getHeight()));
        });
    }

    /**
     * Saat memantau, log tidak dibacakan dan tidak bisa difokus: baris baru yang muncul terus tidak lagi
     * menarik fokus pembaca layar dari tombol. Setelah berhenti, log bisa dibaca dan disalin seperti biasa.
     */
    private void aturModeLog(final boolean memantau) {
        runOnUiThread(() -> {
            tvOut.setTextIsSelectable(!memantau);
            tvOut.setFocusable(!memantau);
            tvOut.setFocusableInTouchMode(!memantau);
            tvOut.setImportantForAccessibility(memantau
                    ? View.IMPORTANT_FOR_ACCESSIBILITY_NO : View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            if (memantau) {
                btnPantau.setContentDescription("Hentikan pemantauan. Selama memantau, log tidak dibacakan; "
                        + "setelah berhenti log bisa dibaca dan disalin.");
                btnPantau.requestFocus();
                btnPantau.sendAccessibilityEvent(android.view.accessibility.AccessibilityEvent.TYPE_VIEW_FOCUSED);
            } else {
                btnPantau.setContentDescription(null);
            }
        });
    }

    /** Kumpulkan baris log dari thread latar, lalu tampilkan sekaligus tiap 150 ms agar layar tidak berat. */
    private void kirim(String s) {
        synchronized (antre) { antre.append(s); }
        if (flushTerjadwal.compareAndSet(false, true)) {
            tvOut.postDelayed(() -> {
                flushTerjadwal.set(false);
                String t;
                synchronized (antre) { t = antre.toString(); antre.setLength(0); }
                if (!t.isEmpty()) append(t);
            }, 150);
        }
    }

    private void dialogPengaturan() {
        final String[] pil = {
                "Mode ketuk: " + (modeLangsung ? "LANGSUNG PANTAU" : "CARI ERROR") + " (ketuk untuk ganti)",
                "Saring log: " + NAMA_TINGKAT[tingkat] + " (ketuk untuk ganti)",
                "Cakupan: " + (pengguna ? "aplikasi yang Anda pasang" : "semua aplikasi") + " (ketuk untuk ganti)"};
        new AlertDialog.Builder(this)
                .setTitle("Pengaturan")
                .setItems(pil, (d, w) -> {
                    if (w == 0) {
                        modeLangsung = !modeLangsung;
                        status(modeLangsung ? "Mode ketuk: langsung pantau. Ketuk aplikasi = dibuka dan lognya dipantau."
                                : "Mode ketuk: cari error. Ketuk aplikasi = catatan error terakhirnya dicari. Tekan lama = langsung pantau.");
                    } else if (w == 1) {
                        tingkat = (tingkat + 1) % NAMA_TINGKAT.length;
                        status("Saring log: " + NAMA_TINGKAT[tingkat] + ". Berlaku langsung, juga saat sedang memantau.");
                    } else {
                        pengguna = !pengguna;
                        muatDaftarAplikasi();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    // ---------- Daftar aplikasi (lokal, tidak perlu ADB) ----------

    private void muatDaftarAplikasi() {
        status("Memuat daftar aplikasi...");
        io.execute(() -> {
            PackageManager pm = getPackageManager();
            List<Item> hasil = new ArrayList<>();
            try {
                for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                    boolean sistem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    if (pengguna && sistem) continue;
                    Item it = new Item();
                    it.pkg = ai.packageName;
                    CharSequence l = pm.getApplicationLabel(ai);
                    it.label = (l != null && l.length() > 0) ? l.toString() : ai.packageName;
                    hasil.add(it);
                }
            } catch (Throwable e) { status("Gagal memuat daftar aplikasi: " + e); return; }
            Collections.sort(hasil, (x, y) -> x.label.toLowerCase(Locale.ROOT).compareTo(y.label.toLowerCase(Locale.ROOT)));
            // Satu baris = satu nama saja (rapat). Paket ditambahkan hanya bila ada nama yang sama.
            Map<String, Integer> hitung = new HashMap<>();
            for (Item it : hasil) {
                String k = it.label.toLowerCase(Locale.ROOT);
                Integer c = hitung.get(k);
                hitung.put(k, c == null ? 1 : c + 1);
            }
            for (Item it : hasil) {
                Integer c = hitung.get(it.label.toLowerCase(Locale.ROOT));
                it.tampil = (c != null && c > 1 && !it.label.equals(it.pkg)) ? it.label + " (" + it.pkg + ")" : it.label;
            }
            runOnUiThread(() -> {
                all.clear();
                all.addAll(hasil);
                saring();
                status("Daftar: " + shown.size() + (pengguna ? " aplikasi yang Anda pasang." : " aplikasi (semua).")
                        + (modeLangsung ? " Ketuk = buka dan pantau log." : " Ketuk = lihat catatan error, tekan lama = pantau log langsung."));
            });
        });
    }

    private void saring() {
        String q = etCari.getText().toString().trim().toLowerCase(Locale.ROOT);
        shown.clear();
        adapter.setNotifyOnChange(false);
        adapter.clear();
        for (Item it : all) {
            if (!q.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(q)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(it);
            adapter.add(it.text());
        }
        adapter.notifyDataSetChanged();
    }

    private void pilihAplikasi(Item it) {
        if (modeLangsung) { langsungPantau(it); return; }
        hentikanPantau();
        dipilih = it;
        tambahanLaporan = "";
        adaLogLangsung = false;
        mulaiStamp = null;
        tvOut.setText("");
        tampilLog(true);
        cariCrash(it);
    }

    /** Satu ketukan: hentikan pantauan lama, lalu pantau (aplikasi dibuka bila belum jalan). */
    private void langsungPantau(Item it) {
        hentikanPantau();
        dipilih = it;
        tambahanLaporan = "";
        adaLogLangsung = false;
        tvOut.setText("");
        tampilLog(true);
        final Item target = it;
        tvOut.postDelayed(() -> mulaiPantau(target, true), 300);
    }

    // ---------- Catatan error (crash) otomatis ----------

    private Adb siapAdb() throws Exception {
        Adb a = Adb.get(this);
        if (!a.isConnected()) {
            status("Menyambung...");
            PairHelper.connect(this, true);
        }
        if (!a.isConnected()) {
            status("Belum tersambung. Sambungkan dulu di layar utama, lalu ketuk Cari ulang error.");
            return null;
        }
        return a;
    }

    /** Cari catatan error terbaru: crash (logcat), lalu crash/ANR/native dari DropBox sistem. Hasil selalu di dialog. */
    private void cariCrash(final Item it) {
        status("Mencari catatan error untuk " + it.label + "...");
        tambahanLaporan = "";
        io.execute(() -> {
            try {
                Adb a = siapAdb();
                if (a == null) {
                    final String m = "Belum tersambung ke ADB. Sambungkan dulu di layar utama, lalu coba lagi.";
                    runOnUiThread(() -> tampilHasil(it, m));
                    return;
                }
                // Keluaran kosong/gagal dianggap gagal baca (stream ADB kadang tertutup dini) dan diulang.
                String dump = bacaDump(a, "shell:logcat -b crash -d -v time", 3);
                final boolean gagalBaca = (dump == null);
                List<String> blok = cariBlokCrash(dump, it.pkg);
                String teksCrash = blok.isEmpty() ? null : blok.get(blok.size() - 1);
                String waktuCrash = null;
                if (teksCrash != null) {
                    Matcher mw = Pattern.compile("Waktu: (\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d)").matcher(teksCrash);
                    if (mw.find()) waktuCrash = mw.group(1);
                }
                String db = cariDropbox(a, it.pkg); // crash/ANR/native dari DropBox, dibandingkan dengan log crash
                String waktuDb = null;
                if (db != null) {
                    Matcher md = Pattern.compile("Waktu: \\d{4}-(\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d)").matcher(db);
                    if (md.find()) waktuDb = md.group(1);
                }
                StringBuilder lain = new StringBuilder();
                String teks, waktu;
                if (teksCrash != null && (db == null || waktuDb == null || waktuCrash == null
                        || waktuCrash.compareTo(waktuDb) >= 0)) {
                    teks = "Jenis: crash aplikasi (Java), sumber: log crash\n"
                            + (blok.size() > 1 ? "Ditemukan " + blok.size() + " catatan; ini yang terbaru.\n" : "")
                            + "\n" + teksCrash;
                    waktu = waktuCrash;
                    for (int i = blok.size() - 2; i >= 0; i--)
                        lain.append("--- catatan crash lain (lebih lama) ---\n").append(blok.get(i)).append("\n\n");
                    if (db != null) lain.append("--- catatan DropBox sistem ---\n").append(db).append("\n\n");
                } else if (db != null) {
                    teks = db;
                    waktu = waktuDb;
                    for (int i = blok.size() - 1; i >= 0; i--)
                        lain.append("--- catatan crash Java (log crash) ---\n").append(blok.get(i)).append("\n\n");
                } else {
                    waktu = null;
                    teks = gagalBaca
                            ? "GAGAL membaca log crash dari HP (koneksi ADB tidak stabil). Ini BUKAN berarti tidak ada error. "
                            + "Ketuk \"Cari ulang error\" sekali lagi."
                            : "Belum ditemukan catatan error (crash, ANR, atau crash native) untuk " + it.label + ".\n\n"
                            + "Catatan lama bisa sudah terhapus (log dibersihkan saat HP restart dan ukurannya terbatas). "
                            + "Ulangi hal yang membuat aplikasi bermasalah, lalu pilih aplikasinya lagi. "
                            + "Atau ketuk \"Pantau log langsung\" sebelum membuka aplikasi.";
                }
                if (waktu != null) teks = umurCatatan(a, waktu) + "\n\n" + teks;
                String st = mulaiStamp;
                if (waktu != null && st != null && waktu.compareTo(st) < 0)
                    teks = "CATATAN: error ini terjadi SEBELUM pemantauan dimulai (" + st
                            + "). Tidak ada crash baru selama pemantauan ini.\n\n" + teks;
                String tl = lain.toString().trim();
                if (tl.length() > 80000) tl = tl.substring(0, 80000) + "\n...(dipotong)";
                tambahanLaporan = tl;
                final String hasil = teks;
                runOnUiThread(() -> tampilHasil(it, hasil));
                status("Pencarian catatan error untuk " + it.label + " selesai.");
            } catch (Throwable e) {
                final String m = "Gagal mencari catatan error: " + e;
                runOnUiThread(() -> tampilHasil(it, m));
                status(m);
            }
        });
    }

    /** Teks yang disalin: judul, aplikasi, tanggal+jam HP saat disalin, isi yang tampil, lalu semua catatan error lainnya. */
    private String laporanSalin(Item it, String isi) {
        String jam = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder("=== LAPORAN ERROR ===\n");
        sb.append("Aplikasi: ").append(it != null ? it.label + " (" + it.pkg + ")" : "-").append('\n');
        sb.append("Tanggal dan jam HP saat disalin: ").append(jam).append("\n\n");
        sb.append(isi);
        String tl = tambahanLaporan;
        if (tl != null && !tl.isEmpty()) sb.append("\n\n=== SEMUA CATATAN ERROR LAINNYA ===\n").append(tl);
        return sb.toString();
    }

    /** Tanggal dan jam HP sekarang, "yyyy-MM-dd HH:mm:ss", atau null bila gagal dibaca. */
    private static String jamHp(Adb a) {
        try {
            String now = Shell.run(a, "shell:date '+%Y-%m-%d %H:%M:%S'", null);
            if (now == null) return null;
            now = now.trim();
            return now.matches("\\d{4}-\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d") ? now : null;
        } catch (Throwable e) {
            return null;
        }
    }

    /** Keterangan waktu: tanggal+jam HP sekarang, waktu kejadian, dan selisihnya, supaya catatan lama tidak disangka baru. */
    private static String umurCatatan(Adb a, String waktu) {
        try {
            String now = jamHp(a);
            if (now == null) return "";
            SimpleDateFormat f = new SimpleDateFormat("yyyy MM-dd HH:mm:ss", Locale.US);
            String th = now.substring(0, 4);
            long t1 = f.parse(th + " " + now.substring(5)).getTime();
            long t0 = f.parse(th + " " + waktu).getTime();
            long menit = Math.max(0, (t1 - t0) / 60000);
            String umur = menit < 1 ? "kurang dari 1 menit" : (menit < 120 ? menit + " menit" : (menit / 60) + " jam");
            String s = "Tanggal dan jam HP sekarang: " + now + "\n"
                    + "Waktu kejadian error: " + th + "-" + waktu + "\n"
                    + "Selisih: sekitar " + umur + " yang lalu.";
            if (menit > 10) {
                s += "\nPERHATIAN: ini catatan LAMA. Tidak ada crash atau ANR yang lebih baru dari ini. "
                        + "Kalau aplikasinya masih bermasalah sekarang, penyebabnya bukan crash yang tercatat; "
                        + "pakai Pantau log langsung lalu salin hasilnya.";
            } else {
                s += "\nIni catatan BARU.";
            }
            return s;
        } catch (Throwable e) {
            return "";
        }
    }

    /** Saat sedang memantau, log langsung tidak dihapus: catatan error ditambahkan di bawahnya. Thread UI. */
    private void tampilHasil(Item it, String isi) {
        if (isFinishing()) return;
        tampilLog(true);
        if (sesiAktif != null || tambahkanKeLog || adaLogLangsung) {
            tambahkanKeLog = false;
            append("\n\n===== CATATAN ERROR =====\n" + isi + "\n===== akhir catatan error =====\n");
        } else tvOut.setText(isi);
        dialogError(it, isi);
    }

    /** Tampilkan hasil pencarian error di dialog (bisa dibaca pembaca layar, bisa disalin). Panggil dari thread UI. */
    private void dialogError(final Item it, final String isi) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle("Catatan error: " + it.label)
                .setMessage(isi)
                .setPositiveButton("Salin semua", (x, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    // Bila ada log langsung di layar, salin SEMUANYA (log langsung + catatan error), bukan hanya isi dialog.
                    String isiSalin = adaLogLangsung ? tvOut.getText().toString() : isi;
                    cm.setPrimaryClip(ClipData.newPlainText("log", laporanSalin(it, isiSalin)));
                    Toast.makeText(this, "Tersalin lengkap dengan tanggal dan jam", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    /** DropBox sistem menyimpan crash/ANR/native lebih lama daripada logcat. Kembalikan yang terbaru, atau null. */
    private static String cariDropbox(Adb a, String pkg) {
        String[][] jenis = {
                {"data_app_crash", "crash aplikasi (Java)"},
                {"data_app_anr", "ANR (aplikasi tidak merespons)"},
                {"data_app_native_crash", "crash native"}};
        String terbaikWaktu = null, terbaikTeks = null, terbaikJenis = null;
        Pattern proses = Pattern.compile("Process: " + Pattern.quote(pkg) + "(?=[,:\\s]|$)");
        for (String[] j : jenis) {
            String out;
            try { out = Shell.run(a, "shell:dumpsys dropbox --print " + j[0], null); }
            catch (Throwable e) { continue; }
            if (out == null) continue;
            Matcher m = ENTRI_DROPBOX.matcher(out);
            List<int[]> posisi = new ArrayList<>();
            List<String> waktu = new ArrayList<>();
            while (m.find()) { posisi.add(new int[]{m.start(), m.end()}); waktu.add(m.group(1)); }
            for (int i = 0; i < posisi.size(); i++) {
                int mulai = posisi.get(i)[1];
                int akhir = i + 1 < posisi.size() ? posisi.get(i + 1)[0] : out.length();
                String e = out.substring(mulai, akhir).trim();
                if (!proses.matcher(e).find()) continue;
                if (terbaikWaktu == null || waktu.get(i).compareTo(terbaikWaktu) >= 0) {
                    terbaikWaktu = waktu.get(i);
                    terbaikTeks = e;
                    terbaikJenis = j[1];
                }
            }
        }
        if (terbaikTeks == null) return null;
        if (terbaikTeks.length() > 20000) terbaikTeks = terbaikTeks.substring(0, 20000) + "\n...(dipotong)";
        return "Jenis: " + terbaikJenis + ", sumber: DropBox sistem\nWaktu: " + terbaikWaktu + "\n\n" + terbaikTeks;
    }

    /** Kumpulkan baris-baris E/AndroidRuntime yang berurutan (satu PID) jadi satu blok crash. */
    private static List<String> cariBlokCrash(String dump, String pkg) {
        List<String> hasil = new ArrayList<>();
        if (dump == null) return hasil;
        StringBuilder blok = new StringBuilder();
        String pidSedang = null;
        for (String line : dump.split("\\r?\\n")) {
            Matcher m = BARIS_RUNTIME.matcher(line);
            if (m.matches()) {
                String pid = m.group(2);
                if (pidSedang != null && !pidSedang.equals(pid)) {
                    tutupBlok(hasil, blok, pkg);
                    blok = new StringBuilder();
                }
                if (blok.length() == 0 && m.group(1) != null)
                    blok.append("Waktu: ").append(m.group(1)).append("\n");
                pidSedang = pid;
                blok.append(m.group(3)).append("\n");
            } else if (blok.length() > 0) {
                tutupBlok(hasil, blok, pkg);
                blok = new StringBuilder();
                pidSedang = null;
            }
        }
        if (blok.length() > 0) tutupBlok(hasil, blok, pkg);
        return hasil;
    }

    private static void tutupBlok(List<String> hasil, StringBuilder blok, String pkg) {
        String teks = blok.toString().trim();
        if (Pattern.compile("Process: " + Pattern.quote(pkg) + "(?=[,:\\s]|$)").matcher(teks).find())
            hasil.add(teks);
    }

    // ---------- Pemantauan log langsung ----------

    /**
     * Urutan sengaja begini: (1) logcat semua aplikasi dijalankan lebih dulu, (2) baru aplikasi dibuka,
     * (3) baris log disaring di sini menurut PID aplikasi (PID dipelajari dari baris "Start proc").
     * Dengan cara ini crash yang terjadi sedetik setelah dibuka (sebelum PID sempat dicari) tetap tertangkap.
     */
    private void mulaiPantau(final Item it, final boolean bukaBila) {
        if (sesiAktif != null) return;
        final Sesi ss = new Sesi();
        sesiAktif = ss;
        runOnUiThread(() -> btnPantau.setText("Hentikan pemantauan"));
        aturModeLog(true);
        io.execute(() -> {
            try {
                Adb a = siapAdb();
                if (a == null) { selesaiSesi(ss, null); return; }
                final String mulai = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)
                        .format(new Date(System.currentTimeMillis() - 1000));
                mulaiStamp = mulai;
                status("Menyiapkan pemantauan " + it.label + "...");
                String pid0 = null;
                try { pid0 = cariPid(a, it.pkg); } catch (Throwable ignored) {}
                if (pid0 != null) ss.pids.add(pid0);
                if (!ss.aktif) return;
                final AdbStream s = a.openStream("shell:logcat -b main,system -v threadtime -T 1");
                ss.stream = s;
                if (!ss.aktif) { selesaiSesi(ss, null); return; }
                final String jam = jamHp(a);
                final String header = "=== Mulai memantau " + it.label + (jam != null ? " pada " + jam + " (jam HP)" : "") + " ===\n";
                runOnUiThread(() -> { tvOut.setText(""); });
                adaLogLangsung = true;
                kirim(header);
                Thread r = new Thread(() -> bacaLog(it, ss, s), "logcat-baca");
                r.setDaemon(true);
                r.start();
                // Penjaga: stream kedua khusus buffer crash. Log utama (semua aplikasi) bisa kehilangan baris
                // saat banjir lewat ADB nirkabel; buffer crash kecil sehingga crash selalu terdeteksi.
                try {
                    final AdbStream g = a.openStream("shell:logcat -b crash -v threadtime -T 1");
                    ss.stream2 = g;
                    if (!ss.aktif) {
                        try { g.close(); } catch (Throwable ignored) {}
                    } else {
                        Thread r2 = new Thread(() -> bacaCrash(it, ss, g, mulai), "logcat-penjaga");
                        r2.setDaemon(true);
                        r2.start();
                    }
                } catch (Throwable e) {
                    status("Penjaga crash tidak aktif: " + e + ". Pemantauan utama tetap berjalan.");
                }

                if (pid0 != null) {
                    status("Memantau log " + it.label + " (PID " + pid0 + "), saring: " + NAMA_TINGKAT[tingkat]
                            + ". Pakai aplikasinya sekarang.");
                } else if (bukaBila) {
                    status("Membuka " + it.label + "...");
                    String hm = null;
                    try { hm = Shell.run(a, "shell:monkey -p " + it.pkg + " -c android.intent.category.LAUNCHER 1", null); }
                    catch (Throwable ignored) {}
                    if (hm != null && hm.contains("No activities found")) {
                        status(it.label + " tidak punya layar utama. Buka manual; pemantauan tetap berjalan.");
                    } else {
                        for (int i = 0; i < 16 && ss.pids.isEmpty() && ss.aktif; i++) {
                            try { Thread.sleep(500); } catch (InterruptedException ie) { return; }
                        }
                        if (ss.aktif) {
                            status(ss.pids.isEmpty()
                                    ? "Proses " + it.label + " belum terlihat. Pemantauan tetap berjalan; buka aplikasinya bila perlu."
                                    : "Memantau log " + it.label + ", saring: " + NAMA_TINGKAT[tingkat]
                                    + ". Bila crash, catatan error muncul otomatis.");
                        }
                    }
                } else {
                    status("Menunggu " + it.label + " dijalankan. Buka aplikasinya; lognya muncul di sini.");
                }
            } catch (Throwable e) {
                selesaiSesi(ss, "Gagal memantau: " + e);
            }
        });
    }

    private void bacaLog(final Item it, final Sesi ss, final AdbStream s) {
        String pesan = null;
        try {
            final Pattern startProc = Pattern.compile("Start proc (\\d+):" + Pattern.quote(it.pkg) + "(?::\\S+)?/");
            final Pattern procPid = Pattern.compile("Process: " + Pattern.quote(it.pkg) + "(?::\\S+)?, PID: (\\d+)");
            BufferedReader br = new BufferedReader(new InputStreamReader(s.openInputStream(), StandardCharsets.UTF_8), 8192);
            String line;
            while (ss.aktif && (line = br.readLine()) != null) {
                Matcher m = BARIS_LOG.matcher(line);
                if (!m.matches()) {
                    if (line.contains(it.pkg)) kirim(line + "\n");
                    continue;
                }
                String pid = m.group(1), lvl = m.group(2), tag = m.group(3), msg = m.group(4);
                boolean cocok = false, tandaProses = false;
                Matcher sp = startProc.matcher(msg);
                if (sp.find()) {
                    ss.pids.add(sp.group(1));
                    cocok = true;
                } else {
                    Matcher pp = procPid.matcher(msg);
                    if (pp.find()) { ss.pids.add(pp.group(1)); cocok = true; tandaProses = true; }
                }
                if (!cocok) cocok = ss.pids.contains(pid) || msg.contains(it.pkg);
                if (!cocok) continue;
                boolean crash = (tag.equals("AndroidRuntime") && (msg.startsWith("FATAL EXCEPTION") || tandaProses))
                        || msg.startsWith("Fatal signal") || msg.contains("ANR in " + it.pkg);
                if (!crash && peringkat(lvl) < MIN_PERINGKAT[tingkat]) continue;
                kirim(line + "\n");
                if (crash) jadwalkanCari(it);
            }
            if (ss.aktif) pesan = "Pemantauan berhenti: sambungan ADB terputus.";
        } catch (IOException e) {
            if (ss.aktif) pesan = "Pemantauan berhenti: sambungan ADB terputus.";
        } catch (Throwable e) {
            pesan = "Gagal memantau: " + e;
        } finally {
            selesaiSesi(ss, pesan);
        }
    }

    /** Penjaga crash: hanya membaca buffer crash; crash baru (setelah pemantauan mulai) memicu pencarian lengkap. */
    private void bacaCrash(final Item it, final Sesi ss, final AdbStream s, final String mulai) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(s.openInputStream(), StandardCharsets.UTF_8), 4096);
            final Pattern proses = Pattern.compile("Process: " + Pattern.quote(it.pkg) + "(?=[,:\\s]|$)");
            String line;
            while (ss.aktif && (line = br.readLine()) != null) {
                Matcher m = BARIS_LOG.matcher(line);
                if (!m.matches()) continue;
                String stamp = line.substring(0, 14); // "MM-dd HH:mm:ss"
                if (stamp.compareTo(mulai) < 0) continue; // baris lama dari -T 1
                String pid = m.group(1), tag = m.group(3), msg = m.group(4);
                boolean crash = proses.matcher(msg).find()
                        || (msg.startsWith("Fatal signal") && msg.contains(it.pkg))
                        || (tag.equals("AndroidRuntime") && msg.startsWith("FATAL EXCEPTION") && ss.pids.contains(pid));
                if (crash && jadwalkanCari(it)) kirim("[penjaga] crash terdeteksi " + stamp + "\n");
            }
        } catch (Throwable e) {
            if (ss.aktif) status("Penjaga crash berhenti; pemantauan utama tetap berjalan.");
        }
    }

    /** Baca keluaran perintah ADB. Kosong atau gagal dianggap gagal baca dan diulang; null bila tetap gagal. */
    private String bacaDump(Adb a, String dest, int maxCoba) {
        for (int i = 0; i < maxCoba; i++) {
            try {
                String out = Shell.run(a, dest, null);
                if (out != null && out.trim().length() > 0) return out;
            } catch (Throwable ignored) {}
            try { Thread.sleep(600); } catch (InterruptedException ie) { return null; }
            if (!a.isConnected()) {
                try { PairHelper.connect(this, true); } catch (Throwable ignored) {}
            }
        }
        return null;
    }

    private static int peringkat(String l) {
        switch (l.charAt(0)) {
            case 'V': return 0;
            case 'D': return 1;
            case 'I': return 2;
            case 'W': return 3;
            case 'E': return 4;
            default: return 5;
        }
    }

    /** Crash terdeteksi: tunggu sebentar (log crash/DropBox perlu waktu ditulis), lalu tampilkan catatan lengkap. */
    private boolean jadwalkanCari(final Item it) {
        if (!crashTerjadwal.compareAndSet(false, true)) return false;
        status("Crash terdeteksi pada " + it.label + ". Mengambil catatan error lengkap...");
        tvOut.postDelayed(() -> {
            crashTerjadwal.set(false);
            if (!isFinishing()) cariCrash(it);
        }, 2500);
        return true;
    }

    private void selesaiSesi(final Sesi ss, String pesan) {
        ss.aktif = false;
        final AdbStream s = ss.stream, s2 = ss.stream2;
        if (s != null || s2 != null) {
            // Tutup di thread terpisah: menutup stream ADB tidak boleh di thread UI.
            Thread t = new Thread(() -> {
                try { if (s != null) s.close(); } catch (Throwable ignored) {}
                try { if (s2 != null) s2.close(); } catch (Throwable ignored) {}
            });
            t.setDaemon(true);
            t.start();
        }
        if (sesiAktif == ss) {
            sesiAktif = null;
            runOnUiThread(() -> btnPantau.setText("Pantau log langsung"));
            aturModeLog(false);
            if (pesan != null) status(pesan);
        }
    }

    private void hentikanPantau() {
        Sesi ss = sesiAktif;
        if (ss != null) selesaiSesi(ss, null);
    }

    private static String cariPid(Adb a, String pkg) throws Exception {
        String out = Shell.run(a, "shell:pidof " + pkg, null);
        if (out != null) {
            String t = out.trim();
            if (t.matches("\\d+(\\s+\\d+)*")) return t.split("\\s+")[0];
        }
        String ps = Shell.run(a, "shell:ps -A -o PID,NAME", null);
        if (ps != null) {
            for (String line : ps.split("\\r?\\n")) {
                String[] bagian = line.trim().split("\\s+");
                if (bagian.length >= 2 && bagian[0].matches("\\d+") && bagian[bagian.length - 1].equals(pkg))
                    return bagian[0];
            }
        }
        return null;
    }
}
