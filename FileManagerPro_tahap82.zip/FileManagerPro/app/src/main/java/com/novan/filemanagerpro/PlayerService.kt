package com.novan.filemanagerpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.File

/**
 * Pemutar musik latar belakang: tetap berbunyi saat layar mati atau aplikasi ditutup,
 * dengan notifikasi berisi tombol kontrol, sesi media (tombol headset), acak, ulang,
 * dan kecepatan putar.
 */
class PlayerService : Service() {

    companion object {
        const val ACT_TOGGLE = "com.novan.filemanagerpro.PLAYER_TOGGLE"
        const val ACT_NEXT = "com.novan.filemanagerpro.PLAYER_NEXT"
        const val ACT_PREV = "com.novan.filemanagerpro.PLAYER_PREV"
        const val ACT_STOP = "com.novan.filemanagerpro.PLAYER_STOP"
        private const val CHANNEL = "player"
        private const val NOTIF_ID = 41

        /** 0 mati, 1 semua lagu, 2 satu lagu */
        const val REPEAT_OFF = 0
        const val REPEAT_ALL = 1
        const val REPEAT_ONE = 2
    }

    inner class LocalBinder : Binder() {
        val service: PlayerService get() = this@PlayerService
    }

    private val binder = LocalBinder()

    var queue: List<String> = emptyList()
        private set
    var index = 0
        private set
    var failed = false
        private set

    /** Dipanggil di thread utama setiap kali status pemutar berubah. */
    var onChange: (() -> Unit)? = null

    private var mp: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var resumeAfterFocus = false
    private val history = ArrayList<Int>()
    private val shuffled = HashSet<Int>()
    private var session: MediaSession? = null
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager
    private var focusRequest: AudioFocusRequest? = null
    private var noisyRegistered = false

    val shuffle: Boolean get() = Prefs.audioShuffle(this)
    val repeat: Int get() = Prefs.audioRepeat(this)
    val speed: Float get() = Prefs.audioSpeed(this)

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (isPlaying()) toggle()
        }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeAfterFocus = false
                if (isPlaying()) pauseInternal()
            }
            // Kehilangan fokus sementara (mis. merekam pesan suara WhatsApp, notifikasi): musik tetap
            // berbunyi, tidak dijeda dan tidak dikecilkan. Hanya fokus hilang permanen (aplikasi musik
            // lain mulai memutar) yang menjeda.
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> Unit
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> Unit
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (resumeAfterFocus && prepared) {
                    resumeAfterFocus = false
                    mp?.start()
                    wantPlay = true
                    updateAll()
                }
            }
        }
    }

    // ---------------------------------------------------------------- siklus hidup

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.player_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val s = MediaSession(this, "FileManagerPro")
        @Suppress("DEPRECATION")
        s.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { if (!isPlaying()) toggle() }
            override fun onPause() { if (isPlaying()) toggle() }
            override fun onSkipToNext() { next() }
            override fun onSkipToPrevious() { prev() }
            override fun onSeekTo(pos: Long) { seekTo(pos.toInt()) }
            override fun onStop() { stopAll() }
        })
        s.isActive = true
        session = s
        registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        noisyRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) {
            stopAll()
            return START_NOT_STICKY
        }
        goForeground()
        when (intent?.action) {
            ACT_TOGGLE -> toggle()
            ACT_NEXT -> next()
            ACT_PREV -> prev()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
        abandonFocus()
        if (noisyRegistered) {
            try { unregisterReceiver(noisyReceiver) } catch (e: Exception) { }
            noisyRegistered = false
        }
        session?.release()
        session = null
        onChange = null
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- perintah

    /** Mengganti daftar putar dan langsung memutar lagu ke-[start]. Isi: jalur berkas atau content://. */
    fun open(list: List<String>, start: Int) {
        if (list.isEmpty()) return
        queue = list
        history.clear()
        shuffled.clear()
        startTrack(start.coerceIn(0, list.size - 1))
    }

    fun jump(i: Int) {
        if (i !in queue.indices) return
        history.add(index)
        startTrack(i)
    }

    fun isPlaying(): Boolean = prepared && mp?.isPlaying == true
    fun isPrepared(): Boolean = prepared
    fun position(): Int = if (prepared) mp?.currentPosition ?: 0 else 0
    fun duration(): Int = if (prepared) mp?.duration ?: 0 else 0

    fun currentName(): String {
        if (queue.isEmpty()) return ""
        val q = queue[index]
        return if (q.startsWith("content:")) Uri.parse(q).lastPathSegment ?: q else File(q).name
    }

    fun toggle() {
        val p = mp ?: return
        if (!prepared) return
        if (p.isPlaying) {
            pauseInternal()
        } else if (requestFocus()) {
            p.start()
            wantPlay = true
            updateAll()
        }
    }

    private fun pauseInternal() {
        val p = mp ?: return
        if (prepared && p.isPlaying) p.pause()
        wantPlay = false
        updateAll()
    }

    fun next() {
        val ni = nextIndex()
        if (ni < 0) return
        history.add(index)
        startTrack(ni)
    }

    fun prev() {
        if (position() > 3000) { seekTo(0); return }
        if (history.isNotEmpty()) {
            startTrack(history.removeAt(history.size - 1))
        } else if (!shuffle && index > 0) {
            startTrack(index - 1)
        } else {
            seekTo(0)
        }
    }

    fun seekTo(ms: Int) {
        val p = mp ?: return
        if (prepared) {
            p.seekTo(ms.coerceIn(0, p.duration))
            updateAll()
        }
    }

    fun skip(delta: Int) = seekTo(position() + delta)

    fun setShuffle(on: Boolean) {
        Prefs.setAudioShuffle(this, on)
        shuffled.clear()
        shuffled.add(index)
        updateAll()
    }

    fun setRepeat(mode: Int) {
        Prefs.setAudioRepeat(this, mode)
        updateAll()
    }

    fun setSpeed(s: Float) {
        Prefs.setAudioSpeed(this, s)
        applySpeed()
        updateAll()
    }

    fun stopAll() {
        releasePlayer()
        abandonFocus()
        session?.isActive = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        onChange?.invoke()
        stopSelf()
    }

    // ---------------------------------------------------------------- inti pemutaran

    private fun nextIndex(): Int {
        val n = queue.size
        if (n == 0) return -1
        if (shuffle) {
            shuffled.add(index)
            if (shuffled.size >= n) {
                if (repeat != REPEAT_ALL) return -1
                shuffled.clear()
                shuffled.add(index)
            }
            if (n == 1) return 0
            val candidates = (0 until n).filter { it !in shuffled }
            return candidates.random()
        }
        if (index + 1 < n) return index + 1
        return if (repeat == REPEAT_ALL) 0 else -1
    }

    private fun startTrack(i: Int) {
        releasePlayer()
        index = i
        failed = false
        prepared = false
        wantPlay = true
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            val q = queue[i]
            if (q.startsWith("content:")) p.setDataSource(this, Uri.parse(q)) else p.setDataSource(q)
            p.setOnPreparedListener {
                prepared = true
                applySpeed()
                if (wantPlay && requestFocus()) it.start() else wantPlay = false
                updateAll()
            }
            p.setOnCompletionListener { onCompleted() }
            p.setOnErrorListener { _, _, _ ->
                failed = true
                wantPlay = false
                prepared = false
                updateAll()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            failed = true
            wantPlay = false
        }
        updateAll()
    }

    private fun onCompleted() {
        if (repeat == REPEAT_ONE) {
            mp?.seekTo(0)
            mp?.start()
            updateAll()
            return
        }
        val ni = nextIndex()
        if (ni >= 0) {
            history.add(index)
            startTrack(ni)
        } else {
            wantPlay = false
            updateAll()
        }
    }

    private fun applySpeed() {
        val p = mp ?: return
        if (!prepared || Build.VERSION.SDK_INT < 23) return
        try {
            val was = p.isPlaying
            p.playbackParams = PlaybackParams().setSpeed(speed)
            if (!was) p.pause()
        } catch (e: Exception) { }
    }

    private fun releasePlayer() {
        prepared = false
        mp?.let {
            try { it.release() } catch (e: Exception) { }
        }
        mp = null
    }

    private fun requestFocus(): Boolean {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusRequest = req
        return audio.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        focusRequest?.let { audio.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    // ---------------------------------------------------------------- notifikasi dan sesi

    private fun updateAll() {
        updateSession()
        nm.notify(NOTIF_ID, buildNotification())
        onChange?.invoke()
    }

    private fun updateSession() {
        val s = session ?: return
        val state = when {
            isPlaying() -> PlaybackState.STATE_PLAYING
            prepared -> PlaybackState.STATE_PAUSED
            failed -> PlaybackState.STATE_ERROR
            wantPlay -> PlaybackState.STATE_BUFFERING
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
            PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO or
            PlaybackState.ACTION_STOP
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(state, position().toLong(), if (isPlaying()) speed else 0f)
                .build()
        )
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, currentName())
                .putLong(MediaMetadata.METADATA_KEY_DURATION, duration().toLong())
                .build()
        )
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, PlayerService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun action(iconRes: Int, title: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, iconRes), title, pi).build()

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, AudioPlayerActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val playing = isPlaying()
        val text = when {
            failed -> getString(R.string.audio_failed)
            queue.isNotEmpty() -> getString(R.string.player_notif_text, index + 1, queue.size)
            else -> ""
        }
        val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        session?.let { style.setMediaSession(it.sessionToken) }
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(currentName().ifEmpty { getString(R.string.music_player) })
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(R.drawable.ic_prev, getString(R.string.audio_prev), actionIntent(ACT_PREV, 1)))
            .addAction(
                action(
                    if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                    getString(if (playing) R.string.audio_pause else R.string.audio_play),
                    actionIntent(ACT_TOGGLE, 2)
                )
            )
            .addAction(action(R.drawable.ic_next, getString(R.string.audio_next), actionIntent(ACT_NEXT, 3)))
            .addAction(action(R.drawable.ic_stop, getString(R.string.audio_stop), actionIntent(ACT_STOP, 4)))
            .setStyle(style)
            .build()
    }
}
