package com.makroku.automation.service

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.makroku.automation.MakroApp
import com.makroku.automation.R
import com.makroku.automation.model.TriggerEvent
import com.makroku.automation.model.WidgetTrigger

/** Widget layar utama dengan 3 tombol; tiap tombol menjalankan makro berpemicu "Widget layar utama" bernomor sama. */
class MacroWidget : AppWidgetProvider() {

    companion object {
        const val ACT = "com.makroku.automation.WIDGET_SLOT"
        private val slotIds = intArrayOf(R.id.slot1, R.id.slot2, R.id.slot3)

        fun build(ctx: Context): RemoteViews {
            val macros = (ctx.applicationContext as MakroApp).repo.macros.value
            val rv = RemoteViews(ctx.packageName, R.layout.widget_makro)
            for (i in 0 until 3) {
                val slot = i + 1
                val m = macros.firstOrNull { x -> x.enabled && x.triggers.any { it is WidgetTrigger && it.slot == slot } }
                rv.setTextViewText(slotIds[i], m?.name ?: "Tombol $slot (kosong)")
                rv.setContentDescription(slotIds[i], m?.name ?: "Tombol $slot, belum ada makro")
                val intent = Intent(ctx, MacroWidget::class.java).setAction(ACT).putExtra("slot", slot)
                rv.setOnClickPendingIntent(
                    slotIds[i],
                    PendingIntent.getBroadcast(ctx, slot, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT),
                )
            }
            return rv
        }

        /** Dipanggil saat daftar makro berubah agar label tombol ikut berubah. */
        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MacroWidget::class.java))
            if (ids.isEmpty()) return
            val rv = build(ctx)
            ids.forEach { mgr.updateAppWidget(it, rv) }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val rv = build(context)
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, rv) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACT) {
            val slot = intent.getIntExtra("slot", 0)
            (context.applicationContext as MakroApp).engine.dispatch(TriggerEvent("widget", mapOf("slot" to slot.toString())))
        }
    }
}
