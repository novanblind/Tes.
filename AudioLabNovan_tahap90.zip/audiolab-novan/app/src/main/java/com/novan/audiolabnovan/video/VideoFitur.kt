package com.novan.audiolabnovan.video

import com.novan.audiolabnovan.Fitur
import com.novan.audiolabnovan.info.InfoMediaActivity

/**
 * Tahap 85: daftar alat video untuk kisi "Alat Video" (meniru kisi video AudioLab asli).
 * Semua alat berjalan di perangkat lewat FFmpeg, tanpa AI dan tanpa internet.
 * Video SFX sengaja tidak ada karena butuh AI.
 */
object VideoFitur {
    const val EXTRA = "alat_video"
    const val EXTRA_JUDUL = "judul_alat_video"
    /** Tahap 86: alamat video (teks URI) yang dibagikan dari pengelola berkas, langsung terpilih. */
    const val EXTRA_URI = "uri_video"

    private val alat = AlatVideoActivity::class.java

    val daftar: List<Fitur.Def> = listOf(
        Fitur.Def("trim", "Potong (Trim)", "\u2702",
            "Ambil satu bagian video, dari waktu mulai sampai waktu akhir.", tujuan = alat),
        Fitur.Def("kompres", "Kompres", "\u21CA",
            "Perkecil ukuran video dengan menurunkan kualitas atau resolusinya.", tujuan = alat),
        Fitur.Def("balik", "Balik (Reverse)", "\u21BA",
            "Putar video dari belakang ke depan. Sebaiknya untuk video pendek.", tujuan = alat),
        Fitur.Def("splitter", "Splitter", "\u00F7",
            "Bagi video jadi beberapa bagian, per lama tertentu atau di titik waktu yang Anda isi.", tujuan = alat),
        Fitur.Def("mixer", "Video Audio Mixer", "\u21C5",
            "Campur suara asli video dengan audio tambahan, misalnya musik latar. Volume masing-masing bisa diatur.", tujuan = alat),
        Fitur.Def("kecepatan", "Pengubah Kecepatan", "\u00BB",
            "Percepat atau perlambat video beserta suaranya.", tujuan = alat),
        Fitur.Def("video_audio", "Video Ke Audio", "\u266A",
            "Ambil suara dari video menjadi berkas MP3, M4A, FLAC, atau WAV.", tujuan = alat),
        Fitur.Def("gif", "Video Ke GIF", "GIF",
            "Ubah potongan pendek video menjadi gambar GIF bergerak.", tujuan = alat),
        Fitur.Def("booster", "Volume Booster", "\u25B2",
            "Keraskan suara video sampai 500 persen, dengan pembatas agar tidak pecah.", tujuan = alat),
        Fitur.Def("hapus", "Hapus", "\u2715",
            "Hapus suara dari video, atau buang satu bagian di tengah video.", tujuan = alat),
        Fitur.Def("heningkan", "Heningkan (Silence)", "\u22EF",
            "Buat suara pada bagian tertentu jadi senyap, gambar tetap utuh.", tujuan = alat),
        Fitur.Def("loop", "Loop", "\u27F3",
            "Ulangi video beberapa kali jadi satu berkas.", tujuan = alat),
        Fitur.Def("noise", "Penghapus Noise Video", "\u2727",
            "Kurangi desis dan dengung pada suara video. Gambar tidak diubah.", tujuan = alat),
        Fitur.Def("info_video", "Info Media Video", "\u24D8",
            "Lihat format, durasi, codec, dan detail lain sebuah video.", tujuan = InfoMediaActivity::class.java),
        Fitur.Def("stabilkan", "Stabilkan", "\u25A3",
            "Kurangi guncangan pada video yang direkam sambil memegang HP.", tujuan = alat),
        Fitur.Def("editor_video", "Editor Video (VideoLab)", "\u25B6",
            "Editor video lengkap: potong dan susun klip, kecepatan, warna, subtitle, musik latar, teks, transisi, dan ekspor.",
            tujuan = com.novan.audiolabnovan.videolab.VideoLabBerandaActivity::class.java)
    )

    fun cari(id: String?): Fitur.Def? = daftar.firstOrNull { it.id == id }
}
