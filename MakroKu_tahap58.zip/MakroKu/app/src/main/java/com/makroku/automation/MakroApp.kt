package com.makroku.automation

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.engine.MacroEngine

class MakroApp : Application() {
    lateinit var repo: MacroRepository
        private set
    lateinit var engine: MacroEngine
        private set

    override fun onCreate() {
        super.onCreate()
        repo = MacroRepository(this)
        engine = MacroEngine(this, repo)
        engine.start()

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_SERVICE, "Layanan MakroKu", NotificationManager.IMPORTANCE_LOW),
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ACTIONS, "Notifikasi makro", NotificationManager.IMPORTANCE_DEFAULT),
        )
    }

    companion object {
        const val CHANNEL_SERVICE = "makroku_service"
        const val CHANNEL_ACTIONS = "makroku_actions"
    }
}
