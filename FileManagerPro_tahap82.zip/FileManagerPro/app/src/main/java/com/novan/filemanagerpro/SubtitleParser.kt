package com.novan.filemanagerpro

import java.io.File

/** Pembaca subtitle SRT dan WebVTT. */
object SubtitleParser {

    class Cue(val start: Long, val end: Long, val text: String)

    private val TIME = Regex(
        """(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})"""
    )
    private val TAGS = Regex("<[^>]*>")
    private val BRACES = Regex("\\{[^}]*\\}")

    fun read(f: File): List<Cue> {
        val bytes = f.readBytes()
        var text = String(bytes, Charsets.UTF_8)
        if (text.contains('\uFFFD')) text = String(bytes, Charsets.ISO_8859_1)
        return parse(text.removePrefix("\uFEFF"))
    }

    private fun ms(h: String, m: String, s: String, f: String): Long =
        (h.toLongOrNull() ?: 0L) * 3600000L + m.toLong() * 60000L + s.toLong() * 1000L +
            f.padEnd(3, '0').toLong()

    fun parse(text: String): List<Cue> {
        val out = ArrayList<Cue>()
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        var i = 0
        while (i < lines.size) {
            val m = TIME.find(lines[i])
            if (m == null) {
                i++
                continue
            }
            val g = m.groupValues
            val start = ms(g[1], g[2], g[3], g[4])
            val end = ms(g[5], g[6], g[7], g[8])
            val sb = StringBuilder()
            i++
            while (i < lines.size && lines[i].isNotBlank()) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(lines[i])
                i++
            }
            val t = sb.toString().replace(TAGS, "").replace(BRACES, "").trim()
            if (t.isNotEmpty()) out.add(Cue(start, end, t))
        }
        return out.sortedBy { it.start }
    }

    /** Mencari subtitle yang namanya sama dengan video, di folder yang sama. */
    fun findFor(video: File): File? {
        val base = video.nameWithoutExtension
        val dir = video.parentFile ?: return null
        for (ext in listOf("srt", "vtt", "SRT", "VTT")) {
            val f = File(dir, "$base.$ext")
            if (f.isFile) return f
        }
        return null
    }
}
