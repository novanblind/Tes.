package com.makroku.automation.data

import com.makroku.automation.model.*
import kotlinx.serialization.json.*

/** Hasil membaca berkas makro: [macros] siap disimpan, [warnings] = bagian yang tidak bisa dibawa. */
data class ImportResult(
    val macros: List<Macro>,
    val warnings: List<String>,
    /** Variabel dari cadangan lengkap MakroKu (kosong untuk berkas MacroDroid). */
    val variables: Map<String, String> = emptyMap(),
)

/**
 * Mengubah berkas `.macro` hasil ekspor MacroDroid menjadi makro MakroKu.
 * Hanya jenis yang pernah dicocokkan dengan contoh berkas asli yang diubah. Sisanya dilewati,
 * diberi catatan di dalam makro, dan disebut di [ImportResult.warnings] supaya tidak diam-diam hilang.
 */
object MacroDroidImport {
    private val paketUmum = mapOf("WhatsApp" to "com.whatsapp", "WhatsApp Business" to "com.whatsapp.w4b")
    private val IF_STOP = setOf("ElseIfConditionAction", "ElseAction", "EndIfAction")
    private val LOOP_STOP = setOf("EndLoopAction")
    private val SISA = setOf("ElseIfConditionAction", "ElseAction", "EndIfAction", "EndLoopAction")

    /** Keadaan selama satu makro diubah. */
    private class Konteks(
        val namaMakro: String, val w: (String) -> Unit,
        /** Nama variabel global yang dideklarasikan di berkas (penanda {v=nama}). */
        val global: Set<String> = emptySet(),
        /** Variabel yang hanya diisi oleh dialog (keluaran), bukan oleh aksi Atur variabel. */
        val keluaran: Set<String> = emptySet(),
    ) {
        /** Variabel kamus (hasil Urai JSON) → variabel teks asal JSON-nya. Dibaca langsung dari teks saat dibutuhkan. */
        val kamus = mutableMapOf<String, String>()
        var peringatBandingTeks = false
        /** GUID pemicu MacroDroid → nomor pemicu pertama yang dihasilkannya di MakroKu (mulai 0). */
        val nomorPemicu = mutableMapOf<Long, Int>()
        /** Variabel daftar (hasil pecah teks) → isinya. */
        val daftar = mutableMapOf<String, List<String>>()
        /** Variabel nomor pilihan → (variabel teks pilihan, isi menu). Dialog MakroKu menyimpan teks, bukan nomor. */
        val menu = mutableMapOf<String, Pair<String, List<String>>>()
        var cabangGagal = 0
        /** Butir daftar yang sedang diulang (untuk penanda {iterator_value}); null di luar ulangan daftar. */
        var iterator: String? = null
    }

    fun convert(text: String): ImportResult {
        val root = Json.parseToJsonElement(text).jsonObject
        val m = root["macro"]?.jsonObject ?: error("Bukan berkas makro MacroDroid")
        val warn = mutableListOf<String>()
        val nama = m.str("m_name").ifBlank { "Makro MacroDroid" }
        fun w(s: String) { if (s !in warn) warn += s }
        val global = (root["globalVariables"] as? JsonArray).orEmpty()
            .mapNotNull { (it as? JsonObject)?.get("m_name")?.jsonPrimitive?.contentOrNull }.toSet()
        val keluaran = m.arr("m_actionList").flatMap { a ->
            val ao = a.jsonObject
            val dariDialog = listOf("saveValueVariable", "saveIndexVariable")
                .mapNotNull { (ao[it] as? JsonObject)?.str("variableName")?.takeIf { n -> n.isNotBlank() } }
            dariDialog + (if (ao.str("m_classType") == "VoiceInputAction") listOf(ao.str("variableName")) else emptyList())
        }.toSet()
        val k = Konteks(nama, ::w, global, keluaran)

        val triggers = mutableListOf<MacroTrigger>()
        // Batasan yang menempel pada satu pemicu. MakroKu hanya punya batasan makro, jadi tiap batasan dibungkus
        // "bukan pemicu ini ATAU batasannya": hanya berlaku bila makro dijalankan oleh pemicu itu.
        val syaratPemicu = mutableListOf<MacroConstraint>()
        m.arr("m_triggerList").forEach { t ->
            val o = t.jsonObject
            val hasil = trigger(o, k)
            if (hasil.isNotEmpty()) {
                val awal = triggers.size
                val guid = o.long("m_SIGUID")
                if (guid != 0L) k.nomorPemicu.putIfAbsent(guid, awal)
                triggers += hasil
                val ada = o.arr("m_constraintList").mapNotNull { constraint(it.jsonObject, k) }
                if (ada.isNotEmpty()) {
                    val nomor = (awal until awal + hasil.size).map<Int, MacroConstraint> { TriggerIndexConstraint(it + 1) }
                    val ini: MacroConstraint = if (nomor.size == 1) nomor[0] else LogicConstraint("OR", nomor)
                    val isi: MacroConstraint = if (ada.size == 1) ada[0] else LogicConstraint(if (o.bool("m_isOrCondition", false)) "OR" else "AND", ada)
                    syaratPemicu += LogicConstraint("OR", listOf(LogicConstraint("NOT", listOf(ini)), isi))
                }
            }
        }
        val actions = parseBlock(m.arr("m_actionList").map { it.jsonObject }, intArrayOf(0), k, emptySet())
        var cons: List<MacroConstraint> = m.arr("m_constraintList").mapNotNull { constraint(it.jsonObject, k) }
        var semua = m.bool("m_isOrCondition", false)
        if (syaratPemicu.isNotEmpty()) {
            if (semua && cons.size > 1) cons = listOf(LogicConstraint("OR", cons))
            semua = false
            cons = cons + syaratPemicu
        }

        val macro = Macro(
            name = nama,
            description = m.str("m_description"),
            category = m.str("m_category").ifBlank { "Umum" },
            enabled = m.bool("m_enabled", true),
            triggers = triggers,
            actions = actions,
            constraints = cons,
            constraintAny = semua,
        )
        return ImportResult(listOf(macro), warn)
    }

    // ── pemicu ──
    private fun trigger(o: JsonObject, k: Konteks): List<MacroTrigger> {
        if (o.bool("m_isDisabled", false)) return emptyList()
        return when (val c = o.str("m_classType")) {
            "NotificationTrigger" -> {
                val pk = paket(o)
                val regex = o.bool("enableRegex", false)
                val teks = if (regex) o.str("m_textContent") else polos(o.str("m_textContent"))
                if (o.bool("m_exactMatch", false)) k.w("Pemicu notifikasi: pencocokan persis tidak dibawa; dipakai \"mengandung\"")
                if (o.bool("m_excludeApps", false) && pk.isNotEmpty()) {
                    k.w("Pemicu notifikasi \"kecuali aplikasi ini\" tidak didukung; pemicu dilewati"); emptyList()
                } else {
                    val tanpa = o.bool("m_excludes", false)
                    val abaikanBerjalan = o.bool("m_ignoreOngoing", false)
                    fun buat(p: String) = NotificationTrigger(p, teks, excludes = tanpa, ignoreOngoing = abaikanBerjalan, regex = regex)
                    if (pk.isEmpty()) listOf(buat("")) else pk.map { buat(it) }
                }
            }
            "TimerTrigger" -> {
                // Urutan hari MacroDroid dibaca mulai Minggu (sama dengan Calendar.DAY_OF_WEEK: 1 = Minggu).
                val hari = o.arr("m_daysOfWeek").mapIndexedNotNull { i, v -> if (v.jsonPrimitive.booleanOrNull == true) i + 1 else null }
                    .filter { it in 1..7 }
                listOf(TimeTrigger(o.int("m_hour").coerceIn(0, 23), o.int("m_minute").coerceIn(0, 59), hari.ifEmpty { ALL_DAYS }))
            }
            "ShakeDeviceTrigger" -> listOf(ShakeTrigger())
            "EmptyTrigger" -> listOf(ManualTrigger)
            "BatteryLevelTrigger" -> {
                if (o.int("m_option") != 0) k.w("Pemicu baterai: opsi lanjutan tidak dibawa")
                listOf(BatteryLevelTrigger(o.int("m_batteryLevel").coerceIn(0, 100), below = o.bool("m_decreasesTo", false)))
            }
            "ExternalPowerTrigger" -> {
                if (o.arr("m_powerConnectedOptions").any { it.jsonPrimitive.booleanOrNull == false }) k.w("Pemicu daya: jenis pengisi (AC/USB/nirkabel) tidak dibedakan")
                listOf(PowerTrigger(o.bool("m_powerConnected", true)))
            }
            "DeviceUnlockedTrigger" -> listOf(UnlockTrigger)
            "FlipDeviceTrigger" -> listOf(FlipTrigger(o.bool("m_faceDown", true)))
            "IntentReceivedTrigger" -> {
                val aksi = o.str("action")
                if (o.arr("extraParams").isNotEmpty() || o.arr("extraValuePatterns").isNotEmpty()) k.w("Pemicu intent: data tambahan (extra) tidak dibaca")
                if (o.bool("enableRegex", false)) k.w("Pemicu intent memakai regex; dipakai sebagai teks biasa")
                if (aksi.isBlank()) { k.w("Pemicu intent tanpa nama aksi dilewati"); emptyList() } else listOf(IntentTrigger(aksi))
            }
            "ScreenContentTrigger" -> {
                val teks = polos(o.str("textToMatch"))
                when {
                    o.int("matchOption") != 0 -> { k.w("Pemicu isi layar berdasarkan ID tampilan tidak didukung (hanya tulisan)"); emptyList() }
                    o.bool("isOffScreen", false) -> { k.w("Pemicu \"tulisan hilang dari layar\" tidak didukung"); emptyList() }
                    teks.isBlank() -> { k.w("Pemicu isi layar tanpa tulisan dilewati"); emptyList() }
                    else -> {
                        if (o.bool("enableRegex", false)) k.w("Pemicu isi layar memakai regex; dipakai sebagai teks biasa")
                        val pk = daftarPaket(o, "packageNameList")
                        if (pk.isEmpty()) listOf(ScreenTextTrigger(teks, "")) else pk.map { ScreenTextTrigger(teks, it) }
                    }
                }
            }
            "ProximityTrigger" -> {
                if (o.int("m_selectedOption") != 0) k.w("Opsi lanjutan sensor jarak tidak dibawa; dibaca dekat/jauh biasa")
                listOf(ProximityTrigger(o.bool("m_near", true)))
            }
            "ScreenOnOffTrigger" -> listOf(ScreenTrigger(o.bool("m_screenOn", true)))
            "ApplicationLaunchedTrigger" -> {
                val buka = o.bool("m_launched", true)
                val pk = if (o.bool("isAllApps", false)) listOf("") else daftarPaket(o, "m_packageNameList")
                if (pk.isEmpty()) { k.w("Pemicu aplikasi tanpa nama paket dilewati"); emptyList() }
                else pk.map { if (buka) AppLaunchedTrigger(it) else AppClosedTrigger(it) }
            }
            else -> { k.w("Pemicu tidak didukung: $c"); emptyList() }
        }
    }

    // ── batasan ──
    private fun constraint(o: JsonObject, k: Konteks): MacroConstraint? {
        val c = o.str("m_classType")
        val hasil: MacroConstraint? = when (c) {
            "NotificationPresentConstraint" -> {
                if (o.bool("enableRegex", false)) k.w("Batasan notifikasi memakai regex; dipakai sebagai teks biasa")
                NotificationPresentConstraint(paket(o).joinToString(","), o.str("m_textContent"), present = !o.bool("m_excludes", false))
            }
            "TriggerThatInvokedConstraint" -> {
                val no = k.nomorPemicu[o.long("m_siGuidThatInvoked")]
                if (no == null) { k.w("Batasan \"pemicu yang menjalankan\" tidak cocok dengan pemicu mana pun"); null }
                else TriggerIndexConstraint(no + 1)
            }
            "MacroDroidVariableConstraint" -> variabel(o, k)
            "CompareValueConstraint" -> bandingNilai(o, k)
            "TimeOfDayConstraint" -> TimeRangeConstraint(
                o.int("m_startHour").coerceIn(0, 23), o.int("m_startMinute").coerceIn(0, 59),
                o.int("m_endHour").coerceIn(0, 23), o.int("m_endMinute").coerceIn(0, 59),
            )
            "MusicActiveConstraint" -> MusicActiveConstraint(o.bool("m_musicActive", true))
            "DeviceLockedConstraint" -> LockedConstraint(o.bool("m_locked", true))
            "ActiveApplicationConstraint" -> {
                val pk = daftarPaket(o, "m_packageNameList")
                if (pk.isEmpty()) { k.w("Batasan aplikasi aktif tanpa nama paket dilewati"); null }
                else {
                    val depan = o.bool("m_foreground", true)
                    if (!depan) k.w("Batasan \"aplikasi berjalan\" memakai sambungan ADB MakroKu")
                    val daftar = pk.map<String, MacroConstraint> { if (depan) ForegroundAppConstraint(it) else AppRunningConstraint(it, true) }
                    val gabung: MacroConstraint = if (daftar.size == 1) daftar[0] else LogicConstraint("OR", daftar)
                    if (o.bool("m_active", true)) gabung else LogicConstraint("NOT", listOf(gabung))
                }
            }
            else -> { k.w("Batasan tidak didukung: $c"); null }
        }
        if (hasil != null && c != "NotificationPresentConstraint" && o.bool("m_not", false)) return LogicConstraint("NOT", listOf(hasil))
        return hasil
    }

    /**
     * Batasan "Bandingkan nilai" MacroDroid untuk teks (type 2). Urutan jenis perbandingan dibaca dari contoh berkas:
     * 0 sama, 1 tidak sama, 4 mengandung, 5 tidak mengandung (dengan regex menyala: ada yang cocok / tidak ada yang cocok).
     */
    private fun bandingNilai(o: JsonObject, k: Konteks): MacroConstraint? {
        if (o.int("type") != 2) { k.w("Batasan bandingkan nilai selain teks tidak dibaca (jenis ${o.int("type")})"); return null }
        val regex = o.bool("enableRegex", false)
        val jenis = when (o.int("comparisonType")) {
            0 -> if (regex) "cocok" else "sama"
            1 -> if (regex) "tidak_cocok" else "beda"
            4 -> if (regex) "cocok" else "mengandung"
            5 -> if (regex) "tidak_cocok" else "tidak_mengandung"
            else -> { k.w("Batasan bandingkan teks: jenis perbandingan ${o.int("comparisonType")} tidak dibaca"); return null }
        }
        if (!k.peringatBandingTeks) {
            k.peringatBandingTeks = true
            k.w("Bandingkan teks: jenis 0 dibaca \"sama\", 1 \"tidak sama\", 4 \"mengandung\", 5 \"tidak mengandung\"; periksa di editor")
        }
        // Pola regex tidak lewat penggantian penanda biasa (tanda kurung kurawal di regex bukan penanda).
        val kanan = if (regex) gantiVar(o.str("value2"), k) else placeholder(o.str("value2"), k)
        return StringCompareConstraint(
            left = placeholder(o.str("value1"), k), textCmp = jenis, right = kanan,
            regex = regex, ignoreCase = o.bool("ignoreCase", false),
        )
    }

    private fun variabel(o: JsonObject, k: Konteks): MacroConstraint? {
        val v = o["m_variable"] as? JsonObject ?: run { k.w("Batasan variabel tanpa nama variabel"); return null }
        val nama = v.str("m_name")
        if (nama.isBlank()) { k.w("Batasan variabel tanpa nama variabel"); return null }
        if (o.bool("m_intCompareVariable", false)) { k.w("Batasan variabel yang membandingkan dua variabel tidak dibaca"); return null }
        val tidakSama = o.bool("m_intNotEqual", false)
        val lebih = o.bool("m_intGreaterThan", false)
        val kurang = o.bool("m_intLessThan", false)

        // Nomor pilihan dari dialog pilihan: MakroKu menyimpan teks pilihan, jadi bandingkan dengan teks butir ke-N.
        k.menu[nama]?.let { (varTeks, butir) ->
            if (lebih || kurang) { k.w("Perbandingan lebih besar/kecil pada nomor pilihan tidak dibaca"); return null }
            val teks = butir.getOrNull(o.int("m_intValue") - 1)
            if (teks == null) { k.w("Nomor pilihan ${o.int("m_intValue")} di luar daftar menu"); return null }
            val sama = VariableConstraint(varTeks, teks)
            return if (tidakSama) LogicConstraint("NOT", listOf(sama)) else sama
        }
        return when (v.int("m_type")) {
            1 -> {
                val cmp = when { tidakSama -> "!="; lebih -> ">"; kurang -> "<"; else -> "==" }
                VariableCompareConstraint(nama, cmp, o.int("m_intValue").toString())
            }
            2 -> {
                if (o.bool("enableRegex", false) || o.int("m_stringComparisonType") != 0) {
                    k.w("Batasan teks variabel selain \"sama dengan\" tidak dibaca"); null
                } else {
                    val sama = VariableConstraint(nama, placeholder(o.str("m_stringValue"), k))
                    if (o.bool("m_stringEqual", true)) sama else LogicConstraint("NOT", listOf(sama))
                }
            }
            0 -> VariableConstraint(nama, if (o.bool("m_booleanValue", false)) "true" else "false")
            else -> { k.w("Batasan variabel bertipe desimal/kamus tidak dibaca"); null }
        }
    }

    // ── aksi (daftar datar: LoopAction…EndLoopAction, IfCondition…ElseIf…Else…EndIf) ──
    private fun parseBlock(l: List<JsonObject>, pos: IntArray, k: Konteks, stop: Set<String>): List<MacroAction> {
        val out = mutableListOf<MacroAction>()
        while (pos[0] < l.size) {
            val o = l[pos[0]]
            val c = o.str("m_classType")
            if (c in stop) return out
            pos[0]++
            val mati = o.bool("m_isDisabled", false)
            when (c) {
                in SISA -> continue // penutup yatim, abaikan
                "LoopAction" -> {
                    val dalam = parseBlock(l, pos, k, LOOP_STOP)
                    if (pos[0] < l.size && l[pos[0]].str("m_classType") == "EndLoopAction") pos[0]++
                    if (mati) continue
                    val syarat = o.arr("m_constraintList").mapNotNull { constraint(it.jsonObject, k) }
                    if (syarat.isNotEmpty()) out += WhileConstraintAction(syarat, 300, dalam)
                    else {
                        if (o.int("m_option") == 3) {
                            k.w("Ulangan tanpa henti (sampai dibatalkan) dipakai 300 putaran")
                            out += LoopAction(300, dalam)
                        } else {
                            k.w("Ulangan tanpa batasan (jumlah putaran tidak terbaca); dipakai 3 kali")
                            out += LoopAction(3, dalam)
                        }
                    }
                }
                "IterateDictionaryAction" -> {
                    val nama = o.str("varAsMagicText").ifBlank { o.str("variableName") }
                    val butir = k.daftar[nama]
                    val awal = pos[0]
                    val lama = k.iterator
                    val hasil = mutableListOf<MacroAction>()
                    if (butir == null || butir.isEmpty()) {
                        k.w("Ulangi tiap butir daftar memakai daftar yang tidak terbaca ($nama); isinya dilewati")
                        k.iterator = ""
                        parseBlock(l, pos, k, LOOP_STOP)
                        hasil += NoteAction("Tidak diimpor dari MacroDroid: ulangi tiap butir daftar")
                    } else {
                        for (b in butir) {
                            pos[0] = awal
                            k.iterator = b
                            hasil += parseBlock(l, pos, k, LOOP_STOP)
                        }
                    }
                    k.iterator = lama
                    if (pos[0] < l.size && l[pos[0]].str("m_classType") == "EndLoopAction") pos[0]++
                    if (!mati) out += hasil
                }
                "IfConditionAction" -> {
                    val sebelum = k.cabangGagal
                    val a = parseIf(o, l, pos, k)
                    if (mati) continue
                    if (k.cabangGagal > sebelum) {
                        k.w("Percabangan dilewati karena ada batasan yang tidak didukung")
                        out += NoteAction("Percabangan tidak diimpor dari MacroDroid (batasan tidak didukung)")
                    } else out += a
                }
                else -> {
                    if (mati) continue
                    val a = satu(o, k) ?: continue
                    // Batasan di aksi biasa: bungkus dengan "Jika batasan terpenuhi".
                    val bat = o.arr("m_constraintList").mapNotNull { constraint(it.jsonObject, k) }
                    out += if (bat.isEmpty()) a else IfConstraintAction(bat, listOf(a), emptyList())
                }
            }
        }
        return out
    }

    /** [o] = IfConditionAction atau ElseIfConditionAction yang baru dibaca. Penutup EndIf dimakan oleh cabang terakhir. */
    private fun parseIf(o: JsonObject, l: List<JsonObject>, pos: IntArray, k: Konteks): MacroAction {
        val daftar = o.arr("m_constraintList").map { constraint(it.jsonObject, k) }
        if (daftar.any { it == null } || daftar.isEmpty()) k.cabangGagal++
        val ada = daftar.filterNotNull()
        val syarat = if (o.bool("m_isOrCondition", false) && ada.size > 1) listOf<MacroConstraint>(LogicConstraint("OR", ada)) else ada
        val maka = parseBlock(l, pos, k, IF_STOP)
        var lain: List<MacroAction> = emptyList()
        if (pos[0] < l.size) {
            val n = l[pos[0]]
            when (n.str("m_classType")) {
                "ElseIfConditionAction" -> { pos[0]++; lain = listOf(parseIf(n, l, pos, k)) }
                "ElseAction" -> {
                    pos[0]++
                    lain = parseBlock(l, pos, k, IF_STOP)
                    if (pos[0] < l.size && l[pos[0]].str("m_classType") == "EndIfAction") pos[0]++
                }
                "EndIfAction" -> pos[0]++
            }
        }
        return IfConstraintAction(syarat, maka, lain)
    }

    private fun satu(o: JsonObject, k: Konteks): MacroAction? {
        val c = o.str("m_classType")
        return when (c) {
            "PauseAction" -> {
                val detik = o.long("m_delayInSeconds") + (o.long("m_delayInMilliSeconds") + 999) / 1000
                if (o.long("m_delayInSeconds") == 0L && o.long("m_delayInMilliSeconds") == 0L) null
                else { if (o.int("unitForVariables") != 0) k.w("Jeda memakai variabel; dipakai nilai tetap"); DelayAction(detik) }
            }
            "SpeakTextAction" -> {
                if (o.double("m_speed", 1.0) != 1.0 || o.double("m_pitch", 1.0) != 1.0) k.w("Kecepatan dan nada bicara tidak dibawa (pakai setelan suara MakroKu)")
                SpeakAction(placeholder(o.str("m_textToSay"), k))
            }
            // Pilihan 0 = aktifkan, 1 = nonaktifkan, 2 = alih (urutan Aktifkan/Nonaktifkan/Alih di MacroDroid, cocok dengan jadwal contoh).
            "SetAutoSyncAction" -> {
                k.w("Sinkron dan data seluler: nilai 0 dibaca \"aktifkan\", 1 \"nonaktifkan\", 2 \"alih\"; periksa di editor")
                SyncAction(enable = o.int("m_state") != 1, toggle = o.int("m_state") == 2)
            }
            "SetDataAction" -> {
                k.w("Sinkron dan data seluler: nilai 0 dibaca \"aktifkan\", 1 \"nonaktifkan\", 2 \"alih\"; periksa di editor")
                MobileDataAction(enable = o.int("m_state") != 1, toggle = o.int("m_state") == 2)
            }
            "TextManipulationAction" -> {
                val jenis = (o["m_textManipulation"] as? JsonObject)?.str("type").orEmpty()
                val teks = o.str("m_text")
                val nama = o.str("variableName")
                if (jenis == "SplitManipulation" && nama.isNotBlank() && "{" !in teks && "[lv=" !in teks && "[v=" !in teks) {
                    val sep = ((o["m_textManipulation"] as JsonObject)["params"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.contentOrNull.orEmpty().ifEmpty { "," }
                    k.daftar[nama] = teks.split(sep).map { it.trim() }.filter { it.isNotEmpty() }
                    null // dipakai langsung oleh dialog pilihan berikutnya
                } else if (jenis == "ReplaceAllManipulation" && nama.isNotBlank()) {
                    val par = ((o["m_textManipulation"] as? JsonObject)?.get("params") as? JsonArray)
                        ?.map { (it as? JsonPrimitive)?.contentOrNull.orEmpty() }.orEmpty()
                    if (par.size < 2 || par[0].isEmpty()) { k.w("Ganti semua teks tanpa teks yang dicari dilewati"); null }
                    else {
                        if (par.drop(2).any { it == "true" }) k.w("Ganti semua teks: opsi regex/abaikan huruf tidak dibawa; dipakai penggantian biasa")
                        TextOpAction(text = placeholder(teks, k), textOp = "replace", arg = par[0], arg2 = par[1], saveTo = nama)
                    }
                } else { k.w("Olah teks tidak didukung (hanya pecah teks tetap dan ganti semua): ${jenis.ifBlank { c }}"); NoteAction("Tidak diimpor dari MacroDroid: olah teks") }
            }
            "SelectionDialogAction" -> {
                val butir = k.daftar[o.str("dictionaryVarName")]
                if (butir == null || butir.isEmpty()) {
                    k.w("Dialog pilihan memakai daftar yang tidak terbaca"); NoteAction("Tidak diimpor dari MacroDroid: dialog pilihan")
                } else {
                    val varTeks = ((o["saveValueVariable"] as? JsonObject)?.str("variableName")).orEmpty().ifBlank { "pilihan_dialog" }
                    val varNomor = ((o["saveIndexVariable"] as? JsonObject)?.str("variableName")).orEmpty()
                    if (varNomor.isNotBlank()) k.menu[varNomor] = varTeks to butir
                    val detik = o.int("defaultTimeOutSecs").let { if (it <= 0) 120 else it }
                    ChoicePromptAction(
                        title = placeholder(o.str("message"), k).ifBlank { k.namaMakro },
                        text = "", items = butir.joinToString("\n"), yesNo = false, saveTo = varTeks, seconds = detik,
                    )
                }
            }
            "SetVariableAction" -> {
                val v = o["m_variable"] as? JsonObject
                val nama = v?.str("m_name").orEmpty()
                if (v == null || nama.isBlank()) { k.w("Aksi variabel tanpa nama variabel dilewati"); return null }
                // Nilai baru ada di kolom m_new…; berkas lama menyimpannya di variabel itu sendiri (dipakai bila kolom baru kosong).
                val adaBaru = o.str("m_newStringValue").isNotEmpty() || o.int("m_newIntValue") != 0 ||
                    o.bool("m_newBooleanValue", false) || o.double("m_newDoubleValue", 0.0) != 0.0 ||
                    o.bool("m_intValueIncrement", false) || o.bool("m_intValueDecrement", false)
                when {
                    o.bool("m_userPrompt", false) -> {
                        val angka = v.int("m_type") == 1 || v.int("m_type") == 3
                        InputPromptAction(
                            title = placeholder(o.str("m_userPromptTitle"), k).ifBlank { nama },
                            text = "", numeric = angka, saveTo = nama,
                        )
                    }
                    !v.bool("supportsInput", true) && nama in k.keluaran && !adaBaru -> null // hanya mendeklarasikan variabel keluaran dialog
                    else -> {
                        if (v.int("m_type") == 1 && o.bool("m_intValueIncrement", false)) return SetVariableAction(nama, "1", "add")
                        if (v.int("m_type") == 1 && o.bool("m_intValueDecrement", false)) return SetVariableAction(nama, "1", "subtract")
                        if (v.int("m_type") == 1 && o.bool("m_intExpression", false)) k.w("Variabel angka dengan ekspresi hitung dibaca sebagai angka biasa: $nama")
                        val teksBaru = o.str("m_newStringValue")
                        val kamus = Regex("^\\{lv=([A-Za-z0-9_]+)((?:\\[[^\\]]+\\])+)\\}$").find(teksBaru.trim())
                        if (kamus != null && kamus.groupValues[1] in k.kamus) {
                            // Isi kamus hasil Urai JSON: ambil langsung dari teks JSON dengan jalur kunci (indeks larik = angka).
                            val jalur = Regex("\\[([^\\]]+)\\]").findAll(kamus.groupValues[2]).joinToString(".") { it.groupValues[1].trim() }
                            return JsonPickAction(json = "{var:" + k.kamus.getValue(kamus.groupValues[1]) + "}", path = jalur, saveTo = nama)
                        }
                        val nilai = when (v.int("m_type")) {
                            2 -> placeholder(teksBaru.ifEmpty { v.str("m_stringValue") }, k)
                            1 -> (o.int("m_newIntValue").takeIf { it != 0 } ?: v.int("m_intValue")).toString()
                            3 -> (o.double("m_newDoubleValue", 0.0).takeIf { it != 0.0 } ?: v.double("m_decimalValue", 0.0)).toString()
                            0 -> if (o.bool("m_newBooleanValue", false) || v.bool("m_booleanValue", false)) "true" else "false"
                            else -> { k.w("Variabel bertipe kamus/larik tidak dibaca: $nama"); return null }
                        }
                        SetVariableAction(nama, nilai)
                    }
                }
            }
            "SendIntentAction" -> {
                when (o.str("m_target")) {
                    "Activity", "" -> IntentAction(
                        action = o.str("m_action"), asActivity = true,
                        pkg = o.str("m_packageName"), cls = o.str("m_className"),
                    )
                    "Broadcast" -> IntentAction(action = o.str("m_action"), asActivity = false, pkg = o.str("m_packageName"), cls = o.str("m_className"))
                    else -> { k.w("Intent ke layanan (service) tidak didukung"); NoteAction("Tidak diimpor dari MacroDroid: intent ke service") }
                }
            }
            "UIInteractionAction" -> {
                val cfg = o["uiInteractionConfiguration"] as? JsonObject
                if (cfg != null && cfg.str("type") == "Paste") {
                    if (cfg.bool("useClipboard", false)) k.w("Tempel dari papan klip tidak dibawa; dipakai teks tertulis")
                    return SetFocusedTextAction(placeholder(cfg.str("text"), k), appendText = !cfg.bool("forceClear", false))
                }
                if (cfg != null && cfg.str("type") == "Click" && cfg.int("clickOption") == 4 && cfg.str("viewId").isNotBlank()) {
                    if (cfg.bool("blocking", false)) k.w("Interaksi layar \"blocking\" tidak dibawa")
                    return ClickIdAction(viewId = cfg.str("viewId"), timeout = 5, longClick = cfg.bool("longClick", false))
                }
                val teks = cfg?.str("textContent").orEmpty()
                if (cfg != null && cfg.str("type") == "Click" && teks.isNotBlank()) {
                    if (cfg.bool("blocking", false)) k.w("Interaksi layar \"blocking\" tidak dibawa")
                    ClickTextAction(text = polos(placeholder(teks, k)), timeout = 5, longClick = cfg.bool("longClick", false))
                } else { k.w("Interaksi layar selain klik teks tidak didukung"); NoteAction("Tidak diimpor dari MacroDroid: interaksi layar") }
            }
            "OpenWebPageAction" -> OpenUrlAction(placeholder(o.str("m_urlToOpen"), k))
            "ToastAction" -> ToastAction(placeholder(o.str("m_messageText"), k))
            "WaitUntilTriggerAction" -> {
                val daftar = o.arr("triggersToWaitFor").map { it.jsonObject }
                val sc = daftar.singleOrNull()?.takeIf { it.str("m_classType") == "ScreenContentTrigger" && it.int("matchOption") == 0 && !it.bool("isOffScreen", false) }
                val teks = sc?.let { polos(it.str("textToMatch")) }.orEmpty()
                if (sc == null || teks.isBlank()) {
                    k.w("Tunggu pemicu hanya didukung untuk satu pemicu Isi layar (tulisan muncul)")
                    NoteAction("Tidak diimpor dari MacroDroid: tunggu pemicu")
                } else {
                    WaitScreenTextAction(
                        text = teks, pkg = daftarPaket(sc, "packageNameList").firstOrNull().orEmpty(),
                        timeout = if (o.bool("timeoutEnabled", false)) o.int("timeoutSeconds") else 0,
                        continueOnTimeout = o.bool("continueOnTimeout", false),
                    )
                }
            }
            "AccessibilityServiceAction" -> {
                val nama = o.arr("nameList").map { it.jsonPrimitive.content }
                if (nama.isNotEmpty() && nama.all { it.contains("MacroDroid", ignoreCase = true) }) {
                    k.w("Aksi layanan aksesibilitas MacroDroid diabaikan: MakroKu memakai layanan Aksesibilitasnya sendiri (pastikan aktif)")
                    null
                } else {
                    k.w("Layanan aksesibilitas aplikasi lain tidak didukung: " + nama.joinToString())
                    NoteAction("Tidak diimpor dari MacroDroid: layanan aksesibilitas " + nama.joinToString())
                }
            }
            "PlaySoundAction" -> {
                val nm = o.str("m_filePath")
                k.w("Suara " + (if (nm.isBlank()) "(tanpa nama)" else "\"" + nm + "\"") + " tidak bisa dibawa (berkas MacroDroid); dipakai nada notifikasi bawaan, pilih berkasnya di editor")
                PlaySoundAction("")
            }
            "SetScreenTimeoutAction" -> {
                val d = o.int("m_timeoutDelay")
                ScreenTimeoutAction(seconds = (if (d == -99) o.int("m_customValueDelay") else d).coerceAtLeast(1))
            }
            "WhatsAppAction" -> {
                if (o.bool("prepopulateOnly", false)) k.w("WhatsApp: \"hanya isi pesan\" tidak dibawa; pesan dikirim")
                WhatsAppAction(number = o.str("number"), text = placeholder(o.str("messageText"), k), business = o.bool("isBusiness", false))
            }
            "CancelActiveMacroAction" -> {
                val nm = o.str("m_macroName")
                if (nm == "[This Macro]" || nm == "[Macro ini]" || nm.isBlank()) {
                    k.w("Batalkan makro aktif: hanya menghentikan jalannya makro ini; putaran lain yang sedang berjalan tidak ikut dibatalkan")
                    StopMacroAction("Dibatalkan")
                } else { k.w("Batalkan makro aktif untuk makro lain tidak didukung: $nm"); NoteAction("Tidak diimpor dari MacroDroid: batalkan makro $nm") }
            }
            "LaunchHomeScreenAction" -> GlobalAction("home")
            "PressBackAction" -> GlobalAction("back")
            "ScreenOnAction" -> {
                if (o.bool("m_screenOff", false) || o.bool("m_screenOffNoLock", false)) { k.w("Layar mati tidak didukung pada aksi Layar hidup"); null }
                else ScreenOnAction()
            }
            "SilentModeVibrateOffAction" -> RingerModeAction("normal")
            "LogAction" -> LogAction(placeholder(o.str("m_logText"), k))
            "BreakFromLoopAction" -> BreakLoopAction
            "ClipboardAction" -> ClipboardAction(placeholder(o.str("m_clipboardText"), k))
            "MessageDialogAction" -> PopupAction(
                title = placeholder(o.str("m_notificationSubject"), k).ifBlank { k.namaMakro },
                text = placeholder(o.str("m_notificationText"), k),
            )
            "SystemSettingAction" -> {
                val kunci = o.str("settingString")
                if (kunci.isBlank()) { k.w("Aksi setelan sistem tanpa nama setelan dilewati"); null }
                else {
                    if (o.bool("useHelper", false)) k.w("Setelan sistem lewat aplikasi pembantu; dipakai cara MakroKu (izin langsung atau ADB)")
                    val tabel = o.int("tableOption")
                    if (tabel != 2) k.w("Tabel setelan: 0 dibaca system, 1 secure, 2 global; periksa di editor")
                    SystemSettingAction(
                        ns = when (tabel) { 0 -> "system"; 1 -> "secure"; else -> "global" },
                        key = kunci, value = placeholder(o.str("valueString"), k),
                    )
                }
            }
            "NotificationReplyAction" -> {
                if (o.str("matchText").isNotBlank()) k.w("Balas notifikasi: pencocokan teks tidak dibawa; membalas notifikasi terbaru aplikasinya")
                val dariPemicu = o.bool("useNotificationTrigger", true)
                val pk = if (dariPemicu) "" else (paket(o, "packageName").firstOrNull().orEmpty())
                ReplyNotificationAction(pkg = pk, text = placeholder(o.str("replyText"), k))
            }
            "LaunchActivityAction" -> {
                val pk = o.str("m_packageToLaunch")
                if (pk.isBlank()) { k.w("Buka aplikasi tanpa nama paket dilewati"); null } else LaunchAppAction(pk)
            }
            "LaunchAppActivityAction" -> {
                val pk = o.str("packageToLaunch")
                if (pk.isBlank()) { k.w("Buka layar aplikasi tanpa nama paket dilewati"); null }
                else IntentAction(action = "", asActivity = true, pkg = pk, cls = o.str("activityToLaunch"))
            }
            "ForceMacroRunAction" -> {
                val nm = o.str("m_macroName")
                if (o.bool("m_waitToComplete", false)) k.w("Jalankan makro: \"tunggu sampai selesai\" tidak dibawa")
                RunMacroAction(macro = if (nm == "[This Macro]" || nm.isBlank()) k.namaMakro else nm)
            }
            "WriteToFileAction" -> {
                if (o.str("m_pathName").isNotBlank()) k.w("Tulis ke berkas: folder tujuan tidak dibawa (dipakai folder MakroKu)")
                WriteFileAction(
                    fileName = placeholder(o.str("m_filename"), k).ifBlank { "catatan.txt" },
                    text = placeholder(o.str("m_logText"), k), append = o.bool("m_append", true),
                )
            }
            "TakeScreenshotAction" -> {
                k.w("Tangkapan layar: tujuan simpan/email MacroDroid tidak dibawa (dipakai setelan MakroKu)")
                ScreenshotAction()
            }
            "VibrateAction" -> {
                k.w("Pola getar MacroDroid diganti getar tetap 500 md")
                VibrateAction(500)
            }
            "SetVolumeAction" -> {
                val aktif = o.arr("m_streamIndexArray").map { it.jsonPrimitive.booleanOrNull == true }
                val nilai = o.arr("m_streamVolumeArray").map { it.jsonPrimitive.intOrNull ?: 0 }
                if (aktif.withIndex().any { it.value && it.index != 1 }) k.w("Atur volume: hanya aliran Media (urutan ke-2) yang dibawa; aliran lain dilewati")
                if (aktif.getOrNull(1) != true) { NoteAction("Tidak diimpor dari MacroDroid: atur volume selain Media") }
                else VolumeAction(stream = "music", percent = (nilai.getOrNull(1) ?: 0).coerceIn(0, 100))
            }
            "JsonParseAction" -> {
                val kamus = o.str("dictionaryVarName")
                val asal = o.str("stringVarName").trim().trim('{', '}', '[', ']').removePrefix("lv=").removePrefix("v=")
                if (kamus.isBlank() || asal.isBlank()) { k.w("Urai JSON tanpa nama variabel dilewati"); null }
                else { k.kamus[kamus] = asal; null } // tidak ada aksi: nilai diambil langsung dari JSON di variabel $asal
            }
            "HttpRequestAction" -> {
                val c2 = o["requestConfig"] as? JsonObject
                if (c2 == null) { k.w("Aksi HTTP tanpa konfigurasi dilewati"); return null }
                k.w("Jenis permintaan HTTP dibaca dari nomor (0 GET, 1 POST, 2 PUT, 3 DELETE); periksa di editor")
                val metode = when (c2.int("requestType")) {
                    0 -> "GET"; 1 -> "POST"; 2 -> "PUT"; 3 -> "DELETE"
                    else -> { k.w("Jenis permintaan HTTP ${c2.int("requestType")} tidak dikenal; dipakai GET"); "GET" }
                }
                val hdr = c2.arr("headerParams").map { it.jsonObject }.filter { it.str("paramName").isNotBlank() }
                val baris = hdr.map { it.str("paramName") + ": " + placeholder(it.str("paramValue"), k) }.toMutableList()
                val tipe = c2.str("contentType")
                if (tipe.isNotBlank() && metode != "GET" && baris.none { it.startsWith("Content-Type", ignoreCase = true) }) baris.add(0, "Content-Type: $tipe")
                val pengganti = Regex("(?i)hapus dulu|masukkan|isi (kunci|key)|your[ _-]?api[ _-]?key|paste")
                hdr.filter { pengganti.containsMatchIn(it.str("paramValue")) }.forEach {
                    k.w("Header ${it.str("paramName")} masih berisi tulisan pengganti; ganti dengan nilai asli (mis. kunci API) di aksi HTTP sebelum dipakai")
                }
                if (c2.int("contentBodySource") != 0) k.w("Isi permintaan HTTP dari berkas tidak dibawa; hanya isi teks")
                if (c2.bool("basicAuthEnabled", false)) k.w("Otentikasi dasar HTTP tidak dibawa; tambahkan header Authorization sendiri")
                if (c2.bool("clientCertEnabled", false) || c2.bool("allowAnyCertificate", false)) k.w("Sertifikat klien / terima semua sertifikat HTTP tidak dibawa")
                if (!c2.bool("blockNextAction", true)) k.w("HTTP: MakroKu selalu menunggu respons sebelum aksi berikutnya")
                HttpRequestAction(
                    url = placeholder(c2.str("urlToOpen"), k), method = metode,
                    body = if (metode == "GET") "" else placeholder(c2.str("contentBodyText"), k),
                    headers = baris.joinToString("\n"),
                    saveTo = c2.str("responseVariableName"),
                    timeout = c2.int("requestTimeOutSeconds").let { if (it <= 0) 15 else it },
                )
            }
            "ClearNotificationsAction" -> {
                val pk = paket(o)
                val pilihan = o.int("m_option")
                if (pilihan != 0 && pilihan != 1) k.w("Hapus notifikasi: opsi $pilihan tidak dikenal; dipakai seperti 1 (yang cocok)")
                k.w("Hapus notifikasi: opsi 0 dibaca \"semua\", 1 \"yang cocok teks\"; judul dicocokkan sebagai \"mengandung\"; periksa di editor")
                val judul = if (pilihan == 0) "" else placeholder(o.str("m_matchText"), k)
                if (judul.isNotBlank() && !o.bool("separateTitleAndMessage", false)) k.w("Hapus notifikasi: teks pencocok dicocokkan ke judul saja")
                ClearNotificationsAction(pkg = pk.joinToString(","), titleContains = judul)
            }
            "VoiceInputAction" -> VoiceInputAction(saveTo = o.str("variableName").ifBlank { "jawaban_suara" })
            else -> { k.w("Aksi tidak didukung dan dilewati: $c"); NoteAction("Tidak diimpor dari MacroDroid: $c") }
        }
    }

    // ── bantu ──
    private fun daftarPaket(o: JsonObject, kunci: String): List<String> =
        o.arr(kunci).map { it.jsonPrimitive.content }.filter { it.isNotBlank() }

    /** Nama paket dari kolom tunggal [kunci] (mis. "packageName"), atau dari nama aplikasi umum. */
    private fun paket(o: JsonObject, kunci: String): List<String> {
        val p = o.str(kunci)
        if (p.isNotBlank()) return listOf(p)
        return paketUmum[o.str("applicationName")]?.let { listOf(it) } ?: emptyList()
    }

    private fun paket(o: JsonObject): List<String> {
        val p = o.arr("m_packageNameList").map { it.jsonPrimitive.content }.filter { it.isNotBlank() }
        if (p.isNotEmpty()) return p
        return o.arr("m_applicationNameList").mapNotNull { paketUmum[it.jsonPrimitive.content] }
    }

    /** "*teks*" menjadi "teks" (pemicu MakroKu mencari yang mengandung teks). */
    private fun polos(s: String) = s.trim('*')

    private val reVar = Regex("[\\{\\[](?:lv|v)=([A-Za-z0-9_]+)[\\}\\]]")

    /** Penanda ajaib MacroDroid ke penanda MakroKu. */
    private fun placeholder(s: String, k: Konteks): String {
        val hasil = reVar.replace(s) {
            if (it.value[1] == 'v' && it.groupValues[1] !in k.global) k.w("Variabel sistem MacroDroid {v=${it.groupValues[1]}} dibaca sebagai variabel MakroKu bernama ${it.groupValues[1]} (isinya kosong bila belum diisi)")
            "{var:" + it.groupValues[1] + "}"
        }
            .replace("{macro_name}", k.namaMakro)
            .replace("{not_title}", "{notif_title}")
            .replace("{not_text_big}", "{notif_big}")
            .replace("{not_text}", "{notif_text}")
            .replace("{notification}", "{notif_full}")
            .replace("{not_package}", "{notif_pkg}")
            .replace("[battery]", "{battery}")
            .replace("[not_title]", "{notif_title}")
            .replace("[notification]", "{notif_full}")
            .replace("[not_text_big]", "{notif_big}")
            .replace("[not_text]", "{notif_text}")
            .replace("{iterator_value}", k.iterator ?: "{iterator_value}")
        if (Regex("[\\{\\[](?:lv|v)=[A-Za-z0-9_]+\\[").containsMatchIn(hasil)) k.w("Isi kamus (mis. {lv=nama[kunci]}) hanya didukung bila seluruh nilai variabel berisi satu rujukan kamus hasil Urai JSON")
        reSisa.findAll(hasil).forEach {
            val n = it.groupValues[1]
            if (!n.startsWith("var:") && n !in dikenal) k.w("Penanda MacroDroid {$n} tidak ada di MakroKu; ditulis apa adanya")
        }
        return hasil
    }

    /** Hanya ganti penanda variabel {lv=x}/{v=x}; dipakai untuk pola regex yang boleh memuat tanda kurung kurawal. */
    private fun gantiVar(s: String, k: Konteks): String = reVar.replace(s) {
        if (it.value[1] == 'v' && it.groupValues[1] !in k.global) k.w("Variabel sistem MacroDroid {v=${it.groupValues[1]}} dibaca sebagai variabel MakroKu bernama ${it.groupValues[1]} (isinya kosong bila belum diisi)")
        "{var:" + it.groupValues[1] + "}"
    }

    private val reSisa = Regex("\\{([A-Za-z0-9_:.]+)\\}")
    private val dikenal = setOf(
        "time", "date", "battery", "sms_sender", "sms_body", "notif_title", "notif_text", "notif_big", "notif_full", "notif_key", "notif_pkg", "call_number", "app_pkg",
    )

    private fun JsonObject.str(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull.orEmpty()
    private fun JsonObject.bool(k: String, d: Boolean) = (this[k] as? JsonPrimitive)?.booleanOrNull ?: d
    private fun JsonObject.long(k: String) = (this[k] as? JsonPrimitive)?.longOrNull ?: 0L
    private fun JsonObject.int(k: String) = (this[k] as? JsonPrimitive)?.intOrNull ?: 0
    private fun JsonObject.double(k: String, d: Double) = (this[k] as? JsonPrimitive)?.doubleOrNull ?: d
    private fun JsonObject.arr(k: String): JsonArray = (this[k] as? JsonArray) ?: JsonArray(emptyList())
}
