package com.novan.pembacauang

import android.app.Activity
import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.Camera
import android.view.Surface
import android.view.SurfaceHolder
import kotlin.math.abs
import kotlin.math.ceil

/**
 * Pembungkus Camera v1 (android.hardware.Camera), disusun mengikuti CameraSource
 * pada aplikasi acuan:
 *
 *  - kamera belakang, pratinjau diminta 1152x648 (0x480 x 0x288) pada 30 fps;
 *  - pasangan ukuran pratinjau/foto yang rasionya sama (toleransi 0,01);
 *    ukuran terpilih = selisih lebar+tinggi terkecil, +100000 bila bukan 16:9;
 *  - rentang fps = jumlah selisih batas bawah dan atas terhadap 30 fps yang terkecil;
 *  - format NV21, 4 buffer pratinjau;
 *  - fokus "continuous-picture" (bila tidak ada, "continuous-video"), area fokus dan
 *    area pengukuran cahaya di seluruh frame (-1000..1000, bobot 1000);
 *  - senter (torch) bila didukung;
 *  - frame yang datang saat OCR masih berjalan disimpan; hanya yang terbaru diproses
 *    setelah OCR sebelumnya selesai.
 */
@Suppress("DEPRECATION")
class CameraSource(
    private val activity: Activity,
    private val onFrame: (data: ByteArray, width: Int, height: Int, rotationDegrees: Int, release: () -> Unit) -> Unit,
) {
    private companion object {
        const val REQUESTED_WIDTH = 0x480 // 1152
        const val REQUESTED_HEIGHT = 0x288 // 648
        const val REQUESTED_FPS = 30f
        const val ASPECT_RATIO_TOLERANCE = 0.01f
        const val BUFFER_COUNT = 4
    }

    private class SizePair(val preview: Camera.Size, val picture: Camera.Size?)

    private val lock = Any()
    private var camera: Camera? = null
    var previewWidth = 0
        private set
    var previewHeight = 0
        private set
    private var rotationDegrees = 0

    // Penerusan frame: satu OCR berjalan, satu frame terbaru menunggu.
    private var busy = false
    private var pendingData: ByteArray? = null

    val isStarted: Boolean get() = synchronized(lock) { camera != null }

    /** Buka kamera dan mulai pratinjau di [holder]. Melempar Exception bila gagal. */
    fun start(holder: SurfaceHolder) {
        synchronized(lock) {
            if (camera != null) return
            val cam = createCamera()
            camera = cam
            try {
                cam.setPreviewDisplay(holder)
                cam.startPreview()
            } catch (e: Exception) {
                camera = null
                try {
                    cam.release()
                } catch (_: Exception) {
                }
                throw e
            }
        }
    }

    fun stop() {
        synchronized(lock) {
            val cam = camera ?: return
            camera = null
            busy = false
            pendingData = null
            try {
                cam.stopPreview()
                cam.setPreviewCallbackWithBuffer(null)
                cam.setPreviewTexture(null)
            } catch (_: Exception) {
            }
            try {
                cam.release()
            } catch (_: Exception) {
            }
        }
    }

    // ---- Membuka & mengatur kamera ----------------------------------------

    private fun createCamera(): Camera {
        val id = backCameraId()
        if (id == -1) throw RuntimeException("Could not find requested camera.")
        val cam = Camera.open(id)
        try {
            val pair = selectSizePair(cam, REQUESTED_WIDTH, REQUESTED_HEIGHT)
                ?: throw RuntimeException("Could not find suitable preview size.")
            previewWidth = pair.preview.width
            previewHeight = pair.preview.height
            val fps = selectPreviewFpsRange(cam, REQUESTED_FPS)
                ?: throw RuntimeException("Could not find suitable preview frames per second range.")

            val params = cam.parameters
            pair.picture?.let { params.setPictureSize(it.width, it.height) }
            params.setPreviewSize(previewWidth, previewHeight)
            params.setPreviewFpsRange(fps[0], fps[1])
            params.previewFormat = ImageFormat.NV21
            setRotation(cam, params, id)

            if (params.supportedFocusModes?.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) {
                params.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
            }
            val flashModes = params.supportedFlashModes
            if (flashModes != null && flashModes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                params.flashMode = Camera.Parameters.FLASH_MODE_TORCH
            }
            cam.parameters = params
            tuneCamera(cam)

            cam.setPreviewCallbackWithBuffer { data, c -> onPreviewFrame(data, c) }
            repeat(BUFFER_COUNT) { cam.addCallbackBuffer(createPreviewBuffer()) }
            return cam
        } catch (e: Exception) {
            try {
                cam.release()
            } catch (_: Exception) {
            }
            throw e
        }
    }

    /** Fokus kontinu + area fokus/pengukuran cahaya di seluruh frame. */
    private fun tuneCamera(cam: Camera) {
        try {
            val p = cam.parameters
            val modes = p.supportedFocusModes
            if (modes != null) {
                val mode = when {
                    modes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) ->
                        Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                    modes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO) ->
                        Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO
                    else -> null
                }
                if (mode != null) p.focusMode = mode
            }
            if (p.maxNumFocusAreas > 0) p.focusAreas = centerAreas()
            if (p.maxNumMeteringAreas > 0) p.meteringAreas = centerAreas()
            cam.parameters = p
        } catch (_: Exception) {
        }
    }

    private fun centerAreas(): List<Camera.Area> =
        listOf(Camera.Area(Rect(-1000, -1000, 1000, 1000), 1000))

    private fun createPreviewBuffer(): ByteArray {
        val bitsPerPixel = ImageFormat.getBitsPerPixel(ImageFormat.NV21)
        val sizeInBits = previewHeight.toLong() * previewWidth * bitsPerPixel
        return ByteArray(ceil(sizeInBits / 8.0).toInt() + 1)
    }

    /** Arah gambar: sama untuk tampilan dan untuk OCR (kamera belakang). */
    private fun setRotation(cam: Camera, params: Camera.Parameters, cameraId: Int) {
        val degrees = when (activity.windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_0 -> 0
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        val info = Camera.CameraInfo()
        Camera.getCameraInfo(cameraId, info)
        val angle: Int
        val displayAngle: Int
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            angle = (info.orientation + degrees) % 360
            displayAngle = (360 - angle) % 360
        } else {
            angle = (info.orientation - degrees + 360) % 360
            displayAngle = angle
        }
        rotationDegrees = (angle / 90) * 90
        cam.setDisplayOrientation(displayAngle)
        params.setRotation(angle)
    }

    // ---- Frame -> OCR ------------------------------------------------------

    private fun onPreviewFrame(data: ByteArray?, cam: Camera) {
        if (data == null) return
        var toProcess: ByteArray? = null
        synchronized(lock) {
            if (camera !== cam) return
            if (busy) {
                // Simpan hanya frame terbaru; buffer frame yang digantikan dikembalikan.
                pendingData?.let { returnBuffer(it, cam) }
                pendingData = data
            } else {
                busy = true
                toProcess = data
            }
        }
        toProcess?.let { dispatch(it, cam) }
    }

    private fun dispatch(data: ByteArray, cam: Camera) {
        onFrame(data, previewWidth, previewHeight, rotationDegrees) {
            var next: ByteArray? = null
            synchronized(lock) {
                returnBuffer(data, cam)
                if (camera !== cam) {
                    busy = false
                    return@synchronized
                }
                next = pendingData
                pendingData = null
                if (next == null) busy = false
            }
            next?.let { dispatch(it, cam) }
        }
    }

    private fun returnBuffer(data: ByteArray, cam: Camera) {
        try {
            if (camera === cam) cam.addCallbackBuffer(data)
        } catch (_: Exception) {
        }
    }

    // ---- Pemilihan pengaturan ---------------------------------------------

    private fun backCameraId(): Int {
        val info = Camera.CameraInfo()
        for (i in 0 until Camera.getNumberOfCameras()) {
            Camera.getCameraInfo(i, info)
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) return i
        }
        return -1
    }

    private fun generateValidPreviewSizeList(cam: Camera): List<SizePair> {
        val params = cam.parameters
        val previews = params.supportedPreviewSizes
        val pictures = params.supportedPictureSizes
        val valid = ArrayList<SizePair>()
        for (preview in previews) {
            val previewRatio = preview.width.toFloat() / preview.height
            for (picture in pictures) {
                val pictureRatio = picture.width.toFloat() / picture.height
                if (abs(previewRatio - pictureRatio) < ASPECT_RATIO_TOLERANCE) {
                    valid.add(SizePair(preview, picture))
                    break
                }
            }
        }
        if (valid.isEmpty()) {
            for (preview in previews) valid.add(SizePair(preview, null))
        }
        return valid
    }

    private fun selectSizePair(cam: Camera, desiredWidth: Int, desiredHeight: Int): SizePair? {
        var selected: SizePair? = null
        var minDiff = Int.MAX_VALUE
        for (pair in generateValidPreviewSizeList(cam)) {
            val size = pair.preview
            var diff = abs(size.width - desiredWidth) + abs(size.height - desiredHeight)
            if (size.width * 9 != size.height * 16) diff += 100_000
            if (diff < minDiff) {
                selected = pair
                minDiff = diff
            }
        }
        return selected
    }

    private fun selectPreviewFpsRange(cam: Camera, desiredFps: Float): IntArray? {
        val desired = (desiredFps * 1000f).toInt()
        var selected: IntArray? = null
        var minDiff = Int.MAX_VALUE
        for (range in cam.parameters.supportedPreviewFpsRange) {
            val deltaMin = desired - range[Camera.Parameters.PREVIEW_FPS_MIN_INDEX]
            val deltaMax = desired - range[Camera.Parameters.PREVIEW_FPS_MAX_INDEX]
            val diff = abs(deltaMin) + abs(deltaMax)
            if (diff < minDiff) {
                selected = range
                minDiff = diff
            }
        }
        return selected
    }
}
