package id.ytplayer.music

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import androidx.annotation.RequiresApi

/**
 * Mode bit-perfect Android 14 ke atas: mixer sistem dikunci ke format tertentu pada perangkat keluaran
 * (umumnya DAC USB) sehingga suara dikirim apa adanya, tanpa resampling, pencampuran, atau pengaturan
 * volume dari Android. Hanya dipakai bila perangkat keluaran memang mendukungnya.
 */
@RequiresApi(34)
object BitPerfect {
    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private var activeKey = ""
    private var activeDevice: AudioDeviceInfo? = null

    private fun audioManager(ctx: Context): AudioManager =
        ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun device(am: AudioManager): AudioDeviceInfo? = try {
        am.getAudioDevicesForAttributes(attrs).firstOrNull()
    } catch (_: Throwable) {
        null
    }

    /** Format bit-perfect yang disediakan perangkat: stereo, float 32-bit atau 16-bit. */
    private fun supported(am: AudioManager, dev: AudioDeviceInfo): List<AudioMixerAttributes> = try {
        am.getSupportedMixerAttributes(dev).filter { a ->
            val f = a.format
            a.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT &&
                f.channelMask == AudioFormat.CHANNEL_OUT_STEREO &&
                (f.encoding == AudioFormat.ENCODING_PCM_FLOAT || f.encoding == AudioFormat.ENCODING_PCM_16BIT)
        }
    } catch (_: Throwable) {
        emptyList()
    }

    /**
     * Mengunci mixer ke laju terkecil yang tidak kurang dari [target]. Mengembalikan laju dan apakah
     * keluarannya float, atau null bila perangkat tidak mendukung (pemutaran lanjut seperti biasa).
     */
    @Synchronized
    fun activate(ctx: Context, target: Int): Pair<Int, Boolean>? {
        try {
            val am = audioManager(ctx)
            val dev = device(am)
            if (dev == null) {
                clear(ctx)
                return null
            }
            val best = supported(am, dev)
                .filter { it.format.sampleRate >= target }
                .minWithOrNull(
                    compareBy<AudioMixerAttributes>(
                        { it.format.sampleRate },
                        { if (it.format.encoding == AudioFormat.ENCODING_PCM_FLOAT) 0 else 1 }
                    )
                )
            if (best == null) {
                clear(ctx)
                return null
            }
            val key = "${dev.id}/${best.format.sampleRate}/${best.format.encoding}"
            if (key != activeKey) {
                if (!am.setPreferredMixerAttributes(attrs, dev, best)) {
                    clear(ctx)
                    return null
                }
                activeKey = key
                activeDevice = dev
            }
            return Pair(best.format.sampleRate, best.format.encoding == AudioFormat.ENCODING_PCM_FLOAT)
        } catch (_: Throwable) {
            return null
        }
    }

    /** Mengembalikan mixer Android ke perilaku biasa. Aman dipanggil kapan saja. */
    @Synchronized
    fun clear(ctx: Context) {
        val dev = activeDevice ?: return
        try {
            audioManager(ctx).clearPreferredMixerAttributes(attrs, dev)
        } catch (_: Throwable) {
        }
        activeDevice = null
        activeKey = ""
    }

    /** Ringkasan untuk layar pengaturan. */
    fun info(ctx: Context): String {
        try {
            val am = audioManager(ctx)
            val dev = device(am) ?: return "Bit-perfect: perangkat keluaran tidak terdeteksi."
            val list = supported(am, dev)
            val name = dev.productName?.toString()?.ifBlank { null } ?: "perangkat keluaran"
            if (list.isEmpty()) {
                return "Bit-perfect: tidak tersedia pada $name. Biasanya hanya ada pada DAC USB."
            }
            val rates = list.map { it.format.sampleRate / 1000.0 }.distinct().sorted()
                .joinToString(", ") { r -> (if (r == Math.floor(r)) r.toInt().toString() else r.toString()) + " kHz" }
            return "Bit-perfect tersedia pada $name: $rates."
        } catch (_: Throwable) {
            return "Bit-perfect: gagal memeriksa perangkat."
        }
    }
}
