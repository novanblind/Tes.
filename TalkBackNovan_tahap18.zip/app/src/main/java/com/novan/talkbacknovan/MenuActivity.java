package com.novan.talkbacknovan;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/** Menu konteks untuk elemen yang sedang difokuskan. */
public class MenuActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTheme(android.R.style.Theme_DeviceDefault_Dialog);
        setTitle("Menu");
        final java.util.List<String> item = TalkBackNovanService.daftarMenu;
        if (item == null || item.isEmpty()) {
            finish();
            return;
        }
        ListView lv = new ListView(this);
        lv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, item));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                TalkBackNovanService.pilihMenu(pos);
                finish();
            }
        });
        setContentView(lv);
    }
}
