package org.telegram.messenger;

import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * Novan Tel - efek untuk pesan suara (gema dan pengubah suara).
 *
 * Telegram merekam suara 16-bit mono, lalu menyerahkan potongan-potongan PCM ke pengode Opus lewat
 * MediaController.writeFrame(...). Tambalan di tools/terapkan.py membuat tiga pembungkus di MediaController:
 *   startRecord -> NovanEfek.mulai(laju)      (memilih efek yang dicentang, menyiapkan rantai efek)
 *   writeFrame  -> NovanEfek.proses(buf, n)   (mengolah PCM di tempat sebelum diteruskan ke pengode)
 *   stopRecord  -> NovanEfek.akhiri(penulis)  (mengirim ekor gema supaya tidak terpotong mendadak)
 *
 * Bawaan semua efek mati: rantai kosong, PCM lewat tanpa diubah sama sekali.
 * Efek dikelompokkan dalam lima kategori (gema, pengubah suara, kejernihan, volume, bass). Tiap kategori hanya satu pilihan
 * (atau "mati"), disimpan di SharedPreferences "novan_mod" dengan kunci "efek_kat_<kategori>"; kategori yang berbeda boleh
 * dipakai bersamaan. Urutan olah: pengubah suara, kejernihan, bass, gema, volume.
 * Kunci lama "efek_<id>" (kotak centang tahap 10) tetap dibaca bila kunci baru belum ada.
 * Kelas ini murni Java (tanpa Android) supaya mudah diuji.
 */
public class NovanEfek {

    /** Penerima ekor efek: meneruskan potongan PCM ke pengode (MediaController.writeFrame). */
    public interface Penulis {
        void tulis(ByteBuffer b, int n);
    }

    /** {id, label untuk layar pengaturan}. Urutan = urutan di layar. */
    public static final String[][] GEMA = {
            {"gema_ringan", "Gema ringan: pantulan lembut, seperti di ruang tamu"},
            {"gema_sedang", "Gema sedang: suara terulang beberapa kali"},
            {"gema_panjang", "Gema panjang: pantulan lorong yang terulang lama"},
            {"gema_gunung", "Gema gunung: pantulan jauh dan redup"},
            {"gema_ruangan", "Ruangan kecil: bergaung tipis"},
            {"gema_kamar_mandi", "Kamar mandi: gaung cepat dan cerah"},
            {"gema_aula", "Aula besar: gaung lebar"},
            {"gema_katedral", "Katedral: gaung sangat panjang"},
            {"gema_gua", "Gua: gaung dalam ditambah pantulan"},
    };

    public static final String[][] UBAH = {
            {"ubah_anak", "Anak-anak: nada tinggi"},
            {"ubah_tupai", "Tupai: nada sangat tinggi dan lucu"},
            {"ubah_wanita", "Lebih tinggi: nada agak naik"},
            {"ubah_pria", "Lebih rendah: nada agak turun"},
            {"ubah_raksasa", "Raksasa: nada rendah dan berat"},
            {"ubah_monster", "Monster: nada sangat rendah, kasar"},
            {"ubah_robot", "Robot: suara logam bergetar"},
            {"ubah_alien", "Alien: nada naik dengan getaran cepat"},
            {"ubah_radio", "Radio atau telepon jadul: sempit dan tipis"},
            {"ubah_megafon", "Megafon: keras dan pecah"},
            {"ubah_bisik", "Berbisik: suara tanpa nada, seperti bisikan"},
            {"ubah_air", "Bawah air: teredam dan bergelombang"},
            {"ubah_getar", "Bergetar: suara naik turun dan bergetar"},
    };

    public static final String[][] JERNIH = {
            {"jernih_ringan", "Jernih ringan: suara sedikit lebih jelas"},
            {"jernih_sedang", "Jernih sedang: ucapan lebih tegas, dengung dikurangi"},
            {"jernih_kuat", "Jernih kuat: sangat jelas, cocok untuk suara pelan atau teredam"},
            {"jernih_siaran", "Suara siaran: bersih dari dengung, tegas dan rata seperti penyiar"},
    };

    public static final String[][] VOLUME = {
            {"volume_naik", "Volume naik sedikit: suara dikuatkan hingga sekitar 4 desibel"},
            {"volume_sedang", "Volume sedang: suara dikuatkan hingga sekitar 8 desibel"},
            {"volume_keras", "Volume keras: suara dikuatkan hingga sekitar 12 desibel"},
            {"volume_maks", "Volume maksimal: dikuatkan hingga sekitar 16 desibel, suara pelan ikut terdengar"},
    };

    public static final String[][] BASS = {
            {"bass_ringan", "Bass ringan: suara sedikit lebih hangat"},
            {"bass_sedang", "Bass sedang: suara lebih tebal"},
            {"bass_kuat", "Bass kuat: suara berat, terdengar di speaker kecil"},
            {"bass_dalam", "Bass dalam: sangat berat dan dalam"},
    };

    /** Urutan kategori di layar: id, judul, daftar pilihan. */
    public static final String[] KAT_ID = {"gema", "ubah", "jernih", "volume", "bass"};
    public static final String[] KAT_JUDUL = {"Gema", "Pengubah suara", "Kejernihan suara", "Volume suara", "Bass suara"};
    public static final String[][][] KAT = {GEMA, UBAH, JERNIH, VOLUME, BASS};

    /** Batas panjang ekor gema (detik) supaya berkas tidak membengkak. */
    private static final double EKOR_MAKS = 3.2;

    private interface Blok {
        float p(float x);

        /** Jumlah sampel tambahan yang perlu dialirkan setelah masukan berhenti agar ekor efek keluar. */
        int ekor();
    }

    // ------------------------------------------------------------ keadaan sesi rekaman
    private static Blok[] rantai = null;
    private static int laju = 0;
    private static int maksLen = 0;

    // penghitung untuk layar Pengaturan (membuktikan kait di perekam Telegram benar-benar dipanggil)
    private static int hitungMulai = 0;
    private static long frameMasuk = 0;
    private static long frameOlah = 0;
    private static String efekTerakhir = "";
    // dua jalur kait: pembungkus Java di MediaController, dan panggilan balik dari kode C (audio.c). Keduanya dijaga agar
    // satu potongan suara tidak diolah dua kali.
    private static boolean javaOlah = false;
    private static boolean mulaiJava = false;
    private static boolean perluMulai = true;
    private static String jalur = "";

    /** Id pilihan yang dipakai pada kategori ini: salah satu id di KAT, atau "mati". */
    public static String terpilih(String kategori) {
        String[][] opsi = null;
        for (int i = 0; i < KAT_ID.length; i++) {
            if (KAT_ID[i].equals(kategori)) {
                opsi = KAT[i];
            }
        }
        if (opsi == null) {
            return "mati";
        }
        String v = NovanMod.teksPref("efek_kat_" + kategori);
        if (v != null) {
            for (String[] o : opsi) {
                if (o[0].equals(v)) {
                    return v;
                }
            }
            return "mati";
        }
        for (String[] o : opsi) {
            if (NovanMod.efekDipilih(o[0])) {
                return o[0];
            }
        }
        return "mati";
    }

    /** Label singkat pilihan (untuk tampilan), "Mati" bila tidak ada. */
    public static String labelPilihan(String kategori) {
        String id = terpilih(kategori);
        for (int i = 0; i < KAT_ID.length; i++) {
            if (KAT_ID[i].equals(kategori)) {
                for (String[] o : KAT[i]) {
                    if (o[0].equals(id)) {
                        int k = o[1].indexOf(':');
                        return k > 0 ? o[1].substring(0, k) : o[1];
                    }
                }
            }
        }
        return "Mati";
    }

    /** Susun rantai efek dari pilihan pengguna saat ini (kosong bila tidak ada yang dipilih). */
    private static Blok[] bangunRantai(int rate) {
        ArrayList<Blok> daftar = new ArrayList<Blok>();
        if (rate < 8000 || rate > 96000) {
            return new Blok[0];
        }
        String[] urutan = {"ubah", "jernih", "bass", "gema", "volume"};
        for (String kat : urutan) {
            String id = terpilih(kat);
            if ("mati".equals(id)) {
                continue;
            }
            Blok b = null;
            try {
                switch (kat) {
                    case "ubah":
                        b = buatUbah(id, rate);
                        break;
                    case "jernih":
                        b = buatJernih(id, rate);
                        break;
                    case "bass":
                        b = buatBass(id, rate);
                        break;
                    case "gema":
                        b = buatGema(id, rate);
                        break;
                    default:
                        b = buatVolume(id, rate);
                        break;
                }
            } catch (Throwable t) {
                b = null;
            }
            if (b != null) {
                daftar.add(b);
            }
        }
        return daftar.toArray(new Blok[0]);
    }

    /** Dipanggil saat rekaman dimulai (sebelum startRecord asli). */
    public static synchronized void mulai(int rate) {
        mulaiJava = true;
        jalur = "Java";
        rantai = null;
        maksLen = 0;
        laju = rate;
        hitungMulai++;
        frameMasuk = 0;
        frameOlah = 0;
        efekTerakhir = "";
        if (!NovanMod.EFEK_SUARA) {
            return;
        }
        Blok[] r = bangunRantai(rate);
        StringBuilder nama = new StringBuilder();
        for (String kat : KAT_ID) {
            String id = terpilih(kat);
            if (!"mati".equals(id)) {
                if (nama.length() > 0) {
                    nama.append(", ");
                }
                nama.append(labelPilihan(kat));
            }
        }
        efekTerakhir = nama.toString();
        if (r.length > 0) {
            rantai = r;
        }
    }

    /** Ada efek yang aktif pada rekaman ini? */
    public static synchronized boolean aktif() {
        return rantai != null;
    }

    /** Ringkasan untuk layar Pengaturan: apakah kait perekam Telegram bekerja pada rekaman terakhir. */
    public static synchronized String status() {
        if (!NovanMod.EFEK_SUARA) {
            return "Efek tidak terpasang pada build ini karena kode Telegram tidak cocok. Kirim log build bagian DIAGNOSA efek suara.";
        }
        if (hitungMulai == 0) {
            return "Belum ada rekaman pesan suara sejak aplikasi dibuka. Rekam satu pesan suara, lalu buka layar ini lagi untuk melihat status.";
        }
        String efek = efekTerakhir.length() == 0 ? "tidak ada efek dipilih" : efekTerakhir;
        String hasil = "Rekaman terakhir (" + laju + " Hz, kait " + jalur + "): " + efek + ". Potongan suara lewat kait: " + frameMasuk
                + ", diolah efek: " + frameOlah + ".";
        if (frameMasuk == 0) {
            hasil += " Perekam belum mengirim suara lewat kait efek; kirim log build bagian DIAGNOSA efek suara.";
        } else if (efekTerakhir.length() > 0 && frameOlah == 0) {
            hasil += " Efek dipilih tetapi tidak sempat diolah.";
        } else if (frameOlah > 0) {
            hasil += " Efek bekerja.";
        }
        return hasil;
    }

    /** Olah PCM 16-bit mono little-endian di tempat: byte 0 sampai len-1 dari buffer (posisi dan limit tidak diubah). */
    public static synchronized void proses(ByteBuffer b, int len) {
        if (b == null || len < 2) {
            return;
        }
        javaOlah = true;
        olahBuffer(b, len);
    }

    /** Dipanggil dari kode C (audio.c) tepat sebelum potongan suara dikodekan Opus. */
    public static synchronized void prosesNative(ByteBuffer b, int len, int rate) {
        try {
            if (javaOlah) {
                javaOlah = false;
                return;
            }
            if (b == null || len < 2) {
                return;
            }
            if (perluMulai) {
                perluMulai = false;
                jalur = "C";
                mulaiDasar(rate >= 8000 && rate <= 96000 ? rate : 16000);
            }
            olahBuffer(b, len);
        } catch (Throwable t) {
            // jangan sampai suara gagal terkirim karena efek
        }
    }

    /** Dipanggil dari kode C saat rekaman baru dimulai. */
    public static synchronized void mulaiNative() {
        if (mulaiJava) {
            mulaiJava = false;
            return;
        }
        perluMulai = true;
    }

    private static void mulaiDasar(int rate) {
        rantai = null;
        maksLen = 0;
        laju = rate;
        hitungMulai++;
        frameMasuk = 0;
        frameOlah = 0;
        efekTerakhir = "";
        if (!NovanMod.EFEK_SUARA) {
            return;
        }
        Blok[] r = bangunRantai(rate);
        StringBuilder nama = new StringBuilder();
        for (String kat : KAT_ID) {
            if (!"mati".equals(terpilih(kat))) {
                if (nama.length() > 0) {
                    nama.append(", ");
                }
                nama.append(labelPilihan(kat));
            }
        }
        efekTerakhir = nama.toString();
        if (r.length > 0) {
            rantai = r;
        }
    }

    private static void olahBuffer(ByteBuffer b, int len) {
        frameMasuk++;
        if (rantai == null) {
            return;
        }
        if (len > b.capacity()) {
            len = b.capacity();
        }
        if (len > maksLen) {
            maksLen = len;
        }
        frameOlah++;
        final Blok[] r = rantai;
        final int n = len / 2;
        for (int i = 0; i < n; i++) {
            int lo = b.get(2 * i) & 0xff;
            int hi = b.get(2 * i + 1);
            float x = ((short) ((hi << 8) | lo)) / 32768f;
            x = olahSampel(r, x);
            int v = Math.round(x * 32767f);
            if (v > 32767) {
                v = 32767;
            } else if (v < -32768) {
                v = -32768;
            }
            b.put(2 * i, (byte) (v & 0xff));
            b.put(2 * i + 1, (byte) ((v >> 8) & 0xff));
        }
    }

    private static float olahSampel(Blok[] r, float x) {
        for (int k = 0; k < r.length; k++) {
            x = r[k].p(x);
        }
        return batas(x);
    }

    /**
     * Uji di layar Pengaturan: olah rekaman pendek (PCM 16-bit mono) dengan pilihan efek saat ini, lengkap dengan ekornya.
     * Tidak menyentuh keadaan rekaman pesan suara. Bila tidak ada efek dipilih, mengembalikan masukan apa adanya.
     */
    public static short[] uji(short[] masuk, int rate) {
        Blok[] r = bangunRantai(rate);
        if (r.length == 0 || masuk == null) {
            return masuk;
        }
        long ekor = 0;
        for (Blok k : r) {
            ekor += k.ekor();
        }
        ekor = Math.min(ekor, (long) (EKOR_MAKS * rate));
        short[] keluar = new short[(int) (masuk.length + ekor)];
        for (int i = 0; i < keluar.length; i++) {
            float x = i < masuk.length ? masuk[i] / 32768f : 0f;
            x = olahSampel(r, x);
            int v = Math.round(x * 32767f);
            keluar[i] = (short) Math.max(-32768, Math.min(32767, v));
        }
        return keluar;
    }

    /** Dipanggil sebelum stopRecord asli: alirkan keheningan lewat rantai agar ekor gema ikut terekam. */
    public static synchronized void akhiri(Penulis w) {
        if (rantai == null || w == null || maksLen < 2) {
            return;
        }
        long ekor = 0;
        for (Blok k : rantai) {
            ekor += k.ekor();
        }
        long maks = (long) (EKOR_MAKS * laju);
        if (ekor > maks) {
            ekor = maks;
        }
        long sisaByte = ekor * 2;
        ByteBuffer t = ByteBuffer.allocateDirect(maksLen);
        while (sisaByte > 0) {
            for (int i = 0; i < maksLen; i++) {
                t.put(i, (byte) 0);
            }
            proses(t, maksLen);
            w.tulis(t, maksLen);
            sisaByte -= maksLen;
        }
    }

    /** Pembatas lembut: sinyal di atas 0,8 ditekuk pelan menuju 1,0 (tidak pecah). */
    private static float batas(float x) {
        float a = Math.abs(x);
        if (a <= 0.8f) {
            return x;
        }
        float y = 0.8f + 0.2f * (float) Math.tanh((a - 0.8f) / 0.2f);
        return x < 0 ? -y : y;
    }

    // ------------------------------------------------------------ pabrik efek
    private static double rasio(double nadaSetengah) {
        return Math.pow(2.0, nadaSetengah / 12.0);
    }

    private static Blok buatUbah(String id, int fs) {
        switch (id) {
            case "ubah_anak":
                return new Nada(fs, rasio(6));
            case "ubah_tupai":
                return new Nada(fs, rasio(10));
            case "ubah_wanita":
                return new Nada(fs, rasio(3.5));
            case "ubah_pria":
                return new Nada(fs, rasio(-3));
            case "ubah_raksasa":
                return new Nada(fs, rasio(-6));
            case "ubah_monster":
                return new Seri(new Nada(fs, rasio(-10)), new Distorsi(2.5f, 0.55f), new Biquad(Biquad.LP, fs, 4200, 0.7));
            case "ubah_robot":
                return new Seri(new Cincin(fs, 60, 1.0f, 1.5f), new Sisir(fs, 6.0, 0.6f));
            case "ubah_alien":
                return new Seri(new Nada(fs, rasio(3)), new Getar(fs, 9.0, 1.3), new Cincin(fs, 170, 0.3f, 1.0f));
            case "ubah_radio":
                return new Seri(new Biquad(Biquad.HP, fs, 450, 0.7), new Biquad(Biquad.LP, fs, 3200, 0.7), new Distorsi(1.6f, 0.9f));
            case "ubah_megafon":
                return new Seri(new Biquad(Biquad.HP, fs, 600, 0.8), new Biquad(Biquad.LP, fs, 3800, 0.8), new Distorsi(4.0f, 0.6f));
            case "ubah_bisik":
                return new Bisik(fs);
            case "ubah_air":
                return new Seri(new Biquad(Biquad.LP, fs, 800, 0.9), new Getar(fs, 1.3, 2.0));
            case "ubah_getar":
                return new Seri(new Getar(fs, 5.5, 1.2), new Gemetar(fs, 6.0, 0.4f));
            default:
                return null;
        }
    }

    private static Blok buatJernih(String id, int fs) {
        switch (id) {
            case "jernih_ringan":
                return new Seri(new Biquad(Biquad.HP, fs, 70, 0.7), new Biquad(Biquad.PK, fs, 300, 1.0, -1.5),
                        new Biquad(Biquad.PK, fs, 3000, 0.9, 3.0), new Biquad(Biquad.HS, fs, 5000, 0.7, 1.5));
            case "jernih_sedang":
                return new Seri(new Biquad(Biquad.HP, fs, 90, 0.7), new Biquad(Biquad.PK, fs, 300, 1.0, -2.5),
                        new Biquad(Biquad.PK, fs, 3000, 0.9, 5.0), new Biquad(Biquad.HS, fs, 5000, 0.7, 3.0));
            case "jernih_kuat":
                return new Seri(new Biquad(Biquad.HP, fs, 100, 0.7), new Biquad(Biquad.PK, fs, 300, 1.0, -3.5),
                        new Biquad(Biquad.PK, fs, 2800, 0.9, 7.0), new Biquad(Biquad.HS, fs, 4800, 0.7, 4.5));
            case "jernih_siaran":
                return new Seri(new Biquad(Biquad.HP, fs, 100, 0.7), new Biquad(Biquad.PK, fs, 280, 1.0, -4.0),
                        new Biquad(Biquad.PK, fs, 3000, 0.9, 6.0), new Biquad(Biquad.HS, fs, 5000, 0.7, 3.0),
                        new Kompresor(fs, -24, 2.5f, 3f));
            default:
                return null;
        }
    }

    private static Blok buatVolume(String id, int fs) {
        switch (id) {
            case "volume_naik":
                return new Kompresor(fs, -22, 2.0f, 4f);
            case "volume_sedang":
                return new Kompresor(fs, -22, 2.5f, 8f);
            case "volume_keras":
                return new Kompresor(fs, -24, 3.0f, 12f);
            case "volume_maks":
                return new Kompresor(fs, -26, 4.0f, 16f);
            default:
                return null;
        }
    }

    private static Blok buatBass(String id, int fs) {
        switch (id) {
            case "bass_ringan":
                return new Biquad(Biquad.LS, fs, 150, 0.7, 4.0);
            case "bass_sedang":
                return new Biquad(Biquad.LS, fs, 150, 0.7, 7.0);
            case "bass_kuat":
                return new Seri(new Biquad(Biquad.LS, fs, 140, 0.7, 9.0), new Eksiter(fs, 0.20f));
            case "bass_dalam":
                return new Seri(new Biquad(Biquad.LS, fs, 120, 0.7, 12.0), new Eksiter(fs, 0.30f));
            default:
                return null;
        }
    }

    private static Blok buatGema(String id, int fs) {
        switch (id) {
            case "gema_ringan":
                return new Pantul(fs, 180, 0.30f, 0.35f, 0.5f);
            case "gema_sedang":
                return new Pantul(fs, 300, 0.45f, 0.45f, 0.5f);
            case "gema_panjang":
                return new Pantul(fs, 480, 0.60f, 0.50f, 0.5f);
            case "gema_gunung":
                return new Pantul(fs, 900, 0.45f, 0.55f, 0.3f);
            case "gema_ruangan":
                return new Gaung(fs, new double[]{23.1, 27.7, 31.3, 35.9, 39.7, 43.1}, 0.45, 0.35f, 0.45f, 0);
            case "gema_kamar_mandi":
                return new Gaung(fs, new double[]{13.7, 17.3, 21.1, 24.7, 28.3, 31.9}, 1.3, 0.10f, 0.40f, 0);
            case "gema_aula":
                return new Gaung(fs, new double[]{41.3, 47.9, 53.1, 61.7, 67.3, 73.9}, 2.2, 0.30f, 0.50f, 15);
            case "gema_katedral":
                return new Gaung(fs, new double[]{59.9, 71.3, 83.9, 97.1, 109.7, 123.1}, 4.5, 0.40f, 0.35f, 35);
            case "gema_gua":
                return new Seri(new Gaung(fs, new double[]{79.3, 91.9, 107.3, 121.7, 137.9, 151.3}, 3.0, 0.60f, 0.45f, 20),
                        new Pantul(fs, 420, 0.35f, 0.30f, 0.4f));
            default:
                return null;
        }
    }

    // ------------------------------------------------------------ blok dasar
    /** Rangkaian blok berurutan. */
    private static class Seri implements Blok {
        private final Blok[] b;

        Seri(Blok... b) {
            this.b = b;
        }

        public float p(float x) {
            for (int i = 0; i < b.length; i++) {
                x = b[i].p(x);
            }
            return x;
        }

        public int ekor() {
            long t = 0;
            for (Blok k : b) {
                t += k.ekor();
            }
            return (int) Math.min(t, Integer.MAX_VALUE);
        }
    }

    /** Tapis biquad (resep RBJ): lolos rendah/tinggi/pita, rak rendah/tinggi, dan puncak (dengan penguatan desibel). */
    private static class Biquad implements Blok {
        static final int LP = 0, HP = 1, BP = 2, LS = 3, HS = 4, PK = 5;
        private final double b0, b1, b2, a1, a2;
        private double z1 = 0, z2 = 0;
        private final int fs;

        Biquad(int jenis, int fs, double f, double q) {
            this(jenis, fs, f, q, 0.0);
        }

        Biquad(int jenis, int fs, double f, double q, double dB) {
            this.fs = fs;
            if (f > fs * 0.45) {
                f = fs * 0.45;
            }
            double w0 = 2 * Math.PI * f / fs;
            double c = Math.cos(w0);
            double al = Math.sin(w0) / (2 * q);
            double x0, x1, x2, y0, y1, y2;
            if (jenis == LP) {
                x0 = (1 - c) / 2;
                x1 = 1 - c;
                x2 = x0;
                y0 = 1 + al;
                y1 = -2 * c;
                y2 = 1 - al;
            } else if (jenis == HP) {
                x0 = (1 + c) / 2;
                x1 = -(1 + c);
                x2 = x0;
                y0 = 1 + al;
                y1 = -2 * c;
                y2 = 1 - al;
            } else if (jenis == BP) {
                x0 = al;
                x1 = 0;
                x2 = -al;
                y0 = 1 + al;
                y1 = -2 * c;
                y2 = 1 - al;
            } else if (jenis == PK) {
                double A = Math.pow(10.0, dB / 40.0);
                x0 = 1 + al * A;
                x1 = -2 * c;
                x2 = 1 - al * A;
                y0 = 1 + al / A;
                y1 = -2 * c;
                y2 = 1 - al / A;
            } else {
                double A = Math.pow(10.0, dB / 40.0);
                double r = 2 * Math.sqrt(A) * al;
                if (jenis == LS) {
                    x0 = A * ((A + 1) - (A - 1) * c + r);
                    x1 = 2 * A * ((A - 1) - (A + 1) * c);
                    x2 = A * ((A + 1) - (A - 1) * c - r);
                    y0 = (A + 1) + (A - 1) * c + r;
                    y1 = -2 * ((A - 1) + (A + 1) * c);
                    y2 = (A + 1) + (A - 1) * c - r;
                } else {
                    x0 = A * ((A + 1) + (A - 1) * c + r);
                    x1 = -2 * A * ((A - 1) + (A + 1) * c);
                    x2 = A * ((A + 1) + (A - 1) * c - r);
                    y0 = (A + 1) - (A - 1) * c + r;
                    y1 = 2 * ((A - 1) - (A + 1) * c);
                    y2 = (A + 1) - (A - 1) * c - r;
                }
            }
            b0 = x0 / y0;
            b1 = x1 / y0;
            b2 = x2 / y0;
            a1 = y1 / y0;
            a2 = y2 / y0;
        }

        public float p(float x) {
            double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return (float) y;
        }

        public int ekor() {
            return fs / 50;
        }
    }

    /** Pemampat suara: suara keras ditekan, lalu semuanya dikuatkan (makeup), jadi yang pelan ikut terdengar. */
    private static class Kompresor implements Blok {
        private final float aNaik, aTurun, ambangDb, rasio, makeupDb;
        private float env = 0f;

        Kompresor(int fs, double ambangDb, float rasio, float makeupDb) {
            this.ambangDb = (float) ambangDb;
            this.rasio = rasio;
            this.makeupDb = makeupDb;
            aNaik = (float) (1 - Math.exp(-1.0 / (0.005 * fs)));
            aTurun = (float) (1 - Math.exp(-1.0 / (0.150 * fs)));
        }

        public float p(float x) {
            float a = Math.abs(x);
            env += (a > env ? aNaik : aTurun) * (a - env);
            float gdb = makeupDb;
            if (env > 1e-5f) {
                float e = (float) (8.685889638 * Math.log(env));
                if (e > ambangDb) {
                    gdb += (ambangDb + (e - ambangDb) / rasio) - e;
                }
            }
            return x * (float) Math.exp(gdb * 0.115129255);
        }

        public int ekor() {
            return 0;
        }
    }

    /** Penambah harmonik bass: bagian bass dipanaskan (tanh) lalu dicampur, supaya bass terdengar di speaker kecil. */
    private static class Eksiter implements Blok {
        private final Biquad rendah, halus;
        private final float campur;

        Eksiter(int fs, float campur) {
            rendah = new Biquad(Biquad.LP, fs, 180, 0.7);
            halus = new Biquad(Biquad.LP, fs, 420, 0.7);
            this.campur = campur;
        }

        public float p(float x) {
            float h = halus.p((float) Math.tanh(3.0 * rendah.p(x)) * 0.5f);
            return x + campur * h;
        }

        public int ekor() {
            return rendah.ekor() * 2;
        }
    }

    /** Pengubah nada dengan durasi tetap: dua titik baca berjalan pada saluran tunda, dipadu silang. */
    private static class Nada implements Blok {
        private final int jendela;
        private final float[] buf;
        private int w = 0;
        private double fase = 0;
        private final double langkah;

        Nada(int fs, double rasio) {
            jendela = Math.max(64, (int) (fs * 0.035));
            buf = new float[2 * jendela + 8];
            langkah = (1.0 - rasio) / jendela;
        }

        private float ambil(double tunda) {
            double pos = w - tunda;
            while (pos < 0) {
                pos += buf.length;
            }
            int i = (int) pos;
            float f = (float) (pos - i);
            int j = i + 1;
            if (j >= buf.length) {
                j = 0;
            }
            if (i >= buf.length) {
                i = 0;
            }
            return buf[i] * (1 - f) + buf[j] * f;
        }

        public float p(float x) {
            buf[w] = x;
            double fa = fase;
            double fb = fa + 0.5;
            if (fb >= 1.0) {
                fb -= 1.0;
            }
            float ya = ambil(fa * jendela);
            float yb = ambil(fb * jendela);
            double ga = 0.5 - 0.5 * Math.cos(2 * Math.PI * fa);
            double gb = 0.5 - 0.5 * Math.cos(2 * Math.PI * fb);
            fase += langkah;
            if (fase >= 1.0) {
                fase -= 1.0;
            } else if (fase < 0) {
                fase += 1.0;
            }
            w++;
            if (w >= buf.length) {
                w = 0;
            }
            return (float) (ga * ya + gb * yb);
        }

        public int ekor() {
            return jendela;
        }
    }

    /** Vibrato: waktu tunda bergoyang pelan (hz), kedalaman dalam milidetik. */
    private static class Getar implements Blok {
        private final float[] buf;
        private int w = 0;
        private double fase = 0;
        private final double dFase;
        private final double tengah, dalam;

        Getar(int fs, double hz, double msDalam) {
            dalam = msDalam * fs / 1000.0;
            tengah = dalam + 2;
            buf = new float[(int) (2 * dalam) + 8];
            dFase = 2 * Math.PI * hz / fs;
        }

        public float p(float x) {
            buf[w] = x;
            double tunda = tengah + dalam * Math.sin(fase);
            fase += dFase;
            if (fase > 2 * Math.PI) {
                fase -= 2 * Math.PI;
            }
            double pos = w - tunda;
            while (pos < 0) {
                pos += buf.length;
            }
            int i = (int) pos;
            float f = (float) (pos - i);
            int j = i + 1;
            if (j >= buf.length) {
                j = 0;
            }
            if (i >= buf.length) {
                i = 0;
            }
            float y = buf[i] * (1 - f) + buf[j] * f;
            w++;
            if (w >= buf.length) {
                w = 0;
            }
            return y;
        }

        public int ekor() {
            return buf.length;
        }
    }

    /** Modulator cincin: kalikan dengan gelombang sinus (campuran 0..1). */
    private static class Cincin implements Blok {
        private double fase = 0;
        private final double dFase;
        private final float campur, penguat;

        Cincin(int fs, double hz, float campur, float penguat) {
            dFase = 2 * Math.PI * hz / fs;
            this.campur = campur;
            this.penguat = penguat;
        }

        public float p(float x) {
            float m = (float) Math.sin(fase);
            fase += dFase;
            if (fase > 2 * Math.PI) {
                fase -= 2 * Math.PI;
            }
            return (x * (1 - campur) + x * m * campur) * penguat;
        }

        public int ekor() {
            return 0;
        }
    }

    /** Tremolo: volume naik turun. */
    private static class Gemetar implements Blok {
        private double fase = 0;
        private final double dFase;
        private final float dalam;

        Gemetar(int fs, double hz, float dalam) {
            dFase = 2 * Math.PI * hz / fs;
            this.dalam = dalam;
        }

        public float p(float x) {
            float m = 1 - dalam + dalam * (0.5f + 0.5f * (float) Math.sin(fase));
            fase += dFase;
            if (fase > 2 * Math.PI) {
                fase -= 2 * Math.PI;
            }
            return x * m;
        }

        public int ekor() {
            return 0;
        }
    }

    /** Sisir maju: y = x + g * x[n - D]; memberi kesan logam. */
    private static class Sisir implements Blok {
        private final float[] buf;
        private int w = 0;
        private final float g;

        Sisir(int fs, double ms, float g) {
            buf = new float[Math.max(2, (int) (fs * ms / 1000.0))];
            this.g = g;
        }

        public float p(float x) {
            float d = buf[w];
            buf[w] = x;
            w++;
            if (w >= buf.length) {
                w = 0;
            }
            return (x + g * d) / (1 + g * 0.5f);
        }

        public int ekor() {
            return buf.length;
        }
    }

    /** Distorsi lembut (tanh), dinormalkan agar tingkat suara kira-kira sama. */
    private static class Distorsi implements Blok {
        private final float drive, norm;

        Distorsi(float drive, float keluar) {
            this.drive = drive;
            this.norm = keluar / (float) Math.tanh(drive);
        }

        public float p(float x) {
            return (float) Math.tanh(drive * x) * norm;
        }

        public int ekor() {
            return 0;
        }
    }

    /** Bisikan: pengode suara (vocoder) berpita; amplop tiap pita dipakai memodulasi derau pada pita yang sama. */
    private static class Bisik implements Blok {
        private final Biquad[] analisis, pembawa;
        private final float[] amplop, skala;
        private final float aEnv;
        private int benih = 12345;

        Bisik(int fs) {
            double[] tepi = {200, 400, 600, 800, 1000, 1300, 1700, 2200, 2900, 3800, 5000, 6500};
            int n = 0;
            for (int i = 0; i + 1 < tepi.length; i++) {
                if (tepi[i + 1] < fs * 0.45) {
                    n++;
                }
            }
            analisis = new Biquad[n];
            pembawa = new Biquad[n];
            amplop = new float[n];
            skala = new float[n];
            for (int i = 0; i < n; i++) {
                double fc = Math.sqrt(tepi[i] * tepi[i + 1]);
                double bw = tepi[i + 1] - tepi[i];
                double q = fc / bw;
                analisis[i] = new Biquad(Biquad.BP, fs, fc, q);
                pembawa[i] = new Biquad(Biquad.BP, fs, fc, q);
                // samakan tenaga: derau putih seragam [-1,1] punya RMS 0,577; amplop rata-rata |x| ~ 0,64 RMS
                skala[i] = (float) (1.57 / (0.577 * Math.sqrt(2 * bw / fs)));
            }
            aEnv = (float) (1 - Math.exp(-2 * Math.PI * 50.0 / fs));
        }

        public float p(float x) {
            benih = benih * 1664525 + 1013904223;
            float derau = ((benih >> 8) & 0xffff) / 32768f - 1f;
            float hasil = 0;
            for (int i = 0; i < analisis.length; i++) {
                float a = Math.abs(analisis[i].p(x));
                amplop[i] += aEnv * (a - amplop[i]);
                hasil += amplop[i] * skala[i] * pembawa[i].p(derau);
            }
            return hasil * 0.6f;
        }

        public int ekor() {
            return 800;
        }
    }

    /** Gema (pantulan berulang) dengan peredam nada tinggi pada umpan balik. */
    private static class Pantul implements Blok {
        private final float[] buf;
        private int w = 0;
        private final float fb, basah;
        private final float aLp;
        private float lp = 0;
        private final int tunda;

        Pantul(int fs, double ms, float fb, float basah, float redam) {
            tunda = Math.max(2, (int) (fs * ms / 1000.0));
            buf = new float[tunda];
            this.fb = fb;
            this.basah = basah;
            this.aLp = redam;
        }

        public float p(float x) {
            float d = buf[w];
            lp += aLp * (d - lp);
            buf[w] = x + fb * lp;
            w++;
            if (w >= buf.length) {
                w = 0;
            }
            return x + basah * d;
        }

        public int ekor() {
            double ulang = Math.ceil(Math.log(0.03) / Math.log(fb));
            return (int) Math.min(ulang * tunda, EKOR_MAKS * 48000);
        }
    }

    /** Gaung ruangan gaya Freeverb: sisir paralel berperedam, dua penyaring semua-lewat, tunda awal. */
    private static class Gaung implements Blok {
        private final float[][] sisir;
        private final int[] posSisir;
        private final float[] fbSisir, lpSisir;
        private final float redam;
        private final float[][] semua;
        private final int[] posSemua;
        private final float[] awal;
        private int posAwal = 0;
        private final float basah, norm;
        private final int ekorSampel;

        Gaung(int fs, double[] ms, double rt60, float redam, float basah, double msAwal) {
            int n = ms.length;
            sisir = new float[n][];
            posSisir = new int[n];
            fbSisir = new float[n];
            lpSisir = new float[n];
            double jumlah = 0;
            for (int i = 0; i < n; i++) {
                int d = Math.max(2, (int) (fs * ms[i] / 1000.0));
                sisir[i] = new float[d];
                double g = Math.pow(10.0, -3.0 * (d / (double) fs) / rt60);
                if (g > 0.98) {
                    g = 0.98;
                }
                fbSisir[i] = (float) g;
                jumlah += 1.0 / (1.0 - g * g);
            }
            norm = (float) (1.0 / Math.sqrt(jumlah));
            this.redam = redam;
            this.basah = basah;
            int[] da = {(int) (fs * 0.0050), (int) (fs * 0.0017)};
            semua = new float[2][];
            posSemua = new int[2];
            for (int i = 0; i < 2; i++) {
                semua[i] = new float[Math.max(2, da[i] + 7 * i)];
            }
            awal = new float[Math.max(1, (int) (fs * msAwal / 1000.0))];
            ekorSampel = (int) Math.min(EKOR_MAKS * fs, (0.75 * rt60 + msAwal / 1000.0) * fs);
        }

        public float p(float x) {
            float masuk = awal.length > 1 ? awal[posAwal] : x;
            if (awal.length > 1) {
                awal[posAwal] = x;
                posAwal++;
                if (posAwal >= awal.length) {
                    posAwal = 0;
                }
            }
            float s = 0;
            for (int i = 0; i < sisir.length; i++) {
                float[] b = sisir[i];
                int k = posSisir[i];
                float o = b[k];
                lpSisir[i] = o * (1 - redam) + lpSisir[i] * redam;
                b[k] = masuk + lpSisir[i] * fbSisir[i];
                k++;
                if (k >= b.length) {
                    k = 0;
                }
                posSisir[i] = k;
                s += o;
            }
            s *= norm;
            for (int i = 0; i < semua.length; i++) {
                float[] b = semua[i];
                int k = posSemua[i];
                float bo = b[k];
                float y = -s + bo;
                b[k] = s + bo * 0.5f;
                k++;
                if (k >= b.length) {
                    k = 0;
                }
                posSemua[i] = k;
                s = y;
            }
            return x + basah * s;
        }

        public int ekor() {
            return ekorSampel;
        }
    }
}
