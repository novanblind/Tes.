package com.novan.githubbynovan;

import android.content.Context;
import android.content.SharedPreferences;

public class Store {
    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("github_by_novan", Context.MODE_PRIVATE);
    }
    public static String token(Context c) { return p(c).getString("token", ""); }
    public static void setToken(Context c, String t) { p(c).edit().putString("token", t).apply(); }

    // ---------- tanda tangan pribadi (keystore buatan sendiri) ----------

    /** Daftar tanda tangan pribadi: tiap item JSON berisi id, nama, alias, sandi, sidik, berkas, unduhan, dibuat. */
    public static java.util.List<org.json.JSONObject> signs(Context c) {
        java.util.List<org.json.JSONObject> out = new java.util.ArrayList<>();
        try {
            org.json.JSONArray a = new org.json.JSONArray(p(c).getString("signs", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i));
        } catch (Exception ignored) { }
        return out;
    }
    private static void saveSigns(Context c, java.util.List<org.json.JSONObject> l) {
        org.json.JSONArray a = new org.json.JSONArray();
        for (org.json.JSONObject o : l) a.put(o);
        p(c).edit().putString("signs", a.toString()).apply();
    }
    public static void addSign(Context c, org.json.JSONObject o) {
        java.util.List<org.json.JSONObject> l = signs(c);
        l.add(o);
        saveSigns(c, l);
    }
    public static void removeSign(Context c, String id) {
        java.util.List<org.json.JSONObject> l = signs(c);
        for (int i = l.size() - 1; i >= 0; i--) if (id.equals(l.get(i).optString("id"))) l.remove(i);
        saveSigns(c, l);
    }
    public static void updateSign(Context c, String id, String key, Object val) {
        java.util.List<org.json.JSONObject> l = signs(c);
        for (org.json.JSONObject o : l) {
            if (id.equals(o.optString("id"))) {
                try { o.put(key, val); } catch (Exception ignored) { }
            }
        }
        saveSigns(c, l);
    }
    /** True bila berkas .p12 sudah ada di folder Download (data lama tanpa penanda dibaca dari kolom unduhan). */
    public static boolean sudahEkspor(org.json.JSONObject o) {
        if (o.has("diekspor")) return o.optBoolean("diekspor", false);
        return o.optString("unduhan").startsWith("Download");
    }
    /** Label singkat untuk daftar: nama, alias, dan waktu dibuat agar nama kembar mudah dibedakan. */
    public static String labelSign(org.json.JSONObject o) {
        String t = o.optString("nama") + " (alias " + o.optString("alias");
        long d = o.optLong("dibuat", 0);
        if (d > 0) {
            t += ", dibuat " + new java.text.SimpleDateFormat("d MMM yyyy HH:mm", new java.util.Locale("id", "ID"))
                    .format(new java.util.Date(d));
        }
        return t + ")";
    }
    public static java.io.File signFile(Context c, String id) {
        java.io.File d = new java.io.File(c.getFilesDir(), "tanda_tangan");
        if (!d.exists()) d.mkdirs();
        return new java.io.File(d, id + ".p12");
    }
    /** Tema tampilan: "sistem" (bawaan, mengikuti HP), "gelap", atau "terang". */
    public static String tema(Context c) { return p(c).getString("tema", "sistem"); }
    public static void setTema(Context c, String t) { p(c).edit().putString("tema", t).apply(); }
    public static void clear(Context c) { p(c).edit().remove("token").apply(); }

    // ---------- setelan bangun APK (dilewati dialognya bila sudah diatur) ----------

    /** Tanda tangan saat bangun APK: "tanya" (bawaan), "bawaan" (kunci GitHub), atau "pribadi". */
    public static String ttMode(Context c) { return p(c).getString("tt_mode", "tanya"); }
    public static void setTtMode(Context c, String m) { p(c).edit().putString("tt_mode", m).apply(); }
    /** Id tanda tangan pribadi bawaan; kosong berarti pilih saat bangun. */
    public static String ttSignId(Context c) { return p(c).getString("tt_sign", ""); }
    public static void setTtSignId(Context c, String id) { p(c).edit().putString("tt_sign", id).apply(); }
    /** True bila keamanan aplikasi memakai setelan tersimpan (dialog pilihan dilewati). Bawaan: ya (penjaga aktif, lainnya mati). */
    public static boolean secSimpan(Context c) { return p(c).getBoolean("sec_simpan", true); }
    public static void setSecSimpan(Context c, boolean v) { p(c).edit().putBoolean("sec_simpan", v).apply(); }
    public static boolean secPenjaga(Context c) { return p(c).getBoolean("sec_penjaga", true); }
    public static void setSecPenjaga(Context c, boolean v) { p(c).edit().putBoolean("sec_penjaga", v).apply(); }
    public static boolean secR8(Context c) { return p(c).getBoolean("sec_r8", false); }
    public static void setSecR8(Context c, boolean v) { p(c).edit().putBoolean("sec_r8", v).apply(); }
    public static boolean secKuat(Context c) { return p(c).getBoolean("sec_kuat", false); }
    public static void setSecKuat(Context c, boolean v) { p(c).edit().putBoolean("sec_kuat", v).apply(); }
    public static boolean secEnk(Context c) { return p(c).getBoolean("sec_enk", false); }
    public static void setSecEnk(Context c, boolean v) { p(c).edit().putBoolean("sec_enk", v).apply(); }

    /** Unduh APK otomatis begitu pembangunan yang dipantau berhasil (bawaan: aktif). */
    public static boolean autoUnduh(Context c) { return p(c).getBoolean("auto_unduh_apk", true); }
    public static void setAutoUnduh(Context c, boolean v) { p(c).edit().putBoolean("auto_unduh_apk", v).apply(); }

    /** Pilihan terakhir kotak "Setelah berhasil, langsung bangun APK dan pantau" di dialog unggah (bawaan: dicentang). */
    public static boolean autoBangun(Context c) { return p(c).getBoolean("auto_bangun_unggah", true); }
    public static void setAutoBangun(Context c, boolean on) { p(c).edit().putBoolean("auto_bangun_unggah", on).apply(); }
}
