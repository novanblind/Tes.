package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Memasang APK hasil bangun. Pilihan pemasang bisa diingat lewat kotak "Jangan tanyakan lagi". */
class Pasang {
    private static final String PREF = "pasang";
    private static final String KUNCI = "pemasang"; // format: aksi|paket/kelas

    /** pilihAplikasi=true: selalu tampilkan daftar pemasang. false: pakai pilihan tersimpan, kalau belum ada tampilkan daftar. */
    static void pasang(Activity a, String path, boolean pilihAplikasi) {
        File f = new File(path);
        if (!f.isFile()) { MainActivity.say("Berkas APK tidak ditemukan"); return; }
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
                MainActivity.say("Nyalakan izin pasang aplikasi untuk Termux Data Novan, lalu kembali dan buka Lihat kemajuan, Pasang APK");
            } catch (Exception e) { MainActivity.say("Izin pasang aplikasi belum aktif"); }
            return;
        }
        Uri u = ApkProvider.uri(a, f);
        if (!pilihAplikasi) {
            String s = pref(a).getString(KUNCI, null);
            if (s != null && jalankan(a, u, s)) return;
            if (s != null) pref(a).edit().remove(KUNCI).apply(); // pemasang tersimpan sudah tidak ada
        }
        tampilkanDaftar(a, u);
    }

    private static SharedPreferences pref(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    private static Intent buatIntent(String aksi, Uri u, ComponentName cn) {
        Intent i = new Intent(aksi);
        i.setDataAndType(u, "application/vnd.android.package-archive");
        i.setClipData(ClipData.newRawUri("apk", u));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        if (cn != null) i.setComponent(cn);
        return i;
    }

    /** Buka pemasang yang tersimpan, langsung tanpa memilih aplikasi. */
    private static boolean jalankan(Activity a, Uri u, String s) {
        try {
            int p = s.indexOf('|');
            String aksi = s.substring(0, p);
            ComponentName cn = ComponentName.unflattenFromString(s.substring(p + 1));
            if (cn == null) return false;
            a.startActivity(buatIntent(aksi, u, cn));
            return true;
        } catch (Exception e) { return false; }
    }

    private static void tampilkanDaftar(Activity a, Uri u) {
        PackageManager pm = a.getPackageManager();
        final List<ResolveInfo> daftar = new ArrayList<>();
        final List<String> aksi = new ArrayList<>();
        final Set<String> sudah = new HashSet<>();
        String[] aksiAksi = { Intent.ACTION_INSTALL_PACKAGE, Intent.ACTION_VIEW };
        for (String ak : aksiAksi) {
            List<ResolveInfo> r;
            try { r = pm.queryIntentActivities(buatIntent(ak, u, null), 0); } catch (Exception e) { continue; }
            for (ResolveInfo ri : r) {
                ActivityInfo ai = ri.activityInfo;
                if (ai == null || !ai.exported) continue;
                String k = ai.packageName + "/" + ai.name;
                if (!sudah.add(k)) continue;
                daftar.add(ri);
                aksi.add(ak);
            }
        }
        if (daftar.isEmpty()) { MainActivity.say("Tidak ada aplikasi pemasang paket yang bisa membuka APK ini"); return; }

        final List<String> nama = new ArrayList<>();
        for (ResolveInfo ri : daftar) {
            CharSequence l = ri.loadLabel(pm);
            String app = "";
            try { app = ri.activityInfo.applicationInfo.loadLabel(pm).toString(); } catch (Exception e) { }
            String t = l == null ? ri.activityInfo.packageName : l.toString();
            if (app.length() > 0 && !app.equals(t)) t = app + ", " + t;
            nama.add(t);
        }

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        ListView lv = new ListView(a);
        lv.setAdapter(new ArrayAdapter<>(a, android.R.layout.simple_list_item_1, nama));
        final CheckBox cb = new CheckBox(a);
        cb.setText("Jangan tanyakan lagi");
        cb.setChecked(false);
        box.addView(lv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        box.addView(cb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        final AlertDialog d = new AlertDialog.Builder(a)
            .setTitle("Buka APK dengan")
            .setView(box)
            .setNegativeButton("Batal", null)
            .create();
        lv.setOnItemClickListener((parent, v, pos, id) -> {
            ActivityInfo ai = daftar.get(pos).activityInfo;
            ComponentName cn = new ComponentName(ai.packageName, ai.name);
            String s = aksi.get(pos) + "|" + cn.flattenToString();
            if (cb.isChecked()) pref(a).edit().putString(KUNCI, s).apply();
            d.dismiss();
            if (!jalankan(a, u, s)) MainActivity.say("Gagal membuka pemasang paket");
        });
        d.show();
    }
}
