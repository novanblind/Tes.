package com.novan.filemanagermax

import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

object ServerUtil {

    /** Menormalkan jalur virtual (tanpa ".." yang keluar dari akar). Selalu diawali "/". */
    fun normalize(base: String, arg: String): String {
        val full = if (arg.startsWith("/")) arg else if (base == "/") "/$arg" else "$base/$arg"
        val parts = ArrayList<String>()
        for (p in full.split("/")) {
            when (p) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(p)
            }
        }
        return "/" + parts.joinToString("/")
    }

    fun fileOf(root: File, virtual: String): File = File(root, virtual.removePrefix("/"))

    /** Alamat IPv4 jaringan lokal (Wi-Fi, hotspot, dsb) atau null bila tidak ada. */
    fun localIp(): String? {
        try {
            val best = ArrayList<String>()
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) best.add(a.hostAddress ?: continue)
                }
            }
            return best.firstOrNull()
        } catch (e: Exception) {
            return null
        }
    }
}
