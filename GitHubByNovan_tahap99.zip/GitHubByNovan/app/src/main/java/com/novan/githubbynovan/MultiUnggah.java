package com.novan.githubbynovan;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Unggah beberapa berkas dari HP sekaligus ke satu folder di repositori, satu per satu berurutan. Dijalankan oleh {@link UnggahService}. */
public final class MultiUnggah {
    public static final long MAX = UnggahBesar.MAX;

    private MultiUnggah() { }

    public static final class Hasil {
        public int berhasil, diganti, total;
        public boolean dibatalkan;
        /** Tautan berkas terakhir yang berhasil diunggah (berguna untuk unggah satu berkas). */
        public String raw = "", web = "";
        /** Pesan galat penuh berkas terakhir yang gagal. */
        public String galat = "";
        public final List<String> gagal = new ArrayList<>();
    }

    public static final class Tugas implements UnggahBesar.Batal {
        volatile boolean batal;

        public void batalkan() { batal = true; }

        @Override public boolean sudahBatal() { return batal; }
    }

    /** Intent pemilih berkas yang membolehkan memilih banyak berkas. */
    public static Intent pemilih() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        return i;
    }

    /** Daftar Uri hasil pemilih, baik satu berkas maupun banyak. */
    public static List<Uri> ambil(Intent data) {
        List<Uri> uris = new ArrayList<>();
        if (data == null) return uris;
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) {
                Uri u = cd.getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        return uris;
    }

    /** Rapikan nama folder tujuan: tanpa garis miring di awal/akhir. Kosong berarti akar repo. */
    public static String rapikanFolder(String f) {
        if (f == null) return "";
        return f.trim().replaceAll("^/+", "").replaceAll("/+$", "");
    }

    /**
     * Mengunggah semua berkas berurutan. Blokir sampai selesai, jadi HANYA boleh dipanggil dari thread latar
     * (dipakai oleh {@link UnggahService}).
     *
     * @param jalurTunggal bila tidak null, berkas pertama (satu-satunya) diunggah ke jalur ini apa adanya
     *                     dan {@code folder} diabaikan; bila null, nama berkas asli dipakai di dalam {@code folder}
     */
    public static Hasil proses(Context ctx, String full, String token, String folder, List<Uri> uris,
                               String jalurTunggal, Tugas tugas, UnggahBesar.Kemajuan k, boolean tanpaPicu) {
        final Hasil h = new Hasil();
        h.total = uris.size();
        final boolean tunggal = jalurTunggal != null;
        ContentResolver cr = ctx.getContentResolver();
        Set<String> dipakai = new HashSet<>();
        for (int i = 0; i < uris.size(); i++) {
            if (tugas.batal) {
                h.dibatalkan = true;
                break;
            }
            Uri u = uris.get(i);
            String nama = "berkas" + (i + 1);
            long ukuran = -1;
            try {
                Cursor c = cr.query(u, null, null, null, null);
                if (c != null) {
                    try {
                        if (c.moveToFirst()) {
                            int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (ni >= 0 && !c.isNull(ni)) nama = c.getString(ni);
                            int si = c.getColumnIndex(OpenableColumns.SIZE);
                            if (si >= 0 && !c.isNull(si)) ukuran = c.getLong(si);
                        }
                    } finally {
                        c.close();
                    }
                }
            } catch (Exception ignored) { }
            final String fn = tunggal ? jalurTunggal : nama;
            final int ke = i + 1;
            final String awalan = tunggal ? "" : "Mengunggah berkas " + ke + " dari " + h.total + ":\n";
            k.pesan(tunggal ? "Mulai mengunggah " + fn + "..." : awalan + fn);

            if (!dipakai.add(nama) && !tunggal) {
                h.gagal.add(nama + ": nama sama, dilewati");
                continue;
            }
            if (ukuran > MAX) {
                h.galat = "Berkas lebih dari 100 MB, terlalu besar.";
                h.gagal.add(nama + ": lebih dari 100 MB, terlalu besar");
                continue;
            }
            String jalur = tunggal ? jalurTunggal : (folder.isEmpty() ? nama : folder + "/" + nama);
            UnggahBesar.Hasil r = UnggahBesar.kirim(ctx, u, full, token, jalur, fn, tugas,
                    pesan -> k.pesan(awalan + pesan), tanpaPicu);
            if (r.dibatalkan) {
                h.dibatalkan = true;
                break;
            }
            if (r.ok) {
                h.berhasil++;
                if (r.diganti) h.diganti++;
                h.raw = r.raw == null ? "" : r.raw;
                h.web = r.web == null ? "" : r.web;
            } else {
                String t = r.galat == null ? "" : r.galat;
                h.galat = t;
                if (t.length() > 160) t = t.substring(0, 160) + "...";
                h.gagal.add(nama + ": " + t);
            }
            // Jeda singkat antar komit agar tidak kena pembatasan laju GitHub.
            if (i < uris.size() - 1) {
                try { Thread.sleep(1000); } catch (InterruptedException ignored) { }
            }
        }
        return h;
    }

    /** Ringkasan hasil untuk dibacakan: jumlah berhasil, diganti, dan daftar gagal. */
    public static String ringkas(Hasil h) {
        StringBuilder sb = new StringBuilder();
        if (h.dibatalkan) sb.append("Unggahan dibatalkan.\n");
        sb.append("Berhasil: ").append(h.berhasil).append(" dari ").append(h.total).append(" berkas.");
        if (h.diganti > 0) sb.append("\nBerkas lama bernama sama yang diganti: ").append(h.diganti).append(".");
        if (!h.gagal.isEmpty()) {
            sb.append("\n\nGagal (").append(h.gagal.size()).append("):");
            for (String g : h.gagal) sb.append("\n- ").append(g);
        }
        return sb.toString();
    }
}
