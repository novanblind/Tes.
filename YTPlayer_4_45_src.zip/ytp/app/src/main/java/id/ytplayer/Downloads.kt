package id.ytplayer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast

/** Pintu masuk unduhan dari Activity (menangani izin penyimpanan di Android 9 ke bawah). */
object Downloads {
    private const val REQ_STORAGE = 77

    private class Pending(val url: String, val title: String, val key: String, val playlist: Boolean = false)

    private var pending: Pending? = null

    fun request(activity: Activity, url: String, title: String, key: String) {
        if (Build.VERSION.SDK_INT <= 28 &&
            activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = Pending(url, title, key)
            activity.requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        DownloadService.start(activity, url, title, key)
    }

    /** Unduh seluruh playlist dengan format/kualitas yang sama untuk setiap video. */
    fun requestPlaylist(activity: Activity, playlistUrl: String, title: String, key: String) {
        if (Build.VERSION.SDK_INT <= 28 &&
            activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = Pending(playlistUrl, title, key, playlist = true)
            activity.requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        DownloadService.startPlaylist(activity, playlistUrl, title, key)
    }

    fun onPermissionResult(activity: Activity, requestCode: Int, grantResults: IntArray) {
        if (requestCode != REQ_STORAGE) return
        val p = pending
        pending = null
        if (p != null && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (p.playlist) DownloadService.startPlaylist(activity, p.url, p.title, p.key)
            else DownloadService.start(activity, p.url, p.title, p.key)
        } else {
            Toast.makeText(activity, "Izin penyimpanan diperlukan untuk mengunduh.", Toast.LENGTH_LONG).show()
        }
    }

    fun findActivity(ctx: Context): Activity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }
}
