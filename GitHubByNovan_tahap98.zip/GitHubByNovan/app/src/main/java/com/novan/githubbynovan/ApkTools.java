package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Pembangunan APK lewat GitHub Actions: bangun, pantau, cek status, unduh APK.
 * Padanan objek PembuatAPK pada skrip Lua.
 */
public class ApkTools {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Satu tombol di dialog. {@code stay}: dialog tidak ditutup setelah ditekan. */
    public static class Btn {
        final String label;
        final Runnable act;
        final boolean stay;
        Btn(String label, Runnable act, boolean stay) { this.label = label; this.act = act; this.stay = stay; }
    }

    public static Btn b(String label, Runnable act) { return new Btn(label, act, false); }
    public static Btn keep(String label, Runnable act) { return new Btn(label, act, true); }

    /** Layar tetap menyala selama memantau/mengunduh agar koneksi tidak terputus saat HP tidur. */
    static void keepOn(Activity a, boolean on) {
        try {
            if (on) a.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else a.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Exception ignored) { }
    }

    // ---------- dialog ----------

    /** Dialog dengan teks yang bisa dipilih dan daftar tombol (jumlah bebas). */
    public static AlertDialog dialog(final Activity a, String title, String msg, List<Btn> btns,
                                     String backLabel, final Runnable back) {
        return dialog(a, title, msg, btns, backLabel, back, 17);
    }

    public static AlertDialog dialog(final Activity a, String title, String msg, List<Btn> btns,
                                     String backLabel, final Runnable back, int textSp) {
        if (a.isFinishing()) return null;
        Ui.warna(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 12), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
        if (msg != null && !msg.isEmpty()) {
            TextView tv = new TextView(a);
            tv.setText(msg);
            tv.setTextSize(textSp);
            tv.setTextIsSelectable(true);
            box.addView(tv);
        }
        final AlertDialog[] holder = new AlertDialog[1];
        for (final Btn t : btns) {
            Button bt = new Button(a);
            bt.setText(t.label);
            bt.setAllCaps(false);
            bt.setTextSize(18);
            bt.setTextColor(Ui.textOn(Ui.BTN));
            bt.setBackgroundColor(Ui.BTN);
            bt.setMinHeight(Ui.dpOf(a, 56));
            bt.setMinimumHeight(Ui.dpOf(a, 56));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dpOf(a, 8);
            bt.setOnClickListener(v -> {
                if (!t.stay && holder[0] != null) holder[0].dismiss();
                if (t.act != null) t.act.run();
            });
            box.addView(bt, lp);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        AlertDialog.Builder bd = new AlertDialog.Builder(a).setTitle(title).setView(sv);
        if (backLabel != null) bd.setNegativeButton(backLabel, (x, w) -> { if (back != null) back.run(); });
        holder[0] = bd.show();
        try {
            holder[0].getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
        return holder[0];
    }

    public static AlertDialog dialog(Activity a, String title, String msg, List<Btn> btns, Runnable back) {
        return dialog(a, title, msg, btns, "kembali", back);
    }

    public static List<Btn> list(Btn... bs) {
        List<Btn> l = new ArrayList<>();
        for (Btn x : bs) l.add(x);
        return l;
    }

    /** Dialog error: rincian bisa dipilih dan ada tombol "salin keterangan error". */
    public static void error(final Activity a, String title, final String detail, Runnable back, Btn... extra) {
        List<Btn> l = new ArrayList<>();
        l.add(keep("salin keterangan error", () -> Ui.copy(a, "Keterangan error", detail)));
        for (Btn x : extra) l.add(x);
        dialog(a, title, detail, l, "kembali", back);
    }

    // ---------- status ----------

    public static String statusText(String status, String conclusion) {
        if ("queued".equals(status) || "waiting".equals(status) || "pending".equals(status)) {
            return "Menunggu giliran";
        } else if ("in_progress".equals(status)) {
            return "Sedang membangun";
        } else if ("completed".equals(status)) {
            if ("success".equals(conclusion)) return "Berhasil";
            if ("failure".equals(conclusion)) return "Gagal";
            if ("cancelled".equals(conclusion)) return "Dibatalkan";
            return "Selesai (" + conclusion + ")";
        }
        return status;
    }

    private static JSONObject firstRun(String res) {
        JSONArray arr = Api.parse(res).optJSONArray("workflow_runs");
        return arr != null && arr.length() > 0 ? arr.optJSONObject(0) : null;
    }

    private interface IdCb { void got(long id); }

    private static void lastRunId(String full, String token, final IdCb cb) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs?per_page=1", token, null, (ok, res) -> {
            long id = 0;
            if (ok) {
                JSONObject r = firstRun(res);
                if (r != null) id = r.optLong("id", 0);
            }
            cb.got(id);
        });
    }

    /** Catat nomor pembangunan terakhir lebih dulu (dipakai sebagai batas untuk pemantauan). */
    public static void baselineRun(String full, String token, Runnable then, final long[] out) {
        lastRunId(full, token, id -> {
            out[0] = id;
            then.run();
        });
    }

    public static void cekStatus(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs?per_page=1", token, null, (ok, res) -> MAIN.post(() -> {
            if (a.isFinishing()) return;
            if (!ok) {
                error(a, "Gagal memeriksa status", "Proyek: " + full + "\n\n" + res, back,
                        b("coba lagi", () -> cekStatus(a, full, token, back)));
                return;
            }
            JSONObject run = firstRun(res);
            if (run == null) {
                dialog(a, "Status pembangunan", "Proyek: " + full
                                + "\n\nBelum ada pembangunan APK. Tekan Bangun APK sekarang.",
                        list(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back))), back);
                return;
            }
            showRun(a, full, token, run, back);
        }));
    }

    public static void showRun(final Activity a, final String full, final String token, JSONObject run,
                               final Runnable back) {
        if (a.isFinishing()) return;
        String status = run.optString("status", "");
        String concl = Api.str(run, "conclusion");
        String text = statusText(status, concl);
        final String logUrl = run.optString("html_url", "");
        final long runId = run.optLong("id", 0);
        String title = run.optString("display_title", run.optString("name", ""));
        String msg = "Proyek: " + full + "\nPembangunan nomor: " + run.optInt("run_number", 0);
        if (!title.isEmpty()) msg += "\nKeterangan: " + title;
        msg += "\nStatus: " + text;

        Runnable again = () -> TandaTanganRepo.mulai(a, full, token, back);
        final Runnable kembaliKeRun = () -> showRun(a, full, token, run, back);
        Runnable web = () -> logRun(a, full, token, run, kembaliKeRun);

        if ("completed".equals(status) && "success".equals(concl)) {
            dialog(a, "Pembangunan APK berhasil", msg + "\n\nAPK sudah selesai dan rilisnya siap diunduh.",
                    list(b("unduh APK", () -> ambilApk(a, full, token, back)),
                            b("bangun ulang", again),
                            b("jalankan ulang pembangunan ini (rerun)", () -> aksiRun(a, full, token, run, true,
                                    () -> cekStatus(a, full, token, back))),
                            b("riwayat pembangunan", () -> riwayat(a, full, token, back)),
                            b("ringkasan pembangunan", () -> ringkasan(a, full, token, run, kembaliKeRun)),
                            b("lihat log lengkap", web)), back);
        } else if ("completed".equals(status)) {
            // Gagal: langsung buka rincian error (tanpa dialog perantara); tombol salin ada di sana.
            Toast.makeText(a, "Pembangunan APK gagal. Mengambil rincian error...", Toast.LENGTH_SHORT).show();
            bacaLogError(a, full, token, runId, logUrl, back, again);
            return;
        } else {
            dialog(a, "Pembangunan sedang berjalan", msg + "\n\nPembangunan masih berjalan.",
                    list(b("pantau otomatis", () -> pantau(a, full, token, back, 0)),
                            b("periksa lagi", () -> cekStatus(a, full, token, back)),
                            b("batalkan pembangunan", () -> aksiRun(a, full, token, run, true,
                                    () -> cekStatus(a, full, token, back))),
                            b("riwayat pembangunan", () -> riwayat(a, full, token, back)),
                            b("lihat log lengkap", web)), back);
        }
        Toast.makeText(a, "Status pembangunan: " + text, Toast.LENGTH_SHORT).show();
    }

    // ---------- pantau ----------

    private static boolean askedNotif = false;

    static void askNotif(Activity a) {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif
                && a.checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            askedNotif = true;
            try { a.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 78); }
            catch (Exception ignored) { }
        }
    }

    private static boolean dead(Activity a) {
        return a.isFinishing() || (Build.VERSION.SDK_INT >= 17 && a.isDestroyed());
    }

    /**
     * Pantau otomatis sampai pembangunan selesai. Pemantauan dijalankan oleh layanan latar depan
     * (BuildWatchService), jadi tetap berjalan saat pengguna pindah ke aplikasi lain; hasilnya muncul
     * sendiri atau lewat notifikasi.
     */
    public static void pantau(final Activity a, final String full, final String token, final Runnable back,
                              final long idAwal) {
        pantau(a, full, token, back, idAwal, true);
    }

    /** @param mulaiLayanan false bila layanan pemantau sudah berjalan (mis. dinyalakan setelah unggah otomatis); hanya menampilkan dialognya */
    static void pantau(final Activity a, final String full, final String token, final Runnable back,
                       final long idAwal, final boolean mulaiLayanan) {
        if (dead(a)) return;
        askNotif(a);
        if (mulaiLayanan && !BuildWatchService.start(a, full, token, idAwal)) {
            error(a, "Pemantauan latar belakang tidak bisa dimulai",
                    "Pemantauan belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.\nProyek: " + full, back,
                    b("coba lagi", () -> pantau(a, full, token, back, idAwal)));
            return;
        }

        final TextView tv = new TextView(a);
        tv.setTextSize(17);
        keepOn(a, true);
        tv.setText("Menunggu GitHub memulai pembangunan APK...\n\nBoleh pindah aplikasi. Anda akan diberi notifikasi saat selesai.");
        if (!mulaiLayanan && !BuildWatchService.lastText.isEmpty()) tv.setText(BuildWatchService.lastText);
        tv.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 16), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
        final AlertDialog[] diag = new AlertDialog[1];
        final BuildWatchService.Listener[] self = new BuildWatchService.Listener[1];
        self[0] = new BuildWatchService.Listener() {
            @Override public void onStatus(String text) {
                if (dead(a)) { if (BuildWatchService.listener == self[0]) BuildWatchService.listener = null; return; }
                tv.setText(text);
            }
            @Override public void onFinished() {
                if (BuildWatchService.listener == self[0]) BuildWatchService.listener = null;
                try { if (diag[0] != null) diag[0].dismiss(); } catch (Exception ignored) { }
                // Bila aplikasi sedang tidak tampil, hasil ditampilkan saat layar aplikasi dibuka lagi.
                if (!dead(a) && App.visible()) tampilkanHasilTertunda(a, back);
            }
        };
        diag[0] = new AlertDialog.Builder(a).setTitle("Memantau pembangunan APK").setView(tv)
                .setPositiveButton("batalkan build", (x, w) -> konfirmasiBatalPantau(a, full, token, back, idAwal))
                .setNegativeButton("berhenti memantau", (x, w) -> {
                    BuildWatchService.stop(a);
                    if (back != null) back.run();
                })
                .setOnDismissListener(x -> {
                    // Menutup dialog tidak menghentikan pemantauan; hanya tombol berhenti yang menghentikan.
                    if (BuildWatchService.listener == self[0]) BuildWatchService.listener = null;
                    keepOn(a, false);
                })
                .show();
        try {
            diag[0].getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            diag[0].getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
        } catch (Exception ignored) { }
        BuildWatchService.listener = self[0];
    }

    /** Tombol "batalkan build" di dialog pemantauan: tanya dulu, lalu batalkan pembangunan terbaru. */
    private static void konfirmasiBatalPantau(final Activity a, final String full, final String token,
                                              final Runnable back, final long idAwal) {
        if (dead(a)) return;
        AlertDialog d = new AlertDialog.Builder(a).setTitle("Batalkan pembangunan?")
                .setMessage("Pembangunan yang sedang berjalan di " + full + " dihentikan. Prosesnya tidak bisa "
                        + "dilanjutkan, hanya bisa dibangun ulang dari awal.")
                .setPositiveButton("batalkan", (x, w) -> batalkanTerbaru(a, full, token, back))
                .setNegativeButton("jangan batalkan", (x, w) -> pantau(a, full, token, back, idAwal, false))
                .show();
        try {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
    }

    private static void batalkanTerbaru(final Activity a, final String full, final String token, final Runnable back) {
        lastRunId(full, token, id -> {
            if (dead(a)) return;
            if (id == 0) {
                Toast.makeText(a, "Belum ada pembangunan yang bisa dibatalkan.", Toast.LENGTH_LONG).show();
                return;
            }
            batalkanRun(a, full, token, id, false, back);
        });
    }

    /** Menampilkan hasil pemantauan yang selesai saat aplikasi di latar belakang (bila ada). */
    public static void tampilkanHasilTertunda(final Activity a) {
        if (!BuildWatchService.hasPending() && !DownloadService.hasPending() && !HapusArtefakService.hasPending()
                && !UnggahService.hasPending()) return;
        MAIN.post(() -> tampilkanHasilTertunda(a, null));
    }

    public static void tampilkanHasilTertunda(final Activity a, final Runnable back) {
        if (dead(a)) return;
        BuildWatchService.Result r = BuildWatchService.takePending();
        if (r != null) {
            BuildWatchService.cancelResultNotification(a);
            hasilPantau(a, r, back);
        }
        DownloadService.Result d = DownloadService.takePending();
        if (d != null) {
            DownloadService.cancelResultNotification(a);
            hasilUnduh(a, d, back);
        }
        HapusArtefakService.Hasil h = HapusArtefakService.takePending();
        if (h != null) {
            HapusArtefakService.cancelResultNotification(a);
            hasilHapusSemua(a, h, back);
        }
        UnggahService.Hasil u = UnggahService.takePending();
        if (u != null) {
            UnggahService.cancelResultNotification(a);
            hasilUnggah(a, u, back, null);
        }
    }

    /**
     * Rincian hasil unggahan dari {@link UnggahService}.
     *
     * @param lagi aksi untuk tombol "unggah berkas lain"; null bila tombol itu tidak perlu
     */
    static void hasilUnggah(final Activity a, final UnggahService.Hasil r, final Runnable back, final Runnable lagi) {
        if (dead(a) || r.h == null) return;
        final MultiUnggah.Hasil h = r.h;
        final String full = r.full, token = r.token;
        final long idAwal = r.idAwal;
        final String link = h.raw.isEmpty() ? h.web : h.raw;
        List<Btn> tombol = list();
        // Bangun otomatis: satu kali di akhir unggahan, lewat alur biasa (tanda tangan, keamanan aplikasi, lalu jalan).
        String catatanAuto = "";
        if (r.auto && h.berhasil > 0) {
            if (UnggahService.layakBangun(h)) {
                android.widget.Toast.makeText(a, "Unggahan selesai. Memulai pembangunan APK.",
                        android.widget.Toast.LENGTH_LONG).show();
                TandaTanganRepo.mulai(a, full, token, back);
                return;
            }
            catatanAuto = "\n\nBangun otomatis tidak jalan karena unggahan tidak lengkap. "
                    + "Tekan Bangun APK sekarang bila tetap ingin membangun.";
        }
        if (r.tunggal) {
            if (h.berhasil == 0) {
                dialog(a, h.dibatalkan ? "Unggahan dibatalkan" : "Gagal mengunggah berkas",
                        "Berkas: " + r.target + "\nRepo: " + full
                                + (h.dibatalkan ? "" : "\n\n" + h.galat), tombol, "oke", back);
                return;
            }
            String msg = "Berkas: " + r.target + "\nRepo: " + full
                    + (h.diganti > 0 ? "\n(berkas lama dengan nama sama sudah diganti)" : "")
                    + "\n\nJika proyek sudah lengkap, tekan Bangun APK sekarang. "
                    + "Jika repo ini membangun otomatis, tekan Pantau." + catatanAuto;
            tombol.add(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back)));
            tombol.add(b("pantau pembangunan APK", () -> pantau(a, full, token, back, idAwal)));
            tombol.add(b("cek status APK", () -> cekStatus(a, full, token, back)));
            if (lagi != null) tombol.add(b("unggah berkas lain", lagi));
            if (!link.isEmpty()) {
                tombol.add(keep("salin tautan raw", () -> Ui.copy(a, "Tautan raw", link)));
                tombol.add(keep("bagikan tautan", () -> Ui.share(a, "Berkas: " + r.target, link)));
            }
            dialog(a, "Berkas berhasil diunggah", msg, tombol, back);
            return;
        }
        StringBuilder msg = new StringBuilder(MultiUnggah.ringkas(h));
        msg.append("\n\nRepo: ").append(full).append("\nFolder tujuan: ")
                .append(r.folder.isEmpty() ? "folder utama" : r.folder);
        if (r.auto) {
            msg.append(catatanAuto);
        } else if (h.berhasil > 1) {
            msg.append("\n\nCatatan: bila repo membangun otomatis, bisa terjadi beberapa build. "
                    + "Centang \"Setelah berhasil, langsung bangun APK dan pantau\" agar build hanya sekali.");
        }
        if (h.berhasil > 0) {
            tombol.add(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back)));
            tombol.add(b("pantau pembangunan APK", () -> pantau(a, full, token, back, idAwal)));
            tombol.add(b("cek status APK", () -> cekStatus(a, full, token, back)));
        }
        if (lagi != null) tombol.add(b("unggah berkas lain", lagi));
        dialog(a, "Unggahan selesai", msg.toString(), tombol, back);
    }

    private static void hasilUnduh(final Activity a, final DownloadService.Result r, final Runnable back) {
        if (!r.ok) {
            error(a, "Gagal Mengunduh APK", "Berkas: " + r.name + "\n\nKesalahan:\n" + r.message, back,
                    b("buka di browser", () -> Ui.browse(a, r.fallback != null && !r.fallback.isEmpty()
                            ? r.fallback : r.url)));
            return;
        }
        saved(a, r.target, back);
    }

    private static void hasilPantau(final Activity a, final BuildWatchService.Result r, final Runnable back) {
        final String full = r.full, token = r.token;
        final long idAwal = r.idAwal;
        switch (r.kind) {
            case BuildWatchService.KIND_DONE:
                if (Store.autoUnduh(a) && r.run != null && "success".equals(Api.str(r.run, "conclusion"))) {
                    Toast.makeText(a, "Pembangunan APK berhasil. Mengunduh APK otomatis...", Toast.LENGTH_LONG).show();
                    ambilApk(a, full, token, back);
                } else {
                    showRun(a, full, token, r.run, back);
                }
                break;
            case BuildWatchService.KIND_NO_RUN:
                dialog(a, "Belum ada pembangunan baru",
                        "GitHub belum memulai pembangunan baru. Tekan Bangun APK sekarang.",
                        list(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back)),
                                b("lihat status terakhir", () -> cekStatus(a, full, token, back))), back);
                break;
            case BuildWatchService.KIND_TIMEOUT:
                error(a, "Pemantauan dihentikan", r.detail, back,
                        b("periksa status", () -> cekStatus(a, full, token, back)));
                break;
            default:
                error(a, "Gagal memantau pembangunan", r.detail, back,
                        b("pantau lagi", () -> pantau(a, full, token, back, idAwal)));
        }
    }

    // ---------- analisis error ----------

    private static boolean failed(String c) {
        return "failure".equals(c) || "timed_out".equals(c) || "cancelled".equals(c);
    }

    public static void bacaLogError(final Activity a, final String full, final String token, final long runId,
                                    final String logUrl, final Runnable back) {
        bacaLogError(a, full, token, runId, logUrl, back, null);
    }

    /** @param ulang aksi untuk tombol "bangun ulang" di dialog hasil; null bila tidak perlu */
    public static void bacaLogError(final Activity a, final String full, final String token, final long runId,
                                    final String logUrl, final Runnable back, final Runnable ulang) {
        final TextView tv = new TextView(a);
        tv.setTextSize(17);
        tv.setText("Mengambil rincian kegagalan build...");
        tv.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 16), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
        final AlertDialog pd = new AlertDialog.Builder(a).setTitle("Menganalisis Error").setView(tv).show();
        final Btn web = b("lihat log lengkap", () -> logRun(a, full, token, runId, 0, true, back));
        final Btn[] extra = ulang == null ? new Btn[]{web} : new Btn[]{b("bangun ulang", ulang),
                b("jalankan ulang pembangunan ini (rerun)", () ->
                        jalankanUlangRun(a, full, token, runId, false, true, back)),
                b("jalankan ulang hanya bagian yang gagal", () ->
                        jalankanUlangRun(a, full, token, runId, true, true, back)),
                b("riwayat pembangunan", () -> riwayat(a, full, token, back)), web};

        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId + "/jobs", token, null,
                (okJobs, resJobs) -> MAIN.post(() -> {
                    if (a.isFinishing()) return;
                    if (!okJobs) {
                        try { pd.dismiss(); } catch (Exception ignored) { }
                        error(a, "Gagal memeriksa rincian build",
                                "Proyek: " + full + "\nRun ID: " + runId + "\n\n" + resJobs, back, extra);
                        return;
                    }
                    long jobId = 0;
                    String jobName = "Tidak diketahui", stepName = "Tidak diketahui";
                    boolean adaLangkah = false;
                    JSONObject jobObj = null;
                    JSONArray jobs = Api.parse(resJobs).optJSONArray("jobs");
                    for (int i = 0; jobs != null && i < jobs.length(); i++) {
                        JSONObject j = jobs.optJSONObject(i);
                        if (j == null || !failed(j.optString("conclusion", ""))) continue;
                        jobId = j.optLong("id", 0);
                        jobObj = j;
                        jobName = j.optString("name", jobName);
                        JSONArray steps = j.optJSONArray("steps");
                        adaLangkah = steps != null && steps.length() > 0;
                        for (int k = 0; steps != null && k < steps.length(); k++) {
                            JSONObject st = steps.optJSONObject(k);
                            if (st != null && failed(st.optString("conclusion", ""))) {
                                stepName = st.optString("name", "Kompilasi");
                                break;
                            }
                        }
                        if ("Tidak diketahui".equals(stepName)) {
                            stepName = adaLangkah
                                    ? "tidak ada yang tercatat gagal (kemungkinan dibatalkan)"
                                    : "tidak ada. Pekerjaan gagal sebelum langkah pertama berjalan";
                        }
                        break;
                    }
                    if (jobId == 0) {
                        try { pd.dismiss(); } catch (Exception ignored) { }
                        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId, token, null,
                                (okRun, resRun) -> MAIN.post(() -> {
                                    if (a.isFinishing()) return;
                                    String info = "";
                                    if (okRun) {
                                        JSONObject ro = Api.parse(resRun);
                                        info = "\n\nStatus run: " + Api.str(ro, "status")
                                                + "\nHasil run: " + Api.str(ro, "conclusion")
                                                + "\nPemicu: " + Api.str(ro, "event")
                                                + "\nAlur kerja: " + Api.str(ro, "path")
                                                + "\nCabang: " + Api.str(ro, "head_branch");
                                        if ("startup_failure".equals(Api.str(ro, "conclusion"))) {
                                            info += "\n\nAlur kerja gagal dimulai (startup_failure). Biasanya berkas "
                                                    + "workflow salah tulis atau izin (permissions) tidak cocok.";
                                        }
                                    }
                                    Btn[] pakai = extra;
                                    if (okRun && "action_required".equals(Api.str(Api.parse(resRun), "conclusion"))) {
                                        info += "\n\nGitHub menahan pembangunan ini sebelum satu langkah pun berjalan. "
                                                + "Ketuk \"periksa penyebab ditahan\" di bawah.";
                                        pakai = gabung(tombolTindakan(a, full, token, runId, back), extra);
                                    }
                                    error(a, "Rincian Error", "Proyek: " + full + "\nRun ID: " + runId
                                            + "\n\nTidak ada langkah yang gagal. Alur kerja mungkin salah tulis atau dibatalkan."
                                            + info, back, pakai);
                                }));
                        return;
                    }
                    tv.setText("Mengunduh teks log dari GitHub...");
                    final String header = "Proyek: " + full + "\nRun ID: " + runId + "\nJob: " + jobName
                            + "\nLangkah gagal: " + stepName;
                    final String step = stepName;
                    final long fjob = jobId;
                    final JSONObject fjobObj = jobObj;
                    Api.POOL.execute(() -> {
                        List<String> lines = null;
                        String err = null;
                        for (int attempt = 1; attempt <= 3 && lines == null; attempt++) {
                            try {
                                lines = fetchLog(Api.BASE + "/repos/" + full + "/actions/jobs/" + fjob + "/logs", token);
                            } catch (Exception e) {
                                err = String.valueOf(e.getMessage());
                                if (err.startsWith("Kode ")) break;
                                try { Thread.sleep(1200L * attempt); } catch (InterruptedException ignored) { }
                            }
                        }
                        if (lines == null || lines.isEmpty()) {
                            String p = petunjukJob(full, token, fjob, fjobObj);
                            err = p;
                        }
                        final List<String> fl = lines;
                        final String fe = err;
                        MAIN.post(() -> {
                            try { pd.dismiss(); } catch (Exception ignored) { }
                            Btn[] ex = extra;
                            if (fe != null && fe.contains(TAG_TAGIHAN)) {
                                List<Btn> l = new ArrayList<>();
                                l.add(b("buka penagihan GitHub", () -> bukaWeb(a, "https://github.com/settings/billing")));
                                l.add(b("buka pengaturan repo ini", () -> bukaWeb(a, "https://github.com/" + full + "/settings")));
                                for (Btn x : extra) l.add(x);
                                ex = l.toArray(new Btn[0]);
                            }
                            showAnalysis(a, header, step, fl, fe, back, ex);
                        });
                    });
                }));
    }

    /** Teks tambahan saat log tidak ada: keterangan (annotation) dari GitHub dan data job. Jalankan di thread latar. */
    private static String petunjukJob(String full, String token, long jobId, JSONObject job) {
        StringBuilder sb = new StringBuilder();
        if (job != null) {
            sb.append("\n\nStatus job: ").append(job.optString("status", "-"))
                    .append("\nHasil job: ").append(Api.str(job, "conclusion"))
                    .append("\nMulai: ").append(Api.str(job, "started_at"))
                    .append("\nSelesai: ").append(Api.str(job, "completed_at"))
                    .append("\nRunner: ").append(Api.str(job, "runner_name").isEmpty()
                            ? "(tidak ada runner yang menjalankan)" : Api.str(job, "runner_name"));
            JSONArray steps = job.optJSONArray("steps");
            sb.append("\nJumlah langkah tercatat: ").append(steps == null ? 0 : steps.length());
        }
        String ann = "";
        try {
            java.net.HttpURLConnection c = Saver.open(
                    Api.BASE + "/repos/" + full + "/check-runs/" + jobId + "/annotations", token,
                    "application/vnd.github+json");
            try {
                int code = c.getResponseCode();
                if (code < 400) {
                    java.io.BufferedReader r = new java.io.BufferedReader(
                            new java.io.InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder();
                    String l;
                    while ((l = r.readLine()) != null) body.append(l).append('\n');
                    r.close();
                    JSONArray arr = Api.parseArr(body.toString());
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        String m = Api.str(o, "message");
                        if (m.isEmpty()) continue;
                        ann += "\n- [" + Api.str(o, "annotation_level") + "] " + m
                                + (Api.str(o, "path").isEmpty() || ".github".equals(Api.str(o, "path")) ? ""
                                : " (" + Api.str(o, "path") + ":" + o.optInt("start_line", 0) + ")");
                    }
                } else {
                    ann = "\n(keterangan tidak bisa diambil, kode " + code + ")";
                }
            } finally {
                c.disconnect();
            }
        } catch (Exception e) {
            ann = "\n(keterangan tidak bisa diambil: " + e.getMessage() + ")";
        }
        if (ann.trim().isEmpty()) {
            sb.append("\n\nGitHub tidak memberi keterangan apa pun untuk job ini.");
        } else {
            sb.append("\n\nKeterangan dari GitHub (asli):").append(ann);
        }
        final String low = ann.toLowerCase(java.util.Locale.ROOT);
        final boolean tagihan = low.contains("billing") || low.contains("payment") || low.contains("spending limit");
        final boolean kunci = tagihan && adaKunci(full, token);
        String sebab;
        if (low.contains("billing") || low.contains("payment") || low.contains("spending limit")) {
            sebab = TAG_TAGIHAN + " tidak boleh memakai GitHub Actions saat ini, karena pembayaran gagal "
                    + "atau jatah menit Actions habis dan batas pengeluaran (spending limit) bernilai 0. "
                    + "Job langsung berhenti sebelum satu langkah pun berjalan, makanya log tidak ada."
                    + "\n\nCARA MENGATASI:"
                    + "\n\nA. Tetap privat (aman untuk tanda tangan pribadi):"
                    + "\nBuka Settings > Billing and plans > Usage dan lihat sisa menit Actions. "
                    + "Jatahnya reset tiap bulan. Kalau ada kartu yang gagal bayar, itu juga harus dibereskan."
                    + "\n\nB. Jadikan repo publik (repo publik tidak memakai jatah menit):"
                    + "\nSettings repo > General > Danger Zone > Change visibility. Kodenya jadi bisa dilihat semua orang. "
                    + (kunci
                    ? "\nAWAS: repo ini berisi kunci tanda tangan pribadi di folder .tanda-tangan (keystore dan sandi). "
                      + "Bila dijadikan publik, siapa pun bisa mengambilnya dan menandatangani APK atas nama Anda. "
                      + "Menghapus folder itu tidak cukup karena tetap ada di riwayat repo. Jangan jadikan repo ini publik; "
                      + "lebih aman buat repo publik baru, lalu pilih tanda tangan pribadi lewat Secrets."
                    : "\nUntuk tanda tangan pribadi di repo publik, pilih \"tanda tangan pribadi lewat Secrets\" saat "
                      + "Mulai pembangunan APK: kunci disimpan terenkripsi di GitHub Secrets, bukan sebagai berkas.")
                    + "\nAtau pakai tanda tangan bawaan GitHub (kunci berganti tiap build, aplikasi lama "
                    + "harus dicopot dulu sebelum memasang yang baru)."
                    + "\n\nC. Atau buat repo publik baru khusus untuk membangun APK dengan tanda tangan bawaan."
                    + "\n\nD. Naikkan batas pengeluaran atau bereskan kartu yang gagal bayar, hanya bila Anda "
                    + "memang mau membayar.";
        } else if (low.contains("no runner") || low.contains("runner") && low.contains("matching")) {
            sebab = "PENYEBAB: tidak ada runner yang cocok dengan label runs-on di berkas workflow."
                    + "\n\nCARA MENGATASI: periksa baris runs-on di .github/workflows, misalnya ubuntu-latest "
                    + "atau ubuntu-24.04. Nama label yang salah tulis membuat job menunggu tanpa runner.";
        } else if (low.contains("invalid workflow") || low.contains("syntax") || low.contains("unexpected value")
                || low.contains("yaml")) {
            sebab = "PENYEBAB: berkas workflow salah tulis (sintaks YAML atau nama kunci tidak dikenal)."
                    + "\n\nCARA MENGATASI: perbaiki berkas di .github/workflows sesuai baris yang disebut di "
                    + "keterangan asli di bawah, lalu bangun ulang. Indentasi harus memakai spasi, bukan tab.";
        } else if (low.contains("quota") || low.contains("storage")) {
            sebab = "PENYEBAB: kuota penyimpanan artefak atau paket GitHub penuh."
                    + "\n\nCARA MENGATASI: hapus artefak lama lewat menu hapus artefak di aplikasi ini, "
                    + "lalu bangun ulang.";
        } else if (low.contains("cancel")) {
            sebab = "PENYEBAB: pembangunan dibatalkan sebelum sempat berjalan."
                    + "\n\nCARA MENGATASI: bangun ulang. Bila ada pembangunan lain yang sedang jalan di repo "
                    + "yang sama, tunggu selesai dulu.";
        } else {
            sebab = "PENYEBAB: job gagal sebelum ada langkah yang berjalan, jadi log memang tidak ada. "
                    + "Penyebab umum: jatah menit Actions atau batas pembayaran akun, berkas workflow salah tulis "
                    + "(indentasi, runs-on, permissions), atau runner tidak tersedia."
                    + "\n\nCARA MENGATASI: buka halaman run di web (tombol \"buka log di web\") dan baca "
                    + "bagian Catatan (Annotations) di bagian atas.";
        }
        return sebab + "\n\n--- Rincian teknis ---" + sb;
    }

    /** True bila repo berisi keystore tanda tangan pribadi (.tanda-tangan/kunci.p12). Jalankan di thread latar. */
    static boolean adaKunci(String full, String token) {
        try {
            java.net.HttpURLConnection c = Saver.open(
                    Api.BASE + "/repos/" + full + "/contents/" + TandaTanganRepo.KS_PATH, token,
                    "application/vnd.github+json");
            try {
                return c.getResponseCode() == 200;
            } finally {
                c.disconnect();
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** Penanda teks penyebab bila tagihan akun GitHub yang jadi masalah. */
    private static final String TAG_TAGIHAN = "PENYEBAB: akun GitHub Anda";

    private static void bukaWeb(Activity a, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            a.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(a, "Peramban tidak terbuka. Buka manual: " + url, Toast.LENGTH_LONG).show();
        }
    }

    private static List<String> fetchLog(String url, String token) throws Exception {
        java.net.HttpURLConnection c = Saver.open(url, token, "application/vnd.github+json");
        try {
            int code = c.getResponseCode();
            if (code >= 400) {
                throw new java.io.IOException("Kode " + code + " saat mengambil log (log mungkin sudah "
                        + "kedaluwarsa atau token tidak punya izin).");
            }
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            List<String> out = new ArrayList<>();
            String l;
            while ((l = r.readLine()) != null) {
                out.add(l);
                if (out.size() > 40000) out.subList(0, 10000).clear();
            }
            r.close();
            return out;
        } finally {
            c.disconnect();
        }
    }

    private static void showAnalysis(final Activity a, String header, String step, List<String> lines,
                                     String err, Runnable back, Btn... web) {
        if (lines == null || lines.isEmpty()) {
            if (err != null && err.contains("PENYEBAB:")) {
                error(a, "Build tidak bisa dimulai", header + "\n\n" + err, back, web);
                return;
            }
            error(a, "Gagal Mengambil Log", header + "\n\nTidak dapat membaca berkas log:\n" + err, back, web);
            return;
        }
        final String brief, all, stepLog, spoken;
        try {
            LogAnalyzer.Result r = LogAnalyzer.analyze(lines);
            brief = LogAnalyzer.report(r, header, 20);
            all = LogAnalyzer.report(r, header, -1);
            stepLog = header + "\n\n--- Log langkah yang gagal ---\n" + LogAnalyzer.tail(r.area, 1500);
            spoken = LogAnalyzer.spoken(r, step);
        } catch (Exception e) {
            String t = header + "\n\nAnalisis otomatis gagal: " + e + "\n\n--- 60 baris terakhir log ---\n"
                    + LogAnalyzer.tail(lines, 60);
            List<Btn> l1 = list(keep("salin ringkasan", () -> Ui.copy(a, "Ringkasan error APK", t)));
            for (Btn x : web) l1.add(x);
            dialog(a, "Hasil Analisis Error APK", t, l1, "kembali", back, 14);
            return;
        }
        final String last = header + "\n\n--- Log (600 baris terakhir) ---\n" + LogAnalyzer.tail(lines, 600);
        Toast.makeText(a, spoken, Toast.LENGTH_LONG).show();
        List<Btn> l2 = list(
                keep("salin ringkasan penyebab", () -> Ui.copy(a, "Ringkasan penyebab error APK", brief)),
                keep("salin semua kesalahan", () -> Ui.copy(a, "Semua kesalahan APK", all)),
                keep("salin log langkah yang gagal", () -> Ui.copy(a, "Log langkah gagal APK", stepLog)),
                keep("salin 600 baris terakhir log", () -> Ui.copy(a, "Log lengkap APK", last)));
        for (Btn x : web) l2.add(x);
        dialog(a, "Hasil Analisis Error APK", brief, l2, "kembali", back, 14);
    }

    // ---------- bangun ----------

    private interface WfCb { void next(boolean justInstalled); }

    private static String encPath(String path) {
        if (path == null || path.isEmpty()) return "";
        String[] parts = path.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append("/");
            sb.append(Api.enc(parts[i]));
        }
        return sb.toString();
    }

    private static void ensureWorkflow(final Activity a, final String full, final String token,
                                       final Runnable back, final WfCb next) {
        final String path = ".github/workflows/" + ProjectBuilder.WORKFLOW_NAME;
        final String url = Api.BASE + "/repos/" + full + "/contents/" + encPath(path);
        Api.request("GET", url, token, null, (found, res) -> MAIN.post(() -> {
            if (a.isFinishing()) return;
            if (found) {
                next.next(false);
                return;
            }
            if (!res.contains("404")) {
                error(a, "Gagal memeriksa alur kerja APK", "Proyek: " + full + "\n\n" + res, back);
                return;
            }
            // Alur kerja belum ada: pasang otomatis tanpa dialog, lalu lanjut membangun APK.
            Toast.makeText(a, "Alur kerja APK belum ada. Memasang otomatis...", Toast.LENGTH_LONG).show();
            String name = full.substring(full.indexOf('/') + 1);
            String slug = ProjectBuilder.slug(name);
            if (slug.isEmpty()) slug = "aplikasi";
            final String slugF = slug;
            ProjectBuilder.workflowUntuk(a, full, token, slugF, (okW, content) -> {
                if (a.isFinishing()) return;
                if (!okW) {
                    error(a, "Gagal memasang alur kerja", content, back);
                    return;
                }
                JSONObject body = Api.o("message", "Pasang alur kerja bangun APK",
                        "content", Base64.encodeToString(content.getBytes(StandardCharsets.UTF_8),
                                Base64.NO_WRAP));
                Api.request("PUT", url, token, body.toString(), (ok2, res2) -> MAIN.post(() -> {
                    if (a.isFinishing()) return;
                    if (ok2) {
                        Toast.makeText(a, "Alur kerja terpasang. APK sedang dibangun.", Toast.LENGTH_SHORT).show();
                        next.next(true);
                    } else {
                        String info = "Proyek: " + full + "\n\nSyarat: proyek Android Gradle dengan modul app.\n\n" + res2;
                        if (res2.toLowerCase().contains("workflow")) {
                            info += "\n\nToken perlu izin workflow. Buat token baru dengan izin repo dan workflow.";
                        }
                        error(a, "Gagal memasang alur kerja", info, back,
                                b("coba lagi", () -> bangunUlang(a, full, token, back)));
                    }
                }));
            });
        }));
    }

    public static void bangunUlang(final Activity a, final String full, final String token, final Runnable back) {
        lastRunId(full, token, idAwal -> ensureWorkflow(a, full, token, back, installed -> {
            if (installed) {
                MAIN.post(() -> pantau(a, full, token, back, idAwal));
                return;
            }
            Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
                if (!ok) {
                    MAIN.post(() -> error(a, "Gagal membaca proyek", "Proyek: " + full + "\n\n" + res, back,
                            b("coba lagi", () -> bangunUlang(a, full, token, back))));
                    return;
                }
                final String branch = Api.parse(res).optString("default_branch", "main");
                String ep = Api.BASE + "/repos/" + full + "/actions/workflows/" + ProjectBuilder.WORKFLOW_NAME
                        + "/dispatches";
                Api.request("POST", ep, token, Api.o("ref", branch).toString(), (ok2, res2) -> MAIN.post(() -> {
                    if (a.isFinishing()) return;
                    if (ok2) {
                        Toast.makeText(a, "Pembangunan APK dimulai.", Toast.LENGTH_SHORT).show();
                        pantau(a, full, token, back, idAwal);
                    } else {
                        String info = "Proyek: " + full + "\nCabang: " + branch + "\n\n" + res2;
                        if (res2.contains("workflow_dispatch")) {
                            info += "\n\nAlur kerja belum punya pemicu workflow_dispatch, jadi tidak bisa dijalankan manual.";
                        }
                        error(a, "Gagal memulai pembangunan APK", info, back,
                                b("coba lagi", () -> bangunUlang(a, full, token, back)));
                    }
                }));
            });
        }));
    }

    // ---------- pembangunan yang ditahan GitHub (action_required) ----------

    private static Btn[] gabung(Btn[] depan, Btn[] belakang) {
        Btn[] h = new Btn[depan.length + belakang.length];
        System.arraycopy(depan, 0, h, 0, depan.length);
        System.arraycopy(belakang, 0, h, depan.length, belakang.length);
        return h;
    }

    /** Tombol untuk pembangunan yang ditahan GitHub: setujui dan jalankan, serta periksa penyebab. */
    private static Btn[] tombolTindakan(final Activity a, final String full, final String token,
                                        final long runId, final Runnable back) {
        return new Btn[]{b("periksa penyebab ditahan", () -> periksaTindakan(a, full, token, runId, back))};
    }

    /** Kumpulkan data dari GitHub untuk menjelaskan kenapa pembangunan ditahan. Semua tampil di aplikasi. */
    public static void periksaTindakan(final Activity a, final String full, final String token,
                                       final long runId, final Runnable back) {
        if (dead(a)) return;
        Toast.makeText(a, "Memeriksa penyebab pembangunan ditahan...", Toast.LENGTH_SHORT).show();
        final StringBuilder sb = new StringBuilder("Proyek: " + full + "\nRun ID: " + runId);
        final String repo = Api.BASE + "/repos/" + full;
        Api.request("GET", repo + "/actions/runs/" + runId, token, null, (ok1, r1) -> MAIN.post(() -> {
            if (dead(a)) return;
            if (ok1) {
                JSONObject ro = Api.parse(r1);
                JSONObject pelaku = ro.optJSONObject("triggering_actor");
                String sha = Api.str(ro, "head_sha");
                sb.append("\n\nPemicu: ").append(Api.str(ro, "event"))
                        .append("\nCabang: ").append(Api.str(ro, "head_branch"))
                        .append("\nKomit: ").append(sha.length() > 7 ? sha.substring(0, 7) : sha)
                        .append("\nPelaku: ").append(pelaku == null ? "-" : Api.str(pelaku, "login"))
                        .append("\nKeterangan: ").append(Api.str(ro, "display_title"));
            } else {
                sb.append("\n\nGagal membaca data pembangunan: ").append(r1);
            }
            Api.request("GET", repo + "/actions/permissions", token, null, (ok2, r2) -> MAIN.post(() -> {
                if (dead(a)) return;
                if (ok2) {
                    JSONObject po = Api.parse(r2);
                    sb.append("\n\nGitHub Actions di repositori: ")
                            .append(po.optBoolean("enabled", true) ? "aktif" : "NONAKTIF")
                            .append("\nTindakan yang diizinkan: ")
                            .append(po.optString("allowed_actions", "semua"));
                } else {
                    sb.append("\n\nIzin Actions tidak terbaca: ").append(r2);
                }
                Api.request("GET", repo + "/actions/workflows/" + ProjectBuilder.WORKFLOW_NAME, token, null,
                        (ok3, r3) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    if (ok3) {
                        sb.append("\n\nStatus berkas alur kerja: ").append(Api.str(Api.parse(r3), "state"));
                    } else {
                        sb.append("\n\nBerkas alur kerja tidak terbaca: ").append(r3);
                    }
                    Api.request("GET", repo + "/actions/runs/" + runId + "/pending_deployments", token, null,
                            (ok4, r4) -> MAIN.post(() -> {
                        if (dead(a)) return;
                        if (ok4) {
                            sb.append("\n\nPersetujuan lingkungan yang menunggu: ").append(Api.parseArr(r4).length());
                        }
                        sb.append("\n\nArti: action_required berarti GitHub menahan proses ini sebelum satu "
                                + "langkah pun berjalan. Kalau tertulis bahwa berkas alur kerja mungkin berbahaya, "
                                + "persetujuan hanya bisa diberikan di halaman proses di situs GitHub (tombol "
                                + "Setujui dan jalankan); API GitHub tidak menyediakannya untuk aplikasi. "
                                + "Alur kerja versi baru dari aplikasi ini tidak lagi mengambil semua secret sekaligus.");
                        error(a, "Penyebab ditahan", sb.toString(), back,
                                b("bangun ulang", () -> bangunUlang(a, full, token, back)));
                    }));
                }));
            }));
        }));
    }

    // ---------- batalkan, jalankan ulang, riwayat pembangunan ----------

    private static String tgl(String iso) {
        if (iso == null) return "";
        if (iso.length() < 16) return iso;
        return iso.substring(0, 10) + " " + iso.substring(11, 16) + " UTC";
    }

    private static void konfirmasi(final Activity a, String title, String msg, String yes, final Runnable onYes) {
        if (dead(a)) return;
        AlertDialog d = new AlertDialog.Builder(a).setTitle(title).setMessage(msg)
                .setPositiveButton(yes, (x, w) -> onYes.run())
                .setNegativeButton("batal", null).show();
        try {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
    }

    /** Batalkan pembangunan yang sedang antre atau berjalan. {@code paksa}: force-cancel untuk yang macet. */
    public static void batalkanRun(final Activity a, final String full, final String token, final long runId,
                                   final boolean paksa, final Runnable back) {
        String ep = Api.BASE + "/repos/" + full + "/actions/runs/" + runId + (paksa ? "/force-cancel" : "/cancel");
        Toast.makeText(a, paksa ? "Mengirim permintaan paksa batal..." : "Mengirim permintaan batal...",
                Toast.LENGTH_SHORT).show();
        Api.request("POST", ep, token, "{}", (ok, res) -> MAIN.post(() -> {
            if (dead(a)) return;
            if (ok) {
                dialog(a, "Permintaan batal terkirim",
                        "Proyek: " + full + "\nPembangunan ID: " + runId
                                + "\n\nGitHub biasanya butuh beberapa detik sampai status berubah menjadi Dibatalkan. "
                                + "Bila setelah 1 sampai 2 menit belum berubah, ulangi dan pilih paksa batal.",
                        list(b("periksa status", () -> cekStatus(a, full, token, back)),
                                b("riwayat pembangunan", () -> riwayat(a, full, token, back))), back);
            } else {
                String info = "Proyek: " + full + "\nPembangunan ID: " + runId + "\n\n" + res;
                if (res.contains("409")) {
                    info += "\n\nPembangunan ini kemungkinan sudah selesai atau sedang dalam proses dibatalkan.";
                } else if (res.contains("403") || res.contains("404")) {
                    info += "\n\nPastikan token punya izin menulis ke repositori (repo) dan Actions.";
                }
                error(a, "Gagal membatalkan pembangunan", info, back,
                        b("periksa status", () -> cekStatus(a, full, token, back)));
            }
        }));
    }

    /**
     * Jalankan ulang satu pembangunan (kode/commit yang sama seperti saat itu).
     * @param hanyaGagal hanya langkah yang gagal
     * @param terbaru true bila ini pembangunan terbaru, supaya hasilnya bisa dipantau otomatis
     */
    public static void jalankanUlangRun(final Activity a, final String full, final String token, final long runId,
                                        final boolean hanyaGagal, final boolean terbaru, final Runnable back) {
        String ep = Api.BASE + "/repos/" + full + "/actions/runs/" + runId
                + (hanyaGagal ? "/rerun-failed-jobs" : "/rerun");
        Toast.makeText(a, "Meminta GitHub menjalankan ulang...", Toast.LENGTH_SHORT).show();
        Api.request("POST", ep, token, "{}", (ok, res) -> MAIN.post(() -> {
            if (dead(a)) return;
            if (!ok) {
                String info = "Proyek: " + full + "\nPembangunan ID: " + runId + "\n\n" + res;
                if (res.contains("403")) {
                    info += "\n\nKemungkinan penyebab: pembangunan sudah lebih dari 30 hari, atau token belum punya "
                            + "izin menulis (repo dan workflow).";
                } else if (res.contains("409") || res.contains("422")) {
                    info += "\n\nGitHub menolak karena pembangunan ini masih berjalan, atau tidak ada bagian yang gagal "
                            + "untuk diulang.";
                }
                error(a, "Gagal menjalankan ulang", info, back,
                        b("coba lagi", () -> jalankanUlangRun(a, full, token, runId, hanyaGagal, terbaru, back)));
                return;
            }
            if (terbaru) {
                Toast.makeText(a, "Pembangunan dijalankan ulang. Mulai memantau...", Toast.LENGTH_SHORT).show();
                // beri GitHub waktu mengubah status dari selesai menjadi antre sebelum dipantau
                MAIN.postDelayed(() -> {
                    if (!dead(a)) pantau(a, full, token, back, Math.max(0, runId - 1));
                }, 4000);
            } else {
                dialog(a, "Dijalankan ulang",
                        "Proyek: " + full + "\nPembangunan ID: " + runId
                                + "\n\nPermintaan diterima. Lihat hasilnya di riwayat pembangunan beberapa saat lagi.",
                        list(b("riwayat pembangunan", () -> riwayat(a, full, token, back))), back);
            }
        }));
    }

    /** Daftar 20 pembangunan terakhir; ketuk satu untuk batalkan, jalankan ulang, atau lihat error. */
    public static void riwayat(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs?per_page=20", token, null, (ok, res) -> MAIN.post(() -> {
            if (dead(a)) return;
            if (!ok) {
                error(a, "Gagal memuat riwayat pembangunan", "Proyek: " + full + "\n\n" + res, back,
                        b("coba lagi", () -> riwayat(a, full, token, back)));
                return;
            }
            JSONArray arr = Api.parse(res).optJSONArray("workflow_runs");
            if (arr == null || arr.length() == 0) {
                dialog(a, "Riwayat pembangunan", "Proyek: " + full
                                + "\n\nBelum ada pembangunan APK. Tekan Bangun APK sekarang.",
                        list(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back))), back);
                return;
            }
            final Runnable kembaliKeDaftar = () -> riwayat(a, full, token, back);
            List<Btn> l = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                final JSONObject r = arr.optJSONObject(i);
                if (r == null) continue;
                final boolean terbaru = i == 0;
                String judul = r.optString("display_title", r.optString("name", ""));
                if (judul.length() > 40) judul = judul.substring(0, 40) + "...";
                String label = "Nomor " + r.optInt("run_number", 0) + ", "
                        + statusText(r.optString("status", ""), Api.str(r, "conclusion"))
                        + ", " + tgl(r.optString("created_at", ""))
                        + (judul.isEmpty() ? "" : ", " + judul);
                l.add(b(label, () -> aksiRun(a, full, token, r, terbaru, kembaliKeDaftar)));
            }
            dialog(a, "Riwayat pembangunan", "Proyek: " + full + "\n" + l.size()
                    + " pembangunan terakhir. Ketuk satu untuk membatalkan, menjalankan ulang, atau melihat error.", l, back);
        }));
    }

    /** Aksi untuk satu pembangunan: batalkan, paksa batal, jalankan ulang, lihat error, unduh. */
    public static void aksiRun(final Activity a, final String full, final String token, final JSONObject run,
                               final boolean terbaru, final Runnable back) {
        if (dead(a)) return;
        final long runId = run.optLong("id", 0);
        final String status = run.optString("status", "");
        final String concl = Api.str(run, "conclusion");
        final String logUrl = run.optString("html_url", "");
        String judul = run.optString("display_title", run.optString("name", ""));
        int percobaan = run.optInt("run_attempt", 1);
        String msg = "Proyek: " + full + "\nPembangunan nomor: " + run.optInt("run_number", 0)
                + (percobaan > 1 ? " (percobaan ke-" + percobaan + ")" : "")
                + (judul.isEmpty() ? "" : "\nKeterangan: " + judul)
                + "\nDimulai: " + tgl(run.optString("created_at", ""))
                + "\nStatus: " + statusText(status, concl);
        List<Btn> l = new ArrayList<>();
        if (!"completed".equals(status)) {
            l.add(b("batalkan pembangunan ini", () -> konfirmasi(a, "Batalkan pembangunan?",
                    "Pembangunan ini dihentikan. Proses yang sudah berjalan tidak bisa dilanjutkan, hanya bisa "
                            + "dijalankan ulang dari awal.", "batalkan",
                    () -> batalkanRun(a, full, token, runId, false, back))));
            l.add(b("paksa batal (bila macet dan batal biasa tidak mempan)", () -> konfirmasi(a,
                    "Paksa batal?", "Paksa batal menghentikan pembangunan tanpa menunggu langkah yang sedang berjalan. "
                            + "Pakai hanya bila batal biasa tidak berhasil.", "paksa batal",
                    () -> batalkanRun(a, full, token, runId, true, back))));
        } else {
            if ("action_required".equals(concl)) {
                l.add(b("periksa penyebab ditahan", () -> periksaTindakan(a, full, token, runId, back)));
            }
            if ("failure".equals(concl)) {
                l.add(b("lihat rincian error", () -> bacaLogError(a, full, token, runId, logUrl, back)));
            }
            l.add(b("jalankan ulang pembangunan ini (rerun)", () -> konfirmasi(a, "Jalankan ulang?",
                    "Pembangunan ini diulang dari awal memakai kode (commit) yang sama seperti saat itu, bukan kode "
                            + "terbaru. Untuk memakai kode terbaru, pakai Bangun APK sekarang.", "jalankan ulang",
                    () -> jalankanUlangRun(a, full, token, runId, false, terbaru, back))));
            if ("failure".equals(concl) || "timed_out".equals(concl) || "cancelled".equals(concl)) {
                l.add(b("jalankan ulang hanya bagian yang gagal",
                        () -> jalankanUlangRun(a, full, token, runId, true, terbaru, back)));
            }
            if ("success".equals(concl) && terbaru) {
                l.add(b("unduh APK", () -> ambilApk(a, full, token, back)));
            }
        }
        if ("completed".equals(status) && "success".equals(concl)) {
            l.add(b("ringkasan pembangunan", () -> ringkasan(a, full, token, run,
                    () -> aksiRun(a, full, token, run, terbaru, back))));
        }
        l.add(b("lihat log lengkap", () -> logRun(a, full, token, run,
                () -> aksiRun(a, full, token, run, terbaru, back))));
        dialog(a, "Pembangunan nomor " + run.optInt("run_number", 0), msg, l, back);
    }

    // ---------- workflow dan log (semua di aplikasi, tanpa browser) ----------

    private static final int HAL = 120; // baris log per halaman
    private static String cariTerakhir = "";

    /** Pusat workflow dan log: log pembangunan dan berkas workflow dilihat di aplikasi. */
    public static void workflowLog(final Activity a, final String full, final String token, final Runnable back) {
        if (dead(a)) return;
        final Runnable ke = () -> workflowLog(a, full, token, back);
        dialog(a, "Workflow dan log", "Proyek: " + full,
                list(b("log pembangunan terbaru", () -> logTerbaru(a, full, token, ke)),
                        b("pilih pembangunan lain", () -> riwayat(a, full, token, ke)),
                        b("berkas workflow", () -> daftarWorkflow(a, full, token, ke))), back);
    }

    private static void logTerbaru(final Activity a, final String full, final String token, final Runnable back) {
        Toast.makeText(a, "Mengambil pembangunan terbaru...", Toast.LENGTH_SHORT).show();
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs?per_page=1", token, null,
                (ok, res) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    if (!ok) {
                        error(a, "Gagal memuat pembangunan", "Proyek: " + full + "\n\n" + res, back,
                                b("coba lagi", () -> logTerbaru(a, full, token, back)));
                        return;
                    }
                    JSONObject run = firstRun(res);
                    if (run == null) {
                        dialog(a, "Belum ada log", "Belum ada pembangunan APK.",
                                list(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back))), back);
                        return;
                    }
                    logRun(a, full, token, run, back);
                }));
    }

    /** Lihat log satu pembangunan di aplikasi. */
    public static void logRun(final Activity a, final String full, final String token, final JSONObject run,
                              final Runnable back) {
        logRun(a, full, token, run.optLong("id", 0), run.optInt("run_number", 0),
                "failure".equals(Api.str(run, "conclusion")), back);
    }

    public static void logRun(final Activity a, final String full, final String token, final long runId,
                              final int nomor, final boolean gagal, final Runnable back) {
        if (dead(a)) return;
        Toast.makeText(a, "Mengambil daftar pekerjaan...", Toast.LENGTH_SHORT).show();
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId + "/jobs", token, null,
                (ok, res) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    if (!ok) {
                        error(a, "Gagal mengambil log", "Proyek: " + full + "\n\n" + res, back,
                                b("coba lagi", () -> logRun(a, full, token, runId, nomor, gagal, back)));
                        return;
                    }
                    JSONArray jobs = Api.parse(res).optJSONArray("jobs");
                    if (jobs == null || jobs.length() == 0) {
                        dialog(a, "Log belum ada", "Pembangunan ini belum punya pekerjaan. Coba lagi sebentar lagi.",
                                list(b("coba lagi", () -> logRun(a, full, token, runId, nomor, gagal, back))), back);
                        return;
                    }
                    if (jobs.length() == 1) {
                        logJob(a, full, token, runId, nomor, gagal, jobs.optJSONObject(0), back);
                        return;
                    }
                    List<Btn> l = new ArrayList<>();
                    for (int i = 0; i < jobs.length(); i++) {
                        final JSONObject j = jobs.optJSONObject(i);
                        if (j == null) continue;
                        l.add(b(j.optString("name", "Pekerjaan") + ", "
                                        + statusText(j.optString("status", ""), Api.str(j, "conclusion")),
                                () -> logJob(a, full, token, runId, nomor, gagal, j,
                                        () -> logRun(a, full, token, runId, nomor, gagal, back))));
                    }
                    dialog(a, "Pilih pekerjaan", "Ada " + l.size() + " pekerjaan. Pilih satu untuk melihat lognya.",
                            l, back);
                }));
    }

    private static void logJob(final Activity a, final String full, final String token, final long runId,
                               final int nomor, final boolean gagal, final JSONObject job, final Runnable back) {
        if (dead(a)) return;
        final long jobId = job.optLong("id", 0);
        final String header = "Proyek: " + full + "\nPembangunan nomor: " + (nomor > 0 ? String.valueOf(nomor) : "-")
                + "\nPekerjaan: " + job.optString("name", "-")
                + "\nStatus: " + statusText(job.optString("status", ""), Api.str(job, "conclusion"));
        final TextView tv = new TextView(a);
        tv.setTextSize(17);
        tv.setText("Mengunduh log...");
        tv.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 16), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
        final AlertDialog pd = new AlertDialog.Builder(a).setTitle("Log pembangunan").setView(tv).show();
        Api.POOL.execute(() -> {
            List<String> lines = null;
            String err = null;
            for (int attempt = 1; attempt <= 3 && lines == null; attempt++) {
                try {
                    lines = fetchLog(Api.BASE + "/repos/" + full + "/actions/jobs/" + jobId + "/logs", token);
                } catch (Exception ex) {
                    err = String.valueOf(ex.getMessage());
                    if (err.startsWith("Kode ")) break;
                    try { Thread.sleep(1200L * attempt); } catch (InterruptedException ignored) { }
                }
            }
            final List<String> fl = lines;
            final String fe = err;
            MAIN.post(() -> {
                try { pd.dismiss(); } catch (Exception ignored) { }
                if (dead(a)) return;
                if (fl == null || fl.isEmpty()) {
                    error(a, "Log tidak bisa dibaca", header + "\n\n"
                                    + (fe == null ? "Log masih kosong. Coba lagi sebentar lagi." : fe), back,
                            b("coba lagi", () -> logJob(a, full, token, runId, nomor, gagal, job, back)));
                    return;
                }
                new LogView(a, full, token, runId, gagal, job, header, fl, back).tampil(fl.size());
            });
        });
    }

    private static String ringkasLangkah(JSONObject job) {
        StringBuilder sb = new StringBuilder();
        JSONArray st = job.optJSONArray("steps");
        for (int i = 0; st != null && i < st.length(); i++) {
            JSONObject s = st.optJSONObject(i);
            if (s == null) continue;
            String c = Api.str(s, "conclusion");
            String t = "skipped".equals(c) ? "Dilewati" : statusText(s.optString("status", ""), c);
            if (sb.length() > 0) sb.append('\n');
            sb.append(s.optInt("number", i + 1)).append(". ").append(s.optString("name", "")).append(": ").append(t);
        }
        return sb.length() == 0 ? "Belum ada data langkah." : sb.toString();
    }

    /** Penampil log per halaman (120 baris), dengan pencarian kata. */
    private static class LogView {
        final Activity a;
        final String full, token, header;
        final long runId;
        final boolean gagal;
        final JSONObject job;
        final List<String> lines;
        final Runnable back;

        LogView(Activity a, String full, String token, long runId, boolean gagal, JSONObject job,
                String header, List<String> lines, Runnable back) {
            this.a = a; this.full = full; this.token = token; this.runId = runId; this.gagal = gagal;
            this.job = job; this.header = header; this.lines = lines; this.back = back;
        }

        /** Tampilkan halaman yang berakhir di baris {@code end} (log selalu dibuka dari akhir). */
        void tampil(int end) {
            if (dead(a)) return;
            final int n = lines.size();
            final int e = Math.max(Math.min(end, n), Math.min(HAL, n));
            final int s = Math.max(0, e - HAL);
            StringBuilder sb = new StringBuilder();
            for (int q = s; q < e; q++) {
                String c = LogAnalyzer.clean(lines.get(q));
                if (c.length() > 300) c = c.substring(0, 300) + "...";
                if (sb.length() > 0) sb.append('\n');
                sb.append(c);
            }
            final String halaman = sb.toString();
            String msg = header + "\n\nBaris " + (s + 1) + " sampai " + e + " dari " + n + ".\n\n" + halaman;
            List<Btn> l = new ArrayList<>();
            if (s > 0) l.add(b(HAL + " baris sebelumnya", () -> tampil(s)));
            if (e < n) l.add(b(HAL + " baris berikutnya", () -> tampil(e + HAL)));
            if (s > 0) l.add(b("ke awal log", () -> tampil(HAL)));
            if (e < n) l.add(b("ke akhir log", () -> tampil(n)));
            l.add(b("cari kata di log", () -> cari(e)));
            if (!cariTerakhir.isEmpty()) l.add(b("cari lagi: " + cariTerakhir, () -> lompat(cariTerakhir, e)));
            l.add(keep("salin halaman ini", () -> Ui.copy(a, "Log halaman ini", header + "\n\n" + halaman)));
            l.add(keep("salin 600 baris terakhir", () -> Ui.copy(a, "Log 600 baris terakhir",
                    header + "\n\n" + LogAnalyzer.tail(lines, 600))));
            l.add(b("daftar langkah", () -> dialog(a, "Langkah pembangunan", ringkasLangkah(job),
                    new ArrayList<Btn>(), "kembali", () -> tampil(e))));
            if (gagal) l.add(b("analisis error", () -> bacaLogError(a, full, token, runId, "", () -> tampil(e))));
            dialog(a, "Log pembangunan", msg, l, "kembali", back, 14);
        }

        void cari(final int e) {
            if (dead(a)) return;
            final EditText et = new EditText(a);
            et.setSingleLine(true);
            et.setTextSize(18);
            et.setHint("kata yang dicari");
            et.setText(cariTerakhir);
            LinearLayout box = new LinearLayout(a);
            box.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 8), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
            box.addView(et, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            AlertDialog d = new AlertDialog.Builder(a).setTitle("Cari di log")
                    .setMessage("Mencari ke bawah dari halaman ini.")
                    .setView(box)
                    .setPositiveButton("cari", (x, w) -> {
                        String k = et.getText().toString().trim();
                        if (k.isEmpty()) {
                            tampil(e);
                            return;
                        }
                        cariTerakhir = k;
                        lompat(k, e);
                    })
                    .setNegativeButton("batal", (x, w) -> tampil(e))
                    .show();
            try {
                d.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
                d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            } catch (Exception ignored) { }
        }

        void lompat(String kata, int dari) {
            final String k = kata.toLowerCase();
            final int n = lines.size();
            int m = -1;
            boolean putar = false;
            for (int i = dari; i < n && m < 0; i++) {
                if (LogAnalyzer.clean(lines.get(i)).toLowerCase().contains(k)) m = i;
            }
            for (int i = 0; i < Math.min(dari, n) && m < 0; i++) {
                if (LogAnalyzer.clean(lines.get(i)).toLowerCase().contains(k)) {
                    m = i;
                    putar = true;
                }
            }
            if (m < 0) {
                Toast.makeText(a, "Kata \"" + kata + "\" tidak ditemukan.", Toast.LENGTH_LONG).show();
                tampil(dari);
                return;
            }
            Toast.makeText(a, "Ditemukan di baris " + (m + 1) + (putar ? " (mulai dari awal)" : "") + ".",
                    Toast.LENGTH_LONG).show();
            tampil(Math.max(0, m - 5) + HAL);
        }
    }

    private static void daftarWorkflow(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/workflows", token, null,
                (ok, res) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    if (!ok) {
                        error(a, "Gagal memuat workflow", "Proyek: " + full + "\n\n" + res, back,
                                b("coba lagi", () -> daftarWorkflow(a, full, token, back)));
                        return;
                    }
                    JSONArray w = Api.parse(res).optJSONArray("workflows");
                    if (w == null || w.length() == 0) {
                        dialog(a, "Belum ada workflow", "Repositori ini belum punya workflow. Tekan Bangun APK untuk memasangnya.",
                                list(b("bangun APK sekarang", () -> TandaTanganRepo.mulai(a, full, token, back))), back);
                        return;
                    }
                    final Runnable ke = () -> daftarWorkflow(a, full, token, back);
                    List<Btn> l = new ArrayList<>();
                    for (int i = 0; i < w.length(); i++) {
                        final JSONObject o = w.optJSONObject(i);
                        if (o == null) continue;
                        final String path = o.optString("path", "");
                        String label = o.optString("name", path) + ", " + path
                                + ("active".equals(o.optString("state", "")) ? "" : ", nonaktif");
                        l.add(b(label, () -> bukaWorkflow(a, full, token, path, ke)));
                    }
                    dialog(a, "Berkas workflow", "Proyek: " + full + "\nKetuk satu untuk melihat dan mengedit isinya.",
                            l, back);
                }));
    }

    private static void bukaWorkflow(final Activity a, final String full, final String token, final String path,
                                     final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/contents/" + encPath(path), token, null,
                (ok, res) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    if (!ok) {
                        error(a, "Gagal membuka workflow", "Berkas: " + path + "\n\n" + res, back);
                        return;
                    }
                    a.startActivity(new Intent(a, EditActivity.class)
                            .putExtra("repo", full).putExtra("path", path)
                            .putExtra("sha", Api.parse(res).optString("sha", "")).putExtra("new", false));
                }));
    }


    // ---------- ringkasan pembangunan ----------

    private static long detik(String iso) {
        if (iso == null || iso.length() < 19) return -1;
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(iso.substring(0, 19)).getTime() / 1000L;
        } catch (Exception e) {
            return -1;
        }
    }

    private static String lama(long dari, long sampai) {
        if (dari < 0 || sampai < 0 || sampai < dari) return "-";
        long d = sampai - dari;
        if (d < 60) return d + " dtk";
        return (d / 60) + " mnt " + (d % 60) + " dtk";
    }

    private static String potong(String x, int maks) {
        return x.length() > maks ? x.substring(0, maks) + "..." : x;
    }

    /** Ringkasan satu pembangunan: waktu, hasil (artefak), langkah dan lamanya, serta baris penting dari log. */
    public static void ringkasan(final Activity a, final String full, final String token, final JSONObject run,
                                 final Runnable back) {
        if (dead(a)) return;
        final long runId = run.optLong("id", 0);
        Toast.makeText(a, "Menyusun ringkasan...", Toast.LENGTH_SHORT).show();
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId + "/jobs?per_page=30", token, null,
                (okJ, resJ) -> {
                    final JSONArray jobs = okJ ? Api.parse(resJ).optJSONArray("jobs") : null;
                    Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId
                            + "/artifacts?per_page=100", token, null, (okA, resA) -> {
                        final JSONArray arts = okA ? Api.parse(resA).optJSONArray("artifacts") : null;
                        Api.POOL.execute(() -> {
                            // Baris penting dari log pekerjaan pertama (bila bisa dibaca).
                            final List<String> penting = new ArrayList<>();
                            int peringatan = 0;
                            if (jobs != null && jobs.length() > 0) {
                                long jobId = jobs.optJSONObject(0).optLong("id", 0);
                                try {
                                    List<String> lines = fetchLog(Api.BASE + "/repos/" + full + "/actions/jobs/"
                                            + jobId + "/logs", token);
                                    String[] kunci = {"build successful", "model masuk assets", "hasil:",
                                            "selisih relatif", "peringatan:", "ukuran model asli", "mode int8",
                                            "mode fp16", "dikecilkan="};
                                    for (String raw : lines) {
                                        String c = LogAnalyzer.clean(raw).trim();
                                        if (c.isEmpty()) continue;
                                        String lc = c.toLowerCase();
                                        if (lc.contains("warning:") || lc.contains("##[warning]")) peringatan++;
                                        boolean cocok = lc.startsWith("-rw") && lc.contains(".apk");
                                        for (String k : kunci) if (lc.contains(k)) cocok = true;
                                        if (cocok && !penting.contains(c) && penting.size() < 15) penting.add(potong(c, 200));
                                    }
                                } catch (Exception ignored) { }
                            }
                            final int fp = peringatan;
                            MAIN.post(() -> {
                                if (dead(a)) return;
                                StringBuilder sb = new StringBuilder();
                                sb.append("Proyek: ").append(full)
                                        .append("\nPembangunan nomor: ").append(run.optInt("run_number", 0));
                                String judul = run.optString("display_title", run.optString("name", ""));
                                if (!judul.isEmpty()) sb.append("\nKeterangan: ").append(judul);
                                String mulai = run.optString("run_started_at", run.optString("created_at", ""));
                                sb.append("\nStatus: ").append(statusText(run.optString("status", ""), Api.str(run, "conclusion")))
                                        .append("\nDimulai: ").append(tgl(mulai))
                                        .append("\nLama total: ").append(lama(detik(mulai), detik(run.optString("updated_at", ""))));

                                sb.append("\n\nHasil (artefak):");
                                if (arts == null || arts.length() == 0) {
                                    sb.append("\nTidak ada artefak (belum ada, sudah kedaluwarsa, atau sudah dihapus).");
                                } else {
                                    for (int i = 0; i < arts.length(); i++) {
                                        JSONObject it = arts.optJSONObject(i);
                                        if (it == null) continue;
                                        sb.append("\n").append(i + 1).append(". ").append(it.optString("name", "-"))
                                                .append(", ").append(Ui.size(it.optLong("size_in_bytes", 0)))
                                                .append(it.optBoolean("expired", false) ? " (kedaluwarsa)" : "");
                                    }
                                }

                                sb.append("\n\nLangkah dan lamanya:");
                                if (jobs == null || jobs.length() == 0) {
                                    sb.append("\nRincian langkah tidak bisa dibaca.");
                                } else {
                                    for (int i = 0; i < jobs.length(); i++) {
                                        JSONObject j = jobs.optJSONObject(i);
                                        if (j == null) continue;
                                        sb.append("\nPekerjaan ").append(j.optString("name", "-")).append(", ")
                                                .append(lama(detik(j.optString("started_at", "")),
                                                        detik(j.optString("completed_at", ""))));
                                        JSONArray st = j.optJSONArray("steps");
                                        if (st == null) continue;
                                        for (int k = 0; k < st.length(); k++) {
                                            JSONObject x = st.optJSONObject(k);
                                            if (x == null) continue;
                                            String h = Api.str(x, "conclusion");
                                            sb.append("\n  ").append(x.optInt("number", k + 1)).append(". ")
                                                    .append(x.optString("name", "-")).append(": ")
                                                    .append(lama(detik(x.optString("started_at", "")),
                                                            detik(x.optString("completed_at", ""))));
                                            if (!h.isEmpty() && !"success".equals(h)) sb.append(" (").append(h).append(")");
                                        }
                                    }
                                }

                                sb.append("\n\nBaris penting dari log:");
                                if (penting.isEmpty()) {
                                    sb.append("\nTidak ada baris penting yang dikenali, atau log tidak bisa dibaca.");
                                } else {
                                    for (String p : penting) sb.append("\n- ").append(p);
                                }
                                sb.append("\n\nPeringatan di log: ").append(fp).append(" baris");
                                if (fp > 0) sb.append(" (cari kata warning di log lengkap)");

                                final String teks = sb.toString();
                                dialog(a, "Ringkasan pembangunan", teks,
                                        list(b("unduh APK", () -> ambilApk(a, full, token, back)),
                                                b("lihat log lengkap", () -> logRun(a, full, token, run, () ->
                                                        ringkasan(a, full, token, run, back))),
                                                keep("salin ringkasan", () -> Ui.copy(a, "Ringkasan pembangunan", teks))),
                                        "kembali", back, 14);
                            });
                        });
                    });
                });
    }

    // ---------- unduh APK ----------

    /**
     * Unduh APK terbaru. Bila rilis (Releases) lebih lama daripada pembangunan sukses terakhir, yang diunduh
     * adalah artefak pembangunan terakhir itu (bukan APK rilis lama).
     */
    public static void ambilApk(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs?status=success&per_page=1", token, null,
                (okRun, resRun) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    final JSONObject run = okRun ? firstRun(resRun) : null;
                    if (run == null) {
                        ambilApkLama(a, full, token, back);
                        return;
                    }
                    Api.request("GET", Api.BASE + "/repos/" + full + "/releases/latest", token, null,
                            (okRel, resRel) -> MAIN.post(() -> {
                                if (dead(a)) return;
                                String waktuRilis = "";
                                if (okRel) {
                                    JSONArray assets = Api.parse(resRel).optJSONArray("assets");
                                    if (assets != null) {
                                        for (int i = 0; i < assets.length(); i++) {
                                            JSONObject it = assets.optJSONObject(i);
                                            if (it == null || !it.optString("name", "").toLowerCase().endsWith(".apk")) continue;
                                            String t = it.optString("updated_at", it.optString("created_at", ""));
                                            if (t.compareTo(waktuRilis) > 0) waktuRilis = t;
                                        }
                                    }
                                }
                                final String waktuRun = run.optString("updated_at", "");
                                if (waktuRilis.isEmpty() || waktuRun.compareTo(waktuRilis) > 0) {
                                    ambilDariRun(a, full, token, run, !waktuRilis.isEmpty(), back);
                                } else {
                                    ambilApkLama(a, full, token, back);
                                }
                            }));
                }));
    }

    /** Artefak dari satu pembangunan (yang terakhir sukses). Bila kosong atau kedaluwarsa, pakai cara lama. */
    private static void ambilDariRun(final Activity a, final String full, final String token, final JSONObject run,
                                     final boolean rilisLebihLama, final Runnable back) {
        final long runId = run.optLong("id", 0);
        final int nomor = run.optInt("run_number", 0);
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/runs/" + runId + "/artifacts?per_page=100",
                token, null, (ok, res) -> MAIN.post(() -> {
                    if (dead(a)) return;
                    JSONArray semua = ok ? Api.parse(res).optJSONArray("artifacts") : null;
                    final JSONArray aktif = new JSONArray();
                    if (semua != null) {
                        for (int i = 0; i < semua.length(); i++) {
                            JSONObject it = semua.optJSONObject(i);
                            if (it != null && !it.optBoolean("expired", false)) aktif.put(it);
                        }
                    }
                    if (aktif.length() == 0) {
                        ambilApkLama(a, full, token, back);
                        return;
                    }
                    if (rilisLebihLama) {
                        Toast.makeText(a, "Rilis lebih lama dari pembangunan nomor " + nomor
                                + ". Mengunduh dari pembangunan terbaru.", Toast.LENGTH_LONG).show();
                    } else if (aktif.length() > 1) {
                        Toast.makeText(a, "Pembangunan nomor " + nomor + " punya " + aktif.length()
                                + " berkas. Pilih salah satu.", Toast.LENGTH_LONG).show();
                    }
                    if (aktif.length() == 1) {
                        JSONObject it = aktif.optJSONObject(0);
                        download(a, it.optString("archive_download_url", ""),
                                it.optString("name", "aplikasi-apk"), token, true, false, null, back);
                        return;
                    }
                    pickArtifact(a, full, token, aktif, back);
                }));
    }

    private static void ambilApkLama(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full + "/releases/latest", token, null, (okRel, resRel) -> {
            if (okRel) {
                JSONObject r = Api.parse(resRel);
                JSONArray assets = r.optJSONArray("assets");
                if (assets != null && assets.length() > 0) {
                    JSONObject target = null;
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject it = assets.optJSONObject(i);
                        if (it != null && it.optString("name", "").toLowerCase().endsWith(".apk")) {
                            target = it;
                            break;
                        }
                    }
                    if (target == null) target = assets.optJSONObject(0);
                    final JSONObject finalTarget = target;
                    MAIN.post(() -> {
                        if (a.isFinishing()) return;
                        final String name = finalTarget.optString("name", "aplikasi.apk");
                        final String link = finalTarget.optString("browser_download_url", "");
                        String apiUrl = finalTarget.optString("url", "");
                        final String dl = apiUrl.isEmpty() ? link : apiUrl;
                        // Satu ketukan: langsung mengunduh APK terbaru tanpa dialog "APK Siap Diunduh".
                        download(a, dl, name, token, false, true, link, back);
                    });
                    return;
                }
            }
            Api.request("GET", Api.BASE + "/repos/" + full + "/actions/artifacts?per_page=20", token, null,
                    (okArt, resArt) -> MAIN.post(() -> {
                        if (a.isFinishing()) return;
                        final JSONArray arts = okArt ? Api.parse(resArt).optJSONArray("artifacts") : null;
                        if (arts != null && arts.length() == 1) {
                            JSONObject it = arts.optJSONObject(0);
                            download(a, it.optString("archive_download_url", ""),
                                    it.optString("name", "aplikasi-apk"), token, true, false, null,
                                    () -> ambilApk(a, full, token, back));
                            return;
                        }
                        if (arts != null && arts.length() > 1) {
                            pickArtifact(a, full, token, arts, back);
                            return;
                        }
                        Btn[] more = {
                                b("cek status pembangunan", () -> cekStatus(a, full, token, back)),
                                b("lihat workflow dan log", () -> workflowLog(a, full, token, back))};
                        if (!okArt) {
                            error(a, "Gagal mengambil APK", "Proyek: " + full + "\n\nRilis: " + resRel
                                    + "\nArtefak: " + resArt, back, more);
                        } else {
                            dialog(a, "APK Belum Siap", "Belum ada APK. Build mungkin belum selesai. Cek status pembangunan.", list(more), back);
                        }
                    }));
        });
    }

    // ---------- hapus artefak ----------

    /**
     * Daftar artefak build repo (maks. 100) dengan kotak centang, lalu hapus yang dicentang.
     * Artefak hanya salinan sementara hasil build; APK di Releases tidak ikut terhapus.
     * Menghapus artefak membebaskan kuota penyimpanan artefak GitHub.
     */
    public static void hapusArtefak(final Activity a, final String full, final String token, final Runnable back) {
        Toast.makeText(a, "Mengambil daftar artefak...", Toast.LENGTH_SHORT).show();
        Api.request("GET", Api.BASE + "/repos/" + full + "/actions/artifacts?per_page=100", token, null, (ok, res) -> {
            if (dead(a)) return;
            if (!ok) {
                error(a, "Gagal mengambil daftar artefak", "Proyek: " + full + "\n\n" + res, back);
                return;
            }
            final JSONArray arts = Api.parse(res).optJSONArray("artifacts");
            if (arts == null || arts.length() == 0) {
                dialog(a, "Tidak Ada Artefak", "Repo ini tidak punya artefak.", new ArrayList<Btn>(), back);
                return;
            }
            tampilHapusArtefak(a, full, token, arts, back);
        });
    }

    private static void tampilHapusArtefak(final Activity a, final String full, final String token,
                                           final JSONArray arts, final Runnable back) {
        final int n = arts.length();
        final String[] names = new String[n];
        final long[] ids = new long[n];
        final boolean[] sel = new boolean[n];
        long total = 0;
        for (int i = 0; i < n; i++) {
            JSONObject it = arts.optJSONObject(i);
            ids[i] = it == null ? 0 : it.optLong("id", 0);
            long sz = it == null ? 0 : it.optLong("size_in_bytes", 0);
            total += sz;
            String tgl = it == null ? "" : it.optString("created_at", "").split("T")[0];
            names[i] = (it == null ? "?" : it.optString("name", "?")) + " (" + Ui.size(sz) + ", " + tgl + ")";
        }
        final AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("Hapus Artefak (" + n + ", total " + Ui.size(total) + ")")
                .setMultiChoiceItems(names, sel, (x, which, checked) -> sel[which] = checked)
                .setPositiveButton("hapus yang dicentang", null)
                .setNeutralButton("centang semua", null)
                .setNegativeButton("kembali", (x, w) -> { if (back != null) back.run(); })
                .show();
        try {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
        // Tombol centang semua dan hapus tidak menutup dialog daftar sebelum waktunya.
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
            boolean semua = true;
            for (boolean s : sel) if (!s) { semua = false; break; }
            for (int i = 0; i < n; i++) {
                sel[i] = !semua;
                d.getListView().setItemChecked(i, !semua);
            }
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setText(semua ? "centang semua" : "hapus centang semua");
        });
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            final List<Long> pilih = new ArrayList<>();
            for (int i = 0; i < n; i++) if (sel[i] && ids[i] != 0) pilih.add(ids[i]);
            if (pilih.isEmpty()) {
                Toast.makeText(a, "Belum ada artefak yang dicentang.", Toast.LENGTH_SHORT).show();
                return;
            }
            AlertDialog c = new AlertDialog.Builder(a).setTitle("Hapus " + pilih.size() + " artefak?")
                    .setMessage("Artefak tidak bisa dikembalikan. APK di Releases tidak ikut terhapus.")
                    .setPositiveButton("hapus", (x, w) -> {
                        d.dismiss();
                        hapusBerurutan(a, full, token, pilih, back);
                    })
                    .setNegativeButton("batal", null).show();
            try {
                c.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
                c.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            } catch (Exception ignored) { }
        });
    }

    private static void hapusBerurutan(final Activity a, final String full, final String token,
                                       final List<Long> ids, final Runnable back) {
        final AlertDialog pd = new AlertDialog.Builder(a).setTitle("Menghapus artefak")
                .setMessage("Menghapus 1 dari " + ids.size() + "...").setCancelable(false).show();
        hapusSatu(a, full, token, ids, 0, 0, "", pd, back);
    }

    private static void hapusSatu(final Activity a, final String full, final String token, final List<Long> ids,
                                  final int idx, final int berhasil, final String galat, final AlertDialog pd,
                                  final Runnable back) {
        if (idx >= ids.size()) {
            try { pd.dismiss(); } catch (Exception ignored) { }
            if (dead(a)) return;
            final int gagal = ids.size() - berhasil;
            String msg = berhasil + " artefak berhasil dihapus." + (gagal > 0 ? "\n" + gagal + " gagal dihapus.\n\n" + galat : "")
                    + "\n\nKuota GitHub diperbarui tiap 6-12 jam, jadi hasilnya mungkin belum terlihat.";
            if (gagal > 0) error(a, "Selesai dengan kendala", msg, back);
            else dialog(a, "Artefak Terhapus", msg, new ArrayList<Btn>(), back);
            return;
        }
        if (dead(a)) { try { pd.dismiss(); } catch (Exception ignored) { } return; }
        try { pd.setMessage("Menghapus " + (idx + 1) + " dari " + ids.size() + "..."); } catch (Exception ignored) { }
        Api.request("DELETE", Api.BASE + "/repos/" + full + "/actions/artifacts/" + ids.get(idx), token, null,
                (ok, res) -> hapusSatu(a, full, token, ids, idx + 1, berhasil + (ok ? 1 : 0),
                        ok || !galat.isEmpty() ? galat : res, pd, back));
    }

    // ---------- hapus semua artefak di semua repositori ----------

    /**
     * Hapus SEMUA artefak di SEMUA repositori milik akun ini. Berjalan sebagai layanan latar depan
     * (tetap jalan saat pindah aplikasi), dengan konfirmasi, notifikasi kemajuan, dan tombol hentikan.
     */
    public static void hapusSemuaArtefak(final Activity a, final String token, final Runnable back) {
        if (HapusArtefakService.busy()) {
            progresHapusSemua(a, back);
            return;
        }
        AlertDialog c = new AlertDialog.Builder(a).setTitle("Hapus semua artefak?")
                .setMessage("Artefak di SEMUA repositori Anda dihapus dan tidak bisa dikembalikan. "
                        + "APK di Releases tidak ikut terhapus.\n\nBerjalan di latar belakang. Anda diberi notifikasi saat selesai.")
                .setPositiveButton("hapus semua", (x, w) -> {
                    askNotif(a);
                    if (!HapusArtefakService.start(a, token)) {
                        error(a, "Penghapusan latar belakang tidak bisa dimulai",
                                "Layanan belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.", back);
                        return;
                    }
                    progresHapusSemua(a, back);
                })
                .setNegativeButton("batal", (x, w) -> { if (back != null) back.run(); }).show();
        try {
            c.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
            c.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
    }

    /** Dialog kemajuan; menutupnya (sembunyikan) tidak menghentikan penghapusan. */
    private static void progresHapusSemua(final Activity a, final Runnable back) {
        final TextView tv = new TextView(a);
        tv.setTextSize(17);
        String t = HapusArtefakService.lastText;
        tv.setText(t == null || t.isEmpty() ? "Memulai penghapusan..." : t);
        tv.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 16), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
        keepOn(a, true);
        final AlertDialog[] pd = new AlertDialog[1];
        final HapusArtefakService.Listener[] self = new HapusArtefakService.Listener[1];
        self[0] = new HapusArtefakService.Listener() {
            @Override public void onStatus(String text) {
                if (dead(a)) { if (HapusArtefakService.listener == self[0]) HapusArtefakService.listener = null; return; }
                tv.setText(text);
            }
            @Override public void onFinished() {
                if (HapusArtefakService.listener == self[0]) HapusArtefakService.listener = null;
                try { if (pd[0] != null) pd[0].dismiss(); } catch (Exception ignored) { }
                if (!dead(a) && App.visible()) tampilkanHasilTertunda(a, back);
            }
        };
        pd[0] = new AlertDialog.Builder(a).setTitle("Menghapus semua artefak").setView(tv)
                .setNeutralButton("sembunyikan", null)
                .setNegativeButton("hentikan", null)
                .setOnDismissListener(x -> {
                    if (HapusArtefakService.listener == self[0]) HapusArtefakService.listener = null;
                    keepOn(a, false);
                })
                .show();
        try {
            pd[0].getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            pd[0].getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
        } catch (Exception ignored) { }
        // Tombol hentikan tidak menutup dialog: ringkasan hasil tampil di sini begitu proses berhenti.
        pd[0].getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            HapusArtefakService.cancel(a);
            pd[0].getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(false);
            tv.setText("Menghentikan penghapusan...");
        });
        HapusArtefakService.listener = self[0];
        // Bila layanan sudah selesai sebelum pendengar terpasang, langsung tampilkan hasilnya.
        if (!HapusArtefakService.busy()) self[0].onFinished();
    }

    private static void hasilHapusSemua(final Activity a, final HapusArtefakService.Hasil r, final Runnable back) {
        if (r.gagal) error(a, "Selesai dengan kendala", r.message, back);
        else dialog(a, "Selesai", r.message, new ArrayList<Btn>(), back);
    }

    private static void pickArtifact(final Activity a, final String full, final String token, final JSONArray arts,
                                     final Runnable back) {
        final String[] names = new String[arts.length()];
        for (int i = 0; i < names.length; i++) {
            JSONObject it = arts.optJSONObject(i);
            names[i] = (i + 1) + ". " + it.optString("name", "") + " (" + Ui.size(it.optLong("size_in_bytes", 0)) + ")";
        }
        AlertDialog d = new AlertDialog.Builder(a).setTitle("Pilih Berkas Artefak (" + names.length + ")")
                .setItems(names, (x, which) -> {
                    JSONObject it = arts.optJSONObject(which);
                    final String artName = it.optString("name", "aplikasi-apk");
                    final String artUrl = it.optString("archive_download_url", "");
                    final Runnable again = () -> ambilApk(a, full, token, back);
                    download(a, artUrl, artName, token, true, false, null, again);
                })
                .setNegativeButton("kembali", (x, w) -> { if (back != null) back.run(); }).show();
        try { d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false); } catch (Exception ignored) { }
    }

    static void download(final Activity a, final String url, final String name, final String token,
                                 final boolean zip, final boolean octet, final String fallback, final Runnable back) {
        Runnable go = () -> {
            if (dead(a)) return;
            if (DownloadService.busy()) {
                error(a, "Unduhan lain masih berjalan",
                        "Tunggu unduhan sebelumnya selesai atau batalkan lewat notifikasi.",
                        back);
                return;
            }
            askNotif(a);
            if (!DownloadService.start(a, url, token, name, zip, octet, fallback)) {
                error(a, "Unduhan latar belakang tidak bisa dimulai",
                        "Unduhan belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.\nBerkas: " + name, back,
                        b("coba lagi", () -> download(a, url, name, token, zip, octet, fallback, back)));
                return;
            }
            final TextView tv = new TextView(a);
            tv.setTextSize(17);
            tv.setText("Sedang mengunduh " + name + " ke folder Download...\n\nBoleh pindah aplikasi. Anda diberi notifikasi saat selesai.");
            tv.setPadding(Ui.dpOf(a, 20), Ui.dpOf(a, 16), Ui.dpOf(a, 20), Ui.dpOf(a, 8));
            keepOn(a, true);
            final AlertDialog[] pd = new AlertDialog[1];
            final DownloadService.Listener[] self = new DownloadService.Listener[1];
            self[0] = new DownloadService.Listener() {
                @Override public void onStatus(String text) {
                    if (dead(a)) { if (DownloadService.listener == self[0]) DownloadService.listener = null; return; }
                    tv.setText(text);
                }
                @Override public void onFinished() {
                    if (DownloadService.listener == self[0]) DownloadService.listener = null;
                    try { if (pd[0] != null) pd[0].dismiss(); } catch (Exception ignored) { }
                    // Bila aplikasi sedang tidak tampil, hasil ditampilkan saat layar aplikasi dibuka lagi.
                    if (!dead(a) && App.visible()) tampilkanHasilTertunda(a, back);
                }
            };
            pd[0] = new AlertDialog.Builder(a).setTitle("Mengunduh APK").setView(tv)
                    .setNeutralButton("sembunyikan", null)
                    .setNegativeButton("batalkan unduhan", (x, w) -> {
                        DownloadService.cancel(a);
                        Toast.makeText(a, "Unduhan dibatalkan.", Toast.LENGTH_SHORT).show();
                        if (back != null) back.run();
                    })
                    .setOnDismissListener(x -> {
                        // Menutup dialog tidak menghentikan unduhan; hanya tombol batalkan yang menghentikan.
                        if (DownloadService.listener == self[0]) DownloadService.listener = null;
                        keepOn(a, false);
                    })
                    .show();
            try {
                pd[0].getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
                pd[0].getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
            } catch (Exception ignored) { }
            DownloadService.listener = self[0];
        };
        if (a instanceof BaseActivity) ((BaseActivity) a).withStorage(go); else go.run();
    }

    private static String pathOf(Saver.Target t) {
        return t.file != null ? t.file.getAbsolutePath() : "Download/" + t.name;
    }

    private static void saved(final Activity a, final Saver.Target t, Runnable back) {
        final String path = pathOf(t);
        dialog(a, "APK Berhasil Disimpan", "Berkas APK berhasil diunduh ke folder Download:\n\n" + path,
                list(b("pasang APK sekarang", () -> install(a, t)),
                        b("buka folder Download", () -> openDownloads(a)),
                        keep("salin lokasi berkas", () -> Ui.copy(a, "Lokasi APK", path))), "tutup", back);
    }

    private static void openDownloads(Activity a) {
        try {
            a.startActivity(new Intent("android.intent.action.VIEW_DOWNLOADS"));
        } catch (Exception e) {
            Toast.makeText(a, "Buka aplikasi File lalu folder Download.", Toast.LENGTH_LONG).show();
        }
    }

    private static void install(Activity a, Saver.Target t) {
        try {
            Uri uri;
            if (t.uri != null) {
                uri = t.uri;
            } else {
                File f = t.file;
                if (Build.VERSION.SDK_INT >= 24) {
                    android.os.StrictMode.class.getMethod("disableDeathOnFileUriExposure").invoke(null);
                }
                uri = Uri.fromFile(f);
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(a, "Pemasang tidak terbuka. Pilih berkas APK di folder Download.", Toast.LENGTH_LONG).show();
            openDownloads(a);
        }
    }
}
