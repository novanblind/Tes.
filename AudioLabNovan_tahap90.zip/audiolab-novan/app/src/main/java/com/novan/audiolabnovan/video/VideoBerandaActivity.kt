package com.novan.audiolabnovan.video

import android.content.Intent
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import com.novan.audiolabnovan.BerandaActivity
import com.novan.audiolabnovan.Fitur
import com.novan.audiolabnovan.R

/**
 * Tahap 85: kisi "Alat Video". Setiap tombol membuka halaman alatnya sendiri,
 * tempat memilih video dan mengatur opsi, sama seperti kisi fitur audio di halaman utama.
 */
class VideoBerandaActivity : BerandaActivity() {

    override fun daftarTampil(): List<Fitur.Def> = VideoFitur.daftar

    override fun tambahHeader(akar: LinearLayout) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(warna(R.color.bar_bg))
            setPadding(dp(8), dp(10), dp(16), dp(10))
        }
        val kembali = TextView(this).apply {
            text = "\u2190"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(warna(R.color.bar_teks))
            contentDescription = "Kembali"
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        bar.addView(kembali, LinearLayout.LayoutParams(dp(48), dp(48)))
        val judul = TextView(this).apply {
            text = "Alat Video"
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(warna(R.color.bar_teks))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        bar.addView(judul, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        akar.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    override fun buka(d: Fitur.Def) {
        val tujuan = d.tujuan ?: AlatVideoActivity::class.java
        startActivity(
            Intent(this, tujuan)
                .putExtra(VideoFitur.EXTRA, d.id)
                .putExtra(VideoFitur.EXTRA_JUDUL, d.judul)
        )
    }
}
