package id.ytplayer

import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/** Pengunduh HTTP sederhana (HttpURLConnection) untuk NewPipeExtractor. */
object DownloaderImpl : Downloader() {

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: Request): Response {
        val conn = URL(request.url()).openConnection() as HttpURLConnection
        var ok = false
        try {
            conn.requestMethod = request.httpMethod()
            conn.connectTimeout = 30_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)

            for ((name, values) in request.headers()) {
                values.forEachIndexed { i, v ->
                    if (i == 0) conn.setRequestProperty(name, v) else conn.addRequestProperty(name, v)
                }
            }

            val data = request.dataToSend()
            if (data != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(data.size)
                conn.outputStream.use { it.write(data) }
            }

            val code = conn.responseCode
            if (code == 429) {
                throw ReCaptchaException("Permintaan dibatasi (HTTP 429)", request.url())
            }

            val raw = if (code >= 400) conn.errorStream else conn.inputStream
            val body = raw?.let { s ->
                val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) GZIPInputStream(s) else s
                stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } ?: ""

            val headers = HashMap<String, List<String>>()
            for ((k, v) in conn.headerFields) {
                if (k != null) headers[k] = v
            }
            ok = true
            return Response(code, conn.responseMessage ?: "", headers, body, conn.url.toString())
        } finally {
            // Badan respons sudah dibaca habis & ditutup → koneksi dikembalikan ke kolam keep-alive
            // dan dipakai ulang permintaan berikutnya (tanpa jabat tangan TLS baru).
            // disconnect() hanya bila gagal.
            if (!ok) conn.disconnect()
        }
    }
}
