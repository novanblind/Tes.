package com.novan.githubbynovan;

import android.app.Activity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/**
 * Memasang kelas KunciTandaTangan.java ke repositori yang sudah ada, agar tersedia untuk
 * mengenkripsi data/fitur penting dengan kunci yang diturunkan dari sidik jari tanda tangan asli.
 * Alur kerja (GitHub Actions) yang menyematkan rahasia saat build dipastikan memakai versi terbaru.
 */
public class LindungiKunci {
    private static final String SKIP = " [skip ci]";
    private static final String[] AKAR = {"/src/main/java/", "/src/main/kotlin/"};

    public static void mulai(final Activity a, final String full, final String token, final Runnable back) {
        String msg = "Proyek: " + full
                + "\n\nAplikasi menambahkan kelas KunciTandaTangan.java ke proyek, lalu memperbarui alur kerja bila perlu."
                + "\n\nPakai di kode Anda: KunciTandaTangan.enkripsiTeks(this, teks) untuk menulis, "
                + "dan KunciTandaTangan.dekripsiTeksAtauNull(this, hasil) untuk membaca."
                + "\n\nUntuk teks tetap di kode, bungkus dengan KunciTandaTangan.s(\"teks\"). "
                + "Saat build dengan tanda tangan pribadi, teks itu dienkripsi otomatis."
                + "\n\nAtau centang \"Aktifkan enkripsi string otomatis\" di dialog Kirim tanda tangan ke repo, "
                + "tanpa perlu menandai teks."
                + "\n\nKunci diturunkan dari tanda tangan APK. Bila APK ditandatangani ulang orang lain, "
                + "data terenkripsi tidak bisa dibaca."
                + "\n\nTidak aktif untuk tanda tangan bawaan GitHub. Pilih tanda tangan pribadi saat Mulai pembangunan APK."
                + "\n\nSyarat: ada MainActivity.java atau .kt di src/main/java atau src/main/kotlin.";
        ApkTools.dialog(a, "Kunci terikat tanda tangan", msg, ApkTools.list(
                ApkTools.b("pasang kelas kunci", () -> cari(a, full, token, back))), "batal", back);
    }

    /** Langkah 1: cari lokasi MainActivity dari pohon repo untuk menentukan paket. */
    private static void cari(final Activity a, final String full, final String token, final Runnable back) {
        Api.request("GET", Api.BASE + "/repos/" + full, token, null, (ok, res) -> {
            if (!ok) {
                TandaTanganRepo.gagal(a, "Gagal membaca repositori", full, res, back);
                return;
            }
            String branch = Api.parse(res).optString("default_branch", "main");
            Api.request("GET", Api.BASE + "/repos/" + full + "/git/trees/" + branch + "?recursive=1", token, null,
                    (ok2, r2) -> {
                        if (!ok2) {
                            TandaTanganRepo.gagal(a, "Gagal memeriksa daftar berkas", full, r2, back);
                            return;
                        }
                        JSONArray tree = Api.parse(r2).optJSONArray("tree");
                        String main = null;
                        for (int i = 0; tree != null && i < tree.length(); i++) {
                            JSONObject it = tree.optJSONObject(i);
                            String p = it == null ? "" : it.optString("path", "");
                            if (p.startsWith("build/") || p.contains("/build/")) continue;
                            if (!(p.endsWith("/MainActivity.java") || p.endsWith("/MainActivity.kt"))) continue;
                            if (p.contains(AKAR[0]) || p.contains(AKAR[1])) { main = p; break; }
                        }
                        if (main == null) {
                            a.runOnUiThread(() -> ApkTools.error(a, "MainActivity tidak ditemukan",
                                    "Proyek: " + full + "\n\nMainActivity.java atau .kt tidak ditemukan di src/main/java atau src/main/kotlin.", back));
                            return;
                        }
                        pasang(a, full, token, main, back);
                    });
        });
    }

    /** Langkah 2: tulis KunciTandaTangan.java, lalu pastikan alur kerja terbaru. */
    private static void pasang(final Activity a, final String full, final String token, final String main,
                               final Runnable back) {
        int idx = -1, len = 0;
        for (String k : AKAR) {
            int i = main.indexOf(k);
            if (i >= 0) { idx = i; len = k.length(); break; }
        }
        String modul = main.substring(0, idx);
        String sesudah = main.substring(idx + len);
        int slash = sesudah.lastIndexOf('/');
        if (slash <= 0) {
            a.runOnUiThread(() -> ApkTools.error(a, "Nama paket tidak terbaca",
                    "MainActivity tidak berada dalam paket.", back));
            return;
        }
        final String dir = sesudah.substring(0, slash);
        final String paket = dir.replace('/', '.');
        final String kelasPath = modul + "/src/main/java/" + dir + "/KunciTandaTangan.java";

        final byte[] kelas;
        try {
            kelas = ProjectBuilder.fill(ProjectBuilder.asset(a, "kunciGuard"),
                    java.util.Collections.singletonMap("PAKET", paket)).getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            a.runOnUiThread(() -> ApkTools.error(a, "Templat kelas kunci tidak terbaca", String.valueOf(e.getMessage()), back));
            return;
        }

        TandaTanganRepo.tulis(a, full, token, kelasPath, kelas,
                "Tambah kelas kunci terikat tanda tangan" + SKIP, back, () ->
                        TandaTanganRepo.pastikanAlurKerja(a, full, token, back,
                                () -> a.runOnUiThread(() -> selesai(a, full, kelasPath, back))));
    }

    private static void selesai(Activity a, String full, String kelasPath, Runnable back) {
        ApkTools.dialog(a, "Kelas kunci terpasang",
                "Proyek: " + full + "\n\nKelas ditambahkan di " + kelasPath + ".\n\nCara manual: KunciTandaTangan.enkripsiTeks(this, teks) untuk menyimpan, "
                        + "KunciTandaTangan.dekripsiTeksAtauNull(this, hasil) untuk membaca "
                        + "(null bila tanda tangan berbeda)."
                        + "\n\nCara otomatis: bungkus teks dengan KunciTandaTangan.s(\"teks\"), "
                        + "build akan mengenkripsinya."
                        + "\n\nLangkah berikutnya: pilih Mulai pembangunan APK dengan tanda tangan pribadi.",
                ApkTools.list(), "tutup", back);
    }
}
