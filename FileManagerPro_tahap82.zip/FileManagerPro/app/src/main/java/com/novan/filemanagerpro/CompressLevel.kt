package com.novan.filemanagerpro

import android.content.Context
import androidx.appcompat.app.AlertDialog

/** Dialog pilihan tingkat kompresi untuk membuat arsip. */
object CompressLevel {
    fun pick(c: Context, onPick: (Int) -> Unit) {
        val labels = arrayOf(
            c.getString(R.string.level_store), c.getString(R.string.level_fast),
            c.getString(R.string.level_normal), c.getString(R.string.level_max)
        )
        val levels = intArrayOf(
            ArchiveOps.LEVEL_STORE, ArchiveOps.LEVEL_FAST, ArchiveOps.LEVEL_NORMAL, ArchiveOps.LEVEL_MAX
        )
        AlertDialog.Builder(c)
            .setTitle(R.string.level_title)
            .setSingleChoiceItems(labels, 2) { dlg, which ->
                dlg.dismiss()
                onPick(levels[which])
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Meminta kata sandi opsional (hanya untuk ZIP). Kosong atau Lewati berarti tanpa kata sandi. */
    fun askPassword(c: Context, enabled: Boolean, onDone: (String?) -> Unit) {
        if (!enabled) { onDone(null); return }
        val input = android.widget.EditText(c)
        input.hint = c.getString(R.string.rar_password_hint)
        input.inputType = android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val box = PasswordUi.dialogView(c, input)
        AlertDialog.Builder(c)
            .setTitle(R.string.zip_password_title)
            .setMessage(R.string.zip_password_msg)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                onDone(input.text.toString().ifEmpty { null })
            }
            .setNegativeButton(R.string.zip_password_skip) { _, _ -> onDone(null) }
            .show()
    }
}
