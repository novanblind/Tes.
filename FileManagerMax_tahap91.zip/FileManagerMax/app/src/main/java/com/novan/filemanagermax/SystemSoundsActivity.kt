package com.novan.filemanagermax

import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaScannerConnection
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/**
 * Nada sistem: nada dering, notifikasi, alarm, dan suara antarmuka bawaan ponsel, ditampilkan
 * sebagai folder per jenis. Folder dicari otomatis di semua partisi (system, product, vendor,
 * odm, my_product milik Oppo/Realme/OnePlus, mi_ext milik Xiaomi, optics/prism milik Samsung,
 * dan lainnya), jadi cocok di semua merek ponsel. Folder bisa dibuka, diputar, dan disalin.
 */
class SystemSoundsActivity : AppCompatActivity() {

    private class Sound(val title: String, val file: File?, val uri: Uri?, val rel: String)

    /** Satu folder jenis nada; isinya digabung dari semua partisi. */
    private class Cat(val key: String, val name: String, val folder: String) {
        val sounds = ArrayList<Sound>()
    }

    /** Satu nada yang akan disalin, [sub] = folder tujuan relatif ("" = langsung di folder tujuan). */
    private class Item(val s: Sound, val sub: String)

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var cats: List<Cat> = emptyList()
    private var openCat: Cat? = null
    private var sounds: List<Sound> = emptyList()
    private var player: MediaPlayer? = null
    private var playing = -1
    private var selecting = false
    private val sel = HashSet<Int>()
    private var baseRows: List<Row> = emptyList()
    private var afterPick: ((File) -> Unit)? = null
    private var restoreKey: String? = null

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) afterPick?.invoke(File(p))
            afterPick = null
        }

    /** Nama folder di ponsel -> (nama tampil, nama folder hasil salinan). Urutan = urutan tampil. */
    private val known = linkedMapOf(
        "ringtones" to (R.string.snd_ringtones to "Ringtones"),
        "notifications" to (R.string.snd_notifications to "Notifications"),
        "alarms" to (R.string.snd_alarms to "Alarms"),
        "ui" to (R.string.snd_ui to "UI")
    )
    private val audioExt = setOf("ogg", "mp3", "m4a", "wav", "flac", "opus", "aac", "mid", "midi", "amr", "3gp", "imy", "rtttl", "rtx", "ota", "xmf")
    private val skipRoot = setOf(
        "proc", "sys", "dev", "data", "storage", "mnt", "sdcard", "acct", "config", "cache",
        "d", "debug_ramdisk", "linkerconfig", "metadata", "apex", "lost+found"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.snd_title)
        restoreKey = savedInstanceState?.getString("cat")
        empty = findViewById(R.id.empty)
        empty.setText(R.string.snd_loading)
        empty.visibility = View.VISIBLE
        rowAdapter = RowAdapter(
            onClick = { onRowClick(it) },
            onLong = { if (openCat == null && !selecting) showFolderActions(it) }
        )
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goBack()
        })
        load()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        openCat?.let { outState.putString("cat", it.key) }
    }

    override fun onStop() {
        super.onStop()
        stopPlay()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlay()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun goBack() {
        when {
            selecting -> stopSelect()
            openCat != null -> closeFolder()
            else -> finish()
        }
    }

    // ------------------------------------------------------------ memuat

    private fun makeCat(dirName: String): Cat {
        val k = dirName.lowercase()
        known[k]?.let { return Cat(k, getString(it.first), it.second) }
        if (dirName.isEmpty()) return Cat("", getString(R.string.snd_other), "Other")
        val shown = dirName.replace('_', ' ').replaceFirstChar { c -> c.uppercase() }
        return Cat(k, shown, dirName)
    }

    /** Semua folder media/audio di semua partisi yang ada di ponsel ini, tanpa duplikat. */
    private fun audioRoots(): List<File> {
        val out = LinkedHashMap<String, File>()
        fun add(d: File) {
            try {
                val a = File(d, "media/audio")
                if (a.isDirectory) out.putIfAbsent(a.canonicalPath, a)
            } catch (e: Exception) {
                // abaikan
            }
        }
        for (b in listOf(
            "/system", "/product", "/vendor", "/system_ext", "/odm", "/oem",
            "/system/product", "/system/system_ext", "/system/vendor"
        )) add(File(b))
        // Partisi tambahan milik merek: my_product, my_region, mi_ext, optics, prism, cust, hw_product, dll.
        val top = try { File("/").listFiles() } catch (e: Exception) { null }
        top?.filter { it.isDirectory && it.name !in skipRoot }
            ?.sortedBy { it.name }
            ?.forEach { add(it) }
        return out.values.toList()
    }

    private fun scan(dir: File, rel: String, depth: Int, found: (File, String) -> Unit) {
        val fs = try { dir.listFiles() } catch (e: Exception) { null } ?: return
        for (f in fs.sortedBy { it.name }) {
            if (f.isDirectory) {
                if (depth < 4) scan(f, if (rel.isEmpty()) f.name else rel + "/" + f.name, depth + 1, found)
            } else if (f.extension.lowercase() in audioExt) {
                found(f, rel)
            }
        }
    }

    private fun load() {
        executor.execute {
            val map = LinkedHashMap<String, Cat>()
            val seen = HashSet<String>()
            fun cat(dirName: String): Cat = map.getOrPut(dirName.lowercase()) { makeCat(dirName) }
            fun add(c: Cat, f: File, rel: String) {
                if (!seen.add(c.key + "|" + rel.lowercase() + "|" + f.name.lowercase())) return
                c.sounds.add(Sound(f.nameWithoutExtension, f, null, rel))
            }
            for (root in audioRoots()) {
                val kids = try { root.listFiles() } catch (e: Exception) { null } ?: continue
                for (k in kids.sortedBy { it.name }) {
                    if (k.isDirectory) {
                        scan(k, "", 1) { f, rel -> add(cat(k.name), f, rel) }
                    } else if (k.extension.lowercase() in audioExt) {
                        add(cat(""), k, "")
                    }
                }
            }
            // Cadangan: nada internal yang tidak terbaca sebagai berkas, lewat RingtoneManager.
            val types = linkedMapOf(
                "ringtones" to RingtoneManager.TYPE_RINGTONE,
                "notifications" to RingtoneManager.TYPE_NOTIFICATION,
                "alarms" to RingtoneManager.TYPE_ALARM
            )
            for ((key, type) in types) {
                try {
                    val rm = RingtoneManager(this)
                    rm.setType(type)
                    val cur = rm.cursor
                    val have = map[key]?.sounds?.map { it.title.lowercase() }?.toHashSet() ?: HashSet()
                    while (cur.moveToNext()) {
                        val t = cur.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: continue
                        val u = rm.getRingtoneUri(cur.position) ?: continue
                        if (!u.toString().startsWith("content://media/internal")) continue
                        if (t.lowercase() in have) continue
                        cat(key).sounds.add(Sound(t, null, u, ""))
                    }
                } catch (e: Exception) {
                    // abaikan
                }
            }
            val order = known.keys.toList()
            val result = map.values.filter { it.sounds.isNotEmpty() }.sortedWith(
                compareBy<Cat>(
                    { if (it.key in order) 0 else if (it.key.isEmpty()) 2 else 1 },
                    { if (it.key in order) order.indexOf(it.key) else 0 },
                    { it.name.lowercase() }
                )
            )
            for (c in result) c.sounds.sortWith(compareBy({ it.rel.lowercase() }, { it.title.lowercase() }))
            main.post {
                if (isFinishing || isDestroyed) return@post
                cats = result
                val key = restoreKey
                restoreKey = null
                val again = if (key != null) result.firstOrNull { it.key == key } else null
                if (again != null) openFolder(again, announce = false) else showFolders()
            }
        }
    }

    // ------------------------------------------------------------ daftar folder / isi folder

    private fun count(): Int = if (openCat == null) cats.size else sounds.size

    private fun showFolders() {
        stopPlay()
        openCat = null
        sounds = emptyList()
        selecting = false
        sel.clear()
        title = getString(R.string.snd_title)
        baseRows = cats.map { c ->
            val detail = getString(R.string.snd_folder_count, c.sounds.size)
            Row(R.drawable.ic_folder, c.name, detail, "${c.name}, $detail", c.key)
        }
        refresh()
        empty.setText(R.string.snd_none)
        empty.visibility = if (baseRows.isEmpty()) View.VISIBLE else View.GONE
        updateSubtitle()
        invalidateOptionsMenu()
    }

    private fun openFolder(c: Cat, announce: Boolean = true) {
        stopPlay()
        openCat = c
        sounds = c.sounds
        selecting = false
        sel.clear()
        title = c.name
        baseRows = c.sounds.map { s ->
            val size = s.file?.let { Formatter.formatFileSize(this, it.length()) }
            val detail = listOfNotNull(size, s.rel.ifEmpty { null }).joinToString(", ")
            Row(R.drawable.ic_audio, s.title, detail, if (detail.isEmpty()) s.title else "${s.title}, $detail", s.title)
        }
        refresh()
        empty.setText(R.string.snd_none)
        empty.visibility = if (baseRows.isEmpty()) View.VISIBLE else View.GONE
        updateSubtitle()
        invalidateOptionsMenu()
        if (announce) {
            findViewById<View>(android.R.id.content)
                .announceForAccessibility(getString(R.string.folder_opened, c.name, c.sounds.size))
        }
    }

    private fun closeFolder() {
        showFolders()
        findViewById<View>(android.R.id.content)
            .announceForAccessibility(getString(R.string.snd_title))
    }

    private fun onRowClick(i: Int) {
        if (selecting) { toggle(i); return }
        if (openCat == null) {
            cats.getOrNull(i)?.let { openFolder(it) }
        } else {
            showActions(i)
        }
    }

    // ------------------------------------------------------------ memutar

    private fun stopPlay() {
        try { player?.stop() } catch (e: Exception) { /* abaikan */ }
        try { player?.release() } catch (e: Exception) { /* abaikan */ }
        player = null
        playing = -1
    }

    private fun togglePlay(i: Int) {
        if (playing == i) { stopPlay(); return }
        stopPlay()
        val s = sounds[i]
        try {
            val mp = MediaPlayer()
            if (s.file != null) mp.setDataSource(s.file.absolutePath) else mp.setDataSource(this, s.uri!!)
            mp.setOnCompletionListener { stopPlay() }
            mp.prepare()
            mp.start()
            player = mp
            playing = i
        } catch (e: Exception) {
            say(getString(R.string.snd_play_failed))
        }
    }

    // ------------------------------------------------------------ pilih beberapa

    private fun refresh() {
        rowAdapter.submit(baseRows.mapIndexed { i, r -> r.copy(selected = if (selecting) i in sel else null) })
    }

    private fun updateSubtitle() {
        supportActionBar?.subtitle =
            if (selecting) getString(R.string.zip_select_count, sel.size)
            else getString(R.string.items_count, count())
    }

    private fun startSelect(first: Int?) {
        stopPlay()
        selecting = true
        sel.clear()
        if (first != null) sel.add(first)
        refresh()
        invalidateOptionsMenu()
        updateSubtitle()
    }

    private fun stopSelect() {
        selecting = false
        sel.clear()
        refresh()
        invalidateOptionsMenu()
        updateSubtitle()
    }

    private fun toggle(i: Int) {
        if (!sel.add(i)) sel.remove(i)
        rowAdapter.setSelected(i, i in sel)
        updateSubtitle()
    }

    /** Item untuk disalin sebagai folder: tiap folder jenis jadi subfolder di tujuan. */
    private fun itemsOfFolders(list: List<Cat>): List<Item> = list.flatMap { c ->
        c.sounds.map { s -> Item(s, if (s.rel.isEmpty()) c.folder else c.folder + "/" + s.rel) }
    }

    /** Item untuk disalin langsung ke folder tujuan, tanpa subfolder. */
    private fun itemsFlat(list: List<Sound>): List<Item> = list.map { Item(it, "") }

    private fun chosenFolders(): List<Cat> = sel.sorted().mapNotNull { cats.getOrNull(it) }
    private fun chosenSounds(): List<Sound> = sel.sorted().mapNotNull { sounds.getOrNull(it) }

    // ------------------------------------------------------------ menyalin

    private fun pickFolder(cb: (File) -> Unit) {
        afterPick = cb
        pickLauncher.launch(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.pick_folder_title))
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FOLDER)
        )
    }

    /** Menyalin [item] ke dalam [base] (di subfolder [Item.sub] bila ada). Mengembalikan berkas hasil. */
    private fun copyTo(item: Item, base: File): File {
        val dir = if (item.sub.isEmpty()) base else File(base, item.sub)
        dir.mkdirs()
        val s = item.s
        val name = s.file?.name ?: (s.title.replace(Regex("[^A-Za-z0-9 _.-]"), "_") + ".ogg")
        val target = FileOps.uniqueTarget(dir, name)
        val ins = if (s.file != null) s.file.inputStream() else contentResolver.openInputStream(s.uri!!)
            ?: throw java.io.IOException("Tidak bisa dibaca")
        ins.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
        return target
    }

    private enum class Mode { COPY, SHARE, SHARE_DOC, ZIP }

    /** Menyalin [list] lalu: COPY = selesai di [dest], SHARE = bagikan, ZIP = kemas jadi satu ZIP di [dest]. */
    private fun doCopy(list: List<Item>, mode: Mode, dest: File?) {
        if (list.isEmpty()) { say(getString(R.string.zip_select_none)); return }
        val dlg = AlertDialog.Builder(this)
            .setMessage(getString(R.string.snd_copying, 0, list.size))
            .setCancelable(false).show()
        executor.execute {
            var failed = 0
            val made = ArrayList<File>()
            val tops = LinkedHashSet<File>()
            var zipOut: File? = null
            var fatal: String? = null
            val tmp = File(cacheDir, if (mode == Mode.SHARE || mode == Mode.SHARE_DOC) "share_audio" else "snd_zip")
            try {
                if (mode != Mode.COPY) { tmp.deleteRecursively(); tmp.mkdirs() }
                val base = if (mode == Mode.COPY) dest!! else tmp
                list.forEachIndexed { n, item ->
                    main.post { if (!isDestroyed) dlg.setMessage(getString(R.string.snd_copying, n + 1, list.size)) }
                    try {
                        val f = copyTo(item, base)
                        made.add(f)
                        tops.add(if (item.sub.isEmpty()) f else File(base, item.sub.substringBefore('/')))
                    } catch (e: Exception) {
                        failed++
                    }
                }
                if (mode == Mode.ZIP && made.isNotEmpty()) {
                    val single = tops.singleOrNull()
                    val zipName = if (single != null && single.isDirectory) single.name + ".zip" else "Nada Sistem.zip"
                    val out = FileOps.uniqueTarget(dest!!, zipName)
                    ArchiveOps.compress(tops.toList(), ArchiveOps.OUT_ZIP, out, null, ArchiveOps.LEVEL_STORE)
                    zipOut = out
                }
            } catch (e: Exception) {
                fatal = e.message ?: e.javaClass.simpleName
            }
            if (mode == Mode.ZIP) tmp.deleteRecursively()
            val scan = if (mode == Mode.COPY) made.map { it.absolutePath } else listOfNotNull(zipOut?.absolutePath)
            if (scan.isNotEmpty()) MediaScannerConnection.scanFile(this, scan.toTypedArray(), null, null)
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                if (fatal != null || made.isEmpty()) {
                    say(getString(R.string.op_failed, fatal ?: ""))
                    return@post
                }
                if (selecting) stopSelect()
                var t = when (mode) {
                    Mode.COPY -> getString(R.string.snd_copied_all, made.size, dest!!.absolutePath)
                    Mode.ZIP -> getString(R.string.snd_zipped, made.size, zipOut?.absolutePath ?: "")
                    Mode.SHARE, Mode.SHARE_DOC -> ""
                }
                if (mode == Mode.SHARE_DOC) {
                    if (!Util.shareAsDocument(this, made)) t = getString(R.string.cannot_open)
                } else if (mode == Mode.SHARE) {
                    val ok = if (made.size == 1) Util.share(this, made[0]) else shareMany(made)
                    if (!ok) t = getString(R.string.cannot_open)
                }
                if (failed > 0) t += (if (t.isEmpty()) "" else ". ") + getString(R.string.snd_copy_failed_n, failed)
                if (t.isNotEmpty()) say(t)
            }
        }
    }

    private fun shareMany(files: List<File>): Boolean = try {
        val uris = ArrayList<Uri>(files.map { Util.uriOf(this, it) })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
            .setType("audio/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
        true
    } catch (e: Exception) {
        false
    }

    /** Tekan lama sebuah folder: buka, salin folder, kemas ZIP, atau pilih beberapa. */
    private fun showFolderActions(i: Int) {
        val c = cats.getOrNull(i) ?: return
        val labels = arrayOf(
            getString(R.string.snd_open_folder), getString(R.string.snd_copy_folder),
            getString(R.string.snd_zip), getString(R.string.menu_select)
        )
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> openFolder(c)
                    1 -> pickFolder { doCopy(itemsOfFolders(listOf(c)), Mode.COPY, it) }
                    2 -> pickFolder { doCopy(itemsOfFolders(listOf(c)), Mode.ZIP, it) }
                    3 -> startSelect(i)
                }
            }
            .show()
    }

    private fun showActions(i: Int) {
        if (i !in sounds.indices) return
        val labels = arrayOf(
            getString(if (playing == i) R.string.snd_stop else R.string.snd_play),
            getString(R.string.snd_copy), getString(R.string.action_share), getString(R.string.action_share_doc),
            getString(R.string.menu_select)
        )
        AlertDialog.Builder(this)
            .setTitle(sounds[i].title)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> togglePlay(i)
                    1 -> pickFolder { doCopy(itemsFlat(listOf(sounds[i])), Mode.COPY, it) }
                    2 -> doCopy(itemsFlat(listOf(sounds[i])), Mode.SHARE, null)
                    3 -> doCopy(itemsFlat(listOf(sounds[i])), Mode.SHARE_DOC, null)
                    4 -> startSelect(i)
                }
            }
            .show()
    }

    // ------------------------------------------------------------ menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, M_SELECT, 0, R.string.menu_select)
        menu.add(0, M_COPY_ALL, 1, R.string.snd_copy_all_folders)
        menu.add(0, M_SEL_ALL, 2, R.string.action_select_all)
        menu.add(0, M_SEL_COPY, 3, R.string.snd_copy)
        menu.add(0, M_SEL_SHARE, 4, R.string.action_share)
        menu.add(0, M_SEL_SHARE_DOC, 4, R.string.action_share_doc)
        menu.add(0, M_SEL_ZIP, 5, R.string.snd_zip)
        menu.add(0, M_SEL_CANCEL, 6, R.string.zip_sel_cancel)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val folders = openCat == null
        val has = count() > 0
        menu.findItem(M_SELECT)?.isVisible = !selecting && has
        menu.findItem(M_COPY_ALL)?.let {
            it.isVisible = !selecting && has
            it.setTitle(if (folders) R.string.snd_copy_all_folders else R.string.snd_copy_folder)
        }
        for (id in intArrayOf(M_SEL_ALL, M_SEL_COPY, M_SEL_ZIP, M_SEL_CANCEL)) {
            menu.findItem(id)?.isVisible = selecting
        }
        menu.findItem(M_SEL_SHARE)?.isVisible = selecting && !folders
        menu.findItem(M_SEL_SHARE_DOC)?.isVisible = selecting && !folders
        menu.findItem(M_SEL_COPY)?.setTitle(if (folders) R.string.snd_copy_folder else R.string.snd_copy)
        return true
    }

    private fun selectionItems(): List<Item> =
        if (openCat == null) itemsOfFolders(chosenFolders()) else itemsFlat(chosenSounds())

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> goBack()
            M_SELECT -> startSelect(null)
            M_COPY_ALL -> {
                val c = openCat
                val items = if (c == null) itemsOfFolders(cats) else itemsOfFolders(listOf(c))
                pickFolder { doCopy(items, Mode.COPY, it) }
            }
            M_SEL_ALL -> { sel.clear(); sel.addAll(0 until count()); refresh(); updateSubtitle() }
            M_SEL_COPY -> {
                val l = selectionItems()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else pickFolder { doCopy(l, Mode.COPY, it) }
            }
            M_SEL_SHARE -> {
                val l = selectionItems()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else doCopy(l, Mode.SHARE, null)
            }
            M_SEL_SHARE_DOC -> {
                val l = selectionItems()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else doCopy(l, Mode.SHARE_DOC, null)
            }
            M_SEL_ZIP -> {
                val l = selectionItems()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else pickFolder { doCopy(l, Mode.ZIP, it) }
            }
            M_SEL_CANCEL -> stopSelect()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private companion object {
        const val M_SELECT = 1
        const val M_COPY_ALL = 2
        const val M_SEL_ALL = 3
        const val M_SEL_COPY = 4
        const val M_SEL_SHARE = 5
        const val M_SEL_ZIP = 6
        const val M_SEL_CANCEL = 7
        const val M_SEL_SHARE_DOC = 8
    }
}
