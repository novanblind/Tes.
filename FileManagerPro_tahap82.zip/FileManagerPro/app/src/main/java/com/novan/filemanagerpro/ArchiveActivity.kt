package com.novan.filemanagerpro

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/** Penampil arsip: jelajahi isi arsip tanpa mengekstrak, lalu ekstrak sebagian atau semuanya. */
class ArchiveActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
    }

    private class Node(val name: String, val full: String, val isDir: Boolean, val size: Long)

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var archive: File
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var work: MutableList<ArchiveOps.Edit> = ArrayList()
    private var editable = false
    private var dirty = false
    private var saving = false
    private var savingDlg: AlertDialog? = null
    private var pendingAfter: (() -> Unit)? = null
    private var inPicker = false
    private var clipPaths: List<String> = emptyList()
    private var clipCut = false
    private var selecting = false
    private val sel = HashSet<String>()
    private var prefix = ""
    private var shown: List<Node> = emptyList()
    private var afterPick: ((File) -> Unit)? = null

    /** Berkas zip yang dibuka lewat salinan sementara; dipantau agar hasil edit otomatis masuk kembali ke zip. */
    private class Watch(val file: File, var time: Long, var size: Long)
    private val watches = HashMap<String, Watch>()

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            inPicker = false
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) afterPick?.invoke(File(p))
            afterPick = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val given = intent.getStringExtra(EXTRA_PATH)?.let { File(it) } ?: realFileOf(intent.data)
        val incoming = intent.data
        if (given == null && incoming == null) { finish(); return }
        if (given != null) {
            archive = given
            title = archive.name
        } else {
            title = incomingName(incoming!!)
        }
        empty = findViewById(R.id.empty)
        empty.setText(R.string.archive_loading)
        empty.visibility = View.VISIBLE
        rowAdapter = RowAdapter(onClick = { onClickRow(it) }, onLong = { showActions(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selecting) stopSelect() else if (prefix.isEmpty()) exitArchive() else goUp()
            }
        })

        if (given != null) loadArchive()
        else {
            // dibuka dari aplikasi lain (content://) yang tidak punya jalur asli: salin dulu ke penyimpanan aplikasi
            executor.execute {
                val copy = try {
                    copyIncoming(incoming!!)
                } catch (e: Exception) {
                    main.post {
                        if (!isDestroyed) empty.text = getString(R.string.op_failed, e.message ?: "")
                    }
                    return@execute
                }
                main.post {
                    if (isFinishing || isDestroyed) return@post
                    archive = copy
                    title = archive.name
                    loadArchive()
                }
            }
        }
    }

    /** Jalur asli berkas bila bisa ditemukan (file://, MediaStore, atau penyimpanan eksternal), agar edit masuk ke zip aslinya. */
    private fun realFileOf(uri: Uri?): File? {
        if (uri == null) return null
        try {
            if (uri.scheme == "file") {
                return uri.path?.let { File(it) }?.takeIf { it.isFile && it.canRead() }
            }
            if (uri.scheme != "content") return null
            if (uri.authority == "com.android.externalstorage.documents") {
                val id = DocumentsContract.getDocumentId(uri)
                val vol = id.substringBefore(':')
                val rel = id.substringAfter(':', "")
                val root = if (vol.equals("primary", true)) Environment.getExternalStorageDirectory().absolutePath
                else "/storage/$vol"
                File(root, rel).takeIf { it.isFile && it.canRead() }?.let { return it }
            }
            contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val path = c.getString(0)
                    if (!path.isNullOrEmpty()) File(path).takeIf { it.isFile && it.canRead() }?.let { return it }
                }
            }
        } catch (e: Exception) { /* lanjut ke salinan sementara */ }
        return null
    }

    /** Folder tujuan ekstrak "di sini": folder zip asli, atau Download bila zip hanya salinan sementara. */
    private fun homeDir(): File {
        val parent = archive.parentFile
        val inCache = parent != null && parent.absolutePath.startsWith(cacheDir.absolutePath)
        return if (parent == null || inCache)
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
        else parent
    }

    private fun incomingName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (e: Exception) { /* abaikan */ }
        val n = (name ?: uri.lastPathSegment ?: "arsip.zip").substringAfterLast('/')
            .replace(Regex("[^A-Za-z0-9._+ -]"), "_")
        return if (n.isBlank()) "arsip.zip" else n
    }

    private fun copyIncoming(uri: Uri): File {
        val dir = File(cacheDir, "incoming_zip").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, incomingName(uri))
        val ins = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Berkas tidak bisa dibaca")
        ins.use { i -> out.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        return out
    }

    private var diskStamp: Pair<Long, Long> = 0L to 0L

    private fun stampNow(): Pair<Long, Long> = archive.lastModified() to archive.length()

    /** Menguji arsip: membaca setiap berkas sampai habis (CRC diperiksa pustaka) tanpa menulis apa pun. */
    private fun testArchive() {
        val dlg = AlertDialog.Builder(this)
            .setMessage(getString(R.string.test_running, ""))
            .setCancelable(false)
            .show()
        executor.execute {
            var total = 0
            val bad = ArrayList<String>()
            var fatal: Exception? = null
            try {
                ArchiveOps.walk(this, archive) { e, open ->
                    if (!e.isDir) {
                        total++
                        main.post { if (!isDestroyed) dlg.setMessage(getString(R.string.test_running, e.path.substringAfterLast('/'))) }
                        try {
                            val buf = ByteArray(64 * 1024)
                            open().use { ins -> while (ins.read(buf) >= 0) { /* buang */ } }
                        } catch (ex: PasswordRequired) {
                            throw ex
                        } catch (ex: Exception) {
                            bad.add(e.path + " (" + (ex.message ?: ex.javaClass.simpleName) + ")")
                        }
                    }
                    true
                }
            } catch (ex: Exception) {
                fatal = ex
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                val f = fatal
                val text = when {
                    f is PasswordRequired -> f.message ?: ""
                    f != null -> getString(R.string.op_failed, f.message ?: f.javaClass.simpleName)
                    bad.isEmpty() -> getString(R.string.test_ok, total)
                    else -> getString(R.string.test_bad, bad.size, total) + "\n" +
                        bad.take(10).joinToString("\n") +
                        (if (bad.size > 10) "\n" + getString(R.string.test_more, bad.size - 10) else "")
                }
                AlertDialog.Builder(this).setTitle(R.string.test_archive).setMessage(text)
                    .setPositiveButton(android.R.string.ok, null).show()
            }
        }
    }

    /** Meminta kata sandi arsip RAR lalu memuat ulang. */
    private fun askRarPassword(wrong: Boolean) {
        ArchiveOps.passwords.remove(archive.absolutePath)
        val input = android.widget.EditText(this)
        input.hint = getString(R.string.rar_password_hint)
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.rar_password_title)
            .setView(PasswordUi.dialogView(this, input))
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val pw = input.text.toString()
                if (pw.isNotEmpty()) {
                    ArchiveOps.passwords[archive.absolutePath] = pw
                    loadArchive()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
        if (wrong) dlg.setMessage(R.string.rar_password_wrong)
        dlg.show()
    }

    /** Membaca isi arsip dari disk ke daftar kerja. */
    private fun loadArchive() {
        diskStamp = stampNow()
        executor.execute {
            val result = try {
                ArchiveOps.list(this, archive)
            } catch (e: Exception) {
                main.post {
                    if (!isDestroyed) {
                        if (e is PasswordRequired) {
                            empty.text = e.message ?: ""
                            askRarPassword(e.wrong)
                        } else {
                            empty.text = getString(R.string.op_failed, e.message ?: "")
                        }
                    }
                }
                return@execute
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                editable = ArchiveOps.typeOf(archive) == ArchiveOps.ZIP && !ArchiveOps.needsZip4j(archive)
                work = result.map {
                    ArchiveOps.Edit(it.path, it.isDir, it.size, it.time, if (it.isDir) null else it.path, null)
                }.toMutableList()
                empty.setText(R.string.archive_empty)
                if (prefix.isNotEmpty() && work.none { it.path.startsWith(prefix) }) prefix = ""
                invalidateOptionsMenu()
                render(announce = false)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun goUp() {
        val t = prefix.trimEnd('/')
        val i = t.lastIndexOf('/')
        prefix = if (i < 0) "" else t.substring(0, i + 1)
        render()
    }

    private fun render(announce: Boolean = true) {
        val dirs = LinkedHashMap<String, Node>()
        val fileNodes = ArrayList<Node>()
        for (e in work) {
            if (!e.path.startsWith(prefix)) continue
            val rest = e.path.removePrefix(prefix)
            if (rest.isEmpty()) continue
            val i = rest.indexOf('/')
            if (i >= 0) {
                val n = rest.substring(0, i)
                dirs.putIfAbsent(n, Node(n, prefix + n, true, 0))
            } else if (e.isDir) {
                dirs.putIfAbsent(rest, Node(rest, prefix + rest, true, 0))
            } else {
                fileNodes.add(Node(rest, e.path, false, e.size))
            }
        }
        val nodes = dirs.values.sortedBy { it.name.lowercase() } +
            fileNodes.sortedBy { it.name.lowercase() }
        shown = nodes
        val rows = nodes.map {
            if (it.isDir) {
                Row(R.drawable.ic_folder, it.name, getString(R.string.folder), "${getString(R.string.folder)} ${it.name}", it.full, if (selecting) it.full in sel else null)
            } else {
                val sz = if (it.size >= 0) Formatter.formatFileSize(this, it.size) else ""
                Row(R.drawable.ic_file, it.name, sz, "${getString(R.string.file)} ${it.name}, $sz", it.full, if (selecting) it.full in sel else null)
            }
        }
        rowAdapter.submit(rows)
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = "/" + prefix + (if (dirty) " " + getString(R.string.zip_modified) else "")
        if (announce) say(getString(R.string.folder_opened, if (prefix.isEmpty()) archive.name else prefix.trimEnd('/').substringAfterLast('/'), rows.size))
    }

    private fun onClickRow(i: Int) {
        if (i !in shown.indices) return
        val n = shown[i]
        if (selecting) {
            toggleSel(n.full)
            return
        }
        if (n.isDir) {
            prefix = n.full + "/"
            render()
        } else {
            openEntry(n)
        }
    }

    private fun openEntry(n: Node) {
        val item = work.firstOrNull { it.path == n.full } ?: return
        if (item.srcFile != null) {
            if (!Util.openSmart(this, item.srcFile, listOf(item.srcFile))) say(getString(R.string.cannot_open))
            return
        }
        val src = item.src ?: return
        val dir = File(cacheDir, "arc/" + System.nanoTime()).also { it.mkdirs() }
        val srcName = src.substringAfterLast('/')
        say(getString(R.string.extracting))
        executor.execute {
            try {
                ArchiveOps.extract(this, archive, dir, { it.path == src }, src.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" })
                var target = File(dir, srcName)
                if (n.name != srcName) {
                    val renamed = File(dir, n.name)
                    if (target.renameTo(renamed)) target = renamed
                }
                main.post {
                    if (isDestroyed) return@post
                    if (editable) watches[n.full] = Watch(target, target.lastModified(), target.length())
                    if (!Util.openSmart(this, target, listOf(target))) say(getString(R.string.cannot_open))
                }
            } catch (e: Exception) {
                main.post { if (!isDestroyed) say(getString(R.string.op_failed, e.message ?: "")) }
            }
        }
    }

    private fun showActions(i: Int) {
        if (i !in shown.indices) return
        val n = shown[i]
        if (selecting) {
            toggleSel(n.full)
            return
        }
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (editable) {
            labels.add(getString(R.string.menu_select)); acts.add { startSelect(n.full) }
            labels.add(getString(R.string.action_copy)); acts.add { setClip(listOf(n), false) }
            labels.add(getString(R.string.zip_cut)); acts.add { setClip(listOf(n), true) }
            labels.add(getString(R.string.act_rename)); acts.add { renameNode(n) }
            labels.add(getString(R.string.zip_delete)); acts.add { deleteNodes(listOf(n)) }
        }
        labels.add(getString(R.string.extract_here)); acts.add {
            val dest = FileOps.uniqueTarget(homeDir(), ArchiveOps.baseName(archive))
            extractNode(n, dest)
        }
        labels.add(getString(R.string.extract_to)); acts.add { pickFolder { extractNode(n, it) } }
        AlertDialog.Builder(this)
            .setTitle(n.name)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    // ---------------------------------------------------------- ubah isi zip

    private fun under(n: Node): List<ArchiveOps.Edit> =
        work.filter { it.path == n.full || it.path.startsWith(n.full + "/") }

    private fun markDirty() {
        dirty = true
        render(announce = false)
        invalidateOptionsMenu()
    }

    private fun setClip(nodes: List<Node>, cut: Boolean) {
        if (nodes.isEmpty()) return
        // Simpan dulu perubahan yang belum tersimpan agar isi zip di disk sama dengan yang terlihat.
        saveThen(quiet = true) {
            clipPaths = nodes.map { it.full }
            clipCut = cut
            val entries = nodes.flatMap { under(it) }.distinctBy { it.path }
            Clipboard.setZip(archive, clipPaths, entries, cut)
            invalidateOptionsMenu()
            val label = if (nodes.size == 1) nodes[0].name else getString(R.string.zip_n_items, nodes.size)
            say(getString(if (cut) R.string.zip_clip_cut else R.string.zip_clip_copy, label))
        }
    }

    private fun exists(path: String): Boolean =
        work.any { it.path == path || it.path.startsWith("$path/") }

    private fun uniquePath(parent: String, name: String): String {
        var p = parent + name
        if (!exists(p)) return p
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            p = parent + "$base ($i)$ext"
            if (!exists(p)) return p
            i++
        }
    }

    private fun isDirPath(path: String): Boolean =
        work.any { (it.path == path && it.isDir) || it.path.startsWith("$path/") }

    /** Data konflik untuk entri zip bernama sama di [target]. */
    private fun zipConflict(key: String, name: String, src: ArchiveOps.Edit?, target: String): ConflictItem {
        val t = work.firstOrNull { it.path == target }
        val tDir = t?.isDir ?: true
        val sDir = src?.isDir ?: true
        return ConflictItem(
            key, name, sDir, if (sDir) 0L else (src?.size ?: 0L).coerceAtLeast(0L), src?.time ?: 0L,
            tDir, if (tDir) 0L else (t?.size ?: 0L).coerceAtLeast(0L), t?.time ?: 0L
        )
    }

    /** Konflik folder kembar: dialog Gabung / Lewati / Batal. */
    private fun zipMergeConflict(key: String, name: String, srcTime: Long, target: String, nested: () -> List<ConflictItem>): ConflictItem {
        val t = work.firstOrNull { it.path == target }
        return ConflictItem(key, name, true, 0L, srcTime, true, 0L, t?.time ?: 0L, true, nested)
    }

    /** Membuang [target] (berkas atau folder beserta isinya) dari daftar kerja. */
    private fun removeTarget(target: String): Set<String> =
        work.filter { it.path == target || it.path.startsWith("$target/") }.map { it.path }.toSet()

    /** Konflik berkas di dalam folder zip [p] bila digabung ke [target]. */
    private fun zipNested(p: String, target: String): List<ConflictItem> {
        val out = ArrayList<ConflictItem>()
        for (en in work.filter { it.path.startsWith("$p/") }.sortedBy { it.path }) {
            val mapped = target + en.path.removePrefix(p)
            if (!exists(mapped)) continue
            if (en.isDir && isDirPath(mapped)) continue
            out.add(zipConflict(en.path, en.path.substringAfterLast('/'), en, mapped))
        }
        return out
    }

    private fun paste() {
        if (!editable || clipPaths.isEmpty()) return
        val paths = clipPaths.toList()
        val cut = clipCut
        val conflicts = ArrayList<ConflictItem>()
        for (p in paths) {
            val name = p.substringAfterLast('/')
            val parent = if (p.contains('/')) p.substringBeforeLast('/') + "/" else ""
            val target = prefix + name
            if (target == p) continue
            if (cut && parent == prefix) continue
            if (p.startsWith("$target/")) continue
            if (prefix == "$p/" || prefix.startsWith("$p/")) continue
            if (!exists(target)) continue
            if (work.none { it.path == p || it.path.startsWith("$p/") }) continue
            val src = work.firstOrNull { it.path == p }
            if (isDirPath(p) && isDirPath(target)) {
                conflicts.add(zipMergeConflict(p, name, src?.time ?: 0L, target) { zipNested(p, target) })
            } else {
                conflicts.add(zipConflict(p, name, src, target))
            }
        }
        if (conflicts.isEmpty()) {
            doPaste(paths, cut, emptyMap())
        } else {
            Conflicts.ask(this, conflicts) { actions -> if (actions != null) doPaste(paths, cut, actions) }
        }
    }

    private fun doPaste(paths: List<String>, cut: Boolean, actions: Map<String, ConflictAction>) {
        if (!editable) return
        var done = 0
        var skipped = 0
        val adds = ArrayList<ArchiveOps.Edit>()
        val removes = HashSet<String>()
        for (p in paths) {
            val srcItems = work.filter { it.path == p || it.path.startsWith("$p/") }
            val parent = if (p.contains('/')) p.substringBeforeLast('/') + "/" else ""
            val intoSelf = prefix == "$p/" || prefix.startsWith("$p/")
            if (srcItems.isEmpty() || intoSelf || (cut && parent == prefix)) {
                skipped++
                continue
            }
            val name = p.substringAfterLast('/')
            val target = prefix + name
            val act = actions[p] ?: ConflictAction.RENAME
            if (act == ConflictAction.MERGE && target != p && exists(target) && isDirPath(target) && isDirPath(p)) {
                // Folder yang memuat sumbernya tidak boleh digabung.
                if (p.startsWith("$target/")) { skipped++; continue }
                val skipP = ArrayList<String>()
                val remap = LinkedHashMap<String, String>()
                fun mapRel(rel: String): String {
                    for ((k, v) in remap) {
                        if (rel == k) return v
                        if (rel.startsWith("$k/")) return v + rel.removePrefix(k)
                    }
                    return rel
                }
                for (e in srcItems.sortedBy { it.path }) {
                    val rel = e.path.removePrefix(p)
                    if (rel.isEmpty()) {
                        if (work.none { it.path == target }) adds.add(e.copy(path = target))
                        continue
                    }
                    if (skipP.any { s -> e.path == s || e.path.startsWith("$s/") }) continue
                    var relNew = mapRel(rel)
                    var path = target + relNew
                    if (exists(path) && !(e.isDir && isDirPath(path))) {
                        val a2 = actions[e.path] ?: ConflictAction.RENAME
                        if (a2 == ConflictAction.SKIP) { skipP.add(e.path); continue }
                        if (a2 == ConflictAction.OVERWRITE) {
                            removes.addAll(removeTarget(path))
                        } else {
                            path = uniquePath(path.substringBeforeLast('/') + "/", path.substringAfterLast('/'))
                            relNew = path.removePrefix(target)
                            remap[rel] = relNew
                        }
                    }
                    adds.add(e.copy(path = path))
                    if (cut) removes.add(e.path)
                }
                if (cut) removes.add(p)
                done++
                continue
            }
            val newBase: String
            if (exists(target) && target != p) {
                if (act == ConflictAction.SKIP) { skipped++; continue }
                if (act == ConflictAction.OVERWRITE) {
                    // Folder yang memuat sumbernya tidak boleh ditimpa.
                    if (p.startsWith("$target/")) { skipped++; continue }
                    newBase = target
                    removes.addAll(removeTarget(target))
                } else {
                    newBase = uniquePath(prefix, name)
                }
            } else {
                newBase = uniquePath(prefix, name)
            }
            for (it in srcItems) adds.add(it.copy(path = newBase + it.path.removePrefix(p)))
            if (cut) for (it in srcItems) removes.add(it.path)
            done++
        }
        if (removes.isNotEmpty()) work.removeAll { it.path in removes }
        work.addAll(adds)
        clipPaths = emptyList()
        if (Clipboard.zipArchive == archive) Clipboard.clear()
        if (done > 0) markDirty() else invalidateOptionsMenu()
        say(getString(R.string.paste_result, done, skipped))
    }

    private fun deleteNodes(nodes: List<Node>) {
        if (nodes.isEmpty()) return
        val label = if (nodes.size == 1) nodes[0].name else getString(R.string.zip_n_items, nodes.size)
        AlertDialog.Builder(this)
            .setTitle(R.string.zip_delete)
            .setMessage(getString(R.string.zip_delete_confirm, label))
            .setPositiveButton(R.string.ok) { _, _ ->
                val gone = HashSet<String>()
                for (n in nodes) for (e in under(n)) gone.add(e.path)
                work.removeAll { it.path in gone }
                clipPaths = clipPaths.filter { p -> work.any { it.path == p || it.path.startsWith("$p/") } }
                stopSelect(false)
                markDirty()
                say(getString(R.string.zip_deleted, label))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---- pilih beberapa

    private fun startSelect(first: String?) {
        selecting = true
        sel.clear()
        if (first != null) sel.add(first)
        render(announce = false)
        invalidateOptionsMenu()
        say(getString(R.string.zip_select_on, sel.size))
    }

    private fun stopSelect(redraw: Boolean = true) {
        selecting = false
        sel.clear()
        if (redraw) render(announce = false)
        invalidateOptionsMenu()
    }

    private fun toggleSel(path: String) {
        if (!sel.add(path)) sel.remove(path)
        render(announce = false)
        say(getString(R.string.zip_select_count, sel.size))
    }

    private fun selectedNodes(): List<Node> = shown.filter { it.full in sel }

    // ---- tambah dari penyimpanan

    private fun addFile(f: File, path: String): Int {
        if (f.isDirectory) {
            work.add(ArchiveOps.Edit(path, true, 0, f.lastModified(), null, null))
            var c = 1
            f.listFiles()?.sortedBy { it.name }?.forEach { c += addFile(it, "$path/${it.name}") }
            return c
        }
        work.add(ArchiveOps.Edit(path, false, f.length(), f.lastModified(), null, f))
        return 1
    }

    /** Konflik berkas di dalam folder [f] bila digabung ke folder zip [targetPath]. */
    private fun extNested(f: File, targetPath: String): List<ConflictItem> {
        val out = ArrayList<ConflictItem>()
        val kids = f.listFiles()?.sortedBy { it.name } ?: return out
        for (k in kids) {
            val mp = "$targetPath/${k.name}"
            if (!exists(mp)) continue
            if (k.isDirectory && isDirPath(mp)) {
                out.addAll(extNested(k, mp))
            } else {
                out.add(
                    zipConflict(
                        k.absolutePath, k.name,
                        ArchiveOps.Edit(k.name, k.isDirectory, if (k.isFile) k.length() else 0L, k.lastModified(), null, k),
                        mp
                    )
                )
            }
        }
        return out
    }

    private fun addExternal(files: List<File>) {
        if (!editable) return
        val self = archive.canonicalPath
        val isClip = files === Clipboard.files
        val list = files.filter { it.exists() && it.canonicalPath != self }
        val conflicts = ArrayList<ConflictItem>()
        for (f in list) {
            val target = prefix + f.name
            if (!exists(target)) continue
            if (f.isDirectory && isDirPath(target)) {
                conflicts.add(zipMergeConflict(f.absolutePath, f.name, f.lastModified(), target) { extNested(f, target) })
            } else {
                conflicts.add(
                    zipConflict(
                        f.absolutePath, f.name,
                        ArchiveOps.Edit(f.name, f.isDirectory, if (f.isFile) f.length() else 0L, f.lastModified(), null, f),
                        target
                    )
                )
            }
        }
        if (conflicts.isEmpty()) {
            doAddExternal(list, isClip, emptyMap())
        } else {
            Conflicts.ask(this, conflicts) { actions -> if (actions != null) doAddExternal(list, isClip, actions) }
        }
    }

    /** Memasukkan isi folder [f] ke folder zip [path] yang sudah ada (gabung). */
    private fun addMerged(f: File, path: String, actions: Map<String, ConflictAction>): Int {
        var c = 0
        if (!isDirPath(path)) c += addFile(f, path) else {
            val kids = f.listFiles()?.sortedBy { it.name } ?: return 0
            for (k in kids) {
                val cp = "$path/${k.name}"
                if (!exists(cp)) { c += addFile(k, cp); continue }
                if (k.isDirectory && isDirPath(cp)) { c += addMerged(k, cp, actions); continue }
                val act = actions[k.absolutePath] ?: ConflictAction.RENAME
                if (act == ConflictAction.SKIP) continue
                if (act == ConflictAction.OVERWRITE) {
                    val gone = removeTarget(cp)
                    work.removeAll { it.path in gone }
                    c += addFile(k, cp)
                } else {
                    c += addFile(k, uniquePath("$path/", k.name))
                }
            }
        }
        return c
    }

    private fun doAddExternal(list: List<File>, isClip: Boolean, actions: Map<String, ConflictAction>) {
        if (!editable) return
        var n = 0
        for (f in list) {
            val target = prefix + f.name
            var path = target
            if (exists(target)) {
                val act = actions[f.absolutePath] ?: ConflictAction.RENAME
                if (act == ConflictAction.SKIP) continue
                if (act == ConflictAction.MERGE && f.isDirectory && isDirPath(target)) {
                    n += addMerged(f, target, actions)
                    continue
                }
                if (act == ConflictAction.OVERWRITE) {
                    val gone = removeTarget(target)
                    work.removeAll { it.path in gone }
                } else {
                    path = uniquePath(prefix, f.name)
                }
            }
            n += addFile(f, path)
        }
        if (isClip) Clipboard.clear()
        if (n > 0) markDirty() else invalidateOptionsMenu()
        say(getString(R.string.zip_added, n))
    }

    private fun pickFile(cb: (File) -> Unit) {
        afterPick = cb
        inPicker = true
        pickLauncher.launch(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.zip_pick_file_title))
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FILE)
        )
    }

    private fun newFolder() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_new_folder)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                val nn = input.text.toString().trim()
                if (nn.isEmpty() || nn.contains('/') || nn.contains('\\')) {
                    say(getString(R.string.op_failed, nn)); return@setPositiveButton
                }
                if (exists(prefix + nn)) { say(getString(R.string.zip_name_exists, nn)); return@setPositiveButton }
                work.add(ArchiveOps.Edit(prefix + nn, true, 0, System.currentTimeMillis(), null, null))
                markDirty()
                say(getString(R.string.zip_folder_created, nn))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun renameNode(n: Node) {
        val input = EditText(this)
        input.setText(n.name)
        input.setSelection(n.name.length)
        AlertDialog.Builder(this)
            .setTitle(R.string.act_rename)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                val nn = input.text.toString().trim()
                if (nn.isEmpty() || nn.contains('/') || nn.contains('\\')) {
                    say(getString(R.string.rename_failed)); return@setPositiveButton
                }
                if (nn == n.name) return@setPositiveButton
                val newBase = prefix + nn
                if (exists(newBase)) { say(getString(R.string.zip_name_exists, nn)); return@setPositiveButton }
                val old = n.full
                work = work.map {
                    if (it.path == old || it.path.startsWith("$old/")) it.copy(path = newBase + it.path.removePrefix(old)) else it
                }.toMutableList()
                clipPaths = emptyList()
                markDirty()
                say(getString(R.string.renamed))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSavingDialog() {
        if (savingDlg != null || isFinishing || isDestroyed) return
        savingDlg = AlertDialog.Builder(this).setMessage(R.string.zip_saving).setCancelable(false).show()
    }

    /**
     * Menulis perubahan ke zip, lalu menjalankan [after] bila berhasil.
     * [quiet]: simpan diam-diam di latar belakang (saat aplikasi ditutup/ditinggalkan).
     */
    private fun saveThen(quiet: Boolean = false, after: () -> Unit) {
        if (saving) {
            pendingAfter = after
            if (!quiet) showSavingDialog()
            return
        }
        if (!editable || !dirty) { after(); return }
        saving = true
        val snapshot = work.toList()
        if (!quiet) showSavingDialog()
        Thread {
            val err: String? = try {
                ArchiveOps.rewriteZip(archive, snapshot)
                null
            } catch (e: Exception) {
                e.message ?: e.javaClass.simpleName
            }
            main.post {
                saving = false
                savingDlg?.dismiss()
                savingDlg = null
                val pend = pendingAfter
                pendingAfter = null
                if (isDestroyed) return@post
                if (err == null) {
                    work = snapshot.map {
                        it.copy(src = if (it.isDir) null else it.path, srcFile = null)
                    }.toMutableList()
                    dirty = false
                    diskStamp = stampNow()
                    invalidateOptionsMenu()
                    render(announce = false)
                    if (!quiet) Toast.makeText(this, R.string.zip_saved, Toast.LENGTH_SHORT).show()
                    after()
                    pend?.invoke()
                } else {
                    say(getString(R.string.zip_save_failed, err))
                }
            }
        }.start()
    }

    /**
     * Memeriksa salinan sementara berkas yang dibuka dari zip. Bila isinya berubah
     * (misalnya habis diedit di editor teks), entri di zip diganti dan zip disimpan otomatis.
     */
    private fun syncWatches() {
        if (!editable || watches.isEmpty()) return
        if (saving) {
            pendingAfter = { syncWatches() }
            return
        }
        val changed = ArrayList<String>()
        val it = watches.entries.iterator()
        while (it.hasNext()) {
            val (path, w) = it.next()
            val idx = work.indexOfFirst { e -> e.path == path && !e.isDir }
            if (idx < 0 || !w.file.exists()) { it.remove(); continue }
            val t = w.file.lastModified()
            val l = w.file.length()
            if (t == w.time && l == w.size) continue
            w.time = t
            w.size = l
            work[idx] = work[idx].copy(size = l, time = t, src = null, srcFile = w.file)
            changed.add(path.substringAfterLast('/'))
        }
        if (changed.isEmpty()) return
        markDirty()
        val label = if (changed.size == 1) changed[0] else getString(R.string.zip_n_items, changed.size)
        saveThen(quiet = true) { say(getString(R.string.zip_entry_updated, label, archive.name)) }
    }

    override fun onResume() {
        super.onResume()
        syncWatches()
    }

    override fun onStart() {
        super.onStart()
        if (saving) showSavingDialog()
        // Zip berubah dari luar (mis. isinya dipindah keluar): muat ulang bila tidak ada perubahan tertunda.
        if (::archive.isInitialized && !saving && !dirty && stampNow() != diskStamp) loadArchive()
    }

    override fun onStop() {
        super.onStop()
        if (editable && dirty && !saving && !inPicker && !isFinishing) saveThen(quiet = true) { }
    }

    private fun exitArchive() = saveThen(false) { finish() }

    private fun extractNode(n: Node, dest: File) {
        val strip = prefix
        if (editable) {
            val items = under(n)
            runWork(R.string.extracting) { ArchiveOps.extractItems(archive, items, dest, strip) }
        } else {
            runWork(R.string.extracting) {
                ArchiveOps.extract(this, archive, dest, {
                    it.path == n.full || it.path.startsWith(n.full + "/")
                }, strip)
            }
        }
    }

    private fun extractNodes(nodes: List<Node>, dest: File) {
        val strip = prefix
        val items = nodes.flatMap { under(it) }.distinctBy { it.path }
        stopSelect()
        runWork(R.string.extracting) { ArchiveOps.extractItems(archive, items, dest, strip) }
    }

    private fun extractAll(dest: File) {
        if (editable) {
            val items = work.toList()
            runWork(R.string.extracting) { ArchiveOps.extractItems(archive, items, dest, "") }
        } else {
            runWork(R.string.extracting) { ArchiveOps.extract(this, archive, dest) }
        }
    }

    private fun runWork(msg: Int, work: () -> Int) {
        val dlg = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        Thread {
            val text = try {
                getString(R.string.extract_done, work())
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                say(text)
            }
        }.start()
    }

    private fun pickFolder(cb: (File) -> Unit) {
        afterPick = cb
        inPicker = true
        pickLauncher.launch(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.pick_folder_title))
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FOLDER)
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.archive_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val paste = menu.findItem(R.id.action_paste)
        paste?.isVisible = editable && !selecting && clipPaths.isNotEmpty()
        paste?.title = getString(R.string.menu_paste_count, clipPaths.size)
        val clipN = Clipboard.files.size
        val pb = menu.findItem(R.id.action_paste_browser)
        pb?.isVisible = editable && !selecting && clipN > 0
        pb?.title = getString(R.string.zip_paste_browser, clipN)
        menu.findItem(R.id.action_save_zip)?.isVisible = editable && dirty && !selecting
        for (id in intArrayOf(R.id.action_add_file, R.id.action_add_folder, R.id.action_new_folder, R.id.action_select)) {
            menu.findItem(id)?.isVisible = editable && !selecting
        }
        menu.findItem(R.id.action_extract_all_here)?.isVisible = !selecting
        menu.findItem(R.id.action_extract_all_to)?.isVisible = !selecting
        menu.findItem(R.id.action_test_archive)?.isVisible = !selecting
        for (id in intArrayOf(
            R.id.action_sel_all, R.id.action_sel_copy, R.id.action_sel_cut,
            R.id.action_sel_delete, R.id.action_sel_extract, R.id.action_sel_cancel
        )) menu.findItem(id)?.isVisible = selecting
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> if (selecting) stopSelect() else if (prefix.isEmpty()) exitArchive() else goUp()
            R.id.action_paste -> paste()
            R.id.action_save_zip -> saveThen(false) { }
            R.id.action_new_folder -> newFolder()
            R.id.action_add_file -> pickFile { addExternal(listOf(it)) }
            R.id.action_add_folder -> pickFolder { addExternal(listOf(it)) }
            R.id.action_paste_browser -> addExternal(Clipboard.files)
            R.id.action_select -> startSelect(null)
            R.id.action_sel_cancel -> stopSelect()
            R.id.action_sel_all -> {
                sel.clear()
                shown.forEach { sel.add(it.full) }
                render(announce = false)
                say(getString(R.string.zip_select_count, sel.size))
            }
            R.id.action_sel_copy -> { val l = selectedNodes(); if (l.isEmpty()) say(getString(R.string.zip_select_none)) else { setClip(l, false); stopSelect() } }
            R.id.action_sel_cut -> { val l = selectedNodes(); if (l.isEmpty()) say(getString(R.string.zip_select_none)) else { setClip(l, true); stopSelect() } }
            R.id.action_sel_delete -> { val l = selectedNodes(); if (l.isEmpty()) say(getString(R.string.zip_select_none)) else deleteNodes(l) }
            R.id.action_sel_extract -> {
                val l = selectedNodes()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else pickFolder { extractNodes(l, it) }
            }
            R.id.action_test_archive -> testArchive()
            R.id.action_extract_all_here -> extractAll(
                FileOps.uniqueTarget(
                    homeDir(),
                    ArchiveOps.baseName(archive)
                )
            )
            R.id.action_extract_all_to -> pickFolder {
                extractAll(FileOps.uniqueTarget(it, ArchiveOps.baseName(archive)))
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
