package com.novan.audiolabnovan.sfx

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.karaoke.PenguraiLagu
import com.novan.audiolabnovan.karaoke.batasiLembut
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import java.io.File
import java.util.Locale

/**
 * Tahap 89: Tambah SFX. Pilih audio, susun daftar efek suara beserta waktu bunyinya, lalu simpan hasilnya.
 * Efek bisa dari 15 suara bawaan (dibuat dari rumus oleh [PembuatSfx], tanpa AI dan tanpa internet) atau dari
 * berkas audio sendiri (maksimal 30 detik per efek). Efek dicampur ke audio dalam bilangan pecahan lalu dibatasi
 * lembut ([batasiLembut]) supaya tidak pecah.
 */
class TambahSfxActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri_tambah_sfx"
        const val EXTRA_NAMA = "nama_tambah_sfx"
        private const val SUBFOLDER = "Tambah SFX"
        private const val SR = PenguraiLagu.SR
        private const val MAKS_SFX_DETIK = 30
        private val VOLUME = listOf(25, 50, 75, 100, 150)
        private val POSISI = listOf("Tengah", "Kiri", "Kanan")
        private val RUNDUK = listOf(0, 3, 6, 9)

        /** Waktu seperti "12", "12,5", "1:30", atau "0:12,5" menjadi detik; null bila tidak valid. */
        fun bacaWaktu(teks: String): Double? {
            val s = teks.trim().replace(',', '.')
            if (s.isEmpty()) return null
            val bagian = s.split(':')
            if (bagian.size > 3) return null
            var total = 0.0
            for (b in bagian) {
                val v = b.trim().toDoubleOrNull() ?: return null
                if (v.isNaN() || v.isInfinite() || v < 0.0) return null
                total = total * 60.0 + v
            }
            return total
        }

        fun tampilWaktu(detik: Double): String {
            val s = Math.round(detik * 10.0) / 10.0
            val m = (s / 60.0).toInt()
            val sisa = s - m * 60.0
            return String.format(Locale("id"), "%d:%04.1f", m, sisa)
        }
    }

    private class Dibatalkan : Exception()

    /** [id] >= 0: suara bawaan; [id] = -1: dari berkas ([stereo] terisi). */
    private class Sumber(val nama: String, val id: Int, val stereo: ShortArray?)

    private class Butir(val sumber: Sumber, val detik: Double, val persen: Int, val posisi: Int)

    private val daftarFormat = listOf(OutFmt.MP3, OutFmt.AAC, OutFmt.FLAC, OutFmt.WAV)
    private val sumberSfx = ArrayList<Sumber>()
    private val butir = ArrayList<Butir>()

    private var utama: Uri? = null
    private var namaUtama = ""
    private var pemutar: AudioTrack? = null

    private lateinit var tombolPilih: Button
    private lateinit var tombolProses: Button
    private lateinit var tombolBatal: Button
    private lateinit var spJenis: Spinner
    private lateinit var spVolume: Spinner
    private lateinit var spFormat: Spinner
    private lateinit var spPosisi: Spinner
    private lateinit var spRunduk: Spinner
    private lateinit var spPilihButir: Spinner
    private lateinit var etWaktu: EditText
    private lateinit var tvUtama: TextView
    private lateinit var tvDaftar: TextView
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar

    @Volatile private var batal = false
    @Volatile private var sibuk = false

    private val dialogHasil by lazy { DialogHasil(this) }

    private val pilihUtama = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setUtama(uri, null)
    }

    private val pilihSfx = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) muatSfxBerkas(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Tambah SFX"
        val c = this
        for ((i, n) in PembuatSfx.NAMA.withIndex()) sumberSfx.add(Sumber(n, i, null))

        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, "Tambah SFX"))
        akar.addView(AlatUi.label(c, "Tambahkan efek suara (tepuk tangan, bel, whoosh, dan lain-lain) ke audio pada waktu yang Anda tentukan. " +
            "Dikerjakan di HP tanpa AI dan tanpa internet."))

        tombolPilih = AlatUi.tombol(c, "Pilih audio utama") { pilihUtama.launch(arrayOf("audio/*", "video/*")) }
        akar.addView(tombolPilih, AlatUi.margin(c))
        tvUtama = AlatUi.label(c, "Belum ada audio dipilih.")
        akar.addView(tvUtama)

        spJenis = AlatUi.spinner(c, sumberSfx.map { it.nama })
        akar.addView(AlatUi.label(c, "Jenis efek suara", spJenis))
        akar.addView(spJenis, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Dengarkan efek ini") { dengarkan() }, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Pakai efek dari berkas sendiri") { pilihSfx.launch(arrayOf("audio/*")) }, AlatUi.margin(c))

        etWaktu = EditText(this).apply {
            hint = "Waktu bunyi, contoh 12 atau 1:30,5"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        akar.addView(AlatUi.label(c, "Waktu bunyi (detik atau menit:detik)", etWaktu))
        akar.addView(etWaktu, AlatUi.margin(c))

        spVolume = AlatUi.spinner(c, VOLUME.map { "$it persen" }).also { it.setSelection(3) }
        akar.addView(AlatUi.label(c, "Volume efek", spVolume))
        akar.addView(spVolume, AlatUi.margin(c))
        spPosisi = AlatUi.spinner(c, POSISI.map { if (it == "Tengah") "Tengah (kiri dan kanan sama)" else "Condong ke ${it.lowercase()}" })
        akar.addView(AlatUi.label(c, "Posisi efek", spPosisi))
        akar.addView(spPosisi, AlatUi.margin(c))

        akar.addView(AlatUi.tombol(c, "Tambah ke daftar") { tambah() }, AlatUi.margin(c))
        tvDaftar = TextView(this).apply {
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 8))
        }
        akar.addView(tvDaftar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        spPilihButir = AlatUi.spinner(c, listOf("(daftar kosong)"))
        akar.addView(AlatUi.label(c, "Pilih efek di daftar untuk dihapus", spPilihButir))
        akar.addView(spPilihButir, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Hapus efek terpilih") {
            val i = spPilihButir.selectedItemPosition
            if (butir.isNotEmpty() && i in butir.indices) {
                val b = butir.removeAt(i)
                segarkanDaftar()
                status("Dihapus: ${b.sumber.nama} pada ${tampilWaktu(b.detik)}. Sisa ${butir.size} efek.", true)
            }
        }, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Kosongkan daftar") { butir.clear(); segarkanDaftar() }, AlatUi.margin(c))

        spRunduk = AlatUi.spinner(c, RUNDUK.map { if (it == 0) "Mati" else "Turun $it dB" }).also { it.setSelection(2) }
        akar.addView(AlatUi.label(c, "Turunkan audio utama saat efek bunyi (supaya efek jelas terdengar)", spRunduk))
        akar.addView(spRunduk, AlatUi.margin(c))

        spFormat = AlatUi.spinner(c, daftarFormat.map { it.label })
        akar.addView(AlatUi.label(c, "Format hasil", spFormat))
        akar.addView(spFormat, AlatUi.margin(c))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        akar.addView(bar, AlatUi.margin(c))
        tombolProses = AlatUi.tombol(c, "Tambahkan SFX dan simpan") { proses() }
        akar.addView(tombolProses, AlatUi.margin(c))
        tombolBatal = AlatUi.tombol(c, "Batalkan") { batal = true; try { FFmpegKit.cancel() } catch (_: Throwable) { } }
        tombolBatal.isEnabled = false
        akar.addView(tombolBatal, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
        segarkanDaftar()

        intent.getStringExtra(EXTRA_URI)?.let { setUtama(Uri.parse(it), intent.getStringExtra(EXTRA_NAMA)) }
    }

    private fun namaDari(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { q ->
                if (q.moveToFirst()) q.getString(0)?.let { return it }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "audio"
    }

    private fun setUtama(uri: Uri, nama: String?) {
        utama = uri
        namaUtama = nama?.takeIf { it.isNotBlank() } ?: namaDari(uri)
        tvUtama.text = "Audio utama: $namaUtama"
        status("Audio dipilih. Pilih efek, isi waktunya, lalu tekan Tambah ke daftar.", true)
    }

    private fun status(t: String, umumkan: Boolean = false) {
        runOnUiThread {
            tvStatus.text = t
            if (umumkan) tvStatus.announceForAccessibility(t)
        }
    }

    private fun progres(p: Int) = runOnUiThread { bar.progress = p.coerceIn(0, 100) }

    private fun stereoDari(s: Sumber): ShortArray {
        s.stereo?.let { return it }
        val m = PembuatSfx.buat(s.id, SR)
        return ShortArray(m.size * 2) { m[it / 2] }
    }

    // ----------------------------------------------------------------- daftar efek

    private fun segarkanDaftar() {
        tvDaftar.text = if (butir.isEmpty()) {
            "Daftar efek masih kosong."
        } else {
            "Daftar efek (${butir.size}):\n" + butir.withIndex().joinToString("\n") { (i, b) ->
                "${i + 1}. ${ringkas(b)}"
            }
        }
        val item = if (butir.isEmpty()) listOf("(daftar kosong)") else butir.withIndex().map { (i, b) -> "${i + 1}. ${ringkas(b)}" }
        val lama = spPilihButir.selectedItemPosition
        spPilihButir.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, item)
        spPilihButir.setSelection(lama.coerceIn(0, item.size - 1))
    }

    private fun ringkas(b: Butir): String =
        "${b.sumber.nama}, pada ${tampilWaktu(b.detik)}, volume ${b.persen} persen" +
            (if (b.posisi != 0) ", condong ke ${POSISI[b.posisi].lowercase()}" else "")

    private fun tambah() {
        val waktu = bacaWaktu(etWaktu.text.toString())
        if (waktu == null) {
            status("Waktu tidak valid. Tulis detik seperti 12 atau 12,5, atau menit dan detik seperti 1:30.", true)
            return
        }
        val s = sumberSfx[spJenis.selectedItemPosition.coerceIn(0, sumberSfx.size - 1)]
        val persen = VOLUME[spVolume.selectedItemPosition.coerceIn(0, VOLUME.size - 1)]
        butir.add(Butir(s, waktu, persen, spPosisi.selectedItemPosition.coerceIn(0, POSISI.size - 1)))
        butir.sortBy { it.detik }
        segarkanDaftar()
        status("Ditambahkan: ${s.nama} pada ${tampilWaktu(waktu)}. Jumlah efek ${butir.size}.", true)
    }

    private fun muatSfxBerkas(uri: Uri) {
        status("Membaca efek dari berkas...", true)
        Thread {
            var pesan: String
            try {
                val lagu = PenguraiLagu.urai(this, uri, { false }) { }
                if (lagu == null || lagu.frame < 1) {
                    pesan = "Berkas efek tidak bisa dibaca sebagai audio."
                } else {
                    val maks = minOf(lagu.pcm.size, MAKS_SFX_DETIK * SR * 2)
                    val nama = "Berkas: " + PenguraiLagu.judul(this, uri)
                    val s = Sumber(nama, -1, lagu.pcm.copyOf(maks))
                    runOnUiThread {
                        sumberSfx.add(s)
                        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sumberSfx.map { it.nama })
                        spJenis.adapter = ad
                        spJenis.setSelection(sumberSfx.size - 1)
                    }
                    pesan = "Efek dari berkas siap dan sudah terpilih: ${s.nama}." +
                        if (lagu.pcm.size > maks) " Hanya $MAKS_SFX_DETIK detik pertama yang dipakai." else ""
                }
            } catch (e: Throwable) {
                pesan = "Efek dari berkas gagal dibaca: ${e.message ?: e.javaClass.simpleName}"
            }
            status(pesan, true)
        }.start()
    }

    private fun dengarkan() {
        hentikanContoh()
        try {
            val s = sumberSfx[spJenis.selectedItemPosition.coerceIn(0, sumberSfx.size - 1)]
            val pcm = stereoDari(s).let { if (it.size > 10 * SR * 2) it.copyOf(10 * SR * 2) else it }
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build())
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t.play()
            pemutar = t
        } catch (e: Throwable) {
            status("Efek tidak bisa diputar: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun hentikanContoh() {
        try { pemutar?.stop() } catch (_: Throwable) { }
        try { pemutar?.release() } catch (_: Throwable) { }
        pemutar = null
    }

    // ----------------------------------------------------------------- proses

    private fun proses() {
        val src = utama
        if (src == null) { status("Pilih audio utama dulu.", true); return }
        if (butir.isEmpty()) { status("Daftar efek masih kosong. Tambahkan minimal satu efek.", true); return }
        if (sibuk) { Toast.makeText(this, "Masih bekerja. Tunggu atau batalkan dulu.", Toast.LENGTH_SHORT).show(); return }
        hentikanContoh()
        val fmt = daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val judul = PenyimpanHasil.judulDari(namaUtama)
        val rencana = ArrayList(butir)
        val rundukDb = RUNDUK[spRunduk.selectedItemPosition.coerceIn(0, RUNDUK.size - 1)]

        sibuk = true
        batal = false
        tombolPilih.isEnabled = false
        tombolProses.isEnabled = false
        tombolBatal.isEnabled = true
        bar.progress = 0
        bar.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Membaca audio. Biarkan layar menyala sampai selesai.", true)

        Thread {
            var pesan: String? = null
            var uriHasil: Uri? = null
            var namaHasil = ""
            var catatan = ""
            val stamp = System.currentTimeMillis()
            val tmpWav = File(cacheDir, "sfx_$stamp.wav")
            val tmpOut = File(cacheDir, "sfx_$stamp.${fmt.ext}")
            try {
                var terakhir = -10
                val lagu = PenguraiLagu.urai(this, src, { batal }) { p ->
                    progres(p * 60 / 100)
                    if (p - terakhir >= 10) { terakhir = p; status("Membaca audio $p persen...") }
                }
                if (batal) throw Dibatalkan()
                if (lagu == null) { pesan = "Berkas ini tidak bisa dibaca sebagai audio."; return@Thread }
                val pcm = lagu.pcm
                val frame = lagu.frame

                status("Menambahkan efek suara...", true)
                val cache = HashMap<Sumber, ShortArray>()
                fun data(sm: Sumber): ShortArray = cache.getOrPut(sm) { stereoDari(sm) }

                // Audio utama merunduk di sekitar efek (selang yang saling tumpang digabung jadi satu).
                if (rundukDb > 0) {
                    val g = Math.pow(10.0, -rundukDb / 20.0)
                    val atak = (SR * 0.03).toInt()
                    val lepas = (SR * 0.25).toInt()
                    val selang = ArrayList<LongArray>()
                    for (b in rencana) {
                        val mulai = Math.round(b.detik * SR)
                        if (mulai >= frame) continue
                        selang.add(longArrayOf(mulai, minOf(frame.toLong(), mulai + data(b.sumber).size / 2L)))
                    }
                    selang.sortBy { it[0] }
                    val gabung = ArrayList<LongArray>()
                    for (x in selang) {
                        val akhirTerakhir = gabung.lastOrNull()
                        if (akhirTerakhir != null && x[0] <= akhirTerakhir[1] + lepas) {
                            akhirTerakhir[1] = maxOf(akhirTerakhir[1], x[1])
                        } else {
                            gabung.add(x)
                        }
                    }
                    for (m in gabung) {
                        if (batal) throw Dibatalkan()
                        val cs = m[0]
                        val ce = m[1]
                        val s0 = maxOf(0L, cs - atak)
                        val e0 = minOf(frame.toLong(), ce + lepas)
                        var k = s0
                        while (k < e0) {
                            val gain = when {
                                k < cs -> 1.0 - (1.0 - g) * (k - (cs - atak)).toDouble() / atak
                                k <= ce -> g
                                else -> g + (1.0 - g) * (k - ce).toDouble() / lepas
                            }
                            val p = (k * 2L).toInt()
                            pcm[p] = (pcm[p] * gain).toInt().toShort()
                            pcm[p + 1] = (pcm[p + 1] * gain).toInt().toShort()
                            k++
                        }
                    }
                }

                var dipakai = 0
                var dilewati = 0
                for ((k, b) in rencana.withIndex()) {
                    if (batal) throw Dibatalkan()
                    val mulai = Math.round(b.detik * SR)
                    if (mulai >= frame) { dilewati++; continue }
                    val sfx = data(b.sumber)
                    val g = b.persen / 100.0
                    val gKiri = g * (if (b.posisi == 2) 0.3 else 1.0)
                    val gKanan = g * (if (b.posisi == 1) 0.3 else 1.0)
                    val n = minOf(sfx.size / 2L, frame - mulai).toInt()
                    for (j in 0 until n) {
                        val p = ((mulai + j) * 2L).toInt()
                        pcm[p] = batasiLembut(pcm[p] + sfx[2 * j] * gKiri)
                        pcm[p + 1] = batasiLembut(pcm[p + 1] + sfx[2 * j + 1] * gKanan)
                    }
                    dipakai++
                    progres(60 + (k + 1) * 30 / rencana.size)
                }
                if (dipakai == 0) {
                    pesan = "Semua waktu efek melewati akhir audio, jadi tidak ada yang ditambahkan. Panjang audio ${tampilWaktu(frame.toDouble() / SR)}."
                    return@Thread
                }
                if (dilewati > 0) catatan = " $dilewati efek dilewati karena waktunya melewati akhir audio."

                status("Menyandi hasil...", true)
                progres(92)
                PenyimpanHasil.tulisWav(tmpWav, pcm, frame, SR, 2)
                if (batal) throw Dibatalkan()
                val galat = PenyimpanHasil.sandi(tmpWav, tmpOut, fmt, 192, judul, "Tambah SFX")
                if (galat != null) { pesan = galat; return@Thread }
                namaHasil = "SFX_" + PenyimpanHasil.stempel() + "." + fmt.ext
                uriHasil = PenyimpanHasil.simpan(this, tmpOut, namaHasil, fmt, SUBFOLDER)
                if (lagu.durasiMs >= PenguraiLagu.MAKS_MS - 2000) catatan += " Audio panjang: hanya 12 menit pertama yang diproses."
            } catch (e: Dibatalkan) {
                pesan = "Dibatalkan."
            } catch (e: OutOfMemoryError) {
                pesan = "Memori HP tidak cukup untuk berkas ini. Coba audio yang lebih pendek."
            } catch (e: Throwable) {
                pesan = "Gagal: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                tmpWav.delete()
                tmpOut.delete()
                val u = uriHasil
                val n = namaHasil
                val p = pesan
                val ket = catatan
                runOnUiThread { selesai(u, n, p, fmt, ket) }
            }
        }.start()
    }

    private fun selesai(uri: Uri?, nama: String, pesan: String?, fmt: OutFmt, catatan: String) {
        sibuk = false
        tombolPilih.isEnabled = true
        tombolProses.isEnabled = true
        tombolBatal.isEnabled = false
        bar.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (uri != null) {
            status("Selesai. Tersimpan di folder Musik, AudioLab Novan, Tambah SFX, dengan nama $nama.$catatan", true)
            dialogHasil.tampilkan(uri, nama, fmt.mime)
        } else {
            status(pesan ?: "Gagal.", true)
        }
    }

    override fun onDestroy() {
        batal = true
        hentikanContoh()
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}
