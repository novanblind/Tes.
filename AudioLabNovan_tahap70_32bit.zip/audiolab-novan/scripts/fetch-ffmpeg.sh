#!/usr/bin/env bash
# Unduh AAR FFmpeg (libmp3lame) yang dikunci versi + checksum-nya, lalu pangkas jadi
# armeabi-v7a saja (32-bit). Hasil: app/libs/ffmpeg-kit-6.1.1-arm32.aar
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=app/libs/ffmpeg-kit-6.1.1-arm32.aar
[ -s "$OUT" ] && { echo "sudah ada: $OUT"; exit 0; }
COMMIT=0ea7de70ceb270dadb15e4468d94a7648babe1b3
SHA=5b8da42b87d2e63292112f81c2611d4c208bade75c591426cae0d4c5c959d522
REPO="https://github.com/moizhassankh/ffmpeg-kit-android-16KB.git"
TMP=$(mktemp -d)
git init -q "$TMP/g"
git -C "$TMP/g" fetch -q --depth 1 "$REPO" "$COMMIT"
git -C "$TMP/g" checkout -q FETCH_HEAD
cp "$TMP/g/ffmpeg-kit-6.1.1.aar" "$TMP/full.aar"
echo "$SHA  $TMP/full.aar" | sha256sum -c -
mkdir -p "$TMP/x" app/libs
ROOT="$PWD"
(
  cd "$TMP/x"
  unzip -q ../full.aar
  [ -d jni/armeabi-v7a ] || { echo "GAGAL: jni/armeabi-v7a tidak ada di AAR"; exit 1; }
  rm -rf jni/arm64-v8a jni/x86 jni/x86_64
  # Pangkas set non-NEON (duplikat; HP 32-bit Android 7+ hampir semuanya NEON).
  # Hanya dibuang bila pasangan _neon-nya ada.
  for f in jni/armeabi-v7a/lib*.so; do
    b=$(basename "$f" .so)
    case "$b" in *_neon|c++_shared|ffmpegkit_abidetect) continue;; esac
    if [ "$b" = "libffmpegkit" ]; then n=jni/armeabi-v7a/libffmpegkit_armv7a_neon.so
    else n=jni/armeabi-v7a/${b}_neon.so; fi
    [ -f "$n" ] && rm -f "$f"
  done
  for need in libffmpegkit_armv7a_neon libffmpegkit_abidetect libc++_shared libavcodec_neon libavutil_neon; do
    [ -f "jni/armeabi-v7a/$need.so" ] || { echo "GAGAL: $need.so hilang setelah pangkas"; exit 1; }
  done
  ls -la jni/armeabi-v7a
  zip -q -r -X "$ROOT/$OUT" .
)
rm -rf "$TMP"
ls -la "$OUT"
