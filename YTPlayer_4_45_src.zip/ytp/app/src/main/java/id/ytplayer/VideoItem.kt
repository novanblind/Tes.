package id.ytplayer

import org.json.JSONObject
import java.util.Locale

/** Satu entri video pada daftar (hasil cari, terkait, riwayat). */
data class VideoItem(
    val url: String,
    val title: String,
    val uploader: String,
    val thumb: String?,
    val durationSec: Long,   // < 0 = siaran langsung / tidak diketahui
    val views: Long,         // < 0 = tidak diketahui
    val date: String
) {
    val isLive: Boolean get() = durationSec < 0

    fun meta(): String =
        listOf(uploader, Fmt.views(views), Fmt.indoDate(date)).filter { it.isNotBlank() }.joinToString(" • ")

    /** Kalimat lengkap untuk dibacakan TalkBack. */
    fun spoken(): String {
        val parts = ArrayList<String>()
        parts += title
        if (uploader.isNotBlank()) parts += "Oleh $uploader"
        Fmt.spokenViews(views).takeIf { it.isNotBlank() }?.let { parts += it }
        parts += if (isLive) "Siaran langsung" else "Durasi ${Fmt.spokenDuration(durationSec)}"
        Fmt.indoDate(date).takeIf { it.isNotBlank() }?.let { parts += it }
        return parts.joinToString(". ")
    }

    fun toJson(): JSONObject = JSONObject()
        .put("url", url).put("title", title).put("uploader", uploader)
        .put("thumb", thumb ?: "").put("dur", durationSec).put("views", views).put("date", date)

    companion object {
        fun fromJson(o: JSONObject) = VideoItem(
            url = o.optString("url"),
            title = o.optString("title"),
            uploader = o.optString("uploader"),
            thumb = o.optString("thumb").ifEmpty { null },
            durationSec = o.optLong("dur", -1),
            views = o.optLong("views", -1),
            date = o.optString("date")
        )
    }
}

/** Pemformat teks tampilan dan teks ucapan (Bahasa Indonesia). */
object Fmt {
    private val id = Locale("id", "ID")

    // Mengenali bentuk panjang dan singkatan: "6 months ago", "6 mo ago", "2 yr ago", "5 hr ago", "3 wk ago", dst.
    private val relRe = Regex(
        "(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?|wks?|months?|mos?|years?|yrs?|s|h|d|w|y)\\s+ago",
        RegexOption.IGNORE_CASE
    )
    private val absRe = Regex("\\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\.?\\s+(\\d{1,2}),\\s+(\\d{4})")
    private val months = mapOf(
        "Jan" to "Jan", "Feb" to "Feb", "Mar" to "Mar", "Apr" to "Apr", "May" to "Mei", "Jun" to "Jun",
        "Jul" to "Jul", "Aug" to "Agu", "Sep" to "Sep", "Oct" to "Okt", "Nov" to "Nov", "Dec" to "Des"
    )

    /** Menerjemahkan keterangan waktu unggah dari YouTube (Inggris) ke Bahasa Indonesia. */
    fun indoDate(raw: String): String {
        var s = raw.trim()
        if (s.isEmpty()) return s
        s = s.replace(Regex("^Streamed live\\s+", RegexOption.IGNORE_CASE), "Siaran langsung ")
            .replace(Regex("^Streamed\\s+", RegexOption.IGNORE_CASE), "Disiarkan ")
            .replace(Regex("^Premiered\\s+", RegexOption.IGNORE_CASE), "Tayang perdana ")
        s = relRe.replace(s) { m ->
            val u = m.groupValues[2].lowercase()
            val unit = when {
                u.startsWith("sec") || u == "s" -> "detik"
                u.startsWith("mi") -> "menit"
                u.startsWith("h") -> "jam"
                u.startsWith("d") -> "hari"
                u.startsWith("w") -> "minggu"
                u.startsWith("mo") -> "bulan"
                else -> "tahun"
            }
            "${m.groupValues[1]} $unit lalu"
        }
        s = absRe.replace(s) { m ->
            "${m.groupValues[2]} ${months[m.groupValues[1]] ?: m.groupValues[1]} ${m.groupValues[3]}"
        }
        s = s.replace(Regex("^Yesterday$", RegexOption.IGNORE_CASE), "Kemarin")
            .replace(Regex("^Today$", RegexOption.IGNORE_CASE), "Hari ini")
            .replace(Regex("^just now$", RegexOption.IGNORE_CASE), "baru saja")
        return s
    }

    private val relIdRe = Regex(
        "(\\d+)\\s*(detik|menit|jam|hari|minggu|bulan|tahun)\\s+(?:yang\\s+)?lalu",
        RegexOption.IGNORE_CASE
    )
    private val monthIdx = mapOf(
        "jan" to 0, "feb" to 1, "mar" to 2, "apr" to 3, "may" to 4, "jun" to 5,
        "jul" to 6, "aug" to 7, "sep" to 8, "oct" to 9, "nov" to 10, "dec" to 11
    )

    /**
     * Perkiraan umur video (detik) dari keterangan waktu unggah YouTube ("3 weeks ago",
     * "2 minggu lalu", "Mar 5, 2024", ...). Mengembalikan -1 bila tidak bisa dibaca.
     * Bulan dihitung 30 hari dan tahun 365 hari, sama seperti pembulatan YouTube.
     */
    fun ageSeconds(raw: String): Long {
        val s = raw.trim()
        if (s.isEmpty()) return -1
        val rel = relRe.find(s)
        if (rel != null) {
            val n = rel.groupValues[1].toLongOrNull() ?: return -1
            val u = rel.groupValues[2].lowercase()
            val unit = when {
                u.startsWith("sec") || u == "s" -> 1L
                u.startsWith("mi") -> 60L
                u.startsWith("h") -> 3600L
                u.startsWith("d") -> 86400L
                u.startsWith("w") -> 604800L
                u.startsWith("mo") -> 2592000L
                else -> 31536000L
            }
            return n * unit
        }
        val ind = relIdRe.find(s)
        if (ind != null) {
            val n = ind.groupValues[1].toLongOrNull() ?: return -1
            val unit = when (ind.groupValues[2].lowercase()) {
                "detik" -> 1L
                "menit" -> 60L
                "jam" -> 3600L
                "hari" -> 86400L
                "minggu" -> 604800L
                "bulan" -> 2592000L
                else -> 31536000L
            }
            return n * unit
        }
        val low = s.lowercase()
        if (low.endsWith("yesterday") || low.endsWith("kemarin")) return 86400L
        if (low.endsWith("today") || low.endsWith("hari ini") || low.endsWith("just now") ||
            low.endsWith("baru saja")
        ) return 0L
        val abs = absRe.find(s)
        if (abs != null) {
            val mi = monthIdx[abs.groupValues[1].lowercase().take(3)] ?: return -1
            val day = abs.groupValues[2].toIntOrNull() ?: return -1
            val year = abs.groupValues[3].toIntOrNull() ?: return -1
            val cal = java.util.Calendar.getInstance()
            cal.clear()
            cal.set(year, mi, day)
            val age = (System.currentTimeMillis() - cal.timeInMillis) / 1000
            return if (age < 0) 0L else age
        }
        return -1
    }

    fun clock(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(id, "%d:%02d:%02d", h, m, sec)
        else String.format(id, "%d:%02d", m, sec)
    }

    fun spokenDuration(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        val parts = ArrayList<String>()
        if (h > 0) parts += "$h jam"
        if (m > 0) parts += "$m menit"
        if (sec > 0 || parts.isEmpty()) parts += "$sec detik"
        return parts.joinToString(" ")
    }

    private fun compact(v: Long, long: Boolean): String {
        fun one(x: Double): String = String.format(id, "%.1f", x).removeSuffix(",0")
        return when {
            v >= 1_000_000_000 -> one(v / 1e9) + if (long) " miliar" else " M"
            v >= 1_000_000 -> one(v / 1e6) + if (long) " juta" else " jt"
            v >= 1_000 -> one(v / 1e3) + if (long) " ribu" else " rb"
            else -> v.toString()
        }
    }

    fun views(v: Long): String = if (v < 0) "" else "${compact(v, false)} x ditonton"
    fun spokenViews(v: Long): String = if (v < 0) "" else "${compact(v, true)} kali ditonton"
}

/** Filter tanggal unggah seperti YouTube asli. maxAgeSec = 0 berarti tanpa filter. */
object DateFilter {
    class Option(val label: String, val maxAgeSec: Long)

    val options = listOf(
        Option("Kapan saja", 0L),
        Option("Satu jam terakhir", 3600L),
        Option("Hari ini", 86400L),
        Option("Minggu ini", 7 * 86400L),
        Option("Bulan ini", 30 * 86400L),
        Option("Tahun ini", 365 * 86400L)
    )

    /** Video tanpa keterangan tanggal yang bisa dibaca (mis. siaran langsung) tidak lolos filter. */
    fun matches(item: VideoItem, maxAgeSec: Long): Boolean {
        if (maxAgeSec <= 0L) return true
        val age = Fmt.ageSeconds(item.date)
        return age in 0..maxAgeSec
    }
}
