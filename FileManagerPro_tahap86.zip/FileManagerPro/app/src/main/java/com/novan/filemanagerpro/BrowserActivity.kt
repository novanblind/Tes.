package com.novan.filemanagerpro

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.format.DateFormat
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ActionMode
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Date
import java.util.concurrent.Executors

class BrowserActivity : AppCompatActivity() {

    companion object {
        /** Nama folder akar yang umum di Android (termasuk partisi khusus merek). */
        private val ROOT_NAMES = listOf(
            "acct", "apex", "bin", "bugreports", "cache", "config", "cust", "d", "data", "data_mirror",
            "debug_ramdisk", "dev", "etc", "hw_product", "init", "lib", "linkerconfig", "lost+found",
            "metadata", "mi_ext", "mnt", "my_bigball", "my_carrier", "my_company", "my_engineering",
            "my_heytap", "my_manifest", "my_preload", "my_product", "my_region", "my_stock", "odm",
            "odm_dlkm", "oem", "optics", "prism", "proc", "product", "root", "sbin", "sdcard",
            "second_stage_resources", "storage", "sys", "system", "system_dlkm", "system_ext",
            "vendor", "vendor_dlkm", "vendor_overlay", "version"
        )

        const val EXTRA_ROOT = "root"
        const val EXTRA_TITLE = "title"
        const val EXTRA_NEWEST = "newest"
        const val EXTRA_MODE = "mode"
        const val MODE_PICK_FOLDER = "pick_folder"
        const val MODE_PICK_FILE = "pick_file"
        const val RESULT_PATH = "result_path"
    }

    private class Act(val label: String, val run: () -> Unit)

    private lateinit var root: File
    private lateinit var current: File
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: View
    private lateinit var rootTitle: String
    /** Mode Unduhan: selalu urut dari yang paling baru di atas, bukan menurut nama. */
    private var newestFirst = false

    private var files: List<File> = emptyList()
    private var actionMode: ActionMode? = null
    private var searchQuery: String? = null
    private var mode: String? = null
    private var afterPick: ((File) -> Unit)? = null

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) afterPick?.invoke(File(p))
            afterPick = null
        }

    @Volatile
    private var searchToken = 0

    private val executor = Executors.newSingleThreadExecutor()
    private val searchExecutor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        mode = intent.getStringExtra(EXTRA_MODE)
        root = File(intent.getStringExtra(EXTRA_ROOT) ?: "/storage/emulated/0")
        rootTitle = intent.getStringExtra(EXTRA_TITLE) ?: root.name
        newestFirst = intent.getBooleanExtra(EXTRA_NEWEST, false)
        current = File(savedInstanceState?.getString("current") ?: root.absolutePath)

        empty = findViewById(R.id.empty)
        rowAdapter = RowAdapter(
            onClick = { onRowClick(it) },
            onLong = { onRowLong(it) }
        )
        val list = findViewById<RecyclerView>(R.id.list)
        list.adapter = rowAdapter
        val swipe = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.swipe)
        findViewById<View>(R.id.crumbScroll).visibility = View.VISIBLE
        (swipe.layoutParams as android.widget.FrameLayout.LayoutParams).topMargin =
            (48 * resources.displayMetrics.density).toInt()
        swipe.setOnRefreshListener {
            if (searchQuery == null) refresh()
            swipe.isRefreshing = false
        }
        applyViewMode()
        findViewById<android.widget.Button>(R.id.pasteDo).setOnClickListener { paste() }
        findViewById<android.widget.Button>(R.id.pasteCancel).setOnClickListener {
            Clipboard.clear()
            invalidateOptionsMenu()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goUp()
            }
        })

        open(current, announce = false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("current", current.absolutePath)
    }

    private var mini: MiniPlayer? = null

    override fun onStart() {
        super.onStart()
        val m = mini ?: MiniPlayer(this, findViewById(R.id.miniPlayer)).also { mini = it }
        m.start()
        OpService.listeners.add(opListener)
        if (opSeen != OpService.version) {
            opSeen = OpService.version
            refresh()
        }
    }

    override fun onStop() {
        super.onStop()
        OpService.listeners.remove(opListener)
        mini?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        opDialog?.dismiss()
        executor.shutdownNow()
        searchExecutor.shutdownNow()
    }

    // ---------------------------------------------------------------- navigasi

    private fun goUp() {
        if (actionMode != null) {
            actionMode?.finish()
            return
        }
        if (searchQuery != null) {
            exitSearch()
            return
        }
        if (current.absolutePath == root.absolutePath) {
            finish()
        } else {
            val parent = current.parentFile
            if (parent != null) open(parent) else finish()
        }
    }

    private fun exitSearch() {
        searchQuery = null
        searchToken++
        open(current, announce = false)
    }

    private fun comparator(): Comparator<File> {
        if (newestFirst) {
            return compareByDescending<File> { it.lastModified() }.thenBy { it.name.lowercase() }
        }
        if (Prefs.sortKey(this) == 4) return compareBy<File> { !it.isDirectory }
        val base: Comparator<File> = when (Prefs.sortKey(this)) {
            1 -> compareBy<File> { it.length() }
            2 -> compareBy<File> { it.lastModified() }
            3 -> compareBy<File>({ it.extension.lowercase() }, { it.name.lowercase() })
            else -> compareBy<File> { it.name.lowercase() }
        }
        val dir = if (Prefs.sortAsc(this)) base else base.reversed()
        return compareBy<File> { !it.isDirectory }.then(dir)
    }

    private fun open(dir: File, announce: Boolean = true) {
        // Android/data dan Android/obb tidak bisa dibaca aplikasi biasa: buka lewat Files sistem.
        if (SystemFiles.isRestricted(dir)) {
            SystemFiles.openOrExplain(this, dir) { say(it) }
            if (dir.absolutePath == root.absolutePath) finish()
            return
        }
        current = dir
        val name = if (dir.absolutePath == root.absolutePath) rootTitle else dir.name
        title = name
        supportActionBar?.subtitle = dir.absolutePath
        buildCrumbs(dir)
        val hidden = Prefs.showHidden(this)
        val cmp = comparator()

        executor.execute {
            val children = listChildren(dir)
                .filter { hidden || !it.name.startsWith(".") }
                .sortedWith(cmp)
            val rows = children.map { toRow(it, false) }
            main.post {
                if (isFinishing || isDestroyed) return@post
                if (searchQuery != null || current.absolutePath != dir.absolutePath) return@post
                files = children
                rowAdapter.submit(rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                invalidateOptionsMenu()
                if (announce) {
                    say(getString(R.string.folder_opened, name, rows.size))
                }
            }
        }
    }

    /**
     * Isi folder. Bila daftar biasa gagal (mis. folder akar "/" atau folder yang bacanya dibatasi),
     * dicoba lewat perintah `ls`, dan untuk "/" ditambah nama folder akar yang umum di semua merek
     * ponsel; hanya yang benar-benar ada yang ditampilkan.
     */
    private fun listChildren(dir: File): List<File> {
        val isRoot = dir.absolutePath == "/"
        val direct = try { dir.listFiles() } catch (e: Exception) { null }
        if (direct != null && !(isRoot && direct.isEmpty())) {
            return if (isRoot) direct.filter { exists(it) } else direct.toList()
        }
        val names = LinkedHashSet<String>()
        shellNames(dir)?.let { names.addAll(it) }
        if (isRoot) names.addAll(ROOT_NAMES)
        val out = ArrayList<File>()
        for (n in names) {
            val f = File(dir, n)
            if (exists(f)) out.add(f)
        }
        return out
    }

    private fun exists(f: File): Boolean = try { f.exists() } catch (e: Exception) { false }

    private fun shellNames(dir: File): List<String>? {
        var p: Process? = null
        return try {
            val q = dir.absolutePath.replace("'", "'\\''")
            p = ProcessBuilder("sh", "-c", "ls -1A '$q' 2>/dev/null").start()
            val lines = p.inputStream.bufferedReader().readLines().filter { it.isNotEmpty() }
            p.waitFor()
            if (lines.isEmpty()) null else lines
        } catch (e: Exception) {
            null
        } finally {
            try { p?.destroy() } catch (e: Exception) { /* abaikan */ }
        }
    }

    /** Jalur folder yang bisa diketuk, dari akar sampai folder saat ini. */
    private fun buildCrumbs(dir: File) {
        val box = findViewById<android.widget.LinearLayout>(R.id.crumbs)
        box.removeAllViews()
        val chain = ArrayList<File>()
        var f: File? = dir
        while (f != null) {
            chain.add(0, f)
            if (f.absolutePath == root.absolutePath) break
            f = f.parentFile
        }
        if (chain.firstOrNull()?.absolutePath != root.absolutePath) {
            chain.clear()
            chain.add(dir)
        }
        for ((i, d) in chain.withIndex()) {
            if (i > 0) {
                val sep = android.widget.TextView(this)
                sep.text = "›"
                sep.textSize = 18f
                sep.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                box.addView(sep)
            }
            val t = android.widget.TextView(this)
            t.text = if (d.absolutePath == root.absolutePath) rootTitle else d.name
            t.textSize = 15f
            t.gravity = android.view.Gravity.CENTER_VERTICAL
            t.minHeight = (48 * resources.displayMetrics.density).toInt()
            t.setPadding(
                (8 * resources.displayMetrics.density).toInt(), 0,
                (8 * resources.displayMetrics.density).toInt(), 0
            )
            val last = i == chain.size - 1
            t.setTextColor(
                if (last) 0xFF008578.toInt() else getColor(android.R.color.darker_gray)
            )
            t.isClickable = !last
            t.isFocusable = true
            t.contentDescription = t.text
            if (!last) t.setOnClickListener { open(d) }
            box.addView(t)
        }
        val sc = findViewById<android.widget.HorizontalScrollView>(R.id.crumbScroll)
        sc.post { sc.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun applyViewMode() {
        val list = findViewById<RecyclerView>(R.id.list)
        val grid = Prefs.viewMode(this) == 2
        rowAdapter.grid = grid
        list.layoutManager = if (grid) {
            val dp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
            GridLayoutManager(this, (dp / 110).toInt().coerceAtLeast(2))
        } else {
            LinearLayoutManager(this)
        }
    }

    private fun refresh() {
        if (searchQuery != null) exitSearch() else open(current, announce = false)
    }

    private fun iconFor(f: File): Int {
        if (f.isDirectory) return R.drawable.ic_folder
        if (ArchiveOps.isSupported(f)) return R.drawable.ic_archive
        if (f.extension.equals("apk", ignoreCase = true)) return R.drawable.ic_apk
        return when (Util.kindOf(f)) {
            Util.K_IMAGE -> R.drawable.ic_image
            Util.K_AUDIO -> R.drawable.ic_audio
            Util.K_VIDEO -> R.drawable.ic_video
            else -> R.drawable.ic_file
        }
    }

    private fun toRow(f: File, showPath: Boolean): Row {
        val detailed = Prefs.viewMode(this) == 1
        val stamp = Date(f.lastModified())
        val date = if (detailed) {
            DateFormat.getMediumDateFormat(this).format(stamp) + " " +
                DateFormat.getTimeFormat(this).format(stamp)
        } else {
            DateFormat.getMediumDateFormat(this).format(stamp)
        }
        return if (f.isDirectory) {
            val n = f.list()?.count { !it.startsWith(".") }
            val cnt = if (n == null) getString(R.string.items_unknown) else getString(R.string.items_count, n)
            val detail = if (showPath) (f.parent ?: "")
            else if (detailed) cnt + ", " + date
            else cnt
            Row(
                iconFor(f), f.name, detail,
                "${f.name}, $detail", f.absolutePath
            )
        } else {
            val size = Util.formatSize(this, f.length())
            val detail = if (showPath) "${f.parent ?: ""}, $size" else "$size, $date"
            val kind = Util.kindOf(f)
            val thumb = if (Prefs.showThumbs(this) && (kind == Util.K_IMAGE || kind == Util.K_VIDEO))
                f.absolutePath else null
            Row(
                iconFor(f), f.name, detail,
                "${f.name}, $detail", f.absolutePath,
                thumb = thumb
            )
        }
    }

    private fun say(text: String) {
        Snackbar.make(findViewById(android.R.id.content), text, Snackbar.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- klik baris

    private fun onRowClick(i: Int) {
        if (i !in files.indices) return
        if (actionMode != null) {
            toggle(i)
            return
        }
        val f = files[i]
        if (f.isDirectory) {
            searchQuery = null
            searchToken++
            open(f)
        } else {
            when (mode) {
                null -> openFile(f)
                MODE_PICK_FILE -> returnPath(f)
                else -> say(getString(R.string.pick_folder_hint))
            }
        }
    }

    private fun returnPath(f: File) {
        setResult(RESULT_OK, Intent().putExtra(RESULT_PATH, f.absolutePath))
        finish()
    }

    private fun onRowLong(i: Int) {
        if (mode != null) return
        if (i !in files.indices) return
        if (actionMode != null) toggle(i) else showActions(i)
    }

    private fun showActions(i: Int) {
        val f = files[i]
        val acts = ArrayList<Act>()
        acts.add(Act(getString(R.string.menu_select)) { startSelection(i) })
        acts.add(Act(getString(R.string.act_open)) { onRowClick(i) })
        acts.add(Act(getString(R.string.action_copy)) { toClipboard(listOf(f), false) })
        acts.add(Act(getString(R.string.action_cut)) { toClipboard(listOf(f), true) })
        acts.add(Act(getString(R.string.act_rename)) { promptRename(f) })
        acts.add(Act(getString(R.string.act_compress)) { promptCompress(listOf(f)) })
        if (ArchiveOps.isSupported(f)) {
            acts.add(Act(getString(R.string.act_view_archive)) {
                startActivity(Intent(this, ArchiveActivity::class.java).putExtra(ArchiveActivity.EXTRA_PATH, f.absolutePath))
            })
            acts.add(Act(getString(R.string.extract_here)) { extractHere(f) })
            acts.add(Act(getString(R.string.extract_to)) { extractTo(f) })
        }
        if (f.isFile && f.length() > 65536L) {
            acts.add(Act(getString(R.string.act_split_file)) {
                SplitSize.pick(this, true) { size ->
                    startOp(OpJobs.splitFile(f, size, getString(R.string.op_splitting)))
                }
            })
        }
        if (f.isFile && f.name.endsWith(".001") && ArchiveOps.partsOf(f).isNotEmpty()) {
            acts.add(Act(getString(R.string.act_join_parts)) {
                startOp(OpJobs.joinParts(f, getString(R.string.op_joining)))
            })
        }
        acts.add(Act(getString(R.string.action_delete)) { confirmDelete(listOf(f)) })
        if (f.isFile) {
            acts.add(Act(getString(R.string.action_share)) { share(listOf(f)) })
            acts.add(Act(getString(R.string.action_share_doc)) { shareDoc(listOf(f)) })
            acts.add(Act(getString(R.string.act_open_with)) {
                if (!Util.openWith(this, f)) say(getString(R.string.cannot_open))
            })
            acts.add(Act(getString(R.string.act_open_as)) { promptOpenAs(f) })
            acts.add(Act(getString(R.string.act_edit_text)) {
                if (!Util.openInEditor(this, f)) say(getString(R.string.cannot_open))
            })
            if (Util.kindOf(f) == Util.K_AUDIO) {
                acts.add(Act(getString(R.string.act_ringtone)) { promptRingtone(f) })
            }
        }
        if (f.isFile) {
            acts.add(Act(getString(R.string.act_checksum)) { showChecksum(f) })
        }
        acts.add(Act(getString(if (f.name.startsWith(".")) R.string.act_unhide else R.string.act_hide)) { toggleHidden(f) })
        acts.add(Act(getString(R.string.act_properties)) { showProperties(f) })
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(acts.map { it.label }.toTypedArray()) { _, which -> acts[which].run() }
            .show()
    }

    // ---------------------------------------------------------------- mode pilih

    private val modeCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            menuInflater.inflate(R.menu.selection_menu, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.sel_all -> {
                    rowAdapter.setAllSelected(true)
                    updateModeTitle()
                }
                R.id.sel_copy -> withSelection { toClipboard(it, false); mode.finish() }
                R.id.sel_cut -> withSelection { toClipboard(it, true); mode.finish() }
                R.id.sel_delete -> withSelection { confirmDelete(it) }
                R.id.sel_share -> withSelection { share(it) }
                R.id.sel_share_doc -> withSelection { shareDoc(it) }
                R.id.sel_compress -> withSelection { promptCompress(it) }
                R.id.sel_range -> promptRange()
                R.id.sel_rename -> withSelection { promptBatchRename(it) }
                R.id.sel_pdf -> withSelection { promptPdf(it) }
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            actionMode = null
            rowAdapter.setAllSelected(null)
        }
    }

    private fun startSelection(initial: Int?) {
        if (actionMode != null) return
        actionMode = startSupportActionMode(modeCallback)
        rowAdapter.setAllSelected(false)
        if (initial != null) rowAdapter.setSelected(initial, true)
        updateModeTitle()
    }

    private fun toggle(i: Int) {
        rowAdapter.setSelected(i, rowAdapter.rows[i].selected != true)
        updateModeTitle()
    }

    private fun updateModeTitle() {
        actionMode?.title = getString(R.string.n_selected, rowAdapter.selectedIndices().size)
    }

    private fun selectedFiles(): List<File> =
        rowAdapter.selectedIndices().filter { it in files.indices }.map { files[it] }

    private fun withSelection(block: (List<File>) -> Unit) {
        val sel = selectedFiles()
        if (sel.isNotEmpty()) block(sel)
    }

    // ---------------------------------------------------------------- menu opsi

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.browser_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val inSearch = searchQuery != null
        val paste = menu.findItem(R.id.action_paste)
        val browse = mode == null
        menu.findItem(R.id.action_pick_folder).isVisible = mode == MODE_PICK_FOLDER && !inSearch
        menu.findItem(R.id.action_select).isVisible = browse
        menu.findItem(R.id.action_new_file).isVisible = browse && !inSearch
        menu.findItem(R.id.action_new_note).isVisible = browse && !inSearch
        paste.isVisible = browse && Clipboard.size > 0 && !inSearch
        paste.title = getString(R.string.menu_paste_count, Clipboard.size)
        val bar = findViewById<View>(R.id.pasteBar)
        bar.visibility = if (paste.isVisible) View.VISIBLE else View.GONE
        findViewById<android.widget.TextView>(R.id.pasteInfo).text = getString(
            if (Clipboard.cut) R.string.paste_bar_move else R.string.paste_bar_copy,
            Clipboard.size
        )
        menu.findItem(R.id.action_adv_search).isVisible = browse
        menu.findItem(R.id.action_new_folder).isVisible = !inSearch
        menu.findItem(R.id.action_hidden).isChecked = Prefs.showHidden(this)
        val bm = menu.findItem(R.id.action_bookmark)
        bm.isVisible = browse && !inSearch
        menu.findItem(R.id.action_shortcut).isVisible = browse && !inSearch
        bm.title = getString(
            if (Bookmarks.has(this, current.absolutePath)) R.string.menu_bookmark_remove
            else R.string.menu_bookmark_add
        )
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> goUp()
            R.id.action_search -> promptSearch()
            R.id.action_adv_search -> startActivity(
                Intent(this, SearchActivity::class.java)
                    .putExtra(SearchActivity.EXTRA_ROOT, current.absolutePath)
                    .putExtra(SearchActivity.EXTRA_TITLE, current.name.ifEmpty { rootTitle })
            )
            R.id.action_new_folder -> promptName(R.string.menu_new_folder, "") { createFolder(it) }
            R.id.action_new_file -> promptName(R.string.menu_new_file, "") { createFile(it) }
            R.id.action_new_note -> promptName(R.string.menu_new_note, "") { createNote(it) }
            R.id.action_paste -> paste()
            R.id.action_pick_folder -> returnPath(current)
            R.id.action_select -> if (files.isNotEmpty()) startSelection(null)
            R.id.action_sort -> if (newestFirst) say(getString(R.string.sort_newest_fixed)) else showSortDialog()
            R.id.action_view -> showViewDialog()
            R.id.action_bookmark -> toggleBookmark()
            R.id.action_shortcut -> addShortcut()
            R.id.action_hidden -> {
                Prefs.setShowHidden(this, !Prefs.showHidden(this))
                if (searchQuery != null) exitSearch() else open(current, announce = false)
            }
            R.id.action_refresh -> if (searchQuery != null) exitSearch() else open(current, announce = false)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun addShortcut() {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            say(getString(R.string.shortcut_unsupported))
            return
        }
        val name = current.name.ifEmpty { rootTitle }
        val target = Intent(this, BrowserActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .putExtra(EXTRA_ROOT, current.absolutePath)
            .putExtra(EXTRA_TITLE, name)
        val sc = ShortcutInfoCompat.Builder(this, "dir:" + current.absolutePath)
            .setShortLabel(name)
            .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
            .setIntent(target)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, sc, null)
        say(getString(R.string.shortcut_requested, name))
    }

    private fun toggleBookmark() {
        val p = current.absolutePath
        val name = current.name.ifEmpty { rootTitle }
        if (Bookmarks.has(this, p)) {
            Bookmarks.remove(this, p)
            say(getString(R.string.bookmark_removed, name))
        } else {
            Bookmarks.add(this, p)
            say(getString(R.string.bookmark_added, name))
        }
    }

    private fun showSortDialog() {
        val labels = arrayOf(
            getString(R.string.sort_name_asc), getString(R.string.sort_name_desc),
            getString(R.string.sort_size_asc), getString(R.string.sort_size_desc),
            getString(R.string.sort_date_asc), getString(R.string.sort_date_desc),
            getString(R.string.sort_type_asc), getString(R.string.sort_type_desc),
            getString(R.string.sort_none)
        )
        val checked = if (Prefs.sortKey(this) == 4) 8
        else Prefs.sortKey(this) * 2 + if (Prefs.sortAsc(this)) 0 else 1
        AlertDialog.Builder(this)
            .setTitle(R.string.sort_title)
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                Prefs.setSort(this, which / 2, which % 2 == 0)
                dialog.dismiss()
                if (searchQuery != null) exitSearch() else open(current, announce = false)
            }
            .show()
    }

    private fun showViewDialog() {
        val labels = arrayOf(
            getString(R.string.view_list), getString(R.string.view_details), getString(R.string.view_grid)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.view_title)
            .setSingleChoiceItems(labels, Prefs.viewMode(this)) { dialog, which ->
                Prefs.setViewMode(this, which)
                dialog.dismiss()
                applyViewMode()
                refresh()
            }
            .show()
    }

    private fun promptTwo(
        titleRes: Int, hint1: String, init1: String, numeric1: Boolean,
        hint2: String, init2: String, numeric2: Boolean,
        onOk: (String, String) -> Unit
    ) {
        fun field(hint: String, init: String, numeric: Boolean) = EditText(this).apply {
            setText(init)
            this.hint = hint
            contentDescription = hint
            inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val a = field(hint1, init1, numeric1)
        val b = field(hint2, init2, numeric2)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(a)
            addView(b)
        }
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(a.text.toString().trim(), b.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Pilih rentang: nomor urut berkas di daftar, mulai dari 1. */
    private fun promptRange() {
        val total = rowAdapter.rows.size
        promptTwo(
            R.string.range_title,
            getString(R.string.range_start), "1", true,
            getString(R.string.range_end), total.toString(), true
        ) { a, b ->
            val from = a.toIntOrNull()
            val to = b.toIntOrNull()
            if (from == null || to == null || from > to) {
                say(getString(R.string.range_invalid)); return@promptTwo
            }
            if (from < 1 || to > total) {
                say(getString(R.string.range_out, total)); return@promptTwo
            }
            for (i in (from - 1) until to) rowAdapter.setSelected(i, true)
            updateModeTitle()
            say(getString(R.string.range_selected, to - from + 1))
        }
    }

    private fun promptBatchRename(list: List<File>) {
        val labels = arrayOf(getString(R.string.batch_numbering), getString(R.string.batch_replace))
        AlertDialog.Builder(this)
            .setTitle(R.string.batch_rename)
            .setItems(labels) { _, which ->
                if (which == 0) batchNumbering(list) else batchReplace(list)
            }
            .show()
    }

    private fun batchNumbering(list: List<File>) {
        promptTwo(
            R.string.batch_numbering,
            getString(R.string.batch_base), "", false,
            getString(R.string.batch_start), "1", true
        ) { base, startText ->
            val start = startText.toIntOrNull()
            if (base.isEmpty() || start == null || start < 0 || base.contains('/')) {
                say(getString(R.string.invalid_name)); return@promptTwo
            }
            val digits = (start + list.size - 1).toString().length
            val plan = list.mapIndexed { idx, f ->
                val n = (start + idx).toString().padStart(digits, '0')
                val ext = if (f.isFile && f.extension.isNotEmpty()) "." + f.extension else ""
                f to File(f.parentFile, "$base $n$ext")
            }
            batchRename(plan)
        }
    }

    private fun batchReplace(list: List<File>) {
        promptTwo(
            R.string.batch_replace,
            getString(R.string.batch_find), "", false,
            getString(R.string.batch_with), "", false
        ) { find, with ->
            if (find.isEmpty() || with.contains('/')) {
                say(getString(R.string.invalid_name)); return@promptTwo
            }
            val plan = list.mapNotNull { f ->
                val nn = f.name.replace(find, with, ignoreCase = true)
                if (nn == f.name) null
                else if (!validName(nn)) null
                else f to File(f.parentFile, nn)
            }
            if (plan.isEmpty()) { say(getString(R.string.batch_nothing)); return@promptTwo }
            batchRename(plan)
        }
    }

    /** Dua tahap lewat nama sementara, supaya nama yang saling bertukar tidak bentrok. */
    private fun batchRename(plan: List<Pair<File, File>>) {
        runTask(R.string.renaming) {
            val sources = plan.map { it.first.absolutePath }.toSet()
            var ok = 0
            var fail = 0
            val temps = ArrayList<Triple<File, File, File>>()
            for ((src, target) in plan) {
                if (src.absolutePath == target.absolutePath) continue
                if (target.exists() && target.absolutePath !in sources) { fail++; continue }
                val tmp = File(src.parentFile, ".rn_" + System.nanoTime() + "_" + temps.size)
                if (src.renameTo(tmp)) temps.add(Triple(src, tmp, target)) else fail++
            }
            for ((src, tmp, target) in temps) {
                if (!target.exists() && tmp.renameTo(target)) ok++ else { tmp.renameTo(src); fail++ }
            }
            getString(R.string.batch_rename_result, ok, fail)
        }
    }

    // ---------------------------------------------------------------- dialog bantu

    private fun promptName(titleRes: Int, initial: String, onOk: (String) -> Unit) {
        val edit = EditText(this).apply {
            setText(initial)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            hint = getString(R.string.name_hint)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(edit)
        }
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(edit.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun validName(name: String): Boolean =
        name.isNotEmpty() && !name.contains('/') && name != "." && name != ".."

    private fun createFolder(name: String) {
        if (!validName(name)) { say(getString(R.string.invalid_name)); return }
        val f = File(current, name)
        if (f.exists()) { say(getString(R.string.already_exists)); return }
        if (f.mkdirs()) {
            say(getString(R.string.created))
            open(current, announce = false)
        } else {
            say(getString(R.string.op_failed, name))
        }
    }

    private fun createFile(name: String) {
        if (!validName(name)) { say(getString(R.string.invalid_name)); return }
        val f = File(current, name)
        if (f.exists()) { say(getString(R.string.already_exists)); return }
        try {
            if (f.createNewFile()) {
                say(getString(R.string.created))
                open(current, announce = false)
            } else {
                say(getString(R.string.op_failed, name))
            }
        } catch (e: Exception) {
            say(getString(R.string.op_failed, e.message ?: name))
        }
    }

    /** Catatan teks: buat berkas .txt lalu langsung buka di editor untuk menulis. */
    private fun createNote(raw: String) {
        var name = raw
        if (name.isNotEmpty() && !name.contains('.')) name += ".txt"
        if (!validName(name)) { say(getString(R.string.invalid_name)); return }
        val f = File(current, name)
        if (f.exists()) { say(getString(R.string.already_exists)); return }
        try {
            if (f.createNewFile()) {
                open(current, announce = false)
                startActivity(
                    Intent(this, TextEditorActivity::class.java)
                        .putExtra(TextEditorActivity.EXTRA_PATH, f.absolutePath)
                )
            } else {
                say(getString(R.string.op_failed, name))
            }
        } catch (e: Exception) {
            say(getString(R.string.op_failed, e.message ?: name))
        }
    }

    /** PDF dari gambar yang dipilih: satu gambar per halaman, urut sesuai daftar. */
    private fun promptPdf(sel: List<File>) {
        val imgs = sel.filter { it.isFile && Util.kindOf(it) == Util.K_IMAGE }
        if (imgs.isEmpty()) { say(getString(R.string.pdf_need_images)); return }
        val stamp = DateFormat.format("yyyyMMdd_HHmmss", Date()).toString()
        promptName(R.string.pdf_title, "Gambar_$stamp.pdf") { raw ->
            var name = raw
            if (name.isNotEmpty() && !name.lowercase().endsWith(".pdf")) name += ".pdf"
            if (!validName(name)) { say(getString(R.string.invalid_name)); return@promptName }
            val out = File(current, name)
            if (out.exists()) { say(getString(R.string.already_exists)); return@promptName }
            actionMode?.finish()
            val dlg = AlertDialog.Builder(this)
                .setMessage(getString(R.string.pdf_making, 0, imgs.size))
                .setCancelable(false)
                .show()
            val dir = current
            executor.execute {
                var pages = 0
                var err: String? = null
                try {
                    pages = PdfMaker.create(imgs, out) { done, total ->
                        main.post { if (!isDestroyed) dlg.setMessage(getString(R.string.pdf_making, done, total)) }
                    }
                } catch (e: Exception) {
                    err = e.message ?: name
                } catch (e: OutOfMemoryError) {
                    err = getString(R.string.pdf_memory)
                }
                main.post {
                    if (isDestroyed) return@post
                    dlg.dismiss()
                    when {
                        err != null -> say(getString(R.string.op_failed, err))
                        pages == 0 -> say(getString(R.string.pdf_none_read))
                        else -> {
                            say(getString(R.string.pdf_done, name, pages))
                            if (current == dir) open(current, announce = false)
                        }
                    }
                }
            }
        }
    }

    private fun promptRename(f: File) {
        promptName(R.string.act_rename, f.name) { newName ->
            if (!validName(newName)) { say(getString(R.string.invalid_name)); return@promptName }
            if (newName == f.name) return@promptName
            val target = File(f.parentFile, newName)
            if (target.exists()) { say(getString(R.string.already_exists)); return@promptName }
            if (f.renameTo(target)) {
                say(getString(R.string.renamed))
                if (searchQuery != null) exitSearch() else open(current, announce = false)
            } else {
                say(getString(R.string.rename_failed))
            }
        }
    }

    /** Sembunyikan/tampilkan dengan menambah atau membuang titik di awal nama. */
    private fun toggleHidden(f: File) {
        val newName = if (f.name.startsWith(".")) f.name.trimStart('.') else "." + f.name
        if (newName.isEmpty() || !validName(newName)) { say(getString(R.string.invalid_name)); return }
        val target = File(f.parentFile, newName)
        if (target.exists()) { say(getString(R.string.already_exists)); return }
        if (f.renameTo(target)) {
            say(getString(if (newName.startsWith(".")) R.string.hidden_done else R.string.unhidden_done))
            if (searchQuery != null) exitSearch() else open(current, announce = false)
        } else {
            say(getString(R.string.rename_failed))
        }
    }

    /** Menghitung MD5, SHA-1 dan SHA-256 sekaligus dalam satu kali baca berkas. */
    private fun showChecksum(f: File) {
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.act_checksum)
            .setMessage(R.string.calculating)
            .setNegativeButton(R.string.close, null)
            .show()
        executor.execute {
            val result: Map<String, String>? = try {
                val algos = listOf("MD5", "SHA-1", "SHA-256")
                val digests = algos.map { java.security.MessageDigest.getInstance(it) }
                f.inputStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        for (d in digests) d.update(buf, 0, n)
                    }
                }
                val map = LinkedHashMap<String, String>()
                for (k in algos.indices) {
                    map[algos[k]] = digests[k].digest().joinToString("") { "%02x".format(it) }
                }
                map
            } catch (e: Exception) {
                null
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                if (result == null) { say(getString(R.string.checksum_failed)); return@post }
                val text = result.entries.joinToString("\n") { it.key + ": " + it.value }
                AlertDialog.Builder(this)
                    .setTitle(R.string.act_checksum)
                    .setMessage(f.name + "\n\n" + text)
                    .setPositiveButton(R.string.checksum_copy) { _, _ ->
                        val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("checksum", text))
                        say(getString(R.string.checksum_copied))
                    }
                    .setNeutralButton(R.string.checksum_compare) { _, _ -> promptCompareChecksum(result) }
                    .setNegativeButton(R.string.close, null)
                    .show()
            }
        }
    }

    private fun promptCompareChecksum(result: Map<String, String>) {
        promptName(R.string.checksum_compare, "") { typed ->
            val want = typed.trim().lowercase().replace(" ", "")
            if (want.isEmpty()) return@promptName
            val hit = result.entries.firstOrNull { it.value == want }
            if (hit != null) say(getString(R.string.checksum_match, hit.key))
            else say(getString(R.string.checksum_mismatch))
        }
    }

    private fun promptSearch() {
        promptName(R.string.menu_search, "") { q ->
            if (q.isEmpty()) return@promptName
            startSearch(q)
        }
    }

    private fun startSearch(q: String) {
        actionMode?.finish()
        searchQuery = q
        val token = ++searchToken
        title = getString(R.string.search_results, q)
        supportActionBar?.subtitle = current.absolutePath
        val dir = current
        val hidden = Prefs.showHidden(this)
        searchExecutor.execute {
            val out = ArrayList<File>()
            FileOps.search(dir, q, hidden, out, 500) { token == searchToken }
            val rows = out.map { toRow(it, true) }
            main.post {
                if (isFinishing || isDestroyed || token != searchToken) return@post
                files = out
                rowAdapter.submit(rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                invalidateOptionsMenu()
                say(getString(R.string.search_done, rows.size))
            }
        }
    }

    // ---------------------------------------------------------------- operasi

    private var opSeen = OpService.version

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val opListener: (String) -> Unit = { msg ->
        if (!isDestroyed) {
            opSeen = OpService.version
            say(msg)
            refresh()
        }
    }

    /** Menjalankan operasi di layanan latar depan agar tetap jalan walau layar atau aplikasi ditutup. */
    private fun startOp(job: OpService.Job) {
        if (OpService.needsNotifPermission(this) && !notifAsked) {
            notifAsked = true
            notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        actionMode?.finish()
        OpService.enqueue(this, job)
        opDialog?.dismiss()
        opDialog = OpDialog(this, job) { say(getString(R.string.op_hidden)) }.also { it.show() }
    }

    private var opDialog: OpDialog? = null

    private fun runTask(msgRes: Int, work: () -> String) {
        val dlg = AlertDialog.Builder(this).setMessage(msgRes).setCancelable(false).show()
        executor.execute {
            val result = try {
                work()
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                actionMode?.finish()
                say(result)
                if (searchQuery != null) exitSearch() else open(current, announce = false)
            }
        }
    }

    private fun toClipboard(list: List<File>, cut: Boolean) {
        Clipboard.set(list, cut)
        invalidateOptionsMenu()
        say(getString(if (cut) R.string.clip_cut else R.string.clip_copy, list.size))
    }

    private fun paste() {
        val cut = Clipboard.cut
        val title = getString(if (cut) R.string.op_moving else R.string.op_copying)
        val zip = Clipboard.zipArchive
        val target = current
        val files = Clipboard.files.toList()
        val zipEntries = Clipboard.zipEntries
        val zipTops = Clipboard.zipTops
        val conflicts = if (zip != null) Conflicts.forZip(zipTops, zipEntries, target)
        else Conflicts.forFiles(files, cut, target)
        val go = { actions: Map<String, ConflictAction> ->
            val job = if (zip != null) {
                OpJobs.pasteZip(zip, zipEntries, zipTops, cut, target, title, actions)
            } else {
                OpJobs.paste(files, cut, target, title, actions)
            }
            // Setelah ditempel, papan klip kosong lagi dan tombol Tempel hilang.
            Clipboard.clear()
            invalidateOptionsMenu()
            startOp(job)
        }
        if (conflicts.isEmpty()) {
            go(emptyMap())
        } else {
            // Papan klip tetap utuh bila pengguna menekan Batal.
            Conflicts.ask(this, conflicts) { actions -> if (actions != null) go(actions) }
        }
    }

    private fun confirmDelete(list: List<File>) {
        DeleteDialog.show(this, list) { toTrash -> doDelete(list, toTrash) }
    }

    private fun doDelete(list: List<File>, toTrash: Boolean) {
        startOp(OpJobs.delete(list, toTrash, getString(R.string.op_deleting)))
    }

    private fun mimeOf(f: File): String {
        val ext = MimeTypeMap.getFileExtensionFromUrl(f.name).lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    private fun uriOf(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun share(list: List<File>) {
        val fs = list.filter { it.isFile }
        if (fs.isEmpty()) { say(getString(R.string.no_files_share)); return }
        try {
            val intent = if (fs.size == 1) {
                Intent(Intent.ACTION_SEND)
                    .setType(mimeOf(fs[0]))
                    .putExtra(Intent.EXTRA_STREAM, uriOf(fs[0]))
            } else {
                val uris = ArrayList<Uri>(fs.map { uriOf(it) })
                Intent(Intent.ACTION_SEND_MULTIPLE)
                    .setType("*/*")
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
        } catch (e: Exception) {
            say(getString(R.string.op_failed, e.message ?: ""))
        }
    }

    private fun shareDoc(list: List<File>) {
        val fs = list.filter { it.isFile }
        if (fs.isEmpty()) { say(getString(R.string.no_files_share)); return }
        if (!Util.shareAsDocument(this, fs)) say(getString(R.string.cannot_open))
    }

    private fun showProperties(f: File) {
        PropsDialog.showFile(this, f)
    }

    private fun promptCompress(list: List<File>) {
        val labels = arrayOf(
            getString(R.string.fmt_zip), getString(R.string.fmt_targz), getString(R.string.fmt_7z),
            getString(R.string.fmt_zip_split)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.compress_format)
            .setItems(labels) { _, format ->
                val base = if (list.size == 1) list[0].name else current.name
                CompressLevel.pick(this) { level ->
                  CompressLevel.askPassword(this, format == ArchiveOps.OUT_ZIP || format == ArchiveOps.OUT_ZIP_SPLIT) { password ->
                   SplitSize.pick(this, format == ArchiveOps.OUT_ZIP_SPLIT) { split ->
                    promptName(R.string.act_compress, base) { name ->
                        if (!validName(name)) { say(getString(R.string.invalid_name)); return@promptName }
                        val out = FileOps.uniqueTarget(current, name + ArchiveOps.outExt(format))
                        startOp(OpJobs.compress(list, format, out, getString(R.string.op_compressing), level, password, split))
                    }
                   }
                  }
                }
            }
            .show()
    }

    private fun extractHere(f: File) {
        val dest = FileOps.uniqueTarget(f.parentFile ?: current, ArchiveOps.baseName(f))
        runTask(R.string.extracting) {
            val n = ArchiveOps.extract(this, f, dest)
            getString(R.string.extract_done, n)
        }
    }

    private fun extractTo(f: File) {
        afterPick = { dir ->
            val dest = FileOps.uniqueTarget(dir, ArchiveOps.baseName(f))
            runTask(R.string.extracting) {
                val n = ArchiveOps.extract(this, f, dest)
                getString(R.string.extract_done, n)
            }
        }
        pickLauncher.launch(
            Intent(this, BrowserActivity::class.java)
                .putExtra(EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                .putExtra(EXTRA_TITLE, getString(R.string.pick_folder_title))
                .putExtra(EXTRA_MODE, MODE_PICK_FOLDER)
        )
    }

    private fun promptOpenAs(f: File) {
        val labels = arrayOf(
            getString(R.string.as_text), getString(R.string.as_image), getString(R.string.as_audio),
            getString(R.string.as_video), getString(R.string.as_any)
        )
        val mimes = arrayOf("text/plain", "image/*", "audio/*", "video/*", "*/*")
        AlertDialog.Builder(this)
            .setTitle(R.string.open_as_title)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    // "Teks": langsung di editor teks bawaan (bisa disimpan), tanpa lewat aplikasi lain
                    if (!Util.openInEditor(this, f)) say(getString(R.string.cannot_open))
                } else if (!Util.openWith(this, f, mimes[which])) say(getString(R.string.cannot_open))
            }
            .show()
    }

    private fun promptRingtone(f: File) {
        val labels = arrayOf(
            getString(R.string.ringtone_call), getString(R.string.ringtone_notif),
            getString(R.string.ringtone_alarm)
        )
        val types = intArrayOf(
            android.media.RingtoneManager.TYPE_RINGTONE,
            android.media.RingtoneManager.TYPE_NOTIFICATION,
            android.media.RingtoneManager.TYPE_ALARM
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.ringtone_title)
            .setItems(labels) { _, which -> say(getString(Util.setRingtone(this, f, types[which]))) }
            .show()
    }

    private fun openFile(f: File) {
        if (Util.openSmart(this, f, files)) return
        say(getString(R.string.cannot_open))
    }

    @Suppress("unused")
    private fun openFileExternal(f: File) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uriOf(f), mimeOf(f))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            say(getString(R.string.cannot_open))
        } catch (e: IllegalArgumentException) {
            say(getString(R.string.cannot_open))
        }
    }
}

private var notifAsked = false
