package org.telegram.messenger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.telegram.tgnet.TLRPC;

/**
 * Novan Tel - transkripsi pesan suara (tahap 16).
 *
 * Baris "Transkripsi" di menu tekan-tahan pesan suara dan video bulat. Berkasnya dikirim ke Whisper di Groq
 * (kunci API milik pengguna, disimpan di HP), hasilnya ditampilkan di kotak teks yang bisa dipilih. Bila bahasa
 * suara berbeda dari bahasa tujuan (bawaan Indonesia), teks langsung diterjemahkan lewat model chat Groq.
 * Hasil disimpan sementara di memori supaya pesan yang sama tidak diminta berulang.
 */
public class NovanTranskripsi {

    /** Daftar model (dipisah koma) dari build; dicoba berurutan sampai ada yang berhasil. */
    private static final String[] MODEL_SUARA = "__MODEL_SUARA__".split(",");
    private static final String[] MODEL_CHAT = "__MODEL_CHAT__".split(",");

    private static final long BATAS_BERKAS = 25L * 1024L * 1024L;
    private static final String URL_SUARA = "https://api.groq.com/openai/v1/audio/transcriptions";
    private static final String URL_CHAT = "https://api.groq.com/openai/v1/chat/completions";
    private static final String URL_KUNCI = "https://console.groq.com/keys";

    /** kode Whisper, nama Inggris (dipakai di perintah terjemahan dan pembanding bahasa), label Indonesia. */
    public static final String[][] BAHASA = {
            {"id", "Indonesian", "Indonesia"},
            {"en", "English", "Inggris"},
            {"ar", "Arabic", "Arab"},
            {"jw", "Javanese", "Jawa"},
            {"su", "Sundanese", "Sunda"},
            {"ms", "Malay", "Melayu"},
            {"zh", "Chinese", "Mandarin"},
            {"ja", "Japanese", "Jepang"},
            {"ko", "Korean", "Korea"},
            {"fr", "French", "Prancis"},
            {"de", "German", "Jerman"},
            {"es", "Spanish", "Spanyol"},
            {"pt", "Portuguese", "Portugis"},
            {"it", "Italian", "Italia"},
            {"nl", "Dutch", "Belanda"},
            {"ru", "Russian", "Rusia"},
            {"tr", "Turkish", "Turki"},
            {"hi", "Hindi", "Hindi"},
            {"ur", "Urdu", "Urdu"},
            {"fa", "Persian", "Persia"},
            {"th", "Thai", "Thailand"},
            {"vi", "Vietnamese", "Vietnam"}
    };

    private static final Object KUNCI_SIBUK = new Object();
    private static volatile boolean sibuk = false;
    private static final Map<String, Hasil> SIMPANAN = new HashMap<String, Hasil>();

    private static class Hasil {
        String asli;
        String bahasaAsli;   // nama Inggris huruf kecil dari Whisper, atau null
        String terjemah;     // null bila tidak diterjemahkan
        String tujuan;       // kode bahasa terjemahan
        String catatan;      // pesan galat terjemahan, bila ada
    }

    private NovanTranskripsi() {
    }

    // ------------------------------------------------------------ pilihan pengguna

    private static SharedPreferences pref() {
        Context c = ApplicationLoader.applicationContext;
        return c == null ? null : c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE);
    }

    public static String kunci() {
        SharedPreferences p = pref();
        String k = p == null ? "" : p.getString("groq_kunci", "");
        return k == null ? "" : k.trim();
    }

    public static boolean menuAktif() {
        return menuNyala();
    }

    private static boolean menuNyala() {
        SharedPreferences p = pref();
        return p == null ? NovanMod.TRANSKRIPSI : p.getBoolean("transkripsi", NovanMod.TRANSKRIPSI);
    }

    private static boolean terjemahOtomatis() {
        SharedPreferences p = pref();
        return p == null || p.getBoolean("transkripsi_terjemah_otomatis", true);
    }

    private static String bahasaTujuan() {
        SharedPreferences p = pref();
        String k = p == null ? "id" : p.getString("transkripsi_bahasa_tujuan", "id");
        return cariBahasa(k) != null ? k : "id";
    }

    private static String bahasaSuara() {
        SharedPreferences p = pref();
        String k = p == null ? "auto" : p.getString("transkripsi_bahasa_suara", "auto");
        return "auto".equals(k) || cariBahasa(k) != null ? k : "auto";
    }

    private static String[] cariBahasa(String kode) {
        for (String[] b : BAHASA) {
            if (b[0].equals(kode)) {
                return b;
            }
        }
        return null;
    }

    private static String labelBahasa(String kode) {
        String[] b = cariBahasa(kode);
        return b == null ? kode : b[2];
    }

    /** Label Indonesia dari nama Inggris yang dilaporkan Whisper (mis. "english" menjadi "Inggris"). */
    private static String labelDariNama(String nama) {
        if (nama == null) {
            return null;
        }
        for (String[] b : BAHASA) {
            if (b[1].equalsIgnoreCase(nama)) {
                return b[2];
            }
        }
        return nama;
    }

    // ------------------------------------------------------------ titik masuk dari menu pesan

    /** Tampilkan baris Transkripsi untuk pesan ini? Pesan suara atau video bulat, bila sakelar nyala. */
    public static boolean bisa(MessageObject m) {
        try {
            if (!menuNyala() || m == null || m.messageOwner == null) {
                return false;
            }
            return MessageObject.isVoiceMessage(m.messageOwner) || videoBulat(m);
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean videoBulat(MessageObject m) {
        try {
            Object r = MessageObject.class.getMethod("isRoundVideoMessage", TLRPC.Message.class).invoke(null, m.messageOwner);
            return r instanceof Boolean && (Boolean) r;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String kunciPesan(MessageObject m) {
        return m.currentAccount + "_" + m.getDialogId() + "_" + m.getId();
    }

    public static void mulai(final Activity act, final MessageObject m) {
        final Context c = act != null ? act : ApplicationLoader.applicationContext;
        if (c == null || m == null) {
            return;
        }
        final File berkas = NovanMod.berkasPesan(m);
        if (berkas == null) {
            Toast.makeText(c, "Berkas belum terunduh. Unduh atau putar dulu, lalu coba lagi.", Toast.LENGTH_LONG).show();
            return;
        }
        if (berkas.length() > BATAS_BERKAS) {
            Toast.makeText(c, "Berkas lebih dari 25 MB, melebihi batas Groq.", Toast.LENGTH_LONG).show();
            return;
        }
        final String kunciApi = kunci();
        if (kunciApi.isEmpty()) {
            if (act != null) {
                dialogKunci(act, new Runnable() {
                    @Override
                    public void run() {
                        mulai(act, m);
                    }
                });
            } else {
                Toast.makeText(c, "Kunci API Groq belum diisi di Pengaturan Novan Tel", Toast.LENGTH_LONG).show();
            }
            return;
        }
        final String id = kunciPesan(m);
        Hasil ada;
        synchronized (KUNCI_SIBUK) {
            ada = SIMPANAN.get(id);
        }
        if (ada != null && act != null) {
            tampil(act, ada);
            return;
        }
        if (sibuk) {
            Toast.makeText(c, "Transkripsi sebelumnya masih berjalan", Toast.LENGTH_SHORT).show();
            return;
        }
        sibuk = true;
        final boolean bulat = videoBulat(m);
        final String suara = bahasaSuara();
        final String tujuan = bahasaTujuan();
        final boolean otomatis = terjemahOtomatis();
        Toast.makeText(c, "Sedang mentranskripsi...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    proses(act, c, m, id, berkas, bulat, kunciApi, suara, tujuan, otomatis);
                } catch (Throwable t) {
                    Log.w("NovanTranskripsi", "gagal", t);
                    toast(c, "Transkripsi gagal: " + t.getClass().getSimpleName());
                } finally {
                    sibuk = false;
                }
            }
        }).start();
    }

    private static void proses(final Activity act, Context c, MessageObject m, String id, File berkas, boolean bulat,
                               String kunciApi, String suara, String tujuan, boolean otomatis) {
        String[] r = null;
        String galat = "Koneksi gagal";
        for (String model : MODEL_SUARA) {
            model = model.trim();
            if (model.isEmpty()) {
                continue;
            }
            for (int percobaan = 0; percobaan < 2 && r == null; percobaan++) {
                String[] x = kirimSuara(berkas, bulat, kunciApi, model, suara);
                if (x[0] != null) {
                    r = x;
                } else {
                    galat = x[2];
                    if (percobaan == 0) {
                        tidur(2000);
                    }
                }
            }
            if (r != null) {
                break;
            }
        }
        if (r == null) {
            toast(c, "Gagal: " + galat);
            return;
        }
        final Hasil h = new Hasil();
        h.asli = r[0];
        h.bahasaAsli = r[1];
        h.tujuan = tujuan;
        if (otomatis) {
            boolean sama = h.bahasaAsli != null && cariBahasa(tujuan) != null
                    && cariBahasa(tujuan)[1].equalsIgnoreCase(h.bahasaAsli);
            if (!sama) {
                String[] t = terjemahkan(h.asli, tujuan, kunciApi);
                if (t[0] != null) {
                    h.terjemah = t[0];
                } else {
                    h.catatan = "Terjemahan gagal: " + t[1];
                }
            }
        }
        synchronized (KUNCI_SIBUK) {
            if (SIMPANAN.size() > 60) {
                SIMPANAN.clear();
            }
            SIMPANAN.put(id, h);
        }
        if (act != null) {
            AndroidUtilities.runOnUIThread(new Runnable() {
                @Override
                public void run() {
                    tampil(act, h);
                }
            });
        } else {
            toast(c, h.terjemah != null ? h.terjemah : h.asli);
        }
    }

    // ------------------------------------------------------------ permintaan ke Groq

    private static void tidur(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static String ekstensi(String nama) {
        int t = nama == null ? -1 : nama.lastIndexOf('.');
        return t >= 0 && t < nama.length() - 1 ? nama.substring(t + 1).toLowerCase(Locale.US) : "";
    }

    private static String jenis(String ext) {
        if ("mp3".equals(ext)) {
            return "audio/mpeg";
        } else if ("m4a".equals(ext)) {
            return "audio/m4a";
        } else if ("wav".equals(ext)) {
            return "audio/wav";
        } else if ("flac".equals(ext)) {
            return "audio/flac";
        } else if ("mp4".equals(ext)) {
            return "video/mp4";
        } else if ("webm".equals(ext)) {
            return "video/webm";
        }
        return "audio/ogg";
    }

    private static String baca(InputStream in) throws java.io.IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String b;
        while ((b = r.readLine()) != null) {
            sb.append(b);
        }
        r.close();
        return sb.toString();
    }

    private static String galatHttp(HttpURLConnection conn, int kode, String model) {
        String d;
        if (kode == 401) {
            d = "Kunci API Groq salah atau kedaluwarsa";
        } else if (kode == 413) {
            d = "Berkas terlalu besar untuk Groq";
        } else if (kode == 429) {
            d = "Batas kuota atau kecepatan Groq tercapai, tunggu sebentar (" + model + ")";
        } else {
            d = "Galat HTTP " + kode + " (" + model + ")";
        }
        try {
            InputStream es = conn.getErrorStream();
            if (es != null) {
                String pesan = new JSONObject(baca(es)).getJSONObject("error").getString("message");
                if (pesan != null && !pesan.isEmpty()) {
                    d = d + ": " + (pesan.length() > 140 ? pesan.substring(0, 140) : pesan);
                }
            }
        } catch (Throwable ignored) {
        }
        return d;
    }

    /** Hasil: {teks, bahasa Whisper atau null, galat}. teks null berarti gagal. */
    private static String[] kirimSuara(File berkas, boolean bulat, String kunciApi, String model, String bahasa) {
        HttpURLConnection conn = null;
        try {
            String batas = "BatasNovan" + System.currentTimeMillis();
            String crlf = "\r\n";
            String nama = berkas.getName().replace("\"", "");
            String ext = ekstensi(nama);
            if (!"ogg".equals(ext) && !"mp3".equals(ext) && !"m4a".equals(ext) && !"wav".equals(ext)
                    && !"flac".equals(ext) && !"mp4".equals(ext) && !"webm".equals(ext)) {
                ext = bulat ? "mp4" : "ogg";
                nama = "pesan." + ext;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("--").append(batas).append(crlf);
            sb.append("Content-Disposition: form-data; name=\"model\"").append(crlf).append(crlf);
            sb.append(model).append(crlf);
            if (bahasa != null && !bahasa.isEmpty() && !"auto".equals(bahasa)) {
                sb.append("--").append(batas).append(crlf);
                sb.append("Content-Disposition: form-data; name=\"language\"").append(crlf).append(crlf);
                sb.append(bahasa).append(crlf);
            }
            sb.append("--").append(batas).append(crlf);
            sb.append("Content-Disposition: form-data; name=\"response_format\"").append(crlf).append(crlf);
            sb.append("verbose_json").append(crlf);
            sb.append("--").append(batas).append(crlf);
            sb.append("Content-Disposition: form-data; name=\"file\"; filename=\"").append(nama).append("\"").append(crlf);
            sb.append("Content-Type: ").append(jenis(ext)).append(crlf).append(crlf);
            byte[] kepala = sb.toString().getBytes("UTF-8");
            byte[] ekor = (crlf + "--" + batas + "--" + crlf).getBytes("UTF-8");

            conn = (HttpURLConnection) new URL(URL_SUARA).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(120000);
            conn.setRequestProperty("Authorization", "Bearer " + kunciApi);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + batas);
            conn.setFixedLengthStreamingMode(kepala.length + berkas.length() + ekor.length);

            OutputStream o = conn.getOutputStream();
            o.write(kepala);
            InputStream f = new FileInputStream(berkas);
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = f.read(buf)) != -1) {
                    o.write(buf, 0, n);
                }
            } finally {
                f.close();
            }
            o.write(ekor);
            o.flush();
            o.close();

            int kode = conn.getResponseCode();
            if (kode != 200) {
                return new String[]{null, null, galatHttp(conn, kode, model)};
            }
            JSONObject j = new JSONObject(baca(conn.getInputStream()));
            String teks = j.optString("text", "").trim();
            if (teks.isEmpty()) {
                return new String[]{null, null, "Hasil transkripsi kosong (tidak ada ucapan yang terdengar)"};
            }
            String bhs = j.optString("language", "");
            return new String[]{teks, bhs.isEmpty() ? null : bhs.toLowerCase(Locale.US), null};
        } catch (Throwable t) {
            return new String[]{null, null, "Koneksi gagal: " + t.getClass().getSimpleName()};
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** Hasil: {jawaban, galat}. jawaban null berarti semua model gagal. */
    private static String[] chat(String sistem, String pengguna, String kunciApi) {
        String galat = "Koneksi gagal";
        for (String model : MODEL_CHAT) {
            model = model.trim();
            if (model.isEmpty()) {
                continue;
            }
            HttpURLConnection conn = null;
            try {
                JSONObject akar = new JSONObject();
                akar.put("model", model);
                JSONArray pesan = new JSONArray();
                pesan.put(new JSONObject().put("role", "system").put("content", sistem));
                pesan.put(new JSONObject().put("role", "user").put("content", pengguna));
                akar.put("messages", pesan);
                akar.put("temperature", 0.3);
                byte[] isi = akar.toString().getBytes("UTF-8");

                conn = (HttpURLConnection) new URL(URL_CHAT).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(90000);
                conn.setRequestProperty("Authorization", "Bearer " + kunciApi);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setFixedLengthStreamingMode(isi.length);
                OutputStream o = conn.getOutputStream();
                o.write(isi);
                o.flush();
                o.close();
                int kode = conn.getResponseCode();
                if (kode != 200) {
                    galat = galatHttp(conn, kode, model);
                    continue;
                }
                JSONObject j = new JSONObject(baca(conn.getInputStream()));
                JSONArray pilihan = j.getJSONArray("choices");
                if (pilihan.length() == 0) {
                    galat = "Jawaban kosong (" + model + ")";
                    continue;
                }
                String jawab = pilihan.getJSONObject(0).getJSONObject("message").optString("content", "");
                jawab = jawab.replaceAll("(?s)<think>.*?</think>", "").trim();
                if (jawab.isEmpty()) {
                    galat = "Jawaban kosong (" + model + ")";
                    continue;
                }
                return new String[]{jawab, null};
            } catch (Throwable t) {
                galat = "Koneksi gagal: " + t.getClass().getSimpleName();
            } finally {
                if (conn != null) {
                    try {
                        conn.disconnect();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
        return new String[]{null, galat};
    }

    private static String[] terjemahkan(String teks, String kodeTujuan, String kunciApi) {
        String[] b = cariBahasa(kodeTujuan);
        String nama = b == null ? "Indonesian" : b[1];
        String sistem = "You are a professional translator. Translate the user's text into natural, fluent " + nama
                + ". Keep the original meaning and tone. Output only the translation, with no introduction, notes or quotes.";
        return chat(sistem, teks, kunciApi);
    }

    private static String[] rangkum(String teks, String kodeTujuan, String kunciApi) {
        String[] b = cariBahasa(kodeTujuan);
        String nama = b == null ? "Indonesian" : b[1];
        String sistem = "You are a helpful assistant. Summarize the user's text into 3 to 5 short key points written in " + nama
                + ". Output only the points, one per line, starting each with a dash.";
        return chat(sistem, teks, kunciApi);
    }

    // ------------------------------------------------------------ tampilan hasil

    private static void toast(final Context c, final String t) {
        AndroidUtilities.runOnUIThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(c, t, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static void salinKe(Context c, String teks) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("transkripsi", teks));
            Toast.makeText(c, "Teks tersalin", Toast.LENGTH_SHORT).show();
        } catch (Throwable e) {
            Toast.makeText(c, "Gagal menyalin", Toast.LENGTH_SHORT).show();
        }
    }

    private static EditText kotakTeks(Activity act, String isi, String deskripsi) {
        EditText et = new EditText(act);
        et.setText(isi);
        et.setKeyListener(null);
        et.setTextIsSelectable(true);
        et.setFocusable(true);
        et.setFocusableInTouchMode(true);
        et.setTextSize(17);
        et.setContentDescription(deskripsi);
        int pad = (int) (16 * act.getResources().getDisplayMetrics().density + 0.5f);
        et.setPadding(pad, pad, pad, pad);
        return et;
    }

    private static String teksUtama(Hasil h) {
        return h.terjemah != null ? h.terjemah : h.asli;
    }

    private static void tampil(final Activity act, final Hasil h) {
        try {
            StringBuilder sb = new StringBuilder();
            String judul;
            if (h.terjemah != null) {
                judul = "Transkripsi dan terjemahan";
                sb.append("Terjemahan (").append(labelBahasa(h.tujuan)).append("):\n").append(h.terjemah);
                sb.append("\n\nTeks asli");
                String l = labelDariNama(h.bahasaAsli);
                if (l != null) {
                    sb.append(" (").append(l).append(")");
                }
                sb.append(":\n").append(h.asli);
            } else {
                judul = "Hasil transkripsi";
                if (h.catatan != null) {
                    sb.append(h.catatan).append("\n\n");
                }
                sb.append(h.asli);
            }
            final EditText et = kotakTeks(act, sb.toString(), "Hasil transkripsi");
            ScrollView sv = new ScrollView(act);
            sv.addView(et);
            new AlertDialog.Builder(act)
                    .setTitle(judul)
                    .setView(sv)
                    .setPositiveButton("Salin", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            int a = et.getSelectionStart();
                            int b = et.getSelectionEnd();
                            String semua = et.getText().toString();
                            if (a >= 0 && b >= 0 && a != b) {
                                salinKe(act, semua.substring(Math.min(a, b), Math.max(a, b)));
                            } else {
                                salinKe(act, teksUtama(h));
                            }
                        }
                    })
                    .setNeutralButton("Opsi lainnya", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            menuLanjut(act, h);
                        }
                    })
                    .setNegativeButton("Tutup", null)
                    .show();
        } catch (Throwable t) {
            Log.w("NovanTranskripsi", "tampil gagal", t);
        }
    }

    private static void menuLanjut(final Activity act, final Hasil h) {
        final String[] pilihan = {
                "Salin teks asli",
                "Salin terjemahan",
                "Terjemahkan ke bahasa lain",
                "Rangkum menjadi 3 sampai 5 poin",
                "Simpan ke berkas txt",
                "Bagikan teks"
        };
        new AlertDialog.Builder(act)
                .setTitle("Pilih aksi")
                .setItems(pilihan, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (w == 0) {
                            salinKe(act, h.asli);
                        } else if (w == 1) {
                            if (h.terjemah != null) {
                                salinKe(act, h.terjemah);
                            } else {
                                Toast.makeText(act, "Belum ada terjemahan. Pilih Terjemahkan ke bahasa lain.", Toast.LENGTH_SHORT).show();
                            }
                        } else if (w == 2) {
                            pilihBahasaTerjemah(act, h);
                        } else if (w == 3) {
                            jalankanLatar(act, "Sedang merangkum...", "Hasil rangkuman", h, true, null);
                        } else if (w == 4) {
                            simpanTxt(act, h);
                        } else {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_TEXT, teksUtama(h));
                            Intent p = Intent.createChooser(i, "Bagikan teks");
                            act.startActivity(p);
                        }
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private static void pilihBahasaTerjemah(final Activity act, final Hasil h) {
        String[] label = new String[BAHASA.length];
        for (int i = 0; i < BAHASA.length; i++) {
            label[i] = BAHASA[i][2];
        }
        new AlertDialog.Builder(act)
                .setTitle("Terjemahkan ke")
                .setItems(label, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        jalankanLatar(act, "Sedang menerjemahkan...", "Terjemahan", h, false, BAHASA[w][0]);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Terjemahan atau rangkuman di thread latar; hasilnya ditampilkan di kotak teks sederhana. */
    private static void jalankanLatar(final Activity act, String kabar, final String judul, final Hasil h,
                                      final boolean rangkuman, final String kodeBahasa) {
        final String kunciApi = kunci();
        if (kunciApi.isEmpty()) {
            dialogKunci(act, null);
            return;
        }
        Toast.makeText(act, kabar, Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String[] r = rangkuman
                        ? rangkum(h.asli, bahasaTujuan(), kunciApi)
                        : terjemahkan(h.asli, kodeBahasa, kunciApi);
                AndroidUtilities.runOnUIThread(new Runnable() {
                    @Override
                    public void run() {
                        if (r[0] == null) {
                            Toast.makeText(act, "Gagal: " + r[1], Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (!rangkuman) {
                            h.terjemah = r[0];
                            h.tujuan = kodeBahasa;
                            h.catatan = null;
                        }
                        String j = rangkuman ? judul : judul + " (" + labelBahasa(kodeBahasa) + ")";
                        tampilTeks(act, j, r[0]);
                    }
                });
            }
        }).start();
    }

    private static void tampilTeks(final Activity act, String judul, final String isi) {
        try {
            ScrollView sv = new ScrollView(act);
            sv.addView(kotakTeks(act, isi, judul));
            new AlertDialog.Builder(act)
                    .setTitle(judul)
                    .setView(sv)
                    .setPositiveButton("Salin", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            salinKe(act, isi);
                        }
                    })
                    .setNegativeButton("Tutup", null)
                    .show();
        } catch (Throwable t) {
            Log.w("NovanTranskripsi", "tampilTeks gagal", t);
        }
    }

    private static void simpanTxt(final Activity act, final Hasil h) {
        final Context c = act.getApplicationContext() != null ? act.getApplicationContext() : act;
        final StringBuilder sb = new StringBuilder();
        if (h.terjemah != null) {
            sb.append("Terjemahan (").append(labelBahasa(h.tujuan)).append("):\n").append(h.terjemah).append("\n\n");
            sb.append("Teks asli:\n");
        }
        sb.append(h.asli).append("\n");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String nama = "Transkripsi_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt";
                boolean ok = NovanMod.simpanTeks(c, nama, sb.toString());
                toast(c, ok ? "Tersimpan di folder " + NovanMod.FOLDER_UNDUHAN + ": " + nama : "Gagal menyimpan berkas");
            }
        }).start();
    }

    // ------------------------------------------------------------ kunci API

    /** Kotak isian kunci API Groq. Dipakai dari menu pesan (setelah.run dijalankan bila kunci tersimpan) dan dari Pengaturan. */
    public static void dialogKunci(final Activity act, final Runnable setelah) {
        try {
            LinearLayout kotak = new LinearLayout(act);
            kotak.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (20 * act.getResources().getDisplayMetrics().density + 0.5f);
            kotak.setPadding(pad, pad / 2, pad, pad / 2);
            TextView tv = new TextView(act);
            tv.setText("Kunci API Groq (gratis di console.groq.com). Disimpan hanya di HP ini.");
            tv.setTextSize(15);
            kotak.addView(tv);
            final EditText et = new EditText(act);
            et.setSingleLine(true);
            et.setText(kunci());
            et.setContentDescription("Kunci API Groq");
            kotak.addView(et);
            Button web = new Button(act);
            web.setAllCaps(false);
            web.setText("Buka halaman kunci Groq");
            web.setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {
                    try {
                        act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(URL_KUNCI)));
                    } catch (Throwable ignored) {
                    }
                }
            });
            kotak.addView(web);
            new AlertDialog.Builder(act)
                    .setTitle("Kunci API Groq")
                    .setView(kotak)
                    .setPositiveButton("Simpan", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            String k = et.getText().toString().trim();
                            SharedPreferences p = act.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE);
                            p.edit().putString("groq_kunci", k).apply();
                            Toast.makeText(act, k.isEmpty() ? "Kunci dihapus" : "Kunci API Groq tersimpan", Toast.LENGTH_SHORT).show();
                            if (!k.isEmpty() && setelah != null) {
                                setelah.run();
                            }
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable t) {
            Log.w("NovanTranskripsi", "dialogKunci gagal", t);
        }
    }

    /** Teks ringkas untuk baris Pengaturan. */
    public static String statusKunci() {
        return kunci().isEmpty() ? "belum diisi" : "sudah diisi";
    }

    public static String[] kodeBahasa(boolean denganOtomatis) {
        int n = BAHASA.length + (denganOtomatis ? 1 : 0);
        String[] r = new String[n];
        int k = 0;
        if (denganOtomatis) {
            r[k++] = "auto";
        }
        for (String[] b : BAHASA) {
            r[k++] = b[0];
        }
        return r;
    }

    public static String[] labelBahasaDaftar(boolean denganOtomatis) {
        int n = BAHASA.length + (denganOtomatis ? 1 : 0);
        String[] r = new String[n];
        int k = 0;
        if (denganOtomatis) {
            r[k++] = "Otomatis (disarankan)";
        }
        for (String[] b : BAHASA) {
            r[k++] = b[2];
        }
        return r;
    }
}
