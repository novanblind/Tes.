#!/usr/bin/env bash
# Unduh AAR FFmpeg (libmp3lame) yang dikunci versi + checksum-nya, lalu pangkas jadi
# arm64-v8a saja (64-bit). Hasil: app/libs/ffmpeg-kit-6.1.1-arm64.aar
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=app/libs/ffmpeg-kit-6.1.1-arm64.aar
[ -s "$OUT" ] && { echo "sudah ada: $OUT"; exit 0; }
COMMIT=0ea7de70ceb270dadb15e4468d94a7648babe1b3
SHA=5b8da42b87d2e63292112f81c2611d4c208bade75c591426cae0d4c5c959d522
REPO="https://github.com/moizhassankh/ffmpeg-kit-android-16KB.git"
TMP=$(mktemp -d)
git init -q "$TMP/g"
git -C "$TMP/g" fetch -q --depth 1 "$REPO" "$COMMIT"
git -C "$TMP/g" checkout -q FETCH_HEAD
cp "$TMP/g/ffmpeg-kit-6.1.1.aar" "$TMP/full.aar"
echo "$SHA  $TMP/full.aar" | sha256sum -c -
mkdir -p "$TMP/x" app/libs
ROOT="$PWD"
(cd "$TMP/x" && unzip -q ../full.aar && rm -rf jni/armeabi-v7a jni/x86 jni/x86_64 && zip -q -r -X "$ROOT/$OUT" .)
rm -rf "$TMP"
ls -la "$OUT"
