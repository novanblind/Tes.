package com.novan.pisahsuara;

import android.content.Context;
import android.content.pm.PackageManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioPlaybackConfiguration;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Membangun dan mendaftarkan kebijakan audio (AudioPolicy). Dipakai dua jalur:
 * di dalam aplikasi (lewat Shizuku) dan di proses shell (Server, lewat ADB).
 */
public class Policy {
    static final int[] ALLOWED = {2, 3, 4, 8, 11, 22, 23, 26, 27, 30};
    private static Object current;

    public static String key(AudioDeviceInfo d) { return d.getType() + "|" + d.getAddress(); }

    public static List<AudioDeviceInfo> outputs(AudioManager am) {
        List<AudioDeviceInfo> r = new ArrayList<>();
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            for (int t : ALLOWED) if (d.getType() == t) { r.add(d); break; }
        }
        return r;
    }

    /** Galat terakhir saat melepas kebijakan lama (null bila berhasil); bila gagal, kebijakan lama bisa tertinggal dan menang atas yang baru. */
    public static volatile String galatLepas = null;

    /** Kunci perangkat luar yang dipakai aturan Bluetooth yang sedang terpasang ("-" = tak ada aturan ke perangkat luar). */
    public static volatile String extTerpakai = "-";

    /** Kunci perangkat luar yang akan dipilih bila kebijakan dipasang sekarang; null bila tak ada. */
    public static String pilihExt(AudioManager am, String btKey) {
        for (AudioDeviceInfo d : outputs(am)) {
            if (d.getType() != 2 && (btKey == null || btKey.equals(key(d)))) return key(d);
        }
        return null;
    }

    public static void release(AudioManager am) {
        galatLepas = null;
        extTerpakai = "-";
        if (current == null) return;
        galatLepas = lepasObjek(am, current);
        current = null;
    }

    /** Lepas satu objek kebijakan; mengembalikan null bila berhasil, atau keterangan galat. */
    private static String lepasObjek(AudioManager am, Object pol) {
        try {
            Class<?> polCls = Class.forName("android.media.audiopolicy.AudioPolicy");
            AudioManager.class.getMethod("unregisterAudioPolicy", polCls).invoke(am, pol);
            return null;
        } catch (Throwable e) { return galat(e); }
    }

    private static String galat(Throwable e) {
        Throwable t = (e instanceof InvocationTargetException && e.getCause() != null) ? e.getCause() : e;
        return t.getClass().getSimpleName() + ": " + t.getMessage();
    }

    /**
     * hp = UID aplikasi yang diputar di speaker HP; bt = UID aplikasi yang diputar di perangkat luar.
     * btKey = "tipe|alamat" perangkat luar, atau null untuk perangkat luar pertama yang tersambung.
     */
    public static synchronized String register(Context ctx, AudioManager am, int[] hp, int[] bt, String btKey) {
        try {
            // Tahap 34: kebijakan lama TIDAK dilepas lebih dulu. Dulu ada celah (puluhan sampai ratusan ms) tanpa aturan,
            // saat itu suara aplikasi mengikuti sistem dan bocor ke perangkat yang salah. Kini yang baru dipasang dulu,
            // yang lama baru dilepas sesudahnya.
            galatLepas = null;
            final Object lama = current;
            AudioDeviceInfo speaker = null, ext = null;
            for (AudioDeviceInfo d : outputs(am)) {
                if (d.getType() == 2) { if (speaker == null) speaker = d; }
                else if (btKey == null || btKey.equals(key(d))) { if (ext == null) ext = d; }
            }
            boolean pakaiHp = hp.length > 0 && speaker != null;
            boolean pakaiBt = bt.length > 0 && ext != null;
            if (!pakaiHp && !pakaiBt) {
                release(am);
                return bt.length > 0 && ext == null
                        ? "Perangkat Bluetooth belum tersambung" : "Tidak ada aturan aktif";
            }
            Class<?> ruleCls = Class.forName("android.media.audiopolicy.AudioMixingRule");
            Class<?> ruleBuilderCls = Class.forName("android.media.audiopolicy.AudioMixingRule$Builder");
            Class<?> mixCls = Class.forName("android.media.audiopolicy.AudioMix");
            Class<?> mixBuilderCls = Class.forName("android.media.audiopolicy.AudioMix$Builder");
            Class<?> polCls = Class.forName("android.media.audiopolicy.AudioPolicy");
            Class<?> polBuilderCls = Class.forName("android.media.audiopolicy.AudioPolicy$Builder");
            int ruleUid;
            try {
                ruleUid = ruleCls.getField("RULE_MATCH_UID").getInt(null);
            } catch (NoSuchFieldException e) {
                return "Gagal: Android " + Build.VERSION.RELEASE + " tidak punya aturan suara per-aplikasi (RULE_MATCH_UID); "
                        + "pemisahan suara per-aplikasi tidak bisa jalan di versi ini.";
            }
            int renderFlag = mixCls.getField("ROUTE_FLAG_RENDER").getInt(null);
            AudioFormat format = new AudioFormat.Builder()
                    .setSampleRate(48000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();
            Object pb = polBuilderCls.getConstructor(Context.class).newInstance(ctx);
            java.lang.reflect.Method addMix = polBuilderCls.getMethod("addMix", mixCls);
            java.lang.reflect.Method addRule = ruleBuilderCls.getMethod("addMixRule", int.class, Object.class);
            int[][] daftar = {pakaiHp ? hp : new int[0], pakaiBt ? bt : new int[0]};
            AudioDeviceInfo[] tujuan = {speaker, ext};
            for (int g = 0; g < 2; g++) {
                if (daftar[g].length == 0) continue;
                Object rb = ruleBuilderCls.getConstructor().newInstance();
                for (int u : daftar[g]) addRule.invoke(rb, ruleUid, u);
                Object rule = ruleBuilderCls.getMethod("build").invoke(rb);
                Object mb = mixBuilderCls.getConstructor(ruleCls).newInstance(rule);
                mixBuilderCls.getMethod("setFormat", AudioFormat.class).invoke(mb, format);
                mixBuilderCls.getMethod("setRouteFlags", int.class).invoke(mb, renderFlag);
                mixBuilderCls.getMethod("setDevice", AudioDeviceInfo.class).invoke(mb, tujuan[g]);
                addMix.invoke(pb, mixBuilderCls.getMethod("build").invoke(mb));
            }
            Object pol = polBuilderCls.getMethod("build").invoke(pb);
            Method reg = AudioManager.class.getMethod("registerAudioPolicy", polCls);
            int res = (Integer) reg.invoke(am, pol);
            if (res != 0 && lama != null) {
                // Sistem menolak dua kebijakan bersamaan: lepas yang lama lalu coba lagi (celah singkat, jalur cadangan).
                galatLepas = lepasObjek(am, lama);
                current = null;
                res = (Integer) reg.invoke(am, pol);
                if (res == 0) { current = pol; extTerpakai = "-"; }
                else return "Gagal mendaftarkan kebijakan audio (kode " + res + ")";
            } else if (res != 0) {
                return "Gagal mendaftarkan kebijakan audio (kode " + res + ")";
            } else {
                current = pol;
                if (lama != null) galatLepas = lepasObjek(am, lama);
            }
            extTerpakai = pakaiBt && ext != null ? key(ext) : "-";
            StringBuilder sb = new StringBuilder("Aktif:");
            if (pakaiHp) sb.append(" ").append(hp.length).append(" aplikasi ke speaker HP;");
            if (pakaiBt) sb.append(" ").append(bt.length).append(" aplikasi ke perangkat luar;");
            if (hp.length > 0 && speaker == null) sb.append(" (speaker HP tidak ditemukan)");
            if (bt.length > 0 && ext == null) sb.append(" (perangkat luar belum tersambung)");
            sb.append(" [diterima Server: hp=").append(java.util.Arrays.toString(hp))
              .append(" bt=").append(java.util.Arrays.toString(bt))
              .append(" speaker=").append(speaker != null ? key(speaker) : "tidak ada")
              .append(" luar=").append(ext != null ? key(ext) : "tidak ada")
              .append(" pakaiHp=").append(pakaiHp).append(" pakaiBt=").append(pakaiBt).append("]");
            if (galatLepas != null) sb.append(" (melepas kebijakan lama GAGAL: ").append(galatLepas).append(')');
            return sb.toString();
        } catch (Throwable e) {
            return "Gagal: " + galat(e);
        }
    }

    private static Method cari(Class<?> c, String nama) {
        try { return c.getMethod(nama); } catch (Throwable e) {}
        try { Method m = c.getDeclaredMethod(nama); m.setAccessible(true); return m; } catch (Throwable e) { return null; }
    }

    /**
     * Laporan keadaan NYATA: apakah kebijakan terpasang, dan setiap aliran suara yang sedang aktif
     * keluar lewat perangkat apa. Baris: "T waktu", "KEBIJAKAN ya|tidak", "P uid status usage tipe alamat".
     * status 2 = sedang memutar; tipe 2 = speaker HP; tipe -1 = perangkat tidak diketahui.
     */
    public static synchronized String laporan(AudioManager am) {
        StringBuilder sb = new StringBuilder();
        sb.append("T ").append(System.currentTimeMillis()).append('\n');
        sb.append(current != null ? "KEBIJAKAN ya\n" : "KEBIJAKAN tidak\n");
        try {
            List<AudioPlaybackConfiguration> daftar = am.getActivePlaybackConfigurations();
            Class<?> c = AudioPlaybackConfiguration.class;
            Method mUid = cari(c, "getClientUid");
            Method mState = cari(c, "getPlayerState");
            Method mDev = cari(c, "getAudioDeviceInfo");
            for (AudioPlaybackConfiguration o : daftar) {
                int uid = -1, state = -1, usage = -1, tipe = -1;
                String alamat = "-";
                try { if (mUid != null) uid = (Integer) mUid.invoke(o); } catch (Throwable e) {}
                try { if (mState != null) state = (Integer) mState.invoke(o); } catch (Throwable e) {}
                try { usage = o.getAudioAttributes().getUsage(); } catch (Throwable e) {}
                try {
                    if (mDev != null) {
                        AudioDeviceInfo d = (AudioDeviceInfo) mDev.invoke(o);
                        if (d != null) {
                            tipe = d.getType();
                            String ad = d.getAddress();
                            if (ad != null && !ad.isEmpty()) alamat = ad.replace(' ', '_');
                        }
                    }
                } catch (Throwable e) {}
                sb.append("P ").append(uid).append(' ').append(state).append(' ').append(usage)
                        .append(' ').append(tipe).append(' ').append(alamat).append('\n');
            }
        } catch (Throwable e) {
            sb.append("GALAT ").append(galat(e).replace('\n', ' ')).append('\n');
        }
        return sb.toString();
    }

    /** True bila salah satu uid sedang MEMUTAR (status 2). Bila tak bisa dipastikan, dianggap ya (aman). */
    public static boolean sedangMemutar(AudioManager am, int[] uids) {
        try {
            Class<?> c = AudioPlaybackConfiguration.class;
            Method mUid = cari(c, "getClientUid");
            Method mState = cari(c, "getPlayerState");
            if (mUid == null || mState == null) return true;
            for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                if (ada(uids, (Integer) mUid.invoke(o)) && (Integer) mState.invoke(o) == 2) return true;
            }
            return false;
        } catch (Throwable e) { return true; }
    }

    /** True bila salah satu uid punya pemain suara (status apa pun, termasuk jeda). Bila tak bisa dipastikan, dianggap ya. */
    public static boolean adaPemain(AudioManager am, int[] uids) {
        try {
            Method mUid = cari(AudioPlaybackConfiguration.class, "getClientUid");
            if (mUid == null) return true;
            for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                if (ada(uids, (Integer) mUid.invoke(o))) return true;
            }
            return false;
        } catch (Throwable e) { return true; }
    }

    /** Tipe perangkat tempat media sistem keluar sekarang (2 = speaker HP), -1 bila tak terbaca. */
    public static int tipeMediaAktif(AudioManager am) {
        try {
            android.media.AudioAttributes aa = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA).build();
            List<?> cur = (List<?>) AudioManager.class.getMethod("getAudioDevicesForAttributes", android.media.AudioAttributes.class).invoke(am, aa);
            if (cur != null && !cur.isEmpty()) return ((AudioDeviceInfo) cur.get(0)).getType();
        } catch (Throwable e) {}
        return -1;
    }

    private static boolean ada(int[] a, int v) { for (int x : a) if (x == v) return true; return false; }

    /**
     * Setelah aturan berubah: aplikasi yang sedang memutar dan perangkat keluarnya belum sesuai
     * dipicu jeda lalu putar (lewat sesi media) supaya aliran suaranya dibuat ulang dan pindah.
     * Hanya untuk aplikasi yang aturannya baru berubah (ubah). Aplikasi tanpa sesi media tidak terjangkau.
     */
    public static void dorong(final Context ctx, final AudioManager am, final int[] ubah,
                              final int[] hp, final int[] bt, final Handler h) {
        if (ubah.length == 0) return;
        final int[] kali = {0};
        h.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    java.util.HashSet<Integer> perlu = new java.util.HashSet<>();
                    Class<?> c = AudioPlaybackConfiguration.class;
                    Method mUid = cari(c, "getClientUid");
                    Method mState = cari(c, "getPlayerState");
                    Method mDev = cari(c, "getAudioDeviceInfo");
                    if (mUid == null) return;
                    for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                        int uid = (Integer) mUid.invoke(o);
                        if (!ada(ubah, uid)) continue;
                        int state = mState != null ? (Integer) mState.invoke(o) : -1;
                        if (state != 2) continue;
                        int tipe = -1;
                        try {
                            AudioDeviceInfo d = mDev != null ? (AudioDeviceInfo) mDev.invoke(o) : null;
                            if (d != null) tipe = d.getType();
                        } catch (Throwable e) {}
                        boolean sudah = ada(hp, uid) ? tipe == 2 : ada(bt, uid) && tipe != 2 && tipe != -1;
                        if (!sudah) perlu.add(uid);
                    }
                    if (perlu.isEmpty()) return;
                    MediaSessionManager msm = (MediaSessionManager) ctx.getSystemService("media_session");
                    PackageManager pm = ctx.getPackageManager();
                    for (final MediaController mc : msm.getActiveSessions(null)) {
                        int uid;
                        try { uid = pm.getPackageUid(mc.getPackageName(), 0); } catch (Throwable e) { continue; }
                        if (!perlu.contains(uid)) continue;
                        PlaybackState ps = mc.getPlaybackState();
                        if (ps == null || ps.getState() != PlaybackState.STATE_PLAYING) continue;
                        // Posisi sekarang (diperkirakan), supaya bisa digeser ke posisi yang sama:
                        // pemutar (mis. ExoPlayer) membuat ulang saluran suaranya saat posisi digeser.
                        long pos = ps.getPosition();
                        if (pos >= 0) {
                            pos += (long) ((android.os.SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime())
                                    * ps.getPlaybackSpeed());
                        }
                        final long posAkhir = pos;
                        if (kali[0] >= 2) {
                            // Percobaan terakhir: berhenti total supaya pemutar (mis. ExoPlayer) melepas dan membuat ulang
                            // saluran suaranya, lalu putar dan geser ke posisi semula.
                            mc.getTransportControls().stop();
                            h.postDelayed(new Runnable() {
                                @Override public void run() { try { mc.getTransportControls().play(); } catch (Throwable e) {} }
                            }, 600);
                            h.postDelayed(new Runnable() {
                                @Override public void run() {
                                    try { if (posAkhir >= 0) mc.getTransportControls().seekTo(posAkhir); } catch (Throwable e) {}
                                }
                            }, 1400);
                        } else {
                            mc.getTransportControls().pause();
                            h.postDelayed(new Runnable() {
                                @Override public void run() {
                                    try { if (posAkhir >= 0) mc.getTransportControls().seekTo(posAkhir); } catch (Throwable e) {}
                                }
                            }, 200);
                            h.postDelayed(new Runnable() {
                                @Override public void run() {
                                    try { mc.getTransportControls().play(); } catch (Throwable e) {}
                                }
                            }, 550);
                        }
                    }
                } catch (Throwable e) {
                } finally {
                    // Periksa lagi sampai 3 kali: aplikasi yang belum pindah dipicu ulang.
                    if (++kali[0] < 3) h.postDelayed(this, 2500);
                }
            }
        }, 700);
    }

    private static String sig(Class<?>[] p) {
        StringBuilder sb = new StringBuilder("(");
        for (int i = 0; i < p.length; i++) { if (i > 0) sb.append(','); sb.append(p[i].getSimpleName()); }
        return sb.append(')').toString();
    }

    /** Susun argumen sesuai tipe parameter: stream (3), indeks, [muted=false], perangkat (2 = speaker). Null bila tak dikenal. */
    private static Object[] susunArg(Class<?>[] p, android.media.AudioAttributes aa, int stream, int index, boolean berbasisAtribut) {
        int[] ints = berbasisAtribut ? new int[]{index, 2} : new int[]{stream, index, 2};
        Object[] r = new Object[p.length];
        int k = 0;
        for (int i = 0; i < p.length; i++) {
            if (p[i] == android.media.AudioAttributes.class) r[i] = aa;
            else if (p[i] == int.class) { if (k >= ints.length) return null; r[i] = ints[k++]; }
            else if (p[i] == boolean.class) r[i] = false;
            else return null;
        }
        return k == ints.length ? r : null;
    }

    /**
     * Samakan volume media speaker HP dengan volume media yang sedang aktif (mis. Bluetooth), karena tombol
     * volume hanya mengubah perangkat aktif. Di Android baru tanda tangan metode AudioSystem berubah
     * (ada parameter muted), jadi semua kandidat dicoba menurut tipe parameternya.
     * Mengembalikan "ok" atau keterangan galat (memuat tanda tangan yang ditemukan).
     */
    public static String setVolumeSpeaker(int index) {
        return setVolumeSpeaker(null, index);
    }

    /** Metode yang terakhir berhasil dipakai untuk mengatur volume speaker (untuk diagnosis). */
    public static volatile String volMetode = "-";

    private static AudioDeviceInfo perangkat(AudioManager am, boolean speaker) {
        for (AudioDeviceInfo d : outputs(am)) {
            if (speaker ? d.getType() == 2 : d.getType() != 2) return d;
        }
        return null;
    }

    private static Object bangunVolumeInfo(AudioManager am, int index) throws Exception {
        Class<?> vib = Class.forName("android.media.VolumeInfo$Builder");
        Object b = vib.getConstructor(int.class).newInstance(AudioManager.STREAM_MUSIC);
        vib.getMethod("setMinVolumeIndex", int.class).invoke(b, am.getStreamMinVolume(AudioManager.STREAM_MUSIC));
        vib.getMethod("setMaxVolumeIndex", int.class).invoke(b, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vib.getMethod("setVolumeIndex", int.class).invoke(b, index);
        return vib.getMethod("build").invoke(b);
    }

    /**
     * Cara resmi per perangkat (Android 13+): AudioService sendiri yang menyimpan indeks volume speaker,
     * jadi tidak tertimpa kembali seperti bila AudioSystem dipanggil langsung.
     */
    private static String viaDeviceVolume(AudioManager am, int index) {
        try {
            AudioDeviceInfo spk = perangkat(am, true);
            if (spk == null) return "speaker tak ditemukan";
            Class<?> vic = Class.forName("android.media.VolumeInfo");
            Class<?> dac = Class.forName("android.media.AudioDeviceAttributes");
            Object vi = bangunVolumeInfo(am, index);
            Object ada = dac.getConstructor(AudioDeviceInfo.class).newInstance(spk);
            AudioManager.class.getMethod("setDeviceVolume", vic, dac).invoke(am, vi, ada);
            return "ok";
        } catch (Throwable e) { return "setDeviceVolume " + galat(e); }
    }

    /** Indeks volume media tersimpan untuk perangkat (speaker atau perangkat luar); -1 bila tak terbaca. */
    public static int bacaVolumePerangkat(AudioManager am, boolean speaker) {
        try {
            AudioDeviceInfo d = perangkat(am, speaker);
            if (d == null) return -1;
            Class<?> vic = Class.forName("android.media.VolumeInfo");
            Class<?> dac = Class.forName("android.media.AudioDeviceAttributes");
            Object ada = dac.getConstructor(AudioDeviceInfo.class).newInstance(d);
            Object r = AudioManager.class.getMethod("getDeviceVolume", vic, dac).invoke(am, bangunVolumeInfo(am, 0), ada);
            int idx = (Integer) vic.getMethod("getVolumeIndex").invoke(r);
            return idx;
        } catch (Throwable e) { return -1; }
    }

    public static String setVolumeSpeaker(AudioManager am, int index) {
        if (am != null) {
            String r = viaDeviceVolume(am, index);
            if (r.equals("ok")) { volMetode = "setDeviceVolume"; return "ok"; }
            volMetode = "AudioSystem (" + r + ")";
        }
        return setVolumeSpeakerLama(index);
    }

    private static String setVolumeSpeakerLama(int index) {
        return setStreamSpeaker(AudioManager.STREAM_MUSIC, index,
                new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).build(), false);
    }

    /**
     * Atur indeks volume stream tertentu di perangkat speaker HP lewat AudioSystem. semua=false: berhenti di cara pertama
     * yang berhasil. semua=true: semua cara dicoba (stream dan atribut), "ok" bila salah satu berhasil.
     */
    private static String setStreamSpeaker(int stream, int index, android.media.AudioAttributes aa, boolean semua) {
        StringBuilder info = new StringBuilder();
        boolean adaOk = false;
        try {
            Class<?> as = Class.forName("android.media.AudioSystem");
            String[] nama = {"setStreamVolumeIndexAS", "setStreamVolumeIndex", "setVolumeIndexForAttributes"};
            for (String n : nama) {
                for (Method m : as.getDeclaredMethods()) {
                    if (!m.getName().equals(n)) continue;
                    Class<?>[] p = m.getParameterTypes();
                    Object[] arg = susunArg(p, aa, stream, index, n.equals("setVolumeIndexForAttributes"));
                    if (arg == null) { info.append(n).append(sig(p)).append(" tak cocok; "); continue; }
                    try {
                        m.setAccessible(true);
                        Object r = m.invoke(null, arg);
                        int kode = r instanceof Integer ? (Integer) r : 0;
                        if (kode == 0) { if (!semua) return "ok"; adaOk = true; info.append(n).append(" ok; "); }
                        else info.append(n).append(sig(p)).append(" kode ").append(kode).append("; ");
                    } catch (Throwable e) {
                        info.append(n).append(sig(p)).append(' ').append(galat(e)).append("; ");
                    }
                }
            }
            if (info.length() == 0) info.append("tak ada metode volume AudioSystem yang cocok");
        } catch (Throwable e) {
            info.append(galat(e));
        }
        if (adaOk) return "ok";
        return info.toString().replace('\n', ' ');
    }

    /** Rincian terakhir pengaturan volume aksesibilitas + nilai yang terbaca kembali dari speaker HP (diagnosis). */
    public static volatile String volRinci = "-";

    /** Indeks volume speaker HP yang terbaca kembali lewat AudioSystem (stream), "?" bila tak terbaca. */
    private static String bacaIndeksSpeaker(int stream) {
        try {
            Class<?> as = Class.forName("android.media.AudioSystem");
            for (Method m : as.getDeclaredMethods()) {
                if (!m.getName().equals("getStreamVolumeIndex")) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 2 && p[0] == int.class && p[1] == int.class) {
                    m.setAccessible(true);
                    return String.valueOf(m.invoke(null, stream, 2));
                }
            }
        } catch (Throwable e) { return "galat"; }
        return "?";
    }

    private static String bacaIndeksAtribut(android.media.AudioAttributes aa) {
        try {
            Class<?> as = Class.forName("android.media.AudioSystem");
            for (Method m : as.getDeclaredMethods()) {
                if (!m.getName().equals("getVolumeIndexForAttributes")) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 2 && p[0] == android.media.AudioAttributes.class && p[1] == int.class) {
                    m.setAccessible(true);
                    return String.valueOf(m.invoke(null, aa, 2));
                }
            }
        } catch (Throwable e) { return "galat"; }
        return "?";
    }

    /**
     * Tahap 35: selain volume media, samakan juga volume aksesibilitas (suara mesin suara/pembaca layar, usage 11) di
     * speaker HP. Suara mesin suara memakai stream aksesibilitas (10) dan atribut usage 11, yang punya indeks per perangkat
     * sendiri; bila hanya stream media yang diatur, volume mesin suara di speaker HP tidak ikut berubah.
     * Mengembalikan hasil bagian media ("ok" atau galat); rincian aksesibilitas ada di volRinci.
     */
    public static String setVolumeSpeakerSemua(AudioManager am, int idxMedia, int idxA11y) {
        String r = setVolumeSpeaker(am, idxMedia);
        StringBuilder d = new StringBuilder();
        try {
            android.media.AudioAttributes aaA = new android.media.AudioAttributes.Builder()
                    .setUsage(11).build();
            String ra = setStreamSpeaker(10, idxA11y, aaA, true);
            d.append("a11y=").append(ra.equals("ok") ? "ok" : ra);
            d.append(" baca[musik=").append(bacaIndeksSpeaker(3))
             .append(" a11y=").append(bacaIndeksSpeaker(10))
             .append(" atribut11=").append(bacaIndeksAtribut(aaA)).append(']');
        } catch (Throwable e) { d.append("a11y galat ").append(galat(e)); }
        volRinci = d.toString();
        return r;
    }

    /** {kelasStrategi, kelasDeviceAttributes, strategiMedia} atau null. */
    private static Object[] strategiMedia() {
        try {
            android.media.AudioAttributes aa = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA).build();
            Class<?> sc = Class.forName("android.media.audiopolicy.AudioProductStrategy");
            Class<?> dac = Class.forName("android.media.AudioDeviceAttributes");
            List<?> semua = (List<?>) sc.getMethod("getAudioProductStrategies").invoke(null);
            for (Object o : semua) {
                if ((Boolean) sc.getMethod("supportsAudioAttributes", android.media.AudioAttributes.class).invoke(o, aa))
                    return new Object[]{sc, dac, o};
            }
        } catch (Throwable e) {}
        return null;
    }

    private static int tipeAttr(Object dac, Object attr) {
        try { return (Integer) ((Class<?>) dac).getMethod("getType").invoke(attr); } catch (Throwable e) { return -1; }
    }

    /** Perangkat pilihan strategi media sistem saat ini ("tidak ada" = sistem bebas memilih). Untuk diagnosis. */
    public static String pilihanMedia(AudioManager am) {
        try {
            Object[] x = strategiMedia();
            if (x == null) return "strategi tak ditemukan";
            Object pr = AudioManager.class.getMethod("getPreferredDeviceForStrategy", (Class<?>) x[0]).invoke(am, x[2]);
            if (pr == null) return "tidak ada";
            return "tipe " + tipeAttr(x[1], pr) + " alamat " + ((Class<?>) x[1]).getMethod("getAddress").invoke(pr);
        } catch (Throwable e) { return "galat " + galat(e); }
    }

    /**
     * Pemaksaan pindah sementara mengubah pilihan perangkat media lalu mengembalikannya. Bila Server mati di antaranya,
     * pilihan ke speaker tersangkut dan SEMUA media ikut ke speaker meski Bluetooth tersambung. Pilihan ke speaker
     * (tipe 2) dihapus agar sistem bebas memilih lagi. Mengembalikan keterangan.
     */
    public static String bersihkanPilihan(AudioManager am) {
        try {
            Object[] x = strategiMedia();
            if (x == null) return "strategi tak ditemukan";
            Object pr = AudioManager.class.getMethod("getPreferredDeviceForStrategy", (Class<?>) x[0]).invoke(am, x[2]);
            if (pr == null) return "bersih (tidak ada pilihan)";
            int t = tipeAttr(x[1], pr);
            if (t != 2) return "dibiarkan (pilihan tipe " + t + ")";
            Object r = AudioManager.class.getMethod("removePreferredDeviceForStrategy", (Class<?>) x[0]).invoke(am, x[2]);
            return "pilihan speaker tersangkut DIHAPUS (hasil " + r + ")";
        } catch (Throwable e) { return "galat " + galat(e); }
    }

    /** Cuplikan "dumpsys media.audio_policy" bagian policy mix + daftar perangkat keluaran (diagnosis). */
    public static String dumpMix(AudioManager am) {
        StringBuilder sb = new StringBuilder();
        try {
            for (AudioDeviceInfo d : outputs(am)) sb.append("dev=").append(d.getType()).append('|').append(d.getAddress()).append(' ');
            if (current != null) sb.append("| mixTerdaftar=ya ");
            Process pr = Runtime.getRuntime().exec(new String[]{"dumpsys", "media.audio_policy"});
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(pr.getInputStream()));
            String l;
            int sisa = 0, n = 0, a2dp = 0;
            StringBuilder sa = new StringBuilder();
            while ((l = r.readLine()) != null && n < 400000) {
                n += l.length();
                String lo = l.toLowerCase();
                if (lo.contains("audio policy mix")) sisa = 12;
                if (sisa > 0) { sb.append(" / ").append(l.trim()); sisa--; }
                else if (a2dp < 8 && (lo.contains("a2dp") || lo.contains("suspend"))) { sa.append(" ~ ").append(l.trim()); a2dp++; }
                if (sb.length() > 1500 && a2dp >= 8) break;
            }
            try { pr.destroy(); } catch (Throwable e) {}
            if (sa.length() > 0) sb.append(" || A2DP:").append(sa);
        } catch (Throwable e) { sb.append("dump gagal: ").append(galat(e)); }
        return sb.toString().replace('\n', ' ');
    }

    /** Catatan hasil percobaan paksa pindah terakhir (ditampilkan di status untuk diagnosis). */
    public static volatile String paksaCatatan = "-";

    /**
     * Memaksa SEMUA aliran suara media yang sudah berjalan (aplikasi apa pun, tanpa perlu sesi media) membuat
     * ulang saluran keluarnya, supaya aturan kebijakan baru dipakai. Caranya: perangkat pilihan strategi media
     * diubah sebentar ke perangkat yang berbeda dari yang aktif lalu dikembalikan; kerangka audio menandai
     * semua AudioTrack strategi itu tidak berlaku, dan tiap AudioTrack otomatis meminta saluran baru
     * (saat itu aturan UID menentukan tujuannya). Aplikasi yang tidak dicentang kembali ke perangkat sistem.
     */
    public static synchronized String paksaPindah(final AudioManager am, Handler h) {
        final StringBuilder info = new StringBuilder();
        try {
            android.media.AudioAttributes aa = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA).build();
            final Class<?> sc = Class.forName("android.media.audiopolicy.AudioProductStrategy");
            final Class<?> dac = Class.forName("android.media.AudioDeviceAttributes");
            List<?> semua = null;
            try { semua = (List<?>) sc.getMethod("getAudioProductStrategies").invoke(null); } catch (Throwable e) { info.append("strategi1:").append(galat(e)).append(' '); }
            if (semua == null) {
                try { semua = (List<?>) AudioManager.class.getMethod("getAudioProductStrategies").invoke(null); } catch (Throwable e) { info.append("strategi2:").append(galat(e)).append(' '); }
            }
            if (semua == null) return "gagal: daftar strategi tidak ada. " + info;
            Object st = null;
            for (Object o : semua) {
                try {
                    if ((Boolean) sc.getMethod("supportsAudioAttributes", android.media.AudioAttributes.class).invoke(o, aa)) { st = o; break; }
                } catch (Throwable e) { info.append("supports:").append(galat(e)).append(' '); break; }
            }
            if (st == null) return "gagal: strategi media tidak ditemukan. " + info;
            final Object strat = st;

            AudioDeviceInfo speaker = null, ext = null;
            for (AudioDeviceInfo d : outputs(am)) {
                if (d.getType() == 2) { if (speaker == null) speaker = d; } else if (ext == null) ext = d;
            }
            int tipeAktif = -1;
            try {
                List<?> cur = (List<?>) AudioManager.class.getMethod("getAudioDevicesForAttributes", android.media.AudioAttributes.class).invoke(am, aa);
                if (cur != null && !cur.isEmpty()) tipeAktif = ((AudioDeviceInfo) cur.get(0)).getType();
            } catch (Throwable e) { info.append("aktif:").append(galat(e)).append(' '); }
            AudioDeviceInfo tujuan = (tipeAktif == 2 && ext != null) ? ext : speaker;
            if (tujuan == null) return "gagal: tidak ada perangkat untuk dialihkan sementara. " + info;

            Object priorAsli = AudioManager.class.getMethod("getPreferredDeviceForStrategy", sc).invoke(am, strat);
            // Pilihan lama ke speaker dianggap tersangkut (sisa pemaksaan yang terputus): jangan dikembalikan.
            final Object prior = (priorAsli != null && tipeAttr(dac, priorAsli) == 2) ? null : priorAsli;
            if (priorAsli != null && prior == null) info.append("pilihan speaker lama dibuang; ");
            Object attr = dac.getConstructor(AudioDeviceInfo.class).newInstance(tujuan);
            Object ok = AudioManager.class.getMethod("setPreferredDeviceForStrategy", sc, dac).invoke(am, strat, attr);
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        if (prior != null) AudioManager.class.getMethod("setPreferredDeviceForStrategy", sc, dac).invoke(am, strat, prior);
                        else AudioManager.class.getMethod("removePreferredDeviceForStrategy", sc).invoke(am, strat);
                    } catch (Throwable e) { paksaCatatan = "gagal mengembalikan: " + galat(e); }
                }
            }, 400);
            return "ok (sementara ke tipe " + tujuan.getType() + ", hasil " + ok + ")";
        } catch (Throwable e) {
            return "gagal: " + galat(e) + " " + info;
        }
    }

    /** Ringkasan pemain aktif milik uid tertentu: uid:status:tipePerangkat:usage:flags (untuk diagnosis). */
    public static String ringkasUid(AudioManager am, int[] uids) {
        StringBuilder sb = new StringBuilder();
        try {
            Class<?> c = AudioPlaybackConfiguration.class;
            Method mUid = cari(c, "getClientUid");
            Method mState = cari(c, "getPlayerState");
            Method mDev = cari(c, "getAudioDeviceInfo");
            for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                int uid = mUid != null ? (Integer) mUid.invoke(o) : -1;
                if (!ada(uids, uid)) continue;
                int state = -1, tipe = -1;
                try { state = (Integer) mState.invoke(o); } catch (Throwable e) {}
                try { AudioDeviceInfo d = (AudioDeviceInfo) mDev.invoke(o); if (d != null) tipe = d.getType(); } catch (Throwable e) {}
                int usage = -1, flags = -1;
                try { usage = o.getAudioAttributes().getUsage(); flags = o.getAudioAttributes().getFlags(); } catch (Throwable e) {}
                sb.append(uid).append(':').append(state).append(':').append(tipe).append(':').append(usage).append(':').append(flags).append(' ');
            }
        } catch (Throwable e) { sb.append("galat ").append(galat(e)); }
        return sb.length() == 0 ? "tak ada pemain" : sb.toString().trim();
    }

    /** True bila ada pemutar aksesibilitas (mesin suara pembaca layar, usage 11) yang sedang memutar. */
    public static boolean aksesibilitasAktif(AudioManager am) {
        try {
            Method mState = cari(AudioPlaybackConfiguration.class, "getPlayerState");
            for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                int usage = -1, state = -1;
                try { usage = o.getAudioAttributes().getUsage(); } catch (Throwable e) {}
                try { if (mState != null) state = (Integer) mState.invoke(o); } catch (Throwable e) {}
                if (usage == 11 && state == 2) return true;
            }
        } catch (Throwable e) {}
        return false;
    }

    /**
     * UID aplikasi yang sedang memutar (status 2) di perangkat yang salah menurut aturan: aplikasi di daftar HP
     * harus di speaker (tipe 2), aplikasi di daftar luar harus di perangkat selain speaker. Perangkat yang tak terbaca
     * (-1) tidak dihitung salah. Aplikasi daftar luar tidak dihitung bila tak ada perangkat luar tersambung.
     */
    public static int[] tidakSesuai(AudioManager am, int[] hp, int[] bt) {
        java.util.LinkedHashSet<Integer> salah = new java.util.LinkedHashSet<>();
        try {
            boolean adaLuar = perangkat(am, false) != null;
            Class<?> c = AudioPlaybackConfiguration.class;
            Method mUid = cari(c, "getClientUid");
            Method mState = cari(c, "getPlayerState");
            Method mDev = cari(c, "getAudioDeviceInfo");
            if (mUid == null || mState == null || mDev == null) return new int[0];
            for (AudioPlaybackConfiguration o : am.getActivePlaybackConfigurations()) {
                int uid = (Integer) mUid.invoke(o);
                if ((Integer) mState.invoke(o) != 2) continue;
                AudioDeviceInfo d = (AudioDeviceInfo) mDev.invoke(o);
                if (d == null) continue;
                int tipe = d.getType();
                if (ada(hp, uid) && tipe != 2) salah.add(uid);
                else if (ada(bt, uid) && adaLuar && tipe == 2) salah.add(uid);
            }
        } catch (Throwable e) {}
        int[] r = new int[salah.size()];
        int k = 0;
        for (int u : salah) r[k++] = u;
        return r;
    }
}
