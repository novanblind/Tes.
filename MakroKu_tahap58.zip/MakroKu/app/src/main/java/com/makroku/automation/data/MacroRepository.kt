package com.makroku.automation.data

import android.content.Context
import com.makroku.automation.model.ActionBlock
import com.makroku.automation.model.AppJson
import com.makroku.automation.model.MacroAction
import com.makroku.automation.model.LogEntry
import com.makroku.automation.model.Macro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.io.File

/** Penyimpanan makro, log, dan variabel (berkas JSON + SharedPreferences). */
class MacroRepository(ctx: Context) {
    private val macroFile = File(ctx.filesDir, "macros.json")
    private val logFile = File(ctx.filesDir, "logs.json")
    private val prefs = ctx.getSharedPreferences("variables", Context.MODE_PRIVATE)
    private val lock = Any()
    private val settings = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Saklar utama: bila mati, semua makro berhenti merespons pemicu. */
    private val _appEnabled = MutableStateFlow(settings.getBoolean("app_enabled", true))
    val appEnabled: StateFlow<Boolean> = _appEnabled.asStateFlow()
    fun setAppEnabled(on: Boolean) {
        settings.edit().putBoolean("app_enabled", on).apply()
        _appEnabled.value = on
        log("MakroKu", if (on) "MakroKu diaktifkan" else "MakroKu dinonaktifkan", true)
    }

    private val macroSer = ListSerializer(Macro.serializer())
    private val logSer = ListSerializer(LogEntry.serializer())

    private val _macros = MutableStateFlow(readMacros())
    val macros: StateFlow<List<Macro>> = _macros.asStateFlow()

    private val blockFile = File(ctx.filesDir, "blocks.json")
    private val blockSer = ListSerializer(ActionBlock.serializer())
    private val _blocks = MutableStateFlow(
        try { if (blockFile.exists()) AppJson.decodeFromString(blockSer, blockFile.readText()) else emptyList() } catch (e: Exception) { emptyList() },
    )
    val blocks: StateFlow<List<ActionBlock>> = _blocks.asStateFlow()

    private fun persistBlocks() = synchronized(lock) { blockFile.writeText(AppJson.encodeToString(blockSer, _blocks.value)) }

    /** Simpan blok; nama yang sama (tanpa peduli huruf besar) diganti isinya. */
    fun saveBlock(name: String, actions: List<MacroAction>) = synchronized(lock) {
        val n = name.trim()
        _blocks.update { l -> l.filterNot { it.name.equals(n, ignoreCase = true) } + ActionBlock(n, actions) }
        persistBlocks()
    }

    fun deleteBlock(name: String) = synchronized(lock) {
        _blocks.update { l -> l.filterNot { it.name == name } }
        persistBlocks()
    }

    fun renameBlock(old: String, new: String) = synchronized(lock) {
        _blocks.update { l -> l.map { if (it.name == old) it.copy(name = new.trim()) else it } }
        persistBlocks()
    }

    private val _logs = MutableStateFlow(readLogs())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _vars = MutableStateFlow(prefs.all.mapValues { it.value.toString() })
    val variables: StateFlow<Map<String, String>> = _vars.asStateFlow()

    private fun readMacros(): List<Macro> = try {
        if (macroFile.exists()) AppJson.decodeFromString(macroSer, macroFile.readText()) else emptyList()
    } catch (e: Exception) { emptyList() }

    private fun readLogs(): List<LogEntry> = try {
        if (logFile.exists()) AppJson.decodeFromString(logSer, logFile.readText()) else emptyList()
    } catch (e: Exception) { emptyList() }

    private fun persistMacros() = synchronized(lock) {
        macroFile.writeText(AppJson.encodeToString(macroSer, _macros.value))
    }

    fun find(id: Long): Macro? = _macros.value.firstOrNull { it.id == id }

    /** Simpan (baru bila id == 0). Mengembalikan makro dengan id final. */
    fun save(m: Macro): Macro = synchronized(lock) {
        val list = _macros.value
        val saved = if (m.id == 0L) m.copy(id = (list.maxOfOrNull { it.id } ?: 0L) + 1) else m
        _macros.value = if (list.any { it.id == saved.id }) list.map { if (it.id == saved.id) saved else it } else list + saved
        persistMacros()
        saved
    }

    fun delete(id: Long) = synchronized(lock) {
        _macros.update { l -> l.filterNot { it.id == id } }
        persistMacros()
    }

    fun setEnabled(id: Long, enabled: Boolean) = synchronized(lock) {
        _macros.update { l -> l.map { if (it.id == id) it.copy(enabled = enabled) else it } }
        persistMacros()
    }

    private fun ubah(pilih: (Macro) -> Boolean, f: (Macro) -> Macro) = synchronized(lock) {
        _macros.update { l -> l.map { if (pilih(it)) f(it) else it } }
        persistMacros()
    }

    fun rename(id: Long, name: String) = ubah({ it.id == id }) { it.copy(name = name.trim()) }

    fun setCategory(id: Long, category: String) = ubah({ it.id == id }) { it.copy(category = category.trim().ifBlank { "Umum" }) }

    fun renameCategory(old: String, new: String) =
        ubah({ it.category.ifBlank { "Umum" } == old }) { it.copy(category = new.trim().ifBlank { "Umum" }) }

    fun setCategoryEnabled(category: String, enabled: Boolean) =
        ubah({ it.category.ifBlank { "Umum" } == category }) { it.copy(enabled = enabled) }

    /** Gandakan makro (nama diberi akhiran "salinan", dalam keadaan nonaktif agar tidak jalan dobel). */
    fun duplicate(id: Long): Macro? {
        val m = find(id) ?: return null
        return save(m.copy(id = 0, name = m.name + " (salinan)", enabled = false, lastRun = 0, runCount = 0))
    }

    /** Satu makro sebagai JSON (daftar berisi satu makro) agar bisa diimpor lagi lewat Impor makro. */
    fun exportOne(id: Long): String? = find(id)?.let { AppJson.encodeToString(macroSer, listOf(it)) }

    fun markRun(id: Long) = synchronized(lock) {
        _macros.update { l -> l.map { if (it.id == id) it.copy(lastRun = System.currentTimeMillis(), runCount = it.runCount + 1) else it } }
        persistMacros()
    }

    fun exportJson(): String = AppJson.encodeToString(macroSer, _macros.value)

    /** Cadangan lengkap: semua makro dan semua variabel dalam satu berkas JSON. */
    fun exportBackup(): String {
        val akar = JsonObject(
            mapOf(
                "makroku_backup" to JsonPrimitive(1),
                "macros" to AppJson.encodeToJsonElement(macroSer, _macros.value),
                "variables" to JsonObject(_vars.value.mapValues { JsonPrimitive(it.value) }),
            ),
        )
        return AppJson.encodeToString(JsonElement.serializer(), akar)
    }

    /** Simpan hasil baca berkas: makro (id diberi ulang) dan variabel dari cadangan lengkap. Mengembalikan jumlah makro. */
    fun applyImport(h: ImportResult): Int {
        val n = importMacros(h.macros)
        h.variables.forEach { (k, v) -> setVariable(k, v) }
        return n
    }

    /** Impor daftar makro (id diberi ulang). Mengembalikan jumlah makro yang masuk. */
    fun importJson(text: String): Int {
        return importMacros(parseImport(text))
    }

    /**
     * Baca isi berkas makro: format MakroKu (daftar JSON) atau berkas `.macro` asli MacroDroid.
     * Melempar galat bila bukan berkas makro. Makro belum disimpan.
     */
    fun parseImportFull(text: String): ImportResult {
        val t = text.trim().removePrefix("\uFEFF")
        val hasil = if (t.startsWith("{")) {
            val akar = AppJson.parseToJsonElement(t) as? JsonObject ?: error("Bukan berkas makro")
            if (akar.containsKey("makroku_backup")) {
                val ms = AppJson.decodeFromJsonElement(macroSer, akar["macros"] ?: JsonArray(emptyList()))
                val vars = (akar["variables"] as? JsonObject)?.mapValues { it.value.jsonPrimitive.contentOrNull.orEmpty() }.orEmpty()
                ImportResult(ms, emptyList(), vars)
            } else MacroDroidImport.convert(t)
        } else ImportResult(AppJson.decodeFromString(macroSer, t), emptyList())
        require(hasil.macros.isNotEmpty() || hasil.variables.isNotEmpty()) { "Berkas tidak berisi makro" }
        return hasil
    }

    fun parseImport(text: String): List<Macro> = parseImportFull(text).macros

    /** Simpan daftar makro hasil [parseImport] (id diberi ulang). Mengembalikan jumlahnya. */
    fun importMacros(list: List<Macro>): Int {
        list.forEach { save(it.copy(id = 0, lastRun = 0, runCount = 0)) }
        return list.size
    }

    // ── Log ──
    fun log(macro: String, message: String, ok: Boolean = true) = synchronized(lock) {
        _logs.update { (listOf(LogEntry(System.currentTimeMillis(), macro, message, ok)) + it).take(300) }
        try { logFile.writeText(AppJson.encodeToString(logSer, _logs.value)) } catch (_: Exception) {}
    }

    fun clearLogs() = synchronized(lock) {
        _logs.value = emptyList()
        logFile.delete()
    }

    // ── Variabel ──
    fun setVariable(name: String, value: String) {
        prefs.edit().putString(name, value).apply()
        _vars.update { it + (name to value) }
    }

    fun deleteVariable(name: String) {
        prefs.edit().remove(name).apply()
        _vars.update { it - name }
    }
}
