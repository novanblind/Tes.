package com.novan.filemanagermax

import android.content.Context
import android.text.InputType
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout

/** Kotak centang "Tampilkan kata sandi" untuk semua kolom kata sandi. */
object PasswordUi {
    private const val HIDDEN = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    private const val VISIBLE = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD

    /** Membuat kotak centang yang mengatur tampil/sembunyi isi [input]. */
    fun checkBox(c: Context, input: EditText): CheckBox {
        input.inputType = HIDDEN
        val show = CheckBox(c)
        show.text = c.getString(R.string.zip_password_show)
        show.minHeight = (48 * c.resources.displayMetrics.density).toInt()
        show.setOnCheckedChangeListener { _, checked ->
            val pos = input.selectionEnd
            input.inputType = if (checked) VISIBLE else HIDDEN
            input.setSelection(pos.coerceIn(0, input.text.length))
        }
        return show
    }

    /** Membungkus kolom kata sandi dan kotak centangnya untuk dipasang di dialog. */
    fun dialogView(c: Context, input: EditText): LinearLayout {
        val pad = (20 * c.resources.displayMetrics.density).toInt()
        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(checkBox(c, input))
        return box
    }
}
