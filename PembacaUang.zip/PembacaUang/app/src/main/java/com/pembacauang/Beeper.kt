package com.pembacauang

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper

/** Bip pendek tiap 10 detik selama kamera aktif, tanda aplikasi sedang "mendengarkan". */
object Beeper {
    private const val INTERVAL_MS = 10_000L

    private var player: MediaPlayer? = null
    private var handler: Handler? = null
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                player?.start()
                handler?.postDelayed(this, INTERVAL_MS)
            } catch (_: Exception) {
            }
        }
    }

    fun start(context: Context) {
        stop()
        try {
            player = MediaPlayer.create(context.applicationContext, R.raw.beep)
            handler = Handler(Looper.getMainLooper())
            running = true
            handler?.post(tick)
        } catch (_: Exception) {
        }
    }

    fun stop() {
        running = false
        try {
            handler?.removeCallbacks(tick)
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        handler = null
    }
}
