package com.novan.filemanagerpro

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.math.BigDecimal
import java.math.MathContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipFile

/**
 * Pembaca dokumen Office tanpa library tambahan: berkas .docx adalah zip berisi XML,
 * dibaca dengan XmlPullParser bawaan Android. Hasilnya daftar blok teks (judul, paragraf,
 * butir, tabel) supaya mudah dibaca pembaca layar.
 */
object OfficeReader {

    const val K_INFO = 0
    const val K_PARA = 1
    const val K_HEADING = 2
    const val K_LIST = 3
    const val K_TABLE = 4
    const val K_ROW = 5
    const val K_PAGE = 6

    internal const val MAX_BLOCKS = 100_000
    internal const val MAX_BLOCK_CHARS = 20_000


    /**
     * Xml.newPullParser() bawaan Android menyalakan pemrosesan namespace, sehingga nama tag
     * tanpa awalan ("p", "document", "sldId") dan atribut "r:id" tidak cocok dengan kode di sini
     * yang memakai nama berawalan ("w:p", "p:sldId", "r:id"). Dimatikan agar nama tag utuh.
     */
    internal fun newXmlParser(): XmlPullParser {
        val p = Xml.newPullParser()
        try {
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        } catch (e: Exception) {
            // abaikan
        }
        return p
    }

    class Block(val kind: Int, val level: Int, val text: String)

    class Doc {
        var format = "docx"
        var kind = "text"
        var typeName = "Dokumen Word"
        var sheets = 0
        var slides = 0
        var rows = 0
        val blocks = ArrayList<Block>()
        var paragraphs = 0
        var headings = 0
        var tables = 0
        var images = 0
        var truncated = false
    }

    private val WORD_EXT = setOf("docx", "docm", "dotx", "dotm")
    private val DOC_EXT = setOf("doc", "dot")
    private val RTF_EXT = setOf("rtf")
    private val CSV_EXT = setOf("csv")
    private val TSV_EXT = setOf("tsv", "tab")
    private val EXCEL_EXT = setOf("xlsx", "xlsm", "xltx", "xltm")
    private val XLS_EXT = setOf("xls", "xlt")
    private val PPT_EXT = setOf("pptx", "pptm", "potx", "potm", "ppsx", "ppsm")
    private val OLDPPT_EXT = setOf("ppt", "pps", "pot")
    private val ODT_EXT = setOf("odt", "ott")
    private val ODS_EXT = setOf("ods", "ots")
    private val ODP_EXT = setOf("odp", "otp")
    const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    const val PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    const val DOC_MIME = "application/msword"
    const val XLS_MIME = "application/vnd.ms-excel"
    const val PPT_MIME = "application/vnd.ms-powerpoint"
    const val ODT_MIME = "application/vnd.oasis.opendocument.text"
    const val ODS_MIME = "application/vnd.oasis.opendocument.spreadsheet"
    const val ODP_MIME = "application/vnd.oasis.opendocument.presentation"

    fun mimeFor(format: String): String = when (format) {
        "xlsx" -> XLSX_MIME
        "pptx" -> PPTX_MIME
        "doc" -> DOC_MIME
        "xls" -> XLS_MIME
        "ppt" -> PPT_MIME
        "rtf" -> "application/rtf"
        "csv" -> "text/csv"
        "tsv" -> "text/tab-separated-values"
        "odt" -> ODT_MIME
        "ods" -> ODS_MIME
        "odp" -> ODP_MIME
        else -> DOCX_MIME
    }

    /** Mengembalikan "docx" bila nama atau jenis berkas dikenali, selain itu null. */
    fun formatOf(name: String?, mime: String?): String? {
        val ext = name?.substringAfterLast('.', "")?.lowercase() ?: ""
        if (ext in WORD_EXT) return "docx"
        if (ext in DOC_EXT) return "doc"
        if (ext in RTF_EXT) return "rtf"
        if (ext in CSV_EXT) return "csv"
        if (ext in TSV_EXT) return "tsv"
        if (ext in EXCEL_EXT) return "xlsx"
        if (ext in XLS_EXT) return "xls"
        if (ext in PPT_EXT) return "pptx"
        if (ext in OLDPPT_EXT) return "ppt"
        if (ext in ODT_EXT) return "odt"
        if (ext in ODS_EXT) return "ods"
        if (ext in ODP_EXT) return "odp"
        if (mime == DOCX_MIME) return "docx"
        if (mime == DOC_MIME) return "doc"
        if (mime == "application/rtf" || mime == "text/rtf") return "rtf"
        if (mime == "text/csv") return "csv"
        if (mime == "text/tab-separated-values") return "tsv"
        if (mime == XLSX_MIME) return "xlsx"
        if (mime == XLS_MIME) return "xls"
        if (mime == PPTX_MIME) return "pptx"
        if (mime == PPT_MIME) return "ppt"
        if (mime == ODT_MIME || mime == "application/vnd.oasis.opendocument.text-template") return "odt"
        if (mime == ODS_MIME || mime == "application/vnd.oasis.opendocument.spreadsheet-template") return "ods"
        if (mime == ODP_MIME || mime == "application/vnd.oasis.opendocument.presentation-template") return "odp"
        return null
    }

    fun isSupported(f: File): Boolean = f.isFile && formatOf(f.name, null) != null

    fun parse(f: File, format: String, name: String = f.name): Doc = when (format) {
        "docx" -> parseDocx(f)
        "doc" -> parseDoc(f)
        "rtf" -> RtfReader.parse(f)
        "csv", "tsv" -> CsvReader.parse(f, name, format == "tsv")
        "xls" -> parseXls(f)
        "ppt" -> parsePpt(f)
        "xlsx" -> parseXlsx(f)
        "pptx" -> parsePptx(f)
        "odt", "ods", "odp" -> parseOdf(f, format)
        else -> throw IllegalArgumentException("format")
    }

    /** Berkas berekstensi .doc bisa sebenarnya OLE (Word lama), zip (.docx) atau RTF. */
    private fun parseDoc(f: File): Doc {
        val head = ByteArray(8)
        val n = try { f.inputStream().use { it.read(head) } } catch (e: Exception) { 0 }
        if (n >= 4 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()) return parseDocx(f)
        if (n >= 5 && String(head, 0, 5, Charsets.ISO_8859_1) == "{\\rtf") return RtfReader.parse(f)
        return LegacyDoc.parse(f)
    }

    /** Berkas .xls bisa sebenarnya OLE (BIFF), zip (.xlsx), atau teks (HTML/CSV bawaan situs). */
    private fun parseXls(f: File): Doc {
        val head = ByteArray(8)
        val n = try { f.inputStream().use { it.read(head) } } catch (e: Exception) { 0 }
        if (n >= 4 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()) return parseXlsx(f)
        if (n >= 4 && OleFile.isOle(f)) return LegacyXls.parse(f)
        throw IllegalStateException("Berkas ini bukan Excel biner. Gunakan Buka dengan aplikasi lain atau editor teks.")
    }

    /** Berkas .ppt bisa sebenarnya OLE (PowerPoint lama) atau zip (.pptx). */
    private fun parsePpt(f: File): Doc {
        val head = ByteArray(8)
        val n = try { f.inputStream().use { it.read(head) } } catch (e: Exception) { 0 }
        if (n >= 4 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()) return parsePptx(f)
        if (n >= 4 && OleFile.isOle(f)) return LegacyPpt.parse(f)
        throw IllegalStateException("Berkas ini bukan PowerPoint biner. Gunakan Buka dengan aplikasi lain.")
    }

    private fun parseDocx(f: File): Doc {
        if (OleFile.isOle(f)) {
            throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
        }
        ZipFile(f).use { zip ->
            val docEntry = zip.getEntry("word/document.xml")
                ?: throw IllegalStateException("bukan docx")
            val headingLevel = HashMap<String, Int>()
            val listStyle = HashSet<String>()
            zip.getEntry("word/styles.xml")?.let { e ->
                zip.getInputStream(e).use { readStyles(it, headingLevel, listStyle) }
            }
            val doc = Doc()
            zip.getInputStream(docEntry).use { DocxParser(doc, headingLevel, listStyle).run(it) }
            if (doc.blocks.isEmpty()) {
                doc.blocks.add(Block(K_PARA, 0, "Dokumen kosong atau tidak berisi teks."))
            }
            return doc
        }
    }

    private fun readStyles(ins: InputStream, level: HashMap<String, Int>, lists: HashSet<String>) {
        val p = newXmlParser()
        p.setInput(ins, null)
        var id: String? = null
        var lvl = 0
        var isList = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "w:style" -> {
                        id = p.getAttributeValue(null, "w:styleId")
                        lvl = 0
                        isList = false
                    }
                    "w:name" -> if (id != null) {
                        val n = (p.getAttributeValue(null, "w:val") ?: "").lowercase()
                        if (n.startsWith("heading ")) lvl = n.substring(8).trim().toIntOrNull() ?: 0
                        else if (n == "title") lvl = 1
                        if (n.startsWith("list bullet") || n.startsWith("list number")) isList = true
                    }
                    "w:outlineLvl" -> if (id != null && lvl == 0) {
                        val v = p.getAttributeValue(null, "w:val")?.toIntOrNull()
                        if (v != null && v in 0..8) lvl = v + 1
                    }
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "w:style") {
                val k = id
                if (k != null) {
                    if (lvl > 0) level[k] = lvl
                    if (isList) lists.add(k)
                }
                id = null
            }
            ev = p.next()
        }
    }


    // ---------------------------------------------------------------- Excel (.xlsx)

    private fun colIndex(ref: String?): Int {
        if (ref == null) return 0
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1)
            else if (ch in 'a'..'z') n = n * 26 + (ch - 'a' + 1)
            else break
        }
        return n
    }

    internal fun colLetters(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.insert(0, 'A' + r)
            n = (n - 1) / 26
        }
        return sb.toString()
    }

    private fun parseXlsx(f: File): Doc {
        if (OleFile.isOle(f)) {
            throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
        }
        ZipFile(f).use { zip ->
            val wb = zip.getEntry("xl/workbook.xml") ?: throw IllegalStateException("bukan xlsx")
            // nama lembar dan hubungan ke berkas
            class SheetRef(val name: String, val rid: String?, val hidden: Boolean)
            val refs = ArrayList<SheetRef>()
            var date1904 = false
            zip.getInputStream(wb).use { ins ->
                val p = newXmlParser()
                p.setInput(ins, null)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "workbookPr" -> {
                                val v = p.getAttributeValue(null, "date1904")
                                date1904 = v == "1" || v == "true"
                            }
                            "sheet" -> refs.add(
                                SheetRef(
                                    p.getAttributeValue(null, "name") ?: "Lembar ${refs.size + 1}",
                                    p.getAttributeValue(null, "r:id"),
                                    p.getAttributeValue(null, "state").let { it == "hidden" || it == "veryHidden" }
                                )
                            )
                        }
                    }
                    ev = p.next()
                }
            }
            val targets = HashMap<String, String>()
            zip.getEntry("xl/_rels/workbook.xml.rels")?.let { e ->
                zip.getInputStream(e).use { ins ->
                    val p = newXmlParser()
                    p.setInput(ins, null)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                            val type = p.getAttributeValue(null, "Type") ?: ""
                            val id = p.getAttributeValue(null, "Id")
                            val t = p.getAttributeValue(null, "Target")
                            if (id != null && t != null && type.endsWith("/worksheet")) {
                                targets[id] = if (t.startsWith("/")) t.substring(1) else "xl/$t"
                            }
                        }
                        ev = p.next()
                    }
                }
            }
            val shared = ArrayList<String>()
            zip.getEntry("xl/sharedStrings.xml")?.let { e ->
                zip.getInputStream(e).use { readSharedStrings(it, shared) }
            }
            val dateXf = ArrayList<Boolean>()
            zip.getEntry("xl/styles.xml")?.let { e ->
                zip.getInputStream(e).use { readDateStyles(it, dateXf) }
            }

            val doc = Doc()
            doc.format = "xlsx"
            doc.kind = "sheet"
            doc.typeName = "Lembar kerja Excel"
            val visible = refs.filter { r -> !r.hidden && r.rid?.let { targets[it] } != null }
            val total = visible.size
            if (total == 0) {
                doc.blocks.add(Block(K_PARA, 0, "Buku kerja ini tidak berisi lembar yang bisa dibaca."))
                return doc
            }
            for ((i, r) in visible.withIndex()) {
                val entry = zip.getEntry(r.rid?.let { targets[it] } ?: continue) ?: continue
                doc.sheets++
                val sheet = SheetParser(shared, dateXf, date1904)
                zip.getInputStream(entry).use { sheet.run(it) }
                if (doc.blocks.size + sheet.out.size + 2 > MAX_BLOCKS) {
                    doc.truncated = true
                }
                doc.headings++
                doc.blocks.add(Block(K_HEADING, 1, "Lembar ${i + 1} dari $total: ${r.name}"))
                if (sheet.out.isEmpty()) {
                    doc.blocks.add(Block(K_PARA, 0, "Lembar ini kosong."))
                } else {
                    val range = if (sheet.minCol == sheet.maxCol) "kolom ${colLetters(sheet.minCol)}"
                    else "kolom ${colLetters(sheet.minCol)} sampai ${colLetters(sheet.maxCol)}"
                    doc.tables++
                    doc.blocks.add(Block(K_TABLE, 0, "${sheet.out.size} baris berisi data, $range"))
                    for (b in sheet.out) {
                        if (doc.blocks.size >= MAX_BLOCKS) { doc.truncated = true; break }
                        doc.blocks.add(b)
                        doc.rows++
                    }
                }
                if (doc.truncated) break
            }
            return doc
        }
    }

    private fun readSharedStrings(ins: InputStream, out: ArrayList<String>) {
        val p = newXmlParser()
        p.setInput(ins, null)
        val sb = StringBuilder()
        var inT = false
        var inPh = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> sb.setLength(0)
                    "rPh" -> inPh = true
                    "t" -> inT = true
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "rPh" -> inPh = false
                    "si" -> {
                        var t = sb.toString()
                        if (t.length > MAX_BLOCK_CHARS) t = t.substring(0, MAX_BLOCK_CHARS) + "…"
                        out.add(t)
                    }
                }
                XmlPullParser.TEXT -> if (inT && !inPh) sb.append(p.text)
            }
            ev = p.next()
        }
    }

    internal val BUILTIN_DATE = setOf(14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47)

    internal fun isDateCode(code: String): Boolean {
        val sb = StringBuilder()
        var i = 0
        while (i < code.length) {
            val ch = code[i]
            when (ch) {
                '"' -> { i++; while (i < code.length && code[i] != '"') i++ }
                '[' -> { i++; while (i < code.length && code[i] != ']') i++ }
                '\\', '_', '*' -> i++
                else -> sb.append(ch.lowercaseChar())
            }
            i++
        }
        return Regex("[dmyhs]").containsMatchIn(sb)
    }

    private fun readDateStyles(ins: InputStream, out: ArrayList<Boolean>) {
        val p = newXmlParser()
        p.setInput(ins, null)
        val custom = HashMap<Int, Boolean>()
        var inXfs = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "numFmt" -> {
                        val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                        val code = p.getAttributeValue(null, "formatCode")
                        if (id != null && code != null) custom[id] = isDateCode(code)
                    }
                    "cellXfs" -> inXfs = true
                    "xf" -> if (inXfs) {
                        val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                        out.add(custom[id] ?: (id in BUILTIN_DATE))
                    }
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "cellXfs") {
                return
            }
            ev = p.next()
        }
    }

    internal fun formatNumber(v: String): String {
        val d = v.toDoubleOrNull() ?: return v
        if (d.isNaN() || d.isInfinite()) return v
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return try {
            BigDecimal(d).round(MathContext(12)).stripTrailingZeros().toPlainString()
        } catch (e: Exception) {
            v
        }
    }

    internal fun formatDate(v: String, date1904: Boolean): String {
        val d = v.toDoubleOrNull() ?: return v
        if (d < 0 || d > 3_000_000) return formatNumber(v)
        val days = if (date1904) d + 1462 else d
        val millis = Math.round((days - 25569.0) * 86_400_000.0)
        val tz = TimeZone.getTimeZone("UTC")
        val id = Locale("id", "ID")
        val hasTime = d - Math.floor(d) > 1e-9
        val pattern = when {
            d < 1.0 && hasTime -> "HH:mm"
            hasTime -> "d MMMM yyyy HH:mm"
            else -> "d MMMM yyyy"
        }
        return SimpleDateFormat(pattern, id).apply { timeZone = tz }.format(java.util.Date(millis))
    }

    internal class Cell(val col: Int, val text: String, val isText: Boolean)

    /** Mengumpulkan baris lembar kerja menjadi blok, memakai baris pertama sebagai judul kolom bila cocok. */
    internal class SheetRows {
        val out = ArrayList<Block>()
        var minCol = Int.MAX_VALUE
        var maxCol = 0
        private var header: HashMap<Int, String>? = null
        private var firstRowDone = false

        fun addRow(rowNum: Int, cells: List<Cell>) {
            if (cells.isEmpty()) return
            for (c in cells) {
                if (c.col < minCol) minCol = c.col
                if (c.col > maxCol) maxCol = c.col
            }
            if (!firstRowDone) {
                firstRowDone = true
                if (cells.size >= 2 && cells.all { it.isText }) {
                    val h = HashMap<Int, String>()
                    for (c in cells) h[c.col] = c.text
                    header = h
                    out.add(Block(K_ROW, 0, "Baris $rowNum, judul kolom: " + cells.joinToString("; ") { it.text }))
                    return
                }
            }
            val h = header
            val body = cells.joinToString("; ") { c ->
                val label = h?.get(c.col) ?: "Kolom ${colLetters(c.col)}"
                "$label: ${c.text}"
            }
            out.add(Block(K_ROW, 0, "Baris $rowNum: $body"))
        }
    }

    private class SheetParser(
        val shared: List<String>,
        val dateXf: List<Boolean>,
        val date1904: Boolean
    ) {
        private val sheetRows = SheetRows()
        val out: ArrayList<Block> get() = sheetRows.out
        val minCol: Int get() = sheetRows.minCol
        val maxCol: Int get() = sheetRows.maxCol

        private var rowNum = 0
        private var lastCol = 0
        private var cells = ArrayList<Cell>()

        private var cType: String? = null
        private var cStyle = -1
        private var cCol = 0
        private val vBuf = StringBuilder()
        private var inV = false
        private var inT = false
        private var inPh = false

        fun run(ins: InputStream) {
            val p = newXmlParser()
            p.setInput(ins, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "row" -> {
                            rowNum = p.getAttributeValue(null, "r")?.toIntOrNull() ?: (rowNum + 1)
                            cells = ArrayList()
                            lastCol = 0
                        }
                        "c" -> {
                            val c = colIndex(p.getAttributeValue(null, "r"))
                            cCol = if (c > 0) c else lastCol + 1
                            lastCol = cCol
                            cType = p.getAttributeValue(null, "t")
                            cStyle = p.getAttributeValue(null, "s")?.toIntOrNull() ?: -1
                            vBuf.setLength(0)
                        }
                        "v" -> inV = true
                        "t" -> inT = true
                        "rPh" -> inPh = true
                    }
                    XmlPullParser.END_TAG -> when (p.name) {
                        "v" -> inV = false
                        "t" -> inT = false
                        "rPh" -> inPh = false
                        "c" -> endCell()
                        "row" -> endRow()
                    }
                    XmlPullParser.TEXT -> if ((inV || inT) && !inPh) vBuf.append(p.text)
                }
                ev = p.next()
            }
        }

        private fun endCell() {
            val raw = vBuf.toString().trim()
            if (raw.isEmpty()) return
            var isText = false
            val text = when (cType) {
                "s" -> {
                    isText = true
                    shared.getOrNull(raw.toIntOrNull() ?: -1) ?: ""
                }
                "str", "inlineStr" -> { isText = true; raw }
                "b" -> if (raw == "1") "Benar" else "Salah"
                "e" -> "Galat $raw"
                "d" -> raw
                else -> if (cStyle >= 0 && dateXf.getOrNull(cStyle) == true) formatDate(raw, date1904)
                else formatNumber(raw)
            }
            if (text.isBlank()) return
            val t = if (text.length > MAX_BLOCK_CHARS) text.substring(0, MAX_BLOCK_CHARS) + "…" else text.trim()
            cells.add(Cell(cCol, t, isText && t.toDoubleOrNull() == null))
        }

        private fun endRow() {
            sheetRows.addRow(rowNum, cells)
        }
    }

    // ---------------------------------------------------------------- PowerPoint (.pptx)

    private fun resolvePath(baseDir: String, target: String): String {
        if (target.startsWith("/")) return target.substring(1)
        val parts = ArrayList<String>()
        for (seg in (baseDir + target).split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }

    /** Pasangan Id -> (Type, Target) dari berkas .rels. */
    private fun readRels(zip: ZipFile, path: String): Map<String, Pair<String, String>> {
        val out = HashMap<String, Pair<String, String>>()
        val e = zip.getEntry(path) ?: return out
        zip.getInputStream(e).use { ins ->
            val p = newXmlParser()
            p.setInput(ins, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = p.getAttributeValue(null, "Id")
                    val type = p.getAttributeValue(null, "Type")
                    val t = p.getAttributeValue(null, "Target")
                    if (id != null && type != null && t != null) out[id] = Pair(type, t)
                }
                ev = p.next()
            }
        }
        return out
    }

    private fun parsePptx(f: File): Doc {
        if (OleFile.isOle(f)) {
            throw IllegalStateException("Dokumen dilindungi kata sandi, tidak bisa dibuka di penampil bawaan.")
        }
        ZipFile(f).use { zip ->
            val pres = zip.getEntry("ppt/presentation.xml") ?: throw IllegalStateException("bukan pptx")
            val order = ArrayList<String>()
            zip.getInputStream(pres).use { ins ->
                val p = newXmlParser()
                p.setInput(ins, null)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "p:sldId") {
                        p.getAttributeValue(null, "r:id")?.let { order.add(it) }
                    }
                    ev = p.next()
                }
            }
            val rels = readRels(zip, "ppt/_rels/presentation.xml.rels")
            val paths = order.mapNotNull { id ->
                val r = rels[id]
                if (r != null && r.first.endsWith("/slide")) resolvePath("ppt/", r.second) else null
            }
            val doc = Doc()
            doc.format = "pptx"
            doc.kind = "deck"
            doc.typeName = "Presentasi PowerPoint"
            if (paths.isEmpty()) {
                doc.blocks.add(Block(K_PARA, 0, "Presentasi ini tidak berisi slide yang bisa dibaca."))
                return doc
            }
            val total = paths.size
            for ((i, sp) in paths.withIndex()) {
                if (doc.blocks.size >= MAX_BLOCKS) { doc.truncated = true; break }
                doc.slides++
                val sl = SlideParser(doc)
                var failed = false
                try {
                    val e = zip.getEntry(sp)
                    if (e == null) failed = true
                    else zip.getInputStream(e).use { sl.run(it) }
                } catch (ex: Exception) {
                    failed = true
                }
                var head = "Slide ${i + 1} dari $total"
                if (sl.title.isNotEmpty()) head += ": " + sl.title
                if (sl.hidden) head += " (tersembunyi)"
                doc.headings++
                doc.blocks.add(Block(K_HEADING, 1, head))
                if (failed) {
                    doc.blocks.add(Block(K_PARA, 0, "Slide ini tidak dapat dibaca."))
                    continue
                }
                if (sl.out.isEmpty()) doc.blocks.add(Block(K_PARA, 0, "Slide ini tidak berisi teks."))
                for (b in sl.out) {
                    if (doc.blocks.size >= MAX_BLOCKS) { doc.truncated = true; break }
                    doc.blocks.add(b)
                }
                // catatan pembicara
                try {
                    val slideRels = readRels(zip, "ppt/slides/_rels/" + sp.substringAfterLast('/') + ".rels")
                    val notesRel = slideRels.values.firstOrNull { it.first.endsWith("/notesSlide") }
                    if (notesRel != null) {
                        val ne = zip.getEntry(resolvePath("ppt/slides/", notesRel.second))
                        if (ne != null) {
                            val notes = zip.getInputStream(ne).use { readNotes(it) }
                            if (notes.isNotBlank()) {
                                doc.blocks.add(Block(K_PARA, 0, "Catatan pembicara: $notes"))
                            }
                        }
                    }
                } catch (ex: Exception) {
                    // catatan dilewati
                }
            }
            return doc
        }
    }

    private fun readNotes(ins: InputStream): String {
        val p = newXmlParser()
        p.setInput(ins, null)
        val result = StringBuilder()
        val lines = ArrayList<String>()
        val para = StringBuilder()
        var inSp = false
        var inT = false
        var phType: String? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "p:sp" -> { inSp = true; phType = null; lines.clear() }
                    "p:ph" -> phType = p.getAttributeValue(null, "type")
                    "a:p" -> para.setLength(0)
                    "a:t" -> inT = true
                    "a:br" -> para.append(' ')
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "a:t" -> inT = false
                    "a:p" -> if (inSp) {
                        val t = para.toString().trim()
                        if (t.isNotEmpty()) lines.add(t)
                    }
                    "p:sp" -> {
                        if (phType == "body" && lines.isNotEmpty()) {
                            if (result.isNotEmpty()) result.append('\n')
                            result.append(lines.joinToString("\n"))
                        }
                        inSp = false
                    }
                }
                XmlPullParser.TEXT -> if (inT) para.append(p.text)
            }
            ev = p.next()
        }
        var t = result.toString().trim()
        if (t.length > MAX_BLOCK_CHARS) t = t.substring(0, MAX_BLOCK_CHARS) + "…"
        return t
    }

    internal fun tableBlocks(rows: List<List<String>>, no: Int): List<Block> {
        val out = ArrayList<Block>()
        if (rows.none { r -> r.any { it.isNotBlank() } }) return out
        val cols = rows.maxOf { it.size }
        out.add(Block(K_TABLE, 0, "Tabel $no: ${rows.size} baris, $cols kolom"))
        val header = rows.first { r -> r.any { it.isNotBlank() } }
        val headerIdx = rows.indexOf(header)
        val useHeader = rows.count { r -> r.any { it.isNotBlank() } } > 1 &&
            header.none { it.isBlank() } && rows.all { it.size == header.size }
        for ((i, r) in rows.withIndex()) {
            if (r.none { it.isNotBlank() }) continue
            val body = if (useHeader && i != headerIdx) {
                r.mapIndexedNotNull { j, c -> if (c.isBlank()) null else "${header[j]}: $c" }.joinToString("; ")
            } else {
                r.filter { it.isNotBlank() }.joinToString("; ")
            }
            val label = if (useHeader && i == headerIdx) "Baris ${i + 1}, judul kolom: " else "Baris ${i + 1}: "
            out.add(Block(K_ROW, 0, label + body))
        }
        return out
    }

    private class SlideParser(val doc: Doc) {
        val out = ArrayList<Block>()
        var title = ""
        var hidden = false

        private class Para(val text: String, val level: Int, val explicit: Boolean, val none: Boolean)

        private var skip = 0
        private var inT = false
        private var inSp = false
        private var hasPh = false
        private var phType: String? = null
        private val paras = ArrayList<Para>()
        private val sb = StringBuilder()
        private var pLevel = 0
        private var buNone = false
        private var buExplicit = false
        private var tblDepth = 0
        private var rows = ArrayList<List<String>>()
        private var curRow = ArrayList<String>()
        private val cell = StringBuilder()
        private var inPic = false
        private var picAlt = ""

        fun run(ins: InputStream) {
            val p = newXmlParser()
            p.setInput(ins, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        if (skip > 0) skip++
                        else if (p.name == "mc:Fallback") skip = 1
                        else onStart(p)
                    }
                    XmlPullParser.END_TAG -> {
                        if (skip > 0) skip-- else onEnd(p.name)
                    }
                    XmlPullParser.TEXT -> if (inT && skip == 0) sb.append(p.text)
                }
                if (doc.truncated) return
                ev = p.next()
            }
        }

        private fun onStart(p: XmlPullParser) {
            when (p.name) {
                "p:sld" -> hidden = p.getAttributeValue(null, "show") == "0"
                "p:sp" -> { inSp = true; hasPh = false; phType = null; paras.clear() }
                "p:ph" -> { hasPh = true; phType = p.getAttributeValue(null, "type") }
                "a:p" -> { sb.setLength(0); pLevel = 0; buNone = false; buExplicit = false }
                "a:pPr" -> pLevel = p.getAttributeValue(null, "lvl")?.toIntOrNull() ?: 0
                "a:buNone" -> buNone = true
                "a:buChar", "a:buAutoNum", "a:buBlip" -> buExplicit = true
                "a:t" -> inT = true
                "a:br" -> sb.append('\n')
                "a:tbl" -> { tblDepth++; if (tblDepth == 1) rows = ArrayList() }
                "a:tr" -> if (tblDepth == 1) curRow = ArrayList()
                "a:tc" -> if (tblDepth == 1) cell.setLength(0)
                "p:pic" -> { inPic = true; picAlt = "" }
                "p:cNvPr" -> if (inPic) picAlt = (p.getAttributeValue(null, "descr") ?: "").trim()
                "c:chart" -> out.add(Block(K_PARA, 0, "[Bagan]"))
                "dgm:relIds" -> out.add(Block(K_PARA, 0, "[Diagram SmartArt]"))
            }
        }

        private fun onEnd(name: String) {
            when (name) {
                "a:t" -> inT = false
                "a:p" -> endPara()
                "a:tc" -> if (tblDepth == 1) curRow.add(cell.toString().trim())
                "a:tr" -> if (tblDepth == 1) rows.add(curRow)
                "a:tbl" -> {
                    if (tblDepth == 1) {
                        val no = doc.tables + 1
                        val tb = tableBlocks(rows, no)
                        if (tb.isNotEmpty()) { doc.tables++; out.addAll(tb) }
                    }
                    if (tblDepth > 0) tblDepth--
                }
                "p:sp" -> endSp()
                "p:pic" -> {
                    inPic = false
                    doc.images++
                    out.add(Block(K_PARA, 0, if (picAlt.isEmpty()) "[Gambar]" else "[Gambar: $picAlt]"))
                }
            }
        }

        private fun clean(s: String): String {
            val o = StringBuilder(s.length)
            var last = false
            for (ch in s) {
                val sp = ch == ' ' || ch == '\t' || ch == '\u00A0'
                if (sp) { if (!last) o.append(' '); last = true } else { o.append(ch); last = false }
            }
            var t = o.toString().trim()
            if (t.length > MAX_BLOCK_CHARS) t = t.substring(0, MAX_BLOCK_CHARS) + "…"
            return t
        }

        private fun endPara() {
            val text = clean(sb.toString())
            sb.setLength(0)
            if (text.isEmpty()) return
            if (tblDepth > 0) {
                if (cell.isNotEmpty()) cell.append(", ")
                cell.append(text)
            } else if (inSp) {
                paras.add(Para(text, pLevel, buExplicit, buNone))
            }
        }

        private fun endSp() {
            inSp = false
            if (paras.isEmpty()) return
            val t = phType
            when {
                t == "title" || t == "ctrTitle" -> {
                    if (title.isEmpty()) title = paras.joinToString(" ") { it.text.replace('\n', ' ') }
                    else addParas(false)
                }
                t == "sldNum" || t == "dt" || t == "ftr" || t == "hdr" -> {}
                else -> addParas(hasPh && (t == null || t == "body" || t == "obj"))
            }
            paras.clear()
        }

        private fun addParas(bodyPh: Boolean) {
            for (pa in paras) {
                val bullet = pa.explicit || (bodyPh && !pa.none)
                doc.paragraphs++
                out.add(Block(if (bullet) K_LIST else K_PARA, pa.level.coerceIn(0, 5), pa.text))
            }
        }
    }


    // ---------------------------------------------------------------- OpenDocument (.odt, .ods, .odp)

    private const val M_TEXT = 0
    private const val M_SHEET = 1
    private const val M_PRES = 2

    private fun cleanText(s: String): String {
        val o = StringBuilder(s.length)
        var last = false
        for (ch in s) {
            val sp = ch == ' ' || ch == '\t' || ch == '\u00A0'
            if (sp) { if (!last) o.append(' '); last = true } else { o.append(ch); last = false }
        }
        var t = o.toString().trim()
        if (t.length > MAX_BLOCK_CHARS) t = t.substring(0, MAX_BLOCK_CHARS) + "…"
        return t
    }

    private class OdfSlide(val name: String, val hidden: Boolean) {
        val titleParts = ArrayList<String>()
        val blocks = ArrayList<Block>()
        val notes = ArrayList<String>()
    }

    private fun parseOdf(f: File, format: String): Doc {
        ZipFile(f).use { zip ->
            val entry = zip.getEntry("content.xml") ?: throw IllegalStateException("bukan OpenDocument")
            val mode = when (format) { "ods" -> M_SHEET; "odp" -> M_PRES; else -> M_TEXT }
            val doc = Doc()
            doc.format = format
            when (mode) {
                M_SHEET -> { doc.kind = "sheet"; doc.typeName = "Lembar kerja OpenDocument" }
                M_PRES -> { doc.kind = "deck"; doc.typeName = "Presentasi OpenDocument" }
                else -> { doc.kind = "text"; doc.typeName = "Dokumen teks OpenDocument" }
            }
            val parser = OdfParser(doc, mode)
            zip.getInputStream(entry).use { parser.run(it) }
            parser.finish()
            if (doc.blocks.isEmpty()) {
                doc.blocks.add(Block(K_PARA, 0, "Dokumen kosong atau tidak berisi teks."))
            }
            return doc
        }
    }

    private class OdfParser(val doc: Doc, val mode: Int) {
        private var skip = 0
        private val stack = ArrayList<StringBuilder>()
        private val levels = ArrayList<Int>()
        private var listDepth = 0
        private var inAlt = false
        private val altSb = StringBuilder()
        private var frameImage = false
        private val frameStack = ArrayList<String?>()

        // tabel
        private var tblDepth = 0
        private var rows = ArrayList<List<String>>()
        private var curRow = ArrayList<String>()
        private val cell = StringBuilder()
        private var colRepeat = 1
        private var valueType: String? = null
        private var valAttr: String? = null

        // lembar kerja
        private var sheetName = ""
        private var sheetHidden = false
        private var sheetRows = SheetRows()
        private val sheets = ArrayList<Pair<String, SheetRows>>()
        private var rowNo = 0
        private var rowStart = 1
        private var rowRepeat = 1
        private var rowHidden = false
        private var curCells = ArrayList<Cell>()
        private var colNo = 0

        // presentasi
        private val slides = ArrayList<OdfSlide>()
        private var slide: OdfSlide? = null
        private var inNotes = false
        private val dummy = ArrayList<Block>()
        private var sink: ArrayList<Block> = doc.blocks

        private val skipTags = setOf("text:note", "text:tracked-changes", "office:annotation")

        fun run(ins: InputStream) {
            val p = newXmlParser()
            p.setInput(ins, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        if (skip > 0) skip++
                        else if (p.name in skipTags) skip = 1
                        else onStart(p)
                    }
                    XmlPullParser.END_TAG -> {
                        if (skip > 0) skip-- else onEnd(p.name)
                    }
                    XmlPullParser.TEXT -> if (skip == 0) {
                        if (inAlt) altSb.append(p.text)
                        else if (stack.isNotEmpty()) stack[stack.size - 1].append(p.text)
                    }
                }
                if (doc.truncated) return
                ev = p.next()
            }
        }

        private fun add(b: Block) {
            if (doc.blocks.size + (if (mode == M_PRES) slides.sumOf { it.blocks.size } else 0) >= MAX_BLOCKS) {
                doc.truncated = true
                return
            }
            sink.add(b)
        }

        private fun onStart(p: XmlPullParser) {
            when (p.name) {
                "text:p" -> { stack.add(StringBuilder()); levels.add(0) }
                "text:h" -> {
                    stack.add(StringBuilder())
                    levels.add(p.getAttributeValue(null, "text:outline-level")?.toIntOrNull() ?: 1)
                }
                "text:list" -> listDepth++
                "text:s" -> if (stack.isNotEmpty()) stack[stack.size - 1].append(' ')
                "text:tab" -> if (stack.isNotEmpty()) stack[stack.size - 1].append(' ')
                "text:line-break" -> if (stack.isNotEmpty()) stack[stack.size - 1].append('\n')
                "draw:frame" -> {
                    frameStack.add(p.getAttributeValue(null, "presentation:class"))
                    frameImage = false
                    altSb.setLength(0)
                }
                "draw:image" -> frameImage = true
                "svg:title", "svg:desc" -> { inAlt = true }
                "draw:object", "draw:object-ole" -> inline("[Objek tertanam]")
                "draw:page" -> if (mode == M_PRES) {
                    val sl = OdfSlide(
                        p.getAttributeValue(null, "draw:name") ?: "",
                        p.getAttributeValue(null, "presentation:visibility") == "hidden"
                    )
                    slide = sl
                    slides.add(sl)
                    sink = sl.blocks
                }
                "presentation:notes" -> inNotes = true
                "table:table" -> {
                    tblDepth++
                    if (tblDepth == 1) {
                        if (mode == M_SHEET) {
                            sheetName = p.getAttributeValue(null, "table:name") ?: "Lembar ${sheets.size + 1}"
                            sheetHidden = p.getAttributeValue(null, "table:display") == "false"
                            sheetRows = SheetRows()
                            rowNo = 0
                        } else {
                            rows = ArrayList()
                        }
                    }
                }
                "table:table-row" -> if (tblDepth == 1) {
                    if (mode == M_SHEET) {
                        rowRepeat = p.getAttributeValue(null, "table:number-rows-repeated")?.toIntOrNull() ?: 1
                        val vis = p.getAttributeValue(null, "table:visibility")
                        rowHidden = vis == "collapse" || vis == "filter"
                        rowStart = rowNo + 1
                        curCells = ArrayList()
                        colNo = 0
                    } else {
                        curRow = ArrayList()
                    }
                }
                "table:table-cell" -> if (tblDepth == 1) {
                    colRepeat = p.getAttributeValue(null, "table:number-columns-repeated")?.toIntOrNull() ?: 1
                    valueType = p.getAttributeValue(null, "office:value-type")
                    valAttr = p.getAttributeValue(null, "office:value")
                        ?: p.getAttributeValue(null, "office:date-value")
                        ?: p.getAttributeValue(null, "office:string-value")
                        ?: p.getAttributeValue(null, "office:boolean-value")
                    cell.setLength(0)
                }
                "table:covered-table-cell" -> if (tblDepth == 1) {
                    colRepeat = p.getAttributeValue(null, "table:number-columns-repeated")?.toIntOrNull() ?: 1
                }
            }
        }

        private fun onEnd(name: String) {
            when (name) {
                "text:p", "text:h" -> endPara()
                "text:list" -> if (listDepth > 0) listDepth--
                "svg:title", "svg:desc" -> { inAlt = false; if (altSb.isNotEmpty()) altSb.append(' ') }
                "draw:frame" -> {
                    if (frameStack.isNotEmpty()) frameStack.removeAt(frameStack.size - 1)
                    if (frameImage) {
                        frameImage = false
                        doc.images++
                        val alt = cleanText(altSb.toString())
                        inline(if (alt.isEmpty()) "[Gambar]" else "[Gambar: $alt]")
                    }
                    altSb.setLength(0)
                }
                "draw:page" -> if (mode == M_PRES) { slide = null; sink = dummy }
                "presentation:notes" -> inNotes = false
                "table:table-cell" -> if (tblDepth == 1) endCell()
                "table:covered-table-cell" -> if (tblDepth == 1) {
                    if (mode == M_SHEET) colNo += colRepeat else curRow.add("")
                }
                "table:table-row" -> if (tblDepth == 1) {
                    if (mode == M_SHEET) {
                        if (!sheetHidden && !rowHidden && curCells.isNotEmpty()) sheetRows.addRow(rowStart, curCells)
                        rowNo += rowRepeat
                    } else {
                        rows.add(curRow)
                    }
                }
                "table:table" -> {
                    if (tblDepth == 1) endTable()
                    if (tblDepth > 0) tblDepth--
                }
            }
        }

        private fun inline(text: String) {
            when {
                stack.isNotEmpty() -> stack[stack.size - 1].append(' ').append(text).append(' ')
                tblDepth > 0 -> {
                    if (cell.isNotEmpty()) cell.append(", ")
                    cell.append(text)
                }
                mode == M_SHEET -> {}
                else -> add(Block(K_PARA, 0, text))
            }
        }

        private fun endCell() {
            var text = cell.toString().trim()
            if (mode == M_SHEET) {
                if (text.isEmpty()) {
                    val v = valAttr
                    if (v != null) {
                        text = when (valueType) {
                            "boolean" -> if (v == "true") "Benar" else "Salah"
                            "float", "percentage", "currency" -> formatNumber(v)
                            else -> v
                        }
                    }
                }
                if (text.isNotEmpty() && !sheetHidden) {
                    val isText = valueType == "string" && text.toDoubleOrNull() == null
                    for (r in 0 until minOf(colRepeat, 20)) curCells.add(Cell(colNo + 1 + r, text, isText))
                }
                colNo += colRepeat
            } else {
                for (r in 0 until minOf(colRepeat, 50)) curRow.add(text)
            }
        }

        private fun endTable() {
            if (mode == M_SHEET) {
                if (!sheetHidden) sheets.add(Pair(sheetName, sheetRows))
            } else {
                val tb = tableBlocks(rows, doc.tables + 1)
                if (tb.isNotEmpty()) {
                    doc.tables++
                    for (b in tb) add(b)
                }
            }
        }

        private fun endPara() {
            val sbd = stack.removeAt(stack.size - 1)
            val lvl = levels.removeAt(levels.size - 1)
            val text = cleanText(sbd.toString())
            if (text.isEmpty()) return
            if (tblDepth > 0) {
                if (cell.isNotEmpty()) cell.append(", ")
                cell.append(text)
                return
            }
            when (mode) {
                M_TEXT -> when {
                    lvl > 0 -> { doc.headings++; add(Block(K_HEADING, lvl.coerceAtMost(6), text)) }
                    listDepth > 0 -> { doc.paragraphs++; add(Block(K_LIST, (listDepth - 1).coerceIn(0, 5), text)) }
                    else -> { doc.paragraphs++; add(Block(K_PARA, 0, text)) }
                }
                M_PRES -> {
                    val cls = frameStack.lastOrNull { it != null }
                    val sl = slide
                    when {
                        sl == null -> {}
                        inNotes -> if (cls == "notes") sl.notes.add(text)
                        cls == "title" -> sl.titleParts.add(text.replace('\n', ' '))
                        cls == "page-number" || cls == "footer" || cls == "date-time" || cls == "header" -> {}
                        listDepth > 0 -> { doc.paragraphs++; add(Block(K_LIST, (listDepth - 1).coerceIn(0, 5), text)) }
                        else -> { doc.paragraphs++; add(Block(K_PARA, 0, text)) }
                    }
                }
                else -> {}
            }
        }

        /** Menyusun hasil akhir untuk lembar kerja dan presentasi. */
        fun finish() {
            if (mode == M_SHEET) {
                val total = sheets.size
                if (total == 0) {
                    doc.blocks.add(Block(K_PARA, 0, "Buku kerja ini tidak berisi lembar yang bisa dibaca."))
                    return
                }
                for ((i, sh) in sheets.withIndex()) {
                    doc.sheets++
                    val rowsOut = sh.second
                    doc.headings++
                    doc.blocks.add(Block(K_HEADING, 1, "Lembar ${i + 1} dari $total: ${sh.first}"))
                    if (rowsOut.out.isEmpty()) {
                        doc.blocks.add(Block(K_PARA, 0, "Lembar ini kosong."))
                    } else {
                        val range = if (rowsOut.minCol == rowsOut.maxCol) "kolom ${colLetters(rowsOut.minCol)}"
                        else "kolom ${colLetters(rowsOut.minCol)} sampai ${colLetters(rowsOut.maxCol)}"
                        doc.tables++
                        doc.blocks.add(Block(K_TABLE, 0, "${rowsOut.out.size} baris berisi data, $range"))
                        for (b in rowsOut.out) {
                            if (doc.blocks.size >= MAX_BLOCKS) { doc.truncated = true; break }
                            doc.blocks.add(b)
                            doc.rows++
                        }
                    }
                    if (doc.truncated) break
                }
            } else if (mode == M_PRES) {
                val total = slides.size
                if (total == 0) {
                    doc.blocks.add(Block(K_PARA, 0, "Presentasi ini tidak berisi slide yang bisa dibaca."))
                    return
                }
                for ((i, sl) in slides.withIndex()) {
                    doc.slides++
                    val title = sl.titleParts.joinToString(" ")
                    var head = "Slide ${i + 1} dari $total"
                    if (title.isNotEmpty()) head += ": $title"
                    if (sl.hidden) head += " (tersembunyi)"
                    doc.headings++
                    doc.blocks.add(Block(K_HEADING, 1, head))
                    if (sl.blocks.isEmpty()) doc.blocks.add(Block(K_PARA, 0, "Slide ini tidak berisi teks."))
                    for (b in sl.blocks) doc.blocks.add(b)
                    if (sl.notes.isNotEmpty()) {
                        doc.blocks.add(Block(K_PARA, 0, "Catatan pembicara: " + sl.notes.joinToString("\n")))
                    }
                    if (doc.blocks.size >= MAX_BLOCKS) { doc.truncated = true; break }
                }
            }
        }
    }

    private class DocxParser(
        val doc: Doc,
        val styleLevel: Map<String, Int>,
        val listStyles: Set<String>
    ) {
        val sb = StringBuilder()
        var inT = false
        var skip = 0
        var txbx = 0
        var pStyle: String? = null
        var outline = 0
        var isList = false
        var listLevel = 0
        var pageBefore = false
        var pageInside = false
        var pendingAlt = ""

        var tblDepth = 0
        var rows = ArrayList<List<String>>()
        var curRow = ArrayList<String>()
        val cell = StringBuilder()

        fun run(ins: InputStream) {
            val p = newXmlParser()
            p.setInput(ins, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        if (skip > 0) skip++
                        else if (p.name == "mc:Fallback") skip = 1
                        else onStart(p)
                    }
                    XmlPullParser.END_TAG -> {
                        if (skip > 0) skip-- else onEnd(p.name)
                    }
                    XmlPullParser.TEXT -> if (inT && skip == 0) sb.append(p.text)
                }
                if (doc.truncated) return
                ev = p.next()
            }
        }

        fun onStart(p: XmlPullParser) {
            when (p.name) {
                "w:p" -> if (txbx == 0) {
                    sb.setLength(0)
                    pStyle = null; outline = 0; isList = false; listLevel = 0
                    pageBefore = false; pageInside = false
                }
                "w:pStyle" -> if (txbx == 0) {
                    pStyle = p.getAttributeValue(null, "w:val")
                    if (pStyle?.let { it in listStyles } == true) isList = true
                }
                "w:numId" -> if (txbx == 0) {
                    if (p.getAttributeValue(null, "w:val") == "0") isList = false else isList = true
                }
                "w:ilvl" -> if (txbx == 0) listLevel = p.getAttributeValue(null, "w:val")?.toIntOrNull() ?: 0
                "w:outlineLvl" -> if (txbx == 0) {
                    val v = p.getAttributeValue(null, "w:val")?.toIntOrNull()
                    if (v != null && v in 0..8) outline = v + 1
                }
                "w:pageBreakBefore" -> if (txbx == 0) {
                    val v = p.getAttributeValue(null, "w:val")
                    if (v != "0" && v != "false") pageBefore = true
                }
                "w:t" -> inT = true
                "w:tab" -> sb.append(' ')
                "w:br" -> {
                    if (p.getAttributeValue(null, "w:type") == "page") pageInside = true
                    else sb.append('\n')
                }
                "w:cr" -> sb.append('\n')
                "w:noBreakHyphen" -> sb.append('-')
                "w:txbxContent" -> txbx++
                "w:drawing" -> pendingAlt = ""
                "wp:docPr" -> {
                    pendingAlt = (p.getAttributeValue(null, "descr")
                        ?: p.getAttributeValue(null, "title") ?: "").trim()
                }
                "a:blip" -> addImage(pendingAlt)
                "v:imagedata" -> addImage((p.getAttributeValue(null, "o:title") ?: "").trim())
                "w:tbl" -> {
                    tblDepth++
                    if (tblDepth == 1) rows = ArrayList()
                }
                "w:tr" -> if (tblDepth == 1) curRow = ArrayList()
                "w:tc" -> if (tblDepth == 1) cell.setLength(0)
            }
        }

        fun addImage(alt: String) {
            doc.images++
            if (sb.isNotEmpty() && !sb.endsWith(" ")) sb.append(' ')
            sb.append(if (alt.isEmpty()) "[Gambar]" else "[Gambar: $alt]").append(' ')
        }

        fun onEnd(name: String) {
            when (name) {
                "w:t" -> inT = false
                "w:txbxContent" -> if (txbx > 0) txbx--
                "w:p" -> if (txbx > 0) sb.append(' ') else endParagraph()
                "w:tc" -> if (tblDepth == 1) curRow.add(cell.toString().trim())
                "w:tr" -> if (tblDepth == 1) rows.add(curRow)
                "w:tbl" -> {
                    if (tblDepth == 1) emitTable()
                    if (tblDepth > 0) tblDepth--
                }
            }
        }

        fun clean(s: String): String {
            val out = StringBuilder(s.length)
            var lastSpace = false
            for (ch in s) {
                val sp = ch == ' ' || ch == '\t' || ch == '\u00A0'
                if (sp) {
                    if (!lastSpace) out.append(' ')
                    lastSpace = true
                } else {
                    out.append(ch)
                    lastSpace = false
                }
            }
            var t = out.toString().trim()
            if (t.length > MAX_BLOCK_CHARS) t = t.substring(0, MAX_BLOCK_CHARS) + "…"
            return t
        }

        fun add(b: Block) {
            if (doc.blocks.size >= MAX_BLOCKS) {
                doc.truncated = true
                return
            }
            doc.blocks.add(b)
        }

        fun endParagraph() {
            val text = clean(sb.toString())
            if (tblDepth > 0) {
                if (text.isNotEmpty()) {
                    if (cell.isNotEmpty()) cell.append(", ")
                    cell.append(text)
                }
                return
            }
            if (pageBefore) add(Block(K_PAGE, 0, "Pemisah halaman"))
            if (text.isNotEmpty()) {
                val lvl = if (outline > 0) outline else (pStyle?.let { styleLevel[it] } ?: 0)
                when {
                    lvl > 0 -> {
                        doc.headings++
                        add(Block(K_HEADING, lvl.coerceAtMost(6), text))
                    }
                    isList -> {
                        doc.paragraphs++
                        add(Block(K_LIST, listLevel, text))
                    }
                    else -> {
                        doc.paragraphs++
                        add(Block(K_PARA, 0, text))
                    }
                }
            }
            if (pageInside) add(Block(K_PAGE, 0, "Pemisah halaman"))
            sb.setLength(0)
        }

        fun emitTable() {
            val total = rows.size
            if (rows.none { r -> r.any { it.isNotBlank() } }) return
            doc.tables++
            val cols = rows.maxOf { it.size }
            add(Block(K_TABLE, 0, "Tabel ${doc.tables}: $total baris, $cols kolom"))
            val header = rows.first { r -> r.any { it.isNotBlank() } }
            val headerIdx = rows.indexOf(header)
            val useHeader = rows.count { r -> r.any { it.isNotBlank() } } > 1 &&
                header.none { it.isBlank() } && rows.all { it.size == header.size }
            for ((i, r) in rows.withIndex()) {
                if (r.none { it.isNotBlank() }) continue
                val body = if (useHeader && i != headerIdx) {
                    r.mapIndexedNotNull { j, c -> if (c.isBlank()) null else "${header[j]}: $c" }
                        .joinToString("; ")
                } else {
                    r.filter { it.isNotBlank() }.joinToString("; ")
                }
                val label = if (useHeader && i == headerIdx) "Baris ${i + 1}, judul kolom: "
                else "Baris ${i + 1}: "
                add(Block(K_ROW, 0, label + body))
            }
        }
    }
}
