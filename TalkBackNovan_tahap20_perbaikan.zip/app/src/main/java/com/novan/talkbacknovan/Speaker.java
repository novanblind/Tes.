package com.novan.talkbacknovan;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Locale;

/** Pembungkus TextToSpeech untuk keluaran suara pembaca layar. */
public class Speaker implements TextToSpeech.OnInitListener {
    private final Context context;
    private TextToSpeech tts;
    private boolean siap;
    private boolean sudahCobaBawaan;
    private int penghitung;
    private String terakhir = "";
    private final ArrayList<Object[]> tertunda = new ArrayList<>();

    // Tahap 7 dan 8
    private final Handler utama = new Handler(Looper.getMainLooper());
    private final AudioManager audio;
    private AudioFocusRequest permintaanFokus;
    private boolean punyaFokus;
    private String idTerakhir = "";
    private boolean bisu;
    private static final AudioAttributes ATRIBUT = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build();

    public Speaker(Context c) {
        context = c.getApplicationContext();
        audio = context.getSystemService(AudioManager.class);
        mulai();
    }

    private void mulai() {
        siap = false;
        String mesin = Prefs.get(context).getString(Prefs.K_MESIN, "");
        if (TextUtils.isEmpty(mesin)) {
            tts = new TextToSpeech(context, this);
        } else {
            tts = new TextToSpeech(context, this, mesin);
        }
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) {
            String mesin = Prefs.get(context).getString(Prefs.K_MESIN, "");
            if (!sudahCobaBawaan && !TextUtils.isEmpty(mesin)) {
                // Mesin pilihan gagal dimuat, kembali ke mesin bawaan sistem.
                sudahCobaBawaan = true;
                try {
                    tts.shutdown();
                } catch (Exception ignored) {
                }
                tts = new TextToSpeech(context, this);
            }
            return;
        }
        try {
            tts.setAudioAttributes(ATRIBUT);
        } catch (Exception ignored) {
        }
        try {
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { selesaiUcap(id); }
                @Override public void onError(String id) { selesaiUcap(id); }
                @Override public void onStop(String id, boolean terputus) { selesaiUcap(id); }
            });
        } catch (Exception ignored) {
        }
        try {
            tts.setLanguage(Locale.getDefault());
        } catch (Exception ignored) {
        }
        siap = true;
        terapkanPengaturan();
        for (Object[] item : tertunda) {
            ucapkanLangsung((String) item[0], (Boolean) item[1]);
        }
        tertunda.clear();
    }

    /** Terapkan kecepatan dan nada dari pengaturan. */
    public void terapkanPengaturan() {
        if (!siap) return;
        int laju = Prefs.get(context).getInt(Prefs.K_LAJU, 100);
        int nada = Prefs.get(context).getInt(Prefs.K_NADA, 100);
        tts.setSpeechRate(laju / 100f);
        tts.setPitch(nada / 100f);
    }

    /** Muat ulang mesin TTS (dipanggil saat mesin diganti). */
    public void muatUlang() {
        stop();
        try {
            tts.shutdown();
        } catch (Exception ignored) {
        }
        sudahCobaBawaan = false;
        mulai();
    }

    public void setBisu(boolean b) {
        bisu = b;
        if (b) stop();
    }

    public boolean bisu() {
        return bisu;
    }

    public String ucapanTerakhir() {
        return terakhir;
    }

    private void selesaiUcap(final String id) {
        utama.post(new Runnable() {
            @Override
            public void run() {
                if (id != null && id.equals(idTerakhir)) lepasFokus();
            }
        });
    }

    private void ambilFokus() {
        if (punyaFokus || audio == null) return;
        if (!Prefs.get(context).getBoolean(Prefs.K_DUCK, false)) return;
        try {
            permintaanFokus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(ATRIBUT)
                    .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                        @Override
                        public void onAudioFocusChange(int perubahan) { }
                    })
                    .build();
            punyaFokus = audio.requestAudioFocus(permintaanFokus) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } catch (Exception ignored) {
        }
    }

    private void lepasFokus() {
        if (!punyaFokus || audio == null) return;
        punyaFokus = false;
        try {
            if (permintaanFokus != null) audio.abandonAudioFocusRequest(permintaanFokus);
        } catch (Exception ignored) {
        }
    }

    public void ucapkan(String teks, boolean potong) {
        if (TextUtils.isEmpty(teks) || bisu) return;
        if (Prefs.get(context).getBoolean(Prefs.K_EMOJI, true)) {
            teks = EmojiBacaan.ganti(context, teks);
            if (TextUtils.isEmpty(teks)) return;
        }
        teks = PluginManager.saatUcap(teks);
        if (TextUtils.isEmpty(teks)) return;
        if (!siap) {
            tertunda.add(new Object[]{teks, potong});
            if (tertunda.size() > 5) tertunda.remove(0);
            return;
        }
        ucapkanLangsung(teks, potong);
    }

    public boolean sedangBicara() {
        try {
            return siap && tts != null && tts.isSpeaking();
        } catch (Exception e) {
            return false;
        }
    }

    /** Ucapkan lagi kalimat yang terakhir diucapkan. */
    public void ulangi() {
        if (TextUtils.isEmpty(terakhir)) return;
        ucapkan(terakhir, true);
    }

    private void ucapkanLangsung(String teks, boolean potong) {
        terakhir = teks;
        ambilFokus();
        idTerakhir = "tbn" + (penghitung++);
        Bundle param = new Bundle();
        param.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,
                Prefs.get(context).getInt(Prefs.K_VOL_TTS, 100) / 100f);
        tts.speak(teks,
                potong ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                param, idTerakhir);
    }

    public void stop() {
        if (siap) {
            tts.stop();
        }
        lepasFokus();
    }

    public void tutup() {
        siap = false;
        lepasFokus();
        try {
            tts.stop();
            tts.shutdown();
        } catch (Exception ignored) {
        }
    }
}
