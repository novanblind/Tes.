package com.makroku.automation.engine

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ContentResolver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.view.KeyEvent
import android.accessibilityservice.AccessibilityService
import com.makroku.automation.service.MacroAccessibilityService
import com.makroku.automation.service.MacroNotificationListener
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.widget.Toast
import com.makroku.automation.MakroApp
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.adb.AdbBackend
import com.makroku.automation.model.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Placeholder teks: {var:nama}, {time}, {date}, {battery}, {sms_sender}, {sms_body}, {notif_title}, {notif_text}, {call_number}, {app_pkg}. */
object Magic {
    private val re = Regex("\\{([A-Za-z0-9_:.]+)\\}")
    fun expand(text: String, data: Map<String, String>, vars: Map<String, String>): String =
        re.replace(text) { m ->
            val k = m.groupValues[1]
            when {
                k.startsWith("var:") -> vars[k.removePrefix("var:")].orEmpty()
                k == "time" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                k == "date" -> SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                data.containsKey(k) -> data.getValue(k)
                else -> m.value
            }
        }
}

/** Stopwatch bernama di memori. Hilang bila proses aplikasi dimatikan sistem. */
object Stopwatches {
    private class State(var accum: Long = 0L, var startedAt: Long = 0L, var running: Boolean = false)
    private val map = HashMap<String, State>()

    /** Menjalankan perintah lalu mengembalikan detik berjalan. */
    @Synchronized
    fun apply(name: String, cmd: String): Long {
        val st = map.getOrPut(name) { State() }
        val now = System.currentTimeMillis()
        when (cmd) {
            "start" -> { st.accum = 0L; st.startedAt = now; st.running = true }
            "pause", "stop" -> if (st.running) { st.accum += now - st.startedAt; st.running = false }
            "resume" -> if (!st.running) { st.startedAt = now; st.running = true }
            "reset" -> { st.accum = 0L; st.running = false }
            else -> {}
        }
        val total = st.accum + (if (st.running) now - st.startedAt else 0L)
        return total / 1000L
    }
}

/** Penjaga perangkat tetap terjaga (setara aksi Keep Device Awake MacroDroid). Satu wake lock; mengaktifkan lagi menggantinya. */
@Suppress("DEPRECATION")
object AwakeKeeper {
    private var lock: PowerManager.WakeLock? = null

    @Synchronized
    fun enable(ctx: Context, screenOn: Boolean, seconds: Int) {
        release()
        val pm = ctx.applicationContext.getSystemService(PowerManager::class.java)
        val level = if (screenOn) (PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP) else PowerManager.PARTIAL_WAKE_LOCK
        val wl = pm.newWakeLock(level, "MakroKu:jaga")
        wl.setReferenceCounted(false)
        if (seconds > 0) wl.acquire(seconds.coerceAtMost(86_400) * 1000L) else wl.acquire()
        lock = wl
    }

    @Synchronized
    fun disable() {
        release()
    }

    @Synchronized
    fun isActive(): Boolean = lock?.isHeld == true

    private fun release() {
        lock?.let { if (it.isHeld) it.release() }
        lock = null
    }
}

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class ActionExecutor(private val ctx: Context, private val repo: MacroRepository) {
    private val main = Handler(Looper.getMainLooper())
    private val checker by lazy { ConstraintChecker(ctx, repo) }
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingSpeech = mutableListOf<String>()

    private class StopSignal : RuntimeException()
    private class BreakSignal : RuntimeException()
    private class ContinueSignal : RuntimeException()

    @Volatile private var sound: android.media.Ringtone? = null

    private val nest = java.util.concurrent.atomic.AtomicInteger(0)

    @Volatile private var torchOn = false
    @Volatile private var ttsRate = 1f
    @Volatile private var ttsPitch = 1f

    init {
        runCatching {
            ctx.getSystemService(CameraManager::class.java).registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
                },
                main,
            )
        }
    }

    /** Hasil akhir: bila [toggle] aktif, balik kondisi saat ini; bila tidak, pakai pilihan [enable]. */
    private inline fun want(enable: Boolean, toggle: Boolean, current: () -> Boolean): Boolean =
        if (toggle) !current() else enable

    /**
     * Rentang waktu: baca keadaan SEKARANG untuk tiap aksi yang bisa dikembalikan, lalu kembalikan daftar aksi yang
     * memulihkan keadaan itu. Aksi yang keadaannya tidak bisa dibaca dilewati. Dipanggil sebelum aksi rentang dijalankan.
     */
    suspend fun snapshotUndo(actions: List<MacroAction>): List<MacroAction> {
        val out = mutableListOf<MacroAction>()
        val seen = mutableSetOf<String>()
        for (a in actions) {
            val key = a::class.simpleName + (if (a is VolumeAction) a.stream else "")
            if (!seen.add(key)) continue
            runCatching { undoOf(a) }.getOrNull()?.let { out += it }
        }
        return out
    }

    private suspend fun undoOf(a: MacroAction): List<MacroAction> {
        val am = ctx.getSystemService(AudioManager::class.java)
        return when (a) {
            is SyncAction -> listOf(SyncAction(ContentResolver.getMasterSyncAutomatically()))
            is WifiAction -> listOf(WifiAction(ctx.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled))
            is BluetoothAction -> listOf(BluetoothAction(ctx.getSystemService(BluetoothManager::class.java).adapter?.isEnabled == true))
            is AirplaneAction -> listOf(AirplaneAction(Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1))
            is MobileDataAction -> listOf(MobileDataAction(withContext(Dispatchers.IO) { needAdb("settings get global mobile_data").trim() == "1" }))
            is NfcAction -> listOf(NfcAction(android.nfc.NfcAdapter.getDefaultAdapter(ctx)?.isEnabled ?: return emptyList()))
            is LocationAction -> listOf(LocationAction(ctx.getSystemService(android.location.LocationManager::class.java).isLocationEnabled))
            is FlashlightAction -> listOf(FlashlightAction(torchOn))
            is SpeakerphoneAction -> listOf(SpeakerphoneAction(am.isSpeakerphoneOn))
            is BatterySaverAction -> listOf(BatterySaverAction(ctx.getSystemService(PowerManager::class.java).isPowerSaveMode))
            is DataSaverAction -> listOf(DataSaverAction(withContext(Dispatchers.IO) {
                needAdb("cmd netpolicy get restrict-background").lowercase().contains("enabled")
            }))
            is AutoBrightnessAction -> listOf(AutoBrightnessAction(
                Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC,
            ))
            is BrightnessAction -> {
                val v = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
                val auto = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) ==
                    Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                buildList {
                    add(BrightnessAction((v * 100 + 254) / 255))
                    if (auto) add(AutoBrightnessAction(true))
                }
            }
            is VolumeAction -> {
                val s = streamOf(a.stream)
                val max = am.getStreamMaxVolume(s).coerceAtLeast(1)
                listOf(VolumeAction(a.stream, ((am.getStreamVolume(s) * 100 + max - 1) / max).coerceIn(0, 100)))
            }
            is RingerModeAction -> listOf(RingerModeAction(when (am.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> "silent"
                AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
                else -> "normal"
            }))
            is DndAction -> listOf(DndAction(when (ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter) {
                NotificationManager.INTERRUPTION_FILTER_NONE -> "none"
                NotificationManager.INTERRUPTION_FILTER_PRIORITY -> "priority"
                NotificationManager.INTERRUPTION_FILTER_ALARMS -> "alarms"
                else -> "all"
            }))
            is ScreenTimeoutAction -> listOf(ScreenTimeoutAction(
                (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 60_000) / 1000).coerceIn(5, 1800),
            ))
            else -> emptyList()
        }
    }

    /** Titik masuk dari mesin: aksi "Hentikan makro" hanya mengakhiri daftar aksi ini. */
    suspend fun runTop(actions: List<MacroAction>, data: Map<String, String>, macroName: String) {
        try {
            run(actions, data, macroName)
        } catch (e: StopSignal) {
            repo.log(macroName, "Makro dihentikan oleh aksi 'Hentikan makro'", true)
        } catch (e: BreakSignal) {
            repo.log(macroName, "Aksi 'Keluar dari ulangan' dipakai di luar ulangan", false)
        } catch (e: ContinueSignal) {
            repo.log(macroName, "Aksi 'Lompat ke putaran berikutnya' dipakai di luar ulangan", false)
        }
    }

    private fun adbOrNull(cmd: String): String? =
        if (!AdbBackend.dipasangkan(ctx)) null else try { AdbBackend.shell(ctx, cmd) } catch (e: Throwable) { null }

    private fun needAdb(cmd: String, batasDetik: Long = 20): String {
        if (!AdbBackend.dipasangkan(ctx)) error("Butuh ADB — pasangkan dulu di menu 'Izin via ADB'")
        return AdbBackend.shell(ctx, cmd, batasDetik)
    }

    private fun pkgOk(p: String): String {
        val x = p.trim()
        if (!Regex("[A-Za-z0-9_.]+").matches(x)) error("Nama paket tidak valid: '$p'")
        return x
    }

    /** Bungkus teks dengan tanda petik tunggal untuk shell. */
    private fun sq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun idOk(s: String, nama: String): String {
        val x = s.trim()
        if (!Regex("[A-Za-z0-9_.\$/\\-]+").matches(x)) error("$nama tidak valid: '$s'")
        return x
    }

    /** Jalur berkas yang boleh disentuh aksi shell: hanya memori internal bersama dan /data/local/tmp. */
    private fun pathOk(s: String): String {
        val x = s.trim()
        val awalOk = x == "/sdcard" || x.startsWith("/sdcard/") || x.startsWith("/storage/emulated/0/") || x.startsWith("/data/local/tmp/")
        if (!awalOk || ".." in x || '\n' in x) error("Jalur harus di /sdcard, /storage/emulated/0, atau /data/local/tmp dan tanpa '..': '$s'")
        return x
    }

    /** Paket yang tidak boleh dibekukan atau dibatasi: sistem inti, MakroKu, serta aplikasi yang sedang jadi pembaca layar atau keyboard. */
    private fun dilindungi(p: String): Boolean {
        if (p == "android" || p == ctx.packageName || p.startsWith("com.android.systemui") ||
            p == "com.android.settings" || p == "com.android.phone" || p == "com.android.server.telecom"
        ) return true
        val a11y = readSetting("secure", "enabled_accessibility_services").orEmpty()
        if (a11y.split(':').any { it.trim().startsWith("$p/") }) return true
        val ime = readSetting("secure", "default_input_method").orEmpty()
        return ime.startsWith("$p/")
    }

    /** Tulis pengaturan sistem: langsung bila ada izin, bila tidak lewat ADB. */
    private fun putSetting(ns: String, key: String, value: String) {
        val k = idOk(key, "Kunci pengaturan")
        val langsung = if (ns == "system") Settings.System.canWrite(ctx) else ElevatedPermissions.hasSecureSettings(ctx)
        if (langsung) {
            when (ns) {
                "system" -> Settings.System.putString(ctx.contentResolver, k, value)
                "secure" -> Settings.Secure.putString(ctx.contentResolver, k, value)
                else -> Settings.Global.putString(ctx.contentResolver, k, value)
            }
        } else {
            needAdb("settings put $ns $k ${sq(value)}")
        }
    }

    private fun readSetting(ns: String, key: String): String? = when (ns) {
        "system" -> Settings.System.getString(ctx.contentResolver, key)
        "secure" -> Settings.Secure.getString(ctx.contentResolver, key)
        else -> Settings.Global.getString(ctx.contentResolver, key)
    }

    /** Ukuran layar saat ini (lebar, tinggi) dari `wm size`. */
    private fun layarUkuran(): Pair<Int, Int> {
        val m = Regex("(\\d+)x(\\d+)").findAll(needAdb("wm size")).lastOrNull() ?: return Pair(1080, 2400)
        return Pair(m.groupValues[1].toInt(), m.groupValues[2].toInt())
    }

    private fun streamOf(s: String) = when (s) {
        "ring" -> AudioManager.STREAM_RING
        "alarm" -> AudioManager.STREAM_ALARM
        "notification" -> AudioManager.STREAM_NOTIFICATION
        "system" -> AudioManager.STREAM_SYSTEM
        "voice" -> AudioManager.STREAM_VOICE_CALL
        else -> AudioManager.STREAM_MUSIC
    }

    private val keyCodes = mapOf(
        "home" to 3, "back" to 4, "menu" to 82, "recents" to 187, "power" to 26, "screen_off" to 223, "screen_on" to 224,
        "volume_up" to 24, "volume_down" to 25, "mute" to 164, "play_pause" to 85, "next" to 87, "previous" to 88,
        "stop" to 86, "camera" to 27, "answer_call" to 79, "end_call" to 6, "enter" to 66, "search" to 84, "notifications" to 83,
    )

    private val settingsPanels = mapOf(
        "wifi" to Settings.ACTION_WIFI_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "internet" to Settings.Panel.ACTION_INTERNET_CONNECTIVITY, "display" to Settings.ACTION_DISPLAY_SETTINGS,
        "sound" to Settings.ACTION_SOUND_SETTINGS, "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "apps" to Settings.ACTION_APPLICATION_SETTINGS,
        "accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS, "developer" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        "date" to Settings.ACTION_DATE_SETTINGS, "nfc" to Settings.ACTION_NFC_SETTINGS,
        "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "notification_access" to Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
        "dnd" to Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, "storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
    )

    suspend fun run(actions: List<MacroAction>, data: Map<String, String>, macroName: String) {
        for (a in actions) {
            try {
                exec(a, data, macroName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: StopSignal) {
                throw e
            } catch (e: BreakSignal) {
                throw e
            } catch (e: ContinueSignal) {
                throw e
            } catch (e: Exception) {
                repo.log(macroName, "Aksi gagal (${a::class.simpleName}): ${e.message}", false)
            }
        }
    }

    private fun t(s: String, d: Map<String, String>) = Magic.expand(s, d, repo.variables.value)

    private fun hasPerm(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun startActivity(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private suspend fun exec(a: MacroAction, d: Map<String, String>, name: String) {
        when (a) {
            is OffAction -> {}

            // ───────────── Tahap 40: aksi tambahan ─────────────
            is ContactNameVarAction -> withContext(Dispatchers.IO) {
                val nomor = t(a.number, d).trim()
                if (nomor.isEmpty()) error("Nomor telepon kosong")
                if (!hasPerm(android.Manifest.permission.READ_CONTACTS)) error("Izin Kontak belum diberikan")
                val nama = ContactLookup.name(ctx, nomor)
                repo.setVariable(a.saveTo.trim().ifEmpty { "nama_kontak" }, nama.ifEmpty { nomor })
            }

            is FlashBlinkAction -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: error("Perangkat tidak punya lampu kilat")
                val n = a.count.coerceIn(1, 20)
                val nyala = a.onMs.coerceIn(50, 2000).toLong()
                val mati = a.offMs.coerceIn(50, 2000).toLong()
                try {
                    for (k in 1..n) {
                        cm.setTorchMode(id, true)
                        delay(nyala)
                        cm.setTorchMode(id, false)
                        if (k < n) delay(mati)
                    }
                } finally {
                    runCatching { cm.setTorchMode(id, false) }
                }
            }

            is WaitUntilTimeAction -> {
                val jam = a.hour.coerceIn(0, 23)
                val menit = a.minute.coerceIn(0, 59)
                val cal = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, jam)
                    set(java.util.Calendar.MINUTE, menit)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_MONTH, 1)
                val target = cal.timeInMillis
                val batas = a.maxMinutes.coerceIn(1, 30) * 60_000L
                if (target - System.currentTimeMillis() > batas) {
                    repo.log(name, "Tunggu sampai jam ${String.format(Locale.US, "%02d:%02d", jam, menit)}: lebih jauh dari batas ${batas / 60_000L} menit, makro berhenti", false)
                    throw StopSignal()
                }
                while (true) {
                    val sisa = target - System.currentTimeMillis()
                    if (sisa <= 0L) break
                    delay(minOf(sisa, 1000L))
                }
            }

            is DateMathVarAction -> {
                val cal = java.util.Calendar.getInstance()
                val bidang = when (a.dateUnit) {
                    "minute" -> java.util.Calendar.MINUTE
                    "hour" -> java.util.Calendar.HOUR_OF_DAY
                    "week" -> java.util.Calendar.WEEK_OF_YEAR
                    "month" -> java.util.Calendar.MONTH
                    "year" -> java.util.Calendar.YEAR
                    else -> java.util.Calendar.DAY_OF_MONTH
                }
                cal.add(bidang, a.amount.coerceIn(-100000, 100000))
                val teks = try {
                    SimpleDateFormat(a.format.ifBlank { "yyyy-MM-dd" }, Locale("id", "ID")).format(cal.time)
                } catch (e: IllegalArgumentException) {
                    error("Format tanggal tidak valid: ${a.format}")
                }
                repo.setVariable(a.saveTo.trim().ifBlank { "tanggal_hasil" }, teks)
            }

            // ───────────── Tahap 47: daftar ala Tasker ─────────────
            is ListOpAction -> {
                val nama = a.list.trim().ifEmpty { "daftar" }
                val r = TextTools.listOp(repo.variables.value[nama].orEmpty(), a.listOp, t(a.value, d), t(a.separator, d), a.index)
                r.items?.let { repo.setVariable(nama, it.joinToString("\n")) }
                r.out?.let { repo.setVariable(a.saveTo.trim().ifEmpty { "hasil" }, it) }
            }

            is RandomPickAction -> {
                val baris = t(a.items, d).lines().map { it.trim() }.filter { it.isNotEmpty() }
                if (baris.isEmpty()) error("Daftar pilihan kosong")
                repo.setVariable(a.saveTo.trim().ifBlank { "pilihan" }, baris.random())
            }

            // ───────────── Tahap 41: aksi tambahan ─────────────
            is SpeakDigitsAction -> {
                val teks = t(a.text, d).replace("+", " plus ")
                val dibaca = Regex("\\d").replace(teks) { " ${it.value} " }.replace(Regex("\\s+"), " ").trim()
                if (dibaca.isEmpty()) error("Teks yang diucapkan kosong")
                speak(dibaca)
            }

            is LastCallVarAction -> withContext(Dispatchers.IO) {
                if (!hasPerm(android.Manifest.permission.READ_CALL_LOG)) error("Izin Log Panggilan belum diberikan")
                val jenis = when (a.callType) {
                    "incoming" -> android.provider.CallLog.Calls.INCOMING_TYPE
                    "outgoing" -> android.provider.CallLog.Calls.OUTGOING_TYPE
                    "missed" -> android.provider.CallLog.Calls.MISSED_TYPE
                    else -> -1
                }
                val pilih = if (jenis >= 0) "${android.provider.CallLog.Calls.TYPE}=$jenis" else null
                var nomor = ""
                var nama = ""
                ctx.contentResolver.query(
                    android.provider.CallLog.Calls.CONTENT_URI,
                    arrayOf(android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.CACHED_NAME),
                    pilih, null, "${android.provider.CallLog.Calls.DATE} DESC",
                )?.use { c ->
                    if (c.moveToFirst()) {
                        nomor = c.getString(0).orEmpty()
                        nama = c.getString(1).orEmpty()
                    }
                }
                if (nama.isEmpty() && nomor.isNotEmpty()) nama = ContactLookup.name(ctx, nomor)
                repo.setVariable(a.saveTo.trim().ifEmpty { "nomor_terakhir" }, nomor)
                if (a.saveNameTo.isNotBlank()) repo.setVariable(a.saveNameTo.trim(), nama)
                if (nomor.isEmpty()) repo.log(name, "Riwayat panggilan kosong untuk jenis ini", false)
            }

            is GenerateTextAction -> {
                val set = when (a.genKind) {
                    "digits" -> "0123456789"
                    "letters" -> "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    "hex" -> "0123456789abcdef"
                    else -> "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
                }
                val acak = java.security.SecureRandom()
                val teks = buildString { repeat(a.length.coerceIn(1, 64)) { append(set[acak.nextInt(set.length)]) } }
                repo.setVariable(a.saveTo.trim().ifBlank { "teks_acak" }, teks)
            }

            is CallContactAction -> withContext(Dispatchers.IO) {
                val cari = t(a.contact, d).trim()
                if (cari.isEmpty()) error("Nama kontak kosong")
                if (!hasPerm(android.Manifest.permission.READ_CONTACTS)) error("Izin Kontak belum diberikan")
                val nomor = ContactLookup.numberOf(ctx, cari)
                if (nomor.isEmpty()) error("Kontak '$cari' tidak ditemukan")
                if (a.directCall) {
                    if (!hasPerm(android.Manifest.permission.CALL_PHONE)) error("Izin CALL_PHONE belum diberikan")
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(nomor))))
                } else {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(nomor))))
                }
            }

            is SmsContactAction -> withContext(Dispatchers.IO) {
                val cari = t(a.contact, d).trim()
                if (cari.isEmpty()) error("Nama kontak kosong")
                if (!hasPerm(android.Manifest.permission.READ_CONTACTS)) error("Izin Kontak belum diberikan")
                if (!hasPerm(android.Manifest.permission.SEND_SMS)) error("Izin SEND_SMS belum diberikan")
                val nomor = ContactLookup.numberOf(ctx, cari)
                if (nomor.isEmpty()) error("Kontak '$cari' tidak ditemukan")
                val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                val isi = t(a.text, d)
                if (isi.isEmpty()) error("Isi SMS kosong")
                sm.sendMultipartTextMessage(nomor, null, sm.divideMessage(isi), null, null)
            }

            // ───────────── Tahap 37: aksi tambahan lewat ADB bawaan ─────────────
            is SuspendAppAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                if (a.freeze && dilindungi(p)) error("Aplikasi ini dilindungi (sistem inti, MakroKu, pembaca layar, atau keyboard aktif) dan tidak boleh dibekukan")
                val out = needAdb((if (a.freeze) "pm suspend " else "pm unsuspend ") + p)
                if (out.contains("Exception") || out.contains("Error", ignoreCase = true)) error("pm: ${out.take(160)}")
            }

            is StandbyBucketAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                val b = when (a.bucket) {
                    "working_set", "frequent", "rare", "restricted" -> a.bucket
                    else -> "active"
                }
                if ((b == "rare" || b == "restricted") && dilindungi(p)) error("Aplikasi ini dilindungi dan tidak boleh dibatasi")
                val out = needAdb("am set-standby-bucket $p $b")
                if (out.contains("Exception") || out.contains("Error", ignoreCase = true)) error("am: ${out.take(160)}")
            }

            is SetHomeAppAction -> withContext(Dispatchers.IO) {
                val c = t(a.component, d).trim()
                if (!Regex("[A-Za-z0-9_.\$]+/[A-Za-z0-9_.\$]+").matches(c)) error("Isi komponen berbentuk paket/kelas")
                val out = needAdb("cmd package set-home-activity --user 0 ${sq(c)}")
                if (out.contains("Exception") || out.contains("Error", ignoreCase = true)) error("cmd: ${out.take(160)}")
            }

            is ListPackagesAction -> withContext(Dispatchers.IO) {
                val kata = t(a.contains, d).trim()
                val out = needAdb(if (a.userOnly) "pm list packages -3" else "pm list packages", 30)
                val daftar = out.lineSequence().map { it.trim() }.filter { it.startsWith("package:") }
                    .map { it.removePrefix("package:") }
                    .filter { it.isNotEmpty() && (kata.isEmpty() || it.contains(kata, ignoreCase = true)) }
                    .sorted().toList()
                val nama = a.saveTo.trim().ifBlank { "daftar_aplikasi" }
                repo.setVariable(nama, daftar.joinToString(",").take(20000))
                repo.setVariable(nama + "_jumlah", daftar.size.toString())
            }

            is ContentQueryAction -> withContext(Dispatchers.IO) {
                val uri = t(a.providerUri, d).trim()
                if (!Regex("content://[A-Za-z0-9_.@/\\-]+").matches(uri)) error("Alamat harus berbentuk content://nama/jalur, tanpa tanda lain")
                val kolom = t(a.projection, d).split(',', ':').map { it.trim() }.filter { it.isNotEmpty() }
                if (kolom.any { !Regex("[A-Za-z0-9_]+").matches(it) }) error("Nama kolom hanya huruf, angka, dan garis bawah")
                val sb = StringBuilder("content query --uri ").append(sq(uri))
                if (kolom.isNotEmpty()) sb.append(" --projection ").append(sq(kolom.joinToString(":")))
                val w = t(a.whereClause, d).trim()
                if (w.isNotEmpty()) sb.append(" --where ").append(sq(w))
                val so = t(a.sortOrder, d).trim()
                if (so.isNotEmpty()) sb.append(" --sort ").append(sq(so))
                val out = needAdb(sb.toString(), 30)
                if (out.startsWith("Error") || out.contains("Exception")) error("content: ${out.take(160)}")
                val baris = ArrayList<String>()
                for (ln in out.lines()) {
                    if (ln.startsWith("Row: ")) baris.add(ln)
                    else if (baris.isNotEmpty()) baris[baris.size - 1] = baris[baris.size - 1] + "\n" + ln
                }
                val nilai = baris.map { b ->
                    val tanpaRow = b.replaceFirst(Regex("^Row: \\d+ "), "")
                    if (kolom.size == 1) tanpaRow.removePrefix(kolom[0] + "=") else tanpaRow
                }
                val nama = a.saveTo.trim().ifBlank { "hasil_kueri" }
                repo.setVariable(nama, (nilai.firstOrNull() ?: "").take(20000))
                repo.setVariable(nama + "_jumlah", baris.size.toString())
            }

            is DataSaverAction -> withContext(Dispatchers.IO) {
                val nyala = want(a.enable, a.toggle) { needAdb("cmd netpolicy get restrict-background").lowercase().contains("enabled") }
                needAdb("cmd netpolicy set restrict-background " + if (nyala) "true" else "false")
            }

            is StayOnAction -> withContext(Dispatchers.IO) {
                val m = when (a.stayMode) {
                    "false", "usb", "ac", "wireless" -> a.stayMode
                    else -> "true"
                }
                needAdb("svc power stayon $m")
            }

            is UsbModeAction -> withContext(Dispatchers.IO) {
                val m = when (a.usbMode) {
                    "ptp", "midi", "rndis", "none" -> a.usbMode
                    else -> "mtp"
                }
                needAdb(if (m == "none") "svc usb setFunctions" else "svc usb setFunctions $m")
            }

            is TrimCachesAction -> withContext(Dispatchers.IO) {
                val mb = a.trimMb.coerceIn(100, 1_000_000)
                val out = needAdb("pm trim-caches ${mb}M", 60)
                if (out.contains("Exception") || out.contains("Error", ignoreCase = true)) error("pm: ${out.take(160)}")
            }

            is PermissionCheckAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                val izin = idOk(t(a.permission, d), "Nama izin")
                if (!AdbBackend.dipasangkan(ctx)) error("Butuh ADB — pasangkan dulu di menu 'Izin via ADB'")
                repo.setVariable(a.saveTo.trim().ifBlank { "izin_diberi" }, AdbBackend.izinDiberi(ctx, p, izin).toString())
            }

            is RamVarAction -> {
                val mi = android.app.ActivityManager.MemoryInfo()
                ctx.getSystemService(android.app.ActivityManager::class.java).getMemoryInfo(mi)
                val mb = 1024L * 1024L
                val hasil = when (a.ramInfo) {
                    "total_mb" -> (mi.totalMem / mb).toString()
                    "free_percent" -> (if (mi.totalMem > 0) mi.availMem * 100 / mi.totalMem else 0L).toString()
                    "low" -> mi.lowMemory.toString()
                    else -> (mi.availMem / mb).toString()
                }
                repo.setVariable(a.saveTo.trim().ifBlank { "ram" }, hasil)
            }

            is ThermalVarAction -> withContext(Dispatchers.IO) {
                val out = needAdb(
                    "for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done",
                    20,
                )
                val bacaan = ArrayList<Pair<String, Double>>()
                for (ln in out.lines()) {
                    val bagian = ln.trim().split(' ').filter { it.isNotEmpty() }
                    if (bagian.size < 2) continue
                    val angka = bagian.last().toLongOrNull() ?: continue
                    val c = if (angka >= 1000 || angka <= -1000) angka / 1000.0 else angka.toDouble()
                    if (c < 0.0 || c > 150.0) continue
                    bacaan.add(bagian.dropLast(1).joinToString(" ").lowercase() to c)
                }
                val cpuRe = Regex("cpu|soc|tsens|ap_|mtktscpu|big|little")
                val pilih = when (a.thermalKind) {
                    "battery" -> bacaan.filter { it.first.contains("batt") }
                    "max" -> bacaan
                    else -> bacaan.filter { cpuRe.containsMatchIn(it.first) }
                }
                val v = pilih.maxOfOrNull { it.second } ?: error("Sensor suhu yang dipilih tidak ditemukan atau tidak bisa dibaca")
                repo.setVariable(a.saveTo.trim().ifBlank { "suhu" }, String.format(Locale.US, "%.1f", v))
            }

            is LogcatVarAction -> withContext(Dispatchers.IO) {
                val n = a.lines.coerceIn(10, 1000)
                val kata = t(a.contains, d).trim()
                val out = needAdb("logcat -d -v time -t $n", 30)
                val hasil = out.lineSequence().filter { kata.isEmpty() || it.contains(kata, ignoreCase = true) }.toList().takeLast(200)
                val nama = a.saveTo.trim().ifBlank { "log_sistem" }
                repo.setVariable(nama, hasil.joinToString("\n").takeLast(20000))
                repo.setVariable(nama + "_jumlah", hasil.size.toString())
            }

            is RestartAppAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                needAdb("am force-stop $p")
                delay(a.waitSeconds.coerceIn(0, 10) * 1000L)
                val out = needAdb("monkey -p $p -c android.intent.category.LAUNCHER 1", 30)
                if (out.contains("No activities found") || out.contains("monkey aborted", ignoreCase = true)) error("Tidak bisa membuka ulang $p: ${out.take(120)}")
            }

            // ───────────── Tahap 36: aksi lewat ADB bawaan ─────────────
            is StatusBarAction -> withContext(Dispatchers.IO) {
                needAdb(
                    when (a.barCmd) {
                        "quick_settings" -> "cmd statusbar expand-settings"
                        "collapse" -> "cmd statusbar collapse"
                        else -> "cmd statusbar expand-notifications"
                    },
                )
            }

            is ClearAppDataAction -> withContext(Dispatchers.IO) {
                val out = needAdb("pm clear " + pkgOk(t(a.pkg, d)))
                if (!out.contains("Success", ignoreCase = true)) error("pm clear: ${out.take(120)}")
            }

            is PermissionAction -> withContext(Dispatchers.IO) {
                val izin = idOk(t(a.permission, d), "Nama izin")
                val out = needAdb((if (a.grant) "pm grant " else "pm revoke ") + pkgOk(t(a.pkg, d)) + " " + sq(izin))
                if (out.contains("Exception") || out.contains("Error:") || out.contains("Unknown permission")) error("pm: ${out.take(160)}")
            }

            is AppOpsAction -> withContext(Dispatchers.IO) {
                val op = idOk(t(a.appOp, d), "Nama appop")
                val mode = when (a.appopMode) {
                    "ignore", "deny", "default", "foreground" -> a.appopMode
                    else -> "allow"
                }
                needAdb("cmd appops set ${pkgOk(t(a.pkg, d))} ${sq(op)} $mode")
            }

            is BackgroundRestrictAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                val mode = if (a.allow) "allow" else "ignore"
                needAdb("cmd appops set $p RUN_ANY_IN_BACKGROUND $mode; cmd appops set $p RUN_IN_BACKGROUND $mode")
            }

            is AdbAmAction -> withContext(Dispatchers.IO) {
                val aksi = t(a.intentAction, d).trim()
                val uri = t(a.data, d).trim()
                val komp = t(a.component, d).trim()
                if (aksi.isEmpty() && uri.isEmpty() && komp.isEmpty()) error("Isi action, data, atau komponen")
                val sb = StringBuilder(
                    when (a.amKind) {
                        "broadcast" -> "am broadcast"
                        "service" -> "am start-foreground-service"
                        else -> "am start"
                    },
                )
                if (aksi.isNotEmpty()) sb.append(" -a ").append(sq(aksi))
                if (uri.isNotEmpty()) sb.append(" -d ").append(sq(uri))
                if (komp.isNotEmpty()) sb.append(" -n ").append(sq(komp))
                for (baris in t(a.extras, d).lines()) {
                    val i = baris.indexOf('=')
                    if (i <= 0) continue
                    val k = baris.substring(0, i).trim()
                    val v = baris.substring(i + 1).trim()
                    if (k.isEmpty()) continue
                    val bendera = when {
                        v.equals("true", ignoreCase = true) || v.equals("false", ignoreCase = true) -> "--ez"
                        v.toLongOrNull() != null && v.length < 10 -> "--ei"
                        else -> "--es"
                    }
                    val nilai = if (bendera == "--ez") v.lowercase() else v
                    sb.append(' ').append(bendera).append(' ').append(sq(k)).append(' ').append(sq(nilai))
                }
                val out = needAdb(sb.toString())
                if (out.contains("Error", ignoreCase = true) || out.contains("Exception")) error("am: ${out.take(160)}")
            }

            is WmAction -> withContext(Dispatchers.IO) {
                val v = t(a.wmValue, d).trim()
                when (a.wmCmd) {
                    "density" -> {
                        if (!Regex("\\d{2,4}").matches(v)) error("Kepadatan harus angka, mis. 420")
                        needAdb("wm density $v")
                    }
                    "reset" -> needAdb("wm size reset; wm density reset")
                    else -> {
                        if (!Regex("\\d{3,5}x\\d{3,5}").matches(v)) error("Ukuran harus berbentuk LEBARxTINGGI, mis. 1080x2400")
                        needAdb("wm size $v")
                    }
                }
            }

            is LongTapAction -> withContext(Dispatchers.IO) {
                needAdb("input swipe ${a.x} ${a.y} ${a.x} ${a.y} ${a.ms.coerceIn(300, 10_000)}")
            }

            is DoubleTapAction -> withContext(Dispatchers.IO) {
                needAdb("input tap ${a.x} ${a.y}; input tap ${a.x} ${a.y}")
            }

            is DragAction -> withContext(Dispatchers.IO) {
                needAdb("input draganddrop ${a.x1} ${a.y1} ${a.x2} ${a.y2} ${a.ms.coerceIn(100, 10_000)}")
            }

            is ClickTextAdbAction -> withContext(Dispatchers.IO) {
                val cari = t(a.text, d).trim()
                if (cari.isEmpty()) error("Tulisan yang dicari kosong")
                val batas = System.currentTimeMillis() + a.timeout.coerceIn(1, 60) * 1000L
                var ketemu = false
                while (true) {
                    val xml = needAdb("uiautomator dump /dev/tty 2>/dev/null", 25)
                    val p = UiXml.cari(xml, cari)
                    if (p != null) {
                        needAdb(
                            if (a.longClick) "input swipe ${p.first} ${p.second} ${p.first} ${p.second} 800"
                            else "input tap ${p.first} ${p.second}",
                        )
                        ketemu = true
                        break
                    }
                    if (System.currentTimeMillis() >= batas) break
                    delay(800)
                }
                if (!ketemu) error("Tulisan '$cari' tidak ditemukan di layar")
            }

            is ForegroundAppVarAction -> withContext(Dispatchers.IO) {
                val nama = a.saveTo.trim().ifBlank { "aplikasi_depan" }
                var pkg = ""
                var act = ""
                if (AdbBackend.dipasangkan(ctx)) {
                    val out = adbOrNull("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'").orEmpty()
                    val re = Regex("([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)")
                    val m = out.lineSequence().mapNotNull { re.find(it) }.firstOrNull()
                    if (m != null) {
                        pkg = m.groupValues[1]
                        act = m.groupValues[2]
                    }
                }
                if (pkg.isEmpty()) pkg = MacroAccessibilityService.currentPkg
                repo.setVariable(nama, pkg)
                repo.setVariable(nama + "_activity", act)
            }

            is AppInfoVarAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                val v = a.saveTo.trim().ifBlank { "info_app" }
                val hasil = when (a.appInfoKind) {
                    "installed" -> needAdb("pm path $p").contains("package:").toString()
                    "enabled" -> {
                        val terpasang = needAdb("pm path $p").contains("package:")
                        val mati = needAdb("pm list packages -d").lineSequence().any { it.trim() == "package:$p" }
                        (terpasang && !mati).toString()
                    }
                    "running" -> needAdb("pidof $p").isNotBlank().toString()
                    "path" -> needAdb("pm path $p").lineSequence().firstOrNull().orEmpty().removePrefix("package:")
                    else -> needAdb("dumpsys package $p | grep -m1 versionName").substringAfter("versionName=", "").trim()
                }
                repo.setVariable(v, hasil)
            }

            is GetPropAction -> withContext(Dispatchers.IO) {
                val k = idOk(t(a.prop, d), "Nama properti")
                repo.setVariable(a.saveTo.trim().ifBlank { "properti" }, needAdb("getprop ${sq(k)}"))
            }

            is GetSettingAction -> {
                val ns = when (a.ns) {
                    "system", "secure" -> a.ns
                    else -> "global"
                }
                val k = t(a.key, d).trim()
                if (k.isEmpty()) error("Kunci pengaturan kosong")
                repo.setVariable(a.saveTo.trim().ifBlank { "pengaturan" }, readSetting(ns, k).orEmpty())
            }

            is DozeWhitelistAction -> withContext(Dispatchers.IO) {
                needAdb("dumpsys deviceidle whitelist " + (if (a.add) "+" else "-") + pkgOk(t(a.pkg, d)))
            }

            is UnlockPinAction -> withContext(Dispatchers.IO) {
                val pin = t(a.pin, d).trim()
                if (pin.isEmpty() || !pin.all { it.isLetterOrDigit() }) error("PIN kosong atau berisi karakter selain huruf dan angka")
                val (w, h) = layarUkuran()
                needAdb("input keyevent 224")
                delay(700)
                needAdb("input swipe ${w / 2} ${h * 4 / 5} ${w / 2} ${h / 4} 300")
                delay(700)
                needAdb("input text $pin")
                delay(300)
                needAdb("input keyevent 66")
            }

            is InstallApkAction -> withContext(Dispatchers.IO) {
                val f = pathOk(t(a.apkPath, d))
                if (!f.endsWith(".apk", ignoreCase = true)) error("Berkas harus berakhiran .apk")
                val out = needAdb("pm install -r ${sq(f)}", 180)
                if (!out.contains("Success")) error("pm install: ${out.take(200)}")
                repo.log(name, "APK terpasang: $f", true)
            }

            is SilentUninstallAction -> withContext(Dispatchers.IO) {
                val out = needAdb("pm uninstall " + (if (a.keepData) "-k " else "") + pkgOk(t(a.pkg, d)), 60)
                if (!out.contains("Success")) error("pm uninstall: ${out.take(160)}")
            }

            is ShellFileAction -> withContext(Dispatchers.IO) {
                val s = pathOk(t(a.src, d))
                val v = a.saveTo.trim().ifBlank { "hasil_berkas" }
                fun tujuan() = pathOk(t(a.dst, d))
                when (a.shellFileOp) {
                    "copy" -> needAdb("cp -r ${sq(s)} ${sq(tujuan())}", 120)
                    "move" -> needAdb("mv ${sq(s)} ${sq(tujuan())}", 120)
                    "delete" -> {
                        if (s.trimEnd('/') in listOf("/sdcard", "/storage/emulated/0", "/data/local/tmp")) error("Menghapus folder induk tidak diizinkan")
                        needAdb("rm -rf ${sq(s)}", 120)
                    }
                    "mkdir" -> needAdb("mkdir -p ${sq(s)}")
                    "exists" -> repo.setVariable(v, (needAdb("[ -e ${sq(s)} ] && echo yes || echo no").trim() == "yes").toString())
                    "size" -> repo.setVariable(v, needAdb("stat -c %s ${sq(s)} 2>/dev/null || echo -1").trim())
                    "list" -> repo.setVariable(v, needAdb("ls -1 ${sq(s)}").take(20000))
                    "read" -> repo.setVariable(v, needAdb("cat ${sq(s)}", 30).take(20000))
                    else -> error("Operasi berkas tidak dikenal")
                }
                Unit
            }

            is WifiConnectAction -> withContext(Dispatchers.IO) {
                val ssid = t(a.netName, d).trim()
                if (ssid.isEmpty()) error("Nama jaringan kosong")
                val sandi = t(a.netPassword, d)
                val sec = when (a.wifiSec) {
                    "open", "owe", "wpa3" -> a.wifiSec
                    else -> "wpa2"
                }
                val perintah = "cmd wifi connect-network ${sq(ssid)} $sec" + (if (sec == "open" || sec == "owe") "" else " ${sq(sandi)}")
                val out = needAdb(perintah, 30)
                repo.log(name, "Wi-Fi: ${out.take(120).ifBlank { "perintah dikirim" }}", true)
                if (out.contains("Unknown", ignoreCase = true) || out.contains("Exception")) error("cmd wifi: ${out.take(160)}")
            }

            is HotspotAction -> withContext(Dispatchers.IO) {
                val out = if (a.enable) {
                    val ssid = t(a.netName, d).trim().ifBlank { "MakroKu" }
                    val sandi = t(a.netPassword, d)
                    if (sandi.length < 8) error("Kata sandi hotspot minimal 8 karakter")
                    needAdb("cmd wifi start-softap ${sq(ssid)} wpa2 ${sq(sandi)}", 30)
                } else {
                    needAdb("cmd wifi stop-softap", 30)
                }
                if (out.contains("Unknown", ignoreCase = true) || out.contains("Exception")) error("Perangkat ini tidak mendukung hotspot lewat cmd wifi: ${out.take(120)}")
            }

            is PrivateDnsAction -> withContext(Dispatchers.IO) {
                when (a.dnsMode) {
                    "off" -> putSetting("global", "private_dns_mode", "off")
                    "auto" -> putSetting("global", "private_dns_mode", "opportunistic")
                    else -> {
                        val h = t(a.dnsHost, d).trim()
                        if (h.isEmpty() || !Regex("[A-Za-z0-9.-]+").matches(h)) error("Nama host DNS tidak valid")
                        putSetting("global", "private_dns_specifier", h)
                        putSetting("global", "private_dns_mode", "hostname")
                    }
                }
            }

            is AnimationScaleAction -> withContext(Dispatchers.IO) {
                val v = String.format(Locale.US, "%.2f", a.scalePercent.coerceIn(0, 1000) / 100f)
                for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) putSetting("global", k, v)
            }

            is ImeSetAction -> withContext(Dispatchers.IO) {
                val id = t(a.imeId, d).trim()
                if (!Regex("[A-Za-z0-9_.\$/]+").matches(id) || '/' !in id) error("Isi ID keyboard berbentuk paket/kelas, mis. com.paket/.Layanan")
                needAdb("ime enable ${sq(id)}; ime set ${sq(id)}")
            }

            is A11yServiceAction -> withContext(Dispatchers.IO) {
                val komp = t(a.component, d).trim()
                if (!Regex("[A-Za-z0-9_.\$]+/[A-Za-z0-9_.\$]+").matches(komp)) error("Isi komponen berbentuk paket/kelas")
                fun norm(s: String): String {
                    val p = s.substringBefore('/')
                    val c = s.substringAfter('/', "")
                    return (p + "/" + (if (c.startsWith(".")) p + c else c)).lowercase()
                }
                val sekarang = readSetting("secure", "enabled_accessibility_services").orEmpty()
                    .split(':').map { it.trim() }.filter { it.isNotEmpty() && it != "null" }
                val baru = if (a.enable) (sekarang + komp).distinctBy { norm(it) }
                else sekarang.filter { norm(it) != norm(komp) }
                if (!a.enable && baru.isEmpty()) error("Tidak diizinkan mematikan layanan Aksesibilitas terakhir, supaya pembaca layar tidak hilang")
                putSetting("secure", "enabled_accessibility_services", baru.joinToString(":"))
                if (a.enable) putSetting("secure", "accessibility_enabled", "1")
            }

            is TtsEngineAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                putSetting("secure", "tts_default_synth", p)
                if (a.ttsRate > 0) putSetting("secure", "tts_default_rate", a.ttsRate.coerceIn(10, 500).toString())
            }

            is NoteAction -> {}

            is DateTimeVarAction -> {
                val teks = try {
                    SimpleDateFormat(a.format.ifBlank { "yyyy-MM-dd HH:mm" }, Locale("id", "ID")).format(java.util.Date())
                } catch (e: IllegalArgumentException) {
                    error("Format tanggal tidak valid: ${a.format}")
                }
                repo.setVariable(a.saveTo.trim().ifBlank { "waktu" }, teks)
            }

            is BatteryVarAction -> repo.setVariable(a.saveTo.trim().ifBlank { "baterai" }, checker.batteryLevel().toString())

            is BeepAction -> {
                val tg = android.media.ToneGenerator(AudioManager.STREAM_MUSIC, 100)
                try {
                    val ms = a.ms.coerceIn(50, 3000).toInt()
                    tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, ms)
                    kotlinx.coroutines.delay(ms.toLong() + 100)
                } finally {
                    tg.release()
                }
            }

            is ReadFileAction -> withContext(Dispatchers.IO) {
                val fn = a.fileName.trim()
                if (fn.isEmpty() || '/' in fn || '\\' in fn || ".." in fn) error("Nama berkas tidak valid")
                val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, fn)
                if (!f.exists()) error("Berkas '$fn' belum ada")
                repo.setVariable(a.saveTo.trim().ifBlank { "isi_berkas" }, f.readText().take(20000))
            }

            is ReplyNotificationAction -> {
                val l = MacroNotificationListener.instance ?: error("Akses Notifikasi belum aktif")
                val p = t(a.pkg, d).trim().ifBlank { d["notif_pkg"].orEmpty() }
                if (p.isEmpty()) error("Isi nama paket aplikasi, atau pakai pemicu Notifikasi")
                fun bisaDibalas(n: android.service.notification.StatusBarNotification) =
                    n.notification.actions?.any { !it.remoteInputs.isNullOrEmpty() } == true
                // Utamakan notifikasi pemicu itu sendiri (kunci sama) supaya balasan masuk ke obrolan yang benar.
                val kunci = d["notif_key"].orEmpty()
                val sbn = (if (a.pkg.isBlank() && kunci.isNotEmpty()) l.activeNotifications.firstOrNull { it.key == kunci && bisaDibalas(it) } else null)
                    ?: l.activeNotifications.filter { it.packageName == p }.sortedByDescending { it.postTime }.firstOrNull { bisaDibalas(it) }
                    ?: error("Tidak ada notifikasi $p yang bisa dibalas")
                val act = sbn.notification.actions.first { !it.remoteInputs.isNullOrEmpty() }
                val ri = act.remoteInputs
                val bundle = android.os.Bundle()
                val isi = t(a.text, d)
                ri.forEach { bundle.putCharSequence(it.resultKey, isi) }
                val intent = Intent()
                android.app.RemoteInput.addResultsToIntent(ri, intent, bundle)
                try {
                    act.actionIntent.send(ctx, 0, intent)
                } catch (e: android.app.PendingIntent.CanceledException) {
                    error("Balasan dibatalkan oleh aplikasi $p")
                }
            }

            is TapNotificationAction -> {
                val l = MacroNotificationListener.instance ?: error("Akses Notifikasi belum aktif")
                val p = t(a.pkg, d).trim().ifBlank { d["notif_pkg"].orEmpty() }
                val sbn = l.activeNotifications.filter { it.packageName == p }.maxByOrNull { it.postTime }
                    ?: error("Tidak ada notifikasi dari '$p'")
                val pi = sbn.notification.contentIntent ?: error("Notifikasi ini tidak bisa diketuk")
                try { pi.send() } catch (e: android.app.PendingIntent.CanceledException) { error("Ketukan dibatalkan oleh aplikasi") }
            }

            is NotifToVarAction -> {
                val l = MacroNotificationListener.instance ?: error("Akses Notifikasi belum aktif")
                val p = t(a.pkg, d).trim().ifBlank { d["notif_pkg"].orEmpty() }
                val sbn = l.activeNotifications.filter { it.packageName == p }.maxByOrNull { it.postTime }
                val ex = sbn?.notification?.extras
                val judul = ex?.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
                val isi = ex?.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
                repo.setVariable(
                    a.saveTo.trim().ifBlank { "notifikasi" },
                    when (a.notifPart) { "title" -> judul; "both" -> "$judul. $isi"; else -> isi },
                )
            }

            is PopupAction -> {
                if (!Settings.canDrawOverlays(ctx)) error("Butuh izin 'Tampil di atas aplikasi lain'")
                ctx.startActivity(
                    Intent(ctx, com.makroku.automation.ui.PopupActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("title", t(a.title, d))
                        .putExtra("text", t(a.text, d))
                        .putExtra("seconds", a.seconds.coerceIn(0, 600)),
                )
            }

            is SetRingtoneAction -> {
                if (!Settings.System.canWrite(ctx)) error("Butuh izin 'Ubah pengaturan sistem'")
                val tipe = when (a.ringKind) {
                    "notification" -> RingtoneManager.TYPE_NOTIFICATION
                    "alarm" -> RingtoneManager.TYPE_ALARM
                    else -> RingtoneManager.TYPE_RINGTONE
                }
                val u = t(a.uri, d).trim()
                RingtoneManager.setActualDefaultRingtoneUri(ctx, tipe, if (u.isEmpty()) null else Uri.parse(u))
            }

            is SetWallpaperAction -> withContext(Dispatchers.IO) {
                val fn = a.fileName.trim()
                if (fn.isEmpty() || '/' in fn || '\\' in fn || ".." in fn) error("Nama berkas tidak valid")
                val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, fn)
                if (!f.exists()) error("Berkas '$fn' belum ada di folder data aplikasi")
                val bmp = android.graphics.BitmapFactory.decodeFile(f.path) ?: error("Berkas bukan gambar yang valid")
                val flag = when (a.wallTarget) {
                    "lock" -> android.app.WallpaperManager.FLAG_LOCK
                    "both" -> android.app.WallpaperManager.FLAG_SYSTEM or android.app.WallpaperManager.FLAG_LOCK
                    else -> android.app.WallpaperManager.FLAG_SYSTEM
                }
                android.app.WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, flag)
            }

            is DeleteFileAction -> withContext(Dispatchers.IO) {
                val fn = a.fileName.trim()
                if (fn.isEmpty() || '/' in fn || '\\' in fn || ".." in fn) error("Nama berkas tidak valid")
                val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, fn)
                if (f.exists() && !f.delete()) error("Berkas '$fn' gagal dihapus")
            }

            is StorageVarAction -> {
                val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
                repo.setVariable(a.saveTo.trim().ifBlank { "ruang_kosong_mb" }, (st.availableBytes / (1024 * 1024)).toString())
            }

            is VolumeVarAction -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val stream = when (a.stream) {
                    "ring" -> AudioManager.STREAM_RING
                    "alarm" -> AudioManager.STREAM_ALARM
                    "notification" -> AudioManager.STREAM_NOTIFICATION
                    "system" -> AudioManager.STREAM_SYSTEM
                    "voice" -> AudioManager.STREAM_VOICE_CALL
                    else -> AudioManager.STREAM_MUSIC
                }
                val mx = am.getStreamMaxVolume(stream).coerceAtLeast(1)
                repo.setVariable(a.saveTo.trim().ifBlank { "volume" }, (am.getStreamVolume(stream) * 100 / mx).toString())
            }

            is BatteryInfoVarAction -> {
                val i = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    ?: error("Info baterai tidak tersedia")
                val nilai = when (a.info) {
                    "voltage" -> i.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, 0).toString()
                    "status" -> when (i.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)) {
                        android.os.BatteryManager.BATTERY_STATUS_CHARGING -> "mengisi"
                        android.os.BatteryManager.BATTERY_STATUS_DISCHARGING -> "tidak mengisi"
                        android.os.BatteryManager.BATTERY_STATUS_FULL -> "penuh"
                        android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "tidak diisi"
                        else -> "tidak diketahui"
                    }
                    "health" -> when (i.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, -1)) {
                        android.os.BatteryManager.BATTERY_HEALTH_GOOD -> "baik"
                        android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT -> "terlalu panas"
                        android.os.BatteryManager.BATTERY_HEALTH_DEAD -> "rusak"
                        android.os.BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "tegangan berlebih"
                        android.os.BatteryManager.BATTERY_HEALTH_COLD -> "terlalu dingin"
                        else -> "tidak diketahui"
                    }
                    "plug" -> when (i.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)) {
                        0 -> "tidak dicolok"
                        android.os.BatteryManager.BATTERY_PLUGGED_AC -> "adaptor dinding"
                        android.os.BatteryManager.BATTERY_PLUGGED_USB -> "usb"
                        android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS -> "nirkabel"
                        else -> "lain"
                    }
                    else -> (i.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0).toString()
                }
                repo.setVariable(a.saveTo.trim().ifBlank { "info_baterai" }, nilai)
            }

            is RunBlockAction -> {
                val depth = d["_block_depth"]?.toIntOrNull() ?: 0
                if (depth >= 8) error("Blok aksi bersarang terlalu dalam, mungkin saling memanggil")
                val b = repo.blocks.value.firstOrNull { it.name.equals(a.block.trim(), ignoreCase = true) }
                    ?: error("Blok aksi '${a.block}' tidak ditemukan")
                run(b.actions, d + ("_block_depth" to (depth + 1).toString()), name)
            }

            is ToastAction -> main.post { Toast.makeText(ctx, t(a.text, d), Toast.LENGTH_LONG).show() }

            is NotificationAction -> {
                val nid = (System.currentTimeMillis() and 0x3fffffffL).toInt()
                val b = Notification.Builder(ctx, MakroApp.CHANNEL_ACTIONS)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(t(a.title, d))
                    .setContentText(t(a.text, d))
                    .setAutoCancel(true)
                listOf(a.button1, a.button2).map { t(it, d).trim() }.filter { it.isNotEmpty() }.forEachIndexed { idx, label ->
                    val pi = android.app.PendingIntent.getBroadcast(
                        ctx, nid + idx + 1,
                        Intent(ctx, com.makroku.automation.service.NotifButtonReceiver::class.java)
                            .putExtra("label", label).putExtra("nid", nid),
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
                    )
                    b.addAction(
                        Notification.Action.Builder(
                            android.graphics.drawable.Icon.createWithResource(ctx, android.R.drawable.ic_menu_send), label, pi,
                        ).build(),
                    )
                }
                ctx.getSystemService(NotificationManager::class.java).notify(nid, b.build())
            }

            is VibrateAction -> {
                val v: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                    ctx.getSystemService(VibratorManager::class.java).defaultVibrator
                else ctx.getSystemService(Vibrator::class.java)
                v.vibrate(VibrationEffect.createOneShot(a.ms.coerceIn(1, 10_000), VibrationEffect.DEFAULT_AMPLITUDE))
            }

            is LaunchAppAction -> {
                val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
                    ?: error("Aplikasi ${a.pkg} tidak ditemukan")
                startActivity(i)
            }

            is OpenUrlAction -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t(a.url, d))))

            is WifiAction -> {
                val on = want(a.enable, a.toggle) { ctx.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled }
                val viaAdb = withContext(Dispatchers.IO) { adbOrNull("svc wifi " + if (on) "enable" else "disable") }
                if (viaAdb != null) {
                    // selesai lewat ADB
                } else if (Build.VERSION.SDK_INT >= 29) {
                    // Android 10+ melarang aplikasi biasa mengubah Wi-Fi: tampilkan panel sistem.
                    startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                } else {
                    ctx.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled = on
                }
            }

            is BluetoothAction -> {
                val on = want(a.enable, a.toggle) { ctx.getSystemService(BluetoothManager::class.java).adapter?.isEnabled == true }
                val viaAdb = withContext(Dispatchers.IO) { adbOrNull("svc bluetooth " + if (on) "enable" else "disable") }
                if (viaAdb != null) return
                val ad = ctx.getSystemService(BluetoothManager::class.java).adapter ?: error("Tidak ada Bluetooth")
                val ok = if (on) ad.enable() else ad.disable()
                if (!ok) repo.log(name, "Bluetooth: sistem menolak perubahan (batasan Android 13+)", false)
            }

            is VolumeAction -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val stream = when (a.stream) {
                    "ring" -> AudioManager.STREAM_RING
                    "alarm" -> AudioManager.STREAM_ALARM
                    "notification" -> AudioManager.STREAM_NOTIFICATION
                    "system" -> AudioManager.STREAM_SYSTEM
                    "voice" -> AudioManager.STREAM_VOICE_CALL
                    else -> AudioManager.STREAM_MUSIC
                }
                am.setStreamVolume(stream, am.getStreamMaxVolume(stream) * a.percent.coerceIn(0, 100) / 100, 0)
            }

            is RingerModeAction -> {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (a.ringerMode == "silent" && !nm.isNotificationPolicyAccessGranted)
                    error("Butuh akses 'Jangan ganggu' untuk mode senyap")
                ctx.getSystemService(AudioManager::class.java).ringerMode = when (a.ringerMode) {
                    "silent" -> AudioManager.RINGER_MODE_SILENT
                    "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
            }

            is DndAction -> {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (!nm.isNotificationPolicyAccessGranted) error("Butuh akses 'Jangan ganggu'")
                nm.setInterruptionFilter(
                    when (a.dndMode) {
                        "priority" -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        "alarms" -> NotificationManager.INTERRUPTION_FILTER_ALARMS
                        "none" -> NotificationManager.INTERRUPTION_FILTER_NONE
                        else -> NotificationManager.INTERRUPTION_FILTER_ALL
                    },
                )
            }

            is FlashlightAction -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: error("Perangkat tidak punya lampu kilat")
                cm.setTorchMode(id, want(a.on, a.toggle) { torchOn })
            }

            is SendSmsAction -> {
                if (!hasPerm(android.Manifest.permission.SEND_SMS)) error("Izin SEND_SMS belum diberikan")
                val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                val body = t(a.text, d)
                sm.sendMultipartTextMessage(t(a.number, d), null, sm.divideMessage(body), null, null)
            }

            is CallAction -> {
                if (!hasPerm(android.Manifest.permission.CALL_PHONE)) error("Izin CALL_PHONE belum diberikan")
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + t(a.number, d))))
            }

            is SpeakAction -> speak(t(a.text, d))

            is PlaySoundAction -> {
                val uri = if (a.uri.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(a.uri)
                sound?.stop()
                val r = RingtoneManager.getRingtone(ctx, uri)
                sound = r
                r?.play()
            }

            is ClipboardAction -> main.post {
                ctx.getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("MakroKu", t(a.text, d)))
            }

            is BrightnessAction -> {
                if (!Settings.System.canWrite(ctx)) error("Butuh izin 'Ubah pengaturan sistem'")
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, a.percent.coerceIn(0, 100) * 255 / 100)
            }

            is DelayAction -> delay(a.seconds.coerceAtLeast(0) * 1000)

            is SetVariableAction -> {
                val cur = repo.variables.value[a.name].orEmpty()
                val v = t(a.value, d)
                fun angka(x: Double) = if (x % 1.0 == 0.0 && Math.abs(x) < 9.0e15) x.toLong().toString() else x.toString()
                val x = cur.trim().toDoubleOrNull() ?: 0.0
                val y = v.trim().toDoubleOrNull() ?: 0.0
                when (a.op) {
                    "add" -> repo.setVariable(a.name, angka(x + y))
                    "subtract" -> repo.setVariable(a.name, angka(x - y))
                    "multiply" -> repo.setVariable(a.name, angka(x * y))
                    "divide" -> {
                        if (y == 0.0) error("Tidak bisa membagi dengan nol")
                        repo.setVariable(a.name, angka(x / y))
                    }
                    "modulo" -> {
                        if (y == 0.0) error("Tidak bisa membagi dengan nol")
                        repo.setVariable(a.name, angka(x % y))
                    }
                    "toggle" -> repo.setVariable(
                        a.name,
                        if (cur.trim().lowercase() in listOf("true", "1", "ya", "benar", "on")) "false" else "true",
                    )
                    "prepend" -> repo.setVariable(a.name, v + cur)
                    "swap_case" -> repo.setVariable(a.name, cur.map { if (it.isUpperCase()) it.lowercaseChar() else it.uppercaseChar() }.joinToString(""))
                    "append" -> repo.setVariable(a.name, cur + v)
                    "delete" -> repo.deleteVariable(a.name)
                    else -> repo.setVariable(a.name, v)
                }
            }

            is HttpRequestAction -> withContext(Dispatchers.IO) {
                val c = URL(t(a.url, d)).openConnection() as HttpURLConnection
                try {
                    c.requestMethod = a.method
                    val batas = a.timeout.coerceIn(1, 600) * 1000
                    c.connectTimeout = batas
                    c.readTimeout = batas
                    a.headers.lines().map { t(it, d) }.filter { it.contains(":") }.forEach { h ->
                        c.setRequestProperty(h.substringBefore(":").trim(), h.substringAfter(":").trim())
                    }
                    if (a.body.isNotEmpty() && a.method != "GET") {
                        c.doOutput = true
                        c.outputStream.use { it.write(t(a.body, d).toByteArray()) }
                    }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    repo.setVariable("http_code", code.toString())
                    repo.setVariable("http_response", text.take(20000))
                    if (a.saveTo.isNotBlank()) repo.setVariable(a.saveTo.trim(), text.take(20000))
                } finally {
                    c.disconnect()
                }
            }

            is IntentAction -> {
                val aksi = t(a.action, d).trim()
                val i = if (aksi.isEmpty()) Intent() else Intent(aksi)
                if (a.data.isNotBlank()) i.data = Uri.parse(t(a.data, d))
                val paket = t(a.pkg, d).trim()
                val kelas = t(a.cls, d).trim()
                if (paket.isNotEmpty() && kelas.isNotEmpty()) i.setClassName(paket, kelas)
                else if (paket.isNotEmpty()) i.setPackage(paket)
                if (a.asActivity) startActivity(i) else ctx.sendBroadcast(i)
            }

            is SystemSettingAction -> withContext(Dispatchers.IO) {
                val k = t(a.key, d)
                val v = t(a.value, d)
                if (k.isBlank()) error("Kunci pengaturan kosong")
                if (a.ns != "system" && a.ns != "secure" && a.ns != "global") error("Namespace tidak dikenal: ${a.ns}")
                // Izin langsung bila ada; bila tidak, lewat ADB bawaan.
                putSetting(a.ns, k, v)
            }

            is AdbShellAction -> withContext(Dispatchers.IO) {
                val cmd = t(a.command, d).trim()
                if (cmd.isBlank()) error("Perintah shell kosong")
                val out = AdbBackend.shell(ctx, cmd)
                if (a.saveTo.isNotBlank()) repo.setVariable(a.saveTo.trim(), out.take(4000))
                repo.log(name, "ADB: $cmd → ${out.take(120).ifBlank { "(tanpa keluaran)" }}", true)
            }

            is MobileDataAction -> withContext(Dispatchers.IO) {
                val on = want(a.enable, a.toggle) { needAdb("settings get global mobile_data").trim() == "1" }
                needAdb("svc data " + if (on) "enable" else "disable")
            }
            is AirplaneAction -> withContext(Dispatchers.IO) {
                val on = want(a.enable, a.toggle) { Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 }
                needAdb("cmd connectivity airplane-mode " + if (on) "enable" else "disable")
            }
            is NfcAction -> withContext(Dispatchers.IO) {
                val on = want(a.enable, a.toggle) { android.nfc.NfcAdapter.getDefaultAdapter(ctx)?.isEnabled == true }
                needAdb("svc nfc " + if (on) "enable" else "disable")
            }
            is LocationAction -> {
                val on = want(a.enable, a.toggle) { ctx.getSystemService(android.location.LocationManager::class.java).isLocationEnabled }
                if (ElevatedPermissions.hasSecureSettings(ctx)) {
                    Settings.Secure.putInt(ctx.contentResolver, "location_mode", if (on) 3 else 0)
                } else withContext(Dispatchers.IO) { needAdb("cmd location set-location-enabled $on") }
            }
            is ForceStopAction -> withContext(Dispatchers.IO) { needAdb("am force-stop ${pkgOk(t(a.pkg, d))}") }
            is AppEnableAction -> withContext(Dispatchers.IO) {
                val p = pkgOk(t(a.pkg, d))
                needAdb(if (a.enable) "pm enable $p" else "pm disable-user --user 0 $p")
            }
            is TapAction -> withContext(Dispatchers.IO) { needAdb("input tap ${a.x} ${a.y}") }
            is SwipeAction -> withContext(Dispatchers.IO) {
                needAdb("input swipe ${a.x1} ${a.y1} ${a.x2} ${a.y2} ${a.ms.coerceIn(50, 10_000)}")
            }
            is KeyEventAction -> withContext(Dispatchers.IO) {
                val code = keyCodes[a.keyName] ?: error("Tombol tidak dikenal: ${a.keyName}")
                needAdb("input keyevent $code")
            }
            is TypeTextAction -> withContext(Dispatchers.IO) {
                val txt = t(a.text, d).replace("'", "'\\''").replace(" ", "%s")
                needAdb("input text '$txt'")
            }
            is ScreenshotAction -> withContext(Dispatchers.IO) {
                val folder = a.folder.trim().trimEnd('/')
                if (folder.isEmpty() || '\'' in folder) error("Folder tidak valid")
                val f = "$folder/Makro_${System.currentTimeMillis()}.png"
                needAdb("screencap -p '$f'")
                repo.log(name, "Tangkapan layar disimpan: $f", true)
            }
            is GlobalAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                val g = when (a.globalAct) {
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                    "power_menu" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                    "lock_screen" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
                    "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                    else -> AccessibilityService.GLOBAL_ACTION_BACK
                }
                if (!svc.performGlobalAction(g)) error("Sistem menolak aksi ${a.globalAct}")
            }
            is MediaControlAction -> {
                val code = when (a.mediaCmd) {
                    "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = ctx.getSystemService(AudioManager::class.java)
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            }
            is VolumeStepAction -> {
                val dir = when (a.volDir) {
                    "down" -> AudioManager.ADJUST_LOWER
                    "mute" -> AudioManager.ADJUST_MUTE
                    "unmute" -> AudioManager.ADJUST_UNMUTE
                    "toggle_mute" -> AudioManager.ADJUST_TOGGLE_MUTE
                    else -> AudioManager.ADJUST_RAISE
                }
                ctx.getSystemService(AudioManager::class.java).adjustStreamVolume(streamOf(a.stream), dir, 0)
            }
            is SpeakerphoneAction -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                am.isSpeakerphoneOn = want(a.on, a.toggle) { am.isSpeakerphoneOn }
            }
            is MicMuteAction -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                am.isMicrophoneMute = want(a.mute, a.toggle) { am.isMicrophoneMute }
            }
            is ScreenOnAction -> {
                val pm = ctx.getSystemService(PowerManager::class.java)
                val wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "MakroKu:layar",
                )
                wl.acquire(a.seconds.coerceIn(1, 600) * 1000L)
            }
            is RotationAction -> {
                if (!Settings.System.canWrite(ctx)) error("Butuh izin 'Ubah pengaturan sistem'")
                val cr = ctx.contentResolver
                if (a.rotation == "auto") {
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1)
                } else {
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                    Settings.System.putInt(cr, Settings.System.USER_ROTATION, if (a.rotation == "landscape") 1 else 0)
                }
            }
            is ScreenTimeoutAction -> {
                if (!Settings.System.canWrite(ctx)) error("Butuh izin 'Ubah pengaturan sistem'")
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, a.seconds.coerceIn(5, 1800) * 1000)
            }
            is OpenSettingsAction -> startActivity(Intent(settingsPanels[a.panel] ?: Settings.ACTION_SETTINGS))
            is SetAlarmAction -> startActivity(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.hour.coerceIn(0, 23))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.minute.coerceIn(0, 59))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, t(a.text, d))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            )
            is SetTimerAction -> startActivity(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.seconds.coerceIn(1, 86_400))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, t(a.text, d))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            )
            is EmailAction -> startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                    .putExtra(Intent.EXTRA_EMAIL, arrayOf(t(a.to, d)))
                    .putExtra(Intent.EXTRA_SUBJECT, t(a.subject, d))
                    .putExtra(Intent.EXTRA_TEXT, t(a.body, d)),
            )
            is ClearNotificationsAction -> {
                val l = MacroNotificationListener.instance ?: error("Akses Notifikasi belum aktif")
                val p = t(a.pkg, d).split(',').map { it.trim() }.filter { it.isNotEmpty() }
                val judul = t(a.titleContains, d).trim()
                if (p.isEmpty() && judul.isEmpty()) l.cancelAllNotifications()
                else l.activeNotifications.filter { sbn ->
                    (p.isEmpty() || sbn.packageName in p) && (judul.isEmpty() ||
                        sbn.notification.extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
                            .contains(judul, ignoreCase = true))
                }.forEach { l.cancelNotification(it.key) }
            }
            is LoopAction -> {
                var n = 0
                val total = a.times.coerceIn(1, 1000)
                while (n < total) {
                    n++
                    try {
                        run(a.actions, d, name)
                    } catch (e: ContinueSignal) {
                        // lanjut ke putaran berikutnya
                    } catch (e: BreakSignal) {
                        break
                    }
                }
            }
            is StopMacroAction -> {
                if (a.reason.isNotBlank()) repo.log(name, "Berhenti: ${t(a.reason, d)}", true)
                throw StopSignal()
            }
            is RunMacroAction -> {
                val target = repo.macros.value.firstOrNull { it.name.equals(a.macro.trim(), ignoreCase = true) }
                    ?: error("Makro '${a.macro}' tidak ditemukan")
                if (nest.incrementAndGet() > 8) {
                    nest.decrementAndGet()
                    error("Pemanggilan makro terlalu dalam")
                }
                try {
                    run(target.actions, d + mapOf("par1" to t(a.par1, d), "par2" to t(a.par2, d), "par3" to t(a.par3, d)), target.name)
                } catch (e: StopSignal) {
                    // hanya menghentikan makro yang dipanggil
                } finally {
                    nest.decrementAndGet()
                }
            }
            is IfCompareAction -> {
                val cur = repo.variables.value[a.name].orEmpty()
                run(if (Compare.test(cur, a.cmp, t(a.value, d))) a.then else a.otherwise, d, name)
            }
            is RandomVariableAction -> {
                val lo = minOf(a.min, a.max)
                val hi = maxOf(a.min, a.max)
                repo.setVariable(a.name, (lo..hi).random().toString())
            }
            is SyncAction -> ContentResolver.setMasterSyncAutomatically(want(a.enable, a.toggle) { ContentResolver.getMasterSyncAutomatically() })

            is AutoBrightnessAction -> {
                if (!Settings.System.canWrite(ctx)) error("Butuh izin 'Ubah pengaturan sistem'")
                val on = want(a.enable, a.toggle) {
                    Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) ==
                        Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                }
                Settings.System.putInt(
                    ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    if (on) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
                )
            }

            is BatterySaverAction -> {
                val v = if (want(a.enable, a.toggle) { ctx.getSystemService(PowerManager::class.java).isPowerSaveMode }) 1 else 0
                if (ElevatedPermissions.hasSecureSettings(ctx)) {
                    Settings.Global.putInt(ctx.contentResolver, "low_power", v)
                } else withContext(Dispatchers.IO) { needAdb("settings put global low_power $v") }
            }

            is DarkModeAction -> withContext(Dispatchers.IO) {
                val m = when (a.darkMode) {
                    "toggle" -> {
                        val night = ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
                        if (night == android.content.res.Configuration.UI_MODE_NIGHT_YES) "no" else "yes"
                    }
                    "yes", "no", "auto" -> a.darkMode
                    else -> error("Pilih yes, no, auto, atau toggle")
                }
                needAdb("cmd uimode night $m")
            }

            is EnableMacroAction -> {
                val target = repo.macros.value.firstOrNull { it.name.equals(a.macro.trim(), ignoreCase = true) }
                    ?: error("Makro '${a.macro}' tidak ditemukan")
                repo.setEnabled(target.id, a.enable)
            }

            is ShareTextAction -> startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t(a.text, d)), null,
                ),
            )

            is OpenCameraAction -> startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))

            is WriteFileAction -> withContext(Dispatchers.IO) {
                val fn = a.fileName.trim()
                if (fn.isEmpty() || '/' in fn || '\\' in fn || ".." in fn) error("Nama berkas tidak valid")
                val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, fn)
                val line = t(a.text, d) + "\n"
                if (a.append) f.appendText(line) else f.writeText(line)
                repo.log(name, "Berkas ditulis: ${f.absolutePath}", true)
            }

            is ClearLogAction -> repo.clearLogs()

            is FindPhoneAction -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
                val r = RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                    ?: error("Nada alarm tidak ditemukan")
                r.audioAttributes = android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM).build()
                r.play()
                try {
                    delay(a.seconds.coerceIn(1, 120) * 1000L)
                } finally {
                    r.stop()
                }
            }

            is StopSpeakAction -> main.post { tts?.stop() }

            is IfTimeAction -> run(
                if (checker.check(TimeRangeConstraint(a.fromHour, a.fromMinute, a.toHour, a.toMinute))) a.then else a.otherwise,
                d, name,
            )

            is IfConstraintAction -> run(
                if (a.constraints.filter { it !is OffConstraint }.all { checker.check(it, d) }) a.then else a.otherwise,
                d, name,
            )

            is IfBatteryAction -> run(
                if (checker.check(BatteryConstraint(a.level, a.below))) a.then else a.otherwise,
                d, name,
            )

            is WhatsAppAction -> {
                val num = t(a.number, d).filter { it.isDigit() }
                if (num.isEmpty()) error("Nomor kosong (pakai kode negara, mis. 62812…)")
                val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(t(a.text, d)))
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(if (a.business) "com.whatsapp.w4b" else "com.whatsapp"))
            }

            is SetTtsAction -> {
                ttsRate = a.rate.coerceIn(20, 300) / 100f
                ttsPitch = a.pitch.coerceIn(20, 300) / 100f
                main.post { tts?.setSpeechRate(ttsRate); tts?.setPitch(ttsPitch) }
            }

            is WaitUntilAction -> {
                var left = a.timeout.coerceIn(1, 3600)
                while (left > 0) {
                    val cur = repo.variables.value[a.name].orEmpty()
                    if (Compare.test(cur, a.cmp, t(a.value, d))) return
                    delay(1000)
                    left--
                }
                repo.log(name, "Tunggu sampai '${a.name}': waktu habis, makro berhenti", false)
                throw StopSignal()
            }

            is ClickTextAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                val target = t(a.text, d).trim()
                if (target.isEmpty()) error("Teks yang dicari kosong")
                var left = a.timeout.coerceIn(0, 60) * 1000L
                var ok = svc.clickByText(target, a.longClick)
                while (!ok && left > 0) {
                    delay(500)
                    left -= 500
                    ok = svc.clickByText(target, a.longClick)
                }
                if (!ok) error("Tidak menemukan tombol/teks '$target' yang bisa diketuk di layar")
            }

            is WaitScreenTextAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                val target = t(a.text, d).trim()
                if (target.isEmpty()) error("Tulisan yang ditunggu kosong")
                val paket = t(a.pkg, d).trim()
                var left = (if (a.timeout <= 0) 120 else a.timeout.coerceIn(1, 3600)) * 2
                var ketemu = false
                while (left > 0 && !ketemu) {
                    ketemu = (paket.isEmpty() || MacroAccessibilityService.currentPkg == paket) &&
                        svc.screenText(8000).contains(target, ignoreCase = true)
                    if (!ketemu) { delay(500); left-- }
                }
                if (!ketemu) {
                    if (a.continueOnTimeout) repo.log(name, "Tunggu tulisan '$target': waktu habis, lanjut", true)
                    else {
                        repo.log(name, "Tunggu tulisan '$target': waktu habis, makro berhenti", false)
                        throw StopSignal()
                    }
                }
            }

            is ClickIdAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                val target = t(a.viewId, d).trim()
                if (target.isEmpty()) error("ID tampilan yang dicari kosong")
                if (':' !in target) error("ID tampilan harus lengkap, mis. com.whatsapp:id/send")
                var left = a.timeout.coerceIn(0, 60) * 1000L
                var ok = svc.clickById(target, a.longClick)
                while (!ok && left > 0) {
                    delay(500)
                    left -= 500
                    ok = svc.clickById(target, a.longClick)
                }
                if (!ok) error("Tidak menemukan elemen ber-ID '$target' yang bisa diketuk di layar")
            }

            is ScrollAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                if (!svc.scroll(a.scrollDir != "up")) error("Tidak ada daftar yang bisa digulir di layar")
            }

            is SetFocusedTextAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                if (!svc.setFocusedText(t(a.text, d), a.appendText)) error("Tidak ada kolom teks yang sedang fokus")
            }

            is ReadScreenAction -> {
                val svc = MacroAccessibilityService.instance ?: error("Layanan Aksesibilitas MakroKu belum aktif")
                val v = a.saveTo.trim().ifEmpty { "teks_layar" }
                repo.setVariable(v, svc.screenText(a.maxChars.coerceIn(100, 20000)))
            }

            is TextOpAction -> {
                val out = TextTools.textOp(t(a.text, d), a.textOp, t(a.arg, d), t(a.arg2, d))
                repo.setVariable(a.saveTo.trim().ifEmpty { "hasil" }, out)
            }

            is MathAction -> {
                val out = TextTools.formatNum(TextTools.eval(t(a.expr, d)))
                repo.setVariable(a.saveTo.trim().ifEmpty { "hasil" }, out)
            }

            is JsonPickAction -> {
                val out = TextTools.jsonPick(t(a.json, d), t(a.path, d))
                repo.setVariable(a.saveTo.trim().ifEmpty { "hasil" }, out)
            }

            is WhileAction -> {
                var n = 0
                val limit = a.maxLoops.coerceIn(1, 1000)
                while (n < limit && Compare.test(repo.variables.value[a.name].orEmpty(), a.cmp, t(a.value, d))) {
                    try {
                        run(a.actions, d, name)
                    } catch (e: ContinueSignal) {
                        // lanjut ke putaran berikutnya
                    } catch (e: BreakSignal) {
                        break
                    }
                    n++
                    delay(20)
                }
            }

            is WhileConstraintAction -> {
                var n = 0
                val limit = a.maxLoops.coerceIn(1, 2000)
                val syarat = a.constraints.filter { it !is OffConstraint }
                while (n < limit && syarat.all { checker.check(it, d) }) {
                    try {
                        run(a.actions, d, name)
                    } catch (e: ContinueSignal) {
                        // lanjut ke putaran berikutnya
                    } catch (e: BreakSignal) {
                        break
                    }
                    n++
                    delay(50)
                }
            }

            is KeepAwakeAction -> {
                if (a.enable) {
                    val layar = a.awakeScreen != "cpu_only"
                    AwakeKeeper.enable(ctx, layar, a.awakeSeconds)
                    val lama = if (a.awakeSeconds > 0) "${a.awakeSeconds} detik" else "sampai dimatikan"
                    repo.log(name, "Penjaga perangkat aktif (" + (if (layar) "layar menyala" else "hanya CPU") + ", " + lama + ")", true)
                } else {
                    AwakeKeeper.disable()
                    repo.log(name, "Penjaga perangkat dimatikan", true)
                }
            }

            is SayTimeAction -> {
                val c = java.util.Calendar.getInstance()
                val jam = c.get(java.util.Calendar.HOUR_OF_DAY)
                val mnt = c.get(java.util.Calendar.MINUTE)
                val waktu = "Jam $jam" + (if (mnt == 0) " tepat" else " lewat $mnt menit")
                val tgl = if (a.withDate) ". " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(Date()) else ""
                speak(waktu + tgl)
            }

            is SayBatteryAction -> speak("Baterai ${checker.batteryLevel()} persen")

            is OpenCallLogAction -> startActivity(Intent(Intent.ACTION_VIEW).setType("vnd.android.cursor.dir/calls"))

            is DialNumberAction -> {
                val num = t(a.number, d).filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
                if (num.isEmpty()) error("Nomor kosong")
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
            }

            is UninstallAppAction -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkgOk(a.pkg))))

            is AppInfoAction -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkgOk(a.pkg))))

            is OpenMapAction -> {
                val q = t(a.query, d).trim()
                if (q.isEmpty()) error("Kata pencarian peta kosong")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
            }

            is AddCalendarEventAction -> startActivity(
                Intent(Intent.ACTION_INSERT, android.provider.CalendarContract.Events.CONTENT_URI)
                    .putExtra(android.provider.CalendarContract.Events.TITLE, t(a.title, d))
                    .putExtra(android.provider.CalendarContract.Events.DESCRIPTION, t(a.details, d))
                    .putExtra(android.provider.CalendarContract.Events.EVENT_LOCATION, t(a.place, d)),
            )

            is VibratePatternAction -> {
                val p = t(a.pattern, d).split(",").mapNotNull { it.trim().toLongOrNull()?.coerceIn(0, 5000) }
                if (p.size < 2) error("Pola getar minimal dua angka, mis. 0,200,100,200")
                val v: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                    ctx.getSystemService(VibratorManager::class.java).defaultVibrator
                else ctx.getSystemService(Vibrator::class.java)
                v.vibrate(VibrationEffect.createWaveform(p.take(40).toLongArray(), -1))
            }

            is ClearClipboardAction -> main.post { runCatching { ctx.getSystemService(ClipboardManager::class.java).clearPrimaryClip() } }

            is AnswerCallAction -> {
                if (!hasPerm("android.permission.ANSWER_PHONE_CALLS")) error("Butuh izin 'Jawab panggilan telepon' (beri lewat menu Izin via ADB)")
                ctx.getSystemService(android.telecom.TelecomManager::class.java).acceptRingingCall()
            }

            is EndCallAction -> {
                if (!hasPerm("android.permission.ANSWER_PHONE_CALLS")) error("Butuh izin 'Jawab panggilan telepon' (beri lewat menu Izin via ADB)")
                if (!ctx.getSystemService(android.telecom.TelecomManager::class.java).endCall()) error("Tidak ada panggilan yang bisa diakhiri")
            }

            is ClearCallLogAction -> {
                if (!hasPerm("android.permission.WRITE_CALL_LOG")) error("Butuh izin 'Tulis riwayat panggilan' (beri lewat menu Izin via ADB)")
                ctx.contentResolver.delete(android.provider.CallLog.Calls.CONTENT_URI, null, null)
            }

            is RandomDelayAction -> {
                val lo = a.minSeconds.coerceAtLeast(0)
                val hi = a.maxSeconds.coerceAtLeast(lo)
                delay((lo..hi).random() * 1000L)
            }

            is UdpSendAction -> withContext(Dispatchers.IO) {
                val host = a.host.trim()
                if (host.isEmpty()) error("Alamat tujuan kosong")
                val bytes = t(a.text, d).toByteArray()
                java.net.DatagramSocket().use { s ->
                    s.broadcast = true
                    s.send(java.net.DatagramPacket(bytes, bytes.size, java.net.InetAddress.getByName(host), a.port.coerceIn(1, 65535)))
                }
            }

            is WakeOnLanAction -> withContext(Dispatchers.IO) {
                val hex = a.mac.replace(Regex("[^0-9A-Fa-f]"), "")
                if (hex.length != 12) error("Alamat MAC harus 12 digit heksadesimal")
                val mac = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
                val pkt = ByteArray(6) { 0xFF.toByte() } + ByteArray(16 * 6) { mac[it % 6] }
                val host = a.host.trim().ifEmpty { "255.255.255.255" }
                java.net.DatagramSocket().use { s ->
                    s.broadcast = true
                    s.send(java.net.DatagramPacket(pkt, pkt.size, java.net.InetAddress.getByName(host), a.port.coerceIn(1, 65535)))
                }
            }

            is DeviceInfoVarAction -> {
                val nilai = when (a.deviceInfo) {
                    "manufacturer" -> Build.MANUFACTURER
                    "brand" -> Build.BRAND
                    "device" -> Build.DEVICE
                    "android" -> Build.VERSION.RELEASE
                    "sdk" -> Build.VERSION.SDK_INT.toString()
                    else -> Build.MODEL
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "info_hp" }, nilai)
            }

            is LocationVarAction -> {
                if (!hasPerm("android.permission.ACCESS_FINE_LOCATION") && !hasPerm("android.permission.ACCESS_COARSE_LOCATION"))
                    error("Butuh izin lokasi")
                val lm = ctx.getSystemService(android.location.LocationManager::class.java)
                val loc = listOf("gps", "network", "passive")
                    .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
                    .maxByOrNull { it.time } ?: error("Lokasi terakhir belum tersedia")
                val v = a.saveTo.trim().ifEmpty { "lokasi" }
                repo.setVariable(v, "${loc.latitude},${loc.longitude}")
                repo.setVariable(v + "_lat", loc.latitude.toString())
                repo.setVariable(v + "_lon", loc.longitude.toString())
            }

            is BreakLoopAction -> throw BreakSignal()
            is ContinueLoopAction -> throw ContinueSignal()

            is StopwatchAction -> {
                val key = a.swName.trim().ifEmpty { "stopwatch" }
                val detik = Stopwatches.apply(key, a.swCmd)
                repo.setVariable(a.saveTo.trim().ifEmpty { "sw_$key" }, detik.toString())
            }

            is PowerCommandAction -> withContext(Dispatchers.IO) {
                needAdb(
                    when (a.powerCmd) {
                        "shutdown" -> "svc power shutdown"
                        "recovery" -> "svc power reboot recovery"
                        else -> "svc power reboot"
                    },
                )
            }

            is KillBackgroundAction -> withContext(Dispatchers.IO) { needAdb("am kill " + pkgOk(t(a.pkg, d))) }

            is ScreenRecordAction -> withContext(Dispatchers.IO) {
                val sec = a.seconds.coerceIn(1, 180)
                val fn = t(a.fileName, d).filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "rekam" }
                val out = "/sdcard/Movies/$fn-${System.currentTimeMillis() / 1000}.mp4"
                needAdb("mkdir -p /sdcard/Movies; screenrecord --time-limit $sec $out", sec + 20L)
                repo.log(name, "Rekaman layar tersimpan di $out", true)
            }

            is AssistantAction -> {
                try {
                    startActivity(Intent(Intent.ACTION_VOICE_COMMAND))
                } catch (e: Exception) {
                    startActivity(Intent(Intent.ACTION_ASSIST))
                }
            }

            is UssdAction -> {
                val kode = t(a.code, d).trim()
                if (kode.isEmpty()) error("Kode USSD kosong")
                if (!hasPerm(android.Manifest.permission.CALL_PHONE)) error("Izin CALL_PHONE belum diberikan")
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(kode))))
            }

            is EnableCategoryAction -> {
                val kat = t(a.category, d).trim()
                if (kat.isEmpty()) {
                    repo.macros.value.filter { !it.name.equals(name, ignoreCase = true) }.forEach { repo.setEnabled(it.id, a.enable) }
                } else {
                    if (repo.macros.value.none { it.category.ifBlank { "Umum" }.equals(kat, ignoreCase = true) }) error("Kategori '$kat' tidak ditemukan")
                    val nama = repo.macros.value.first { it.category.ifBlank { "Umum" }.equals(kat, ignoreCase = true) }.category.ifBlank { "Umum" }
                    repo.setCategoryEnabled(nama, a.enable)
                }
            }

            is DownloadFileAction -> withContext(Dispatchers.IO) {
                val fn = a.fileName.trim()
                if (fn.isEmpty() || '/' in fn || '\\' in fn || ".." in fn) error("Nama berkas tidak valid")
                val c = URL(t(a.url, d)).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 15_000
                    c.readTimeout = 30_000
                    val code = c.responseCode
                    if (code !in 200..299) error("Unduhan gagal: HTTP $code")
                    val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, fn)
                    var total = 0L
                    c.inputStream.use { ins ->
                        f.outputStream().use { outs ->
                            val buf = ByteArray(8192)
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                outs.write(buf, 0, r)
                                total += r
                                if (total > 50L * 1024 * 1024) error("Berkas lebih dari 50 MB, unduhan dibatalkan")
                            }
                        }
                    }
                    repo.setVariable("unduh_ukuran", total.toString())
                } finally {
                    c.disconnect()
                }
            }

            is PingAction -> withContext(Dispatchers.IO) {
                val host = t(a.host, d).trim()
                if (host.isEmpty()) error("Alamat kosong")
                val batas = a.timeoutMs.coerceIn(200, 15_000)
                val mulai = System.nanoTime()
                val ok = try {
                    if (a.port > 0) {
                        java.net.Socket().use { s -> s.connect(java.net.InetSocketAddress(host, a.port.coerceIn(1, 65535)), batas) }
                        true
                    } else {
                        java.net.InetAddress.getByName(host).isReachable(batas)
                    }
                } catch (e: Exception) {
                    false
                }
                val ms = (System.nanoTime() - mulai) / 1_000_000L
                val v = a.saveTo.trim().ifEmpty { "ping" }
                repo.setVariable(v, ok.toString())
                repo.setVariable(v + "_ms", ms.toString())
            }

            is NetworkInfoVarAction -> {
                val cm = ctx.getSystemService(android.net.ConnectivityManager::class.java)
                val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
                val nilai = when (a.netInfo) {
                    "ssid" -> wm?.connectionInfo?.ssid.orEmpty().trim('"').let { if (it.contains("unknown ssid")) "" else it }
                    "signal" -> wm?.connectionInfo?.rssi?.toString().orEmpty()
                    "ip" -> cm.getLinkProperties(cm.activeNetwork)?.linkAddresses
                        ?.map { it.address }
                        ?.firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress }
                        ?.hostAddress.orEmpty()
                    "net_type" -> {
                        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                        when {
                            caps == null -> "none"
                            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
                            else -> "other"
                        }
                    }
                    "operator" -> ctx.getSystemService(android.telephony.TelephonyManager::class.java)?.networkOperatorName.orEmpty()
                    else -> ""
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "info_jaringan" }, nilai)
            }

            is ClipboardVarAction -> {
                var teks = ""
                val gerbang = java.util.concurrent.CountDownLatch(1)
                main.post {
                    try {
                        val cb = ctx.getSystemService(ClipboardManager::class.java)
                        teks = cb.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    } catch (e: Exception) {
                        teks = ""
                    } finally {
                        gerbang.countDown()
                    }
                }
                withContext(Dispatchers.IO) { gerbang.await(3, java.util.concurrent.TimeUnit.SECONDS) }
                if (teks.isEmpty()) repo.log(name, "Papan klip kosong, atau Android melarang aplikasi latar membacanya", false)
                repo.setVariable(a.saveTo.trim().ifEmpty { "papan_klip" }, teks.take(20000))
            }

            is VoiceInputAction -> {
                if (!Settings.canDrawOverlays(ctx)) error("Butuh izin 'Tampil di atas aplikasi lain'")
                val id = System.nanoTime().toString()
                val jawab = kotlinx.coroutines.CompletableDeferred<String?>()
                com.makroku.automation.ui.PromptBridge.pending[id] = jawab
                val hasil = try {
                    ctx.startActivity(
                        Intent(ctx, com.makroku.automation.ui.InputPromptActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("id", id)
                            .putExtra("mode", "voice")
                            .putExtra("title", t(a.prompt, d)),
                    )
                    kotlinx.coroutines.withTimeoutOrNull(a.seconds.coerceIn(5, 600) * 1000L) { jawab.await() }
                } finally {
                    com.makroku.automation.ui.PromptBridge.pending.remove(id)
                }
                if (hasil == null) {
                    repo.log(name, "Input suara dibatalkan, tidak terdengar, atau waktu habis, makro berhenti", false)
                    throw StopSignal()
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "jawaban_suara" }, hasil)
            }

            is InputPromptAction -> {
                if (!Settings.canDrawOverlays(ctx)) error("Butuh izin 'Tampil di atas aplikasi lain'")
                val id = System.nanoTime().toString()
                val jawab = kotlinx.coroutines.CompletableDeferred<String?>()
                com.makroku.automation.ui.PromptBridge.pending[id] = jawab
                val hasil = try {
                    ctx.startActivity(
                        Intent(ctx, com.makroku.automation.ui.InputPromptActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("id", id)
                            .putExtra("title", t(a.title, d))
                            .putExtra("text", t(a.text, d))
                            .putExtra("default", t(a.defaultText, d))
                            .putExtra("numeric", a.numeric),
                    )
                    kotlinx.coroutines.withTimeoutOrNull(a.seconds.coerceIn(5, 600) * 1000L) { jawab.await() }
                } finally {
                    com.makroku.automation.ui.PromptBridge.pending.remove(id)
                }
                if (hasil == null) {
                    repo.log(name, "Dialog isian dibatalkan atau waktu habis, makro berhenti", false)
                    throw StopSignal()
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "jawaban" }, hasil)
            }

            // ───────────── Tahap 48: dialog pilihan, berkas, zip ─────────────
            is ChoicePromptAction -> {
                if (!Settings.canDrawOverlays(ctx)) error("Butuh izin 'Tampil di atas aplikasi lain'")
                val daftar = t(a.items, d).lines().map { it.trim() }.filter { it.isNotEmpty() }
                if (!a.yesNo && daftar.isEmpty()) error("Daftar pilihan kosong")
                val id = System.nanoTime().toString()
                val jawab = kotlinx.coroutines.CompletableDeferred<String?>()
                com.makroku.automation.ui.PromptBridge.pending[id] = jawab
                val hasil = try {
                    ctx.startActivity(
                        Intent(ctx, com.makroku.automation.ui.InputPromptActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("id", id)
                            .putExtra("mode", if (a.yesNo) "yesno" else "choice")
                            .putExtra("title", t(a.title, d))
                            .putExtra("text", t(a.text, d))
                            .putExtra("items", daftar.toTypedArray()),
                    )
                    kotlinx.coroutines.withTimeoutOrNull(a.seconds.coerceIn(5, 600) * 1000L) { jawab.await() }
                } finally {
                    com.makroku.automation.ui.PromptBridge.pending.remove(id)
                }
                if (hasil == null) {
                    repo.log(name, "Dialog pilihan dibatalkan atau waktu habis, makro berhenti", false)
                    throw StopSignal()
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "pilihan_dialog" }, hasil)
            }

            is FileListAction -> withContext(Dispatchers.IO) {
                val dasar = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                val sub = t(a.subFolder, d).trim().trim('/')
                if ('\\' in sub || ".." in sub) error("Nama folder tidak valid: '$sub'")
                val dir = if (sub.isEmpty()) dasar else java.io.File(dasar, sub)
                val nama = dir.listFiles()?.map { if (it.isDirectory) it.name + "/" else it.name }?.sorted().orEmpty()
                repo.setVariable(a.saveTo.trim().ifEmpty { "daftar_berkas" }, nama.joinToString("\n"))
            }

            is FileLineAction -> withContext(Dispatchers.IO) {
                val dasar = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                val n = t(a.fromFile, d).trim()
                if (n.isEmpty() || '/' in n || '\\' in n || ".." in n) error("Nama berkas tidak valid: '$n'")
                val f = java.io.File(dasar, n)
                if (!f.exists()) error("Berkas '${f.name}' belum ada")
                if (f.length() > 5_000_000L) error("Berkas terlalu besar (maksimal 5 MB)")
                val baris = f.readLines()
                val p = if (a.index > 0) a.index - 1 else if (a.index < 0) baris.size + a.index else -1
                repo.setVariable(a.saveTo.trim().ifEmpty { "baris" }, if (p in baris.indices) baris[p] else "")
            }

            is ZipAction -> withContext(Dispatchers.IO) {
                val dasar = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                fun nama(x: String): String {
                    val n = t(x, d).trim()
                    if (n.isEmpty() || '/' in n || '\\' in n || ".." in n) error("Nama tidak valid: '$n'")
                    return n
                }
                val asal = java.io.File(dasar, nama(a.fromFile))
                val tujuan = java.io.File(dasar, nama(a.toFile))
                if (!asal.exists()) error("'${asal.name}' belum ada")
                if (a.zipOp == "zip") {
                    val akar = if (asal.isDirectory) asal else (asal.parentFile ?: dasar)
                    java.util.zip.ZipOutputStream(tujuan.outputStream().buffered()).use { zos ->
                        asal.walkTopDown().filter { it.isFile && it != tujuan }.forEach { f ->
                            zos.putNextEntry(java.util.zip.ZipEntry(f.relativeTo(akar).path.replace('\\', '/')))
                            f.inputStream().use { it.copyTo(zos) }
                            zos.closeEntry()
                        }
                    }
                } else {
                    tujuan.mkdirs()
                    val akarKanon = tujuan.canonicalPath + java.io.File.separator
                    java.util.zip.ZipInputStream(asal.inputStream().buffered()).use { zis ->
                        var e = zis.nextEntry
                        while (e != null) {
                            val out = java.io.File(tujuan, e.name)
                            if (!out.canonicalPath.startsWith(akarKanon)) error("Entri zip tidak aman: ${e.name}")
                            if (e.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { zis.copyTo(it) }
                            }
                            zis.closeEntry()
                            e = zis.nextEntry
                        }
                    }
                }
                Unit
            }

            // ───────────── Tahap 49: konversi tanggal, kelola berkas ─────────────
            is DateConvertAction -> {
                val fmt = try {
                    SimpleDateFormat(a.format.ifBlank { "yyyy-MM-dd HH:mm" }, Locale("id", "ID"))
                } catch (e: IllegalArgumentException) {
                    error("Format tanggal tidak valid: ${a.format}")
                }
                fun baca(x: String): Long = try {
                    fmt.parse(t(x, d).trim())!!.time
                } catch (e: Exception) {
                    error("Tanggal '${t(x, d).trim()}' tidak cocok dengan format '${a.format}'")
                }
                val hasil: String = when (a.dateOp) {
                    "to_epoch" -> (baca(a.value) / 1000L).toString()
                    "from_epoch" -> {
                        val dtk = t(a.value, d).trim().toLongOrNull() ?: error("Detik epoch tidak valid")
                        fmt.format(java.util.Date(dtk * 1000L))
                    }
                    "diff_seconds" -> ((baca(a.value2) - baca(a.value)) / 1000L).toString()
                    "diff_minutes" -> ((baca(a.value2) - baca(a.value)) / 60_000L).toString()
                    "diff_hours" -> ((baca(a.value2) - baca(a.value)) / 3_600_000L).toString()
                    "diff_days" -> ((baca(a.value2) - baca(a.value)) / 86_400_000L).toString()
                    else -> error("Operasi tanggal tidak dikenal: ${a.dateOp}")
                }
                repo.setVariable(a.saveTo.trim().ifEmpty { "hasil_tanggal" }, hasil)
            }

            is FileManageAction -> withContext(Dispatchers.IO) {
                val dasar = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                fun nama(x: String): String {
                    val n = t(x, d).trim()
                    if (n.isEmpty() || '/' in n || '\\' in n || ".." in n) error("Nama tidak valid: '$n'")
                    return n
                }
                val asal = java.io.File(dasar, nama(a.fromFile))
                when (a.manageOp) {
                    "mkdir" -> asal.mkdirs()
                    "delete" -> if (asal.exists()) { if (!asal.deleteRecursively()) error("Gagal menghapus '${asal.name}'") }
                    "rename" -> {
                        if (!asal.exists()) error("'${asal.name}' belum ada")
                        if (!asal.renameTo(java.io.File(dasar, nama(a.toFile)))) error("Gagal mengganti nama '${asal.name}'")
                    }
                    else -> error("Operasi tidak dikenal: ${a.manageOp}")
                }
                Unit
            }

            // ───────────── Tahap 50: variabel bernomor ─────────────
            is SplitToVarsAction -> {
                val awalan = a.prefix.trim()
                if (awalan.isEmpty() || !Regex("[A-Za-z0-9_]+").matches(awalan)) error("Awalan nama variabel tidak valid: '$awalan'")
                val pemisah = a.separator.replace("\\n", "\n").ifEmpty { "," }
                val bagian = t(a.text, d).split(pemisah).map { it.trim() }.filter { it.isNotEmpty() }.take(500)
                val lama = Regex(Regex.escape(awalan) + "\\d+")
                repo.variables.value.keys.filter { lama.matches(it) }.forEach { repo.deleteVariable(it) }
                bagian.forEachIndexed { i, v -> repo.setVariable(awalan + (i + 1), v) }
                repo.setVariable(awalan + "_jumlah", bagian.size.toString())
            }

            is ClearVarsAction -> {
                val awalan = a.prefix.trim()
                if (awalan.isEmpty()) error("Awalan wajib diisi agar tidak menghapus semua variabel")
                repo.variables.value.keys.filter { it.startsWith(awalan) }.forEach { repo.deleteVariable(it) }
            }

            is FontScaleAction -> withContext(Dispatchers.IO) {
                val v = String.format(Locale.US, "%.2f", a.fontPercent.coerceIn(50, 200) / 100f)
                if (Settings.System.canWrite(ctx)) Settings.System.putString(ctx.contentResolver, "font_scale", v)
                else needAdb("settings put system font_scale $v")
            }

            is DisplayColorAction -> withContext(Dispatchers.IO) {
                val inversi = if (a.colorMode == "invert") 1 else 0
                val abu = if (a.colorMode == "grayscale") 1 else 0
                fun taruh(k: String, v: Int) {
                    if (ElevatedPermissions.hasSecureSettings(ctx)) Settings.Secure.putInt(ctx.contentResolver, k, v)
                    else needAdb("settings put secure $k $v")
                }
                taruh("accessibility_display_inversion_enabled", inversi)
                if (abu == 1) taruh("accessibility_display_daltonizer", 0)
                taruh("accessibility_display_daltonizer_enabled", abu)
            }

            is FileOpAction -> withContext(Dispatchers.IO) {
                val dasar = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                fun nama(x: String): String {
                    val n = t(x, d).trim()
                    if (n.isEmpty() || '/' in n || '\\' in n || ".." in n) error("Nama berkas tidak valid: '$n'")
                    return n
                }
                val asal = java.io.File(dasar, nama(a.fromFile))
                val v = a.saveTo.trim().ifEmpty { "hasil_berkas" }
                when (a.fileOp) {
                    "exists" -> repo.setVariable(v, asal.exists().toString())
                    "size" -> repo.setVariable(v, (if (asal.exists()) asal.length() else -1L).toString())
                    "copy", "move" -> {
                        if (!asal.exists()) error("Berkas '${asal.name}' belum ada")
                        val tujuan = java.io.File(dasar, nama(a.toFile))
                        asal.copyTo(tujuan, overwrite = true)
                        if (a.fileOp == "move") asal.delete()
                    }
                    else -> error("Operasi berkas tidak dikenal")
                }
                Unit
            }

            is StopSoundAction -> {
                sound?.stop()
                sound = null
            }

            is LogAction -> repo.log(name, t(a.text, d), true)

            is IfVariableAction -> {
                val cur = repo.variables.value[a.name].orEmpty()
                run(if (cur == t(a.value, d)) a.then else a.otherwise, d, name)
            }
        }
    }

    private fun speak(text: String) {
        main.post {
            val engine = tts
            if (engine != null && ttsReady) {
                engine.setSpeechRate(ttsRate)
                engine.setPitch(ttsPitch)
                engine.speak(text, TextToSpeech.QUEUE_ADD, null, "mk" + System.nanoTime())
            } else {
                pendingSpeech.add(text)
                if (engine == null) {
                    tts = TextToSpeech(ctx) { status ->
                        if (status == TextToSpeech.SUCCESS) {
                            ttsReady = true
                            tts?.setSpeechRate(ttsRate)
                            tts?.setPitch(ttsPitch)
                            pendingSpeech.forEach { tts?.speak(it, TextToSpeech.QUEUE_ADD, null, "mk" + System.nanoTime()) }
                            pendingSpeech.clear()
                        }
                    }
                }
            }
        }
    }
}
