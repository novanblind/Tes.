package com.novan.talkbacknovan;

/** Daftar aksi yang bisa dipasang ke gestur dan tombol. Nomor aksi = urutan dalam NAMA. */
public final class Aksi {
    public static final int TIDAK_ADA = 0;
    public static final int ITEM_MAJU = 1;
    public static final int ITEM_MUNDUR = 2;
    public static final int GULIR_MAJU = 3;
    public static final int GULIR_MUNDUR = 4;
    public static final int HALAMAN_BERIKUT = 5;
    public static final int HALAMAN_SEBELUMNYA = 6;
    public static final int KETUK = 7;
    public static final int KETUK_LAMA = 8;
    public static final int BACA_DARI_SINI = 9;
    public static final int BACA_LAYAR = 10;
    public static final int HENTIKAN_SUARA = 11;
    public static final int ULANGI = 12;
    public static final int INFO = 13;
    public static final int GRAN_BERIKUT = 14;
    public static final int GRAN_SEBELUM = 15;
    public static final int BERANDA = 16;
    public static final int KEMBALI = 17;
    public static final int TERBARU = 18;
    public static final int NOTIFIKASI = 19;
    public static final int PENGATURAN_CEPAT = 20;
    public static final int KUNCI_LAYAR = 21;
    public static final int GANTI_NAMA = 22;
    public static final int SALIN = 23;
    public static final int TEMPEL = 24;
    public static final int POTONG = 25;
    public static final int PILIH_SEMUA = 26;
    public static final int MENU = 27;
    public static final int TAMPIL_TEKS = 28;
    public static final int OCR_LAYAR = 29;
    public static final int OCR_FOKUS = 30;
    public static final int PERINTAH_SUARA = 31;
    public static final int LAJU_NAIK = 32;
    public static final int LAJU_TURUN = 33;
    public static final int SCREENSHOT = 34;
    public static final int DAYA = 35;
    public static final int BISU = 36;
    public static final int SALIN_UCAPAN = 37;
    public static final int BACA_KLIP = 38;

    public static final String[] NAMA = {
            "Tidak ada",
            "Item berikutnya",
            "Item sebelumnya",
            "Gulir maju (konten selanjutnya)",
            "Gulir mundur (konten sebelumnya)",
            "Halaman berikutnya (gulir ke kanan)",
            "Halaman sebelumnya (gulir ke kiri)",
            "Ketuk elemen terfokus",
            "Ketuk lama elemen terfokus",
            "Baca dari item ini",
            "Baca seluruh layar",
            "Hentikan suara",
            "Ulangi ucapan terakhir",
            "Ucapkan jam dan baterai",
            "Granularitas berikutnya",
            "Granularitas sebelumnya",
            "Beranda",
            "Kembali",
            "Aplikasi terbaru",
            "Notifikasi",
            "Pengaturan cepat",
            "Kunci layar",
            "Ganti nama elemen terfokus",
            "Salin",
            "Tempel",
            "Potong",
            "Pilih semua teks",
            "Menu elemen terfokus",
            "Tampilkan teks layar",
            "OCR seluruh layar (Gemini/Groq)",
            "OCR elemen terfokus (Gemini/Groq)",
            "Perintah suara",
            "Percepat bicara",
            "Perlambat bicara",
            "Ambil tangkapan layar",
            "Menu daya",
            "Bisukan atau aktifkan suara",
            "Salin ucapan terakhir",
            "Baca isi papan klip"
    };

    private Aksi() {}
}
