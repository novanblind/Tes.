package com.novan.penghilangvokal;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Menghilangkan vokal dengan model MDX-Net (UVR-MDX-NET-Inst_HQ_3, ONNX Runtime).
 *
 * Alur: lagu didekode ke PCM float stereo (berkas sementara), dibaca jendela demi jendela pada
 * 44100 Hz (tiap jendela diberi konteks di kiri-kanan yang dibuang dari hasil), dipisahkan oleh
 * model (STFT, model, iSTFT; lihat MdxNet), lalu musik tanpa vokal disandi ke MP3.
 *
 *  - Jendela boleh saling bertumpuk dan disambung dengan crossfade (pilihan kecepatan).
 *  - Keluaran MP3 VBR lewat LAME, dan vokal bisa disimpan terpisah.
 */
public class VocalRemover {

    public interface Progress {
        void onPercent(int percent);
    }

    public static class NoAudioException extends IOException {
        public NoAudioException() { super("tanpa audio"); }
    }

    public static class CancelledException extends IOException {
        public CancelledException() { super("dibatalkan"); }
    }

    public static class ModelException extends IOException {
        public ModelException(String m) { super(m); }
    }

    /** MDX-Net dilatih pada 44100 Hz stereo. */
    private static final int MODEL_RATE = 44100;
    /** Konteks tambahan di kiri dan kanan tiap potongan (dibuang dari hasil), dalam detik. */
    private static final double PAD_SECONDS = 0.5;
    /** Tumpang tindih minimal antarpotongan (detik), dipakai juga pada mode Cepat supaya sambungan tidak patah. */
    private static final double OVERLAP_MIN_DETIK = 1.0;
    /** Nama berkas model di cache; naikkan bila model diganti supaya salinan lama tidak terpakai. */
    private static final String PREFIX_CACHE = "pakai_mdx2_";

    private static final int PCM_FLOAT = 4;
    /** Pilihan kualitas VBR LAME (V0 terbaik/terbesar ... V9 terkecil), urutannya sama dengan daftar di layar. */
    public static final int[] VBR_PILIHAN = {0, 2, 4, 6, 8};
    /** Algoritma LAME: 2 = mutu tinggi. */
    private static final int MP3_QUALITAS = 2;

    private volatile boolean cancelled = false;

    public void cancel() {
        cancelled = true;
    }

    private void cek() throws CancelledException {
        if (cancelled) throw new CancelledException();
    }

    // ------------------------------------------------------------------------------------
    // Proses utama
    // ------------------------------------------------------------------------------------

    /**
     * @param outVokal boleh null; bila diisi, vokal (lagu asli dikurangi musik) ikut ditulis
     * @param vbrQ kualitas VBR LAME (0 terbaik sampai 9 terkecil)
     * @param mode kecepatan: 0 = cepat (tanpa tumpang tindih antarpotongan), 1 = seimbang (25 persen),
     *             2 = terbaik (50 persen; potongan saling bertumpuk dan dirata-ratakan),
     *             3 = maksimal (seperti 2, tetapi tiap potongan dijalankan dua kali pada posisi
     *             yang digeser setengah langkah STFT lalu dirata-ratakan, mengurangi bunyi
     *             seperti air)
     * @param bersih true = hasil musik dijalankan sekali lagi lewat model untuk mengurangi sisa
     *             vokal yang masih terdengar tipis (lebih lambat)
     */
    public void process(Context ctx, Uri input, File outWav, File outVokal, int vbrQ, int mode,
                        boolean bersih, Progress cb) throws Exception {
        File raw = new File(ctx.getCacheDir(), "dekode.raw");
        try {
            // Tahap 1: dekode lagu ke PCM float stereo pada laju asli (0-20%).
            int[] info = dekode(ctx, input, raw, cb);
            int srcRate = info[0];
            long srcFrames = ((long) info[1] << 32) | (info[2] & 0xFFFFFFFFL);
            cek();

            // Tahap 2: siapkan model.
            File modelFile = salinModel(ctx);
            int utas = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
            MotorOrt motor;
            try {
                motor = new MotorOrt(modelFile, utas);
            } catch (Throwable t) {
                throw new ModelException("model tidak bisa dimuat: " + t.getMessage());
            }

            try {
                jalankan(new MdxNet(motor), raw, srcRate, srcFrames, outWav, outVokal, vbrQ, mode, bersih, cb);
            } finally {
                try {
                    motor.close();
                } catch (Exception ignored) {
                    // tidak ada yang perlu dilakukan
                }
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            raw.delete();
        }
    }

    private void jalankan(MdxNet net, File raw, int srcRate, long srcFrames,
                          File outWav, File outVokal, int vbrQ, int mode, boolean bersih,
                          Progress cb) throws Exception {
        final double ratio = (double) srcRate / MODEL_RATE;
        final long totalOut = (long) Math.floor(srcFrames / ratio);
        if (totalOut <= 0) throw new NoAudioException();

        final int pad = (int) (PAD_SECONDS * MODEL_RATE);    // konteks kiri dan kanan
        final int jendela = 3 * MdxDsp.GEN;                  // tepat tiga potongan model (tanpa sisa kosong)
        final int gen = jendela - 2 * pad;                   // frame hasil per jendela
        final boolean geser = mode >= 3;

        try (RandomAccessFile in = new RandomAccessFile(raw, "r");
             OutputStream out = new BufferedOutputStream(new FileOutputStream(outWav), 1 << 16);
             OutputStream outV = outVokal != null
                     ? new BufferedOutputStream(new FileOutputStream(outVokal), 1 << 16) : null;
             LameEncoder enc = buatEncoder(vbrQ);
             LameEncoder encV = outVokal != null ? buatEncoder(vbrQ) : null) {
            final byte[] mp3buf = new byte[LameEncoder.ukuranBuffer(gen)];

            // Tumpang tindih antarpotongan: 0, 25, atau 50 persen. Makin besar makin lambat
            // (jumlah potongan bertambah), tetapi sambungan antarpotongan makin halus.
            final int step = mode <= 0 ? gen - (int) (OVERLAP_MIN_DETIK * MODEL_RATE)
                    : (mode == 1 ? gen * 3 / 4 : gen / 2);
            final int ov = gen - step;
            // Bobot sambungan berbentuk kosinus (Hann): jumlah bobot kedua potongan selalu tepat 1,
            // dan pergantian dari satu potongan ke potongan berikutnya mulus tanpa sudut tajam.
            final float[] naik = new float[ov];
            for (int i = 0; i < ov; i++) {
                naik[i] = (float) (0.5 - 0.5 * Math.cos(Math.PI * (i + 1.0) / (ov + 1.0)));
            }
            final int totalJendela = totalOut <= gen ? 1 : (int) ((totalOut - gen + step - 1) / step) + 1;
            final float[] accNum = new float[gen * 2];
            final float[] accDen = new float[gen];

            long pos = 0;
            int k = 0;
            int lastPct = -1;
            while (true) {
                cek();
                final boolean terakhir = pos + gen >= totalOut;
                float[] pcm = bacaDiResample(in, pos - pad, jendela, ratio, srcFrames, totalOut);
                float[] hasil = pisahkan(net, pcm, jendela, geser, bersih);
                // Tambahkan ke penampung dengan bobot (menanjak di awal, menurun di akhir potongan).
                for (int i = 0; i < gen; i++) {
                    float w = 1f;
                    if (k > 0 && i < ov) w = naik[i];
                    if (!terakhir && i >= step) w = Math.min(w, naik[gen - 1 - i]);
                    int src = (pad + i) * 2;
                    accNum[i * 2] += w * hasil[src];
                    accNum[i * 2 + 1] += w * hasil[src + 1];
                    accDen[i] += w;
                }

                // Bagian yang sudah final: 'step' sampel pertama (atau semua sisa pada potongan terakhir).
                final int n = terakhir ? (int) (totalOut - pos) : step;
                float[] inst = new float[n * 2];
                for (int i = 0; i < n; i++) {
                    float d = accDen[i];
                    inst[i * 2] = d > 0 ? accNum[i * 2] / d : 0f;
                    inst[i * 2 + 1] = d > 0 ? accNum[i * 2 + 1] / d : 0f;
                }
                tulisMp3(enc, out, keShort(inst, 0, n), n, mp3buf);
                if (outV != null) {
                    // Vokal = lagu asli dikurangi musik; lagu asli ada di pcm sejak frame 'pad'.
                    float[] vok = new float[n * 2];
                    System.arraycopy(pcm, pad * 2, vok, 0, n * 2);
                    for (int j = 0; j < n * 2; j++) vok[j] -= inst[j];
                    tulisMp3(encV, outV, keShort(vok, 0, n), n, mp3buf);
                }

                int pct = 20 + (int) ((k + 1L) * 80 / totalJendela);
                if (pct > 100) pct = 100;
                if (pct != lastPct && cb != null) {
                    lastPct = pct;
                    cb.onPercent(pct);
                }

                if (terakhir) break;

                // Geser penampung sebesar 'step' untuk potongan berikutnya.
                System.arraycopy(accNum, step * 2, accNum, 0, (gen - step) * 2);
                java.util.Arrays.fill(accNum, (gen - step) * 2, gen * 2, 0f);
                System.arraycopy(accDen, step, accDen, 0, gen - step);
                java.util.Arrays.fill(accDen, gen - step, gen, 0f);
                pos += step;
                k++;
            }

            out.write(mp3buf, 0, enc.flush(mp3buf));
            out.flush();
            tulisBingkaiVbr(enc, outWav, mp3buf);
            if (outV != null) {
                outV.write(mp3buf, 0, encV.flush(mp3buf));
                outV.flush();
                tulisBingkaiVbr(encV, outVokal, mp3buf);
            }
        }
        if (cb != null) cb.onPercent(100);
    }

    /** Geseran (frame) untuk rata-rata dua kali jalan: setengah langkah STFT (1024), jadi posisi bingkainya berbeda. */
    private static final int GESER_FRAME = 512;
    /** Bobot hasil tahap kedua (pembersih sisa vokal) terhadap hasil tahap pertama. */
    private static final float BOBOT_PEMBERSIH = 0.7f;

    /** Memisahkan musik dari satu jendela: satu atau dua kali jalan, ditambah pembersihan bila diminta. */
    private float[] pisahkan(MdxNet net, float[] pcm, int n, boolean geser,
                             boolean bersih) throws ModelException, CancelledException {
        float[] h = inferRata(net, pcm, n, geser);
        if (bersih) {
            cek();
            float[] h2 = inferRata(net, h, n, geser);
            final float b = BOBOT_PEMBERSIH;
            for (int i = 0; i < h.length; i++) h[i] = h[i] * (1f - b) + h2[i] * b;
        }
        return h;
    }

    /**
     * Bila geser aktif, model dijalankan dua kali: pada masukan asli dan pada masukan yang digeser
     * GESER_FRAME frame; hasilnya diselaraskan lalu dirata-ratakan. Artefak topeng spektrum
     * berbeda tiap posisi bingkai STFT, jadi rata-ratanya lebih bersih.
     * Hanya GESER_FRAME frame terakhir yang tidak dirata-ratakan (berada di wilayah konteks).
     */
    private float[] inferRata(MdxNet net, float[] x, int n, boolean geser)
            throws ModelException, CancelledException {
        float[] a = infer(net, x, n);
        if (!geser) return a;
        cek();
        final int g = GESER_FRAME;
        float[] xs = new float[n * 2];
        System.arraycopy(x, 0, xs, g * 2, (n - g) * 2);
        float[] b = infer(net, xs, n);
        for (int j = 0; j < n - g; j++) {
            a[j * 2] = 0.5f * (a[j * 2] + b[(j + g) * 2]);
            a[j * 2 + 1] = 0.5f * (a[j * 2 + 1] + b[(j + g) * 2 + 1]);
        }
        return a;
    }

    /** Menjalankan model pada n frame stereo (interleaved); hasilnya musik tanpa vokal, n frame. */
    private float[] infer(MdxNet net, float[] pcm, int n) throws ModelException, CancelledException {
        try {
            return net.pisah(pcm, n, this::cek);
        } catch (CancelledException e) {
            throw e;
        } catch (Throwable t) {
            throw new ModelException("model gagal berjalan: " + t);
        }
    }

    /**
     * Membaca n frame stereo pada 44100 Hz mulai frame 'from' (boleh negatif), dengan interpolasi
     * linear. Frame di luar 0..totalOut diisi nol.
     */
    private float[] bacaDiResample(RandomAccessFile in, long from, int n, double ratio,
                                   long srcFrames, long totalOut) throws IOException {
        float[] res = new float[n * 2];
        long lo = Math.max(0, from);
        long hi = Math.min(totalOut, from + n);
        if (hi <= lo) return res;

        long s0 = (long) Math.floor(lo * ratio);
        long s1 = (long) Math.ceil(hi * ratio) + 2;
        if (s1 > srcFrames) s1 = srcFrames;
        int cnt = (int) Math.max(1, s1 - s0);

        byte[] bytes = new byte[cnt * 8];
        in.seek(s0 * 8);
        int got = 0;
        while (got < bytes.length) {
            int r = in.read(bytes, got, bytes.length - got);
            if (r < 0) break;
            got += r;
        }
        int frames = got / 8;
        if (frames == 0) return res;
        float[] src = new float[frames * 2];
        ByteBuffer.wrap(bytes, 0, frames * 8).order(ByteOrder.LITTLE_ENDIAN)
                .asFloatBuffer().get(src);

        for (long g = lo; g < hi; g++) {
            double p = g * ratio - s0;
            int i0 = (int) p;
            double fr = p - i0;
            if (i0 >= frames) i0 = frames - 1;
            int i1 = Math.min(i0 + 1, frames - 1);
            int o = (int) (g - from) * 2;
            res[o] = (float) (src[i0 * 2] * (1 - fr) + src[i1 * 2] * fr);
            res[o + 1] = (float) (src[i0 * 2 + 1] * (1 - fr) + src[i1 * 2 + 1] * fr);
        }
        return res;
    }

    private LameEncoder buatEncoder(int vbrQ) throws ModelException {
        try {
            return new LameEncoder(MODEL_RATE, Math.max(0, Math.min(9, vbrQ)), MP3_QUALITAS);
        } catch (Throwable t) {
            throw new ModelException("penyandi MP3 tidak bisa dimuat: " + t);
        }
    }

    /** Menimpa bingkai kosong di awal berkas dengan bingkai Xing/LAME supaya durasi dan seek VBR benar. */
    private void tulisBingkaiVbr(LameEncoder enc, File f, byte[] buf) throws IOException {
        int n = enc.lameTag(buf);
        if (n > 0) {
            try (RandomAccessFile ra = new RandomAccessFile(f, "rw")) {
                ra.seek(0);
                ra.write(buf, 0, n);
            }
        }
    }

    private void tulisMp3(LameEncoder enc, OutputStream os, short[] pcm, int frames,
                          byte[] buf) throws IOException {
        int n = enc.encode(pcm, frames, buf);
        if (n > 0) os.write(buf, 0, n);
    }

    private short[] keShort(float[] a, int skipFrames, int keepFrames) {
        short[] r = new short[keepFrames * 2];
        int base = skipFrames * 2;
        for (int i = 0; i < r.length; i++) {
            long v = Math.round(a[base + i] * 32767.0);
            if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
            if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
            r[i] = (short) v;
        }
        return r;
    }


    // ------------------------------------------------------------------------------------
    // Model
    // ------------------------------------------------------------------------------------

    /** Menyalin model .onnx dari assets ke cache (sekali saja) supaya bisa dipetakan ke memori. */
    private File salinModel(Context ctx) throws Exception {
        String nama = null;
        String[] daftar = ctx.getAssets().list("");
        if (daftar != null) {
            for (String s : daftar) {
                if (s.endsWith(".onnx")) {
                    if (nama == null || s.contains("mdx")) nama = s;
                }
            }
        }
        if (nama == null) {
            throw new ModelException("berkas model tidak ada di dalam APK");
        }
        File dest = new File(ctx.getCacheDir(), PREFIX_CACHE + nama);

        // Hapus salinan model lama supaya cache tidak membengkak.
        File[] lama = ctx.getCacheDir().listFiles();
        if (lama != null) {
            for (File f : lama) {
                if (f.getName().startsWith("pakai_") && !f.getName().equals(dest.getName())) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            }
        }
        if (dest.exists() && dest.length() > 1024 * 1024) return dest;

        File tmp = new File(ctx.getCacheDir(), PREFIX_CACHE + nama + ".tmp");
        try (InputStream is = ctx.getAssets().open(nama);
             OutputStream os = new FileOutputStream(tmp)) {
            byte[] buf = new byte[256 * 1024];
            int r;
            while ((r = is.read(buf)) > 0) {
                cek();
                os.write(buf, 0, r);
            }
        }
        if (!tmp.renameTo(dest)) throw new ModelException("gagal menyiapkan model");
        return dest;
    }

    // ------------------------------------------------------------------------------------
    // Dekode lagu -> PCM float stereo (little endian), pada laju sampel asli
    // ------------------------------------------------------------------------------------

    /** @return {laju sampel, bagian tinggi jumlah frame, bagian rendah jumlah frame} */
    private int[] dekode(Context ctx, Uri input, File raw, Progress cb) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try (FileOutputStream fos = new FileOutputStream(raw)) {
            extractor.setDataSource(ctx, input, null);
            int track = -1;
            MediaFormat fmt = null;
            String mime = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) {
                    track = i;
                    fmt = f;
                    mime = m;
                    break;
                }
            }
            if (track < 0) throw new NoAudioException();
            extractor.selectTrack(track);

            int channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            int rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            long durationUs = fmt.containsKey(MediaFormat.KEY_DURATION)
                    ? fmt.getLong(MediaFormat.KEY_DURATION) : 0;

            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(fmt, null, null, 0);
            codec.start();

            int pcmEncoding = 2;
            long frames = 0;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false, outDone = false;
            int lastPct = -1;

            while (!outDone) {
                cek();
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = extractor.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, extractor.getSampleTime(), 0);
                            extractor.advance();
                        }
                    }
                }

                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    if (info.size > 0) {
                        ByteBuffer ob = codec.getOutputBuffer(oi);
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        byte[] data = new byte[info.size];
                        ob.get(data);
                        byte[] out = keStereoFloat(data, channels, pcmEncoding);
                        fos.write(out);
                        frames += out.length / 8;

                        if (durationUs > 0 && cb != null) {
                            int pct = (int) Math.min(20, info.presentationTimeUs * 20 / durationUs);
                            if (pct != lastPct) {
                                lastPct = pct;
                                cb.onPercent(pct);
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat nf = codec.getOutputFormat();
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
                        channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE))
                        rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (nf.containsKey(MediaFormat.KEY_PCM_ENCODING))
                        pcmEncoding = nf.getInteger(MediaFormat.KEY_PCM_ENCODING);
                }
            }
            if (frames <= 0) throw new NoAudioException();
            return new int[]{rate, (int) (frames >>> 32), (int) (frames & 0xFFFFFFFFL)};
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) { }
                try { codec.release(); } catch (Exception ignored) { }
            }
            extractor.release();
        }
    }

    /** PCM 16-bit atau float, n saluran -> float stereo (mono digandakan, >2 saluran: dua pertama). */
    private byte[] keStereoFloat(byte[] data, int channels, int encoding) {
        ByteBuffer in = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        boolean isFloat = encoding == PCM_FLOAT;
        int bps = isFloat ? 4 : 2;
        int frames = data.length / (bps * channels);
        ByteBuffer out = ByteBuffer.allocate(frames * 8).order(ByteOrder.LITTLE_ENDIAN);
        for (int f = 0; f < frames; f++) {
            float l = 0, r = 0;
            for (int c = 0; c < channels; c++) {
                float v = isFloat ? in.getFloat() : in.getShort() / 32768f;
                if (c == 0) l = v;
                if (c == 1) r = v;
            }
            if (channels == 1) r = l;
            out.putFloat(l);
            out.putFloat(r);
        }
        return out.array();
    }

    private byte[] wavHeader(long dataLen, int rate, int channels) {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'});
        b.putInt((int) (36 + dataLen));
        b.put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        b.putInt(16);
        b.putShort((short) 1);
        b.putShort((short) channels);
        b.putInt(rate);
        b.putInt(rate * channels * 2);
        b.putShort((short) (channels * 2));
        b.putShort((short) 16);
        b.put(new byte[]{'d', 'a', 't', 'a'});
        b.putInt((int) dataLen);
        return b.array();
    }
}
