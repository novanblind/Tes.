package com.novan.filemanagerpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Lingkaran kemajuan sederhana untuk persentase penyimpanan terpakai. */
class PieProgress @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val bar = 6f * density
    private val rect = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = bar
        color = 0x33FFFFFF
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = bar
        strokeCap = Paint.Cap.ROUND
        color = 0xFFFFFFFF.toInt()
    }

    var percent: Int = 0
        set(v) {
            field = v.coerceIn(0, 100)
            invalidate()
        }

    var full: Boolean = false
        set(v) {
            field = v
            arc.color = if (v) 0xFFFF5252.toInt() else 0xFFFFFFFF.toInt()
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val half = bar / 2f
        rect.set(half, half, width - half, height - half)
        canvas.drawArc(rect, 0f, 360f, false, track)
        if (percent > 0) canvas.drawArc(rect, -90f, 360f * percent / 100f, false, arc)
    }
}
