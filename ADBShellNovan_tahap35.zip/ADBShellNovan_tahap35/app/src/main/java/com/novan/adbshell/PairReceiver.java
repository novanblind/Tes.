package com.novan.adbshell;

import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class PairReceiver extends BroadcastReceiver {
    @Override public void onReceive(final Context ctx, Intent i) {
        Bundle r = RemoteInput.getResultsFromIntent(i);
        if (r == null) return;
        CharSequence cs = r.getCharSequence("code");
        if (cs == null) return;
        final String code = cs.toString().trim();
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                Context app = ctx.getApplicationContext();
                // Kode boleh diketik sebelum port ditemukan: tunggu sampai 25 detik.
                if (PairHelper.pairPort <= 0) {
                    PairHelper.say(app, "Kode diterima. Menunggu port pairing ditemukan...", false);
                    for (int k = 0; k < 50 && PairHelper.pairPort <= 0; k++) {
                        try { Thread.sleep(500); } catch (InterruptedException e) { break; }
                    }
                }
                if (PairHelper.pairPort <= 0) {
                    PairHelper.say(app, "Port pairing belum ditemukan. Pastikan layar Pasangkan dengan kode pairing "
                            + "masih terbuka, lalu ketik kode lagi.", true);
                    return;
                }
                PairHelper.pairAndConnect(app, PairHelper.pairPort, code);
            } finally {
                pr.finish();
            }
        }).start();
    }
}
