package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat

/**
 * Layar "Unduhan": unduhan yang sedang berjalan, yang sudah selesai, dan yang gagal.
 * Ketuk unduhan gagal/dibatalkan untuk mengunduh ulang; ketuk yang selesai untuk membuka berkasnya;
 * tekan lama untuk pilihan lain (hapus dari daftar, dll).
 */
class DownloadsActivity : Activity() {

    private class Row(val title: String, val detail: String, val desc: String)

    private lateinit var list: ListView
    private lateinit var summary: TextView
    private lateinit var empty: TextView
    private lateinit var filterBtn: Button
    private var filter = 0 // 0 semua, 1 berjalan, 2 menunggu, 3 selesai, 4 gagal
    private var entries: List<DownloadLog.Entry> = emptyList()
    private var rows: List<Row> = emptyList()
    private var lastSummary = ""
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1500L)
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = entries.getOrNull(position)?.id ?: position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_download, parent, false)
            val r = rows[position]
            v.findViewById<TextView>(R.id.dlItemTitle).text = r.title
            v.findViewById<TextView>(R.id.dlItemDetail).text = r.detail
            v.contentDescription = r.desc
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)
        ViewCompat.setAccessibilityHeading(findViewById(R.id.dlTitle), true)
        summary = findViewById(R.id.dlSummary)
        empty = findViewById(R.id.dlEmpty)
        list = findViewById(R.id.dlList)
        list.adapter = adapter
        list.emptyView = empty
        list.setOnItemClickListener { _, _, pos, _ -> entries.getOrNull(pos)?.let { onTap(it) } }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            entries.getOrNull(pos)?.let { showMenu(it) }
            true
        }
        findViewById<Button>(R.id.dlFilter).also { filterBtn = it }.setOnClickListener { chooseFilter() }
        findViewById<Button>(R.id.dlRetryAll).setOnClickListener { retryAll() }
        findViewById<Button>(R.id.dlClearAll).setOnClickListener { chooseClear() }
        findViewById<Button>(R.id.dlClose).setOnClickListener { finish() }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Downloads.onPermissionResult(this, requestCode, grantResults)
    }

    // ------------------------------------------------------------------ tampilan

    private fun statusName(e: DownloadLog.Entry) = when (e.status) {
        DownloadLog.QUEUED -> "Menunggu"
        DownloadLog.RUNNING -> "Berjalan"
        DownloadLog.DONE -> "Selesai"
        DownloadLog.FAILED -> "Gagal"
        else -> "Dibatalkan"
    }

    private fun buildRow(e: DownloadLog.Entry): Row {
        val name = e.title.ifBlank { if (e.playlist) "Playlist" else "Video" }
        val kind = if (e.playlist) "Playlist: " else ""
        val head = "${statusName(e)}: $kind$name"
        val body = when (e.status) {
            DownloadLog.RUNNING -> if (e.pct > 0) "${e.pct}%. ${e.text}" else e.text
            DownloadLog.FAILED -> e.text + if (!e.retry) " (kemungkinan tetap gagal bila diulang)" else ""
            else -> e.text
        }
        val action = when (e.status) {
            DownloadLog.FAILED, DownloadLog.CANCELLED -> "Ketuk dua kali untuk mengunduh ulang."
            DownloadLog.DONE -> if (e.uri != null) "Ketuk dua kali untuk membuka." else ""
            DownloadLog.RUNNING -> "Ketuk dua kali untuk membatalkan."
            else -> ""
        }
        val detail = if (action.isEmpty()) body else "$body\n$action"
        return Row(head, detail, "$head. $detail. Tekan lama untuk pilihan lain.")
    }

    private fun refresh() {
        val all = DownloadLog.list(this)
        val now = all.filter { matches(it) }
        val newRows = now.map { buildRow(it) }
        val same = newRows.size == rows.size &&
            newRows.indices.all { newRows[it].desc == rows[it].desc }
        entries = now
        if (!same) {
            rows = newRows
            adapter.notifyDataSetChanged()
        }
        val run = all.count { it.status == DownloadLog.RUNNING }
        val wait = all.count { it.status == DownloadLog.QUEUED }
        val ok = all.count { it.status == DownloadLog.DONE }
        val bad = all.count { it.status == DownloadLog.FAILED }
        val label = "Tampilkan: " + filterNames[filter] + ". Ketuk untuk mengganti."
        if (filterBtn.text.toString() != label) filterBtn.text = label
        val emptyText = emptyTexts[filter]
        if (empty.text.toString() != emptyText) empty.text = emptyText
        val s = "$run berjalan, $wait menunggu, $ok selesai, $bad gagal."
        if (s != lastSummary) {
            lastSummary = s
            summary.text = s
        }
    }

    // ------------------------------------------------------------------ aksi

    private fun onTap(e: DownloadLog.Entry) {
        when (e.status) {
            DownloadLog.FAILED, DownloadLog.CANCELLED -> retry(e)
            DownloadLog.DONE -> open(e)
            DownloadLog.RUNNING -> confirmCancel()
            else -> Toast.makeText(this, "Menunggu giliran. Unduhan berjalan satu per satu.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun retry(e: DownloadLog.Entry, quiet: Boolean = false) {
        DownloadLog.remove(this, e.id)
        val name = e.title.ifBlank { if (e.playlist) "playlist" else "video" }
        if (e.playlist) Downloads.requestPlaylist(this, e.url, e.title, e.key)
        else Downloads.request(this, e.url, e.title, e.key)
        if (!quiet) Toast.makeText(this, "Mengunduh ulang: $name", Toast.LENGTH_SHORT).show()
        handler.postDelayed({ refresh() }, 400L)
    }

    private fun open(e: DownloadLog.Entry) {
        val uri = e.uri
        if (uri.isNullOrEmpty()) {
            Toast.makeText(this, e.text.ifBlank { "Berkas sudah tersimpan." }, Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse(uri), e.mime ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka berkas ini.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Berkas tidak bisa dibuka. Mungkin sudah dihapus.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmCancel() {
        AlertDialog.Builder(this)
            .setTitle("Batalkan unduhan?")
            .setMessage("Unduhan yang sedang berjalan akan dihentikan.")
            .setPositiveButton("Batalkan unduhan") { _, _ ->
                DownloadService.cancelCurrent(this)
                handler.postDelayed({ refresh() }, 800L)
            }
            .setNegativeButton("Lanjutkan", null)
            .show()
    }

    private val filterNames = arrayOf("Semua", "Berjalan", "Menunggu", "Selesai", "Gagal")
    private val emptyTexts = arrayOf(
        "Belum ada unduhan. Unduhan yang berjalan, selesai, atau gagal akan muncul di sini.",
        "Tidak ada yang sedang diunduh.",
        "Tidak ada yang menunggu di antrean.",
        "Belum ada unduhan yang selesai.",
        "Tidak ada unduhan yang gagal."
    )

    private fun matches(e: DownloadLog.Entry) = when (filter) {
        1 -> e.status == DownloadLog.RUNNING
        2 -> e.status == DownloadLog.QUEUED
        3 -> e.status == DownloadLog.DONE
        4 -> e.status == DownloadLog.FAILED || e.status == DownloadLog.CANCELLED
        else -> true
    }

    private fun chooseFilter() {
        AlertDialog.Builder(this)
            .setTitle("Tampilkan unduhan")
            .setSingleChoiceItems(filterNames, filter) { d, which ->
                filter = which
                d.dismiss()
                rows = emptyList() // paksa daftar digambar ulang
                adapter.notifyDataSetChanged()
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun hasStorage(): Boolean =
        android.os.Build.VERSION.SDK_INT > 28 ||
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun retryAll() {
        val failed = DownloadLog.list(this).filter {
            it.status == DownloadLog.FAILED || it.status == DownloadLog.CANCELLED
        }.sortedBy { it.id }
        if (failed.isEmpty()) {
            Toast.makeText(this, "Tidak ada unduhan yang gagal.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!hasStorage()) {
            // Izin penyimpanan (Android 9 ke bawah) diminta dulu lewat satu unduhan.
            retry(failed.first())
            Toast.makeText(this, "Beri izin penyimpanan, lalu ketuk Ulangi semua yang gagal lagi.", Toast.LENGTH_LONG).show()
            return
        }
        failed.forEach { retry(it, quiet = true) }
        Toast.makeText(this, "Mengulang ${failed.size} unduhan.", Toast.LENGTH_SHORT).show()
    }

    private fun chooseClear() {
        val labels = arrayOf("Hapus yang selesai dari daftar", "Hapus semua riwayat", "Batal")
        AlertDialog.Builder(this)
            .setTitle("Hapus riwayat (berkas unduhan tetap ada)")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> { DownloadLog.clearFinished(this); refresh()
                        Toast.makeText(this, "Unduhan yang selesai dihapus dari daftar.", Toast.LENGTH_LONG).show() }
                    1 -> { DownloadLog.clearAll(this); refresh()
                        Toast.makeText(this, "Semua riwayat unduhan dihapus.", Toast.LENGTH_LONG).show() }
                }
            }
            .show()
    }

    private fun showMenu(e: DownloadLog.Entry) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (e.status == DownloadLog.FAILED || e.status == DownloadLog.CANCELLED || e.status == DownloadLog.DONE) {
            labels += "Unduh ulang"; acts += { retry(e) }
        }
        if (e.status == DownloadLog.DONE && !e.uri.isNullOrEmpty()) {
            labels += "Buka berkas"; acts += { open(e) }
        }
        if (e.status == DownloadLog.RUNNING) {
            labels += "Batalkan unduhan"; acts += { confirmCancel() }
        }
        if (e.status != DownloadLog.RUNNING) {
            labels += "Hapus dari daftar"
            acts += {
                DownloadLog.remove(this, e.id)
                refresh()
            }
        }
        labels += "Tutup"; acts += { }
        AlertDialog.Builder(this)
            .setTitle(e.title.ifBlank { "Unduhan" })
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }
}
