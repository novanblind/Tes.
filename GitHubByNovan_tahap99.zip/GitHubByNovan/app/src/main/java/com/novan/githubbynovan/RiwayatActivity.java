package com.novan.githubbynovan;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * Riwayat commit (seluruh repositori, satu folder, atau satu berkas) dan pengembalian
 * berkas ke versi lama. Mengembalikan = membuat commit baru yang isinya sama dengan versi
 * lama, jadi riwayat tidak pernah dihapus dan pengembalian itu sendiri bisa dibatalkan lagi.
 *
 * Extra: repo (user/nama), path (kosong = seluruh repositori), name (judul),
 * berkas (true bila path adalah satu berkas).
 */
public class RiwayatActivity extends BaseActivity {
    private static final int PER_HALAMAN = 30;
    private static final long MAKS_PULIH = 10L * 1024 * 1024;
    private static final long MAKS_LIHAT = 200L * 1024;

    private Ui ui;
    private String full, path, name, token;
    private boolean berkas;
    private int halaman = 1;
    private final JSONArray semua = new JSONArray();
    private boolean adaLagi;
    private volatile boolean sibuk;
    private int layar = 0; // 0 = daftar commit, 1 = rincian satu commit
    private JSONObject terpilih;
    private volatile boolean berhasilTerakhir;
    private volatile String hasilSha = "";
    private volatile boolean batal;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        Intent i = getIntent();
        full = i.getStringExtra("repo");
        path = i.getStringExtra("path");
        if (path == null) path = "";
        name = i.getStringExtra("name");
        if (name == null || name.isEmpty()) name = path.isEmpty() ? full : path;
        berkas = i.getBooleanExtra("berkas", false);
        tampilDaftar();
        muatHalaman();
    }

    @Override
    public void onBackPressed() {
        if (layar != 0) {
            tampilDaftar();
            return;
        }
        super.onBackPressed();
    }

    // ---------- pembantu teks ----------

    private static String tgl(String iso) {
        if (iso == null) return "";
        if (iso.length() < 16) return iso;
        return iso.substring(0, 10) + " " + iso.substring(11, 16);
    }

    private static String singkat(String sha) {
        return sha != null && sha.length() > 7 ? sha.substring(0, 7) : (sha == null ? "" : sha);
    }

    private static String namaDasar(String p) {
        int k = p.lastIndexOf('/');
        return k >= 0 ? p.substring(k + 1) : p;
    }

    private static String tanggalCommit(JSONObject c) {
        JSONObject ci = c.optJSONObject("commit");
        JSONObject cm = ci == null ? null : ci.optJSONObject("committer");
        return cm == null ? "" : cm.optString("date", "");
    }

    private static String pesanCommit(JSONObject c) {
        JSONObject ci = c.optJSONObject("commit");
        return ci == null ? "" : ci.optString("message", "");
    }

    private static String ringkas(int no, JSONObject c) {
        String pesan = pesanCommit(c);
        int nl = pesan.indexOf('\n');
        if (nl >= 0) pesan = pesan.substring(0, nl);
        if (pesan.length() > 80) pesan = pesan.substring(0, 80) + "...";
        return no + ". " + tgl(tanggalCommit(c)) + ", " + pesan + " (" + singkat(c.optString("sha", "")) + ")";
    }

    private static String labelStatus(String st) {
        if ("added".equals(st)) return "Baru";
        if ("modified".equals(st)) return "Diubah";
        if ("removed".equals(st)) return "Dihapus";
        if ("renamed".equals(st)) return "Diganti nama";
        if ("copied".equals(st)) return "Disalin";
        if ("changed".equals(st)) return "Berubah";
        return st;
    }

    // ---------- daftar commit ----------

    private void tampilDaftar() {
        layar = 0;
        terpilih = null;
        ui = new Ui(this, berkas ? "Riwayat berkas: " + name : "Riwayat commit: " + name);
        ui.label((path.isEmpty() ? "Seluruh repositori " + full : "Lokasi: " + path + " di " + full)
                + "\nWaktu memakai UTC. Ketuk satu commit untuk melihat rincian"
                + (berkas ? ", melihat isi, dan mengembalikan berkas ke versi itu."
                : " dan mengembalikan berkas yang berubah atau terhapus."));
        if (semua.length() == 0 && !sibuk && halaman > 1) ui.label("Tidak ada riwayat.");
        for (int k = 0; k < semua.length(); k++) {
            final JSONObject c = semua.optJSONObject(k);
            if (c == null) continue;
            ui.button(ringkas(k + 1, c), v -> tampilRincian(c));
        }
        if (adaLagi) ui.button("Muat " + PER_HALAMAN + " commit berikutnya", v -> muatHalaman());
        ui.button("Kembali", v -> finish());
    }

    private void muatHalaman() {
        if (sibuk) return;
        sibuk = true;
        ui.say("Memuat riwayat...");
        String url = Api.BASE + "/repos/" + full + "/commits?per_page=" + PER_HALAMAN + "&page=" + halaman
                + (path.isEmpty() ? "" : "&path=" + Api.enc(path));
        Api.request("GET", url, token, null, (ok, res) -> {
            sibuk = false;
            if (isFinishing()) return;
            if (!ok) {
                ui.say("Gagal memuat riwayat: " + res);
                return;
            }
            JSONArray a = Api.parseArr(res);
            for (int k = 0; k < a.length(); k++) {
                JSONObject c = a.optJSONObject(k);
                if (c != null) semua.put(c);
            }
            adaLagi = a.length() >= PER_HALAMAN;
            halaman++;
            if (layar != 0) return;
            tampilDaftar();
            ui.say(semua.length() + " commit dimuat.");
        });
    }

    // ---------- rincian satu commit ----------

    private void tampilRincian(final JSONObject c) {
        layar = 1;
        terpilih = c;
        final String sha = c.optString("sha", "");
        ui = new Ui(this, "Rincian commit " + singkat(sha));
        JSONObject ci = c.optJSONObject("commit");
        JSONObject au = ci == null ? null : ci.optJSONObject("author");
        String oleh = au == null ? "" : au.optString("name", "");
        ui.label("Tanggal: " + tgl(tanggalCommit(c)) + " UTC\nOleh: " + oleh + "\nSHA: " + sha
                + "\n\nPesan:\n" + pesanCommit(c));
        final String html = c.optString("html_url", "");
        if (berkas) {
            ui.button("1. Lihat isi berkas di versi ini", v -> lihatIsi(path, sha));
            ui.button("2. Kembalikan berkas ke versi ini", v -> konfirmasiPulih(path, sha,
                    singkat(sha) + " (" + tgl(tanggalCommit(c)) + ")"));
            ui.button("3. Salin SHA commit", v -> Ui.copy(this, "SHA commit", sha));
            ui.button("4. Salin tautan commit", v -> Ui.copy(this, "Tautan commit", html));
            ui.button("Kembali ke daftar", v -> tampilDaftar());
        } else {
            muatBerkasCommit(c, sha, html);
        }
    }

    private void muatBerkasCommit(final JSONObject c, final String sha, final String html) {
        ui.say("Memuat daftar berkas commit...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/commits/" + sha, token, null, (ok, res) -> {
            if (isFinishing() || layar != 1 || terpilih != c) return;
            if (!ok) {
                ui.say("Gagal memuat rincian commit: " + res);
                ui.button("Coba lagi", v -> tampilRincian(c));
                ui.button("Kembali ke daftar", v -> tampilDaftar());
                return;
            }
            JSONObject j = Api.parse(res);
            final JSONArray files = j.optJSONArray("files");
            JSONArray par = j.optJSONArray("parents");
            final String induk = par != null && par.length() > 0 && par.optJSONObject(0) != null
                    ? par.optJSONObject(0).optString("sha", "") : "";
            int n = files == null ? 0 : files.length();
            ui.progress("Selesai memuat.");
            ui.section("Berkas yang berubah (" + n + ")");
            if (n == 0) ui.label("GitHub tidak mengirim daftar berkas (mungkin commit penggabungan atau kosong).");
            int hapus = 0;
            for (int k = 0; k < n; k++) {
                final JSONObject f = files.optJSONObject(k);
                if (f == null) continue;
                String st = f.optString("status", "");
                if ("removed".equals(st)) hapus++;
                ui.button(labelStatus(st) + ": " + f.optString("filename", ""), v -> aksiBerkas(f, sha, induk));
            }
            if (n >= 300) ui.label("Catatan: GitHub hanya menampilkan 300 berkas pertama dari commit ini.");
            if (induk.isEmpty()) {
                ui.label("Commit ini adalah commit pertama, jadi tidak ada versi sebelumnya untuk dikembalikan.");
            } else if (hapus > 0) {
                final List<String> daftar = new ArrayList<>();
                for (int k = 0; k < n; k++) {
                    JSONObject f = files.optJSONObject(k);
                    if (f != null && "removed".equals(f.optString("status", ""))) {
                        daftar.add(f.optString("filename", ""));
                    }
                }
                ui.button("Pulihkan semua berkas yang dihapus di commit ini (" + hapus + ")", v ->
                        ui.confirm("Pulihkan " + daftar.size() + " berkas?",
                                "Setiap berkas dibuat ulang dengan isi sebelum commit ini. Tiap berkas menjadi satu commit baru, "
                                        + "jadi bisa memakan waktu bila banyak. Riwayat lama tetap ada.",
                                "pulihkan semua", () -> pulihkanBanyak(daftar, induk, "sebelum " + singkat(sha))));
            }
            ui.button("Salin SHA commit", v -> Ui.copy(this, "SHA commit", sha));
            ui.button("Salin tautan commit", v -> Ui.copy(this, "Tautan commit", html));
            ui.button("Kembali ke daftar", v -> tampilDaftar());
        });
    }

    private void aksiBerkas(final JSONObject f, final String sha, final String induk) {
        final String st = f.optString("status", "");
        final String nama = f.optString("filename", "");
        final String lama = "renamed".equals(st) ? f.optString("previous_filename", nama) : nama;
        String info;
        if ("added".equals(st)) {
            info = "Berkas ini baru dibuat di commit ini, jadi tidak ada versi sebelumnya.";
        } else if ("removed".equals(st)) {
            info = "Berkas ini dihapus di commit ini. Pilih Kembalikan untuk membuatnya ulang seperti sebelum dihapus.";
        } else if ("renamed".equals(st)) {
            info = "Berkas ini diganti nama dari " + lama + ". Mengembalikan akan membuat kembali berkas dengan nama lama; "
                    + "berkas bernama baru tetap ada.";
        } else {
            info = "Berkas ini diubah di commit ini. Kembalikan akan menimpa isi sekarang dengan isi sebelum commit ini.";
        }
        List<ApkTools.Btn> l = new ArrayList<>();
        if (!"added".equals(st) && !induk.isEmpty()) {
            l.add(ApkTools.b("Kembalikan ke versi sebelum commit ini", () ->
                    konfirmasiPulih(lama, induk, "sebelum " + singkat(sha))));
            l.add(ApkTools.b("Lihat isi versi sebelum commit ini", () -> lihatIsi(lama, induk)));
        }
        if (!"removed".equals(st)) {
            l.add(ApkTools.b("Lihat isi versi sesudah commit ini", () -> lihatIsi(nama, sha)));
        }
        l.add(ApkTools.b("Buka riwayat berkas ini", () -> startActivity(new Intent(this, RiwayatActivity.class)
                .putExtra("repo", full).putExtra("path", nama).putExtra("name", namaDasar(nama))
                .putExtra("berkas", true))));
        ApkTools.dialog(this, "Berkas: " + nama, info, l, "kembali", null);
    }

    // ---------- lihat isi ----------

    private void lihatIsi(final String target, final String ref) {
        if (sibuk) {
            ui.say("Masih ada proses berjalan. Tunggu sebentar.");
            return;
        }
        sibuk = true;
        ui.say("Membaca isi berkas...");
        Api.POOL.execute(() -> {
            String teks = "";
            Api.Result r = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/contents/" + Api.enc(target)
                    + "?ref=" + ref, token, null);
            if (!r.ok) {
                teks = r.text.contains("Kode: 404") ? "Berkas tidak ada di versi itu." : "Gagal: " + r.text;
            } else {
                JSONObject j = Api.parse(r.text);
                long ukuran = j.optLong("size", 0);
                String isi = j.optString("content", "").replace("\n", "");
                if (ukuran > MAKS_LIHAT || (isi.isEmpty() && ukuran > 0)) {
                    teks = "Berkas berukuran " + Ui.size(ukuran) + ", terlalu besar untuk ditampilkan di sini. "
                            + "Anda tetap bisa mengembalikannya.";
                } else {
                    String s = null;
                    try {
                        s = new String(Base64.decode(isi, Base64.DEFAULT), "UTF-8");
                    } catch (Exception ignored) { }
                    if (s == null) {
                        teks = "Isi tidak bisa dibaca sebagai teks.";
                    } else if (s.indexOf('\u0000') >= 0) {
                        teks = "Berkas biner, tidak bisa ditampilkan sebagai teks.";
                    } else if (s.length() > 20000) {
                        teks = s.substring(0, 20000) + "\n\n[dipotong, hanya 20000 karakter pertama]";
                    } else {
                        teks = s.isEmpty() ? "[berkas kosong]" : s;
                    }
                }
            }
            final String ft = teks;
            runOnUiThread(() -> {
                sibuk = false;
                if (isFinishing()) return;
                ApkTools.dialog(this, "Isi " + namaDasar(target) + " (" + singkat(ref) + ")", ft,
                        ApkTools.list(ApkTools.keep("salin isi", () -> Ui.copy(this, "Isi berkas", ft))),
                        "tutup", null, 15);
            });
        });
    }

    // ---------- kembalikan versi lama ----------

    private void konfirmasiPulih(final String target, final String ref, final String label) {
        ui.confirm("Kembalikan berkas?",
                "Berkas " + target + " akan dibuat ulang atau ditimpa dengan versi " + label + ". "
                        + "Ini membuat satu commit baru di cabang bawaan. Riwayat lama tetap ada, "
                        + "jadi perubahan ini bisa dibatalkan lagi lewat riwayat.",
                "kembalikan", () -> pulihkan(target, ref, label));
    }

    private void pulihkan(final String target, final String ref, final String label) {
        if (sibuk) {
            ui.say("Masih ada proses berjalan. Tunggu sebentar.");
            return;
        }
        sibuk = true;
        ui.progress("Mengembalikan " + target + "...");
        Api.POOL.execute(() -> {
            final String hasil = pulihkanSinkron(target, ref, label);
            final boolean ok = berhasilTerakhir;
            final String sha = hasilSha;
            runOnUiThread(() -> {
                sibuk = false;
                if (isFinishing()) return;
                if (ok && berkas && target.equals(path) && !sha.isEmpty()) {
                    setResult(RESULT_OK, new Intent().putExtra("sha", sha));
                }
                ui.say(hasil);
            });
        });
    }

    /** Hanya dari thread latar. Mengisi berhasilTerakhir dan hasilSha. */
    private String pulihkanSinkron(String target, String ref, String label) {
        berhasilTerakhir = false;
        hasilSha = "";
        String urlTarget = Api.BASE + "/repos/" + full + "/contents/" + Api.enc(target);
        Api.Result lama = Api.requestSync("GET", urlTarget + "?ref=" + ref, token, null);
        if (!lama.ok) {
            if (lama.text.contains("Kode: 404")) return "Berkas " + target + " tidak ada di versi itu.";
            return "Gagal membaca versi lama: " + lama.text;
        }
        JSONObject jl = Api.parse(lama.text);
        String blobLama = jl.optString("sha", "");
        if (blobLama.isEmpty()) return "Jalur " + target + " bukan berkas.";
        long ukuran = jl.optLong("size", 0);
        if (ukuran > MAKS_PULIH) {
            return "Berkas lebih dari 10 MB, terlalu besar untuk dikembalikan dari aplikasi.";
        }
        String isi = jl.optString("content", "").replace("\n", "");
        if (isi.isEmpty() && ukuran > 0) {
            Api.Result b = Api.requestSync("GET", Api.BASE + "/repos/" + full + "/git/blobs/" + blobLama,
                    token, null);
            if (!b.ok) return "Gagal membaca isi berkas: " + b.text;
            isi = Api.parse(b.text).optString("content", "").replace("\n", "");
        }
        Api.Result kini = Api.requestSync("GET", urlTarget, token, null);
        String shaKini = "";
        if (kini.ok) {
            shaKini = Api.parse(kini.text).optString("sha", "");
            if (!shaKini.isEmpty() && shaKini.equals(blobLama)) {
                berhasilTerakhir = true;
                hasilSha = shaKini;
                return "Isi " + target + " sudah sama dengan versi itu. Tidak ada yang diubah.";
            }
        } else if (!kini.text.contains("Kode: 404")) {
            return "Gagal memeriksa berkas saat ini: " + kini.text;
        }
        JSONObject body = Api.o("message", "Kembalikan " + target + " ke versi " + label, "content", isi);
        try {
            if (!shaKini.isEmpty()) body.put("sha", shaKini);
        } catch (Exception ignored) { }
        Api.Result r = Api.requestSync("PUT", urlTarget, token, body.toString());
        if (!r.ok) return "Gagal mengembalikan " + target + ": " + r.text;
        JSONObject jc = Api.parse(r.text).optJSONObject("content");
        hasilSha = jc == null ? "" : jc.optString("sha", "");
        berhasilTerakhir = true;
        return "Berkas " + target + " dikembalikan ke versi " + label + ".";
    }

    private void pulihkanBanyak(final List<String> daftar, final String induk, final String label) {
        if (sibuk) {
            ui.say("Masih ada proses berjalan. Tunggu sebentar.");
            return;
        }
        sibuk = true;
        batal = false;
        final TextView tv = new TextView(this);
        tv.setTextSize(17);
        tv.setText("Mulai memulihkan " + daftar.size() + " berkas...");
        tv.setPadding(Ui.dpOf(this, 20), Ui.dpOf(this, 16), Ui.dpOf(this, 20), Ui.dpOf(this, 8));
        final AlertDialog d = new AlertDialog.Builder(this).setTitle("Memulihkan berkas").setView(tv)
                .setCancelable(false)
                .setNegativeButton("hentikan", (x, w) -> batal = true).show();
        try {
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
        } catch (Exception ignored) { }
        Api.POOL.execute(() -> {
            int sukses = 0, gagal = 0;
            StringBuilder rinci = new StringBuilder();
            for (int k = 0; k < daftar.size() && !batal; k++) {
                final String f = daftar.get(k);
                final int no = k + 1;
                runOnUiThread(() -> tv.setText("Memulihkan " + no + " dari " + daftar.size() + ":\n" + f));
                String m = pulihkanSinkron(f, induk, label);
                if (berhasilTerakhir) {
                    sukses++;
                } else {
                    gagal++;
                    if (rinci.length() < 1200) rinci.append(f).append(": ").append(m).append("\n");
                }
            }
            final int fs = sukses, fg = gagal;
            final boolean henti = batal;
            final String fr = rinci.toString();
            runOnUiThread(() -> {
                sibuk = false;
                try { d.dismiss(); } catch (Exception ignored) { }
                if (isFinishing()) return;
                String ringkasan = "Berhasil: " + fs + "\nGagal: " + fg
                        + (henti ? "\n\nDihentikan sebelum semua berkas diproses." : "")
                        + (fr.isEmpty() ? "" : "\n\nRincian gagal:\n" + fr);
                ApkTools.dialog(this, "Pemulihan selesai", ringkasan, new ArrayList<ApkTools.Btn>(), "tutup", null);
            });
        });
    }
}
