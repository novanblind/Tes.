package org.telegram.messenger;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Novan Tel - kategori halaman utama (tahap 22).
 *
 * Daftar obrolan mendapat tab: Semua Obrolan, Grup, Pribadi, Channel (urutan itu), memakai mesin folder obrolan bawaan
 * Telegram, jadi ketuk nama tab dan usap dua jari kiri/kanan untuk pindah, serta hitungan belum dibaca per tab,
 * semuanya perilaku asli Telegram yang sudah ramah pembaca layar.
 *
 * Tiga folder itu dipasang sebagai folder LOKAL (tidak dikirim ke server): setiap daftar folder dimuat atau diperbarui,
 * kelas ini memastikan urutannya benar. Bila Anda sudah punya folder yang jenisnya sama persis (misalnya folder Grup yang
 * hanya berisi grup), folder itu dipakai ulang dan tidak digandakan.
 *
 * SEMUA akses ke bagian dalam Telegram (MessagesController dan DialogFilter) lewat refleksi dan dibungkus try/catch, jadi
 * bila Telegram mengubah nama bidangnya, build tetap berhasil dan fitur ini hanya melapor "gagal" di Pengaturan Novan Tel.
 */
public final class NovanKategori implements NotificationCenter.NotificationCenterDelegate {

    /** Bawaan build (novan-mod.properties: kategori_utama). Bisa diganti di Pengaturan Novan Tel. */
    public static final boolean BAWAAN = __KATEGORI_UTAMA__;

    public static final String KUNCI = "kategori_utama";
    public static final String KUNCI_STATUS = "kategori_status";

    // id folder lokal: jauh di atas id server (yang kecil dan naik satu-satu), di bawah folder bawaan "Semua Obrolan" (Integer.MAX_VALUE)
    private static final int ID_GRUP = Integer.MAX_VALUE - 31;
    private static final int ID_PRIBADI = Integer.MAX_VALUE - 32;
    private static final int ID_CHANNEL = Integer.MAX_VALUE - 33;
    private static final int LOCAL_ID_DASAR = 880000;

    private static final NovanKategori PENGAMAT = new NovanKategori();
    private static final Handler UTAMA = new Handler(Looper.getMainLooper());

    private static volatile boolean sudahMulai = false;
    private static volatile boolean sedangMengubah = false;
    private static int idFolderDiperbarui = -1;
    private static int idButuhMuatUlang = -1;

    private NovanKategori() {
    }

    // ------------------------------------------------------------------ pintu masuk

    /** Dipanggil dari NovanMod.muat(): daftar pengamat sekali, lalu terapkan pada semua akun. */
    public static void mulai() {
        if (sudahMulai) {
            return;
        }
        sudahMulai = true;
        UTAMA.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    idFolderDiperbarui = NotificationCenter.class.getField("dialogFiltersUpdated").getInt(null);
                } catch (Throwable t) {
                    catatStatus("Gagal: kejadian pembaruan folder tidak ditemukan di kode Telegram");
                    return;
                }
                try {
                    idButuhMuatUlang = NotificationCenter.class.getField("dialogsNeedReload").getInt(null);
                } catch (Throwable ignored) {
                    idButuhMuatUlang = -1;
                }
                try {
                    for (int a = 0; a < UserConfig.MAX_ACCOUNT_COUNT; a++) {
                        NotificationCenter.getInstance(a).addObserver(PENGAMAT, idFolderDiperbarui);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal mendaftarkan pengamat folder: " + t);
                    return;
                }
                terapkanSemua();
                UTAMA.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        terapkanSemua();
                    }
                }, 8000);
            }
        }, 2500);
    }

    /** Terapkan (atau lepas, bila dimatikan) pada semua akun yang sedang masuk. Aman dipanggil dari thread mana pun. */
    public static void terapkanSemua() {
        UTAMA.post(new Runnable() {
            @Override
            public void run() {
                try {
                    boolean nyala = nyala();
                    String hasil = null;
                    for (int a = 0; a < UserConfig.MAX_ACCOUNT_COUNT; a++) {
                        if (!UserConfig.getInstance(a).isClientActivated()) {
                            continue;
                        }
                        String s = nyala ? pasang(a) : lepas(a);
                        if (hasil == null) {
                            hasil = s;
                        }
                    }
                    if (hasil != null) {
                        catatStatus(hasil);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal: " + t);
                }
            }
        });
    }

    @Override
    public void didReceivedNotification(int id, int account, Object... args) {
        if (id != idFolderDiperbarui || sedangMengubah) {
            return;
        }
        final int akun = account;
        UTAMA.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String s = nyala() ? pasang(akun) : lepas(akun);
                    if (s != null) {
                        catatStatus(s);
                    }
                } catch (Throwable t) {
                    catatStatus("Gagal: " + t);
                }
            }
        });
    }

    // ------------------------------------------------------------------ pilihan dan status

    public static boolean nyala() {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null) {
                return BAWAAN;
            }
            return c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE).getBoolean(KUNCI, BAWAAN);
        } catch (Throwable t) {
            return BAWAAN;
        }
    }

    public static String status() {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null) {
                return "";
            }
            return c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE).getString(KUNCI_STATUS, "belum dijalankan");
        } catch (Throwable t) {
            return "";
        }
    }

    private static void catatStatus(String s) {
        try {
            Context c = ApplicationLoader.applicationContext;
            if (c == null || s == null) {
                return;
            }
            SharedPreferences p = c.getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE);
            if (!s.equals(p.getString(KUNCI_STATUS, ""))) {
                p.edit().putString(KUNCI_STATUS, s).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ inti: susun ulang daftar folder

    private static int konstanta(String nama, int bawaan) {
        try {
            Field f = MessagesController.class.getField(nama);
            return f.getInt(null);
        } catch (Throwable t) {
            return bawaan;
        }
    }

    private static Field cariBidang(Class<?> k, String nama) {
        for (Class<?> c = k; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(nama);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
            } catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    private static Object nilai(Object o, String nama) {
        try {
            Field f = cariBidang(o.getClass(), nama);
            return f == null ? null : f.get(o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static int angka(Object o, String nama, int bawaan) {
        try {
            Field f = cariBidang(o.getClass(), nama);
            if (f != null && f.getType() == int.class) {
                return f.getInt(o);
            }
        } catch (Throwable ignored) {
        }
        return bawaan;
    }

    private static boolean setAngka(Object o, String nama, int v) {
        try {
            Field f = cariBidang(o.getClass(), nama);
            if (f != null && f.getType() == int.class) {
                f.setInt(o, v);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static boolean setNama(Object folder, String nama) {
        try {
            Field f = cariBidang(folder.getClass(), "name");
            if (f == null) {
                return false;
            }
            Class<?> t = f.getType();
            if (t == String.class || t == CharSequence.class) {
                f.set(folder, nama);
                return true;
            }
            // Telegram terbaru memakai tipe TL (teks dengan entitas) untuk judul folder
            Constructor<?> k = t.getDeclaredConstructor();
            k.setAccessible(true);
            Object w = k.newInstance();
            Field tx = cariBidang(t, "text");
            if (tx == null) {
                return false;
            }
            tx.set(w, nama);
            Field en = cariBidang(t, "entities");
            if (en != null && en.get(w) == null && List.class.isAssignableFrom(en.getType())) {
                en.set(w, new ArrayList<Object>());
            }
            f.set(folder, w);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean adalahBawaan(Object folder) {
        try {
            Method m = folder.getClass().getMethod("isDefault");
            Object r = m.invoke(folder);
            if (r instanceof Boolean) {
                return (Boolean) r;
            }
        } catch (Throwable ignored) {
        }
        return angka(folder, "id", 0) == Integer.MAX_VALUE;
    }

    private static boolean buatanKita(Object folder) {
        int id = angka(folder, "id", 0);
        return id == ID_GRUP || id == ID_PRIBADI || id == ID_CHANNEL;
    }

    private static boolean kosong(Object koleksi) {
        if (koleksi == null) {
            return true;
        }
        try {
            if (koleksi instanceof java.util.Collection) {
                return ((java.util.Collection<?>) koleksi).isEmpty();
            }
            Method m = koleksi.getClass().getMethod("size");
            Object r = m.invoke(koleksi);
            return !(r instanceof Integer) || (Integer) r == 0;
        } catch (Throwable t) {
            return true;
        }
    }

    /** Jenis folder: 1 Grup, 2 Pribadi, 3 Channel, 0 bukan salah satunya (ada pengecualian atau pilihan manual). */
    private static int jenis(Object folder) {
        int bendera = angka(folder, "flags", -1);
        if (bendera < 0) {
            return 0;
        }
        final int kontak = konstanta("DIALOG_FILTER_FLAG_CONTACTS", 1);
        final int bukanKontak = konstanta("DIALOG_FILTER_FLAG_NON_CONTACTS", 2);
        final int grup = konstanta("DIALOG_FILTER_FLAG_GROUPS", 4);
        final int kanal = konstanta("DIALOG_FILTER_FLAG_CHANNELS", 8);
        final int bot = konstanta("DIALOG_FILTER_FLAG_BOTS", 16);
        final int kecualiTenang = konstanta("DIALOG_FILTER_FLAG_EXCLUDE_MUTED", 32);
        final int kecualiBaca = konstanta("DIALOG_FILTER_FLAG_EXCLUDE_READ", 64);
        final int kecualiArsip = konstanta("DIALOG_FILTER_FLAG_EXCLUDE_ARCHIVED", 128);
        if ((bendera & (kecualiTenang | kecualiBaca | kecualiArsip)) != 0) {
            return 0;
        }
        if (!kosong(nilai(folder, "alwaysShow")) || !kosong(nilai(folder, "neverShow"))) {
            return 0;
        }
        int jenisObrolan = bendera & (kontak | bukanKontak | grup | kanal | bot);
        if (jenisObrolan == grup) {
            return 1;
        }
        if (jenisObrolan == kanal) {
            return 3;
        }
        if (jenisObrolan == (kontak | bukanKontak) || jenisObrolan == (kontak | bukanKontak | bot)) {
            return 2;
        }
        return 0;
    }

    private static int jenisBuatanKita(Object folder) {
        int id = angka(folder, "id", 0);
        if (id == ID_GRUP) {
            return 1;
        }
        if (id == ID_PRIBADI) {
            return 2;
        }
        if (id == ID_CHANNEL) {
            return 3;
        }
        return 0;
    }

    private static Object buatFolder(Class<?> kelas, int jenis) {
        try {
            Constructor<?> k = kelas.getDeclaredConstructor();
            k.setAccessible(true);
            Object f = k.newInstance();
            int id;
            int bendera;
            String nama;
            if (jenis == 1) {
                id = ID_GRUP;
                bendera = konstanta("DIALOG_FILTER_FLAG_GROUPS", 4);
                nama = "Grup";
            } else if (jenis == 2) {
                id = ID_PRIBADI;
                bendera = konstanta("DIALOG_FILTER_FLAG_CONTACTS", 1) | konstanta("DIALOG_FILTER_FLAG_NON_CONTACTS", 2)
                        | konstanta("DIALOG_FILTER_FLAG_BOTS", 16);
                nama = "Pribadi";
            } else {
                id = ID_CHANNEL;
                bendera = konstanta("DIALOG_FILTER_FLAG_CHANNELS", 8);
                nama = "Channel";
            }
            if (!setAngka(f, "id", id) || !setAngka(f, "flags", bendera) || !setNama(f, nama)) {
                return null;
            }
            setAngka(f, "localId", LOCAL_ID_DASAR + jenis);
            return f;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Folder bawaan "Semua Obrolan" (id 0). Telegram hanya mengisinya bila akun punya folder; bila belum, kita buatkan lokal. */
    private static Object buatFolderBawaan(Class<?> kelas) {
        try {
            Constructor<?> k = kelas.getDeclaredConstructor();
            k.setAccessible(true);
            Object f = k.newInstance();
            int bendera = konstanta("DIALOG_FILTER_FLAG_CONTACTS", 1) | konstanta("DIALOG_FILTER_FLAG_NON_CONTACTS", 2)
                    | konstanta("DIALOG_FILTER_FLAG_GROUPS", 4) | konstanta("DIALOG_FILTER_FLAG_CHANNELS", 8)
                    | konstanta("DIALOG_FILTER_FLAG_BOTS", 16);
            if (!setAngka(f, "id", 0) || !setAngka(f, "flags", bendera) || !setNama(f, "Semua Obrolan")) {
                return null;
            }
            return f;
        } catch (Throwable t) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<Object> daftarFolder(MessagesController mc) {
        try {
            Field f = cariBidang(MessagesController.class, "dialogFilters");
            if (f == null) {
                return null;
            }
            Object o = f.get(mc);
            return o instanceof ArrayList ? (ArrayList<Object>) o : null;
        } catch (Throwable t) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private static SparseArray<Object> petaFolder(MessagesController mc) {
        try {
            Field f = cariBidang(MessagesController.class, "dialogFiltersById");
            if (f == null) {
                return null;
            }
            Object o = f.get(mc);
            return o instanceof SparseArray ? (SparseArray<Object>) o : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Class<?> kelasFolder() {
        try {
            return Class.forName("org.telegram.messenger.MessagesController$DialogFilter");
        } catch (Throwable t) {
            return null;
        }
    }

    /** Susun daftar folder: Semua Obrolan, Grup, Pribadi, Channel, lalu folder lain milik pengguna. Mengembalikan teks status. */
    private static String pasang(int akun) {
        MessagesController mc = MessagesController.getInstance(akun);
        ArrayList<Object> daftar = daftarFolder(mc);
        if (daftar == null) {
            return "Gagal: daftar folder Telegram tidak ditemukan (nama bidang berubah)";
        }
        Class<?> kelas = kelasFolder();
        if (kelas == null) {
            return "Gagal: kelas DialogFilter tidak ditemukan";
        }
        Object bawaan = null;
        ArrayList<Object> lain = new ArrayList<Object>();
        for (Object f : new ArrayList<Object>(daftar)) {
            if (adalahBawaan(f)) {
                if (bawaan == null) {
                    bawaan = f;
                }
            } else {
                lain.add(f);
            }
        }
        if (bawaan == null) {
            bawaan = buatFolderBawaan(kelas);
            if (bawaan == null) {
                return "Gagal: folder Semua Obrolan tidak bisa dibuat (bidang id, flags, atau name di DialogFilter berubah)";
            }
        }
        Object[] pilih = new Object[4];
        for (Object f : lain) {
            if (buatanKita(f)) {
                continue;
            }
            int j = jenis(f);
            if (j > 0 && pilih[j] == null) {
                pilih[j] = f;
            }
        }
        for (Object f : lain) {
            if (!buatanKita(f)) {
                continue;
            }
            int j = jenisBuatanKita(f);
            if (j > 0 && pilih[j] == null) {
                pilih[j] = f;
            }
        }
        for (int j = 1; j <= 3; j++) {
            if (pilih[j] == null) {
                pilih[j] = buatFolder(kelas, j);
                if (pilih[j] == null) {
                    return "Gagal: folder lokal tidak bisa dibuat (bidang id, flags, atau name di DialogFilter berubah)";
                }
            }
        }
        ArrayList<Object> baru = new ArrayList<Object>();
        baru.add(bawaan);
        baru.add(pilih[1]);
        baru.add(pilih[2]);
        baru.add(pilih[3]);
        for (Object f : lain) {
            if (f == pilih[1] || f == pilih[2] || f == pilih[3]) {
                continue;
            }
            if (buatanKita(f)) {
                continue; // sisa buatan kita yang sudah tergantikan folder pengguna
            }
            baru.add(f);
        }
        String ringkas = ringkasan(pilih);
        if (samaUrutan(daftar, baru)) {
            return ringkas;
        }
        sedangMengubah = true;
        try {
            SparseArray<Object> peta = petaFolder(mc);
            if (peta != null) {
                for (Object f : daftar) {
                    if (buatanKita(f) && !baru.contains(f)) {
                        peta.remove(angka(f, "id", -1));
                    }
                }
                for (Object f : baru) {
                    if (buatanKita(f)) {
                        peta.put(angka(f, "id", -1), f);
                    }
                }
            }
            for (int j = 1; j <= 3; j++) {
                if (buatanKita(pilih[j])) {
                    setAngka(pilih[j], "order", angka(bawaan, "order", 0) + j);
                }
            }
            daftar.clear();
            daftar.addAll(baru);
            segarkan(mc, akun);
        } finally {
            sedangMengubah = false;
        }
        return ringkas;
    }

    private static String ringkasan(Object[] pilih) {
        int sendiri = 0;
        for (int j = 1; j <= 3; j++) {
            if (!buatanKita(pilih[j])) {
                sendiri++;
            }
        }
        String s = "Nyala: tab Grup, Pribadi, Channel terpasang";
        if (sendiri > 0) {
            s += " (" + sendiri + " memakai folder buatan Anda yang jenisnya sama)";
        }
        return s;
    }

    private static boolean samaUrutan(ArrayList<Object> a, ArrayList<Object> b) {
        if (a.size() != b.size()) {
            return false;
        }
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i) != b.get(i)) {
                return false;
            }
        }
        return true;
    }

    /** Matikan: buang tiga folder lokal. Folder buatan pengguna tidak disentuh. */
    private static String lepas(int akun) {
        MessagesController mc = MessagesController.getInstance(akun);
        ArrayList<Object> daftar = daftarFolder(mc);
        if (daftar == null) {
            return "Mati";
        }
        boolean ada = false;
        for (Object f : daftar) {
            if (buatanKita(f)) {
                ada = true;
            }
        }
        if (!ada) {
            return "Mati";
        }
        sedangMengubah = true;
        try {
            SparseArray<Object> peta = petaFolder(mc);
            for (int i = daftar.size() - 1; i >= 0; i--) {
                Object f = daftar.get(i);
                if (buatanKita(f)) {
                    daftar.remove(i);
                    if (peta != null) {
                        peta.remove(angka(f, "id", -1));
                    }
                }
            }
            segarkan(mc, akun);
        } finally {
            sedangMengubah = false;
        }
        return "Mati";
    }

    /** Hitung ulang isi tiap folder lalu minta layar daftar obrolan menggambar ulang tab. */
    private static void segarkan(MessagesController mc, int akun) {
        try {
            for (Method m : MessagesController.class.getDeclaredMethods()) {
                if ("sortDialogs".equals(m.getName()) && m.getParameterTypes().length == 1) {
                    m.setAccessible(true);
                    m.invoke(mc, new Object[]{null});
                    break;
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            if (idFolderDiperbarui >= 0) {
                NotificationCenter.getInstance(akun).postNotificationName(idFolderDiperbarui);
            }
            if (idButuhMuatUlang >= 0) {
                NotificationCenter.getInstance(akun).postNotificationName(idButuhMuatUlang);
            }
        } catch (Throwable ignored) {
        }
    }
}
