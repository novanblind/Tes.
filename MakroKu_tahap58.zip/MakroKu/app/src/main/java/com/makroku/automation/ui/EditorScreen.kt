package com.makroku.automation.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.makroku.automation.MakroApp
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.model.*
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Papan klip dalam aplikasi untuk menyalin/memotong/menempel pemicu, batasan, dan aksi. */
object ItemClipboard {
    var item: JsonObject? by mutableStateOf(null)
    /** Isi papan klip bila yang disalin lebih dari satu item (mode pilih beberapa). */
    var many: List<JsonObject> by mutableStateOf(emptyList())
}

private fun <T> toJsonList(ser: kotlinx.serialization.KSerializer<T>, items: List<T>): List<JsonObject> =
    items.map { AppJson.encodeToJsonElement(ser, it).jsonObject }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(repo: MacroRepository, macroId: Long?, onClose: () -> Unit) {
    val existing = remember { macroId?.let { repo.find(it) } }
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "Umum") }
    var constraintAny by remember { mutableStateOf(existing?.constraintAny ?: false) }
    val triggers = remember {
        mutableStateListOf<JsonObject>().apply { existing?.let { addAll(toJsonList(MacroTrigger.serializer(), it.triggers)) } }
    }
    val actions = remember {
        mutableStateListOf<JsonObject>().apply { existing?.let { addAll(toJsonList(MacroAction.serializer(), it.actions)) } }
    }
    val constraints = remember {
        mutableStateListOf<JsonObject>().apply { existing?.let { addAll(toJsonList(MacroConstraint.serializer(), it.constraints)) } }
    }
    var error by remember { mutableStateOf<String?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    val rootView = LocalView.current
    LaunchedEffect(error) { error?.let { rootView.announceForAccessibility(it) } }

    fun save() {
        if (name.isBlank()) { error = "Nama makro wajib diisi"; return }
        if (actions.isEmpty()) { error = "Tambahkan minimal satu aksi"; return }
        try {
            val m = (existing ?: Macro(name = name)).copy(
                name = name.trim(), description = desc.trim(), category = category.trim().ifBlank { "Umum" },
                triggers = triggers.map { AppJson.decodeFromJsonElement(MacroTrigger.serializer(), it) },
                actions = actions.map { AppJson.decodeFromJsonElement(MacroAction.serializer(), it) },
                constraints = constraints.map { AppJson.decodeFromJsonElement(MacroConstraint.serializer(), it) },
                constraintAny = constraintAny,
            )
            repo.save(m)
            android.widget.Toast.makeText(ctx, "Makro disimpan", android.widget.Toast.LENGTH_SHORT).show()
            onClose()
        } catch (e: Exception) {
            error = "Data tidak valid: ${e.message}"
        }
    }

    if (topMenu) {
        val engine = (ctx.applicationContext as MakroApp).engine
        val entries = buildList {
            add(MenuEntry("Simpan makro") { save() })
            if (existing != null) {
                add(MenuEntry("Uji makro tersimpan, abaikan batasan") {
                    val ok = engine.runNow(existing.id)
                    rootView.announceForAccessibility(if (ok) "${existing.name} dijalankan. Hasilnya ada di Log." else "MakroKu sedang tidak aktif")
                })
                add(MenuEntry("Gandakan makro") {
                    repo.duplicate(existing.id)
                    android.widget.Toast.makeText(ctx, "Makro digandakan", android.widget.Toast.LENGTH_SHORT).show()
                    onClose()
                })
                add(MenuEntry("Bagikan makro sebagai berkas (WhatsApp dll.)") { repo.exportOne(existing.id)?.let { shareMacroFile(ctx, existing.name, it) } })
            add(MenuEntry("Bagikan makro sebagai JSON") { repo.exportOne(existing.id)?.let { shareText(ctx, existing.name, it) } })
            }
            add(MenuEntry("Hapus semua aksi", true) { actions.clear(); rootView.announceForAccessibility("Semua aksi dihapus") })
        }
        MenuDialog("Menu makro", entries) { topMenu = false }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Makro baru" else "Ubah makro") },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } },
                actions = {
                    IconButton(onClick = { topMenu = true }) { Icon(Icons.Default.MoreVert, "Menu makro") }
                    TextButton(onClick = { save() }) { Text("Simpan") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama makro") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(desc, { desc = it }, label = { Text("Deskripsi (opsional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(category, { category = it }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive; contentDescription = "Kesalahan: $it" }) }

            HorizontalDivider()
            ItemSection("Pemicu (salah satu cukup)", triggers, Catalog.triggers, "Belum ada pemicu (hanya bisa dijalankan manual).", "pemicu")
            HorizontalDivider()
            ItemSection("Batasan", constraints, Catalog.constraints, "Tanpa batasan.", "batasan")
            Row(
                Modifier.toggleable(value = constraintAny, role = Role.Switch, onValueChange = { constraintAny = it }),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Batasan: salah satu cukup", Modifier.weight(1f))
                Switch(constraintAny, null)
            }
            HorizontalDivider()
            ItemSection("Aksi (berurutan)", actions, Catalog.actions, "Belum ada aksi.", "aksi")
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun isNotGate(o: JsonObject): Boolean =
    o["type"]?.jsonPrimitive?.content == "logic" &&
        o["logic"]?.jsonPrimitive?.content == "NOT" &&
        (o["constraints"] as? JsonArray)?.size == 1

private fun notWrap(o: JsonObject): JsonObject = buildJsonObject {
    put("type", "logic")
    put("logic", "NOT")
    put("constraints", JsonArray(listOf(o)))
}

/**
 * Daftar item (pemicu/aksi/batasan). Ketuk = ubah. Tekan tahan = menu lengkap seperti MacroDroid:
 * ubah, uji aksi, nonaktifkan sementara, salin/potong/tempel, gandakan, tambah di atas/bawah, pindah, hapus.
 * [kind] = "pemicu", "aksi", atau "batasan".
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemSection(
    title: String,
    items: SnapshotStateList<JsonObject>,
    catalog: List<Pair<String, JsonObject>>,
    emptyText: String,
    kind: String = "aksi",
) {
    var picking by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val view = LocalView.current
    var editIndex by remember { mutableIntStateOf(-1) }
    var editOff by remember { mutableStateOf(false) }
    var insertAt by remember { mutableIntStateOf(-1) }
    var draft by remember { mutableStateOf<JsonObject?>(null) }
    var menuIndex by remember { mutableIntStateOf(-1) }
    var selecting by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<Int>() }
    var blockName by remember { mutableStateOf(false) }
    val clip = ItemClipboard.item
    val clipAll = ItemClipboard.many.filter { c -> catalog.any { it.second["type"] == Catalog.inner(c)["type"] } }
    val canPaste = clip != null && clipAll.isNotEmpty()
    val pasteLabel = if (clipAll.size > 1) "${clipAll.size} item" else clip?.let { Catalog.labelOf(it) } ?: "item"
    fun labelOf(o: JsonObject) = Catalog.labelOf(o)
    fun say(s: String) = view.announceForAccessibility(s)
    fun salin(o: JsonObject) { ItemClipboard.item = o; ItemClipboard.many = listOf(o); say("${labelOf(o)} disalin") }
    fun salinBanyak(daftar: List<JsonObject>, kata: String) {
        if (daftar.isEmpty()) { say("Belum ada yang dipilih"); return }
        ItemClipboard.item = daftar.first(); ItemClipboard.many = daftar
        say("${daftar.size} item $kata")
    }
    fun pindah(from: Int, to: Int) {
        if (from !in items.indices) return
        val t = to.coerceIn(0, items.size - 1)
        if (t == from) return
        val x = items.removeAt(from)
        items.add(t, x)
        say("${labelOf(x)} dipindah ke urutan ${t + 1}")
    }
    fun toggleOff(i: Int) {
        if (i !in items.indices) return
        val o = items[i]
        if (Catalog.isOff(o)) { items[i] = Catalog.inner(o); say("${labelOf(o)} diaktifkan kembali") }
        else { items[i] = Catalog.wrapOff(o); say("${labelOf(o)} dinonaktifkan sementara") }
    }
    fun ubah(i: Int) {
        if (i !in items.indices) return
        val o = items[i]
        val inn = Catalog.inner(o)
        if (inn.size > 1) { editOff = Catalog.isOff(o); editIndex = i; draft = inn }
    }
    fun pilih(i: Int) {
        if (i in selected) selected.remove(i) else selected.add(i)
        say(if (i in selected) "Dipilih. ${selected.size} terpilih" else "Pilihan dilepas. ${selected.size} terpilih")
    }
    fun selesaiPilih() { selecting = false; selected.clear() }
    fun uji(o: JsonObject) {
        try {
            val a = AppJson.decodeFromJsonElement(MacroAction.serializer(), o)
            (ctx.applicationContext as MakroApp).engine.testAction(a, labelOf(o))
            say("${labelOf(o)} diuji. Hasilnya ada di Log.")
        } catch (e: Exception) {
            say("Tidak bisa menguji: ${e.message}")
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).semantics { heading() })
            if (canPaste && clip != null) {
                TextButton(
                    onClick = { items.addAll(clipAll); say("$pasteLabel ditempel") },
                    modifier = Modifier.semantics { contentDescription = "Tempel $pasteLabel ke $title" },
                ) { Text("Tempel") }
            }
            FilledTonalButton(
                onClick = { insertAt = -1; picking = true },
                modifier = Modifier.semantics { contentDescription = "Tambah, $title" },
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(4.dp))
                Text("Tambah")
            }
        }
        if (items.isEmpty()) Text(emptyText, style = MaterialTheme.typography.bodySmall)
        if (selecting) {
            Text(
                "Mode pilih: ${selected.size} dari ${items.size} terpilih.",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                TextButton(onClick = { selected.clear(); selected.addAll(items.indices.toList()); say("Semua ${items.size} dipilih") }) { Text("Pilih semua") }
                TextButton(onClick = { salinBanyak(selected.sorted().filter { it in items.indices }.map { items[it] }, "disalin"); selesaiPilih() }) { Text("Salin") }
                TextButton(onClick = {
                    val daftar = selected.sorted().filter { it in items.indices }.map { items[it] }
                    salinBanyak(daftar, "dipotong")
                    selected.sortedDescending().forEach { if (it in items.indices) items.removeAt(it) }
                    selesaiPilih()
                }) { Text("Potong") }
                TextButton(onClick = {
                    val idx = selected.sorted().filter { it in items.indices }
                    val salinan = idx.map { items[it] }
                    if (idx.isNotEmpty()) items.addAll(idx.last() + 1, salinan)
                    say("${salinan.size} item digandakan"); selesaiPilih()
                }) { Text("Gandakan") }
                TextButton(onClick = {
                    selected.sorted().forEach { if (it in items.indices && !Catalog.isOff(items[it])) items[it] = Catalog.wrapOff(items[it]) }
                    say("${selected.size} item dinonaktifkan"); selesaiPilih()
                }) { Text("Nonaktifkan") }
                TextButton(onClick = {
                    selected.sorted().forEach { if (it in items.indices) items[it] = Catalog.inner(items[it]) }
                    say("${selected.size} item diaktifkan"); selesaiPilih()
                }) { Text("Aktifkan") }
                TextButton(onClick = {
                    val n = selected.size
                    selected.sortedDescending().forEach { if (it in items.indices) items.removeAt(it) }
                    say("$n item dihapus"); selesaiPilih()
                }) { Text("Hapus") }
                if (kind == "aksi") TextButton(onClick = { if (selected.isNotEmpty()) blockName = true else say("Belum ada yang dipilih") }) { Text("Simpan sebagai blok") }
                TextButton(onClick = { selesaiPilih(); say("Mode pilih selesai") }) { Text("Selesai") }
            }
        }
        items.forEachIndexed { i, o ->
            val lbl = labelOf(o)
            val off = Catalog.isOff(o)
            Card(Modifier.fillMaxWidth().alpha(if (off) 0.55f else 1f)) {
                Column(
                    Modifier
                        .combinedClickable(
                            onClickLabel = if (selecting) "Pilih atau lepas" else "Ubah",
                            onLongClickLabel = if (selecting) "Pilih atau lepas" else "Buka menu",
                            onLongClick = { if (selecting) pilih(i) else menuIndex = i },
                        ) { if (selecting) pilih(i) else ubah(i) }
                        .semantics {
                            contentDescription = (if (i in selected) "Terpilih. " else "") + "${i + 1} dari ${items.size}. " + Catalog.describe(o)
                            customActions = buildList {
                                add(CustomAccessibilityAction("Buka menu") { menuIndex = i; true })
                                add(CustomAccessibilityAction("Pilih beberapa") { selecting = true; selected.clear(); selected.add(i); true })
                                if (kind == "aksi" && !off) add(CustomAccessibilityAction("Uji aksi ini") { uji(o); true })
                                add(CustomAccessibilityAction(if (off) "Aktifkan kembali" else "Nonaktifkan sementara") { toggleOff(i); true })
                                add(CustomAccessibilityAction("Naikkan") { pindah(i, i - 1); true })
                                add(CustomAccessibilityAction("Turunkan") { pindah(i, i + 1); true })
                                add(CustomAccessibilityAction("Gandakan") {
                                    items.add(i + 1, o)
                                    say("$lbl digandakan")
                                    true
                                })
                                add(CustomAccessibilityAction("Salin") { salin(o); true })
                                add(CustomAccessibilityAction("Potong") { salin(o); items.removeAt(i); say("$lbl dipotong"); true })
                                add(CustomAccessibilityAction("Tempel di bawah") {
                                    if (canPaste) { items.addAll(i + 1, clipAll); say("$pasteLabel ditempel") }
                                    true
                                })
                                add(CustomAccessibilityAction("Hapus") { items.removeAt(i); say("$lbl dihapus"); true })
                            }
                        }
                        .padding(12.dp),
                ) {
                    Text(
                        Catalog.describe(o),
                        style = MaterialTheme.typography.bodyMedium,
                        textDecoration = if (off) TextDecoration.LineThrough else null,
                        modifier = Modifier.clearAndSetSemantics {},
                    )
                    Column(Modifier.clearAndSetSemantics {}) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (Catalog.inner(o).size > 1) IconButton(onClick = { ubah(i) }) { Icon(Icons.Default.Edit, "Ubah $lbl") }
                            IconButton(onClick = { menuIndex = i }) { Icon(Icons.Default.MoreVert, "Menu $lbl") }
                            IconButton(onClick = { items.removeAt(i); say("$lbl dihapus") }) { Icon(Icons.Default.Delete, "Hapus $lbl") }
                        }
                        Row {
                            TextButton(onClick = { pindah(i, i - 1) }, modifier = Modifier.semantics { contentDescription = "Naikkan $lbl" }) { Text("Naik") }
                            TextButton(onClick = { pindah(i, i + 1) }, modifier = Modifier.semantics { contentDescription = "Turunkan $lbl" }) { Text("Turun") }
                            TextButton(onClick = { items.add(i + 1, o); say("$lbl digandakan") }, modifier = Modifier.semantics { contentDescription = "Gandakan $lbl" }) { Text("Gandakan") }
                        }
                    }
                }
            }
        }
    }

    if (menuIndex in items.indices) {
        val mi = menuIndex
        val mo = items[mi]
        val inn = Catalog.inner(mo)
        val off = Catalog.isOff(mo)
        val ml = labelOf(mo)
        val entries = buildList {
            if (inn.size > 1) add(MenuEntry("Ubah") { ubah(mi) })
            if (kind == "aksi" && !off) add(MenuEntry("Uji aksi ini sekarang") { uji(inn) })
            add(MenuEntry(if (off) "Aktifkan kembali" else "Nonaktifkan sementara") { toggleOff(mi) })
            if (kind == "batasan" && !off) {
                if (isNotGate(inn)) add(MenuEntry("Batalkan pembalikan, lepas NOT") {
                    items[mi] = (inn["constraints"] as JsonArray)[0].jsonObject
                    say("Pembalikan dibatalkan")
                })
                else add(MenuEntry("Balikkan batasan, jadi kebalikannya") {
                    items[mi] = notWrap(inn)
                    say("$ml dibalikkan")
                })
            }
            add(MenuEntry("Pilih beberapa, mulai dari ini") { selecting = true; selected.clear(); selected.add(mi); say("Mode pilih. 1 terpilih") })
            add(MenuEntry("Salin") { salin(mo) })
            add(MenuEntry("Potong") { salin(mo); items.removeAt(mi); say("$ml dipotong") })
            if (canPaste && clip != null) {
                add(MenuEntry("Tempel $pasteLabel di atas") { items.addAll(mi, clipAll); say("$pasteLabel ditempel") })
                add(MenuEntry("Tempel $pasteLabel di bawah") { items.addAll(mi + 1, clipAll); say("$pasteLabel ditempel") })
            }
            add(MenuEntry("Gandakan") { items.add(mi + 1, mo); say("$ml digandakan") })
            add(MenuEntry("Tambah $kind baru di atas") { insertAt = mi; picking = true })
            add(MenuEntry("Tambah $kind baru di bawah") { insertAt = mi + 1; picking = true })
            if (mi > 0) {
                add(MenuEntry("Naikkan satu langkah") { pindah(mi, mi - 1) })
                add(MenuEntry("Pindahkan ke paling atas") { pindah(mi, 0) })
            }
            if (mi < items.size - 1) {
                add(MenuEntry("Turunkan satu langkah") { pindah(mi, mi + 1) })
                add(MenuEntry("Pindahkan ke paling bawah") { pindah(mi, items.size - 1) })
            }
            add(MenuEntry("Hapus", true) { items.removeAt(mi); say("$ml dihapus") })
        }
        MenuDialog(ml, entries) { menuIndex = -1 }
    }

    if (blockName) {
        TextInputDialog("Simpan sebagai blok aksi", "Nama blok", "", onDismiss = { blockName = false }) { nama ->
            val acts = selected.sorted().filter { it in items.indices }.mapNotNull {
                runCatching { AppJson.decodeFromJsonElement(MacroAction.serializer(), Catalog.inner(items[it])) }.getOrNull()
            }
            (ctx.applicationContext as MakroApp).repo.saveBlock(nama, acts)
            blockName = false
            say("Blok $nama disimpan dengan ${acts.size} aksi. Pakai lewat aksi Jalankan blok aksi tersimpan.")
            selesaiPilih()
        }
    }

    if (picking) {
        PickerDialog(
            title = title,
            labels = catalog.map { it.first },
            searchable = true,
            onPick = { i ->
                picking = false
                val obj = catalog[i].second
                if (obj.size <= 1) {
                    val at = if (insertAt in 0..items.size) insertAt else items.size
                    items.add(at, obj)
                    insertAt = -1
                    say(Catalog.labelOf(obj) + " ditambahkan")
                } else {
                    editIndex = -1; editOff = false; draft = obj
                }
            },
            onDismiss = { picking = false; insertAt = -1 },
        )
    }

    draft?.let { d ->
        ParamDialog(
            title = Catalog.labelOf(d).ifBlank { "Parameter" },
            initial = d,
            onDismiss = { draft = null; insertAt = -1; editOff = false; editIndex = -1 },
            onSave = { saved ->
                val out = if (editOff) Catalog.wrapOff(saved) else saved
                if (editIndex in items.indices) items[editIndex] = out
                else {
                    val at = if (insertAt in 0..items.size) insertAt else items.size
                    items.add(at, out)
                }
                say(Catalog.labelOf(saved) + " disimpan")
                draft = null; editIndex = -1; editOff = false; insertAt = -1
            },
        )
    }
}

private class FormState(val initial: JsonObject) {
    val order = initial.keys.filter { it != "type" }
    val texts = mutableStateMapOf<String, String>()
    val bools = mutableStateMapOf<String, Boolean>()
    val numeric = mutableSetOf<String>()
    val days = mutableStateListOf<Int>()
    val nested = mutableMapOf<String, SnapshotStateList<JsonObject>>()

    init {
        initial.forEach { (k, v) ->
            when {
                k == "type" -> {}
                v is JsonArray && k == "days" -> days.addAll(v.map { it.jsonPrimitive.content.toInt() })
                v is JsonArray -> nested[k] = mutableStateListOf<JsonObject>().apply { addAll(v.map { it.jsonObject }) }
                v is JsonPrimitive && !v.isString && v.booleanOrNull != null -> bools[k] = v.booleanOrNull!!
                v is JsonPrimitive -> {
                    texts[k] = v.content
                    if (!v.isString) numeric += k
                }
                else -> {}
            }
        }
    }

    fun build(): JsonObject = buildJsonObject {
        put("type", initial["type"]!!.jsonPrimitive.content)
        order.forEach { k ->
            when {
                k == "days" -> put(k, JsonArray(days.sorted().map { JsonPrimitive(it) }))
                nested.containsKey(k) -> put(k, JsonArray(nested.getValue(k).toList()))
                bools.containsKey(k) -> put(k, bools.getValue(k))
                k in numeric -> put(k, texts[k]?.toLongOrNull() ?: 0L)
                else -> put(k, texts[k].orEmpty())
            }
        }
    }
}

@Composable
fun ParamDialog(title: String, initial: JsonObject, onDismiss: () -> Unit, onSave: (JsonObject) -> Unit) {
    val state = remember(initial) { FormState(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Pasangan nyala/mati + "otomatis" (toggle) digabung jadi satu pilihan: Aktif, Tidak aktif, Otomatis.
                val pairKey = if (state.bools.containsKey("toggle")) listOf("enable", "on", "mute").firstOrNull { state.bools.containsKey(it) } else null
                state.order.forEach { k ->
                    val label = Catalog.fieldLabels[k] ?: k
                    when {
                        pairKey != null && k == "toggle" -> {}
                        pairKey != null && k == pairKey -> StateChoice(pairKey, state.bools)
                        k == "days" -> DaysPicker(state.days)
                        state.nested.containsKey(k) ->
                            ItemSection(label, state.nested.getValue(k), if (k == "constraints") Catalog.constraints else Catalog.actions, "Kosong", if (k == "constraints") "batasan" else "aksi")
                        state.bools.containsKey(k) -> Row(
                            Modifier.toggleable(
                                value = state.bools[k] == true,
                                role = Role.Switch,
                                onValueChange = { state.bools[k] = it },
                            ),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(label, Modifier.weight(1f))
                            Switch(state.bools[k] == true, null)
                        }
                        Catalog.options.containsKey(k) ->
                            OptionDropdown(k, label, state.texts[k].orEmpty(), Catalog.options.getValue(k)) { state.texts[k] = it }
                        else -> {
                            val num = k in state.numeric
                            Column {
                                OutlinedTextField(
                                    value = state.texts[k].orEmpty(),
                                    onValueChange = { v -> state.texts[k] = if (num) v.filter { c -> c.isDigit() || c == '-' } else v },
                                    label = { Text(label) },
                                    keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                if (!num) MagicTextButton(label) { token -> state.texts[k] = state.texts[k].orEmpty() + token }
                                if (k == "key" && state.texts.containsKey("ns")) {
                                    SettingKeyPicker(state.texts["ns"].orEmpty()) { picked -> state.texts["key"] = picked }
                                }
                            }
                        }
                    }
                }
                Text(
                    "Ketuk \"Sisipkan variabel\" untuk memasukkan waktu, baterai, SMS, dll.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(state.build()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

/** Tombol "Pilih dari daftar" untuk kolom kunci pengaturan: memuat daftar pengaturan namespace terpilih lalu menampilkannya. */
@Composable
private fun SettingKeyPicker(ns: String, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var open by remember { mutableStateOf(false) }
    var items by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    TextButton(
        onClick = { items = null; open = true },
        modifier = Modifier.semantics { contentDescription = "Pilih kunci pengaturan dari daftar $ns" },
    ) { Text("Pilih dari daftar") }
    if (open) {
        LaunchedEffect(ns) {
            items = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.makroku.automation.engine.SettingsLister.list(ctx, ns)
            }
        }
        val list = items
        if (list == null) {
            AlertDialog(
                onDismissRequest = { open = false },
                title = { Text("Memuat daftar") },
                text = { Text("Mohon tunggu.") },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { open = false }) { Text("Batal") } },
            )
        } else if (list.isEmpty()) {
            AlertDialog(
                onDismissRequest = { open = false },
                title = { Text("Daftar kosong") },
                text = { Text("Daftar tidak bisa dibaca. Pasangkan ADB, atau ketik kuncinya sendiri.") },
                confirmButton = { TextButton(onClick = { open = false }) { Text("OK") } },
            )
        } else {
            PickerDialog(
                title = "Pengaturan $ns",
                labels = list.map { (k, v) -> "$k. Nilai sekarang: ${v.take(40).ifBlank { "kosong" }}" },
                searchable = true,
                onPick = { i ->
                    open = false
                    onPick(list[i].first)
                    view.announceForAccessibility("${list[i].first} dipilih")
                },
                onDismiss = { open = false },
            )
        }
    }
}

/** Daftar placeholder (Magic Text) yang bisa disisipkan ke kolom teks. */
private fun magicItems(ctx: android.content.Context): List<Pair<String, String>> {
    val base = listOf(
        "Waktu sekarang (jam:menit)" to "{time}",
        "Tanggal hari ini" to "{date}",
        "Level baterai" to "{battery}",
        "Pengirim SMS masuk" to "{sms_sender}",
        "Isi SMS masuk" to "{sms_body}",
        "Judul notifikasi masuk" to "{notif_title}",
        "Isi notifikasi masuk" to "{notif_text}",
        "Nomor penelepon" to "{call_number}",
        "Paket aplikasi yang dibuka" to "{app_pkg}",
        "Parameter webhook bernama teks" to "{wh_teks}",
    )
    val vars = runCatching { (ctx.applicationContext as MakroApp).repo.variables.value }.getOrDefault(emptyMap())
        .toList().sortedBy { it.first }
        .map { (k, v) -> "Variabel $k (isi sekarang: ${v.take(30).ifBlank { "kosong" }})" to "{var:$k}" }
    return base + vars
}

@Composable
private fun MagicTextButton(fieldLabel: String, onInsert: (String) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var open by remember { mutableStateOf(false) }
    TextButton(
        onClick = { open = true },
        modifier = Modifier.semantics { contentDescription = "Sisipkan variabel ke kolom $fieldLabel" },
    ) { Text("Sisipkan variabel") }
    if (open) {
        val items = remember { magicItems(ctx) }
        PickerDialog(
            title = "Sisipkan variabel",
            labels = items.map { it.first },
            searchable = items.size > 8,
            onPick = { i ->
                open = false
                onInsert(items[i].second)
                view.announceForAccessibility("${items[i].first} disisipkan ke $fieldLabel")
            },
            onDismiss = { open = false },
        )
    }
}

/** Tiga pilihan jelas untuk aksi nyala/mati: Aktif, Tidak aktif, atau Otomatis (membalik keadaan sekarang). */
@Composable
private fun StateChoice(key: String, bools: SnapshotStateMap<String, Boolean>) {
    val yes = if (key == "mute") "Dibisukan" else "Aktif"
    val no = if (key == "mute") "Tidak dibisukan" else "Tidak aktif"
    val choices = listOf(yes, no, "Otomatis: yang tadinya $yes jadi $no, dan sebaliknya")
    val selected = if (bools["toggle"] == true) 2 else if (bools[key] == true) 0 else 1
    Column(Modifier.selectableGroup()) {
        Text("Pilih keadaan", style = MaterialTheme.typography.labelLarge, modifier = Modifier.semantics { heading() })
        choices.forEachIndexed { i, text ->
            Row(
                Modifier.fillMaxWidth().selectable(
                    selected = selected == i,
                    role = Role.RadioButton,
                    onClick = {
                        when (i) {
                            0 -> { bools[key] = true; bools["toggle"] = false }
                            1 -> { bools[key] = false; bools["toggle"] = false }
                            else -> { bools[key] = true; bools["toggle"] = true }
                        }
                    },
                ).padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = selected == i, onClick = null)
                Spacer(Modifier.width(10.dp))
                Text(text)
            }
        }
    }
}

private val dayFull = mapOf(1 to "Minggu", 2 to "Senin", 3 to "Selasa", 4 to "Rabu", 5 to "Kamis", 6 to "Jumat", 7 to "Sabtu")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DaysPicker(days: SnapshotStateList<Int>) {
    Column {
        Text("Hari", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(2, 3, 4, 5, 6, 7, 1).forEach { d ->
                FilterChip(
                    selected = d in days,
                    onClick = { if (d in days) days.remove(d) else days.add(d) },
                    label = { Text(Catalog.dayName(d).take(2)) },
                    modifier = Modifier.semantics { contentDescription = dayFull[d] ?: "" },
                )
            }
        }
    }
}

@Composable
private fun OptionDropdown(field: String, label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shown = Catalog.optionLabel(field, value)
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clearAndSetSemantics {})
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "$label: ${shown.ifBlank { "belum dipilih" }}. Ketuk untuk memilih" },
        ) { Text(shown.ifBlank { "Pilih…" }) }
    }
    if (open) {
        PickerDialog(
            title = label,
            labels = options.map { Catalog.optionLabel(field, it) },
            searchable = options.size > 8,
            onPick = { i -> onPick(options[i]); open = false },
            onDismiss = { open = false },
        )
    }
}

/**
 * Daftar pilihan layar penuh yang ramah pembaca layar: tiap baris satu perhentian dengan nama jelas,
 * urutan "n dari total", jumlah hasil diumumkan saat mencari.
 */
@Composable
fun PickerDialog(title: String, labels: List<String>, searchable: Boolean, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = labels.withIndex().filter { it.value.contains(query.trim(), ignoreCase = true) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                if (searchable) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        label = { Text("Cari") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                }
                Text(
                    "${shown.size} pilihan",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(vertical = 8.dp).semantics { liveRegion = LiveRegionMode.Polite },
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown.size, key = { shown[it].index }) { pos ->
                        val label = shown[pos].value
                        val idx = shown[pos].index
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(min = 56.dp)
                                .clickable(role = Role.Button, onClickLabel = "Pilih") { onPick(idx) }
                                .padding(horizontal = 8.dp, vertical = 12.dp)
                                .semantics(mergeDescendants = true) {
                                    contentDescription = "$label. ${pos + 1} dari ${shown.size}"
                                },
                            verticalAlignment = Alignment.CenterVertically,
                        ) { Text(label, style = MaterialTheme.typography.bodyLarge) }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
            }
        }
    }
}
