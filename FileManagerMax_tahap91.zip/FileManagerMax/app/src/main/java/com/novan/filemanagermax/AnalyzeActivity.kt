package com.novan.filemanagermax

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/** Analisis penyimpanan: ukuran tiap isi teratas dari sebuah penyimpanan, terbesar dulu. */
class AnalyzeActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROOT = "root"
        const val EXTRA_TITLE = "title"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var items: List<File> = emptyList()
    private var folderRows: List<Row> = emptyList()
    private var showCache = false
    private var cacheSize: Long? = null

    private val clearLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            say(getString(R.string.cache_cleared))
            refreshCache()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val root = File(intent.getStringExtra(EXTRA_ROOT) ?: "/storage/emulated/0")
        val label = intent.getStringExtra(EXTRA_TITLE) ?: root.name
        // Kartu File cache ditampilkan di penyimpanan utama saja.
        showCache = root.absolutePath == Environment.getExternalStorageDirectory().absolutePath
        title = getString(R.string.analyze_title, label)
        supportActionBar?.subtitle = getString(
            R.string.storage_used_of,
            Formatter.formatFileSize(this, root.totalSpace - root.freeSpace),
            Formatter.formatFileSize(this, root.totalSpace)
        )

        empty = findViewById(R.id.empty)
        empty.setText(R.string.analyzing)
        empty.visibility = View.VISIBLE
        rowAdapter = RowAdapter(onClick = { onClickRow(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter

        executor.execute {
            val kids = (root.listFiles() ?: emptyArray<File>()).toList()
            val sized = kids.map { it to FileOps.sizeOf(it) }.sortedByDescending { it.second }
            val total = sized.sumOf { it.second }.coerceAtLeast(1L)
            val rows = sized.map { (f, s) ->
                val pct = (s * 100 / total).toInt()
                val detail = "${Formatter.formatFileSize(this, s)}, $pct%"
                Row(
                    if (f.isDirectory) R.drawable.ic_folder else R.drawable.ic_file,
                    f.name, detail,
                    "${getString(if (f.isDirectory) R.string.folder else R.string.file)} ${f.name}, $detail",
                    f.absolutePath
                )
            }
            val cache = if (showCache) try { CacheTools.totalSize(this) } catch (e: Exception) { null } else null
            main.post {
                if (isFinishing || isDestroyed) return@post
                items = sized.map { it.first }
                folderRows = rows
                cacheSize = cache
                submitRows()
                empty.setText(R.string.empty_folder)
                empty.visibility = if (rows.isEmpty() && !showCache) View.VISIBLE else View.GONE
                Snackbar.make(
                    findViewById(android.R.id.content),
                    getString(R.string.analyze_done, rows.size), Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    /** Baris pertama (bila ada) adalah kartu File cache, diikuti isi penyimpanan. */
    private fun submitRows() {
        if (!showCache) { rowAdapter.submit(folderRows); return }
        val size = cacheSize
        val detail = if (size != null) getString(R.string.cache_row_size, Formatter.formatFileSize(this, size))
        else getString(R.string.cache_row_unknown)
        val cacheRow = Row(
            R.drawable.ic_clean, getString(R.string.cache_title), detail,
            getString(R.string.cache_title) + ", " + detail, "cache"
        )
        rowAdapter.submit(listOf(cacheRow) + folderRows)
    }

    private fun refreshCache() {
        executor.execute {
            val size = try { CacheTools.totalSize(this) } catch (e: Exception) { null }
            main.post {
                if (isFinishing || isDestroyed) return@post
                cacheSize = size
                submitRows()
            }
        }
    }

    private fun showCacheDialog() {
        val size = cacheSize
        val msg = (if (size != null) getString(R.string.cache_row_size, Formatter.formatFileSize(this, size)) + "\n\n"
        else "") + getString(R.string.cache_explain)
        val b = AlertDialog.Builder(this)
            .setTitle(R.string.cache_title)
            .setMessage(msg)
            .setPositiveButton(R.string.cache_clear) { _, _ -> clearCache() }
            .setNegativeButton(R.string.cancel, null)
        if (Build.VERSION.SDK_INT >= 26 && size == null && !CacheTools.hasUsageAccess(this)) {
            b.setNeutralButton(R.string.clean_usage_open) { _, _ ->
                try {
                    startActivity(CacheTools.usageSettingsIntent())
                } catch (e: Exception) {
                    say(getString(R.string.cannot_open))
                }
            }
        }
        b.show()
    }

    private fun clearCache() {
        executor.execute {
            val freed = try { CacheTools.deleteReachable(this) } catch (e: Exception) { 0L }
            main.post {
                if (isFinishing || isDestroyed) return@post
                if (Build.VERSION.SDK_INT >= 26) {
                    try {
                        // Dialog sistem: menghapus cache semua aplikasi.
                        clearLauncher.launch(CacheTools.clearAllIntent())
                        return@post
                    } catch (e: Exception) {
                        // lanjut ke cadangan di bawah
                    }
                }
                if (freed > 0) say(getString(R.string.cache_freed, Formatter.formatFileSize(this, freed)))
                else say(getString(R.string.cache_system_hint))
                refreshCache()
            }
        }
    }

    private fun onClickRow(row: Int) {
        if (showCache && row == 0) { showCacheDialog(); return }
        val i = if (showCache) row - 1 else row
        if (i !in items.indices) return
        val f = items[i]
        if (f.isDirectory) {
            startActivity(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, f.absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, f.name)
            )
        } else if (!Util.openSmart(this, f, items)) {
            Snackbar.make(findViewById(android.R.id.content), getString(R.string.cannot_open), Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) { finish(); true } else super.onOptionsItemSelected(item)
}
