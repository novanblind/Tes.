package com.novan.audiolabnovan.videolab;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.RgbMatrix;

/** Filter sepia (warna cokelat tua seperti foto lama). */
@UnstableApi
public final class SepiaMatrix implements RgbMatrix {
    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        // Urutan kolom demi kolom (kolom OpenGL).
        return new float[]{
                0.393f, 0.349f, 0.272f, 0,
                0.769f, 0.686f, 0.534f, 0,
                0.189f, 0.168f, 0.131f, 0,
                0, 0, 0, 1};
    }
}
