package com.novan.filemanagermax

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale

/** Pemutar video bawaan: kontrol sistem, subtitle SRT/VTT, kecepatan, dan pilihan jalur audio. */
class VideoPlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
    }

    private lateinit var video: VideoView
    private lateinit var subView: TextView
    private var position = 0
    private var player: MediaPlayer? = null
    private var cues: List<SubtitleParser.Cue> = emptyList()
    private var shown: String? = null
    private var speed = 1.0f
    private val main = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            updateSubtitle()
            main.postDelayed(this, 250)
        }
    }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) loadSubtitle(File(p))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_player)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        video = findViewById(R.id.video)
        subView = findViewById(R.id.subtitle)
        subView.textSize = Prefs.subSize(this).toFloat()
        position = savedInstanceState?.getInt("pos") ?: 0

        val path = intent.getStringExtra(EXTRA_PATH)
        val uri: Uri? = when {
            path != null -> Uri.fromFile(File(path))
            else -> intent.data
        }
        title = if (path != null) File(path).name else uri?.let { Util.displayName(this, it) } ?: getString(R.string.video_player)
        if (uri == null) { finish(); return }

        // MediaController memakan tombol Kembali saat bilah kontrol tampil; teruskan supaya video tertutup
        val mc = object : MediaController(this) {
            override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
                if (event.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                    if (event.action == android.view.KeyEvent.ACTION_UP) finish()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        mc.setAnchorView(video)
        video.setMediaController(mc)
        video.setVideoURI(uri)
        video.setOnPreparedListener { mp ->
            player = mp
            applySpeed(false)
            if (position > 0) video.seekTo(position)
            video.start()
        }
        video.setOnErrorListener { _, _, _ ->
            if (!isFinishing) {
                AlertDialog.Builder(this)
                    .setMessage(R.string.video_failed)
                    .setPositiveButton(R.string.ok) { _, _ -> finish() }
                    .show()
            }
            true
        }

        val local = if (path != null) File(path) else if (uri.scheme == "file") uri.path?.let { File(it) } else null
        local?.let { v -> SubtitleParser.findFor(v)?.let { loadSubtitle(it, announce = false) } }
    }

    override fun onResume() {
        super.onResume()
        main.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(ticker)
        position = video.currentPosition
        video.pause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pos", video.currentPosition)
    }

    // ---------------------------------------------------------------- subtitle

    private fun loadSubtitle(f: File, announce: Boolean = true) {
        Thread {
            val list = try { SubtitleParser.read(f) } catch (e: Exception) { emptyList() }
            main.post {
                if (isFinishing || isDestroyed) return@post
                cues = list
                shown = null
                updateSubtitle()
                if (announce) {
                    val msg = if (list.isEmpty()) getString(R.string.sub_failed)
                    else getString(R.string.sub_loaded, f.name, list.size)
                    subView.announceForAccessibility(msg)
                    android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun updateSubtitle() {
        if (!Prefs.subsOn(this) || cues.isEmpty()) {
            subView.visibility = View.GONE
            shown = null
            return
        }
        val pos = video.currentPosition.toLong()
        val cue = cues.firstOrNull { pos >= it.start && pos <= it.end }
        if (cue == null) {
            subView.visibility = View.GONE
            shown = null
        } else if (cue.text != shown) {
            shown = cue.text
            subView.text = cue.text
            subView.visibility = View.VISIBLE
        }
    }

    // ---------------------------------------------------------------- menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.video_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.video_subs).isChecked = Prefs.subsOn(this)
        menu.findItem(R.id.video_speed).isVisible = Build.VERSION.SDK_INT >= 23
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.video_subs -> {
                Prefs.setSubsOn(this, !Prefs.subsOn(this))
                shown = null
                updateSubtitle()
                invalidateOptionsMenu()
            }
            R.id.video_sub_file -> pickSubtitle.launch(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, Environment.getExternalStorageDirectory().absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.sub_pick_title))
                    .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FILE)
            )
            R.id.video_sub_size -> showSizeDialog()
            R.id.video_speed -> showSpeedDialog()
            R.id.video_audio -> showAudioDialog()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun showSizeDialog() {
        val sizes = intArrayOf(14, 20, 28, 36, 48)
        val labels = arrayOf(
            getString(R.string.sub_size_small), getString(R.string.sub_size_medium),
            getString(R.string.sub_size_large), getString(R.string.sub_size_xlarge),
            getString(R.string.sub_size_xxlarge)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.sub_size_title)
            .setSingleChoiceItems(labels, sizes.indexOf(Prefs.subSize(this))) { dialog, which ->
                Prefs.setSubSize(this, sizes[which])
                subView.textSize = sizes[which].toFloat()
                dialog.dismiss()
            }
            .show()
    }

    private fun applySpeed(keepPaused: Boolean) {
        val p = player ?: return
        if (Build.VERSION.SDK_INT < 23) return
        try {
            val wasPlaying = video.isPlaying
            p.playbackParams = p.playbackParams.setSpeed(speed)
            if (keepPaused && !wasPlaying) p.pause()
        } catch (e: Exception) { }
    }

    private fun showSpeedDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = values.map { String.format(Locale.US, "%.2fx", it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.audio_speed_title)
            .setSingleChoiceItems(labels, values.indexOfFirst { Math.abs(it - speed) < 0.01f }) { dialog, which ->
                speed = values[which]
                applySpeed(true)
                dialog.dismiss()
            }
            .show()
    }

    private fun showAudioDialog() {
        val p = player ?: return
        val tracks: Array<MediaPlayer.TrackInfo>? = try { p.trackInfo } catch (e: Exception) { null }
        if (tracks == null) return
        val idx = ArrayList<Int>()
        val labels = ArrayList<String>()
        for (i in tracks.indices) {
            if (tracks[i].trackType == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO) {
                val lang = tracks[i].language
                idx.add(i)
                labels.add(
                    getString(R.string.audio_track_n, idx.size) +
                        if (lang.isNullOrEmpty() || lang == "und") "" else " ($lang)"
                )
            }
        }
        if (idx.size < 2) {
            android.widget.Toast.makeText(this, R.string.audio_track_one, android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val current = idx.indexOfFirst { p.getSelectedTrack(MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO) == it }
        AlertDialog.Builder(this)
            .setTitle(R.string.audio_track_title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { dialog, which ->
                try { p.selectTrack(idx[which]) } catch (e: Exception) { }
                dialog.dismiss()
            }
            .show()
    }
}
