package com.pembacauang

import java.util.Locale

/**
 * Mengubah teks hasil OCR menjadi pecahan uang.
 *
 * Alurnya sama dengan aplikasi acuan:
 *  1. teks diubah ke huruf besar, baris baru jadi spasi;
 *  2. dihitung jumlah karakter '0' pada seluruh teks;
 *  3. dicocokkan berurutan ke daftar kata kunci. Kecocokan pertama menang:
 *       a. tulisan nominal ("SERIBU", "LIMA PULUH", ...),
 *       b. nama pahlawan pada uang, termasuk salah baca OCR yang umum,
 *       c. pola angka, hanya bila jumlah '0' sama persis dengan jumlah
 *          nol pecahan itu (mencegah "1000" terbaca dari "100000").
 */
object CurrencyParser {

    private class Rule(val keyword: String, val zeros: Int?, val result: Denomination)

    private fun words(d: Denomination, vararg k: String) = k.map { Rule(it, null, d) }
    private fun digits(d: Denomination, zeros: Int, vararg k: String) = k.map { Rule(it, zeros, d) }

    // Urutan penting: sama dengan urutan pencocokan pada aplikasi acuan.
    private val rules: List<Rule> = buildList {
        addAll(words(Denomination.TUJUH_PULUH_LIMA_RIBU, "75000", "TUJUH PULUH", "75.000", "75 RIBU"))
        addAll(words(Denomination.SERIBU, "SERIBU"))
        addAll(words(Denomination.DUA_RIBU, "DUA RIBU", "HOESNI THAMRIN", "HOESNI", "THAMRIN"))
        addAll(words(Denomination.LIMA_RIBU, "LIMA RIBU", "UMA RIBU", "IDHAM"))
        addAll(words(Denomination.SEPULUH_RIBU, "SEPULUH", "FRANS", "SEPULUN", "AEPULUH"))
        addAll(words(Denomination.DUA_PULUH_RIBU, "DUA PULUH", "RATULANGI"))
        addAll(words(Denomination.LIMA_PULUH_RIBU, "LIMA PULUH", "UMA PULUH"))
        addAll(words(Denomination.SERATUS_RIBU, "SERATUS RIBU"))
        addAll(words(Denomination.SERIBU, "MEUTIA", "PATTIMURA", "PATIMURA"))
        addAll(words(Denomination.DUA_RIBU, "ANTASARI"))
        addAll(words(Denomination.LIMA_RIBU, "CHALID", "BONJOL"))
        addAll(words(Denomination.SEPULUH_RIBU, "KAISIEPO", "BADARUDDIN"))
        addAll(words(Denomination.DUA_PULUH_RIBU, "ISKANDAR"))
        addAll(words(Denomination.LIMA_PULUH_RIBU, "DJUANDA", "KARTAWIDJAJA", "NGURAH"))

        // Pola angka, termasuk salah baca OCR (I/1, Z/2/7/C, S/5).
        addAll(digits(Denomination.SERIBU, 3, "1000", "0001", "000I"))
        addAll(digits(Denomination.DUA_RIBU, 3, "2000", "000C", "0002", "0007", "000Z"))
        addAll(digits(Denomination.LIMA_RIBU, 3, "5000", "0005", "000S", "D00S"))
        addAll(digits(Denomination.SEPULUH_RIBU, 4, "10000", "00001", "0000I"))
        addAll(digits(Denomination.DUA_PULUH_RIBU, 4, "20000", "0000Z", "00002", "00007", "0000C"))
        addAll(digits(Denomination.LIMA_PULUH_RIBU, 4, "50000", "S0000", "0000S"))
        addAll(digits(Denomination.SERATUS_RIBU, 5, "100000", "000001", "00000I"))
    }

    /** Mengembalikan pecahan yang terbaca, atau null bila tidak ada yang cocok. */
    fun parse(ocrText: String): Denomination? {
        if (ocrText.isBlank()) return null
        val text = ocrText.uppercase(Locale.ROOT).replace('\n', ' ')
        val zeroCount = text.count { it == '0' }
        for (rule in rules) {
            if (rule.zeros != null && rule.zeros != zeroCount) continue
            if (text.contains(rule.keyword)) return rule.result
        }
        return null
    }
}
