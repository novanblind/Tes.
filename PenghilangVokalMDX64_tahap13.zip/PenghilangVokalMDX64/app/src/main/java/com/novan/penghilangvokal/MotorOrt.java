package com.novan.penghilangvokal;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.Collections;

/** Menjalankan model MDX-Net (ONNX) dengan ONNX Runtime di CPU. */
final class MotorOrt implements MdxNet.Motor, AutoCloseable {

    private static final long[] BENTUK = {1, 4, MdxDsp.DIM_F, MdxDsp.DIM_T};

    private final OrtEnvironment env;
    private final OrtSession session;
    private final String namaMasuk;
    private final FloatBuffer buf;

    MotorOrt(File model, int utas) throws Exception {
        env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions so = new OrtSession.SessionOptions();
        try {
            so.setIntraOpNumThreads(Math.max(1, utas));
            so.setInterOpNumThreads(1);
            so.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            session = env.createSession(model.getAbsolutePath(), so);
        } finally {
            so.close();
        }
        namaMasuk = session.getInputNames().iterator().next();
        NodeInfo ni = session.getInputInfo().get(namaMasuk);
        if (ni != null && ni.getInfo() instanceof TensorInfo) {
            long[] sh = ((TensorInfo) ni.getInfo()).getShape();
            boolean cocok = sh.length == 4
                    && (sh[1] == 4 || sh[1] < 0)
                    && (sh[2] == MdxDsp.DIM_F || sh[2] < 0)
                    && (sh[3] == MdxDsp.DIM_T || sh[3] < 0);
            if (!cocok) {
                session.close();
                throw new IllegalStateException("bentuk masukan model " + Arrays.toString(sh)
                        + " tidak sama dengan 1x4x" + MdxDsp.DIM_F + "x" + MdxDsp.DIM_T);
            }
        }
        buf = ByteBuffer.allocateDirect(4 * MdxDsp.DIM_F * MdxDsp.DIM_T * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    @Override
    public void jalankan(float[] masuk, float[] keluar) throws Exception {
        buf.clear();
        buf.put(masuk);
        buf.rewind();
        try (OnnxTensor in = OnnxTensor.createTensor(env, buf, BENTUK);
             OrtSession.Result res = session.run(Collections.singletonMap(namaMasuk, in))) {
            FloatBuffer fb = ((OnnxTensor) res.get(0)).getFloatBuffer();
            fb.rewind();
            fb.get(keluar);
        }
    }

    @Override
    public void close() throws Exception {
        session.close();
    }
}
