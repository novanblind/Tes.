package com.novan.filemanagermax

import android.content.Context
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Baca, ekstrak, dan buat arsip: ZIP, 7z, TAR (gz, bz2, xz), GZ, dan RAR (hanya baca). */
object ArchiveOps {

    const val NONE = 0
    const val ZIP = 1
    const val SZ = 2
    const val RAR = 3
    const val TAR = 4
    const val TGZ = 5
    const val TBZ = 6
    const val TXZ = 7
    const val GZ = 8

    /** Format untuk membuat arsip. */
    const val OUT_ZIP = 0
    const val OUT_TGZ = 1
    const val OUT_7Z = 2
    const val OUT_ZIP_SPLIT = 3

    /** Tingkat kompresi untuk membuat arsip. */
    const val LEVEL_STORE = 0
    const val LEVEL_FAST = 1
    const val LEVEL_NORMAL = 2
    const val LEVEL_MAX = 3

    /** Kata sandi sementara di memori (hilang saat aplikasi ditutup), per jalur arsip. */
    val passwords = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** ZIP yang harus dibaca lewat zip4j: berkata sandi atau terpecah (bervolume). */
    fun needsZip4j(f: File): Boolean = try {
        val z = net.lingala.zip4j.ZipFile(f)
        z.isEncrypted || z.isSplitArchive
    } catch (e: Exception) {
        false
    }

    private const val MSG_LOCKED = "Arsip ini terkunci kata sandi."

    /** ZIP berkata sandi (ZipCrypto atau AES) lewat zip4j. */
    private fun walkZipEncrypted(f: File, visit: (ArchEntry, () -> InputStream) -> Boolean) {
        val pw = passwords[f.absolutePath]
        val zf = if (pw == null) net.lingala.zip4j.ZipFile(f) else net.lingala.zip4j.ZipFile(f, pw.toCharArray())
        val headers = zf.fileHeaders
        val first = headers.firstOrNull { !it.isDirectory && it.isEncrypted && it.uncompressedSize > 0 }
        if (first != null) {
            if (pw == null) throw PasswordRequired(MSG_LOCKED, false)
            try {
                zf.getInputStream(first).use { it.read() }
            } catch (e: net.lingala.zip4j.exception.ZipException) {
                if (e.type == net.lingala.zip4j.exception.ZipException.Type.WRONG_PASSWORD) {
                    throw PasswordRequired(MSG_LOCKED, true)
                }
                throw e
            }
        }
        for (fh in headers) {
            val name = norm(fh.fileName ?: "")
            if (name.isEmpty()) continue
            val time = try { fh.lastModifiedTimeEpoch } catch (e: Exception) { 0L }
            if (!visit(ArchEntry(name, fh.isDirectory, fh.uncompressedSize, time)) { zf.getInputStream(fh) }) break
        }
    }

    class ArchEntry(val path: String, val isDir: Boolean, val size: Long, val time: Long)

    private class NoClose(i: InputStream) : FilterInputStream(i) {
        override fun close() {}
    }

    fun typeOf(f: File): Int {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".zip") -> ZIP
            n.endsWith(".7z") -> SZ
            n.endsWith(".rar") || Regex(".*\\.r\\d\\d$").matches(n) -> RAR
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> TGZ
            n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz") -> TBZ
            n.endsWith(".tar.xz") || n.endsWith(".txz") -> TXZ
            n.endsWith(".tar") -> TAR
            n.endsWith(".gz") -> GZ
            else -> NONE
        }
    }

    fun isSupported(f: File): Boolean = f.isFile && typeOf(f) != NONE

    fun baseName(f: File): String {
        val n = f.name
        val l = n.lowercase()
        for (s in listOf(".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".tbz", ".txz", ".zip", ".7z", ".rar", ".tar", ".gz")) {
            if (l.endsWith(s)) return n.substring(0, n.length - s.length).ifEmpty { "arsip" }
        }
        return n
    }

    private fun norm(p: String): String = p.replace('\\', '/').trim('/')

    private fun tarStream(f: File, t: Int): InputStream {
        val raw = BufferedInputStream(FileInputStream(f))
        return when (t) {
            TGZ -> GzipCompressorInputStream(raw)
            TBZ -> BZip2CompressorInputStream(raw)
            TXZ -> XZCompressorInputStream(raw)
            else -> raw
        }
    }

    /**
     * Menelusuri isi arsip. [visit] menerima entri dan fungsi pembuka isi; kembalikan false untuk berhenti.
     * Untuk format berurutan (tar, 7z) isi hanya boleh dibaca selama [visit] berjalan.
     */
    fun walk(c: Context, f: File, visit: (ArchEntry, () -> InputStream) -> Boolean) {
        val t = typeOf(f)
        when (t) {
            ZIP -> if (needsZip4j(f)) walkZipEncrypted(f, visit) else ZipFile(f).use { zf ->
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e: ZipEntry = en.nextElement()
                    val name = norm(e.name)
                    if (name.isEmpty()) continue
                    if (!visit(ArchEntry(name, e.isDirectory, e.size, e.time)) { zf.getInputStream(e) }) break
                }
            }
            SZ -> SevenZFile(f).use { sz ->
                val ins = object : InputStream() {
                    override fun read(): Int = sz.read()
                    override fun read(b: ByteArray, off: Int, len: Int): Int = sz.read(b, off, len)
                }
                var e = sz.nextEntry
                while (e != null) {
                    val name = norm(e.name ?: "")
                    val time = if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L
                    if (name.isNotEmpty() && !visit(ArchEntry(name, e.isDirectory, e.size, time)) { ins }) break
                    e = sz.nextEntry
                }
            }
            TAR, TGZ, TBZ, TXZ -> TarArchiveInputStream(tarStream(f, t)).use { tis ->
                val shared = NoClose(tis)
                var e = tis.nextTarEntry
                while (e != null) {
                    val name = norm(e.name)
                    if (name.isNotEmpty() &&
                        !visit(ArchEntry(name, e.isDirectory, e.size, e.modTime.time)) { shared }
                    ) break
                    e = tis.nextTarEntry
                }
            }
            GZ -> GzipCompressorInputStream(BufferedInputStream(FileInputStream(f))).use { g ->
                val name = f.name.let { if (it.lowercase().endsWith(".gz")) it.dropLast(3) else it }
                visit(ArchEntry(name.ifEmpty { "isi" }, false, -1L, f.lastModified())) { NoClose(g) }
            }
            RAR -> RarSupport.walk(c, f, visit)
            else -> throw IOException("format tidak didukung")
        }
    }

    fun list(c: Context, f: File): List<ArchEntry> {
        val out = ArrayList<ArchEntry>()
        walk(c, f) { e, _ -> out.add(e); true }
        return out
    }

    private fun safeTarget(dest: File, rel: String): File? {
        if (rel.isEmpty()) return null
        val t = File(dest, rel)
        val base = dest.canonicalPath + File.separator
        return if ((t.canonicalPath + File.separator).startsWith(base)) t else null
    }

    /**
     * Mengekstrak entri yang lolos [filter] (semua bila null) ke [dest].
     * [strip] dibuang dari awal jalur entri. Mengembalikan jumlah berkas dan folder.
     */
    fun extract(
        c: Context, archive: File, dest: File,
        filter: ((ArchEntry) -> Boolean)? = null, strip: String = ""
    ): Int {
        dest.mkdirs()
        var n = 0
        walk(c, archive) { e, open ->
            if (filter == null || filter(e)) {
                val rel = e.path.removePrefix(strip).trim('/')
                val target = safeTarget(dest, rel)
                if (target != null) {
                    if (e.isDir) {
                        target.mkdirs()
                        n++
                    } else {
                        target.parentFile?.mkdirs()
                        open().use { ins ->
                            FileOutputStream(target).use { out -> ins.copyTo(out) }
                        }
                        if (e.time > 0) target.setLastModified(e.time)
                        n++
                    }
                }
            }
            true
        }
        return n
    }

    // ------------------------------------------------------------ ubah isi zip

    /** Satu entri pada daftar kerja zip. [src] jalur asli di zip, [srcFile] berkas luar yang akan dimasukkan. */
    data class Edit(
        val path: String, val isDir: Boolean, val size: Long, val time: Long,
        val src: String?, val srcFile: File?
    )

    private val EMPTY_ZIP = byteArrayOf(
        0x50, 0x4B, 0x05, 0x06, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    )

    private fun zipMap(zf: ZipFile?): HashMap<String, ZipEntry> {
        val map = HashMap<String, ZipEntry>()
        if (zf == null) return map
        val en = zf.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            map[norm(e.name)] = e
        }
        return map
    }

    private fun openItem(zf: ZipFile?, map: Map<String, ZipEntry>, item: Edit): InputStream {
        if (item.srcFile != null) return FileInputStream(item.srcFile)
        val e = map[item.src ?: ""] ?: throw IOException(item.src ?: item.path)
        return zf!!.getInputStream(e)
    }

    /** Mengekstrak daftar kerja (termasuk perubahan yang belum disimpan) ke [dest]. */
    fun extractItems(archive: File, items: List<Edit>, dest: File, strip: String, p: Progress? = null): Int {
        if (typeOf(archive) == ZIP && needsZip4j(archive)) return extractItemsEncrypted(archive, items, dest, strip, p)
        dest.mkdirs()
        var n = 0
        val zf = if (items.any { it.src != null } && typeOf(archive) == ZIP) ZipFile(archive) else null
        try {
            val map = zipMap(zf)
            for (item in items) {
                p?.check()
                val rel = item.path.removePrefix(strip).trim('/')
                val target = safeTarget(dest, rel) ?: continue
                if (item.isDir) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    p?.label = target.name
                    openItem(zf, map, item).use { ins ->
                        FileOutputStream(target).use { out -> FileOps.pump(ins, out, p) }
                    }
                    if (item.time > 0) target.setLastModified(item.time)
                }
                n++
            }
        } finally {
            zf?.close()
        }
        return n
    }

    private fun extractItemsEncrypted(archive: File, items: List<Edit>, dest: File, strip: String, p: Progress?): Int {
        dest.mkdirs()
        val pw = passwords[archive.absolutePath]
        val zf = if (pw == null) net.lingala.zip4j.ZipFile(archive) else net.lingala.zip4j.ZipFile(archive, pw.toCharArray())
        val byName = HashMap<String, net.lingala.zip4j.model.FileHeader>()
        for (fh in zf.fileHeaders) byName[norm(fh.fileName ?: "")] = fh
        var n = 0
        for (item in items) {
            p?.check()
            val rel = item.path.removePrefix(strip).trim('/')
            val target = safeTarget(dest, rel) ?: continue
            if (item.isDir) {
                target.mkdirs()
            } else {
                val fh = byName[item.path] ?: continue
                target.parentFile?.mkdirs()
                p?.label = target.name
                zf.getInputStream(fh).use { ins ->
                    FileOutputStream(target).use { out -> FileOps.pump(ins, out, p) }
                }
                if (item.time > 0) target.setLastModified(item.time)
            }
            n++
        }
        return n
    }

    /** Membuang entri tingkat atas [tops] (beserta isinya) dari [zip] di disk. */
    fun removeFromZip(c: Context, zip: File, tops: List<String>) {
        val keep = list(c, zip)
            .map { Edit(it.path, it.isDir, it.size, it.time, if (it.isDir) null else it.path, null) }
            .filter { e -> tops.none { e.path == it || e.path.startsWith("$it/") } }
        rewriteZip(zip, keep)
    }

    /** Menulis ulang [zip] sesuai [items], lewat berkas sementara agar zip asli aman bila gagal. */
    fun rewriteZip(zip: File, items: List<Edit>) {
        val tmp = File(zip.parentFile, zip.name + ".tmp")
        try {
            if (items.isEmpty()) {
                FileOutputStream(tmp).use { it.write(EMPTY_ZIP) }
            } else {
                ZipFile(zip).use { zf ->
                    val map = zipMap(zf)
                    ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zos ->
                        val written = HashSet<String>()
                        for (item in items) {
                            val name = if (item.isDir) item.path + "/" else item.path
                            if (!written.add(name)) continue
                            val ze = ZipEntry(name)
                            if (item.time > 0) ze.time = item.time
                            zos.putNextEntry(ze)
                            if (!item.isDir) {
                                openItem(zf, map, item).use { ins -> ins.copyTo(zos) }
                            }
                            zos.closeEntry()
                        }
                    }
                }
            }
            java.nio.file.Files.move(
                tmp.toPath(), zip.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
            )
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    // ------------------------------------------------------------ membuat arsip

    fun outExt(format: Int): String = when (format) {
        OUT_TGZ -> ".tar.gz"
        OUT_7Z -> ".7z"
        else -> ".zip"
    }

    /** Tingkat deflate (0-9) untuk ZIP dan GZ. */
    private fun deflateLevel(level: Int): Int = when (level) {
        LEVEL_STORE -> 0
        LEVEL_FAST -> 1
        LEVEL_MAX -> 9
        else -> 6
    }

    fun compress(
        files: List<File>, format: Int, out: File, p: Progress? = null, level: Int = LEVEL_NORMAL,
        password: String? = null, splitSize: Long = 0L
    ) {
        try {
            when (format) {
                OUT_ZIP_SPLIT -> compressZipSplit(files, out, p, level, password, splitSize)
                OUT_TGZ -> compressTar(files, out, p, level)
                OUT_7Z -> compress7z(files, out, p, level)
                else -> if (password.isNullOrEmpty()) compressZip(files, out, p, level) else compressZipEncrypted(files, out, p, level, password)
            }
        } catch (e: Exception) {
            out.delete()
            deleteZipParts(out)
            throw e
        }
    }

    /** Menghapus bagian .z01, .z02, … milik [zip]. */
    private fun deleteZipParts(zip: File) {
        val base = zip.name.removeSuffix(".zip")
        zip.parentFile?.listFiles()?.forEach {
            if (Regex(Regex.escape(base) + "\\.z\\d+").matches(it.name)) it.delete()
        }
    }

    /** ZIP terpecah (bervolume): .z01, .z02, …, lalu .zip sebagai bagian terakhir. */
    private fun compressZipSplit(files: List<File>, out: File, p: Progress?, level: Int, password: String?, splitSize: Long) {
        require(splitSize >= 65536L) { "Ukuran bagian minimal 64 KB" }
        val zf = if (password.isNullOrEmpty()) net.lingala.zip4j.ZipFile(out)
        else net.lingala.zip4j.ZipFile(out, password.toCharArray())
        val params = net.lingala.zip4j.model.ZipParameters()
        if (!password.isNullOrEmpty()) {
            params.setEncryptFiles(true)
            params.setEncryptionMethod(net.lingala.zip4j.model.enums.EncryptionMethod.AES)
            params.setAesKeyStrength(net.lingala.zip4j.model.enums.AesKeyStrength.KEY_STRENGTH_256)
        }
        if (level == LEVEL_STORE) {
            params.setCompressionMethod(net.lingala.zip4j.model.enums.CompressionMethod.STORE)
        } else {
            params.setCompressionLevel(
                when (level) {
                    LEVEL_FAST -> net.lingala.zip4j.model.enums.CompressionLevel.FASTEST
                    LEVEL_MAX -> net.lingala.zip4j.model.enums.CompressionLevel.MAXIMUM
                    else -> net.lingala.zip4j.model.enums.CompressionLevel.NORMAL
                }
            )
        }
        zf.setRunInThread(true)
        zf.createSplitZipFile(files.filter { it.canonicalPath != out.canonicalPath }, params, true, splitSize)
        val pm = zf.progressMonitor
        while (pm.state == net.lingala.zip4j.progress.ProgressMonitor.State.BUSY) {
            if (p != null) {
                p.label = pm.fileName ?: p.label
                val tw = pm.totalWork
                if (tw > 0 && p.total > 0) p.advanceTo(pm.workCompleted * p.total / tw)
                if (p.cancelled) pm.setCancelAllTasks(true)
            }
            Thread.sleep(150)
        }
        when (pm.result) {
            net.lingala.zip4j.progress.ProgressMonitor.Result.SUCCESS -> {}
            net.lingala.zip4j.progress.ProgressMonitor.Result.CANCELLED -> throw OpCancelled()
            else -> throw (pm.exception ?: IOException("Gagal membuat ZIP terpecah"))
        }
    }

    /** Memecah satu berkas menjadi potongan polos nama.001, nama.002, … di [dir]. */
    fun splitFile(file: File, dir: File, size: Long, p: Progress? = null): List<File> {
        require(size >= 65536L) { "Ukuran bagian minimal 64 KB" }
        val made = ArrayList<File>()
        try {
            var index = 1
            FileInputStream(file).use { ins ->
                val buf = ByteArray(64 * 1024)
                var eof = false
                while (!eof) {
                    p?.check()
                    val part = File(dir, file.name + String.format(".%03d", index))
                    var written = 0L
                    FileOutputStream(part).use { out ->
                        made.add(part)
                        while (written < size) {
                            val r = ins.read(buf, 0, minOf(buf.size.toLong(), size - written).toInt())
                            if (r < 0) { eof = true; break }
                            out.write(buf, 0, r)
                            written += r
                            p?.add(r.toLong())
                        }
                    }
                    if (written == 0L) { part.delete(); made.remove(part); break }
                    index++
                }
            }
        } catch (e: Exception) {
            made.forEach { it.delete() }
            throw e
        }
        return made
    }

    /** Potongan polos berurutan yang dimulai dari [first] (nama.001). Kosong bila bukan potongan pertama. */
    fun partsOf(first: File): List<File> {
        if (!first.name.endsWith(".001")) return emptyList()
        val base = first.name.removeSuffix(".001")
        val out = ArrayList<File>()
        var i = 1
        while (true) {
            val f = File(first.parentFile, base + String.format(".%03d", i))
            if (!f.isFile) break
            out.add(f)
            i++
        }
        return out
    }

    /** Menggabung potongan polos menjadi satu berkas [out]. */
    fun joinParts(parts: List<File>, out: File, p: Progress? = null) {
        try {
            FileOutputStream(out).use { o ->
                for (part in parts) {
                    p?.check()
                    p?.label = part.name
                    FileInputStream(part).use { FileOps.pump(it, o, p) }
                }
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
    }

    private fun walkFiles(f: File, name: String, out: File, visit: (File, String) -> Unit) {
        if (f.canonicalPath == out.canonicalPath) return
        visit(f, name)
        if (f.isDirectory) {
            f.listFiles()?.sortedBy { it.name }?.forEach { walkFiles(it, "$name/${it.name}", out, visit) }
        }
    }

    private fun compressZip(files: List<File>, out: File, p: Progress?, level: Int) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            zos.setLevel(deflateLevel(level))
            val buf = ByteArray(64 * 1024)
            for (root in files) {
                walkFiles(root, root.name, out) { f, name ->
                    p?.check()
                    if (f.isDirectory) {
                        val e = ZipEntry("$name/")
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        zos.closeEntry()
                    } else {
                        val e = ZipEntry(name)
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        p?.label = f.name
                        FileInputStream(f).use { ins ->
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                zos.write(buf, 0, r)
                                p?.add(r.toLong())
                            }
                        }
                        zos.closeEntry()
                    }
                }
            }
        }
    }

    /** ZIP berkata sandi dengan enkripsi AES-256 (dibuka WinRAR, 7-Zip, dan sejenisnya). */
    private fun compressZipEncrypted(files: List<File>, out: File, p: Progress?, level: Int, password: String) {
        val zf = net.lingala.zip4j.ZipFile(out, password.toCharArray())
        for (root in files) {
            walkFiles(root, root.name, out) { f, name ->
                p?.check()
                if (f.isFile) {
                    val params = net.lingala.zip4j.model.ZipParameters()
                    params.setEncryptFiles(true)
                    params.setEncryptionMethod(net.lingala.zip4j.model.enums.EncryptionMethod.AES)
                    params.setAesKeyStrength(net.lingala.zip4j.model.enums.AesKeyStrength.KEY_STRENGTH_256)
                    params.setFileNameInZip(name)
                    params.setLastModifiedFileTime(f.lastModified())
                    if (level == LEVEL_STORE) {
                        params.setCompressionMethod(net.lingala.zip4j.model.enums.CompressionMethod.STORE)
                    } else {
                        params.setCompressionLevel(
                            when (level) {
                                LEVEL_FAST -> net.lingala.zip4j.model.enums.CompressionLevel.FASTEST
                                LEVEL_MAX -> net.lingala.zip4j.model.enums.CompressionLevel.MAXIMUM
                                else -> net.lingala.zip4j.model.enums.CompressionLevel.NORMAL
                            }
                        )
                    }
                    p?.label = f.name
                    FileInputStream(f).use { zf.addStream(it, params) }
                    p?.add(f.length())
                }
            }
        }
    }

    private fun compressTar(files: List<File>, out: File, p: Progress?, level: Int) {
        val gz = org.apache.commons.compress.compressors.gzip.GzipParameters()
        gz.compressionLevel = deflateLevel(level)
        TarArchiveOutputStream(
            GzipCompressorOutputStream(BufferedOutputStream(FileOutputStream(out)), gz)
        ).use { tos ->
            tos.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            tos.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
            for (root in files) {
                walkFiles(root, root.name, out) { f, name ->
                    p?.check()
                    val e = TarArchiveEntry(f, name)
                    tos.putArchiveEntry(e)
                    if (f.isFile) {
                        p?.label = f.name
                        FileInputStream(f).use { FileOps.pump(it, tos, p) }
                    }
                    tos.closeArchiveEntry()
                }
            }
            tos.finish()
        }
    }

    private fun compress7z(files: List<File>, out: File, p: Progress?, level: Int) {
        SevenZOutputFile(out).use { sz ->
            // LZMA2; tingkat maksimum dibatasi 7 agar memori di ponsel tidak jebol
            val method = when (level) {
                LEVEL_STORE -> org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration(
                    org.apache.commons.compress.archivers.sevenz.SevenZMethod.COPY
                )
                else -> org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration(
                    org.apache.commons.compress.archivers.sevenz.SevenZMethod.LZMA2,
                    when (level) { LEVEL_FAST -> 1; LEVEL_MAX -> 7; else -> 5 }
                )
            }
            sz.setContentMethods(listOf(method))
            val buf = ByteArray(64 * 1024)
            for (root in files) {
                walkFiles(root, root.name, out) { f, name ->
                    p?.check()
                    val e = sz.createArchiveEntry(f, name)
                    sz.putArchiveEntry(e)
                    if (f.isFile) {
                        p?.label = f.name
                        FileInputStream(f).use { ins ->
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                sz.write(buf, 0, r)
                                p?.add(r.toLong())
                            }
                        }
                    }
                    sz.closeArchiveEntry()
                }
            }
            sz.finish()
        }
    }
}
