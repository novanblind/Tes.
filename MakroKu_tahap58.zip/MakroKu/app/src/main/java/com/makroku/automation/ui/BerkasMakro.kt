package com.makroku.automation.ui

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.content.IntentCompat
import com.makroku.automation.data.ImportResult
import java.io.File

/** Ekstensi berkas makro MakroKu. Isinya JSON daftar makro (sama dengan Ekspor makro). */
const val EKSTENSI_MAKRO = "makroku"

private fun namaAman(s: String): String =
    s.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().take(40).ifBlank { "makro" }

/**
 * Tulis [json] ke berkas `<nama>.makroku` di cache lalu bagikan lewat menu Bagikan Android
 * (WhatsApp, Telegram, Bluetooth, surel, dsb). Penerima yang memasang MakroKu cukup membuka berkasnya.
 */
fun shareMacroFile(ctx: Context, nama: String, json: String) {
    runCatching {
        val dir = File(ctx.cacheDir, "bagikan").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "${namaAman(nama)}.$EKSTENSI_MAKRO")
        f.writeText(json)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_SEND)
            .setType("application/octet-stream")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, nama)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri(f.name, uri)
        ctx.startActivity(Intent.createChooser(i, "Bagikan berkas makro").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { Toast.makeText(ctx, "Tidak bisa membagikan: ${it.message}", Toast.LENGTH_LONG).show() }
}

/** Ambil Uri berkas dari intent buka (VIEW) atau bagikan (SEND) bila ada. */
fun uriDariIntent(i: Intent?): Uri? {
    if (i == null) return null
    return when (i.action) {
        Intent.ACTION_VIEW -> i.data
        Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
        else -> null
    }
}

/** Baca isi teks berkas (maksimal 5 MB). */
fun bacaTeksUri(ctx: Context, uri: Uri): String {
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Berkas tidak bisa dibuka")
    require(bytes.size <= 5 * 1024 * 1024) { "Berkas terlalu besar" }
    return bytes.decodeToString()
}

/** Kotak konfirmasi sebelum makro dari berkas diterapkan. */
@Composable
fun ImportMacroDialog(hasil: ImportResult, onApply: () -> Unit, onCancel: () -> Unit) {
    val list = hasil.macros
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(if (list.size == 1) "Terapkan makro ini?" else "Terapkan ${list.size} makro ini?") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                list.forEach { Text("• " + it.name.ifBlank { "(tanpa nama)" }) }
                if (hasil.variables.isNotEmpty()) Text("• ${hasil.variables.size} variabel dipulihkan (nilai yang sama menimpa variabel lama)")
                if (hasil.warnings.isNotEmpty()) {
                    Text("\nBagian yang tidak bisa dibawa dari berkas asli:")
                    hasil.warnings.forEach { Text("– $it") }
                }
                Text("\nMakro masuk dengan setelan aslinya (aktif atau nonaktif) dan tidak menimpa makro yang sudah ada. Terapkan hanya dari sumber yang Anda percaya, karena makro bisa menjalankan aksi di HP ini.")
            }
        },
        confirmButton = { TextButton(onClick = onApply) { Text("Terapkan") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Batal") } },
    )
}
