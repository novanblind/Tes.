package novan.terminal;

import android.os.Environment;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Tanda tangan pribadi untuk bangun-apk: pasangan kunci RSA 2048, sertifikat X.509
 * self-signed (SHA256withRSA), disimpan sebagai PKCS12 (.p12) di penyimpanan privat
 * aplikasi. Tidak memakai pustaka tambahan (DER ditulis manual), sama seperti aplikasi
 * GitHub by novan.
 */
public class Ks {
    static final String HURUF = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    static void out(String s) { MainActivity.H.post(() -> MainActivity.add(s)); }
    static void say(String s) { MainActivity.H.post(() -> MainActivity.say(s)); }

    static File dir() { File d = new File(Env.prefix.getParentFile(), "tanda-tangan"); d.mkdirs(); return d; }
    static File p12(String nama) { return new File(dir(), nama + ".p12"); }
    static File info(String nama) { return new File(dir(), nama + ".properties"); }
    static File aktifFile() { return new File(dir(), "aktif.txt"); }

    static String nama(String s) {
        String n = s.trim().replaceAll("[^A-Za-z0-9_-]", "");
        return n;
    }

    static String sandiAcak() {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) sb.append(HURUF.charAt(r.nextInt(HURUF.length())));
        return sb.toString();
    }

    /** Daftar nama tanda tangan pribadi yang tersimpan. */
    static List<String> daftar() {
        ArrayList<String> r = new ArrayList<>();
        File[] fs = dir().listFiles();
        if (fs != null) {
            for (File f : fs) if (f.getName().endsWith(".p12")) r.add(f.getName().substring(0, f.getName().length() - 4));
        }
        Collections.sort(r);
        return r;
    }

    /** Nama tanda tangan aktif, atau "bawaan" bila belum dipilih / sudah dihapus. */
    static String aktif() {
        File f = aktifFile();
        if (!f.exists()) return "bawaan";
        try {
            String n = readAll(f).trim();
            if (n.isEmpty() || n.equals("bawaan")) return "bawaan";
            if (!p12(n).exists()) return "bawaan";
            return n;
        } catch (IOException e) { return "bawaan"; }
    }

    /**
     * Tanda tangan yang dipakai otomatis saat Bangun APK, atau null bila perlu bertanya.
     * Pilihan yang pernah dibuat (termasuk "bawaan") dihormati; bila belum pernah memilih,
     * tanda tangan pribadi terbaru dipakai bila ada, kalau tidak ada dipakai tanda tangan bawaan proyek.
     */
    static String otomatis() {
        try {
            File f = aktifFile();
            if (f.exists()) {
                String n = readAll(f).trim();
                if (n.equals("bawaan") || (!n.isEmpty() && p12(n).exists())) return n;
            }
        } catch (IOException e) { }
        // Bawaan: tanda tangan pribadi bila ada (yang terbaru dibuat atau diimpor), kalau tidak ada memakai bawaan proyek.
        List<String> l = daftar();
        if (l.isEmpty()) return "bawaan";
        String baru = l.get(0);
        for (String n : l) if (p12(n).lastModified() > p12(baru).lastModified()) baru = n;
        setAktif(baru);
        return baru;
    }

    /** Pilih tanda tangan aktif tanpa menulis apa pun ke layar (dipakai dialog Bangun APK). */
    static void setAktif(String nm) {
        try { write(aktifFile(), nm); } catch (IOException e) { }
    }

    static void pilih(String arg) {
        String n = arg.trim();
        if (n.isEmpty()) { out("Tulis nama tanda tangan. Contoh: pilih-ttd bawaan"); say("Tulis nama tanda tangan"); return; }
        if (n.equals("bawaan")) {
            try { write(aktifFile(), "bawaan"); } catch (IOException e) {}
            out("Tanda tangan aktif: bawaan (debug)"); say("Tanda tangan aktif sekarang bawaan"); return;
        }
        String nm = nama(n);
        if (!p12(nm).exists()) { out("Tidak ditemukan tanda tangan pribadi: " + nm + ". Ketik daftar-ttd untuk melihat yang tersimpan."); say("Tidak ditemukan"); return; }
        try { write(aktifFile(), nm); } catch (IOException e) {}
        out("Tanda tangan aktif: " + nm + " (pribadi)"); say("Tanda tangan aktif sekarang " + nm);
    }

    static void daftarCmd() {
        List<String> l = daftar();
        String a = aktif();
        out("Bawaan (debug)" + (a.equals("bawaan") ? "  <- aktif" : ""));
        if (l.isEmpty()) { out("Belum ada tanda tangan pribadi. Ketik: buat-ttd <nama>"); }
        for (String n : l) out(n + (n.equals(a) ? "  <- aktif" : ""));
        say(l.isEmpty() ? "Hanya ada tanda tangan bawaan" : l.size() + " tanda tangan pribadi tersimpan, aktif: " + a);
    }

    static void hapus(String arg) {
        String nm = nama(arg);
        if (nm.isEmpty()) { out("Tulis nama tanda tangan yang dihapus"); say("Tulis nama tanda tangan"); return; }
        if (!p12(nm).exists()) { out("Tidak ditemukan: " + nm); say("Tidak ditemukan"); return; }
        p12(nm).delete();
        info(nm).delete();
        if (aktif().equals(nm)) aktifFile().delete();
        out("Tanda tangan dihapus: " + nm); say("Tanda tangan " + nm + " dihapus");
    }

    /** buat-ttd <nama>: pasangan kunci baru, sandi dan alias dibuat acak. */
    static void buat(String arg) { buat(arg, null); }

    /** Sama seperti buat-ttd, tetapi menjalankan {@code selesai} (di thread utama) setelah berhasil dibuat. */
    static void buat(String arg, Runnable selesai) {
        String nm = nama(arg);
        if (nm.isEmpty()) { out("Tulis nama tanda tangan. Contoh: buat-ttd pribadi"); say("Tulis nama tanda tangan"); return; }
        if (p12(nm).exists()) { out("Sudah ada tanda tangan bernama " + nm + ". Pakai nama lain atau hapus-ttd " + nm + " dulu."); say("Sudah ada"); return; }
        say("Membuat tanda tangan, mohon tunggu");
        new Thread(() -> {
            try {
                String alias = "novan";
                String sandi = sandiAcak();
                Hasil h = buatInternal(nm, alias, sandi);
                simpan(nm, h);
                out("Tanda tangan dibuat: " + nm);
                out("Alias: " + h.alias);
                out("Sandi: " + h.sandi + "  (simpan baik-baik, tidak ditampilkan lagi otomatis)");
                out("Sidik jari SHA-256: " + h.sidikJari);
                out("Berlaku 100 tahun. Aktifkan dengan: pilih-ttd " + nm);
                say("Tanda tangan " + nm + " berhasil dibuat");
                if (selesai != null) MainActivity.H.post(selesai);
            } catch (Throwable e) {
                out("Gagal membuat tanda tangan: " + e.getMessage());
                say("Gagal membuat tanda tangan");
            }
        }).start();
    }

    static class Hasil { byte[] data; String alias, sandi, sidikJari; }

    static Hasil buatInternal(String cn, String alias, String sandi) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();
        byte[] der = sertifikatDari(kp, cn);
        Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        char[] pw = sandi.toCharArray();
        ks.setKeyEntry(alias, kp.getPrivate(), pw, new Certificate[]{cert});
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ks.store(bos, pw);
        Hasil h = new Hasil();
        h.data = bos.toByteArray();
        h.alias = alias;
        h.sandi = sandi;
        h.sidikJari = sidikJari(der);
        return h;
    }

    static void simpan(String nm, Hasil h) throws IOException {
        try (FileOutputStream o = new FileOutputStream(p12(nm))) { o.write(h.data); }
        Properties p = new Properties();
        p.setProperty("alias", h.alias);
        p.setProperty("sandi", h.sandi);
        p.setProperty("sidikJari", h.sidikJari);
        p.setProperty("dibuat", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
        try (FileOutputStream o = new FileOutputStream(info(nm))) { p.store(o, "Tanda tangan pribadi " + nm); }
    }

    static Properties muat(String nm) throws IOException {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(info(nm))) { p.load(in); }
        return p;
    }

    static List<File> hasilCari = new ArrayList<>();

    /** Cari berkas .p12 atau .pfx: di Download beserta semua subfoldernya (sampai 6 tingkat), dan langsung di penyimpanan utama. */
    static List<File> cari() {
        LinkedHashMap<String, File> found = new LinkedHashMap<>();
        File root = Environment.getExternalStorageDirectory();
        telusuri(new File(root, "Download"), 0, 6, found, new int[]{0});
        telusuri(root, 0, 0, found, new int[]{0});
        List<File> r = new ArrayList<>(found.values());
        Collections.sort(r, (x, y) -> x.getPath().compareToIgnoreCase(y.getPath()));
        return r;
    }

    private static void telusuri(File dir, int dalam, int maks, Map<String, File> found, int[] hitung) {
        File[] fs = dir.listFiles();
        if (fs == null || ++hitung[0] > 2000) return;
        for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.US);
            if (f.isFile()) {
                if (n.endsWith(".p12") || n.endsWith(".pfx")) found.put(f.getPath(), f);
            } else if (f.isDirectory() && dalam < maks && !n.startsWith(".")) {
                telusuri(f, dalam + 1, maks, found, hitung);
            }
        }
    }

    /** Lokasi folder berkas tanpa awalan penyimpanan utama, misalnya "Download/ttd". */
    static String lokasiSingkat(File f) {
        String p = f.getParentFile() == null ? "" : f.getParentFile().getPath();
        String r = Environment.getExternalStorageDirectory().getPath();
        if (p.startsWith(r)) p = p.substring(r.length());
        while (p.startsWith("/")) p = p.substring(1);
        return p.isEmpty() ? "penyimpanan utama" : p;
    }

    /** cari-ttd: tampilkan berkas .p12 yang ditemukan, bernomor. */
    static void cariCmd() {
        hasilCari = cari();
        if (hasilCari.isEmpty()) {
            out("Tidak ditemukan berkas .p12 di Download (termasuk subfolder) atau penyimpanan utama. Ketik jelajah-ttd untuk mencari di folder lain, atau pastikan izin penyimpanan aktif (ketik izin), atau tulis lokasi lengkap: impor-ttd <lokasi> <sandi> [alias] [nama]");
            say("Tidak ditemukan berkas p12"); return;
        }
        for (int i = 0; i < hasilCari.size(); i++) out((i + 1) + ". " + hasilCari.get(i).getPath());
        out("Ketik: impor-ttd <nomor> <sandi>");
        say(hasilCari.size() + " berkas ditemukan. Ketik impor-ttd lalu nomor dan sandi");
    }

    /** jelajah-ttd: pilih berkas .p12 atau .pfx di folder mana saja; hasilnya masuk daftar bernomor untuk impor-ttd. */
    static void jelajahCmd(final android.app.Activity a) {
        Jelajah.buka(a, "Pilih berkas tanda tangan (.p12 atau .pfx)", new String[]{".p12", ".pfx"}, false, f -> {
            hasilCari = new ArrayList<>();
            hasilCari.add(f);
            out("Dipilih: " + f.getPath());
            out("Ketik: impor-ttd 1 <sandi>");
            say("Berkas dipilih. Ketik impor-ttd 1 lalu sandi");
        });
    }

    /** Hasil impor: ok bila berhasil; banyakAlias terisi bila berkas punya beberapa alias dan harus dipilih. */
    static class Impor { boolean ok; String pesan = "", nama = ""; List<String> banyakAlias; }

    /** Salin keystore luar ke penyimpanan tanda tangan. Alias terdeteksi otomatis bila cuma satu di berkas. */
    static Impor imporFile(File src, String sandi, String aliasArg, String nmArg) {
        Impor h = new Impor();
        if (!src.exists()) { h.pesan = "Berkas tidak ditemukan: " + src.getPath(); return h; }
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            try (InputStream in = new FileInputStream(src)) { ks.load(in, sandi.toCharArray()); }
            String alias = aliasArg;
            if (alias.isEmpty()) {
                List<String> al = Collections.list(ks.aliases());
                if (al.isEmpty()) { h.pesan = "Tidak ada alias dalam berkas ini."; return h; }
                if (al.size() == 1) alias = al.get(0);
                else { h.banyakAlias = al; h.pesan = "Ada beberapa alias dalam berkas ini, pilih salah satu."; return h; }
            }
            if (!ks.containsAlias(alias)) { h.pesan = "Alias tidak ditemukan di berkas: " + alias; return h; }
            Certificate cert = ks.getCertificate(alias);
            String sj = sidikJari(cert.getEncoded());
            String nm = nama(!nmArg.isEmpty() ? nmArg : src.getName().replaceAll("(?i)\\.(p12|pfx)$", ""));
            if (nm.isEmpty()) nm = "impor";
            if (p12(nm).exists()) { h.pesan = "Sudah ada tanda tangan bernama " + nm + ". Hapus yang lama atau pakai nama lain."; return h; }
            try (InputStream in = new FileInputStream(src); FileOutputStream o = new FileOutputStream(p12(nm))) { Pkg.copy(in, o); }
            Properties p = new Properties();
            p.setProperty("alias", alias);
            p.setProperty("sandi", sandi);
            p.setProperty("sidikJari", sj);
            p.setProperty("dibuat", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
            try (FileOutputStream o = new FileOutputStream(info(nm))) { p.store(o, "Tanda tangan pribadi " + nm + " (diimpor)"); }
            h.ok = true; h.nama = nm;
            h.pesan = "Tanda tangan diimpor: " + nm + ". Alias: " + alias + ". Sidik jari SHA-256: " + sj;
            return h;
        } catch (Exception e) {
            h.pesan = "Gagal impor: " + e.getMessage() + " (sandi salah atau bukan berkas .p12)";
            return h;
        }
    }

    /** impor-ttd <nomor-dari-cari-ttd atau lokasi.p12> <sandi> [alias] [nama] */
    static void impor(String arg) {
        String[] a = arg.trim().split("\\s+", 4);
        if (a.length < 2 || a[0].isEmpty()) {
            out("Pakai: impor-ttd <nomor dari cari-ttd, atau lokasi lengkap .p12> <sandi> [alias] [nama]");
            say("Format: impor-ttd nomor atau lokasi, lalu sandi"); return;
        }
        File src;
        if (a[0].matches("\\d+")) {
            int idx = Integer.parseInt(a[0]) - 1;
            if (idx < 0 || idx >= hasilCari.size()) { out("Nomor tidak ada di daftar. Ketik cari-ttd dulu."); say("Nomor tidak ada di daftar"); return; }
            src = hasilCari.get(idx);
        } else {
            src = new File(a[0]);
        }
        Impor h = imporFile(src, a[1], a.length > 2 ? a[2].trim() : "", a.length > 3 ? a[3].trim() : "");
        if (h.banyakAlias != null) {
            StringBuilder sb = new StringBuilder();
            for (String s : h.banyakAlias) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
            out("Ada beberapa alias dalam berkas ini: " + sb + ". Tulis ulang: impor-ttd " + a[0] + " " + a[1] + " <alias>");
            say("Ada beberapa alias, tulis alias yang dipakai"); return;
        }
        out(h.pesan);
        if (h.ok) out("Aktifkan dengan: pilih-ttd " + h.nama);
        say(h.ok ? "Tanda tangan " + h.nama + " berhasil diimpor" : h.pesan);
    }

    /** ekspor-ttd <nama>: salin .p12 dan berkas info ke folder Download, untuk cadangan. */
    static void ekspor(String arg) {
        String nm = nama(arg);
        if (nm.isEmpty()) { out("Tulis nama tanda tangan yang diekspor"); say("Tulis nama tanda tangan"); return; }
        if (!p12(nm).exists()) { out("Tidak ditemukan: " + nm); say("Tidak ditemukan"); return; }
        try {
            File dl = new File(Environment.getExternalStorageDirectory(), "Download");
            if (!dl.isDirectory() || !dl.canWrite()) { out("Folder Download tidak bisa ditulis. Ketik izin untuk memberi akses penyimpanan."); say("Tidak bisa menulis ke Download"); return; }
            File outP12 = new File(dl, nm + ".p12");
            try (InputStream in = new FileInputStream(p12(nm)); OutputStream o = new FileOutputStream(outP12)) { Pkg.copy(in, o); }
            Properties p = muat(nm);
            File outInfo = new File(dl, nm + "-info.txt");
            write(outInfo, "Nama: " + nm + "\nAlias: " + p.getProperty("alias") + "\nSandi: " + p.getProperty("sandi")
                + "\nSidik jari SHA-256: " + p.getProperty("sidikJari") + "\nDibuat: " + p.getProperty("dibuat") + "\n");
            out("Diekspor ke: " + outP12.getPath());
            out("Info (alias dan sandi): " + outInfo.getPath());
            say("Tanda tangan " + nm + " diekspor ke Download");
        } catch (Exception e) {
            out("Gagal ekspor: " + e.getMessage());
            say("Gagal ekspor tanda tangan");
        }
    }

    // ---------- berkas ----------
    static String readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] t = new byte[4096]; int n;
            while ((n = in.read(t)) > 0) b.write(t, 0, n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    static void write(File f, String s) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes(StandardCharsets.UTF_8)); }
    }

    // ---------- sidik jari ----------
    static String sidikJari(byte[] der) throws Exception {
        byte[] d = java.security.MessageDigest.getInstance("SHA-256").digest(der);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i++) { if (i > 0) sb.append(':'); sb.append(String.format(Locale.US, "%02X", d[i] & 0xFF)); }
        return sb.toString();
    }

    // ---------- DER minimal (tanpa pustaka tambahan) ----------
    static byte[] tlv(int tag, byte[]... isi) {
        ByteArrayOutputStream c = new ByteArrayOutputStream();
        for (byte[] b : isi) c.write(b, 0, b.length);
        byte[] body = c.toByteArray();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = body.length;
        if (n < 128) { o.write(n); }
        else if (n < 256) { o.write(0x81); o.write(n); }
        else if (n < 65536) { o.write(0x82); o.write(n >> 8); o.write(n & 0xFF); }
        else { o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 0xFF); o.write(n & 0xFF); }
        o.write(body, 0, body.length);
        return o.toByteArray();
    }
    static byte[] seq(byte[]... x) { return tlv(0x30, x); }
    static byte[] set(byte[]... x) { return tlv(0x31, x); }
    static byte[] oid(int... a) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(a[0] * 40 + a[1]);
        for (int i = 2; i < a.length; i++) {
            int v = a[i];
            if (v < 128) { o.write(v); }
            else {
                int[] part = new int[5]; int k = 0;
                while (v > 0) { part[k++] = v & 0x7F; v >>= 7; }
                for (int j = k - 1; j >= 0; j--) o.write(part[j] | (j > 0 ? 0x80 : 0));
            }
        }
        return tlv(0x06, o.toByteArray());
    }
    static byte[] waktu(Date d) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTime(d);
        boolean panjang = c.get(Calendar.YEAR) >= 2050;
        SimpleDateFormat f = new SimpleDateFormat(panjang ? "yyyyMMddHHmmss'Z'" : "yyMMddHHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return tlv(panjang ? 0x18 : 0x17, f.format(d).getBytes(StandardCharsets.US_ASCII));
    }
    static byte[] atribut(byte[] oid, int tagTeks, String nilai) {
        return set(seq(oid, tlv(tagTeks, nilai.getBytes(StandardCharsets.UTF_8))));
    }
    static byte[] namaX500(String cn) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] p = atribut(oid(2, 5, 4, 3), 0x0C, cn);
        b.write(p, 0, p.length);
        return tlv(0x30, b.toByteArray());
    }
    static byte[] sertifikatDari(KeyPair kp, String cn) throws Exception {
        byte[] algo = seq(oid(1, 2, 840, 113549, 1, 1, 11), tlv(0x05, new byte[0]));
        byte[] sn = new byte[16];
        new SecureRandom().nextBytes(sn);
        sn[0] &= 0x7F; if (sn[0] == 0) sn[0] = 1;
        byte[] serial = tlv(0x02, sn);
        Calendar mulai = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        mulai.add(Calendar.DAY_OF_YEAR, -1);
        Calendar akhir = (Calendar) mulai.clone();
        akhir.add(Calendar.YEAR, 100);
        byte[] nama = namaX500(cn);
        byte[] tbs = seq(
            tlv(0xA0, tlv(0x02, new byte[]{2})),
            serial, algo, nama,
            seq(waktu(mulai.getTime()), waktu(akhir.getTime())),
            nama,
            kp.getPublic().getEncoded());
        Signature sg = Signature.getInstance("SHA256withRSA");
        sg.initSign(kp.getPrivate());
        sg.update(tbs);
        byte[] sig = sg.sign();
        byte[] bits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bits, 1, sig.length);
        return seq(tbs, algo, tlv(0x03, bits));
    }
}
