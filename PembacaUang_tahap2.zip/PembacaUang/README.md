# Pembaca Uang

Aplikasi Android untuk membacakan nominal uang kertas rupiah lewat kamera, dibuat dengan
mekanisme dan alur yang sama seperti aplikasi acuan "Pembaca Uang Novan".

## Alur kerja

1. Aplikasi dibuka: getar singkat (60 ms), layar tetap menyala, bip dimulai.
2. Izin kamera diminta. Bila ditolak, aplikasi mengucapkan cara mengaktifkannya.
3. Kamera belakang dibuka dengan Camera v1 (`android.hardware.Camera`) dan senter (torch) menyala otomatis.
4. Tiap frame dianalisis OCR ML Kit (model Latin ikut di dalam aplikasi, jalan offline).
5. Seluruh teks digabung lalu dicocokkan ke pecahan (`CurrencyParser`):
   tulisan nominal, nama pahlawan pada uang, lalu pola angka dengan syarat jumlah angka 0 yang pas.
6. `SpeechGate` mencegah nominal yang sama diucapkan berulang selama uang masih terbaca.
7. Nominal diucapkan lewat Text-to-Speech (atau pengumuman TalkBack bila aktif).
8. Bip tiap 10 detik sebagai tanda aplikasi aktif.
9. Tombol kembali: ucapkan "Terima kasih", getar, keluar.

## Struktur

| Berkas | Fungsi |
|---|---|
| `MainActivity.kt` | Izin, siklus hidup kamera, alur deteksi → suara |
| `CameraSource.kt` | Camera v1: ukuran 1152x648, 30 fps, fokus kontinu + area tengah, senter, 4 buffer NV21 |
| `MoneyRecognizer.kt` | Frame NV21 → bitmap abu-abu → OCR ML Kit → teks |
| `CurrencyParser.kt`, `Denomination.kt` | Teks → pecahan |
| `SpeechGate.kt` | Anti-ulang 1 detik |
| `Speaker.kt` | TTS / TalkBack |
| `Beeper.kt` | Bip tiap 10 detik |

## Build

Buka folder ini di Android Studio (Koala atau lebih baru) lalu Run, atau `./gradlew assembleDebug`.
Tes parser: `./gradlew testDebugUnitTest`.
Ukuran APK dijaga kecil: hanya model OCR Latin ML Kit (`text-recognition`, tanpa model Mandarin/Jepang/Korea/Devanagari),
hanya ABI `arm64-v8a` dan `armeabi-v7a` seperti aplikasi acuan, bahasa `id` dan `en`, serta R8 + shrinkResources pada build rilis.
Butuh JDK 17 dan Android SDK 34. Berjalan di Android 5.0 (API 21) sampai versi terbaru. Pecahan yang dikenali: 1.000, 2.000, 5.000, 10.000, 20.000, 50.000, 75.000, 100.000.

## File .so OCR (64-bit dan 32-bit)

`app/src/main/jniLibs/arm64-v8a/` dan `app/src/main/jniLibs/armeabi-v7a/` berisi `libmlkit_google_ocr_pipeline.so`
(11,0 MB dan 6,8 MB). Satu APK memuat keduanya; HP 64-bit memakai arm64-v8a, HP 32-bit memakai armeabi-v7a.
`useLegacyPackaging = true` membuat .so dikompres di dalam APK (kira-kira 17,8 MB menjadi 7,9 MB).
Tugas `cekSoOcr` memeriksa file dan arsitekturnya sebelum build; bila salah, build gagal dengan pesan jelas.
