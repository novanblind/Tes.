package id.ytplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class VideoAdapter(
    private val onOpen: (VideoItem, Boolean?) -> Unit,
    private val onRemove: ((VideoItem) -> Unit)? = null
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v)

    private val items = ArrayList<VideoItem>()

    private var removable = false

    /** Nomor sumber untuk antrean putar; berganti tiap isi daftar diganti. */
    var sourceId: Int = PlayQueue.newSourceId()
        private set

    fun snapshot(): List<VideoItem> = ArrayList(items)

    /** removable = true: tiap video punya aksi TalkBack "Hapus dari riwayat" (daftar Riwayat). */
    fun set(list: List<VideoItem>, removable: Boolean = false) {
        this.removable = removable
        sourceId = PlayQueue.newSourceId()
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun remove(item: VideoItem) {
        val i = items.indexOfFirst { it.url == item.url }
        if (i >= 0) {
            PlayQueue.remove(sourceId, item.url)
            items.removeAt(i)
            notifyItemRemoved(i)
        }
    }

    fun add(list: List<VideoItem>) {
        if (list.isEmpty()) return
        val start = items.size
        items.addAll(list)
        PlayQueue.append(sourceId, list)
        notifyItemRangeInserted(start, list.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) =
        VideoBinder.bind(
            holder.itemView, items[position],
            onRemove = if (removable) onRemove else null,
            onOpen = onOpen
        )

    override fun getItemCount() = items.size
}
