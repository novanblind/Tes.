package com.novan.githubbynovan;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CheckBox;
import org.json.JSONObject;
import java.util.List;

/**
 * Pengaturan bangun APK: tanda tangan dan keamanan aplikasi bawaan. Bila sudah diatur, dialog pilihannya
 * dilewati saat membangun APK (termasuk bangun otomatis setelah unggah) supaya tidak banyak klik.
 */
public class PengaturanBangunActivity extends Activity {
    private Ui ui;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Tanda tangan bisa ditambah/dihapus di layar lain.
        if (ui != null) render();
    }

    private String labelTt() {
        String m = Store.ttMode(this);
        if ("bawaan".equals(m)) return "Selalu bawaan GitHub";
        if ("pribadi".equals(m)) {
            String id = Store.ttSignId(this);
            for (JSONObject o : Store.signs(this)) {
                if (id.equals(o.optString("id"))) return "Selalu pribadi: " + o.optString("nama");
            }
            return "Selalu pribadi (pilih saat bangun bila ada lebih dari satu)";
        }
        return "Otomatis (disarankan)";
    }

    private void render() {
        ui = new Ui(this, "Pengaturan bangun APK");
        ui.label("Atur sekali di sini, lalu pembangunan APK berjalan dengan sedikit dialog.");

        ui.section("Tanda tangan");
        ui.button("Tanda tangan saat bangun: " + labelTt(), v -> pilihTt());
        ui.label("Otomatis: bila sudah ada tanda tangan pribadi, setiap pembangunan memakainya (bila ada beberapa, "
                + "Anda memilih dulu). Repo publik lewat GitHub Secrets. Bila belum ada tanda tangan pribadi, "
                + "langsung memakai tanda tangan bawaan GitHub tanpa bertanya.");
        ui.button("Kelola tanda tangan pribadi", v -> startActivity(new android.content.Intent(this, SignActivity.class)));

        ui.section("Keamanan aplikasi (tanda tangan pribadi)");
        CheckBox ct = ui.check("Tanya pengaturan keamanan setiap kali bangun", !Store.secSimpan(this));
        ct.setOnCheckedChangeListener((b, on) -> Store.setSecSimpan(this, !on));
        CheckBox cp = ui.check("Penjaga tanda tangan (disarankan)", Store.secPenjaga(this));
        cp.setOnCheckedChangeListener((b, on) -> Store.setSecPenjaga(this, on));
        CheckBox c8 = ui.check("Aktifkan R8 untuk APK rilis", Store.secR8(this));
        final CheckBox ck = ui.check("Obfuskasi lebih kuat (di atas R8)", Store.secR8(this) && Store.secKuat(this));
        ck.setVisibility(c8.isChecked() ? android.view.View.VISIBLE : android.view.View.GONE);
        ck.setOnCheckedChangeListener((b, on) -> Store.setSecKuat(this, on));
        c8.setOnCheckedChangeListener((b, on) -> {
            Store.setSecR8(this, on);
            ck.setVisibility(on ? android.view.View.VISIBLE : android.view.View.GONE);
            if (!on) { ck.setChecked(false); Store.setSecKuat(this, false); }
        });
        CheckBox ce = ui.check("Enkripsi string otomatis", Store.secEnk(this));
        ce.setOnCheckedChangeListener((b, on) -> Store.setSecEnk(this, on));
        ui.label("Empat pilihan terakhir tersimpan langsung dan dipakai tanpa dialog bila \"Tanya pengaturan keamanan\" "
                + "dimatikan. R8, obfuskasi, dan enkripsi string bisa membuat fitur gagal di APK rilis; uji semua fitur setelah dibangun.");

        ui.section("Setelah pembangunan berhasil");
        CheckBox cu = ui.check("Unduh APK otomatis, lalu tampilkan pilihan pasang", Store.autoUnduh(this));
        cu.setOnCheckedChangeListener((b, on) -> Store.setAutoUnduh(this, on));
        ui.label("Berlaku bila build dipantau dari aplikasi ini. Bila aplikasi tidak tampil, unduhan mulai saat dibuka.");

        ui.section("Penyimpanan");
        ui.button("Hapus semua artefak di semua repositori", Ui.DANGER,
                v -> ApkTools.hapusSemuaArtefak(this, Store.token(this), null));
        ui.button("Kembali", v -> finish());
    }

    private void pilihTt() {
        java.util.List<ApkTools.Btn> b = new java.util.ArrayList<>();
        b.add(ApkTools.b("otomatis (disarankan)", () -> { Store.setTtMode(this, "tanya"); render(); }));
        b.add(ApkTools.b("selalu tanda tangan bawaan GitHub", () -> { Store.setTtMode(this, "bawaan"); render(); }));
        b.add(ApkTools.b("selalu tanda tangan pribadi", () -> pilihPribadi()));
        ApkTools.dialog(this, "Tanda tangan saat bangun APK",
                "Otomatis: memakai tanda tangan pribadi bila sudah ada (bila ada beberapa, Anda memilih dulu), "
                        + "repo publik lewat GitHub Secrets. Bila belum ada, langsung memakai tanda tangan bawaan GitHub "
                        + "tanpa bertanya.",
                b, "batal", null);
    }

    private void pilihPribadi() {
        final List<JSONObject> signs = Store.signs(this);
        if (signs.isEmpty()) {
            ApkTools.dialog(this, "Belum ada tanda tangan pribadi",
                    "Buat atau impor tanda tangan dulu, lalu atur di sini.",
                    ApkTools.list(ApkTools.b("buat atau impor tanda tangan",
                            () -> startActivity(new android.content.Intent(this, SignActivity.class)))),
                    "kembali", null);
            return;
        }
        if (signs.size() == 1) {
            Store.setTtMode(this, "pribadi");
            Store.setTtSignId(this, signs.get(0).optString("id"));
            render();
            return;
        }
        java.util.List<ApkTools.Btn> b = new java.util.ArrayList<>();
        for (int i = 0; i < signs.size(); i++) {
            final JSONObject o = signs.get(i);
            b.add(ApkTools.b((i + 1) + ". " + Store.labelSign(o), () -> {
                Store.setTtMode(this, "pribadi");
                Store.setTtSignId(this, o.optString("id"));
                render();
            }));
        }
        if (signs.size() > 1) {
            b.add(ApkTools.b("pilih saat bangun", () -> {
                Store.setTtMode(this, "pribadi");
                Store.setTtSignId(this, "");
                render();
            }));
        }
        ApkTools.dialog(this, "Pilih tanda tangan pribadi bawaan", "Tanda tangan ini dipakai otomatis saat bangun APK.",
                b, "batal", null);
    }
}
