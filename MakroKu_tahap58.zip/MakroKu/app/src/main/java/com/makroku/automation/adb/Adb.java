package com.makroku.automation.adb;

import android.content.Context;
import android.os.Build;

import android.sun.security.x509.AlgorithmId;
import android.sun.security.x509.CertificateAlgorithmId;
import android.sun.security.x509.CertificateExtensions;
import android.sun.security.x509.CertificateIssuerName;
import android.sun.security.x509.CertificateSerialNumber;
import android.sun.security.x509.CertificateSubjectName;
import android.sun.security.x509.CertificateValidity;
import android.sun.security.x509.CertificateVersion;
import android.sun.security.x509.CertificateX509Key;
import android.sun.security.x509.KeyIdentifier;
import android.sun.security.x509.PrivateKeyUsageExtension;
import android.sun.security.x509.SubjectKeyIdentifierExtension;
import android.sun.security.x509.X500Name;
import android.sun.security.x509.X509CertImpl;
import android.sun.security.x509.X509CertInfo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;

/** Pengelola koneksi ADB (Wireless debugging): kunci dan sertifikat disimpan permanen. */
public class Adb extends AbsAdbConnectionManager {
    private static Adb INSTANCE;

    public static synchronized Adb get(Context c) throws Exception {
        if (INSTANCE == null) INSTANCE = new Adb(c.getApplicationContext());
        return INSTANCE;
    }

    private PrivateKey mPrivateKey;
    private Certificate mCertificate;

    private Adb(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File fp = new File(c.getFilesDir(), "adb_priv.der");
        File fc = new File(c.getFilesDir(), "adb_cert.der");
        if (fp.exists() && fc.exists()) {
            mPrivateKey = KeyFactory.getInstance("RSA")
                    .generatePrivate(new PKCS8EncodedKeySpec(readAll(fp)));
            mCertificate = CertificateFactory.getInstance("X.509")
                    .generateCertificate(new ByteArrayInputStream(readAll(fc)));
        } else {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
            KeyPair kp = kpg.generateKeyPair();
            PublicKey publicKey = kp.getPublic();
            mPrivateKey = kp.getPrivate();
            String algorithmName = "SHA512withRSA";
            Date notBefore = new Date();
            Date notAfter = new Date(System.currentTimeMillis() + 3650L * 86400000L);
            CertificateExtensions ext = new CertificateExtensions();
            ext.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(
                    new KeyIdentifier(publicKey).getIdentifier()));
            X500Name name = new X500Name("CN=MakroKu");
            ext.set("PrivateKeyUsage", new PrivateKeyUsageExtension(notBefore, notAfter));
            X509CertInfo info = new X509CertInfo();
            info.set("version", new CertificateVersion(2));
            info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
            info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(algorithmName)));
            info.set("subject", new CertificateSubjectName(name));
            info.set("key", new CertificateX509Key(publicKey));
            info.set("validity", new CertificateValidity(notBefore, notAfter));
            info.set("issuer", new CertificateIssuerName(name));
            info.set("extensions", ext);
            X509CertImpl cert = new X509CertImpl(info);
            cert.sign(mPrivateKey, algorithmName);
            mCertificate = cert;
            try (FileOutputStream o = new FileOutputStream(fp)) { o.write(mPrivateKey.getEncoded()); }
            try (FileOutputStream o = new FileOutputStream(fc)) { o.write(mCertificate.getEncoded()); }
        }
    }

    private static byte[] readAll(File f) throws Exception {
        byte[] b = new byte[(int) f.length()];
        try (FileInputStream i = new FileInputStream(f)) {
            int off = 0;
            while (off < b.length) {
                int n = i.read(b, off, b.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        return b;
    }

    @Override protected PrivateKey getPrivateKey() { return mPrivateKey; }
    @Override protected Certificate getCertificate() { return mCertificate; }
    @Override protected String getDeviceName() { return "MakroKu"; }

    /** Cari port Wireless debugging lewat mDNS (_adb-tls-connect._tcp) lalu sambung. */
    public boolean sambungTls(Context ctx, long timeoutMs) throws Exception {
        final NsdManager nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
        final AtomicInteger port = new AtomicInteger(-1);
        final String[] host = { "127.0.0.1" };
        final CountDownLatch latch = new CountDownLatch(1);
        NsdManager.DiscoveryListener dl = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) {}
            @Override public void onDiscoveryStopped(String t) {}
            @Override public void onStartDiscoveryFailed(String t, int e) { latch.countDown(); }
            @Override public void onStopDiscoveryFailed(String t, int e) {}
            @Override public void onServiceLost(NsdServiceInfo s) {}
            @Override public void onServiceFound(NsdServiceInfo si) {
                nsd.resolveService(si, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo s, int e) {}
                    @Override public void onServiceResolved(NsdServiceInfo r) {
                        if (r.getPort() > 0 && port.compareAndSet(-1, r.getPort())) {
                            try { if (r.getHost() != null) host[0] = r.getHost().getHostAddress(); } catch (Throwable ignored) {}
                            latch.countDown();
                        }
                    }
                });
            }
        };
        try {
            nsd.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, dl);
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } finally {
            try { nsd.stopServiceDiscovery(dl); } catch (Exception ignored) {}
        }
        if (port.get() <= 0) return false;
        try {
            return connect(host[0], port.get());
        } catch (Throwable first) {
            if ("127.0.0.1".equals(host[0])) throw first;
            return connect("127.0.0.1", port.get());
        }
    }
}
