package com.novan.filemanagerpro

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File

/** Daftar penanda. Ketuk untuk membuka, tekan lama untuk menu. */
class BookmarksActivity : AppCompatActivity() {

    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var paths: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.bookmarks)

        empty = findViewById(R.id.empty)
        empty.setText(R.string.bookmarks_empty)
        rowAdapter = RowAdapter(onClick = { openItem(it) }, onLong = { showActions(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        paths = Bookmarks.list(this).filter { File(it).exists() }
        val rows = paths.map { p ->
            val f = File(p)
            val name = f.name.ifEmpty { p }
            val detail = f.parent ?: p
            val kind = getString(if (f.isDirectory) R.string.folder else R.string.file)
            Row(
                if (f.isDirectory) R.drawable.ic_folder else R.drawable.ic_file,
                name, detail, "$kind $name, $detail", p
            )
        }
        rowAdapter.submit(rows)
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = getString(R.string.items_count, rows.size)
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun openItem(i: Int) {
        if (i !in paths.indices) return
        val f = File(paths[i])
        if (f.isDirectory) {
            startActivity(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, f.absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, f.name.ifEmpty { f.absolutePath })
            )
        } else if (!Util.openSmart(this, f, listOf(f))) {
            say(getString(R.string.cannot_open))
        }
    }

    private fun showActions(i: Int) {
        if (i !in paths.indices) return
        val p = paths[i]
        val name = File(p).name.ifEmpty { p }
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(arrayOf(getString(R.string.act_open), getString(R.string.menu_bookmark_remove))) { _, which ->
                if (which == 0) openItem(i) else {
                    Bookmarks.remove(this, p)
                    load()
                    say(getString(R.string.bookmark_removed, name))
                }
            }
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) { finish(); true } else super.onOptionsItemSelected(item)
}
