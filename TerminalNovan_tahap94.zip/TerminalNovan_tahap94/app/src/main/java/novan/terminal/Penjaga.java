package novan.terminal;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Penjaga tanda tangan untuk APK yang dibangun lewat bangun-apk (meniru fitur
 * "Penjaga dari tanda tangan ulang" pada aplikasi GitHub by novan). Hanya aktif
 * bila proyek dibangun dengan tanda tangan pribadi (bukan bawaan/debug): sidik
 * jari sertifikat ditanam ke kelas TTGuard yang disisipkan ke proyek, lalu
 * provider-nya didaftarkan ke AndroidManifest.xml sebelum kompilasi. Pengaturan
 * aktif/nonaktif disimpan di berkas, sama seperti cara Ks menyimpan tanda tangan aktif.
 */
class Penjaga {
    static File flag() { return new File(Env.prefix.getParentFile(), "tanda-tangan/penjaga.txt"); }

    /** Bawaan aktif (disarankan), seperti pilihan bawaan pada GitHub by novan. */
    static boolean aktif() {
        File f = flag();
        if (!f.exists()) return true;
        try { return !"nonaktif".equals(Ks.readAll(f).trim()); } catch (IOException e) { return true; }
    }

    static void set(boolean on) {
        try { Ks.write(flag(), on ? "aktif" : "nonaktif"); } catch (IOException e) { }
    }

    static String paket(String manifestXml) {
        Matcher m = Pattern.compile("package\\s*=\\s*\"([^\"]+)\"").matcher(manifestXml);
        return m.find() ? m.group(1) : null;
    }

    static boolean adaPenjaga(String manifestXml) {
        return manifestXml.contains(".TTGuard\"");
    }

    /** Sisipkan tag <provider> penjaga sebelum tag penutup </application>. */
    static String sisipkanManifest(String manifestXml, String paket) { return sisipkanManifest(manifestXml, paket, false); }

    static String sisipkanManifest(String manifestXml, String paket, boolean gradle) {
        if (adaPenjaga(manifestXml)) return manifestXml;
        // Proyek bangun-apk dikompilasi langsung lewat aapt2 (bukan Gradle), jadi authorities
        // ditulis dari nama paket asli, bukan placeholder ${applicationId} (hanya berlaku lewat Gradle).
        String provider = "        <provider android:name=\"" + paket + ".TTGuard\""
            + " android:authorities=\"" + (gradle ? "${applicationId}" : paket) + ".ttguard\" android:exported=\"false\""
            + " android:initOrder=\"2147483647\" />\n";
        int i = manifestXml.lastIndexOf("</application>");
        if (i < 0) return manifestXml;
        return manifestXml.substring(0, i) + provider + manifestXml.substring(i);
    }

    static String muatTemplate() throws IOException {
        java.io.InputStream in = MainActivity.ctx.getAssets().open("ttguard.txt");
        try {
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] t = new byte[4096]; int n;
            while ((n = in.read(t)) > 0) b.write(t, 0, n);
            return new String(b.toByteArray(), "UTF-8");
        } finally { in.close(); }
    }

    /** Tulis TTGuard.java berisi sidik jari (dipecah & di-XOR) ke folder src proyek. */
    static void pasang(File srcRoot, String paket, String sidikJariHex) throws Exception {
        byte[] fp = hexToBytes(sidikJariHex.replace(":", "").toLowerCase());
        SecureRandom r = new SecureRandom();
        byte[] y = new byte[fp.length];
        r.nextBytes(y);
        byte[] x = new byte[fp.length];
        for (int i = 0; i < fp.length; i++) x[i] = (byte) (fp[i] ^ y[i % y.length]);
        String kode = muatTemplate()
            .replace("@@PAKET@@", paket)
            .replace("__TT_A__", toHex(x))
            .replace("__TT_B__", toHex(y));
        File dir = new File(srcRoot, paket.replace('.', '/'));
        dir.mkdirs();
        Ks.write(new File(dir, "TTGuard.java"), kode);
    }

    static byte[] hexToBytes(String s) {
        int n = s.length() / 2;
        byte[] o = new byte[n];
        for (int i = 0; i < n; i++) o[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return o;
    }

    static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(java.util.Locale.US, "%02x", x & 0xFF));
        return sb.toString();
    }

    // ---------------------------------------------------------------- proyek Gradle

    /** Cari AndroidManifest.xml modul aplikasi (yang punya activity peluncur) di proyek Gradle. */
    static File cariManifest(File d, int dalam) {
        File[] fs = d.listFiles();
        if (fs == null) return null;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            if (f.isFile() && f.getName().equals("AndroidManifest.xml") && f.getPath().replace('\\', '/').contains("/src/main/")) {
                try { if (Ks.readAll(f).contains("android.intent.action.MAIN")) return f; } catch (IOException e) { }
            }
        }
        if (dalam <= 0) return null;
        for (File f : fs) {
            String n = f.getName();
            if (!f.isDirectory() || n.equals("build") || n.startsWith(".") || n.equals("node_modules")) continue;
            File r = cariManifest(f, dalam - 1);
            if (r != null) return r;
        }
        return null;
    }

    static String paketGradle(File manifest, String xml) {
        String pk = paket(xml);
        if (pk != null) return pk;
        File modul = manifest.getParentFile().getParentFile().getParentFile();
        for (String nm : new String[]{"build.gradle", "build.gradle.kts"}) {
            File g = new File(modul, nm);
            if (!g.exists()) continue;
            try {
                String s = Ks.readAll(g);
                Matcher m = Pattern.compile("namespace\\s*=?\\s*[\"']([^\"']+)[\"']").matcher(s);
                if (m.find()) return m.group(1);
                m = Pattern.compile("applicationId\\s*=?\\s*[\"']([^\"']+)[\"']").matcher(s);
                if (m.find()) return m.group(1);
            } catch (IOException e) { }
        }
        return null;
    }

    /** Pasang penjaga ke proyek Gradle (TTGuard.java dan provider di manifest). Mengembalikan keterangan untuk layar. */
    static String pasangGradle(File proj, String sidikJari) throws Exception {
        if (sidikJari == null || sidikJari.isEmpty()) return "Penjaga tanda tangan dilewati: sidik jari tanda tangan tidak ditemukan.";
        File man = cariManifest(proj, 4);
        if (man == null) return "Penjaga tanda tangan dilewati: modul aplikasi (AndroidManifest.xml dengan activity peluncur) tidak ditemukan.";
        String xml = Ks.readAll(man);
        String paket = paketGradle(man, xml);
        if (paket == null) return "Penjaga tanda tangan dilewati: nama paket tidak ditemukan di manifest atau build.gradle.";
        pasang(new File(man.getParentFile(), "java"), paket, sidikJari);
        if (!adaPenjaga(xml)) {
            String baru = sisipkanManifest(xml, paket, true);
            if (baru.equals(xml)) return "Penjaga tanda tangan dilewati: tag application tidak ditemukan di manifest.";
            Ks.write(man, baru);
        }
        return "Penjaga tanda tangan aktif: ditambahkan ke " + man.getParentFile().getParentFile().getParentFile().getName()
            + " (TTGuard.java dan provider di manifest). Proyek ini kini hanya berjalan bila ditandatangani kunci yang sama.";
    }

    /** Bila proyek pernah diberi penjaga oleh aplikasi ini, lepaskan lagi supaya build lain tidak menutup sendiri. */
    static void lepasGradle(File proj) {
        try {
            File man = cariManifest(proj, 4);
            if (man == null) return;
            String xml = Ks.readAll(man);
            Matcher m = Pattern.compile("android:name=\"([^\"]*)\\.TTGuard\"").matcher(xml);
            if (!m.find()) return;
            String paket = m.group(1);
            String baru = xml.replaceAll("[ \\t]*<provider android:name=\"[^\"]*\\.TTGuard\"[^>]*/>\\s*\\n?", "");
            Ks.write(man, baru);
            new File(new File(man.getParentFile(), "java"), paket.replace('.', '/') + "/TTGuard.java").delete();
            MainActivity.H.post(() -> MainActivity.add("Penjaga tanda tangan lama dilepas dari proyek."));
        } catch (Throwable e) { }
    }
}
