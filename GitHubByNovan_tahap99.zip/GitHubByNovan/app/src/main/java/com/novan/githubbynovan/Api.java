package com.novan.githubbynovan;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Api {
    public interface Callback { void done(boolean ok, String result); }

    public static final String BASE = "https://api.github.com";
    public static final ExecutorService POOL = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static class HttpError extends Exception {
        HttpError(String m) { super(m); }
    }

    /** Encode jalur berkas per segmen, mis. "folder a/b.txt" -> "folder%20a/b.txt". */
    public static String enc(String path) {
        StringBuilder sb = new StringBuilder();
        for (String seg : path.split("/")) {
            if (seg.isEmpty()) continue;
            if (sb.length() > 0) sb.append('/');
            try {
                sb.append(URLEncoder.encode(seg, "UTF-8").replace("+", "%20"));
            } catch (Exception e) {
                sb.append(seg);
            }
        }
        return sb.toString();
    }

    public static JSONObject o(Object... kv) {
        JSONObject j = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) j.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) { }
        return j;
    }

    /** Nilai string dari JSON; null JSON menjadi string kosong. */
    public static String str(JSONObject o, String k) {
        return o == null || o.isNull(k) ? "" : o.optString(k, "");
    }

    public static JSONObject parse(String s) {
        try { return new JSONObject(s); } catch (Exception e) { return new JSONObject(); }
    }

    public static JSONArray parseArr(String s) {
        try { return new JSONArray(s); } catch (Exception e) { return new JSONArray(); }
    }

    /** Permintaan ke GitHub API di thread latar; callback dijalankan di thread utama. */
    public static void request(final String method, final String url, final String token,
                               final String body, final Callback cb) {
        POOL.execute(() -> {
            boolean ok = false;
            String res = "";
            int attempts = 3; // seperti skrip: ulangi saat koneksi gagal, bukan saat server menolak
            for (int i = 1; i <= attempts; i++) {
                try {
                    res = call(method, url, token, body);
                    ok = true;
                    break;
                } catch (HttpError e) {
                    res = e.getMessage();
                    break;
                } catch (Exception e) {
                    res = "Koneksi gagal. Periksa internet Anda.";
                    try { Thread.sleep(1200L * i); } catch (Exception ignored) { }
                }
            }
            final boolean fo = ok;
            final String fr = res;
            MAIN.post(() -> cb.done(fo, fr));
        });
    }

    /** Hasil permintaan sinkron. */
    public static class Result {
        public final boolean ok;
        public final String text;
        Result(boolean ok, String text) { this.ok = ok; this.text = text; }
    }

    /**
     * Permintaan sinkron: HANYA boleh dipanggil dari thread latar (mis. Api.POOL),
     * tidak pernah dari thread utama. Aturan ulang sama seperti {@link #request}.
     */
    public static Result requestSync(String method, String url, String token, String body) {
        boolean ok = false;
        String res = "";
        for (int i = 1; i <= 3; i++) {
            try {
                res = call(method, url, token, body);
                ok = true;
                break;
            } catch (HttpError e) {
                res = e.getMessage();
                // Gangguan sementara di sisi GitHub (500/502/503/504): ulangi permintaan baca.
                boolean sementara = res.contains("Kode: 500") || res.contains("Kode: 502")
                        || res.contains("Kode: 503") || res.contains("Kode: 504");
                if (sementara && "GET".equals(method) && i < 3) {
                    try { Thread.sleep(1500L * i); } catch (Exception ignored) { }
                    continue;
                }
                break;
            } catch (Exception e) {
                res = "Koneksi gagal. Periksa internet Anda.";
                try { Thread.sleep(1200L * i); } catch (Exception ignored) { }
            }
        }
        return new Result(ok, res);
    }

    private static String call(String method, String url, String token, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        if ("PATCH".equals(method)) {
            // HttpURLConnection Android (berbasis OkHttp) umumnya mendukung PATCH langsung;
            // bila ditolak, pakai POST dengan penanda override.
            try {
                c.setRequestMethod("PATCH");
            } catch (java.net.ProtocolException e) {
                c.setRequestMethod("POST");
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            }
        } else {
            c.setRequestMethod(method);
        }
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("User-Agent", "GitHub-by-novan");
        c.setRequestProperty("Accept", "application/vnd.github+json");
        if (body != null) {
            byte[] b = body.getBytes("UTF-8");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(b.length);
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.flush();
            os.close();
        }
        int code = c.getResponseCode();
        InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
        String text = "";
        if (in != null) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
            in.close();
            text = new String(bos.toByteArray(), "UTF-8");
        }
        c.disconnect();
        if (code >= 200 && code < 300) return text;
        String msg = "";
        try { msg = new JSONObject(text).optString("message", ""); } catch (Exception ignored) { }
        throw new HttpError("Gagal. Kode: " + code + (msg.isEmpty() ? "" : " (" + msg + ")"));
    }
}
