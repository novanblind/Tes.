package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.CheckBox;
import android.widget.EditText;
import org.json.JSONObject;

public class CreateRepoActivity extends Activity {
    private Ui ui;
    private boolean busy;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        form();
    }

    private void form() {
        ui = new Ui(this, "Buat repositori baru");
        final EditText name = ui.edit("Nama repositori", "contoh: skrip-baru", false, "");
        final EditText desc = ui.edit("Deskripsi", "Keterangan singkat", false, "");
        final CheckBox priv = ui.check("Jadikan privat", false);
        final CheckBox readme = ui.check("Tambahkan README (GitHub Pages ikut diaktifkan)", false);
        ui.button("Buat repositori", v -> {
            if (busy) return;
            final String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                ui.say("Nama repo wajib diisi.");
                return;
            }
            final boolean withReadme = readme.isChecked();
            String body = Api.o("name", n, "description", desc.getText().toString().trim(),
                    "private", priv.isChecked(), "auto_init", withReadme).toString();
            busy = true;
            ui.say("Membuat repositori...");
            Api.request("POST", Api.BASE + "/user/repos", Store.token(this), body, (ok, res) -> {
                if (ok) ReposActivity.invalidate();
                if (!ok) {
                    busy = false;
                    ui.say("Gagal membuat repo. " + res);
                    return;
                }
                final JSONObject obj = Api.parse(res);
                final String full = Api.str(obj, "full_name");
                String br = Api.str(obj, "default_branch");
                final String branch = br.isEmpty() ? "main" : br;
                // Beri GitHub waktu menyiapkan repo sebelum mengaktifkan Pages.
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (!withReadme) {
                        busy = false;
                        result(obj, false, "");
                        return;
                    }
                    String pages = Api.o("source", Api.o("branch", branch, "path", "/")).toString();
                    Api.request("POST", Api.BASE + "/repos/" + full + "/pages", Store.token(this), pages,
                            (okP, resP) -> {
                                busy = false;
                                result(obj, okP, okP ? Api.str(Api.parse(resP), "html_url") : "");
                            });
                }, 1500);
            });
        });
        ui.button("Kembali", v -> finish());
    }

    private void result(final JSONObject obj, boolean pagesOk, String pagesUrl) {
        final String repoName = Api.str(obj, "name");
        final String html = Api.str(obj, "html_url");
        ui = new Ui(this, "Repositori dibuat");
        String msg = "Nama: " + repoName + "\nTautan: " + html;
        if (pagesOk) msg += "\n\nGitHub Pages aktif:\n" + pagesUrl;
        ui.label(msg);
        ui.say(pagesOk ? "Repositori dan Pages berhasil diaktifkan." : "Repositori berhasil dibuat.");
        ui.button("Salin tautan", v -> Ui.copy(this, "Tautan repo", html));
        ui.button("Bagikan", v -> Ui.share(this, "Repo: " + repoName, html));
        ui.button("Buka repositori", v -> {
            startActivity(RepoActivity.of(this, obj));
            finish();
        });
        ui.button("Kembali", v -> finish());
    }
}
