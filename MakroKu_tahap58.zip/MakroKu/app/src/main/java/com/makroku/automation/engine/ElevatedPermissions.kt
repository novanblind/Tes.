package com.makroku.automation.engine

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import com.makroku.automation.adb.AdbBackend
import com.makroku.automation.service.MacroAccessibilityService
import com.makroku.automation.service.MacroNotificationListener

/**
 * Izin tingkat tinggi yang hanya bisa diberikan lewat ADB (sekali saja dari PC),
 * dan pembantu untuk memakainya setelah diberikan.
 */
object ElevatedPermissions {
    const val SECURE = "android.permission.WRITE_SECURE_SETTINGS"

    data class Step(
        val title: String,
        val desc: String,
        val commands: List<String>,
        val granted: (Context) -> Boolean,
    )

    fun hasSecureSettings(ctx: Context) = ctx.checkSelfPermission(SECURE) == PackageManager.PERMISSION_GRANTED

    private fun a11y(ctx: Context) = ComponentName(ctx, MacroAccessibilityService::class.java).flattenToString()
    private fun listener(ctx: Context) = ComponentName(ctx, MacroNotificationListener::class.java).flattenToString()

    private fun secureList(ctx: Context, key: String): List<String> =
        Settings.Secure.getString(ctx.contentResolver, key).orEmpty().split(":").filter { it.isNotBlank() }

    fun isAccessibilityEnabled(ctx: Context) = a11y(ctx) in secureList(ctx, "enabled_accessibility_services")
    fun isListenerEnabled(ctx: Context) = listener(ctx) in secureList(ctx, "enabled_notification_listeners")

    /** Menyalakan layanan Aksesibilitas MakroKu tanpa membuka Pengaturan (butuh WRITE_SECURE_SETTINGS). */
    fun enableAccessibility(ctx: Context): Boolean {
        if (!hasSecureSettings(ctx)) return false
        val comp = a11y(ctx)
        val list = secureList(ctx, "enabled_accessibility_services")
        if (comp !in list) Settings.Secure.putString(ctx.contentResolver, "enabled_accessibility_services", (list + comp).joinToString(":"))
        return Settings.Secure.putString(ctx.contentResolver, "accessibility_enabled", "1")
    }

    /** Menyalakan Akses Notifikasi MakroKu tanpa membuka Pengaturan (butuh WRITE_SECURE_SETTINGS). */
    fun enableNotificationListener(ctx: Context): Boolean {
        if (!hasSecureSettings(ctx)) return false
        val comp = listener(ctx)
        val list = secureList(ctx, "enabled_notification_listeners")
        if (comp in list) return true
        return Settings.Secure.putString(ctx.contentResolver, "enabled_notification_listeners", (list + comp).joinToString(":"))
    }

    private fun runtimePerms(): List<String> = buildList {
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.READ_CALENDAR)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.ANSWER_PHONE_CALLS)
        add(Manifest.permission.WRITE_CALL_LOG)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_IMAGES) else add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
    }

    fun steps(ctx: Context): List<Step> {
        val pkg = ctx.packageName
        return buildList {
            add(Step(
                "WRITE_SECURE_SETTINGS (kunci utama)",
                "Memungkinkan aplikasi mengubah settings secure/global, dan menyalakan Aksesibilitas & Akses Notifikasi sendiri.",
                listOf("adb shell pm grant $pkg $SECURE"),
            ) { hasSecureSettings(it) })
            add(Step(
                "Izin runtime (SMS, telepon, notifikasi, Bluetooth, lokasi)",
                "Memberi semua izin runtime sekaligus tanpa dialog.",
                runtimePerms().map { "adb shell pm grant $pkg $it" },
            ) { c -> runtimePerms().all { c.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } })
            add(Step(
                "Ubah pengaturan sistem (WRITE_SETTINGS)",
                "Untuk aksi kecerahan dan settings put namespace system.",
                listOf("adb shell appops set $pkg WRITE_SETTINGS allow"),
            ) { Settings.System.canWrite(it) })
            add(Step(
                "Tampil di atas aplikasi lain",
                "Agar aplikasi bisa dibuka dari latar belakang.",
                listOf("adb shell appops set $pkg SYSTEM_ALERT_WINDOW allow"),
            ) { Settings.canDrawOverlays(it) })
            if (Build.VERSION.SDK_INT >= 31) add(Step(
                "Alarm tepat waktu",
                "Agar pemicu jadwal tepat menit.",
                listOf("adb shell appops set $pkg SCHEDULE_EXACT_ALARM allow"),
            ) { it.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() })
            add(Step(
                "Akses Jangan Ganggu (DND)",
                "Untuk aksi DND dan mode dering senyap.",
                listOf("adb shell cmd notification allow_dnd $pkg"),
            ) { it.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted })
            add(Step(
                "Akses Notifikasi",
                "Sumber pemicu Notifikasi diterima. (Atau jalankan langkah 1 lalu tombol 'Aktifkan otomatis'.)",
                listOf("adb shell cmd notification allow_listener ${listener(ctx)}"),
            ) { isListenerEnabled(it) })
            add(Step(
                "Layanan Aksesibilitas",
                "Sumber pemicu Aplikasi dibuka. Perintah ini menimpa daftar layanan lain; lebih aman pakai tombol 'Aktifkan otomatis'.",
                listOf(
                    "adb shell settings put secure enabled_accessibility_services ${a11y(ctx)}",
                    "adb shell settings put secure accessibility_enabled 1",
                ),
            ) { isAccessibilityEnabled(it) })
            add(Step(
                "Abaikan optimasi baterai",
                "Agar layanan tidak dimatikan sistem.",
                listOf("adb shell dumpsys deviceidle whitelist +$pkg"),
            ) { it.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg) })
        }
    }

    fun script(ctx: Context): String =
        "# Jalankan di PC (USB debugging aktif, perangkat terhubung)\n" +
            steps(ctx).joinToString("\n") { it.commands.joinToString("\n") }

    /**
     * Beri semua izin lewat sambungan ADB bawaan (tanpa PC, tanpa Shizuku). Panggil dari thread latar.
     * Aksesibilitas & Akses Notifikasi dinyalakan lewat WRITE_SECURE_SETTINGS agar daftar layanan lain tidak tertimpa.
     */
    fun grantAllViaAdb(ctx: Context): String {
        val pkg = ctx.packageName
        val laporan = StringBuilder()
        fun jalan(cmd: String) {
            val hasil = try { AdbBackend.shell(ctx, cmd).ifBlank { "ok" } } catch (e: Throwable) { "GAGAL: ${e.message}" }
            laporan.appendLine("$cmd → ${hasil.take(100)}")
        }
        if (!hasSecureSettings(ctx)) jalan("pm grant $pkg $SECURE")
        val lewati = setOf("Layanan Aksesibilitas", "Akses Notifikasi")
        steps(ctx).filter { it.title !in lewati && !it.title.startsWith("WRITE_SECURE") }
            .forEach { st -> st.commands.forEach { jalan(it.removePrefix("adb shell ")) } }
        if (hasSecureSettings(ctx)) {
            laporan.appendLine("Aksesibilitas → " + if (runCatching { enableAccessibility(ctx) }.getOrDefault(false)) "aktif" else "gagal")
            laporan.appendLine("Akses notifikasi → " + if (runCatching { enableNotificationListener(ctx) }.getOrDefault(false)) "aktif" else "gagal")
        } else {
            laporan.appendLine("WRITE_SECURE_SETTINGS belum diberikan; Aksesibilitas/Akses Notifikasi dilewati.")
        }
        return laporan.toString().trim()
    }
}
