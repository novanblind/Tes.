package com.novan.githubbynovan;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Kelola GitHub Actions Secrets dan Variables milik repositori: lihat daftar, tambah, ganti nilai, dan hapus.
 * Secret dienkripsi di HP sebelum dikirim dan nilainya tidak bisa dibaca lagi; Variable berupa nilai biasa.
 */
public class RahasiaActivity extends Activity {
    private static final Pattern NAMA_OK = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");
    private static final String[] UMUM = {"(tidak dipilih)", "FD_KEY", "TSDB_KEY", "GROQ_API_KEY",
            "GEMINI_API_KEY", "API_KEY", "KS_B64", "KS_PASS", "KS_ALIAS"};

    private Ui ui;
    private String full, token;
    private boolean busy, formTerbuka;
    private String pesanSetelah;
    /** Secret: {nama, tanggal ubah}. Variable: {nama, nilai, tanggal ubah}. */
    private final List<String[]> secrets = new ArrayList<>();
    private final List<String[]> vars = new ArrayList<>();

    private interface Hasil { void selesai(boolean ok, String galat); }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        full = getIntent().getStringExtra("repo");
        muat();
    }

    private String namaRepo() {
        return full.substring(full.indexOf('/') + 1);
    }

    private static String tgl(String s) {
        return s != null && s.length() >= 10 ? s.substring(0, 10) : (s == null ? "" : s);
    }

    private static String singkat(String v) {
        String t = v == null ? "" : v.replace('\n', ' ').replace('\r', ' ');
        return t.length() > 40 ? t.substring(0, 40) + "..." : t;
    }

    private static boolean ada(List<String[]> daftar, String nama) {
        for (String[] r : daftar) if (r[0].equalsIgnoreCase(nama)) return true;
        return false;
    }

    // ---------- memuat daftar ----------

    private void ambil(final boolean secret, final int hal, final List<String[]> acc, final Hasil h) {
        final int per = secret ? 100 : 30;
        String url = Api.BASE + "/repos/" + full + "/actions/" + (secret ? "secrets" : "variables")
                + "?per_page=" + per + "&page=" + hal;
        Api.request("GET", url, token, null, (ok, res) -> {
            if (isFinishing()) return;
            if (!ok) {
                h.selesai(false, res);
                return;
            }
            JSONArray arr = Api.parse(res).optJSONArray(secret ? "secrets" : "variables");
            int n = arr == null ? 0 : arr.length();
            for (int i = 0; i < n; i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String nama = Api.str(o, "name");
                String ubah = Api.str(o, "updated_at");
                acc.add(secret ? new String[]{nama, ubah} : new String[]{nama, Api.str(o, "value"), ubah});
            }
            if (n >= per && hal < 10) ambil(secret, hal + 1, acc, h);
            else h.selesai(true, "");
        });
    }

    private void muat() {
        formTerbuka = false;
        ui = new Ui(this, "Secrets dan Variables: " + namaRepo());
        ui.progress("Memuat daftar secret dan variable...");
        secrets.clear();
        vars.clear();
        ambil(true, 1, secrets, (ok, g) -> {
            if (!ok) {
                gagalMuat(g);
                return;
            }
            ambil(false, 1, vars, (ok2, g2) -> {
                if (!ok2) {
                    gagalMuat(g2);
                    return;
                }
                tampil();
            });
        });
    }

    private void gagalMuat(String res) {
        formTerbuka = false;
        ui = new Ui(this, "Secrets dan Variables: " + namaRepo());
        ui.label("Gagal memuat daftar.\n\n" + RahasiaRepo.petunjukIzin(res, "melihat Secrets dan Variables"));
        ui.button("Coba lagi", v -> muat());
        ui.button("Kembali", v -> finish());
    }

    private void tampil() {
        formTerbuka = false;
        busy = false;
        ui = new Ui(this, "Secrets dan Variables: " + namaRepo());
        ui.label("Repo: " + full + "\nJumlah secret: " + secrets.size() + ". Jumlah variable: " + vars.size()
                + ".\n\nSecret adalah nilai rahasia seperti kunci API atau sandi. Nilainya dienkripsi dan setelah "
                + "disimpan tidak bisa dibaca lagi, hanya bisa diganti atau dihapus. Variable adalah nilai biasa "
                + "yang masih bisa dibaca dan diubah.\n\nAlur kerja (build) membacanya dengan ${{ secrets.NAMA }} "
                + "dan ${{ vars.NAMA }}. Catatan: kunci yang kemudian dimasukkan ke dalam APK saat build tetap bisa "
                + "dibongkar dari APK; Secrets hanya menyembunyikannya dari kode repo dan log build.");
        if (pesanSetelah != null) {
            ui.say(pesanSetelah);
            pesanSetelah = null;
        }
        ui.button("Tambah secret (rahasia, terenkripsi)", v -> formSecret(null));
        ui.button("Tambah variable (nilai biasa)", v -> formVariable(null, ""));
        ui.section("Secrets (" + secrets.size() + ")");
        if (secrets.isEmpty()) ui.label("Belum ada secret.");
        for (final String[] r : secrets) {
            final String nama = r[0];
            ui.button("Secret: " + nama + (r[1].isEmpty() ? "" : ", diubah " + tgl(r[1])), v -> menuSecret(nama));
        }
        ui.section("Variables (" + vars.size() + ")");
        if (vars.isEmpty()) ui.label("Belum ada variable.");
        for (final String[] r : vars) {
            final String nama = r[0], nilai = r[1];
            ui.button("Variable: " + nama + " = " + singkat(nilai), v -> menuVar(nama, nilai));
        }
        ui.button("Segarkan daftar", v -> muat());
        ui.button("Kembali", v -> finish());
    }

    // ---------- menu per item ----------

    private void menuSecret(final String nama) {
        ApkTools.dialog(this, "Secret " + nama,
                "Nilai secret tidak bisa dilihat lagi. Anda bisa menimpa dengan nilai baru atau menghapusnya."
                        + "\n\nContoh pemakaian di alur kerja:\n${{ secrets." + nama + " }}",
                ApkTools.list(
                        ApkTools.b("ganti nilai", () -> formSecret(nama)),
                        ApkTools.b("salin contoh pemakaian di alur kerja",
                                () -> Ui.copy(this, "Pemakaian secret", "${{ secrets." + nama + " }}")),
                        ApkTools.b("hapus secret", () -> hapus(true, nama))),
                "batal", null);
    }

    private void menuVar(final String nama, final String nilai) {
        ApkTools.dialog(this, "Variable " + nama,
                "Nilai sekarang:\n" + nilai + "\n\nContoh pemakaian di alur kerja:\n${{ vars." + nama + " }}",
                ApkTools.list(
                        ApkTools.b("ubah nilai", () -> formVariable(nama, nilai)),
                        ApkTools.b("salin nilai", () -> Ui.copy(this, "Nilai variable " + nama, nilai)),
                        ApkTools.b("salin contoh pemakaian di alur kerja",
                                () -> Ui.copy(this, "Pemakaian variable", "${{ vars." + nama + " }}")),
                        ApkTools.b("hapus variable", () -> hapus(false, nama))),
                "batal", null);
    }

    // ---------- tambah / ubah ----------

    /** Memeriksa nama; mengembalikan nama siap pakai (huruf besar) atau null bila tidak sah (pesan sudah tampil). */
    private String periksaNama(String mentah) {
        String n = mentah == null ? "" : mentah.trim();
        if (n.isEmpty()) {
            ui.say("Nama wajib diisi.");
            return null;
        }
        if (!NAMA_OK.matcher(n).matches()) {
            ui.say("Nama hanya boleh huruf, angka, dan garis bawah (_), dan tidak boleh diawali angka. Tanpa spasi.");
            return null;
        }
        if (n.toUpperCase().startsWith("GITHUB_")) {
            ui.say("Nama tidak boleh diawali GITHUB_ (dipakai GitHub sendiri).");
            return null;
        }
        return n.toUpperCase();
    }

    private void formSecret(final String nama) {
        formTerbuka = true;
        ui = new Ui(this, nama == null ? "Tambah secret" : "Ganti nilai secret");
        final Ui.Choice umum;
        final EditText en;
        if (nama == null) {
            ui.label("Secret disimpan terenkripsi di GitHub dan tidak bisa dibaca lagi setelahnya. "
                    + "Nama yang sudah ada akan ditimpa.");
            umum = ui.choice("Nama umum", UMUM, 0);
            en = ui.edit("Atau ketik nama sendiri (diutamakan bila diisi)",
                    "contoh: FD_KEY (huruf, angka, garis bawah)", false, "");
        } else {
            umum = null;
            en = null;
            ui.label("Nama: " + nama + "\nNilai lama tidak bisa ditampilkan. Nilai baru menimpa yang lama.");
        }
        final EditText ev = ui.edit("Nilai rahasia", "tempel nilainya di sini", false, "");
        ui.label("Spasi dan baris kosong di awal dan akhir dibuang otomatis. Maksimal 48 KB.");
        ui.button("Simpan secret", v -> {
            if (busy) return;
            final String nm = nama != null ? nama : periksaNama(en.getText().toString().trim().isEmpty()
                    ? (umum.index > 0 ? umum.value() : "") : en.getText().toString());
            if (nm == null) return;
            final String nilai = ev.getText().toString().trim();
            if (nilai.isEmpty()) {
                ui.say("Nilai wajib diisi.");
                return;
            }
            if (nilai.getBytes(StandardCharsets.UTF_8).length > 48 * 1024) {
                ui.say("Nilai terlalu besar. Batas GitHub 48 KB.");
                return;
            }
            if (nama == null && ada(secrets, nm)) {
                ui.confirm("Timpa secret?", "Secret " + nm + " sudah ada. Nilai lamanya akan diganti.", "timpa",
                        () -> simpanSecret(nm, nilai));
            } else {
                simpanSecret(nm, nilai);
            }
        });
        ui.button("Batal", v -> tampil());
    }

    private void simpanSecret(final String nm, String nilai) {
        if (busy) return;
        busy = true;
        ui.progress("Mengenkripsi dan menyimpan secret " + nm + "...");
        RahasiaRepo.simpanSatu(this, full, token, nm, nilai, (ok, res) -> {
            busy = false;
            if (isFinishing()) return;
            if (!ok) {
                ui.say("Gagal menyimpan secret: " + RahasiaRepo.petunjukIzin(res, "mengelola Secrets"));
                return;
            }
            pesanSetelah = "Secret " + nm + " tersimpan.";
            muat();
        });
    }

    private void formVariable(final String nama, String nilaiLama) {
        formTerbuka = true;
        ui = new Ui(this, nama == null ? "Tambah variable" : "Ubah variable");
        final EditText en;
        if (nama == null) {
            ui.label("Variable adalah nilai biasa (bukan rahasia). Nama yang sudah ada akan diubah nilainya.");
            en = ui.edit("Nama variable", "contoh: NAMA_APLIKASI (huruf, angka, garis bawah)", false, "");
        } else {
            en = null;
            ui.label("Nama: " + nama);
        }
        final EditText ev = ui.edit("Nilai", "isi nilainya", false, nilaiLama);
        ui.button("Simpan variable", v -> {
            if (busy) return;
            final String nm = nama != null ? nama : periksaNama(en.getText().toString());
            if (nm == null) return;
            final String nilai = ev.getText().toString().trim();
            if (nilai.isEmpty()) {
                ui.say("Nilai wajib diisi.");
                return;
            }
            if (nilai.getBytes(StandardCharsets.UTF_8).length > 48 * 1024) {
                ui.say("Nilai terlalu besar. Batas GitHub 48 KB.");
                return;
            }
            final boolean sudah = nama != null || ada(vars, nm);
            if (nama == null && sudah) {
                ui.confirm("Ubah variable?", "Variable " + nm + " sudah ada. Nilainya akan diganti.", "ubah",
                        () -> simpanVar(nm, nilai, true));
            } else {
                simpanVar(nm, nilai, sudah);
            }
        });
        ui.button("Batal", v -> tampil());
    }

    private void simpanVar(final String nm, String nilai, boolean sudah) {
        if (busy) return;
        busy = true;
        ui.progress("Menyimpan variable " + nm + "...");
        String body = Api.o("name", nm, "value", nilai).toString();
        String url = Api.BASE + "/repos/" + full + "/actions/variables" + (sudah ? "/" + nm : "");
        Api.request(sudah ? "PATCH" : "POST", url, token, body, (ok, res) -> {
            busy = false;
            if (isFinishing()) return;
            if (!ok) {
                ui.say("Gagal menyimpan variable: " + RahasiaRepo.petunjukIzin(res, "mengelola Variables"));
                return;
            }
            pesanSetelah = "Variable " + nm + " tersimpan.";
            muat();
        });
    }

    // ---------- hapus ----------

    private void hapus(final boolean secret, final String nama) {
        ui.confirm((secret ? "Hapus secret?" : "Hapus variable?"),
                (secret ? "Secret " : "Variable ") + nama + " dihapus dari repo ini. "
                        + "Alur kerja yang memakainya bisa gagal atau mendapat nilai kosong.",
                "hapus", () -> {
                    if (busy) return;
                    busy = true;
                    ui.progress("Menghapus " + nama + "...");
                    String url = Api.BASE + "/repos/" + full + "/actions/" + (secret ? "secrets/" : "variables/") + nama;
                    Api.request("DELETE", url, token, null, (ok, res) -> {
                        busy = false;
                        if (isFinishing()) return;
                        if (!ok) {
                            ui.say("Gagal menghapus: " + RahasiaRepo.petunjukIzin(res, "mengelola Secrets dan Variables"));
                            return;
                        }
                        pesanSetelah = (secret ? "Secret " : "Variable ") + nama + " dihapus.";
                        muat();
                    });
                });
    }

    @Override
    public void onBackPressed() {
        if (formTerbuka && !busy) {
            tampil();
            return;
        }
        super.onBackPressed();
    }
}
