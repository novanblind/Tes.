package com.novan.penghilangvokal;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends Activity {

    private static final int REQ_PICK = 1;
    private static final int REQ_PERM = 2;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Button btnPilih, btnMulai, btnBatal;
    private TextView txtFile, txtStatus;
    private ProgressBar progress;
    private CheckBox chkVokal, chkBersih;
    private Spinner spnKualitas, spnKecepatan, spnTema;
    private Button btnHasil;
    private DialogHasil dialogHasil;

    private Uri sourceUri;
    private String sourceName;
    private String terakhirDiumumkan = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Tema: 0 = ikuti sistem (terang/gelap otomatis), 1 = terang, 2 = gelap. Harus dipasang sebelum tampilan dibuat.
        final int temaPilihan = Math.max(0, Math.min(2,
                getSharedPreferences("pengaturan", MODE_PRIVATE).getInt("tema", 0)));
        if (temaPilihan == 1) setTheme(R.style.AppThemeTerang);
        else if (temaPilihan == 2) setTheme(R.style.AppThemeGelap);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPilih = findViewById(R.id.btnPilih);
        btnMulai = findViewById(R.id.btnMulai);
        btnBatal = findViewById(R.id.btnBatal);
        txtFile = findViewById(R.id.txtFile);
        txtStatus = findViewById(R.id.txtStatus);
        progress = findViewById(R.id.progress);
        chkVokal = findViewById(R.id.chkVokal);
        chkBersih = findViewById(R.id.chkBersih);
        spnKualitas = findViewById(R.id.spnKualitas);
        spnKecepatan = findViewById(R.id.spnKecepatan);
        btnHasil = findViewById(R.id.btnHasil);
        spnTema = findViewById(R.id.spnTema);
        ArrayAdapter<CharSequence> adT = ArrayAdapter.createFromResource(this,
                R.array.tema_nama, android.R.layout.simple_spinner_item);
        adT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnTema.setAdapter(adT);
        spnTema.setSelection(temaPilihan, false);
        spnTema.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SharedPreferences p = getSharedPreferences("pengaturan", MODE_PRIVATE);
                if (position != p.getInt("tema", 0)) {
                    p.edit().putInt("tema", position).apply();
                    recreate();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        if (savedInstanceState != null) {
            String u = savedInstanceState.getString("lagu_uri");
            if (u != null) {
                sourceUri = Uri.parse(u);
                sourceName = savedInstanceState.getString("lagu_nama", "lagu");
                txtFile.setText(getString(R.string.lagu_terpilih, sourceName));
            }
        }
        dialogHasil = new DialogHasil(this, this::segarkan);
        btnHasil.setOnClickListener(v -> dialogHasil.tampil());

        ArrayAdapter<CharSequence> adK = ArrayAdapter.createFromResource(this,
                R.array.kualitas_nama, android.R.layout.simple_spinner_item);
        adK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnKualitas.setAdapter(adK);
        ArrayAdapter<CharSequence> adC = ArrayAdapter.createFromResource(this,
                R.array.kecepatan_nama, android.R.layout.simple_spinner_item);
        adC.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnKecepatan.setAdapter(adC);
        SharedPreferences pref = getSharedPreferences("pengaturan", MODE_PRIVATE);
        // Disimpan sebagai nomor pilihan; bawaan pilihan kedua (V2, tinggi, sekitar 190 kbps).
        spnKualitas.setSelection(Math.max(0, Math.min(VocalRemover.VBR_PILIHAN.length - 1,
                pref.getInt("kualitas_v3", 1))));
        spnKecepatan.setSelection(Math.max(0, Math.min(3, pref.getInt("kecepatan", 1))));
        chkBersih.setChecked(pref.getBoolean("bersih", false));

        btnPilih.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/*");
            startActivityForResult(i, REQ_PICK);
        });
        btnMulai.setOnClickListener(v -> mulai());
        btnBatal.setOnClickListener(v -> ProsesService.batal(this));

        terakhirDiumumkan = ProsesStatus.berjalan ? "" : ProsesStatus.pesan;

        // Dibuka lewat menu Bagikan: langsung pakai lagu yang dibagikan (sekali saja, bukan saat dibuat ulang).
        if (savedInstanceState == null) terimaBagikan(getIntent());

        ArrayList<String> perlu = new ArrayList<>();
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            perlu.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perlu.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!perlu.isEmpty()) {
            requestPermissions(perlu.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        terimaBagikan(intent);
    }

    /** Mengambil lagu dari intent Bagikan (ACTION_SEND) lalu menjadikannya lagu terpilih. */
    @SuppressWarnings("deprecation")
    private void terimaBagikan(Intent in) {
        if (in == null || !Intent.ACTION_SEND.equals(in.getAction())) return;
        Uri u = null;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                u = in.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            } else {
                Object o = in.getParcelableExtra(Intent.EXTRA_STREAM);
                if (o instanceof Uri) u = (Uri) o;
            }
        } catch (Exception ignored) { }
        if (u == null && in.getClipData() != null && in.getClipData().getItemCount() > 0) {
            u = in.getClipData().getItemAt(0).getUri();
        }
        if (u == null) {
            setStatus(getString(R.string.bagikan_gagal));
            return;
        }
        // Pastikan berkasnya benar-benar bisa dibuka sebelum dipilih.
        try (java.io.InputStream is = getContentResolver().openInputStream(u)) {
            if (is == null) throw new java.io.IOException();
        } catch (Exception e) {
            setStatus(getString(R.string.bagikan_gagal));
            txtStatus.announceForAccessibility(getString(R.string.bagikan_gagal));
            return;
        }
        pilihLagu(u, true);
    }

    /** Menjadikan {@code uri} lagu terpilih (dari pemilih berkas atau dari menu Bagikan). */
    private void pilihLagu(Uri uri, boolean dibagikan) {
        sourceUri = uri;
        sourceName = queryName(uri);
        txtFile.setText(getString(R.string.lagu_terpilih, sourceName));
        if (!ProsesStatus.berjalan) {
            ProsesStatus.pesan = "";
            ProsesStatus.persen = 0;
            terakhirDiumumkan = "";
        }
        btnMulai.setEnabled(!ProsesStatus.berjalan);
        progress.setProgress(ProsesStatus.berjalan ? ProsesStatus.persen : 0);
        String pesan;
        if (ProsesStatus.berjalan) pesan = getString(R.string.lagu_dibagikan_sibuk, sourceName);
        else if (dibagikan) pesan = getString(R.string.lagu_dibagikan, sourceName);
        else pesan = getString(R.string.siap);
        setStatus(pesan);
        if (dibagikan) txtStatus.announceForAccessibility(pesan);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (sourceUri != null) {
            out.putString("lagu_uri", sourceUri.toString());
            out.putString("lagu_nama", sourceName);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ProsesStatus.setListener(this::segarkan);
        segarkan();
    }

    @Override
    protected void onDestroy() {
        dialogHasil.tutup();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        ProsesStatus.setListener(null);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            pilihLagu(data.getData(), false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERM) return;
        for (int i = 0; i < permissions.length && i < grantResults.length; i++) {
            if (Manifest.permission.WRITE_EXTERNAL_STORAGE.equals(permissions[i])
                    && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                setStatus(getString(R.string.izin_ditolak));
            }
        }
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) { }
        if (name == null && "file".equals(uri.getScheme()) && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        return name != null ? name : "lagu";
    }

    private void setStatus(String s) {
        txtStatus.setText(s);
    }

    private void setBusy(boolean busy) {
        btnPilih.setEnabled(!busy);
        btnMulai.setEnabled(!busy && sourceUri != null);
        btnBatal.setEnabled(busy);
        chkVokal.setEnabled(!busy);
        chkBersih.setEnabled(!busy);
        spnKualitas.setEnabled(!busy);
        spnKecepatan.setEnabled(!busy);
    }

    private void mulai() {
        final Uri uri = sourceUri;
        if (uri == null || ProsesStatus.berjalan) return;
        ProsesStatus.berjalan = true;
        ProsesStatus.persen = 0;
        ProsesStatus.namaLagu = sourceName;
        ProsesStatus.pesan = getString(R.string.memproses);
        segarkan();
        final int idxK = spnKualitas.getSelectedItemPosition();
        final int idxC = spnKecepatan.getSelectedItemPosition();
        getSharedPreferences("pengaturan", MODE_PRIVATE).edit()
                .putInt("kualitas_v3", idxK).putInt("kecepatan", idxC)
                .putBoolean("bersih", chkBersih.isChecked()).apply();
        try {
            ProsesService.mulai(this, uri, sourceName, chkVokal.isChecked(),
                    VocalRemover.VBR_PILIHAN[Math.max(0, idxK)], Math.max(0, idxC),
                    chkBersih.isChecked());
        } catch (Throwable e) {
            ProsesStatus.berjalan = false;
            ProsesStatus.pesan = getString(R.string.gagal, String.valueOf(e.getMessage()));
            segarkan();
        }
    }

    /** Menyelaraskan tampilan dengan keadaan proses (yang berjalan di layanan latar belakang). */
    private void segarkan() {
        final boolean b = ProsesStatus.berjalan;
        setBusy(b);
        btnHasil.setEnabled(!b && !ProsesStatus.hasil.isEmpty());
        progress.setProgress(ProsesStatus.persen);
        if (b && sourceUri == null && !ProsesStatus.namaLagu.isEmpty()) {
            txtFile.setText(getString(R.string.lagu_terpilih, ProsesStatus.namaLagu));
        }
        final String pesan = ProsesStatus.pesan;
        if (!pesan.isEmpty()) {
            setStatus(pesan);
            if (!b && !pesan.equals(terakhirDiumumkan)) {
                terakhirDiumumkan = pesan;
                txtStatus.announceForAccessibility(pesan);
            }
        }
        if (!b && ProsesStatus.hasilBaru && !isFinishing()) {
            ProsesStatus.hasilBaru = false;
            dialogHasil.tampil();
        }
    }
}
