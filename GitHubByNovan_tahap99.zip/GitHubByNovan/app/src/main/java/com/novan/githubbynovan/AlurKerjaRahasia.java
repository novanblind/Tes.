package com.novan.githubbynovan;

import java.util.ArrayList;
import java.util.List;

/**
 * Tahap 99: menambahkan baris "NAMA: ${{ secrets.NAMA }}" ke langkah "Kompilasi APK Android" pada
 * alur kerja yang SUDAH ADA, tanpa mengubah bagian lain (tanda tangan, keamanan, dan langkah lain
 * tetap persis seperti semula). Tanpa kebergantungan Android supaya mudah diuji.
 */
final class AlurKerjaRahasia {
    private AlurKerjaRahasia() {}

    private static int indent(String s) {
        int i = 0;
        while (i < s.length() && s.charAt(i) == ' ') i++;
        return i;
    }

    private static String spasi(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(' ');
        return sb.toString();
    }

    /** Isi alur kerja baru, atau null bila langkah "Kompilasi APK Android" tidak ditemukan. */
    static String sisipkan(String isi, List<String> nama) {
        if (isi == null || nama == null || nama.isEmpty()) return null;
        final String eol = isi.contains("\r\n") ? "\r\n" : "\n";
        List<String> baris = new ArrayList<>();
        for (String s : isi.split("\r?\n", -1)) baris.add(s);

        int mulai = -1;
        for (int i = 0; i < baris.size(); i++) {
            String t = baris.get(i).trim();
            if (t.startsWith("- name:") && t.contains("Kompilasi APK Android")) { mulai = i; break; }
        }
        if (mulai < 0) return null;
        final int ind = indent(baris.get(mulai));
        int akhir = baris.size();
        for (int i = mulai + 1; i < baris.size(); i++) {
            String s = baris.get(i);
            if (s.trim().isEmpty()) continue;
            int d = indent(s);
            if (d < ind || (d == ind && s.trim().startsWith("- "))) { akhir = i; break; }
        }
        final int kunci = ind + 2;
        int envAt = -1, runAt = -1;
        for (int i = mulai + 1; i < akhir; i++) {
            String s = baris.get(i);
            if (indent(s) != kunci) continue;
            String t = s.trim();
            if (t.equals("env:") && envAt < 0) envAt = i;
            if (t.startsWith("run:") && runAt < 0) runAt = i;
        }
        List<String> tambah = new ArrayList<>();
        if (envAt >= 0) {
            int isiInd = kunci + 2;
            if (envAt + 1 < akhir) {
                String n = baris.get(envAt + 1);
                String t = n.trim();
                if (!t.isEmpty() && !t.startsWith("#") && indent(n) > kunci) isiInd = indent(n);
            }
            for (String u : nama) tambah.add(spasi(isiInd) + u + ": ${{ secrets." + u + " }}");
            baris.addAll(envAt + 1, tambah);
        } else if (runAt >= 0) {
            tambah.add(spasi(kunci) + "env:");
            for (String u : nama) tambah.add(spasi(kunci + 2) + u + ": ${{ secrets." + u + " }}");
            baris.addAll(runAt, tambah);
        } else {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < baris.size(); i++) {
            if (i > 0) sb.append(eol);
            sb.append(baris.get(i));
        }
        return sb.toString();
    }
}
