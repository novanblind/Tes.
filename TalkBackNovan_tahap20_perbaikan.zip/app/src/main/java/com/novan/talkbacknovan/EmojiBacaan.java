package com.novan.talkbacknovan;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

/** Mengganti emoji dengan bacaan bahasa Indonesia dari assets/emoji_id.txt (kunci TAB bacaan). */
public final class EmojiBacaan {
    private static HashMap<String, String> peta;
    private static int terpanjang = 1; // dalam code point

    private EmojiBacaan() {}

    private static synchronized void muat(Context c) {
        if (peta != null) return;
        HashMap<String, String> p = new HashMap<>(8192);
        int maks = 1;
        try (InputStream in = c.getApplicationContext().getAssets().open("emoji_id.txt");
             BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String baris;
            while ((baris = br.readLine()) != null) {
                if (baris.isEmpty() || baris.charAt(0) == '#') continue;
                int tab = baris.indexOf('\t');
                if (tab <= 0) continue;
                String kunci = buangFe0f(urai(baris.substring(0, tab)));
                String bacaan = baris.substring(tab + 1).trim();
                if (kunci.isEmpty() || bacaan.isEmpty()) continue;
                p.put(kunci, bacaan);
                maks = Math.max(maks, kunci.codePointCount(0, kunci.length()));
            }
        } catch (Exception ignored) {
        }
        terpanjang = maks;
        peta = p;
    }

    /** Mengubah urutan \\uXXXX dan \\UXXXXXXXX di berkas menjadi karakter sebenarnya. */
    private static String urai(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder sb = new StringBuilder(s.length());
        int i = 0;
        while (i < s.length()) {
            char ch = s.charAt(i);
            if (ch == '\\' && i + 1 < s.length()) {
                char j = s.charAt(i + 1);
                int panjang = j == 'u' ? 4 : (j == 'U' ? 8 : 0);
                if (panjang > 0 && i + 2 + panjang <= s.length()) {
                    try {
                        int cp = Integer.parseInt(s.substring(i + 2, i + 2 + panjang), 16);
                        sb.appendCodePoint(cp);
                        i += 2 + panjang;
                        continue;
                    } catch (Exception ignored) {
                    }
                }
            }
            sb.append(ch);
            i++;
        }
        return sb.toString();
    }

    private static String buangFe0f(String s) {
        return s.indexOf('\uFE0F') < 0 ? s : s.replace("\uFE0F", "");
    }

    private static boolean mungkinEmoji(int cp) {
        return cp >= 0x203C || cp == '#' || cp == '*' || (cp >= '0' && cp <= '9') || cp == 0xA9 || cp == 0xAE;
    }

    /** Ganti semua emoji dalam teks dengan bacaannya; teks lain tidak diubah. */
    public static String ganti(Context c, String teks) {
        if (teks == null || teks.isEmpty()) return teks;
        boolean ada = false;
        for (int i = 0; i < teks.length(); i++) {
            char ch = teks.charAt(i);
            if (ch >= 0x203C || ch == '#' || ch == '*' || ch == 0xA9 || ch == 0xAE) {
                ada = true;
                break;
            }
        }
        if (!ada) return teks;
        if (peta == null) muat(c);
        String s = buangFe0f(teks);
        int[] cp = s.codePoints().toArray();
        StringBuilder hasil = new StringBuilder(s.length() + 32);
        int i = 0;
        while (i < cp.length) {
            String bacaan = null;
            int pakai = 0;
            if (mungkinEmoji(cp[i])) {
                int batas = Math.min(terpanjang, cp.length - i);
                for (int n = batas; n >= 1; n--) {
                    String kunci = new String(cp, i, n);
                    String b = peta.get(kunci);
                    if (b != null) {
                        bacaan = b;
                        pakai = n;
                        break;
                    }
                }
            }
            if (bacaan != null) {
                if (hasil.length() > 0 && hasil.charAt(hasil.length() - 1) != ' ') hasil.append(' ');
                hasil.append(bacaan).append(' ');
                i += pakai;
            } else {
                hasil.appendCodePoint(cp[i]);
                i++;
            }
        }
        return hasil.toString().trim();
    }
}
