package com.novan.githubbynovan;

import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.widget.EditText;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Tanda tangan pribadi: buat keystore sendiri, ekspor ke folder Download, impor kembali dari folder Download
 * (misalnya setelah aplikasi dipasang ulang), dan kelola daftarnya.
 */
public class SignActivity extends BaseActivity {
    private static final int REQ_IMPOR = 4101;
    private Ui ui;
    private boolean busy;
    private boolean dariBangun;

    // data sementara selama proses impor
    private boolean impDariDownload;
    private byte[] impKs;
    private String impBerkas = "", impNama = "", impAlias = "", impSandi = "";

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        dariBangun = getIntent().getBooleanExtra("dari_bangun", false);
        daftar();
        if (getIntent().getBooleanExtra("impor", false)) mulaiImpor();
    }

    // ---------- daftar ----------

    private void daftar() {
        ui = new Ui(this, "Tanda tangan pribadi");
        ui.label("Tanda tangan dipakai untuk APK rilis. Simpan berkasnya baik-baik. "
                + "Pembaruan aplikasi harus memakai tanda tangan yang sama.");
        ui.button("Buat tanda tangan baru", v -> formBuat());
        ui.button("Impor tanda tangan dari folder Download", v -> mulaiImpor());
        List<JSONObject> l = Store.signs(this);
        if (l.isEmpty()) {
            ui.label("Belum ada tanda tangan pribadi.");
        } else {
            for (final JSONObject o : l) {
                ui.button(Store.labelSign(o), v -> rincian(o));
            }
        }
        boolean adaBelum = false;
        for (JSONObject o : l) if (!Store.sudahEkspor(o)) adaBelum = true;
        if (adaBelum) {
            ui.button("Simpan semua yang belum diekspor ke folder Download", v -> eksporSemua());
        }
        ui.button("Kembali", v -> finish());
    }

    private void rincian(final JSONObject o) {
        final boolean sudah = Store.sudahEkspor(o);
        String msg = "Nama: " + o.optString("nama")
                + "\nAlias: " + o.optString("alias")
                + "\nSandi: " + o.optString("sandi")
                + "\nSidik jari SHA-256:\n" + o.optString("sidik")
                + "\n\nBerkas: " + o.optString("unduhan")
                + (sudah ? "\n\nSudah tersimpan di folder Download (.p12 dan -info.txt)." : "");
        List<ApkTools.Btn> btns = new ArrayList<>();
        btns.add(ApkTools.keep("salin sandi", () -> Ui.copy(this, "Sandi tanda tangan", o.optString("sandi"))));
        if (!sudah) {
            btns.add(ApkTools.b("simpan ke folder Download (p12 dan info)", () -> simpanUlang(o)));
        }
        btns.add(ApkTools.b("hapus dari aplikasi", () -> ui.confirm("Hapus tanda tangan?",
                "Salinan di aplikasi dihapus. Berkas di folder Download tetap ada. "
                        + "Tanpa berkas itu, aplikasi lama tidak bisa diperbarui.",
                "hapus", () -> {
                    Store.removeSign(this, o.optString("id"));
                    File f = Store.signFile(this, o.optString("id"));
                    if (f.exists()) f.delete();
                    daftar();
                })));
        ApkTools.dialog(this, "Tanda tangan pribadi", msg, btns, "kembali", null);
    }

    // ---------- ekspor ----------

    private static String infoTeks(String nama, String alias, String sandi, String sidik, String slug) {
        return "TANDA TANGAN APK - SIMPAN BAIK-BAIK\n\nNama pemilik: " + nama
                + "\nAlias: " + alias + "\nSandi: " + sandi
                + "\nSidik jari SHA-256: " + sidik
                + "\nBerkas: " + slug + ".p12 (format PKCS12)"
                + "\n\nSandi tertulis di berkas ini. Jangan membagikannya ke orang lain.\n";
    }

    private static byte[] baca(File f) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    /** Simpan keystore (.p12) dan berkas info (alias + sandi) ke folder Download. Mengembalikan lokasi .p12. */
    private String eksporSatu(JSONObject o) throws Exception {
        File f = Store.signFile(this, o.optString("id"));
        if (!f.exists()) throw new Exception("Salinan di dalam aplikasi tidak ditemukan");
        String slug = o.optString("slug", "tanda-tangan");
        if (slug.isEmpty()) slug = "tanda-tangan";
        String lok = Saver.simpanBytes(this, slug + ".p12", "application/x-pkcs12", baca(f));
        String info = infoTeks(o.optString("nama"), o.optString("alias"), o.optString("sandi"),
                o.optString("sidik"), slug);
        Saver.simpanBytes(this, slug + "-info.txt", "text/plain", info.getBytes(StandardCharsets.UTF_8));
        return lok;
    }

    private void simpanUlang(final JSONObject o) {
        withStorage(() -> {
            ui.say("Menyimpan ke folder Download...");
            Api.POOL.execute(() -> {
                String pesan;
                try {
                    String lok = eksporSatu(o);
                    Store.updateSign(this, o.optString("id"), "diekspor", true);
                    pesan = "Tersimpan: " + lok + "\nBerkas -info.txt (alias dan sandi) ikut disimpan di sana.";
                } catch (Exception e) {
                    pesan = "Gagal menyimpan: " + e.getMessage();
                }
                final String fm = pesan;
                runOnUiThread(() -> { daftar(); ui.say(fm); });
            });
        });
    }

    private void eksporSemua() {
        withStorage(() -> {
            final List<JSONObject> l = new ArrayList<>();
            for (JSONObject o : Store.signs(this)) if (!Store.sudahEkspor(o)) l.add(o);
            if (l.isEmpty()) {
                ui.say("Semua tanda tangan sudah tersimpan di folder Download.");
                return;
            }
            ui.say("Menyimpan " + l.size() + " tanda tangan ke folder Download...");
            Api.POOL.execute(() -> {
                int ok = 0;
                StringBuilder gagal = new StringBuilder();
                for (JSONObject o : l) {
                    try {
                        eksporSatu(o);
                        Store.updateSign(this, o.optString("id"), "diekspor", true);
                        ok++;
                    } catch (Exception e) {
                        gagal.append("\n- ").append(o.optString("nama")).append(": ").append(e.getMessage());
                    }
                }
                final String pesan = ok + " dari " + l.size() + " tanda tangan tersimpan di folder Download." + (gagal.length() > 0 ? "\nGagal:" + gagal : "");
                runOnUiThread(() -> { daftar(); ui.say(pesan); });
            });
        });
    }

    // ---------- impor ----------

    private void mulaiImpor() {
        ApkTools.dialog(this, "Impor tanda tangan",
                "Pilih berkas .p12.\n\n"
                        + "Bila ada berkas -info.txt bernama sama, pilih keduanya: tekan lama berkas pertama, "
                        + "lalu ketuk berkas kedua. Alias dan sandi terisi otomatis. "
                        + "Bila hanya .p12, sandi akan ditanyakan.",
                ApkTools.list(ApkTools.b("pilih berkas", this::bukaPemilih)), "batal", null);
    }

    private void bukaPemilih() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                        Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
            } catch (Exception ignored) { }
        }
        try {
            startActivityForResult(i, REQ_IMPOR);
        } catch (Exception e) {
            ui.say("Pemilih berkas tidak tersedia di HP ini: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPOR) return;
        if (res != RESULT_OK || data == null) {
            ui.say("Tidak ada berkas yang dipilih.");
            return;
        }
        final List<Uri> uris = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) {
            ui.say("Tidak ada berkas yang dipilih.");
            return;
        }
        ui.progress("Membaca berkas...");
        Api.POOL.execute(() -> {
            byte[] ks = null;
            String ksNama = "", nama = "", alias = "", sandi = "";
            boolean ksDl = false;
            for (Uri u : uris) {
                try {
                    String nm = namaUri(u);
                    byte[] d = bacaUri(u);
                    if (d.length > 0 && (d[0] & 0xFF) == 0x30 && ks == null) {
                        ks = d;
                        ksNama = nm;
                        ksDl = Uri.decode(u.toString()).toLowerCase(java.util.Locale.US).contains("download");
                    } else {
                        String t = new String(d, StandardCharsets.UTF_8);
                        String x;
                        if (!(x = nilai(t, "Sandi")).isEmpty()) sandi = x;
                        if (!(x = nilai(t, "Alias")).isEmpty()) alias = x;
                        if (!(x = nilai(t, "Nama pemilik")).isEmpty()) nama = x;
                    }
                } catch (Exception ignored) { }
            }
            final byte[] fks = ks;
            final boolean fdl = ksDl;
            final String fkn = ksNama, fnama = nama, falias = alias, fsandi = sandi;
            runOnUiThread(() -> {
                if (fks == null) {
                    ui.say("Berkas .p12 tidak ditemukan. Pilih berkas .p12.");
                    return;
                }
                impKs = fks;
                impDariDownload = fdl;
                impBerkas = fkn.isEmpty() ? "keystore.p12" : fkn;
                impNama = fnama;
                impAlias = falias;
                impSandi = fsandi;
                if (!fsandi.isEmpty()) verifikasi();
                else formImpor("Sandi belum ditemukan. Masukkan sandi keystore.");
            });
        });
    }

    private String namaUri(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) { }
        return "";
    }

    private byte[] bacaUri(Uri u) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) throw new Exception("tidak bisa membuka berkas");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            long tot = 0;
            while ((n = in.read(buf)) != -1) {
                bos.write(buf, 0, n);
                tot += n;
                if (tot > 1000000) throw new Exception("berkas terlalu besar");
            }
            return bos.toByteArray();
        }
    }

    private static String nilai(String teks, String kunci) {
        Matcher m = Pattern.compile("(?im)^\\s*" + Pattern.quote(kunci) + "\\s*[:=]\\s*(.+?)\\s*$").matcher(teks);
        return m.find() ? m.group(1) : "";
    }

    private void formImpor(String pesan) {
        ui = new Ui(this, "Impor tanda tangan");
        ui.label("Berkas keystore: " + impBerkas);
        final EditText sandi = ui.edit("Sandi keystore (wajib)", "sandi tanda tangan", false, impSandi);
        final EditText alias = ui.edit("Alias kunci (boleh kosong, dicari otomatis)", "contoh: kunci", false, impAlias);
        final EditText nama = ui.edit("Nama tampilan (boleh kosong)", "contoh: Novan", false, impNama);
        ui.button("Impor", v -> {
            if (busy) return;
            impSandi = sandi.getText().toString();
            impAlias = alias.getText().toString().trim();
            impNama = nama.getText().toString().trim();
            if (impSandi.isEmpty()) { ui.say("Sandi wajib diisi."); return; }
            verifikasi();
        });
        ui.button("Kembali", v -> daftar());
        if (pesan != null && !pesan.isEmpty()) ui.say(pesan);
    }

    private void verifikasi() {
        busy = true;
        ui.progress("Memeriksa keystore...");
        final byte[] data = impKs;
        final String sandi = impSandi, aliasIn = impAlias, namaIn = impNama, berkas = impBerkas;
        final boolean dl = impDariDownload;
        Api.POOL.execute(() -> {
            try {
                char[] pw = sandi.toCharArray();
                KeyStore ks = KeyStore.getInstance("PKCS12");
                ks.load(new ByteArrayInputStream(data), pw);
                String al = null;
                if (!aliasIn.isEmpty()) {
                    if (ks.isKeyEntry(aliasIn)) al = aliasIn;
                    else {
                        Enumeration<String> en = ks.aliases();
                        while (en.hasMoreElements()) {
                            String x = en.nextElement();
                            if (x.equalsIgnoreCase(aliasIn) && ks.isKeyEntry(x)) { al = x; break; }
                        }
                    }
                }
                if (al == null) {
                    Enumeration<String> en = ks.aliases();
                    while (en.hasMoreElements()) {
                        String x = en.nextElement();
                        if (ks.isKeyEntry(x)) { al = x; break; }
                    }
                }
                if (al == null) throw new Exception("Tidak ada kunci di dalam keystore ini.");
                Key k = ks.getKey(al, pw);
                if (k == null) throw new Exception("Kunci tidak bisa dibuka dengan sandi ini.");
                Certificate c = ks.getCertificate(al);
                if (c == null) throw new Exception("Sertifikat tidak ditemukan di dalam keystore.");
                String sidik = KeystoreTools.sidikJari(c.getEncoded());
                String nama = namaIn;
                if (nama.isEmpty() && c instanceof X509Certificate) {
                    Matcher m = Pattern.compile("CN=([^,]+)")
                            .matcher(((X509Certificate) c).getSubjectX500Principal().getName());
                    if (m.find()) nama = m.group(1).trim();
                }
                if (nama.isEmpty()) nama = "Tanda tangan impor";

                for (JSONObject o : Store.signs(this)) {
                    if (sidik.equals(o.optString("sidik"))) {
                        final String ada = o.optString("nama");
                        runOnUiThread(() -> {
                            busy = false;
                            impKs = null;
                            daftar();
                            ui.say("Tanda tangan ini sudah ada di aplikasi dengan nama " + ada + ".");
                        });
                        return;
                    }
                }

                String id = String.valueOf(System.currentTimeMillis());
                try (FileOutputStream out = new FileOutputStream(Store.signFile(this, id))) {
                    out.write(data);
                }
                String slug = ProjectBuilder.slug(nama);
                if (slug.isEmpty()) slug = "tanda-tangan";
                slug = slug + "-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());

                final JSONObject rec = new JSONObject();
                rec.put("id", id);
                rec.put("nama", nama);
                rec.put("alias", al);
                rec.put("sandi", sandi);
                rec.put("sidik", sidik);
                rec.put("slug", slug);
                rec.put("unduhan", "diimpor dari " + berkas);
                rec.put("diekspor", dl);
                rec.put("dibuat", System.currentTimeMillis());
                Store.addSign(this, rec);
                final String fnama = nama;
                runOnUiThread(() -> {
                    busy = false;
                    impKs = null;
                    impSandi = "";
                    if (dariBangun) {
                        ApkTools.dialog(this, "Impor berhasil",
                                "Tanda tangan " + fnama + " sudah masuk.\n\nTekan kembali, lalu ulangi "
                                        + "Mulai pembangunan APK.",
                                ApkTools.list(ApkTools.b("kembali ke pembangunan APK", this::finish)),
                                null, null);
                    } else {
                        daftar();
                        rincian(rec);
                        ui.say("Impor berhasil: " + fnama);
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    busy = false;
                    formImpor("Gagal membuka keystore. Cek sandi dan format .p12.\nRincian: "
                            + e.getMessage());
                });
            }
        });
    }

    // ---------- buat ----------

    private void formBuat() {
        ui = new Ui(this, "Buat tanda tangan baru");
        final EditText nama = ui.edit("Nama pemilik (wajib)", "contoh: Novan", false, "");
        final EditText org = ui.edit("Organisasi (boleh kosong)", "contoh: Novan Studio", false, "");
        final EditText negara = ui.edit("Kode negara, 2 huruf", "contoh: ID", false, "ID");
        final EditText alias = ui.edit("Alias kunci", "tanpa spasi", false, "kunci");
        final EditText sandi = ui.edit("Sandi (kosong = dibuat otomatis)", "minimal 6 karakter", false, "");
        ui.label("Kunci RSA 2048 bit, berlaku 27 tahun. Disimpan di folder Download.");
        ui.button("Buat dan simpan ke Download", v -> {
            if (busy) return;
            String n = nama.getText().toString().trim();
            String o = org.getText().toString().trim();
            String c = negara.getText().toString().trim().toUpperCase(Locale.US);
            String a = alias.getText().toString().trim();
            String p = sandi.getText().toString();
            if (n.isEmpty()) { ui.say("Nama pemilik wajib diisi."); return; }
            if (!c.isEmpty() && !c.matches("[A-Z]{2}")) { ui.say("Kode negara harus 2 huruf, misalnya ID."); return; }
            if (a.isEmpty() || !a.matches("[A-Za-z0-9_-]+")) {
                ui.say("Alias hanya huruf, angka, garis bawah, atau tanda hubung.");
                return;
            }
            if (p.isEmpty()) p = KeystoreTools.sandiAcak();
            if (p.length() < 6) { ui.say("Sandi minimal 6 karakter."); return; }
            if (p.indexOf(' ') >= 0) { ui.say("Sandi tidak boleh memakai spasi."); return; }
            final String pf = p;
            withStorage(() -> proses(n, o, c, a, pf));
        });
        ui.button("Kembali", v -> daftar());
    }

    private void proses(final String n, final String o, final String c, final String a, final String p) {
        busy = true;
        ui.progress("Membuat kunci, mohon tunggu beberapa detik...");
        Api.POOL.execute(() -> {
            try {
                KeystoreTools.Hasil h = KeystoreTools.buat(n, o, c, a, p, 27);
                String id = String.valueOf(System.currentTimeMillis());
                String slug = ProjectBuilder.slug(n);
                if (slug.isEmpty()) slug = "tanda-tangan";
                slug = slug + "-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());

                try (FileOutputStream out = new FileOutputStream(Store.signFile(this, id))) {
                    out.write(h.data);
                }
                String lok = Saver.simpanBytes(this, slug + ".p12", "application/x-pkcs12", h.data);

                String info = "TANDA TANGAN APK - SIMPAN BAIK-BAIK\n\nNama pemilik: " + n
                        + "\nOrganisasi: " + o + "\nNegara: " + c
                        + "\nAlias: " + h.alias + "\nSandi: " + h.sandi
                        + "\nSidik jari SHA-256: " + h.sidikJari
                        + "\nBerkas: " + slug + ".p12 (format PKCS12)"
                        + "\n\nSandi tertulis di berkas ini. Jangan membagikannya ke orang lain.\n";
                Saver.simpanBytes(this, slug + "-info.txt", "text/plain", info.getBytes(StandardCharsets.UTF_8));

                final JSONObject rec = new JSONObject();
                rec.put("id", id);
                rec.put("nama", n);
                rec.put("alias", h.alias);
                rec.put("sandi", h.sandi);
                rec.put("sidik", h.sidikJari);
                rec.put("slug", slug);
                rec.put("unduhan", lok);
                rec.put("diekspor", true);
                rec.put("dibuat", System.currentTimeMillis());
                Store.addSign(this, rec);
                runOnUiThread(() -> {
                    busy = false;
                    daftar();
                    rincian(rec);
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    busy = false;
                    ui.say("Gagal membuat tanda tangan: " + e.getMessage());
                });
            }
        });
    }
}
