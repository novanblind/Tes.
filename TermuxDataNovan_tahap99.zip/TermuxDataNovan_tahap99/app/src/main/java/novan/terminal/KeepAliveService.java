package novan.terminal;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

/** Layanan latar depan: menjaga proses tetap hidup saat pindah aplikasi atau layar mati. */
public class KeepAliveService extends Service {
    static int count;
    static long lastUp;
    PowerManager.WakeLock wl;

    @Override public IBinder onBind(Intent i) { return null; }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("term", "Terminal", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("hasil", "Hasil", NotificationManager.IMPORTANCE_HIGH));
    }

    static Notification make(Context c, String chan, String title, String text) {
        PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, chan) : new Notification.Builder(c);
        return b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi).setAutoCancel(true).build();
    }

    static synchronized void begin(Context c) {
        if (count++ == 0) {
            Intent si = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(si); else c.startService(si);
        }
    }

    static synchronized void end(Context c) {
        if (count > 0 && --count == 0) c.stopService(new Intent(c, KeepAliveService.class));
    }

    /** Memperbarui teks pemberitahuan dengan baris terakhir (paling sering tiap 3 detik). */
    static void progress(Context c, String t) {
        if (c == null || count == 0 || t == null || t.trim().isEmpty() || Progres.aktif) return;
        long n = SystemClock.elapsedRealtime();
        if (n - lastUp < 3000) return;
        lastUp = n;
        if (t.length() > 120) t = t.substring(0, 120);
        c.getSystemService(NotificationManager.class).notify(1, make(c, "term", "Termux Data Novan berjalan", t));
    }

    /** Pemberitahuan berjalan dengan batang persen (paling sering tiap 2 detik). */
    static void persen(Context c, int p, String t) {
        if (c == null || count == 0) return;
        long n = SystemClock.elapsedRealtime();
        if (n - lastUp < 2000) return;
        lastUp = n;
        PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, "term") : new Notification.Builder(c);
        Notification nt = b.setContentTitle("Termux Data Novan: " + p + " persen").setContentText(t)
            .setSmallIcon(android.R.drawable.ic_menu_info_details).setContentIntent(pi).setOngoing(true)
            .setProgress(100, p, false).build();
        c.getSystemService(NotificationManager.class).notify(1, nt);
    }

    /** Pemberitahuan penting saat proses selesai, terbaca juga saat berada di aplikasi lain. */
    static void selesai(Context c, String t) {
        if (c == null) return;
        channels(c);
        c.getSystemService(NotificationManager.class).notify(2, make(c, "hasil", "Termux Data Novan", t));
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        channels(this);
        if (wl == null) {
            wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "novan:terminal");
            wl.setReferenceCounted(false);
        }
        if (!wl.isHeld()) wl.acquire();
        Notification n = make(this, "term", "Termux Data Novan", "Perintah sedang berjalan");
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
