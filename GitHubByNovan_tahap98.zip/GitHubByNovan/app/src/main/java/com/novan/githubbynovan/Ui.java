package com.novan.githubbynovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Pembangun layar yang ramah tunanetra: kontras tinggi (gelap atau terang sesuai pilihan, tanpa kuning), teks besar
 * (satuan sp, mengikuti ukuran font sistem), tombol tinggi, judul bertanda heading,
 * label terhubung ke kolom isian, dan pesan status lewat Toast + teks di layar.
 */
public class Ui {
    /** Warna tema aktif; diisi ulang oleh {@link #warna(Context)} setiap layar dibuat. Bawaan: gelap. */
    public static int BG = 0xFF000000, FG = 0xFFFFFFFF, BTN = 0xFF90CAF9,
            DANGER = 0xFFFF8A80, SOFT = 0xFFB3E5FC,
            EDIT_BG = 0xFF1E1E1E, EDIT_LINE = 0xFFFFFFFF, HINT = 0xFFBBBBBB,
            FOKUS_BG = 0xFFFFFFFF, FOKUS_LINE = 0xFF00B0FF;
    public static boolean gelapAktif = true;

    /** True bila tampilan harus gelap: pilihan pengguna, atau mengikuti mode gelap sistem. */
    public static boolean gelap(Context c) {
        String m = Store.tema(c);
        if ("gelap".equals(m)) return true;
        if ("terang".equals(m)) return false;
        int ui = c.getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return ui == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    /** Mengisi warna sesuai tema yang berlaku untuk konteks ini. Mengembalikan true bila gelap. */
    public static boolean warna(Context c) {
        boolean g = gelap(c);
        gelapAktif = g;
        if (g) {
            BG = 0xFF000000; FG = 0xFFFFFFFF; BTN = 0xFF90CAF9; DANGER = 0xFFFF8A80; SOFT = 0xFFB3E5FC;
            EDIT_BG = 0xFF1E1E1E; EDIT_LINE = 0xFFFFFFFF; HINT = 0xFFBBBBBB;
            FOKUS_BG = 0xFFFFFFFF; FOKUS_LINE = 0xFF00B0FF;
        } else {
            BG = 0xFFFAFAFA; FG = 0xFF111111; BTN = 0xFF0D47A1; DANGER = 0xFFB71C1C; SOFT = 0xFF01579B;
            EDIT_BG = 0xFFFFFFFF; EDIT_LINE = 0xFF212121; HINT = 0xFF555555;
            FOKUS_BG = 0xFFBBDEFB; FOKUS_LINE = 0xFF000000;
        }
        return g;
    }

    /** Warna teks (hitam atau putih) yang paling terbaca di atas warna latar tertentu. */
    public static int textOn(int bg) {
        double l = (0.299 * ((bg >> 16) & 0xFF) + 0.587 * ((bg >> 8) & 0xFF) + 0.114 * (bg & 0xFF)) / 255.0;
        return l > 0.5 ? 0xFF000000 : 0xFFFFFFFF;
    }

    public interface Text { void got(String s); }
    public interface TextCheck { void got(String s, boolean dicentang); }
    public interface Check { void got(boolean dicentang); }

    public final Activity act;
    public final LinearLayout box;
    public final TextView status;

    public Ui(Activity a, String title) {
        act = a;
        boolean g = warna(a);
        a.setTheme(g ? R.style.TemaGelap : R.style.TemaTerang);
        a.setTitle(title);
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        box.setPadding(p, p, p, p);
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView h = text(title, 28, FG);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        if (Build.VERSION.SDK_INT >= 28) h.setAccessibilityHeading(true);
        box.addView(h);
        status = text("", 18, SOFT);
        status.setVisibility(View.GONE);
        box.addView(status);
        a.setContentView(sv);
        terapkanBilah(a, g);
    }

    /** Warna bilah status dan navigasi mengikuti tema, ikon dibuat gelap di tema terang. */
    private static void terapkanBilah(Activity a, boolean g) {
        try {
            android.view.Window w = a.getWindow();
            w.setStatusBarColor(BG);
            w.setNavigationBarColor(BG);
            if (Build.VERSION.SDK_INT >= 23) {
                View d = w.getDecorView();
                int f = d.getSystemUiVisibility();
                f = g ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                if (Build.VERSION.SDK_INT >= 26) {
                    f = g ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                            : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                }
                d.setSystemUiVisibility(f);
            }
        } catch (Exception ignored) { }
    }

    public static int dpOf(android.content.Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public int dp(int v) {
        return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(act);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setPadding(0, dp(8), 0, dp(4));
        return v;
    }

    private GradientDrawable shape(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(4), stroke);
        return g;
    }

    private StateListDrawable bg(int color) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable on = shape(FOKUS_BG, FOKUS_LINE);
        s.addState(new int[]{android.R.attr.state_focused}, on);
        s.addState(new int[]{android.R.attr.state_pressed}, on);
        s.addState(new int[]{}, shape(color, color));
        return s;
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(top);
        return p;
    }

    public TextView label(String t) {
        TextView v = text(t, 20, FG);
        box.addView(v);
        return v;
    }

    /** Judul bagian (ditandai sebagai heading untuk pembaca layar). */
    public TextView section(String t) {
        TextView v = text(t, 22, BTN);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(20), 0, dp(4));
        if (Build.VERSION.SDK_INT >= 28) v.setAccessibilityHeading(true);
        box.addView(v);
        return v;
    }

    /** Pilihan satu dari banyak: tombol yang membuka daftar pilihan. */
    public static class Choice {
        public int index;
        public final String[] items;
        Button btn;
        Choice(String[] items, int index) { this.items = items; this.index = index; }
        public String value() { return items[index]; }
    }

    public Choice choice(final String label, final String[] items, int idx) {
        final Choice c = new Choice(items, idx);
        c.btn = button(label + ": " + items[idx] + " (ketuk untuk ganti)", v -> {
            AlertDialog d = new AlertDialog.Builder(act).setTitle(label)
                    .setSingleChoiceItems(items, c.index, (x, w) -> {
                        c.index = w;
                        c.btn.setText(label + ": " + items[w] + " (ketuk untuk ganti)");
                        x.dismiss();
                    })
                    .setNegativeButton("batal", null).show();
            fix(d);
        });
        return c;
    }

    public Button button(String t, View.OnClickListener l) { return button(t, BTN, l); }

    public Button button(String t, int color, View.OnClickListener l) {
        Button b = new Button(act);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setTextColor(new android.content.res.ColorStateList(
                new int[][]{{android.R.attr.state_focused}, {android.R.attr.state_pressed}, {}},
                new int[]{0xFF000000, 0xFF000000, textOn(color)}));
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setMinHeight(dp(64));
        b.setMinimumHeight(dp(64));
        b.setPadding(dp(16), dp(12), dp(16), dp(12));
        b.setBackground(bg(color));
        b.setStateListAnimator(null);
        b.setOnClickListener(l);
        box.addView(b, lp(10));
        return b;
    }

    public EditText edit(String label, String hint, boolean multi, String initial) {
        TextView l = text(label, 20, FG);
        box.addView(l);
        EditText e = new EditText(act);
        e.setId(View.generateViewId());
        l.setLabelFor(e.getId());
        e.setHint(hint);
        e.setHintTextColor(HINT);
        e.setTextColor(FG);
        e.setTextSize(20);
        e.setText(initial);
        e.setBackground(shape(EDIT_BG, EDIT_LINE));
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setMinLines(8);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        box.addView(e, lp(4));
        return e;
    }

    public CheckBox check(String text, boolean checked) {
        CheckBox c = new CheckBox(act);
        c.setText(text);
        c.setTextSize(20);
        c.setTextColor(FG);
        c.setChecked(checked);
        c.setMinHeight(dp(56));
        box.addView(c, lp(8));
        return c;
    }

    /** Pesan status: tampil di layar dan dibacakan pembaca layar lewat Toast. */
    public void say(String m) {
        status.setText(m);
        status.setVisibility(View.VISIBLE);
        Toast.makeText(act, m, Toast.LENGTH_LONG).show();
    }

    /** Pembaruan progres tanpa Toast agar tidak membanjiri pembaca layar. */
    public void progress(String m) {
        status.setText(m);
        status.setVisibility(View.VISIBLE);
    }

    /** Teks pesan di dalam isi dialog yang bisa digulir (bukan setMessage), agar ikut tergulir bersama kolom isian. */
    private void addMsg(LinearLayout f, String msg) {
        if (msg == null || msg.isEmpty()) return;
        TextView m = new TextView(act);
        m.setText(msg);
        m.setTextSize(18);
        m.setPadding(0, 0, 0, dp(8));
        f.addView(m);
    }

    public void fix(AlertDialog d) {
        // Dialog ikut mengecil saat keyboard tampil, supaya isi dan tombol bawah tetap bisa digeser/dijangkau.
        try {
            d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        } catch (Exception ignored) { }
        try {
            android.widget.Button b = d.getButton(AlertDialog.BUTTON_POSITIVE);
            if (b != null) b.setAllCaps(false);
        } catch (Exception ignored) { }
        try {
            android.widget.Button b = d.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (b != null) b.setAllCaps(false);
        } catch (Exception ignored) { }
    }

    /** Dialog informasi satu tombol; {@code after} dijalankan setelah tombol ditekan. */
    public void info(String title, String msg, String ok, final Runnable after) {
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setMessage(msg)
                .setPositiveButton(ok, (x, w) -> { if (after != null) after.run(); })
                .setCancelable(false).show();
        fix(d);
    }

    public void confirm(String title, String msg, String yes, final Runnable onYes) {
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setMessage(msg)
                .setPositiveButton(yes, (x, w) -> onYes.run())
                .setNegativeButton("batal", null).show();
        fix(d);
    }

    public void prompt(String title, String hint, String initial, final Text cb) {
        FrameLayout f = new FrameLayout(act);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText e = new EditText(act);
        e.setHint(hint);
        e.setText(initial);
        e.setTextSize(20);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        f.addView(e);
        ScrollView psv = new ScrollView(act);
        psv.addView(f);
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setView(psv)
                .setPositiveButton("simpan", (x, w) -> cb.got(e.getText().toString().trim()))
                .setNegativeButton("batal", null).show();
        fix(d);
    }

    /** Dialog dengan pesan, satu kolom isian berlabel, dan tombol simpan. */
    public void ask(String title, String message, String label, String initial, String yes, final Text cb) {
        LinearLayout f = new LinearLayout(act);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        addMsg(f, message);
        TextView l = new TextView(act);
        l.setText(label);
        l.setTextSize(18);
        f.addView(l);
        final EditText e = new EditText(act);
        e.setId(View.generateViewId());
        l.setLabelFor(e.getId());
        e.setText(initial);
        e.setTextSize(20);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        f.addView(e);
        ScrollView sv = new ScrollView(act);
        sv.addView(f);
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setView(sv)
                .setPositiveButton(yes, (x, w) -> cb.got(e.getText().toString().trim()))
                .setNegativeButton("batal", null).show();
        fix(d);
    }

    /** Seperti {@link #ask}, ditambah satu kotak centang di bawah isian. */
    public void askCheck(String title, String message, String label, String initial, String checkText,
                         boolean checked, String yes, final TextCheck cb) {
        LinearLayout f = new LinearLayout(act);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        addMsg(f, message);
        TextView l = new TextView(act);
        l.setText(label);
        l.setTextSize(18);
        f.addView(l);
        final EditText e = new EditText(act);
        e.setId(View.generateViewId());
        l.setLabelFor(e.getId());
        e.setText(initial);
        e.setTextSize(20);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        f.addView(e);
        final CheckBox cbx = new CheckBox(act);
        cbx.setText(checkText);
        cbx.setTextSize(18);
        cbx.setChecked(checked);
        cbx.setMinHeight(dp(56));
        f.addView(cbx);
        ScrollView sv = new ScrollView(act);
        sv.addView(f);
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setView(sv)
                .setPositiveButton(yes, (x, w) -> cb.got(e.getText().toString().trim(), cbx.isChecked()))
                .setNegativeButton("batal", null).show();
        fix(d);
    }

    /** Seperti {@link #confirm}, ditambah satu kotak centang. */
    public void confirmCheck(String title, String msg, String checkText, boolean checked, String yes,
                             final Check cb) {
        LinearLayout f = new LinearLayout(act);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        addMsg(f, msg);
        final CheckBox cbx = new CheckBox(act);
        cbx.setText(checkText);
        cbx.setTextSize(18);
        cbx.setChecked(checked);
        cbx.setMinHeight(dp(56));
        f.addView(cbx);
        ScrollView sv = new ScrollView(act);
        sv.addView(f);
        AlertDialog d = new AlertDialog.Builder(act).setTitle(title).setView(sv)
                .setPositiveButton(yes, (x, w) -> cb.got(cbx.isChecked()))
                .setNegativeButton("batal", null).show();
        fix(d);
    }

    public static void copy(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        Toast.makeText(c, label + " disalin.", Toast.LENGTH_SHORT).show();
    }

    public static void share(Context c, String subject, String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, subject);
        i.putExtra(Intent.EXTRA_TEXT, text);
        c.startActivity(Intent.createChooser(i, "Bagikan via"));
    }

    public static void browse(Context c, String url) {
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(c, "Gagal membuka browser.", Toast.LENGTH_SHORT).show();
        }
    }

    public static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", b / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0));
    }
}
