package com.novan.filemanagermax

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.pm.PackageInfoCompat
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TreeSet

/**
 * Dialog Properti yang lengkap dan jelas untuk berkas, folder, video, audio, gambar,
 * berkas APK, dan aplikasi terpasang (arsitektur, target SDK, SDK minimal, dan lain-lain,
 * ditambah tombol untuk membuka halaman aplikasi di Play Store).
 *
 * Setiap baris adalah satu elemen yang bisa difokuskan dan dibacakan utuh oleh pembaca layar
 * dalam bentuk "Label: nilai".
 */
object PropsDialog {

    // ------------------------------------------------------------------ kerangka tampilan

    private class Sheet(val ctx: Activity) {
        val scroll = ScrollView(ctx)
        val root = LinearLayout(ctx)
        val head = LinearLayout(ctx)
        val icon = ImageView(ctx)
        val titleView = TextView(ctx)
        val basics = LinearLayout(ctx)
        val extras = LinearLayout(ctx)
        val tail = LinearLayout(ctx)
        val primary: Int
        val secondary: Int

        @Volatile
        var alive = true

        fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

        init {
            val ta = ctx.obtainStyledAttributes(
                intArrayOf(android.R.attr.textColorPrimary, android.R.attr.textColorSecondary)
            )
            primary = ta.getColorStateList(0)?.defaultColor ?: Color.BLACK
            secondary = ta.getColorStateList(1)?.defaultColor ?: Color.DKGRAY
            ta.recycle()

            root.orientation = LinearLayout.VERTICAL
            root.setPadding(dp(24), dp(20), dp(24), dp(8))

            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.isFocusable = true
            head.setPadding(0, 0, 0, dp(12))

            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            icon.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val ilp = LinearLayout.LayoutParams(dp(56), dp(56))
            ilp.rightMargin = dp(16)
            head.addView(icon, ilp)

            titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            titleView.setTypeface(titleView.typeface, android.graphics.Typeface.BOLD)
            titleView.setTextColor(primary)
            titleView.maxLines = 3
            titleView.ellipsize = TextUtils.TruncateAt.END
            titleView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            head.addView(
                titleView,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )

            for (c in arrayOf(basics, extras, tail)) c.orientation = LinearLayout.VERTICAL
            root.addView(head)
            root.addView(basics)
            root.addView(extras)
            root.addView(tail)
            scroll.addView(root)
        }

        fun setTitle(t: String) {
            titleView.text = t
            head.contentDescription = t
        }

        /** Satu baris label + nilai; seluruh baris dibacakan sebagai "Label: nilai". */
        fun row(parent: LinearLayout, label: String, value: String): TextView {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            r.setPadding(0, dp(6), 0, dp(6))
            r.isFocusable = true
            r.contentDescription = "$label: $value"

            val l = TextView(ctx)
            l.text = label
            l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            l.setTextColor(secondary)
            l.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

            val v = TextView(ctx)
            v.text = value
            v.tag = label
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            v.setTextColor(primary)
            v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

            r.addView(l, LinearLayout.LayoutParams(dp(112), ViewGroup.LayoutParams.WRAP_CONTENT))
            r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            parent.addView(r)
            return v
        }

        fun setValue(v: TextView, text: String) {
            v.text = text
            (v.parent as? View)?.contentDescription = "${v.tag}: $text"
        }

        /** Baris berisi label dan sebuah tampilan (mis. tombol). */
        fun rowView(parent: LinearLayout, label: String, view: View) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(6), 0, dp(6))
            val l = TextView(ctx)
            l.text = label
            l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            l.setTextColor(secondary)
            l.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            r.addView(l, LinearLayout.LayoutParams(dp(112), ViewGroup.LayoutParams.WRAP_CONTENT))
            r.addView(view, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            parent.addView(r)
        }

        fun addAll(parent: LinearLayout, list: List<Pair<String, String>>) {
            for (p in list) row(parent, p.first, p.second)
        }

        /** Menjalankan [block] di thread utama bila dialog masih terbuka. */
        fun ui(block: () -> Unit) {
            ctx.runOnUiThread {
                if (alive && !ctx.isFinishing && !ctx.isDestroyed) block()
            }
        }
    }

    private fun present(s: Sheet, neutralLabel: Int = 0, neutral: (() -> Unit)? = null) {
        val b = AlertDialog.Builder(s.ctx)
            .setView(s.scroll)
            .setPositiveButton(R.string.pr_ok, null)
        if (neutral != null) b.setNeutralButton(neutralLabel) { _, _ -> neutral() }
        val d = b.create()
        d.setOnDismissListener { s.alive = false }
        d.show()
    }

    // ------------------------------------------------------------------ format

    private fun str(s: Sheet, id: Int): String = s.ctx.getString(id)

    private fun sizeText(c: Activity, bytes: Long): String {
        val exact = NumberFormat.getIntegerInstance(Locale.getDefault()).format(bytes)
        return "${Util.formatSize(c, bytes)} ($exact byte)"
    }

    private fun dateText(ms: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH.mm", Locale.getDefault()).format(Date(ms))

    private fun durationText(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun androidName(api: Int): String? = when (api) {
        21 -> "5.0"; 22 -> "5.1"; 23 -> "6.0"; 24 -> "7.0"; 25 -> "7.1"
        26 -> "8.0"; 27 -> "8.1"; 28 -> "9"; 29 -> "10"; 30 -> "11"
        31 -> "12"; 32 -> "12L"; 33 -> "13"; 34 -> "14"; 35 -> "15"
        36 -> "16"; 37 -> "17"
        else -> null
    }

    private fun sdkText(api: Int): String {
        if (api <= 0) return "-"
        val n = androidName(api)
        return if (n != null) "$api (Android $n)" else api.toString()
    }

    // ------------------------------------------------------------------ berkas dan folder

    fun showFile(ctx: Activity, f: File) {
        val s = Sheet(ctx)
        val isDir = f.isDirectory
        val kind = if (isDir) -1 else Util.kindOf(f)
        val isApk = !isDir && f.extension.equals("apk", ignoreCase = true)
        s.setTitle(f.name.ifEmpty { f.absolutePath })

        s.icon.setImageResource(Util.iconFor(f))
        if (kind == Util.K_IMAGE || kind == Util.K_VIDEO) Thumbs.load(s.icon, f.absolutePath)

        s.row(s.basics, str(s, R.string.pr_type), str(s, if (isDir) R.string.pr_folder else R.string.pr_file))
        if (!isDir && f.extension.isNotEmpty()) {
            val mime = Util.mimeOf(f)
            if (mime != "*/*") s.row(s.basics, str(s, R.string.pr_format), mime)
        }
        val sizeView = s.row(
            s.basics, str(s, R.string.pr_size),
            if (isDir) str(s, R.string.pr_calculating) else sizeText(ctx, f.length())
        )
        s.row(s.basics, str(s, R.string.pr_modified), dateText(f.lastModified()))
        s.row(s.basics, str(s, R.string.pr_path), f.absolutePath)
        val perm = when {
            f.canRead() && f.canWrite() -> R.string.pr_perm_rw
            f.canRead() -> R.string.pr_perm_r
            f.canWrite() -> R.string.pr_perm_w
            else -> R.string.pr_perm_none
        }
        s.row(s.basics, str(s, R.string.pr_perm), str(s, perm))
        s.row(
            s.basics, str(s, R.string.pr_hidden),
            str(s, if (f.name.startsWith(".")) R.string.pr_yes else R.string.pr_no)
        )

        // Checksum hanya untuk berkas, dihitung bila tombol ditekan.
        if (!isDir && f.isFile) {
            val btn = Button(ctx)
            btn.setText(R.string.pr_checksum_btn)
            btn.setOnClickListener {
                btn.isEnabled = false
                btn.setText(R.string.pr_calculating)
                Thread {
                    val out: List<Pair<String, String>>? = try {
                        val md5 = MessageDigest.getInstance("MD5")
                        val sha1 = MessageDigest.getInstance("SHA-1")
                        val sha256 = MessageDigest.getInstance("SHA-256")
                        f.inputStream().use { ins ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                if (!s.alive) return@Thread
                                val n = ins.read(buf)
                                if (n < 0) break
                                md5.update(buf, 0, n)
                                sha1.update(buf, 0, n)
                                sha256.update(buf, 0, n)
                            }
                        }
                        listOf(
                            "MD5" to hex(md5.digest()),
                            "SHA-1" to hex(sha1.digest()),
                            "SHA-256" to hex(sha256.digest())
                        )
                    } catch (e: Exception) {
                        null
                    }
                    s.ui {
                        s.tail.removeAllViews()
                        if (out == null) s.row(s.tail, str(s, R.string.pr_checksum), str(s, R.string.pr_failed))
                        else s.addAll(s.tail, out)
                    }
                }.start()
            }
            s.rowView(s.tail, str(s, R.string.pr_checksum), btn)
        }

        val apkPkg = arrayOfNulls<String>(1)
        if (isApk) {
            present(s, R.string.pr_store) {
                val p = apkPkg[0]
                if (p == null) Toast.makeText(ctx, R.string.pr_store_fail, Toast.LENGTH_SHORT).show()
                else openStore(ctx, p)
            }
        } else {
            present(s)
        }

        Thread {
            val extra = ArrayList<Pair<String, String>>()
            try {
                if (isDir) {
                    var dirs = 0
                    var files = 0
                    f.listFiles()?.forEach { if (it.isDirectory) dirs++ else files++ }
                    val total = FileOps.sizeOf(f)
                    s.ui {
                        s.setValue(sizeView, sizeText(ctx, total))
                        s.row(
                            s.extras, str(s, R.string.pr_contains),
                            ctx.getString(R.string.pr_contains_val, dirs, files)
                        )
                    }
                    return@Thread
                }
                when (kind) {
                    Util.K_IMAGE -> imageRows(ctx, f, extra)
                    Util.K_VIDEO, Util.K_AUDIO -> mediaRows(ctx, f, kind == Util.K_VIDEO, extra)
                }
                if (isApk) apkFileRows(ctx, f, extra, apkPkg, s)
            } catch (e: Throwable) {
                // rincian tambahan bersifat opsional
            }
            s.ui { s.addAll(s.extras, extra) }
        }.start()
    }

    private fun imageRows(ctx: Activity, f: File, out: MutableList<Pair<String, String>>) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        var w = o.outWidth
        var h = o.outHeight
        var camera = ""
        var taken = ""
        try {
            val ex = ExifInterface(f.absolutePath)
            if (ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) in 5..8) {
                val t = w; w = h; h = t
            }
            camera = listOfNotNull(
                ex.getAttribute(ExifInterface.TAG_MAKE), ex.getAttribute(ExifInterface.TAG_MODEL)
            ).joinToString(" ").trim()
            val raw = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
            if (!raw.isNullOrBlank()) {
                taken = try {
                    val d = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(raw)
                    if (d != null) dateText(d.time) else raw
                } catch (e: Exception) {
                    raw
                }
            }
        } catch (e: Exception) {
            // tanpa EXIF
        }
        if (w > 0 && h > 0) out.add(ctx.getString(R.string.pr_resolution) to "$w x $h")
        if (camera.isNotEmpty()) out.add(ctx.getString(R.string.pr_camera) to camera)
        if (taken.isNotEmpty()) out.add(ctx.getString(R.string.pr_taken) to taken)
    }

    private fun mediaRows(ctx: Activity, f: File, video: Boolean, out: MutableList<Pair<String, String>>) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            fun meta(k: Int): String? = r.extractMetadata(k)?.takeIf { it.isNotBlank() }
            if (video) {
                var w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                var h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
                if (w > 0 && h > 0) out.add(ctx.getString(R.string.pr_resolution) to "$w x $h")
            }
            meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let {
                out.add(ctx.getString(R.string.pr_duration) to durationText(it))
            }
            if (!video) {
                meta(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let { out.add(ctx.getString(R.string.pr_title) to it) }
                meta(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let { out.add(ctx.getString(R.string.pr_artist) to it) }
                meta(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.let { out.add(ctx.getString(R.string.pr_album) to it) }
            }
            meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()?.let {
                out.add(ctx.getString(R.string.pr_bitrate) to "${it / 1000} kb/s")
            }
            if (video && Build.VERSION.SDK_INT >= 23) {
                meta(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()?.let {
                    out.add(ctx.getString(R.string.pr_framerate) to String.format(Locale.US, "%.2f fps", it))
                }
            }
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun apkFileRows(
        ctx: Activity, f: File, out: MutableList<Pair<String, String>>,
        pkgOut: Array<String?>, s: Sheet
    ) {
        val pm = ctx.packageManager
        val pi = pm.getPackageArchiveInfo(f.absolutePath, infoFlags()) ?: return
        val ai = pi.applicationInfo ?: return
        ai.sourceDir = f.absolutePath
        ai.publicSourceDir = f.absolutePath
        pkgOut[0] = pi.packageName
        out.addAll(appRows(ctx, pm, ai, pi, installed = false))
        val cur = try { pm.getPackageInfo(pi.packageName, 0) } catch (e: Exception) { null }
        out.add(
            ctx.getString(R.string.pr_install_state) to
                if (cur == null) ctx.getString(R.string.pr_not_installed)
                else ctx.getString(R.string.pr_installed_ver, cur.versionName ?: "-")
        )
    }

    // ------------------------------------------------------------------ aplikasi terpasang

    fun showApp(ctx: Activity, pkg: String) {
        val pm = ctx.packageManager
        val ai0 = try { pm.getApplicationInfo(pkg, 0) } catch (e: Exception) {
            Toast.makeText(ctx, R.string.pr_app_gone, Toast.LENGTH_SHORT).show()
            return
        }
        val s = Sheet(ctx)
        s.setTitle(pm.getApplicationLabel(ai0).toString())
        try { s.icon.setImageDrawable(pm.getApplicationIcon(ai0)) } catch (e: Exception) {
            s.icon.setImageResource(R.drawable.ic_apk)
        }
        s.row(s.basics, str(s, R.string.pr_package), pkg)
        present(s, R.string.pr_store) { openStore(ctx, pkg) }

        Thread {
            val rows = try {
                val pi = pm.getPackageInfo(pkg, infoFlags())
                appRows(ctx, pm, pi.applicationInfo ?: ai0, pi, installed = true)
            } catch (e: Throwable) {
                emptyList()
            }
            s.ui {
                // paket sudah ada di bagian atas
                val pkgLabel = str(s, R.string.pr_package)
                s.addAll(s.extras, rows.filter { it.first != pkgLabel })
            }
        }.start()
    }

    private fun infoFlags(): Int {
        var fl = PackageManager.GET_PERMISSIONS
        fl = fl or (if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else 0)
        return fl
    }

    private val ABI_SPLITS = mapOf(
        "arm64_v8a" to "arm64-v8a", "armeabi_v7a" to "armeabi-v7a", "x86_64" to "x86_64",
        "x86" to "x86", "armeabi" to "armeabi", "mips64" to "mips64", "mips" to "mips"
    )

    /** Arsitektur CPU yang didukung APK: dari folder lib/ di dalam APK dan nama split config. */
    private fun abisOf(paths: List<String>): List<String> {
        val set = TreeSet<String>()
        for (p in paths) {
            try {
                java.util.zip.ZipFile(p).use { z ->
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val n = en.nextElement().name
                        if (n.startsWith("lib/")) {
                            val parts = n.split('/')
                            if (parts.size >= 3 && parts[2].isNotEmpty()) set.add(parts[1])
                        }
                    }
                }
            } catch (e: Exception) {
                // APK tidak terbaca
            }
            val name = File(p).name
            for ((key, abi) in ABI_SPLITS) {
                if (name.contains("config.$key")) { set.add(abi); break }
            }
        }
        return set.toList()
    }

    @Suppress("DEPRECATION")
    private fun appRows(
        ctx: Activity, pm: PackageManager, ai: ApplicationInfo, pi: PackageInfo, installed: Boolean
    ): List<Pair<String, String>> {
        val r = ArrayList<Pair<String, String>>()
        fun add(labelId: Int, v: String) { r.add(ctx.getString(labelId) to v) }

        add(R.string.pr_app_name, ai.loadLabel(pm).toString())
        add(R.string.pr_package, ai.packageName)
        add(R.string.pr_version, pi.versionName ?: "-")
        add(R.string.pr_version_code, PackageInfoCompat.getLongVersionCode(pi).toString())
        add(R.string.pr_target_sdk, sdkText(ai.targetSdkVersion))
        add(R.string.pr_min_sdk, sdkText(ai.minSdkVersion))
        if (Build.VERSION.SDK_INT >= 31 && ai.compileSdkVersion > 0) {
            add(R.string.pr_compile_sdk, sdkText(ai.compileSdkVersion))
        }

        val paths = ArrayList<String>()
        ai.sourceDir?.let { paths.add(it) }
        ai.splitSourceDirs?.let { paths.addAll(it) }
        val abis = abisOf(paths)
        add(
            R.string.pr_abis,
            if (abis.isEmpty()) ctx.getString(R.string.pr_abis_none) else abis.joinToString(", ")
        )
        add(R.string.pr_device_abis, Build.SUPPORTED_ABIS.joinToString(", "))
        if (installed) {
            val run = try {
                ApplicationInfo::class.java.getField("primaryCpuAbi").get(ai) as? String
            } catch (e: Throwable) {
                null
            }
            if (!run.isNullOrEmpty()) add(R.string.pr_run_abi, run)

            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val upd = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            add(
                R.string.pr_app_kind,
                ctx.getString(
                    when {
                        sys && upd -> R.string.pr_kind_system_upd
                        sys -> R.string.pr_kind_system
                        else -> R.string.pr_kind_user
                    }
                )
            )
            add(R.string.pr_status, ctx.getString(if (ai.enabled) R.string.pr_enabled else R.string.pr_disabled))
        }
        val splits = ai.splitSourceDirs?.size ?: 0
        if (splits > 0) add(R.string.pr_split, ctx.getString(R.string.pr_split_val, splits))
        var total = 0L
        for (p in paths) total += File(p).length()
        if (total > 0) add(R.string.pr_apk_size, sizeText(ctx, total))
        ai.sourceDir?.let { add(R.string.pr_apk_path, it) }
        if (installed) {
            ai.dataDir?.let { add(R.string.pr_data_dir, it) }
            add(R.string.pr_installed, dateText(pi.firstInstallTime))
            add(R.string.pr_updated, dateText(pi.lastUpdateTime))
            val inst = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(ai.packageName).installingPackageName
                else pm.getInstallerPackageName(ai.packageName)
            } catch (e: Exception) {
                null
            }
            add(R.string.pr_installer, if (inst.isNullOrEmpty()) ctx.getString(R.string.pr_installer_none) else storeName(inst))
            add(R.string.pr_uid, ai.uid.toString())
        }
        add(R.string.pr_perms, (pi.requestedPermissions?.size ?: 0).toString())
        add(
            R.string.pr_debuggable,
            ctx.getString(if ((ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) R.string.pr_yes else R.string.pr_no)
        )

        val cert: ByteArray? = try {
            if (Build.VERSION.SDK_INT >= 28) {
                val si = pi.signingInfo
                val arr = if (si == null) null
                else if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
                arr?.firstOrNull()?.toByteArray()
            } else {
                pi.signatures?.firstOrNull()?.toByteArray()
            }
        } catch (e: Exception) {
            null
        }
        if (cert != null) {
            add(R.string.pr_signature, hex(MessageDigest.getInstance("SHA-256").digest(cert)))
        }
        return r
    }

    private fun storeName(pkg: String): String = when (pkg) {
        "com.android.vending" -> "Google Play Store"
        "com.google.android.packageinstaller", "com.android.packageinstaller" -> "Pemasang paket ($pkg)"
        "com.sec.android.app.samsungapps" -> "Galaxy Store"
        "com.heytap.market", "com.oppo.market" -> "App Market OPPO"
        "com.xiaomi.mipicks", "com.xiaomi.market" -> "Xiaomi GetApps"
        "com.amazon.venezia" -> "Amazon Appstore"
        else -> pkg
    }

    /** Membuka halaman aplikasi di Play Store; bila tidak ada, lewat peramban. */
    fun openStore(ctx: Activity, pkg: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                .setPackage("com.android.vending")
            ctx.startActivity(i)
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                )
            } catch (e2: Exception) {
                Toast.makeText(ctx, R.string.pr_store_fail, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
