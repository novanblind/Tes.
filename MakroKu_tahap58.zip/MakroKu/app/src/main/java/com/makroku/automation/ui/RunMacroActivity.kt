package com.makroku.automation.ui

import android.app.Activity
import android.os.Bundle
import com.makroku.automation.MakroApp

/** Activity tak terlihat untuk menjalankan makro dari pintasan layar utama. */
class RunMacroActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("macroId", 0L)
        if (id != 0L && !(application as MakroApp).engine.runNow(id))
            android.widget.Toast.makeText(this, "MakroKu sedang tidak aktif", android.widget.Toast.LENGTH_SHORT).show()
        finish()
    }
}
