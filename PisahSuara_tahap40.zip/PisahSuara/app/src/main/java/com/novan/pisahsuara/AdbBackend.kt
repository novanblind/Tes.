package com.novan.pisahsuara

import android.content.Context
import android.provider.Settings
import io.github.muntashirakon.adb.AdbStream
import java.io.InputStreamReader

/** Jalur tanpa Shizuku: sambung ke adbd lewat Debugging nirkabel lalu jalankan Server sebagai shell. */
object AdbBackend {
    private const val LOG = "/data/local/tmp/pisahsuara.log"
    private const val STATE = "/data/local/tmp/pisahsuara.state"
    private const val CFG = "/data/local/tmp/pisahsuara.cfg"
    private const val POLA = "com.novan.pisahsuara.Serve[r]"

    /** Nomor versi aplikasi ini; Server menulisnya ke berkas status supaya Server versi lama (setelah pembaruan) ketahuan. */
    fun versiApp(c: Context): String = try {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toString()
        else @Suppress("DEPRECATION") pi.versionCode.toString()
    } catch (e: Throwable) { "?" }

    /** Android 7-10: tidak ada pairing; begitu tersambung lewat 127.0.0.1:5555 (setelah "adb tcpip 5555" dari komputer/HP lain) dianggap terpasang. */
    @JvmStatic fun tandaiPasang(c: Context) {
        c.getSharedPreferences("adb_pisah", Context.MODE_PRIVATE).edit().putBoolean("paired", true).putBoolean("tcp", true).apply()
    }

    fun dipasangkan(c: Context) = c.getSharedPreferences("adb_pisah", Context.MODE_PRIVATE).getBoolean("paired", false)

    fun tersambung(c: Context): Boolean = try { Adb.get(c).isConnected } catch (e: Throwable) { false }

    fun jalankanPublik(a: Adb, tujuan: String): String = jalankan(a, tujuan)

    private val kolam = java.util.concurrent.Executors.newCachedThreadPool()

    /** Satu panggilan ADB yang tidak menjawab tidak boleh menahan semuanya: batas 10 detik lalu galat. */
    private fun jalankan(a: Adb, tujuan: String): String {
        val f = kolam.submit(java.util.concurrent.Callable { jalankanLangsung(a, tujuan) })
        return try {
            f.get(10, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: java.util.concurrent.TimeoutException) {
            f.cancel(true)
            throw java.io.IOException("ADB tidak menjawab (>10 dtk): ${tujuan.take(60)}")
        } catch (e: java.util.concurrent.ExecutionException) {
            throw (e.cause ?: e)
        }
    }

    private fun jalankanLangsung(a: Adb, tujuan: String): String {
        val s: AdbStream = a.openStream(tujuan)
        val sb = StringBuilder()
        try {
            val r = InputStreamReader(s.openInputStream(), Charsets.UTF_8)
            val buf = CharArray(2048)
            while (true) {
                val n = r.read(buf)
                if (n <= 0) break
                sb.append(buf, 0, n)
            }
        } catch (_: java.io.IOException) {
        } finally {
            try { s.close() } catch (_: Throwable) {}
        }
        return sb.toString()
    }

    /** Dipanggil sekali setiap berhasil tersambung: beri diri izin agar bisa menyalakan Debugging nirkabel sendiri. */
    @JvmStatic
    fun setelahTersambung(c: Context, a: Adb) {
        if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { jalankan(a, "shell:pm grant ${c.packageName} android.permission.WRITE_SECURE_SETTINGS") } catch (_: Throwable) {}
        }
        aktifkanDebugging(c)
        // Pindah ke jalur lokal (127.0.0.1:5555) supaya tetap tersambung saat Wi-Fi dimatikan.
        if (!Lokal.viaLokal) Lokal.aktifkanModeTanpaWifi(c, a)
    }

    fun aktifkanDebugging(c: Context) {
        if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val r = c.contentResolver
        try { Settings.Global.putInt(r, "development_settings_enabled", 1) } catch (_: Throwable) {}
        try { Settings.Global.putInt(r, "adb_enabled", 1) } catch (_: Throwable) {}
        if (Kompat.adaNirkabel()) try { Settings.Global.putInt(r, "adb_wifi_enabled", 1) } catch (_: Throwable) {}
        try { Settings.Global.putLong(r, "adb_allowed_connection_time", 0L) } catch (_: Throwable) {}
    }

    /** Wi-Fi tersambung? Tanpa Wi-Fi tidak ada gunanya memindai Debugging nirkabel (boros baterai). */
    fun wifiAda(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
    } catch (e: Throwable) { false }

    /** Pastikan tersambung; coba beberapa kali (mis. setelah HP restart, Wi-Fi belum siap). */
    private fun pastikanTersambung(c: Context, percobaan: Int): Adb? {
        val a = try { Adb.get(c) } catch (e: Throwable) { return null }
        for (i in 0 until percobaan) {
            if (a.isConnected) return a
            aktifkanDebugging(c)
            if (!Kompat.adaNirkabel()) {
                // Android 7-10: hanya jalur lokal (mode TCP dihidupkan dari komputer / HP lain lewat USB). Hilang saat HP restart.
                if (Lokal.sambungLokal(a)) { tandaiPasang(c); setelahTersambung(c, a); return a }
                return null
            }
            // Setelah restart, adbd kembali ke mode awal: coba jalur lokal dulu, lalu lewat Wi-Fi.
            if (Lokal.modeAktif(c) && Lokal.sambungLokal(a)) return a
            Lokal.viaLokal = false
            if (!wifiAda(c)) return null
            try { a.sambungTls(c, 6000L) } catch (_: Throwable) {}
            if (a.isConnected) { setelahTersambung(c, a); return a }
            try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
        }
        return if (a.isConnected) a else null
    }

    /** Beberapa baris terakhir log dan keluaran galat Server, untuk menjelaskan kenapa Server berhenti. */
    fun catatanServer(c: Context): String? = try {
        val a = Adb.get(c)
        if (!a.isConnected) null
        else {
            val jalan = jalankan(a, "shell:pgrep -f '$POLA' 2>/dev/null").trim()
            val log = jalankan(a, "shell:tail -n 3 $LOG 2>/dev/null; tail -n 3 /data/local/tmp/pisahsuara.out 2>/dev/null")
                .trim().replace("\n", " | ").take(300)
            val kill = if (jalan.isEmpty())
                jalankan(a, "shell:logcat -d -t 400 2>/dev/null | grep -i -E 'pisahsuara|app_process|Killing|signal 9|SIGHUP' | tail -n 3")
                    .trim().replace("\n", " | ").take(250) else ""
            ("proses=" + (if (jalan.isEmpty()) "MATI" else "hidup(pid $jalan)") + " | " + log +
                (if (kill.isNotEmpty()) " | logcat: $kill" else "")).take(700)
        }
    } catch (e: Throwable) { null }

    /** Laporan keadaan nyata dari Server (null bila ADB terputus atau Server belum menulis). */
    fun bacaLaporan(c: Context): String? = try {
        val a = Adb.get(c)
        if (!a.isConnected) null else jalankan(a, "shell:cat $STATE 2>/dev/null").trim().ifEmpty { null }
    } catch (e: Throwable) { null }

    /**
     * Perbarui aturan pada Server yang sudah berjalan, tanpa memulai ulang (langsung berlaku).
     * Mengembalikan hasil dari Server, atau null bila Server tidak hidup / tidak menjawab (pemanggil memulai ulang penuh).
     */
    fun perbarui(c: Context, hp: List<Int>, bt: List<Int>, kunci: String?): String? {
        if (!dipasangkan(c) || !tersambung(c)) return null
        val a = try { Adb.get(c) } catch (e: Throwable) { return null }
        return try {
            val awal = bacaLaporan(c) ?: return null
            val tAwal = awal.lines().firstOrNull { it.startsWith("T ") }?.substring(2)?.trim()?.toLongOrNull() ?: return null
            if (Math.abs(System.currentTimeMillis() - tAwal) > 25000) return null
            // Server dari versi aplikasi yang lebih lama: mulai ulang penuh supaya kode barunya dipakai.
            if (awal.lines().none { it.trim() == "VERSI ${versiApp(c)}" }) return null
            val h = if (hp.isEmpty()) "-" else hp.joinToString(",")
            val b = if (bt.isEmpty()) "-" else bt.joinToString(",")
            val k = (kunci ?: "auto").replace("'", "")
            val sig = "hp=$h;bt=$b;key=$k"
            if (awal.lines().none { it == "CFG $sig" }) {
                jalankan(a, "shell:echo '$sig' > $CFG")
            }
            for (i in 0 until 16) {
                val l = bacaLaporan(c)
                if (l != null && l.lines().any { it == "CFG $sig" }) {
                    return l.lines().firstOrNull { it.startsWith("HASIL ") }?.removePrefix("HASIL ") ?: "Aktif"
                }
                try { Thread.sleep(250) } catch (_: InterruptedException) { return null }
            }
            null
        } catch (e: Throwable) { null }
    }

    fun hentikan(c: Context) {
        val a = try { Adb.get(c) } catch (e: Throwable) { return }
        tutupAliran()
        if (!a.isConnected) return
        try { jalankan(a, "shell:pkill -f '$POLA'") } catch (_: Throwable) {}
    }

    // Aliran ADB yang dibiarkan terbuka: selama terbuka, Server tetap hidup (tidak dimatikan saat aliran ditutup).
    @Volatile private var aliranServer: AdbStream? = null

    private fun tutupAliran() {
        try { aliranServer?.close() } catch (_: Throwable) {}
        aliranServer = null
    }

    fun terapkan(c: Context, hp: List<Int>, bt: List<Int>, kunci: String?): String {
        if (!dipasangkan(c)) return "ADB belum dipasangkan. Ketuk baris Sambungan ADB."
        val a = pastikanTersambung(c, 5) ?: return "ADB belum tersambung. Nyalakan Wi-Fi dan Debugging nirkabel."
        return try {
            val apk = c.applicationInfo.sourceDir
            val h = if (hp.isEmpty()) "-" else hp.joinToString(",")
            val b = if (bt.isEmpty()) "-" else bt.joinToString(",")
            val k = (kunci ?: "auto").replace("'", "")
            tutupAliran()
            try { jalankan(a, "shell:pkill -f '$POLA'") } catch (_: Throwable) {}
            try { jalankan(a, "shell:rm -f $LOG $STATE $CFG /data/local/tmp/pisahsuara.out") } catch (_: Throwable) {}
            // Server hidup selama aliran ADB ini terbuka (di perangkat ini proses yang dilepas dari aliran langsung
            // dimatikan, jadi aliran sengaja dibiarkan terbuka). Bila koneksi putus, penjaga memulai ulang.
            val s = a.openStream("shell:CLASSPATH=$apk exec app_process /system/bin com.novan.pisahsuara.Server '$h' '$b' '$k' '$LOG' '${versiApp(c)}' 2>/data/local/tmp/pisahsuara.out")
            aliranServer = s
            Thread {
                try {
                    val ins = s.openInputStream()
                    val buf = ByteArray(1024)
                    while (ins.read(buf) > 0) { /* buang */ }
                } catch (_: Throwable) {}
            }.start()
            var hasil = ""
            for (i in 0 until 24) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
                hasil = jalankan(a, "shell:cat $LOG 2>/dev/null").trim()
                if (hasil.contains("OK ") || hasil.contains("ERR")) break
            }
            val ok = hasil.lines().firstOrNull { it.startsWith("OK ") }
            val err = hasil.lines().firstOrNull { it.startsWith("ERR ") && !it.startsWith("ERR Server") }
            if (ok != null) ok.removePrefix("OK ")
            else if (err != null) "Gagal: " + err.removePrefix("ERR ")
            else {
                fun cmd(x: String) = try { jalankan(a, "shell:$x").trim() } catch (_: Throwable) { "?" }
                val jalan = cmd("pgrep -f '$POLA'")
                val keluar = cmd("cat /data/local/tmp/pisahsuara.out 2>&1")
                val lg = cmd("logcat -d -t 300 | grep -i -E 'pisahsuara|AndroidRuntime|app_process' | tail -n 6")
                val info = cmd("id -un; ls -l $apk 2>&1; ls /system/bin/app_process* 2>&1")
                "Server gagal. log=[${hasil.take(300)}] jalan=[${if (jalan.isEmpty()) "tidak" else "ya"}] " +
                    "keluaran=[${keluar.take(300)}] logcat=[${lg.takeLast(500)}] info=[${info.take(300)}]"
            }
        } catch (e: Throwable) {
            "Gagal lewat ADB: ${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
