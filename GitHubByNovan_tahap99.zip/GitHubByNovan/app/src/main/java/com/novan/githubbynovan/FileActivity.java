package com.novan.githubbynovan;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import org.json.JSONObject;

public class FileActivity extends BaseActivity {
    private static final int REQ_EDIT = 9;
    private static final int REQ_RIWAYAT = 10;
    private static final long MAX_EDIT = 1024 * 1024;

    private Ui ui;
    private String full, path, name, sha, html, raw, token;
    private long size;
    private boolean busy;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        Intent i = getIntent();
        full = i.getStringExtra("repo");
        path = i.getStringExtra("path");
        name = i.getStringExtra("name");
        sha = i.getStringExtra("sha");
        html = i.getStringExtra("html");
        raw = i.getStringExtra("raw");
        size = i.getLongExtra("size", 0);
        render();
    }

    private void render() {
        ui = new Ui(this, "Berkas: " + name);
        ui.label("Lokasi: " + path + "\nUkuran: " + Ui.size(size));
        ui.button("1. Unduh berkas", v -> download());
        ui.button("2. Edit isi berkas", v -> edit());
        ui.button("3. Ganti nama berkas", v -> rename());
        ui.button("4. Riwayat berkas (lihat dan kembalikan versi lama)", v -> riwayat());
        ui.button("5. Salin tautan raw", v -> Ui.copy(this, "Tautan raw", raw));
        ui.button("6. Salin tautan web", v -> Ui.copy(this, "Tautan web", html));
        ui.button("7. Bagikan tautan raw", v -> Ui.share(this, "Berkas: " + name, raw));
        ui.button("8. Hapus berkas", Ui.DANGER, v -> delete());
        ui.button("Kembali", v -> finish());
    }

    private void download() {
        if (busy) return;
        withStorage(() -> {
            busy = true;
            ui.say("Mulai mengunduh " + name + "...");
            Saver.save(this, full, path, token, name, false, new Saver.Listener() {
                @Override public void progress(long b) { ui.progress("Mengunduh: " + Ui.size(b)); }
                @Override public void done(boolean ok, String m) { busy = false; ui.say(m); }
            });
        });
    }

    private void riwayat() {
        startActivityForResult(new Intent(this, RiwayatActivity.class)
                .putExtra("repo", full).putExtra("path", path).putExtra("name", name)
                .putExtra("berkas", true), REQ_RIWAYAT);
    }

    private void edit() {
        if (size > MAX_EDIT) {
            ui.say("Berkas lebih dari 1 MB, terlalu besar untuk diedit. Gunakan unduh.");
            return;
        }
        startActivityForResult(new Intent(this, EditActivity.class)
                .putExtra("repo", full).putExtra("path", path)
                .putExtra("sha", sha).putExtra("new", false), REQ_EDIT);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if ((req == REQ_EDIT || req == REQ_RIWAYAT) && res == RESULT_OK && data != null) {
            String n = data.getStringExtra("sha");
            if (n != null && !n.isEmpty()) sha = n;
        }
    }

    private String url(String p) {
        return Api.BASE + "/repos/" + full + "/contents/" + Api.enc(p);
    }

    private void rename() {
        ui.prompt("Ganti nama berkas", "Nama baru", name, n -> {
            if (n.isEmpty() || n.equals(name) || n.contains("/")) {
                if (n.contains("/")) ui.say("Nama berkas tidak boleh mengandung garis miring.");
                return;
            }
            final int cut = path.lastIndexOf('/');
            final String newPath = (cut >= 0 ? path.substring(0, cut + 1) : "") + n;
            ui.say("Mengganti nama...");
            Api.request("GET", Api.BASE + "/repos/" + full + "/git/blobs/" + sha, token, null, (ok, res) -> {
                if (!ok) { ui.say("Gagal membaca berkas: " + res); return; }
                String content = Api.parse(res).optString("content", "").replace("\n", "");
                String body = Api.o("message", "Ganti nama " + name + " menjadi " + n,
                        "content", content).toString();
                Api.request("PUT", url(newPath), token, body, (ok2, res2) -> {
                    if (!ok2) { ui.say("Gagal membuat berkas baru: " + res2); return; }
                    String del = Api.o("message", "Hapus " + name + " (diganti nama)", "sha", sha).toString();
                    Api.request("DELETE", url(path), token, del, (ok3, res3) -> {
                        if (!ok3) { ui.say("Berkas baru dibuat, tetapi gagal menghapus yang lama: " + res3); return; }
                        ui.say("Nama berkas diganti menjadi " + n + ".");
                        finish();
                    });
                });
            });
        });
    }

    private void delete() {
        ui.confirm("Hapus berkas?", "Hapus " + name + " dari repositori?", "hapus berkas", () ->
                Api.request("DELETE", url(path), token,
                        Api.o("message", "Hapus " + name, "sha", sha).toString(), (ok, res) -> {
                            if (!ok) { ui.say("Gagal: " + res); return; }
                            ui.say("Berkas dihapus.");
                            finish();
                        }));
    }
}
