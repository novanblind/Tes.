package com.novan.githubbynovan;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public class RepoActivity extends BaseActivity {
    public static Intent of(Context c, JSONObject r) {
        return new Intent(c, RepoActivity.class)
                .putExtra("full", r.optString("full_name", ""))
                .putExtra("name", r.optString("name", ""))
                .putExtra("private", r.optBoolean("private", false))
                .putExtra("html", r.optString("html_url", ""));
    }

    private static final int REQ_PICK = 21;
    private static final int REQ_RILIS = 22;
    private static final long MAX_UPLOAD = UnggahBesar.MAX;

    private Ui ui;
    private String full, name, html, token;
    private boolean priv, busy;
    private UnggahService.Listener unggahListener;
    private boolean tampilUnggah;
    private final long[] baseline = {0};
    private String rTag = "", rJudul = "", rCatatan = "", rNama = "";
    private boolean rPra, rDraf, rAuto, rTerbaru = true;
    private String rTarget = "";
    private RilisService.Listener rilisListener;
    private boolean tampilRilis, tampilForm;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        Intent i = getIntent();
        full = i.getStringExtra("full");
        name = i.getStringExtra("name");
        html = i.getStringExtra("html");
        priv = i.getBooleanExtra("private", false);
        render();
        String tagAwal = i.getStringExtra("rilisTag");
        if (tagAwal != null && !tagAwal.isEmpty() && !RilisService.busy()) {
            rTag = tagAwal;
            rilisFormulir();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (RilisService.untuk(full)) {
            sambungRilis();
            return;
        } else if (RilisService.hasPending()) {
            selesaiRilis();
            return;
        }
        if (UnggahService.untuk(full)) {
            sambungUnggah();
        } else if (tampilUnggah) {
            tampilUnggah = false;
            render();
        }
    }

    @Override
    protected void onPause() {
        lepasUnggah();
        lepasRilis();
        super.onPause();
    }

    private void render() {
        tampilForm = false;
        ui = new Ui(this, "Repo: " + name);
        ui.label("Status: " + (priv ? "privat" : "publik") + "\nNama lengkap: " + full);
        final Runnable back = () -> { };
        ui.button("1. Buka berkas", v -> startActivity(new Intent(this, BrowseActivity.class)
                .putExtra("repo", full).putExtra("path", "").putExtra("name", name)));
        ui.button("2. Tambah berkas (ketik teks)", v -> startActivity(
                new Intent(this, AddFileActivity.class).putExtra("repo", full)));
        ui.button("3. Unggah berkas dari HP", v -> pickFile());
        ui.button("4. Bangun APK dari repo ini", v -> TandaTanganRepo.mulai(this, full, token, back));
        ui.button("5. Cek status pembangunan APK", v -> ApkTools.cekStatus(this, full, token, back));
        ui.button("6. Riwayat pembangunan (batalkan, jalankan ulang)", v -> ApkTools.riwayat(this, full, token, back));
        ui.button("7. Unduh APK terbaru", v -> ApkTools.ambilApk(this, full, token, back));
        ui.button("8. Lihat workflow dan log", v -> ApkTools.workflowLog(this, full, token, back));
        ui.button("9. Hapus artefak (kosongkan kuota penyimpanan)", v -> ApkTools.hapusArtefak(this, full, token, back));
        ui.button("10. Lindungi dari tanda tangan ulang", v -> LindungiRepo.mulai(this, full, token, back));
        ui.button("11. Kunci terikat tanda tangan (lindungi data/fitur)", v -> LindungiKunci.mulai(this, full, token, back));
        ui.button("12. Buat rilis (Releases) dan unggah APK", v -> rilisFormulir());
        ui.button("13. Daftar rilis dan hapus rilis", v -> startActivity(RilisDaftarActivity.of(this, full, name).putExtra("private", priv)));
        ui.button("14. Riwayat commit (lihat dan kembalikan versi lama)", v -> startActivity(
                new Intent(this, RiwayatActivity.class).putExtra("repo", full).putExtra("path", "")
                        .putExtra("name", name)));
        ui.button("15. Secrets dan Variables (rahasia dan nilai untuk build)", v -> startActivity(
                new Intent(this, RahasiaActivity.class).putExtra("repo", full)));
        ui.button("16. Info repositori (deskripsi, topik, tautan situs, arsip)", v -> startActivity(
                new Intent(this, InfoRepoActivity.class).putExtra("repo", full)));
        ui.button("17. Unduh repositori sebagai ZIP", v -> downloadZip());
        ui.button("18. Ubah status privasi (saat ini " + (priv ? "privat" : "publik") + ")", v -> togglePrivacy());
        ui.button("19. Ganti nama repositori", v -> rename());
        ui.button("20. Salin tautan repositori", v -> Ui.copy(this, "Tautan repositori", html));
        ui.button("21. Bagikan tautan repositori", v -> Ui.share(this, "Repo: " + name, html));
        ui.button("22. Situs web (GitHub Pages) repo ini", v -> startActivity(
                new Intent(this, SitusActivity.class).putExtra("repo", full)));
        ui.button("23. Buka di browser", v -> Ui.browse(this, html));
        ui.button("24. Hapus repositori", Ui.DANGER, v -> delete());
        ui.button("Kembali", v -> finish());
    }

    private void pickFile() {
        try {
            startActivityForResult(MultiUnggah.pemilih(), REQ_PICK);
        } catch (Exception e) {
            ui.say("Pemilih berkas tidak tersedia di HP ini: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_RILIS && res == RESULT_OK && data != null) {
            List<Uri> pilih = MultiUnggah.ambil(data);
            if (!pilih.isEmpty()) rilisKonfirmasi(pilih);
            return;
        }
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        List<Uri> uris = MultiUnggah.ambil(data);
        if (uris.isEmpty()) {
            ui.say("Tidak ada berkas yang dipilih.");
        } else if (uris.size() == 1) {
            askUploadName(uris.get(0));
        } else {
            unggahBanyak(uris);
        }
    }

    private void unggahBanyak(final List<Uri> uris) {
        if (busy || UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        ui.askCheck("Unggah " + uris.size() + " berkas",
                "Diunggah ke repo " + full + ". Berkas bernama sama akan diganti. "
                        + "Berjalan di latar belakang, boleh pindah aplikasi. "
                        + "Bila kotak di bawah dicentang, APK dibangun sekali setelah semua berhasil.",
                "Folder tujuan (kosong = folder utama):", "",
                "Setelah berhasil, langsung bangun APK dan pantau", Store.autoBangun(this), "unggah semua", (t, auto) -> {
                    final String folder = MultiUnggah.rapikanFolder(t);
                    Store.setAutoBangun(this, auto);
                    busy = true;
                    ui.progress("Menyiapkan unggahan...");
                    ApkTools.baselineRun(full, token, () -> mulaiUnggah(uris, folder, null, auto), baseline);
                });
    }

    /** Menyerahkan unggahan ke layanan latar depan, lalu menampilkan kemajuannya di layar ini. */
    private void mulaiUnggah(List<Uri> uris, String folder, String jalurTunggal, boolean auto) {
        busy = false;
        ApkTools.askNotif(this);
        if (!UnggahService.start(this, full, token, folder, uris, jalurTunggal, baseline[0], auto)) {
            render();
            ui.say("Unggahan belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.");
            return;
        }
        if (UnggahService.lastText.isEmpty()) {
            UnggahService.lastText = jalurTunggal != null ? "Mulai mengunggah " + jalurTunggal + "..."
                    : "Mulai mengunggah " + uris.size() + " berkas...";
        }
        sambungUnggah();
    }

    /** Menampilkan kemajuan unggahan yang sedang berjalan dan tombol batal; dipanggil juga saat kembali ke layar ini. */
    private void sambungUnggah() {
        lepasUnggah();
        render();
        tampilUnggah = true;
        String t = UnggahService.lastText;
        ui.progress(t.isEmpty() ? "Mengunggah..." : t);
        ui.label("Berjalan di latar belakang. Kemajuan dan tombol batal ada di notifikasi.");
        ui.button("Batalkan unggahan", Ui.DANGER, v -> {
            UnggahService.cancel(this);
            ui.say("Unggahan sedang dihentikan...");
        });
        final UnggahService.Listener[] self = new UnggahService.Listener[1];
        self[0] = new UnggahService.Listener() {
            @Override public void onStatus(String text) {
                if (!isFinishing()) ui.progress(text);
            }

            @Override public void onFinished() {
                if (UnggahService.listener == self[0]) UnggahService.listener = null;
                if (unggahListener == self[0]) unggahListener = null;
                if (!isFinishing() && !isDestroyed()) selesaiUnggah();
            }
        };
        unggahListener = self[0];
        UnggahService.listener = self[0];
        if (!UnggahService.busy()) self[0].onFinished();
    }

    private void lepasUnggah() {
        if (UnggahService.listener == unggahListener) UnggahService.listener = null;
        unggahListener = null;
    }

    private void selesaiUnggah() {
        tampilUnggah = false;
        render();
        UnggahService.Hasil r = UnggahService.takePending();
        if (r == null) {
            ui.say("Unggahan dihentikan.");
            return;
        }
        UnggahService.cancelResultNotification(this);
        MultiUnggah.Hasil h = r.h;
        if (r.tunggal) {
            ui.say(h.berhasil > 0 ? "Berkas berhasil diunggah." : h.dibatalkan ? "Unggahan dibatalkan." : "Gagal mengunggah berkas.");
        } else {
            ui.say("Unggahan selesai. Berhasil " + h.berhasil + " dari " + h.total + " berkas"
                    + (h.gagal.isEmpty() ? "." : ", gagal " + h.gagal.size() + "."));
        }
        ApkTools.hasilUnggah(this, r, this::render, this::pickFile);
    }

    private void askUploadName(final Uri uri) {
        String n = "berkas";
        long size = -1;
        try {
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (ni >= 0 && !c.isNull(ni)) n = c.getString(ni);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) { }
        if (size > MAX_UPLOAD) {
            ui.say("Berkas lebih dari 100 MB, terlalu besar untuk diunggah.");
            return;
        }
        final String fn = n;
        ui.askCheck("Unggah berkas terpilih", "Ukuran berkas: " + (size >= 0 ? Ui.size(size) : "tidak diketahui"),
                "Nama berkas di GitHub (boleh dengan folder):",
                fn, "Setelah berhasil, langsung bangun APK dan pantau", Store.autoBangun(this), "unggah berkas", (t, auto) -> {
                    Store.setAutoBangun(this, auto);
                    upload(uri, t.isEmpty() ? fn : t, auto);
                });
    }

    private void upload(final Uri uri, String rawTarget, final boolean auto) {
        final String target = rawTarget.replaceFirst("^/+", "");
        if (target.isEmpty()) {
            ui.say("Nama berkas tidak valid.");
            return;
        }
        if (busy || UnggahService.busy()) {
            ui.say("Masih ada unggahan yang berjalan. Mohon tunggu.");
            return;
        }
        busy = true;
        ui.progress("Menyiapkan unggahan...");
        ApkTools.baselineRun(full, token, () -> mulaiUnggah(Collections.singletonList(uri), "", target, auto), baseline);
    }

    // ---------- rilis (Releases) ----------

    /**
     * Formulir rilis berupa halaman penuh yang bisa digulir (bukan dialog), supaya saat keyboard tampil
     * pengguna pembaca layar tetap bisa menggeser sampai tombol paling bawah. Layar ikut mengecil
     * mengikuti keyboard (adjustResize di manifest).
     */
    private void rilisFormulir() {
        if (busy || UnggahService.busy() || RilisService.busy()) {
            ui.say("Masih ada unggahan atau rilis berjalan. Tunggu dulu.");
            return;
        }
        tampilForm = true;
        ui = new Ui(this, "Buat rilis di " + name);
        ui.label("Pilih satu atau banyak berkas (APK, ZIP, dan lain-lain), semuanya diunggah sebagai lampiran rilis. "
                + "Bila tag sudah ada, rilis dipakai (pilihan di bawah diabaikan) dan lampiran sama diganti. "
                + "Maksimal 2 GB. Isi formulir, lalu tekan Pilih berkas di bawah.");
        final EditText eTag = ui.edit("Nama tag (contoh: v15, tanpa spasi):", "v15", false, rTag);
        ui.button("Pilih atau usul nama tag", v -> pilihTag(eTag));
        final EditText eJudul = ui.edit("Judul rilis (kosong = sama dengan tag):", "", false, rJudul);
        final EditText eCatatan = ui.edit("Catatan rilis (boleh kosong):", "", true, rCatatan);
        eCatatan.setMinLines(3);
        final CheckBox cAuto = ui.check("Buat catatan rilis otomatis dari GitHub (ditambahkan setelah catatan Anda)", rAuto);
        final CheckBox cPra = ui.check("Pra-rilis", rPra);
        final CheckBox cDraf = ui.check("Draf (belum diterbitkan, hanya terlihat oleh pemilik)", rDraf);
        final CheckBox cTerbaru = ui.check("Jadikan rilis terbaru (tidak berlaku untuk draf dan pra-rilis)", rTerbaru);
        final EditText eTarget = ui.edit("Cabang atau commit sumber tag baru (kosong = cabang bawaan repo):", "main", false, rTarget);
        final EditText eNama = ui.edit("Nama berkas di rilis (hanya bila satu berkas; kosong = nama asli):",
                "", false, rNama);
        ui.button("Pilih berkas dan lanjut", v -> {
            rTag = eTag.getText().toString().trim();
            rJudul = eJudul.getText().toString().trim();
            rCatatan = eCatatan.getText().toString().trim();
            rNama = eNama.getText().toString().trim();
            rTarget = eTarget.getText().toString().trim();
            if (rTarget.matches(".*\\s.*")) {
                ui.say("Cabang atau commit tidak boleh memuat spasi.");
                eTarget.requestFocus();
                return;
            }
            rAuto = cAuto.isChecked();
            rPra = cPra.isChecked();
            rDraf = cDraf.isChecked();
            rTerbaru = cTerbaru.isChecked();
            if (rTag.isEmpty() || rTag.matches(".*\\s.*")) {
                ui.say("Nama tag wajib diisi dan tidak boleh memuat spasi.");
                eTag.requestFocus();
                return;
            }
            if (rNama.contains("/")) {
                ui.say("Nama berkas tidak boleh memuat garis miring.");
                eNama.requestFocus();
                return;
            }
            try {
                startActivityForResult(MultiUnggah.pemilih(), REQ_RILIS);
            } catch (Exception e) {
                ui.say("Pemilih berkas tidak tersedia di HP ini: " + e.getMessage());
            }
        });
        ui.button("Buat rilis tanpa berkas (hanya catatan)", v -> {
            rTag = eTag.getText().toString().trim();
            rJudul = eJudul.getText().toString().trim();
            rCatatan = eCatatan.getText().toString().trim();
            rTarget = eTarget.getText().toString().trim();
            rAuto = cAuto.isChecked();
            rPra = cPra.isChecked();
            rDraf = cDraf.isChecked();
            rTerbaru = cTerbaru.isChecked();
            if (rTag.isEmpty() || rTag.matches(".*\\s.*") || rTarget.matches(".*\\s.*")) {
                ui.say("Nama tag wajib diisi dan, juga cabang atau commit, tidak boleh memuat spasi.");
                return;
            }
            ui.confirm("Buat rilis tanpa berkas?", "Repositori: " + full + "\nTag: " + rTag
                    + (rDraf ? "\nStatus: draf" : rPra ? "\nStatus: pra-rilis" : "")
                    + "\n\nBerkas bisa ditambahkan nanti lewat Daftar rilis.", "buat rilis", () -> rilisTanpaBerkas());
        });
        ui.button("Batal", v -> {
            tampilForm = false;
            render();
        });
    }

    /** Naikkan angka terakhir pada tag: v1.57 jadi v1.58, v15 jadi v16. Null bila tidak ada angka. */
    private static String tagBerikutnya(String tag) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.*?)(\\d+)(\\D*)$").matcher(tag);
        if (!m.matches()) return null;
        try {
            return m.group(1) + (Long.parseLong(m.group(2)) + 1) + m.group(3);
        } catch (Exception e) {
            return null;
        }
    }

    private void pilihTag(final EditText eTag) {
        ui.progress("Memuat tag...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/releases?per_page=1", token, null, (ok1, res1) -> {
            if (isFinishing() || isDestroyed()) return;
            String terakhir = "";
            if (ok1) {
                org.json.JSONArray ra = Api.parseArr(res1);
                if (ra.length() > 0) terakhir = Api.str(ra.optJSONObject(0), "tag_name");
            }
            final String usul = terakhir.isEmpty() ? null : tagBerikutnya(terakhir);
            final String tLast = terakhir;
            Api.request("GET", Api.BASE + "/repos/" + full + "/tags?per_page=50", token, null, (ok2, res2) -> {
                if (isFinishing() || isDestroyed()) return;
                final List<String> nama = new ArrayList<>();
                final List<String> isi = new ArrayList<>();
                if (usul != null) {
                    nama.add("Usul tag berikutnya: " + usul + " (rilis terakhir " + tLast + ")");
                    isi.add(usul);
                }
                if (ok2) {
                    org.json.JSONArray ta = Api.parseArr(res2);
                    for (int i = 0; i < ta.length(); i++) {
                        String t = Api.str(ta.optJSONObject(i), "name");
                        if (t.isEmpty()) continue;
                        nama.add("Tag yang ada: " + t + " (rilis dipakai ulang, berkas ditambahkan)");
                        isi.add(t);
                    }
                }
                if (nama.isEmpty()) {
                    ui.say("Belum ada tag atau rilis di repositori ini. Ketik nama tag sendiri.");
                    return;
                }
                ui.say(nama.size() + " pilihan tag.");
                AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Pilih tag")
                        .setItems(nama.toArray(new String[0]), (d, w) -> {
                            eTag.setText(isi.get(w));
                            ui.say("Tag diisi " + isi.get(w) + ".");
                        })
                        .setNegativeButton("batal", null);
                ui.fix(b.show());
            });
        });
    }

    private void rilisTanpaBerkas() {
        boolean biasa = !rPra && !rDraf;
        org.json.JSONObject body = Api.o("tag_name", rTag, "name", rJudul.isEmpty() ? rTag : rJudul, "body", rCatatan,
                "draft", rDraf, "prerelease", rPra, "make_latest", (biasa && rTerbaru) ? "true" : "false");
        try {
            if (rAuto) body.put("generate_notes", true);
            if (!rTarget.isEmpty()) body.put("target_commitish", rTarget);
        } catch (Exception ignored) { }
        ui.progress("Membuat rilis " + rTag + "...");
        Api.request("POST", Api.BASE + "/repos/" + full + "/releases", token, body.toString(), (ok, res) -> {
            if (isFinishing() || isDestroyed()) return;
            if (!ok) {
                String h = res.contains("422") ? "\n(Tag mungkin sudah punya rilis, atau cabang atau commit tidak ada, atau repo belum punya komit.)" : "";
                ui.say("Gagal membuat rilis. " + res + h);
                return;
            }
            String u = Api.str(Api.parse(res), "html_url");
            tampilForm = false;
            render();
            ui.say("Rilis " + rTag + " dibuat.");
            ui.confirm("Rilis berhasil", "Rilis " + rTag + " dibuat tanpa berkas.\n\nHalaman rilis:\n" + u,
                    "salin tautan", () -> Ui.copy(this, "Tautan rilis", u));
        });
    }

    @Override
    public void onBackPressed() {
        // Di formulir rilis, Kembali menutup formulir (kembali ke menu repositori), bukan layar repositori.
        if (tampilForm) {
            tampilForm = false;
            render();
            return;
        }
        super.onBackPressed();
    }

    private void rilisKonfirmasi(final List<Uri> uris) {
        final List<String> namas = new ArrayList<>();
        StringBuilder daftar = new StringBuilder();
        long total = 0;
        for (Uri uri : uris) {
            String n = "berkas" + (namas.size() + 1);
            long size = -1;
            try {
                Cursor c = getContentResolver().query(uri, null, null, null, null);
                if (c != null) {
                    try {
                        if (c.moveToFirst()) {
                            int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (ni >= 0 && !c.isNull(ni)) n = c.getString(ni);
                            int si = c.getColumnIndex(OpenableColumns.SIZE);
                            if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                        }
                    } finally { c.close(); }
                }
            } catch (Exception ignored) { }
            // Nama khusus hanya berlaku bila satu berkas yang dipilih.
            if (uris.size() == 1 && !rNama.isEmpty()) n = rNama;
            namas.add(n);
            if (size > 0) total += size;
            daftar.append("\n- ").append(n).append(size >= 0 ? " (" + Ui.size(size) + ")" : "");
        }
        for (int a1 = 0; a1 < namas.size(); a1++)
            for (int b1 = a1 + 1; b1 < namas.size(); b1++)
                if (namas.get(a1).equals(namas.get(b1))) {
                    ui.say("Ada dua berkas bernama sama (" + namas.get(a1) + "). Pilih ulang tanpa berkas kembar.");
                    return;
                }
        ui.confirm("Buat rilis dan unggah?",
                "Repositori: " + full + "\nTag: " + rTag + "\nJudul: " + (rJudul.isEmpty() ? rTag : rJudul)
                        + (rDraf ? "\nStatus: draf" : rPra ? "\nStatus: pra-rilis" : "") + (rAuto ? "\nCatatan otomatis: ya" : "")
                        + "\nBerkas: " + uris.size() + (total > 0 ? " (total " + Ui.size(total) + ")" : "") + daftar
                        + (uris.size() > 1 && !rNama.isEmpty() ? "\n\nNama berkas khusus diabaikan karena berkas lebih dari satu." : "")
                        + (priv ? "\n\nRepo privat, jadi rilis tidak bisa diunduh publik." : ""),
                "buat rilis", () -> {
                    ApkTools.askNotif(this);
                    RilisService.pilihan(rPra, rDraf, rAuto, rTerbaru);
                    RilisService.optTarget = rTarget;
                    if (!RilisService.startBanyak(this, full, token, rTag, rJudul, rCatatan, namas, uris)) {
                        ui.say("Rilis belum bisa dimulai. Buka aplikasi di layar depan, lalu coba lagi.");
                        return;
                    }
                    RilisService.lastText = "Mulai membuat rilis " + rTag + "...";
                    sambungRilis();
                });
    }

    private void sambungRilis() {
        lepasRilis();
        render();
        tampilRilis = true;
        String t = RilisService.lastText;
        ui.progress(t.isEmpty() ? "Membuat rilis..." : t);
        ui.label("Berjalan di latar belakang. Kemajuan dan tombol batal ada di notifikasi.");
        ui.button("Batalkan rilis", Ui.DANGER, v -> {
            RilisService.cancel(this);
            ui.say("Rilis sedang dihentikan...");
        });
        final RilisService.Listener[] self = new RilisService.Listener[1];
        self[0] = new RilisService.Listener() {
            @Override public void onStatus(String text) {
                if (!isFinishing()) ui.progress(text);
            }

            @Override public void onFinished() {
                if (RilisService.listener == self[0]) RilisService.listener = null;
                if (rilisListener == self[0]) rilisListener = null;
                if (!isFinishing() && !isDestroyed()) selesaiRilis();
            }
        };
        rilisListener = self[0];
        RilisService.listener = self[0];
        if (!RilisService.busy()) self[0].onFinished();
    }

    private void lepasRilis() {
        if (RilisService.listener == rilisListener) RilisService.listener = null;
        rilisListener = null;
    }

    private void selesaiRilis() {
        tampilRilis = false;
        render();
        final RilisService.Hasil h = RilisService.takePending();
        if (h == null) {
            ui.say("Rilis dihentikan.");
            return;
        }
        RilisService.cancelResultNotification(this);
        ui.say(h.pesan);
        if (h.ok) {
            ui.confirm("Rilis berhasil",
                    h.pesan + "\n\nTautan unduh langsung (versi ini):\n" + h.urlTag
                            + "\n\nTautan selalu-terbaru:\n" + h.urlTerbaru
                            + "\n\nHalaman rilis:\n" + h.urlRilis,
                    "salin tautan unduh", () -> Ui.copy(this, "Tautan unduh", h.urlTag));
        }
    }

    private void downloadZip() {
        if (busy) return;
        withStorage(() -> {
            busy = true;
            ui.say("Mulai mengunduh repositori sebagai ZIP...");
            Saver.save(this, full, "", token, name + ".zip", true, new Saver.Listener() {
                @Override public void progress(long b) { ui.progress("Mengunduh: " + Ui.size(b)); }
                @Override public void done(boolean ok, String m) { busy = false; ui.say(m); }
            });
        });
    }

    private void togglePrivacy() {
        final boolean target = !priv;
        if (target) { // dijadikan privat: tidak perlu pemeriksaan
            konfirmasiPrivasi(true);
            return;
        }
        // Mau dijadikan publik: periksa dulu apakah repo berisi kunci tanda tangan pribadi.
        Api.request("GET", Api.BASE + "/repos/" + full + "/contents/" + TandaTanganRepo.KS_PATH, token, null,
                (ok, res) -> runOnUiThread(() -> {
                    if (ok) {
                        ui.confirm("Awas: ada kunci tanda tangan pribadi",
                                "Repo " + name + " berisi keystore dan sandi tanda tangan pribadi di folder "
                                        + ".tanda-tangan. Bila dijadikan publik, siapa pun bisa mengambilnya dan "
                                        + "menandatangani APK atas nama Anda.\n\nMenghapus folder itu tidak cukup "
                                        + "karena tetap ada di riwayat repo. Kunci ini harus dianggap bocor dan "
                                        + "diganti dengan tanda tangan baru.\n\nDisarankan batal.",
                                "tetap jadikan publik", () -> ubahPrivasi(false));
                    } else {
                        konfirmasiPrivasi(false);
                    }
                }));
    }

    private void konfirmasiPrivasi(final boolean target) {
        // target: true = privat, false = publik (nilai untuk kolom "private")
        ui.confirm("Ubah privasi?", "Jadikan repositori " + name + (target ? " privat?" : " publik?"),
                "ubah", () -> ubahPrivasi(target));
    }

    private void ubahPrivasi(final boolean target) {
        Api.request("PATCH", Api.BASE + "/repos/" + full, token,
                Api.o("private", target).toString(), (ok, res) -> runOnUiThread(() -> {
                    if (!ok) {
                        ui.say("Gagal: " + res);
                        return;
                    }
                    ReposActivity.invalidate();
                    priv = target;
                    render();
                    ui.say("Repositori sekarang " + (priv ? "privat." : "publik."));
                }));
    }

    private void rename() {
        ui.prompt("Ganti nama repositori", "Nama baru", name, n -> {
            if (n.isEmpty() || n.equals(name)) return;
            Api.request("PATCH", Api.BASE + "/repos/" + full, token,
                    Api.o("name", n).toString(), (ok, res) -> runOnUiThread(() -> {
                        if (!ok) {
                            ui.say("Gagal: " + res);
                            return;
                        }
                        JSONObject r = Api.parse(res);
                        ReposActivity.invalidate();
                        full = r.optString("full_name", full);
                        name = r.optString("name", n);
                        html = r.optString("html_url", html);
                        render();
                        ui.say("Nama repositori diganti menjadi " + name + ".");
                    }));
        });
    }

    private void delete() {
        ui.confirm("Hapus repositori?", "Repositori " + full + " akan dihapus PERMANEN beserta seluruh isinya.",
                "hapus permanen", () -> Api.request("DELETE", Api.BASE + "/repos/" + full, token, null,
                        (ok, res) -> runOnUiThread(() -> {
                            if (!ok) {
                                String err = res;
                                if (err.contains("403") || err.contains("404")) {
                                    err += "\n(Perlu izin token 'delete_repo')";
                                }
                                ui.say("Gagal: " + err);
                                return;
                            }
                            ReposActivity.invalidate();
                            ui.say("Repositori dihapus.");
                            finish();
                        })));
    }
}
