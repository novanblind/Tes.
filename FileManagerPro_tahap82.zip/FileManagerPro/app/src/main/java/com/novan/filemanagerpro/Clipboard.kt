package com.novan.filemanagerpro

import java.io.File

/**
 * Papan klip internal untuk salin dan pindahkan. Isinya berkas biasa ([files]) atau
 * entri dari dalam zip ([zipArchive], [zipTops], [zipEntries]); keduanya tidak pernah terisi bersamaan.
 */
object Clipboard {
    var files: List<File> = emptyList()
        private set
    var cut: Boolean = false
        private set

    /** Zip asal bila yang disalin/dipindah adalah isi zip; null untuk berkas biasa. */
    var zipArchive: File? = null
        private set
    /** Jalur entri tingkat atas yang dipilih di dalam zip. */
    var zipTops: List<String> = emptyList()
        private set
    /** Semua entri (termasuk isi folder) di bawah [zipTops]. */
    var zipEntries: List<ArchiveOps.Edit> = emptyList()
        private set

    val isZip: Boolean get() = zipArchive != null

    /** Jumlah item di papan klip, baik berkas biasa maupun entri zip. */
    val size: Int get() = if (isZip) zipTops.size else files.size

    fun set(list: List<File>, isCut: Boolean) {
        files = list
        cut = isCut
        zipArchive = null
        zipTops = emptyList()
        zipEntries = emptyList()
    }

    fun setZip(archive: File, tops: List<String>, entries: List<ArchiveOps.Edit>, isCut: Boolean) {
        files = emptyList()
        cut = isCut
        zipArchive = archive
        zipTops = tops
        zipEntries = entries
    }

    fun clear() {
        files = emptyList()
        cut = false
        zipArchive = null
        zipTops = emptyList()
        zipEntries = emptyList()
    }
}
