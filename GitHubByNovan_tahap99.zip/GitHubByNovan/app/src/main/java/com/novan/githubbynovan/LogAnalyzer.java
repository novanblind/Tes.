package com.novan.githubbynovan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Menganalisis log pembangunan GitHub Actions (padanan PembuatAPK.analisisLog pada skrip Lua). */
public class LogAnalyzer {

    public static class Item {
        public String type, file = null, message;
        public Integer line = null, col = null;

        String format() {
            String loc = "";
            if (file != null) {
                loc = file;
                if (line != null) loc += " baris " + line;
                if (col != null) loc += " kolom " + col;
                loc += ": ";
            }
            return "[" + type + "] " + loc + message;
        }
    }

    public static class Result {
        public List<String> area = new ArrayList<>();
        public String task = null;
        public final List<Item> codeErrors = new ArrayList<>();
        public final List<String> otherErrors = new ArrayList<>();
        public final List<String> gradleBlock = new ArrayList<>();
        public final List<String> causes = new ArrayList<>();
    }

    // Setiap item: {kata kunci huruf kecil, penjelasan}
    static final String[][] CAUSES = {
        {"unresolved reference",
         "Ada nama (kelas, fungsi, variabel, atau R.xxx) yang tidak ditemukan. Cek salah ketik, import, pustaka, atau sumber daya di res."},
        {"type mismatch",
         "Tipe data tidak cocok dengan yang diminta fungsi atau variabel."},
        {"overrides nothing",
         "Fungsi override tidak ada di kelas induknya. Cek nama dan parameternya."},
        {"overload resolution ambiguity",
         "Ada beberapa fungsi yang cocok, kompiler tidak bisa memilih."},
        {"none of the following candidates",
         "Parameter pemanggilan fungsi salah (jumlah atau tipe)."},
        {"must be exhaustive",
         "Ekspresi when atau if belum mencakup semua kemungkinan. Tambahkan else."},
        {"val cannot be reassigned",
         "Nilai val diubah setelah diisi. Ganti val menjadi var."},
        {"expecting '",
         "Penulisan kode salah: kurang atau lebih tanda kurung, koma, atau kata kunci."},
        {"cannot find symbol",
         "Kode Java memakai nama yang tidak ditemukan."},
        {"was compiled with an incompatible version of kotlin",
         "Pustaka memakai Kotlin lebih baru. Naikkan versi plugin Kotlin atau pakai pustaka lama."},
        {"could not resolve",
         "Pustaka atau plugin tidak bisa diunduh. Cek nama, versi, dan daftar repositori di settings.gradle."},
        {"could not find ",
         "Pustaka, plugin, atau berkas tidak ditemukan. Cek nama, versi, dan repositori."},
        {"failed to find target with hash string",
         "Platform Android untuk compileSdk belum terpasang. Pasang di langkah SDK atau turunkan compileSdk."},
        {"licenses have not been accepted",
         "Lisensi Android SDK belum diterima."},
        {"failed to install the following",
         "Paket Android SDK gagal dipasang. Biasanya lisensi belum diterima atau nama salah."},
        {"sdk location not found",
         "Lokasi Android SDK tidak diketahui. Langkah pemasangan SDK mungkin gagal."},
        {"java heap space",
         "Memori Java habis. Naikkan org.gradle.jvmargs di gradle.properties."},
        {"outofmemoryerror",
         "Memori habis. Naikkan org.gradle.jvmargs di gradle.properties."},
        {"unsupported class file major version",
         "Versi Java tidak cocok dengan Gradle atau pustaka. Sesuaikan versi Java di workflow."},
        {"invalid source release",
         "Versi Java di workflow terlalu rendah. Naikkan di langkah pemasangan Java."},
        {"inconsistent jvm-target",
         "Target JVM Java dan Kotlin berbeda. Samakan sourceCompatibility, targetCompatibility, dan jvmTarget."},
        {"duplicate class",
         "Ada kelas ganda dari dua pustaka. Hapus salah satunya."},
        {"manifest merger failed",
         "Penggabungan AndroidManifest.xml gagal. Baca pesan di atasnya."},
        {"android:exported",
         "Komponen dengan intent-filter wajib memakai android:exported untuk target SDK 31 ke atas."},
        {"linking references failed",
         "Ada sumber daya yang dirujuk tapi tidak ada atau salah tulis di res atau AndroidManifest.xml."},
        {"error: resource",
         "Sumber daya yang dirujuk tidak ditemukan. Cek nama dan folder res."},
        {"minsdkversion",
         "minSdk proyek lebih kecil dari kebutuhan pustaka. Naikkan minSdk atau pakai pustaka lama."},
        {"cannot mutate the dependencies of configuration",
         "Versi Gradle terlalu baru untuk plugin Android. Pakai alur kerja terbaru aplikasi atau naikkan AGP ke 9.x."},
        {"minimum supported gradle version",
         "Versi Gradle terlalu rendah. Naikkan gradle-version di workflow."},
        {"script compilation error",
         "build.gradle atau settings.gradle salah tulis. Baca baris yang disebut."},
        {"could not get unknown property",
         "build.gradle memakai properti tidak dikenal. Cek ejaan atau versi plugin."},
        {"no signature of method",
         "build.gradle memanggil fungsi yang tidak ada di versi ini."},
        {"end-of-central-directory",
         "Berkas ZIP rusak atau tidak lengkap. Unggah ulang."},
        {"does not contain a gradle build",
         "settings.gradle atau build.gradle tidak ditemukan. Cek struktur folder repo."},
        {"berkas apk tidak ditemukan",
         "Build selesai tapi tidak ada APK. Cek tugas assembleDebug dan jalur keluaran."},
        {"unable to access jarfile",
         "gradle-wrapper.jar tidak ada atau gradlew hanya placeholder. Hapus gradlew dan gradle/wrapper, atau pakai alur kerja terbaru aplikasi."},
        {"permission denied",
         "Berkas tidak boleh dijalankan atau dibaca (misalnya gradlew tanpa izin eksekusi)."}
    };

    private static final String[] OTHER_WORDS = {
        "could not resolve", "could not find ", "caused by:", "duplicate class",
        "manifest merger failed", "license for package", "sdk location not found",
        "failed to install", "outofmemoryerror", "java heap space", "unsupported class file",
        "invalid source release", "no such file", "permission denied", "script compilation error",
        "could not get unknown property", "execution failed", "failed to find", "cannot find",
        "berkas apk tidak ditemukan", "error:", "unzip:", "end-of-central-directory",
    };

    private static final Pattern TS = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d+Z\\s?");
    private static final Pattern ANSI = Pattern.compile("\u001B\\[[\\d;]*[A-Za-z]");
    private static final Pattern K1 = Pattern.compile("^file:///(.*?\\.kts?):(\\d+):(\\d+)\\s+(.*)$");
    private static final Pattern K2 = Pattern.compile("^file:///(.*?\\.kts?):\\((\\d+), (\\d+)\\):\\s*(.*)$");
    private static final Pattern K3 = Pattern.compile("^(.*?\\.kts?):\\((\\d+), (\\d+)\\):\\s*(.*)$");
    private static final Pattern J1 = Pattern.compile("^(\\S+\\.java):(\\d+): error: (.*)$");
    private static final Pattern J2 = Pattern.compile("^\\S+\\.java:\\d+:.*");
    private static final Pattern TASK1 = Pattern.compile("^> Task (\\S+) FAILED.*");
    private static final Pattern TASK2 = Pattern.compile("Execution failed for task '([^']+)'");
    private static final Pattern RUNNER = Pattern.compile("^/?home/runner/work/[^/]+/[^/]+/");

    /** Buang cap waktu, kode warna, dan karakter CR dari satu baris log. */
    public static String clean(String b) {
        String c = TS.matcher(b).replaceFirst("");
        c = ANSI.matcher(c).replaceAll("");
        return c.replace("\r", "");
    }

    static String trim(String s) { return s.replaceAll("^\\s+", "").replaceAll("\\s+$", ""); }

    /** Jalur di mesin GitHub menjadi jalur relatif di dalam repo. */
    static String shortPath(String p) {
        if (p.startsWith("file:///")) p = "/" + p.substring(8);
        return RUNNER.matcher(p).replaceFirst("");
    }

    public static Result analyze(List<String> raw) {
        List<String> b = new ArrayList<>(raw.size());
        for (String s : raw) b.add(clean(s));

        int err = -1;
        for (int i = 0; i < b.size(); i++) {
            if (b.get(i).startsWith("##[error]")) { err = i; break; }
        }
        int start = 0;
        if (err >= 0) {
            for (int i = err; i >= 0; i--) {
                if (b.get(i).startsWith("##[group]Run ")) { start = i; break; }
            }
        }
        int end = err >= 0 ? err : b.size() - 1;
        Result r = new Result();
        for (int i = start; i <= end && i < b.size(); i++) r.area.add(b.get(i));

        Set<String> seen = new HashSet<>();
        List<String> w = r.area;
        int n = w.size();
        int i = 0;
        while (i < n) {
            String l = w.get(i);
            String lower = l.toLowerCase(Locale.ROOT);
            if (l.startsWith("e: ")) {
                String rest = l.substring(3);
                Item it = new Item();
                it.type = "Kotlin";
                Matcher m = K1.matcher(rest);
                if (!m.matches()) m = K2.matcher(rest);
                if (!m.matches()) m = K3.matcher(rest);
                if (m.matches()) {
                    it.file = shortPath(m.group(1));
                    it.line = Integer.valueOf(m.group(2));
                    it.col = Integer.valueOf(m.group(3));
                    it.message = m.group(4);
                } else {
                    it.message = trim(rest);
                }
                String key = it.file + "|" + it.line + "|" + it.col + "|" + it.message;
                if (seen.add(key) && r.codeErrors.size() < 300) r.codeErrors.add(it);
            } else {
                Matcher jm = J1.matcher(l);
                if (jm.matches()) {
                    String msg = jm.group(3);
                    String s1 = i + 1 < n ? w.get(i + 1) : null;
                    String s2 = i + 2 < n ? w.get(i + 2) : null;
                    if (s1 != null && !s1.isEmpty() && !J2.matcher(s1).matches()) {
                        msg += "  |  " + trim(s1);
                        if (s2 != null && s2.matches("^\\s*\\^.*")) i++;
                        i++;
                    }
                    Item it = new Item();
                    it.type = "Java";
                    it.file = shortPath(jm.group(1));
                    it.line = Integer.valueOf(jm.group(2));
                    it.message = msg;
                    String key = it.file + "|" + it.line + "|" + it.message;
                    if (seen.add(key) && r.codeErrors.size() < 300) r.codeErrors.add(it);
                } else {
                    Matcher t1 = TASK1.matcher(l);
                    if (t1.matches()) r.task = t1.group(1);
                    Matcher t2 = TASK2.matcher(l);
                    if (t2.find() && r.task == null) r.task = t2.group(1);

                    if (l.contains("* What went wrong:")) {
                        int k = i + 1, counted = 0;
                        while (k < n && counted < 25) {
                            String x = w.get(k);
                            if (x.startsWith("* Try:") || x.startsWith("* Exception")
                                    || x.startsWith("* Get more help")) break;
                            if (!trim(x).isEmpty()) {
                                r.gradleBlock.add(x);
                                counted++;
                            }
                            k++;
                        }
                    } else if (!l.startsWith("##[error]Process completed") && !l.startsWith("w: ")) {
                        for (String word : OTHER_WORDS) {
                            if (lower.contains(word)) {
                                String text = shortPath(trim(l));
                                if (!text.isEmpty() && seen.add("L|" + text) && r.otherErrors.size() < 60) {
                                    r.otherErrors.add(text);
                                }
                                break;
                            }
                        }
                    }
                }
            }
            i++;
        }

        // Buang baris "lain" yang sudah tampil di blok pesan Gradle.
        Set<String> inBlock = new HashSet<>();
        for (String x : r.gradleBlock) inBlock.add(trim(x));
        List<String> rest = new ArrayList<>();
        for (String x : r.otherErrors) if (!inBlock.contains(x)) rest.add(x);
        r.otherErrors.clear();
        r.otherErrors.addAll(rest);

        // Penjelasan penyebab berdasarkan isi langkah yang gagal.
        String lowAll = String.join("\n", w).toLowerCase(Locale.ROOT);
        Set<String> done = new HashSet<>();
        for (String[] p : CAUSES) {
            if (lowAll.contains(p[0]) && !done.contains(p[1]) && r.causes.size() < 6) {
                done.add(p[1]);
                r.causes.add(p[1]);
            }
        }
        return r;
    }

    /** Teks laporan. {@code limit} = jumlah maksimum kesalahan kode yang ditampilkan (-1 = semua). */
    public static String report(Result a, String header, int limit) {
        List<String> t = new ArrayList<>();
        t.add(header);
        t.add("");
        if (a.task != null) t.add("Tugas Gradle yang gagal: " + a.task);
        t.add("Jumlah kesalahan kode: " + a.codeErrors.size());

        if (!a.codeErrors.isEmpty()) {
            t.add("");
            t.add("PENYEBAB UTAMA (kesalahan di kode)");
            int show = a.codeErrors.size();
            if (limit >= 0 && show > limit) show = limit;
            for (int k = 0; k < show; k++) t.add((k + 1) + ". " + a.codeErrors.get(k).format());
            if (show < a.codeErrors.size()) {
                t.add("(Hanya " + show + " dari " + a.codeErrors.size() + " kesalahan yang ditampilkan di sini. "
                        + "Tekan \"salin semua kesalahan\" untuk daftar lengkap.)");
            }
        }
        if (!a.causes.isEmpty()) {
            t.add("");
            t.add("ARTINYA");
            for (String p : a.causes) t.add("- " + p);
        }
        if (!a.gradleBlock.isEmpty()) {
            t.add("");
            t.add("PESAN DARI GRADLE");
            t.addAll(a.gradleBlock);
        }
        if (!a.otherErrors.isEmpty()) {
            t.add("");
            t.add("BARIS KESALAHAN LAIN DI LOG");
            int max = a.otherErrors.size();
            if (limit >= 0 && max > 12) max = 12;
            for (int k = 0; k < max; k++) t.add("- " + a.otherErrors.get(k));
            if (max < a.otherErrors.size()) {
                t.add("(" + (a.otherErrors.size() - max) + " baris lain ada di \"salin semua kesalahan\".)");
            }
        }
        boolean found = !a.codeErrors.isEmpty() || !a.otherErrors.isEmpty() || !a.gradleBlock.isEmpty();
        int last = found ? 12 : 40;
        t.add("");
        if (found) {
            t.add("BARIS TERAKHIR LANGKAH YANG GAGAL");
        } else {
            t.add("Kesalahan tidak dikenali otomatis. " + last
                    + " baris terakhir langkah yang gagal:");
        }
        List<String> collect = new ArrayList<>();
        for (int k = a.area.size() - 1; k >= 0; k--) {
            if (!trim(a.area.get(k)).isEmpty()) {
                collect.add(0, a.area.get(k));
                if (collect.size() >= last) break;
            }
        }
        t.addAll(collect);
        return String.join("\n", t);
    }

    /** Kalimat singkat untuk dibacakan pembaca layar. */
    public static String spoken(Result a, String stepName) {
        String s = "Langkah gagal: " + stepName + ". ";
        if (!a.codeErrors.isEmpty()) {
            Item g = a.codeErrors.get(0);
            s += "Ditemukan " + a.codeErrors.size() + " kesalahan kode. Yang pertama: ";
            if (g.file != null) {
                s += "berkas " + g.file;
                if (g.line != null) s += " baris " + g.line;
                s += ". ";
            }
            s += g.message.replaceAll("\\.+$", "") + ". ";
        } else if (!a.causes.isEmpty()) {
            s += a.causes.get(0) + " ";
        } else if (!a.otherErrors.isEmpty()) {
            s += "Pesan: " + a.otherErrors.get(0) + ". ";
        } else {
            s += "Penyebab tidak dikenali. Log langkah gagal ditampilkan. ";
        }
        return s + "Rincian lengkap ada di bawah, bisa disalin.";
    }

    /** Ambil {@code count} baris terakhir (sudah dibersihkan), digabung dengan baris baru. */
    public static String tail(List<String> lines, int count) {
        StringBuilder sb = new StringBuilder();
        for (int q = Math.max(0, lines.size() - count); q < lines.size(); q++) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(clean(lines.get(q)));
        }
        return sb.toString();
    }
}
