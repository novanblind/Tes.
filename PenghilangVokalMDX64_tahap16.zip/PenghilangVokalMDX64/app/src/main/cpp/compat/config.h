/* config.h pengganti hasil ./configure LAME untuk Android (bionic, clang). */
#ifndef LAME_ANDROID_CONFIG_H
#define LAME_ANDROID_CONFIG_H

#define PACKAGE "lame"
#define VERSION "3.100"

#define STDC_HEADERS 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_MEMORY_H 1
#define HAVE_UNISTD_H 1
#define HAVE_LIMITS_H 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_FLOAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_STRCHR 1
#define HAVE_MEMCPY 1

#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_UNSIGNED_SHORT 2
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_LONG_LONG 8
#define SIZEOF_FLOAT 4
#define SIZEOF_DOUBLE 8
#ifdef __LP64__
#define SIZEOF_LONG 8
#define SIZEOF_UNSIGNED_LONG 8
#define SIZEOF_LONG_DOUBLE 16
#else
#define SIZEOF_LONG 4
#define SIZEOF_UNSIGNED_LONG 4
#define SIZEOF_LONG_DOUBLE 8
#endif

/* Tipe float IEEE754 yang biasanya dideteksi ./configure (dipakai util.h: fast_log2, dll). */
typedef float ieee754_float32_t;
typedef double ieee754_float64_t;

#endif
