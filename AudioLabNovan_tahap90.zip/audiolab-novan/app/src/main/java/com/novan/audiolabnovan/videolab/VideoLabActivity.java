package com.novan.audiolabnovan.videolab;

import com.novan.audiolabnovan.R;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.ui.PlayerView;

import androidx.appcompat.app.AlertDialog;
import androidx.media3.common.Effect;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.transformer.Effects;
import java.util.Collections;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;
import androidx.media3.effect.Brightness;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.HslAdjustment;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.RgbAdjustment;
import androidx.media3.effect.RgbFilter;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.effect.TextOverlay;
import androidx.media3.effect.TextureOverlay;
import com.google.common.collect.ImmutableList;
import android.content.Intent;
import android.text.InputType;
import androidx.media3.transformer.AudioEncoderSettings;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.VideoEncoderSettings;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VideoLabActivity extends AppCompatActivity {

    private final List<Clip> clips = new ArrayList<>();
    private int selected = -1;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView info, message;
    private SeekBar seek;
    private Button btnPlay, btnExport, btnCancel;
    private LinearLayout clipList;
    private ProgressBar progress;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Transformer transformer;
    private File outFile;
    private boolean exporting = false;
    private boolean seeking = false;
    private int lastAnnounced = 0;
    private Button btnMute;
    private TextView musicInfo;
    private boolean pendingAudioOnly = false;
    private boolean exportAudioOnly = false;
    private Uri musicUri;
    private String musicName = "";
    private long musicDurMs = 0;
    private float musicVolume = 0.5f;
    private int ratioIndex = 0;
    private int resIndex = 0;
    private int qualIndex = 0;
    private boolean stabBusy = false;
    // pemulihan proyek saat aplikasi dibuka berjalan di latar belakang
    private volatile java.util.Map<String, Long> durCache = null;
    private boolean restorePending = false;
    private Intent deferredIntent = null;
    private static final String RESTORE_MSG = "Sedang memulihkan proyek terakhir. Tunggu sebentar.";
    private boolean subMode = false;          // ekspor audio khusus untuk dikenali Groq
    private boolean exportForSubs = false;
    private boolean subReplace = false;
    private long subSig = 0;
    private final List<long[]> subMap = new ArrayList<>();
    private static final String[] GROQ_MODELS = {"whisper-large-v3-turbo", "whisper-large-v3"};
    private static final String[] GROQ_MODEL_LABELS = {"Whisper large v3 turbo, cepat", "Whisper large v3, paling akurat"};
    private static final String[] LANG_CODES = {"id", "en", "ms", "jw", "su", "ar", ""};
    private static final String[] LANG_LABELS = {"Indonesia", "Inggris", "Melayu", "Jawa", "Sunda", "Arab", "Otomatis, kenali sendiri"};
    private int targetMb = 0; // batas ukuran file hasil, 0 = tanpa batas
    private int transIndex = 0;
    private final List<SubtitleItem> subs = new ArrayList<>();
    private TextView exportInfo;
    private final List<OverlayItem> overlays = new ArrayList<>();
    private LinearLayout overlayList;
    private final List<ImageItem> images = new ArrayList<>();
    private LinearLayout imageList;
    private boolean fadeWhite = false;
    private final ActivityResultLauncher<String[]> pickPhotos =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPhotosPicked);
    private long pendingImgStartMs = 0;
    private final java.util.HashMap<String, Bitmap> imgCache = new java.util.HashMap<>();
    private final ActivityResultLauncher<String[]> pickImage =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onImagePicked);
    private LinearLayout subList;
    private TextView ratioInfo;
    private TextView subStyleInfo;
    private Button btnRecord;
    // gaya subtitle (berlaku untuk semua subtitle)
    private int subSize = 1;
    private int subPos = 2;
    private int subColor = 0;
    private boolean subBg = true;
    private int codecIndex = 0;
    // musik latar tambahan
    private long musicStartMs = 0;
    private long musicFadeInMs = 0;
    private long musicFadeOutMs = 0;
    private int duckLevel = 0;            // 0 mati, 1 ringan, 2 sedang, 3 kuat
    private int duckSens = 0;             // tahap 51: kepekaan deteksi bicara: 0 normal, 1 tinggi, 2 sangat tinggi
    private int duckRel = 1;              // tahap 51: kecepatan musik naik lagi: 0 cepat, 1 sedang, 2 pelan
    private static final String[] DUCK_SENS_LABELS = {"Normal", "Tinggi, suara pelan ikut terdeteksi",
            "Sangat tinggi, derau ruangan bisa ikut menekan musik"};
    private static final String[] DUCK_REL_LABELS = {"Cepat, musik naik lagi sekitar 0,1 detik sesudah bicara berhenti",
            "Sedang, sekitar 0,4 detik", "Pelan, sekitar 1 detik"};
    private long[][] duckSegs = null;
    private boolean duckReady = false;
    private boolean duckBusy = false;
    private static final float[] DUCK_GAIN = {1f, 0.5f, 0.25f, 0.1f};
    private static final String[] DUCK_LABELS = {"Mati, musik tetap", "Ringan, musik turun ke 50 persen",
            "Sedang, musik turun ke 25 persen", "Kuat, musik turun ke 10 persen"};
    // urungkan / ulangi dan simpan otomatis
    private final ArrayDeque<String> undoStack = new ArrayDeque<>();
    private final ArrayDeque<String> redoStack = new ArrayDeque<>();
    private String currentJson = "";
    private boolean restoring = false;
    // hasil ekspor terakhir dan rekaman
    private volatile Uri lastSavedUri;
    private volatile String lastSavedMime = "video/mp4";
    private MediaRecorder recorder;
    private File recordFile;
    private boolean pendingCapture = false;

    private final ActivityResultLauncher<String[]> pickMusic =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onMusicPicked);

    // ---------- tahap 15: efek suara tambahan dan latar buram ----------
    private final List<SfxItem> sfxList = new ArrayList<>();
    private LinearLayout sfxListView;
    private boolean blurBg = false;
    private File sfxBedFile;
    private android.media.MediaPlayer sfxPreview;
    private final ActivityResultLauncher<String[]> pickSfx =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onSfxPicked);

    private void addSfx() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (clips.isEmpty()) { say("Belum ada video. Tambah video dulu."); return; }
        if (sfxList.size() >= 20) { say("Maksimal 20 efek suara tambahan."); return; }
        pickSfx.launch(new String[]{"audio/*"});
    }

    private void onSfxPicked(Uri u) {
        if (u == null) return;
        long d = durationOf(u);
        if (d <= 0) { say("File efek suara tidak bisa dibaca."); return; }
        persist(u);
        final SfxItem item = new SfxItem(u, nameOf(u), outputPositionMs(), d);
        final long total = totalOutMs();
        askSeconds("Efek suara dibunyikan di detik", "Detik pada hasil akhir, total " + speak(total),
                item.atMs, sec -> {
                    long ms = (long) (sec * 1000);
                    if (ms < 0 || ms >= total) {
                        say("Harus antara 0 dan " + speak(total) + ".");
                        return;
                    }
                    item.atMs = ms;
                    sfxList.add(item);
                    Collections.sort(sfxList, (a, b) -> Long.compare(a.atMs, b.atMs));
                    rebuildSfx();
                    say("Efek suara ditambahkan: " + item.name + ", di " + speak(ms) + ".");
                });
    }

    private void rebuildSfx() {
        if (sfxListView == null) return;
        sfxListView.removeAllViews();
        if (sfxList.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Belum ada efek suara tambahan.");
            t.setTextSize(16);
            sfxListView.addView(t);
            return;
        }
        for (int i = 0; i < sfxList.size(); i++) {
            final SfxItem it = sfxList.get(i);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setText("Efek suara " + (i + 1) + ", " + it.name + ", di " + speak(it.atMs)
                    + ", volume " + Math.round(it.volume * 100) + " persen");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                showSfxMenu(it);
            });
            sfxListView.addView(b);
        }
    }

    private void showSfxMenu(final SfxItem it) {
        final String[] labels = {"Dengarkan", "Ubah waktu", "Ubah volume", "Hapus"};
        choose("Efek suara: " + it.name, labels, -1, which -> {
            if (which == 0) {
                previewSfx(it);
            } else if (which == 1) {
                final long total = totalOutMs();
                askSeconds("Efek suara dibunyikan di detik", "Detik pada hasil akhir, total " + speak(total),
                        it.atMs, sec -> {
                            long ms = (long) (sec * 1000);
                            if (ms < 0 || ms >= total) {
                                say("Harus antara 0 dan " + speak(total) + ".");
                                return;
                            }
                            it.atMs = ms;
                            Collections.sort(sfxList, (a, b) -> Long.compare(a.atMs, b.atMs));
                            rebuildSfx();
                            say("Waktu efek suara diubah ke " + speak(ms) + ".");
                        });
            } else if (which == 2) {
                choose("Volume efek suara", VOL_LABELS, indexOf(VOLS, it.volume), w -> {
                    it.volume = VOLS[w];
                    rebuildSfx();
                    say("Volume efek suara diatur " + VOL_LABELS[w] + ".");
                });
            } else {
                sfxList.remove(it);
                rebuildSfx();
                say("Efek suara dihapus.");
            }
        });
    }

    private void previewSfx(SfxItem it) {
        stopSfxPreview();
        try {
            android.media.MediaPlayer mp = new android.media.MediaPlayer();
            mp.setDataSource(this, it.uri);
            float v = Math.min(1f, it.volume);
            mp.setVolume(v, v);
            mp.setOnPreparedListener(m -> m.start());
            mp.setOnCompletionListener(m -> {
                m.release();
                if (sfxPreview == m) sfxPreview = null;
            });
            sfxPreview = mp;
            mp.prepareAsync();
            say("Memutar efek suara " + it.name + ".");
        } catch (Exception e) {
            say("Tidak bisa memutar: " + e.getMessage());
        }
    }

    private void stopSfxPreview() {
        if (sfxPreview != null) {
            try { sfxPreview.release(); } catch (Exception ignored) { }
            sfxPreview = null;
        }
    }

    private void clearSfx() {
        if (exporting) { say("Sedang mengekspor."); return; }
        sfxList.clear();
        rebuildSfx();
        say("Semua efek suara tambahan dihapus.");
    }

    private void toggleBlurBg() {
        if (exporting) { say("Sedang mengekspor."); return; }
        blurBg = !blurBg;
        updateRatioInfo();
        String note = "";
        if (blurBg && (ratioIndex == 0 || RATIO_CROP[ratioIndex])) {
            note = " Pilih rasio yang berakhiran muat, bingkai hitam, agar latar buram dipakai.";
        }
        say("Latar buram " + (blurBg ? "hidup" : "mati") + "." + note
                + " Hasilnya terlihat pada video hasil ekspor, bukan pada pratinjau.");
    }

    // ---------- tahap 14: notifikasi ekspor ----------
    private boolean visible = false;
    private boolean notifAsked = false;
    private int lastNotifPct = -1;
    private final ActivityResultLauncher<String> notifPerm =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    granted -> onExportClicked(pendingAudioOnly));

    @Override
    protected void onStart() {
        super.onStart();
        visible = true;
        if (sharePending >= 0) handler.post(this::askShareConfirm);
    }

    // ---------- tahap 13: pemutar dan pengelola hasil ekspor ----------
    private ResultManager results;
    private Runnable afterGrant;
    private final ActivityResultLauncher<androidx.activity.result.IntentSenderRequest> grantLauncher =
            registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), res -> {
                Runnable r = afterGrant;
                afterGrant = null;
                if (res.getResultCode() == RESULT_OK && r != null) r.run();
                else sayQuiet("Izin tidak diberikan, tidak ada yang diubah.");
            });

    void notice(String s) { sayQuiet(s); }

    void pauseMain() {
        if (player != null) player.pause();
        updatePlayLabel();
    }

    void requestGrant(android.content.IntentSender sender, Runnable after) {
        afterGrant = after;
        grantLauncher.launch(new androidx.activity.result.IntentSenderRequest.Builder(sender).build());
    }

    void forgetSaved(Uri u) {
        if (u != null && u.equals(lastSavedUri)) lastSavedUri = null;
    }

    private final ActivityResultLauncher<String[]> pickVideos =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

    private final ActivityResultLauncher<String> saveProject =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/json"), this::onSaveProject);

    private final ActivityResultLauncher<String[]> openProject =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onOpenProject);

    private final ActivityResultLauncher<String> saveSrt =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/x-subrip"), this::onSaveSrt);

    private final ActivityResultLauncher<String[]> openSrt =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onOpenSrt);

    private final ActivityResultLauncher<String> micPerm =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startRecording();
                else say("Izin mikrofon ditolak, tidak bisa merekam.");
            });

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (pendingCapture) {
                    pendingCapture = false;
                    if (granted) captureFrame();
                    else say("Izin penyimpanan ditolak, gambar tidak disimpan.");
                    return;
                }
                if (granted) startExport(pendingAudioOnly);
                else say("Izin penyimpanan ditolak, ekspor dibatalkan.");
            });

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            Clip c = current();
            if (c != null && player != null) {
                long pos = player.getCurrentPosition();
                if (listenStopAt >= 0 && player.isPlaying() && pos >= listenStopAt) {
                    player.pause();
                    player.seekTo(listenStopAt);
                    listenStopAt = -1;
                    pos = player.getCurrentPosition();
                    updatePlayLabel();
                    say("Selesai memutar bagian terpilih.");
                }
                if (player.isPlaying() && pos >= c.endMs) {
                    player.pause();
                    player.seekTo(c.endMs);
                    pos = c.endMs;
                    updatePlayLabel();
                    say("Mencapai akhir klip.");
                }
                if (!seeking && !seek.isAccessibilityFocused()) {
                    seek.setProgress((int) Math.max(0, Math.min(c.endMs - c.startMs, pos - c.startMs)));
                }
            }
            if (exporting && splitter == null && transformer != null) {
                ProgressHolder ph = new ProgressHolder();
                int st = transformer.getProgress(ph);
                if (st == Transformer.PROGRESS_STATE_AVAILABLE) {
                    progress.setProgress(ph.progress);
                    if (ph.progress >= lastNotifPct + 1) {
                        lastNotifPct = ph.progress;
                        ExportNotifier.update(VideoLabActivity.this, ph.progress);
                    }
                    int step = (ph.progress / 20) * 20;
                    if (step > lastAnnounced) {
                        lastAnnounced = step;
                        say("Ekspor " + step + " persen.");
                    }
                }
            }
            if (exporting && splitter != null && splitter.isRunning()) {
                int pct = splitter.overallPercent();
                progress.setProgress(pct);
                if (pct >= lastNotifPct + 1) {
                    lastNotifPct = pct;
                    ExportNotifier.update(VideoLabActivity.this, pct);
                }
                int stepSplit = (pct / 20) * 20;
                if (stepSplit > lastAnnounced) {
                    lastAnnounced = stepSplit;
                    say("Memotong " + stepSplit + " persen. Sedang bagian " + splitter.currentPart()
                            + " dari " + splitter.totalParts() + ".");
                }
            }
            refreshPotong();
            handler.postDelayed(this, 250);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videolab_main);
        setupSections();
        applyFeatureMode();
        results = new ResultManager(this);
        if (savedInstanceState == null) {
            getWindow().getDecorView().post(() -> handleIncoming(getIntent()));
        }

        playerView = findViewById(R.id.playerView);
        playerView.setUseController(false);
        info = findViewById(R.id.info);
        message = findViewById(R.id.message);
        seek = findViewById(R.id.seek);
        btnPlay = findViewById(R.id.btnPlay);
        btnExport = findViewById(R.id.btnExport);
        btnCancel = findViewById(R.id.btnCancel);
        clipList = findViewById(R.id.clipList);
        progress = findViewById(R.id.progress);
        musicInfo = findViewById(R.id.musicInfo);
        btnMute = findViewById(R.id.btnMute);

        player = new ExoPlayer.Builder(this).build();
        // Suara video diputar sebagai media dan minta fokus suara, supaya tidak diredam aplikasi lain.
        player.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder()
                .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        player.addListener(new androidx.media3.common.Player.Listener() {
            @Override
            public void onPlayerError(androidx.media3.common.PlaybackException e) {
                updatePlayLabel();
                say("Video tidak bisa diputar: " + e.getErrorCodeName() + ".");
            }

            @Override
            public void onTracksChanged(androidx.media3.common.Tracks t) {
                Clip c = current();
                if (c != null && !c.isImage && !t.getGroups().isEmpty()
                        && !t.isTypeSupported(androidx.media3.common.C.TRACK_TYPE_AUDIO)) {
                    say("Peringatan: video ini tidak punya suara yang bisa diputar. Kemungkinan videonya memang tanpa suara, atau format suaranya tidak didukung.");
                }
            }
        });
        playerView.setPlayer(player);

        findViewById(R.id.btnAdd).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            pickVideos.launch(new String[]{"video/*"});
        });
        btnPlay.setOnClickListener(v -> togglePlay());
        findViewById(R.id.btnBack).setOnClickListener(v -> step(-5000));
        findViewById(R.id.btnFwd).setOnClickListener(v -> step(5000));
        findViewById(R.id.btnMarkStart).setOnClickListener(v -> markStart());
        findViewById(R.id.btnMarkEnd).setOnClickListener(v -> markEnd());
        findViewById(R.id.btnSplit).setOnClickListener(v -> splitClip());
        findViewById(R.id.btnReset).setOnClickListener(v -> resetClip());
        findViewById(R.id.btnDelete).setOnClickListener(v -> deleteClip());
        btnExport.setOnClickListener(v -> onExportClicked(false));
        findViewById(R.id.btnExportAudio).setOnClickListener(v -> onExportClicked(true));
        findViewById(R.id.btnDup).setOnClickListener(v -> duplicateClip());
        findViewById(R.id.btnUp).setOnClickListener(v -> moveClip(-1));
        findViewById(R.id.btnDown).setOnClickListener(v -> moveClip(1));
        findViewById(R.id.btnSpeed).setOnClickListener(v -> chooseSpeed());
        findViewById(R.id.btnVolume).setOnClickListener(v -> chooseVolume());
        btnMute.setOnClickListener(v -> toggleMute());
        findViewById(R.id.btnFadeIn).setOnClickListener(v -> chooseFade(true));
        findViewById(R.id.btnFadeOut).setOnClickListener(v -> chooseFade(false));
        findViewById(R.id.btnMusic).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            pickMusic.launch(new String[]{"audio/*"});
        });
        findViewById(R.id.btnMusicVol).setOnClickListener(v -> chooseMusicVolume());
        findViewById(R.id.btnMusicDel).setOnClickListener(v -> removeMusic());
        ratioInfo = findViewById(R.id.ratioInfo);
        findViewById(R.id.btnRotate).setOnClickListener(v -> rotateClip());
        findViewById(R.id.btnZoom).setOnClickListener(v -> chooseZoom());
        findViewById(R.id.btnBright).setOnClickListener(v -> chooseAdjust(true));
        findViewById(R.id.btnContrast).setOnClickListener(v -> chooseAdjust(false));
        findViewById(R.id.btnFilter).setOnClickListener(v -> chooseFilter());
        findViewById(R.id.btnTitle).setOnClickListener(v -> editTitle());
        findViewById(R.id.btnTitlePos).setOnClickListener(v -> chooseTitleOption(0));
        findViewById(R.id.btnTitleSize).setOnClickListener(v -> chooseTitleOption(1));
        findViewById(R.id.btnTitleColor).setOnClickListener(v -> chooseTitleOption(2));
        findViewById(R.id.btnFlipH).setOnClickListener(v -> flipClip(true));
        findViewById(R.id.btnFlipV).setOnClickListener(v -> flipClip(false));
        findViewById(R.id.btnUndo).setOnClickListener(v -> undo());
        findViewById(R.id.btnRedo).setOnClickListener(v -> redo());
        findViewById(R.id.btnNewProj).setOnClickListener(v -> newProject());
        findViewById(R.id.btnSummary).setOnClickListener(v -> showSummary());
        findViewById(R.id.btnBack1).setOnClickListener(v -> step(-1000));
        findViewById(R.id.btnFwd1).setOnClickListener(v -> step(1000));
        findViewById(R.id.btnBack01).setOnClickListener(v -> step(-100));
        findViewById(R.id.btnFwd01).setOnClickListener(v -> step(100));
        findViewById(R.id.btnGoStart).setOnClickListener(v -> goToEdge(false));
        findViewById(R.id.btnGoEnd).setOnClickListener(v -> goToEdge(true));
        findViewById(R.id.btnJump).setOnClickListener(v -> jumpToTime());
        findViewById(R.id.btnPotongDengar).setOnClickListener(v -> openPotong());
        findViewById(R.id.btnBack15).setOnClickListener(v -> step(-15000));
        findViewById(R.id.btnFwd15).setOnClickListener(v -> step(15000));
        findViewById(R.id.btnReadPos).setOnClickListener(v -> readPosition());
        findViewById(R.id.btnQuickFront).setOnClickListener(v -> markStart());
        findViewById(R.id.btnQuickBack).setOnClickListener(v -> markEnd());
        findViewById(R.id.btnSelA).setOnClickListener(v -> markSelA());
        findViewById(R.id.btnSelB).setOnClickListener(v -> markSelB());
        findViewById(R.id.btnSelListen).setOnClickListener(v -> listenSel());
        findViewById(R.id.btnSelClear).setOnClickListener(v -> clearSel(true));
        findViewById(R.id.btnSelKeep).setOnClickListener(v -> keepSel());
        findViewById(R.id.btnSelRemove).setOnClickListener(v -> removeSel());
        findViewById(R.id.btnSnap).setOnClickListener(v -> onSnapClicked());
        findViewById(R.id.btnSetStart).setOnClickListener(v -> setEdgeByNumber(false));
        findViewById(R.id.btnSetEnd).setOnClickListener(v -> setEdgeByNumber(true));
        btnRecord = findViewById(R.id.btnRecord);
        btnRecord.setOnClickListener(v -> toggleRecord());
        findViewById(R.id.btnMusicStart).setOnClickListener(v -> chooseMusicStart());
        findViewById(R.id.btnMusicFadeIn).setOnClickListener(v -> chooseMusicFade(true));
        findViewById(R.id.btnMusicFadeOut).setOnClickListener(v -> chooseMusicFade(false));
        findViewById(R.id.btnMusicDuck).setOnClickListener(v -> chooseMusicDuck());
        findViewById(R.id.btnMusicDuckSens).setOnClickListener(v -> chooseMusicDuckSens());
        findViewById(R.id.btnMusicDuckRel).setOnClickListener(v -> chooseMusicDuckRel());
        subStyleInfo = findViewById(R.id.subStyleInfo);
        findViewById(R.id.btnSubSize).setOnClickListener(v -> chooseSubStyle(0));
        findViewById(R.id.btnSubPos).setOnClickListener(v -> chooseSubStyle(1));
        findViewById(R.id.btnSubColor).setOnClickListener(v -> chooseSubStyle(2));
        findViewById(R.id.btnSubBg).setOnClickListener(v -> chooseSubStyle(3));
        findViewById(R.id.btnSubClear).setOnClickListener(v -> clearSubs());
        findViewById(R.id.btnSubTranslate).setOnClickListener(v -> chooseTranslate());
        findViewById(R.id.btnSrtExport).setOnClickListener(v -> {
            if (subs.isEmpty()) { say("Belum ada subtitle untuk diekspor."); return; }
            saveSrt.launch("subtitle_videolab.srt");
        });
        findViewById(R.id.btnSrtImport).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            openSrt.launch(new String[]{"*/*"});
        });
        findViewById(R.id.btnCodec).setOnClickListener(v -> chooseCodec());
        findViewById(R.id.btnShare).setOnClickListener(v -> shareLast());
        sfxListView = findViewById(R.id.sfxList);
        findViewById(R.id.btnSfxAdd).setOnClickListener(v -> addSfx());
        findViewById(R.id.btnSfxClear).setOnClickListener(v -> clearSfx());
        findViewById(R.id.btnBlurBg).setOnClickListener(v -> toggleBlurBg());
        findViewById(R.id.btnResults).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            results.showList();
        });
        findViewById(R.id.btnRatio).setOnClickListener(v -> chooseRatio());
        findViewById(R.id.btnAutoSub).setOnClickListener(v -> startAutoSubtitles());
        findViewById(R.id.btnGroqKey).setOnClickListener(v -> editGroqKey(false));
        findViewById(R.id.btnGroqModel).setOnClickListener(v -> chooseGroqModel());
        findViewById(R.id.btnGroqLang).setOnClickListener(v -> chooseGroqLang());
        findViewById(R.id.btnStabilize).setOnClickListener(v -> chooseStabilize());
        findViewById(R.id.btnQuickCompress).setOnClickListener(v -> quickCompress());
        findViewById(R.id.btnTemplate).setOnClickListener(v -> chooseTemplate());
        findViewById(R.id.btnQuickExport).setOnClickListener(v -> chooseQuickExport());
        findViewById(R.id.btnSplitStatus).setOnClickListener(v -> chooseSplit());
        findViewById(R.id.btnShareSplit).setOnClickListener(v -> shareSplitToStatus());
        findViewById(R.id.btnQueueAdd).setOnClickListener(v -> queueAdd());
        findViewById(R.id.btnQueueList).setOnClickListener(v -> queueManage());
        findViewById(R.id.btnQueueStart).setOnClickListener(v -> queueStart());
        findViewById(R.id.btnSizeLimit).setOnClickListener(v -> chooseSizeLimit());
        updateRatioInfo();
        exportInfo = findViewById(R.id.exportInfo);
        subList = findViewById(R.id.subList);
        findViewById(R.id.btnSaveProj).setOnClickListener(v -> {
            if (clips.isEmpty()) { say("Belum ada klip untuk disimpan."); return; }
            saveProject.launch("proyek_videolab.json");
        });
        findViewById(R.id.btnOpenProj).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            openProject.launch(new String[]{"*/*"});
        });
        findViewById(R.id.btnSubAdd).setOnClickListener(v -> addSubtitle());
        findViewById(R.id.btnTrans).setOnClickListener(v -> chooseTransition());
        findViewById(R.id.btnRes).setOnClickListener(v -> chooseResolution());
        findViewById(R.id.btnQual).setOnClickListener(v -> chooseQuality());
        overlayList = findViewById(R.id.overlayList);
        findViewById(R.id.btnOvText).setOnClickListener(v -> addOverlay(0));
        findViewById(R.id.btnOvSticker).setOnClickListener(v -> addOverlay(1));
        findViewById(R.id.btnOvClear).setOnClickListener(v -> clearOverlays());
        findViewById(R.id.btnPitch).setOnClickListener(v -> choosePitch());
        findViewById(R.id.btnSat).setOnClickListener(v -> chooseColorTweak(0));
        findViewById(R.id.btnHue).setOnClickListener(v -> chooseColorTweak(1));
        findViewById(R.id.btnWarm).setOnClickListener(v -> chooseColorTweak(2));
        imageList = findViewById(R.id.imageList);
        findViewById(R.id.btnImgAdd).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            if (current() == null) { say("Belum ada video."); return; }
            pendingImgStartMs = outputPositionMs();
            pickImage.launch(new String[]{"image/*"});
        });
        findViewById(R.id.btnImgClear).setOnClickListener(v -> clearImages());
        findViewById(R.id.btnAddPhoto).setOnClickListener(v -> {
            if (exporting) { say("Sedang mengekspor."); return; }
            pickPhotos.launch(new String[]{"image/*"});
        });
        findViewById(R.id.btnPhotoDur).setOnClickListener(v -> choosePhotoDuration());
        findViewById(R.id.btnRamp).setOnClickListener(v -> chooseSpeedRamp());
        findViewById(R.id.btnSilence).setOnClickListener(v -> chooseSilenceCut());
        findViewById(R.id.btnNormalize).setOnClickListener(v -> chooseNormalize());
        findViewById(R.id.btnFadeColor).setOnClickListener(v -> chooseFadeColor());
        findViewById(R.id.btnStyle).setOnClickListener(v -> chooseStyle());
        findViewById(R.id.btnCopyFx).setOnClickListener(v -> copyLookToAll());
        findViewById(R.id.btnSubText).setOnClickListener(v -> subtitlesFromText());
        findViewById(R.id.btnSubCutMode).setOnClickListener(v -> toggleSubCut());
        updateSubCutButton();
        findViewById(R.id.btnFocus).setOnClickListener(v -> chooseFocus());
        findViewById(R.id.btnMotion).setOnClickListener(v -> chooseMotion());
        findViewById(R.id.btnAudFx).setOnClickListener(v -> chooseAudioFx());
        rebuildImages();
        rebuildOverlays();
        rebuildSfx();
        updateExportInfo();
        updateSubStyleInfo();
        rebuildSubs();
        updateMusicInfo();
        btnCancel.setOnClickListener(v -> cancelExport());

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                Clip c = current();
                if (fromUser && c != null) {
                    player.seekTo(c.startMs + p);
                    ViewCompat.setStateDescription(sb, "posisi " + speak(c.startMs + p));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) { seeking = false; }
        });

        restoreAutosave();
        handler.post(ticker);
    }

    @Override
    protected void onStop() {
        visible = false;
        super.onStop();
        if (recorder != null) stopRecording();
        if (player != null) { player.pause(); updatePlayLabel(); }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(ticker);
        if (splitter != null && splitter.isRunning()) {
            splitter.cancel();
            ExportService.stop(this);
        }
        if (transformer != null && exporting) {
            transformer.cancel();
            if (outFile != null) outFile.delete();
            ExportService.stop(this);
        }
        if (recorder != null) {
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        if (results != null) results.dismiss();
        stopSfxPreview();
        if (player != null) player.release();
        super.onDestroy();
    }

    // ---------- util ----------

    private Clip current() {
        return (selected >= 0 && selected < clips.size()) ? clips.get(selected) : null;
    }

    private static final String BUSY_MSG =
            "Proses analisis, pengenalan suara, atau terjemahan masih berjalan. Tunggu sampai selesai agar waktu subtitle tidak meleset.";

    private Clip editable() {
        if (queueRunning) { say("Antrean ekspor sedang berjalan. Tunggu sampai selesai."); return null; }
        if (exporting) { say("Sedang mengekspor."); return null; }
        if (stabBusy) { say(BUSY_MSG); return null; }
        if (restorePending) { say(RESTORE_MSG); return null; }
        Clip c = current();
        if (c == null) say("Belum ada klip yang dipilih.");
        return c;
    }

    /** Menyampaikan pesan tanpa memeriksa perubahan proyek (dipakai oleh urungkan/ulangi). */
    // ---------- tahap 12: menu ringkas berbagian ----------
    private final java.util.ArrayList<TextView> sectionHeads = new java.util.ArrayList<>();
    private final java.util.ArrayList<LinearLayout> sectionBodies = new java.util.ArrayList<>();
    private final java.util.ArrayList<Boolean> sectionPinned = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> sectionNames = new java.util.ArrayList<>();
    /** Tahap 52: anak rootColumn menurut urutan XML asli, dipakai mode fitur untuk memilih apa yang tampil. */
    private final java.util.ArrayList<View> origKids = new java.util.ArrayList<>();

    /**
     * Tahap 52: bila dibuka dari kisi fitur di halaman awal (extra "fitur"), hanya bagian inti, bagian fitur itu,
     * dan tombol ekspor yang tampil, tanpa bagian yang bisa dibuka tutup. Tanpa extra (atau "semua") tampilan lama.
     */
    private void applyFeatureMode() {
        Fitur.Def d = Fitur.cari(getIntent().getStringExtra(Fitur.EXTRA));
        if (d == null) return;
        java.util.HashSet<Integer> show = new java.util.HashSet<>();
        for (int i : Fitur.INTI) show.add(i);
        for (int i : Fitur.EKSPOR) show.add(i);
        for (int i : d.tampil) show.add(i);
        java.util.HashSet<View> orig = new java.util.HashSet<>(origKids);
        for (int i = 0; i < origKids.size(); i++) {
            View v = origKids.get(i);
            Object tag = v.getTag();
            boolean head = v instanceof TextView && tag != null && tag.toString().startsWith("bagian");
            if (head || !show.contains(i)) v.setVisibility(View.GONE);
        }
        for (LinearLayout body : sectionBodies) {
            body.setVisibility(View.VISIBLE);
            // Tombol "Ekspor video sekarang" per bagian tidak perlu; ekspor sudah ada di bawah.
            for (int k = 0; k < body.getChildCount(); k++) {
                View c = body.getChildAt(k);
                if (!orig.contains(c)) c.setVisibility(View.GONE);
            }
        }
        setTitle(d.judul);
        LinearLayout root = findViewById(R.id.rootColumn);
        TextView judul = new TextView(this);
        judul.setText(d.judul);
        judul.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 22);
        judul.setPadding(0, 8, 0, 16);
        ViewCompat.setAccessibilityHeading(judul, true);
        root.addView(judul, 0);
    }

    /** Mengelompokkan tombol di bawah tiap judul bagian agar bisa dibuka dan ditutup. */
    private void setupSections() {
        LinearLayout root = findViewById(R.id.rootColumn);
        java.util.ArrayList<View> kids = new java.util.ArrayList<>();
        for (int i = 0; i < root.getChildCount(); i++) kids.add(root.getChildAt(i));
        root.removeAllViews();
        origKids.addAll(kids);
        LinearLayout body = null;
        boolean pinned = false;
        for (View v : kids) {
            String tag = v.getTag() == null ? "" : v.getTag().toString();
            if (v instanceof TextView && tag.startsWith("bagian")) {
                if (body != null) finishSection(body, pinned);
                pinned = tag.equals("bagian_buka");
                TextView head = (TextView) v;
                body = new LinearLayout(this);
                body.setOrientation(LinearLayout.VERTICAL);
                root.addView(head);
                root.addView(body, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                sectionHeads.add(head);
                sectionBodies.add(body);
                sectionPinned.add(pinned);
                sectionNames.add(head.getText().toString());
            } else if (v instanceof TextView && tag.equals("akhir")) {
                if (body != null) finishSection(body, pinned);
                body = null;
                root.addView(v);
            } else if (body != null) {
                body.addView(v);
            } else {
                root.addView(v);
            }
        }
        if (body != null) finishSection(body, pinned);
        for (int i = 0; i < sectionHeads.size(); i++) {
            final int idx = i;
            final TextView head = sectionHeads.get(i);
            head.setClickable(true);
            head.setFocusable(true);
            head.setPadding(0, 12, 0, 12);
            ViewCompat.setAccessibilityDelegate(head, new androidx.core.view.AccessibilityDelegateCompat() {
                @Override
                public void onInitializeAccessibilityNodeInfo(View host,
                        androidx.core.view.accessibility.AccessibilityNodeInfoCompat info) {
                    super.onInitializeAccessibilityNodeInfo(host, info);
                    info.setClassName("android.widget.Button");
                }
            });
            head.setOnClickListener(v -> toggleSection(idx));
            applySectionState(idx, sectionPinned.get(i));
        }
    }

    /** Tombol ekspor cepat di ujung setiap bagian, supaya tidak perlu menggulir jauh. */
    private void finishSection(LinearLayout body, boolean pinned) {
        if (pinned) return;
        Button quick = new Button(this);
        quick.setText("Ekspor video sekarang");
        quick.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        quick.setOnClickListener(v -> {
            if (exporting) { sayQuiet("Sedang mengekspor."); return; }
            onExportClicked(false);
        });
        body.addView(quick);
    }

    private void applySectionState(int idx, boolean open) {
        TextView head = sectionHeads.get(idx);
        String name = sectionNames.get(idx);
        sectionBodies.get(idx).setVisibility(open ? View.VISIBLE : View.GONE);
        head.setText(name + (open ? "  \u25BE" : "  \u25B8"));
        head.setContentDescription(name);
        ViewCompat.setStateDescription(head, open ? "terbuka" : "tertutup");
    }

    private void toggleSection(int idx) {
        boolean open = sectionBodies.get(idx).getVisibility() != View.VISIBLE;
        if (open && !sectionPinned.get(idx)) {
            for (int i = 0; i < sectionHeads.size(); i++) {
                if (i != idx && !sectionPinned.get(i)) applySectionState(i, false);
            }
        }
        applySectionState(idx, open);
        sayQuiet(sectionNames.get(idx) + (open ? " dibuka." : " ditutup."));
    }

    private void sayQuiet(String s) {
        message.setText(s);
    }

    private void say(String s) {
        message.setText(s);
        if (potongStatus != null && potongDialog != null && potongDialog.isShowing()) potongStatus.setText(s);
        // Setiap aksi pengguna diakhiri dengan say(). Di sini kondisi proyek dibandingkan
        // dengan kondisi terakhir; kalau berubah, dicatat sebagai satu langkah urungkan
        // dan disimpan otomatis. Aksi yang tidak mengubah apa pun tidak dicatat.
        trackChange();
    }

    private String speak(long ms) {
        if (ms < 60000) {
            return String.format(new Locale("id"), "%.1f detik", ms / 1000.0);
        }
        long total = ms / 1000;
        long m = total / 60, s = total % 60;
        return s == 0 ? m + " menit" : m + " menit " + s + " detik";
    }

    private void updatePlayLabel() {
        btnPlay.setText(player != null && player.isPlaying() ? "Jeda" : "Putar");
    }

    private void updateInfo() {
        Clip c = current();
        btnMute.setText(c != null && c.muted ? "Aktifkan suara klip" : "Bisukan suara klip");
        if (c == null) {
            info.setText("Belum ada video. Tekan Tambah video.");
            return;
        }
        info.setText("Klip " + (selected + 1) + " dari " + clips.size() + ": " + c.name
                + ". Posisi sekarang " + speak(player.getCurrentPosition())
                + ". Potongan dari " + speak(c.startMs) + " sampai " + speak(c.endMs)
                + ". Total video hasil sekitar " + speak(totalOutMs()) + ".");
    }

    private void configureSeek() {
        Clip c = current();
        if (c == null) { seek.setMax(0); return; }
        seek.setMax((int) (c.endMs - c.startMs));
        long pos = player.getCurrentPosition();
        seek.setProgress((int) Math.max(0, Math.min(c.endMs - c.startMs, pos - c.startMs)));
    }

    private void rebuildList() {
        clipList.removeAllViews();
        for (int i = 0; i < clips.size(); i++) {
            final int idx = i;
            Clip c = clips.get(i);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setTextColor(Color.WHITE);
            b.setText("Klip " + (i + 1) + ", " + c.name + ", dari " + speak(c.startMs)
                    + " sampai " + speak(c.endMs) + ", durasi hasil " + speak(c.outDurationMs())
                    + effectSummary(c));
            boolean sel = (i == selected);
            b.setBackgroundColor(sel ? 0xFF1565C0 : 0xFF424242);
            ViewCompat.setStateDescription(b, sel ? "dipilih" : "tidak dipilih");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                select(idx);
            });
            clipList.addView(b);
        }
    }

    // ---------- pilih & kelola klip ----------

    private void handleIncoming(Intent in) {
        if (in == null) return;
        if (restorePending) { deferredIntent = in; return; }
        String act = in.getAction();
        List<Uri> list = new ArrayList<>();
        try {
            if (Intent.ACTION_SEND.equals(act)) {
                Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) list.add(u);
            } else if (Intent.ACTION_SEND_MULTIPLE.equals(act)) {
                ArrayList<Uri> us = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (us != null) list.addAll(us);
            } else if (Intent.ACTION_VIEW.equals(act) && in.getData() != null) {
                list.add(in.getData());
            }
        } catch (Exception ignored) { }
        if (list.isEmpty()) return;
        in.setAction(Intent.ACTION_MAIN); // agar tidak diproses dua kali
        if (exporting) { say("Sedang mengekspor, video yang dibagikan tidak ditambahkan."); return; }
        onPicked(list);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private void onPicked(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        if (restorePending) { say(RESTORE_MSG); return; }
        int added = 0;
        TimeSnap sn = takeSnap();
        for (Uri u : uris) {
            persist(u);
            long d = durationOf(u);
            if (d <= 0) continue;
            clips.add(new Clip(u, nameOf(u), d, 0, d));
            added++;
        }
        if (added == 0) { say("Video tidak bisa dibaca."); return; }
        remapItems(sn);
        if (selected < 0) {
            select(0);
        } else {
            rebuildList();
        }
        say(added + " video ditambahkan. Total " + clips.size() + " klip.");
    }

    private String nameOf(Uri u) {
        try (Cursor cur = getContentResolver().query(u, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return cur.getString(i);
            }
        } catch (Exception ignored) { }
        return "video";
    }

    private long durationOf(Uri u) {
        java.util.Map<String, Long> cache = durCache;
        if (cache != null) {
            Long v = cache.get(u.toString());
            if (v != null) return v;
        }
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, u);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? 0 : Long.parseLong(d);
        } catch (Exception e) {
            return 0;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    private void select(int i) {
        selected = i;
        selA = -1; selB = -1; listenStopAt = -1;
        Clip c = clips.get(i);
        if (c.isImage) {
            player.setMediaItem(new MediaItem.Builder().setUri(c.uri).setImageDurationMs(c.durationMs).build());
        } else {
            player.setMediaItem(MediaItem.fromUri(c.uri));
        }
        player.prepare();
        player.seekTo(c.startMs);
        player.pause();
        applyPreview(c);
        updatePlayLabel();
        rebuildList();
        configureSeek();
        updateInfo();
        say("Klip " + (i + 1) + " dipilih.");
    }

    private void togglePlay() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        listenStopAt = -1;
        if (player.isPlaying()) {
            player.pause();
        } else {
            long pos = player.getCurrentPosition();
            if (pos >= c.endMs - 100 || pos < c.startMs) player.seekTo(c.startMs);
            player.play();
        }
        updatePlayLabel();
        say(player.isPlaying() ? "Memutar." : "Dijeda.");
    }

    private void step(long delta) {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        long pos = Math.max(c.startMs, Math.min(c.endMs, player.getCurrentPosition() + delta));
        player.seekTo(pos);
        configureSeek();
        updateInfo();
        say("Posisi " + speak(pos) + " dari " + speak(c.durationMs) + ".");
    }

    private String sec1(long ms) {
        return String.format(Locale.US, "%.1f", ms / 1000.0);
    }

    private void goToEdge(boolean end) {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        long pos = end ? c.endMs : c.startMs;
        player.seekTo(pos);
        configureSeek();
        updateInfo();
        say((end ? "Di akhir potongan, " : "Di awal potongan, ") + speak(pos) + " dari " + speak(c.durationMs) + ".");
    }

    interface SecPick { void pick(double sec); }

    private void askSeconds(String title, String hint, long defMs, final SecPick cb) {
        final EditText et = new EditText(this);
        et.setHint(hint);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setText(sec1(defMs));
        et.setSelectAllOnFocus(true);
        et.setPadding(48, 32, 48, 32);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setPositiveButton("Simpan", (d, w) -> {
                    double v = parseSec(et.getText().toString());
                    if (v < 0) { say("Angka tidak valid."); return; }
                    cb.pick(v);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void jumpToTime() {
        final Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        askSeconds("Lompat ke waktu", "Detik pada video asli", player.getCurrentPosition(), sec -> {
            long ms = (long) (sec * 1000);
            if (ms < c.startMs || ms > c.endMs) {
                say("Di luar potongan. Pilih antara " + speak(c.startMs) + " dan " + speak(c.endMs) + ".");
                return;
            }
            player.seekTo(ms);
            configureSeek(); updateInfo();
            say("Posisi " + speak(ms) + ".");
        });
    }

    private void setEdgeByNumber(final boolean end) {
        final Clip c = editable();
        if (c == null) return;
        askSeconds(end ? "Akhir potongan" : "Awal potongan",
                "Detik pada video asli, durasi penuh " + speak(c.durationMs),
                end ? c.endMs : c.startMs, sec -> {
                    long ms = (long) (sec * 1000);
                    final TimeSnap sn = takeSnap();
                    if (end) {
                        if (ms <= c.startMs + 200 || ms > c.durationMs) {
                            say("Akhir harus setelah awal dan tidak melebihi " + speak(c.durationMs) + ".");
                            return;
                        }
                        c.endMs = ms;
                    } else {
                        if (ms < 0 || ms >= c.endMs - 200) {
                            say("Awal harus sebelum akhir klip.");
                            return;
                        }
                        c.startMs = ms;
                    }
                    remapItems(sn);
                    long pos = player.getCurrentPosition();
                    if (pos < c.startMs || pos > c.endMs) player.seekTo(end ? c.endMs : c.startMs);
                    rebuildList(); configureSeek(); updateInfo();
                    say((end ? "Akhir klip diatur di " : "Awal klip diatur di ")
                            + speak(end ? c.endMs : c.startMs) + ".");
                });
    }

    private void markStart() {
        Clip c = editable();
        if (c == null) return;
        long pos = player.getCurrentPosition();
        if (pos >= c.endMs - 200) { say("Awal harus sebelum akhir klip."); return; }
        TimeSnap sn = takeSnap();
        c.startMs = Math.max(0, pos);
        remapItems(sn);
        rebuildList(); configureSeek(); updateInfo();
        say("Awal klip diatur di " + speak(c.startMs) + ".");
    }

    private void markEnd() {
        Clip c = editable();
        if (c == null) return;
        long pos = player.getCurrentPosition();
        if (pos <= c.startMs + 200) { say("Akhir harus setelah awal klip."); return; }
        TimeSnap sn = takeSnap();
        c.endMs = Math.min(c.durationMs, pos);
        remapItems(sn);
        rebuildList(); configureSeek(); updateInfo();
        say("Akhir klip diatur di " + speak(c.endMs) + ".");
    }

    private void splitClip() {
        Clip c = editable();
        if (c == null) return;
        long pos = player.getCurrentPosition();
        if (pos <= c.startMs + 500 || pos >= c.endMs - 500) {
            say("Posisi terlalu dekat dengan ujung klip. Geser posisi dulu.");
            return;
        }
        // Bagian kedua mewarisi semua efek; fade keluar ikut bagian kedua, fade masuk tetap
        // di bagian pertama, dan teks judul hanya di bagian pertama.
        Clip second = c.copy();
        second.startMs = pos;
        second.fadeInMs = 0;
        second.title = "";
        c.endMs = pos;
        c.fadeOutMs = 0;
        clips.add(selected + 1, second);
        rebuildList(); configureSeek(); updateInfo();
        say("Klip dipisah di " + speak(pos) + ". Sekarang " + clips.size() + " klip.");
    }

    // ---------- tahap 37: layar khusus potong sambil mendengarkan ----------
    // Satu layar penuh dengan tombol besar: Putar, Jeda, Lanjut, Berhenti, maju mundur, tanda, dan hasil potong.
    // Memakai pemutar yang sama dengan layar utama, jadi semua hasil langsung berlaku pada klip terpilih.

    private android.app.Dialog potongDialog;
    private TextView potongStatus, potongPos;
    private Button pdPutar, pdJeda, pdLanjut, pdBerhenti;
    private SeekBar pdSeek;
    private TextView pdSeekLabel;
    private boolean pdSeeking = false;

    private void playClip() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (c.isImage) { say("Foto tidak bisa diputar. Pilih klip video."); return; }
        applyPreview(c);
        listenStopAt = -1;
        long pos = player.getCurrentPosition();
        if (pos >= c.endMs - 100 || pos < c.startMs) player.seekTo(c.startMs);
        player.play();
        updatePlayLabel();
        configureSeek(); updateInfo();
        String extra = "";
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null && am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0) {
                extra = " Volume media HP nol, tekan Volume naik.";
            }
        } catch (Exception ignored) { }
        if (c.muted) extra += " Suara klip ini sedang dibisukan.";
        say("Memutar." + extra);
    }

    private void pauseClip() {
        if (!player.isPlaying()) { say("Sedang tidak memutar."); return; }
        listenStopAt = -1;
        player.pause();
        updatePlayLabel();
        configureSeek(); updateInfo();
        say("Dijeda di " + speak(player.getCurrentPosition()) + ".");
    }

    private void resumeClip() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (player.isPlaying()) { say("Sudah memutar."); return; }
        playClip();
    }

    private void stopClip() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        listenStopAt = -1;
        player.pause();
        player.seekTo(c.startMs);
        updatePlayLabel();
        configureSeek(); updateInfo();
        say("Berhenti. Kembali ke awal potongan, " + speak(c.startMs) + ".");
    }

    private void changeVolume(boolean up) {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                    up ? android.media.AudioManager.ADJUST_RAISE : android.media.AudioManager.ADJUST_LOWER,
                    android.media.AudioManager.FLAG_SHOW_UI);
            int v = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);
            int m = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
            say("Volume media " + v + " dari " + m + ".");
        } catch (Exception e) {
            say("Volume tidak bisa diatur dari sini. Pakai tombol volume HP.");
        }
    }

    private void refreshPotong() {
        if (potongDialog == null || !potongDialog.isShowing() || potongPos == null) return;
        Clip c = current();
        if (c == null) return;
        long pos = player.getCurrentPosition();
        boolean playing = player.isPlaying();
        potongPos.setText("Klip " + (selected + 1) + ", posisi " + speak(pos) + " dari " + speak(c.durationMs)
                + ". Potongan " + speak(c.startMs) + " sampai " + speak(c.endMs) + ".\n" + selText());
        boolean paused = !playing && pos > c.startMs + 50 && pos < c.endMs - 100;
        pdPutar.setEnabled(!playing);
        pdJeda.setEnabled(playing);
        pdLanjut.setEnabled(paused);
        pdBerhenti.setEnabled(playing || paused);
        updatePdSeek(c, pos);
    }

    // ---------- tahap 38: penggeser persentase di layar potong ----------
    private int pdPercent(Clip c, long pos) {
        long len = c.endMs - c.startMs;
        if (len <= 0) return 0;
        long v = Math.max(0, Math.min(len, pos - c.startMs));
        return (int) Math.round(v * 100.0 / len);
    }

    private String pdSeekText(Clip c, int pct) {
        return pct + " persen";
    }

    private void updatePdSeek(Clip c, long pos) {
        if (pdSeek == null || pdSeeking || pdSeek.isAccessibilityFocused()) return;
        int pct = pdPercent(c, pos);
        if (pdSeek.getProgress() != pct) pdSeek.setProgress(pct);
        ViewCompat.setStateDescription(pdSeek, pdSeekText(c, pct));
        if (pdSeekLabel != null) pdSeekLabel.setText("Posisi " + pct + " persen dari potongan");
    }

    private void pdSeekToPercent(int pct, boolean announce) {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        pct = Math.max(0, Math.min(100, pct));
        long pos = c.startMs + Math.round((c.endMs - c.startMs) * pct / 100.0);
        player.seekTo(pos);
        if (pdSeek != null && pdSeek.getProgress() != pct) pdSeek.setProgress(pct);
        if (pdSeek != null) ViewCompat.setStateDescription(pdSeek, pdSeekText(c, pct));
        if (pdSeekLabel != null) pdSeekLabel.setText("Posisi " + pct + " persen dari potongan");
        configureSeek(); updateInfo();
        if (announce) say(pdSeekText(c, pct) + ".");
    }

    private void pdPercentStep(int delta) {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        pdSeekToPercent(pdPercent(c, player.getCurrentPosition()) + delta, true);
    }

    private Button pdTombol(LinearLayout parent, String label, Runnable aksi) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(18f);
        b.setMinHeight((int) (64 * getResources().getDisplayMetrics().density));
        b.setOnClickListener(v -> aksi.run());
        parent.addView(b, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return b;
    }

    /** Dua tombol sebaris, sama lebar. */
    private Button[] pdBaris(LinearLayout parent, String l1, Runnable a1, String l2, Runnable a2) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        Button[] r = new Button[2];
        String[] ls = {l1, l2};
        Runnable[] as = {a1, a2};
        for (int i = 0; i < 2; i++) {
            final Runnable a = as[i];
            Button b = new Button(this);
            b.setText(ls[i]);
            b.setAllCaps(false);
            b.setTextSize(17f);
            b.setMinHeight((int) (64 * getResources().getDisplayMetrics().density));
            b.setOnClickListener(v -> a.run());
            row.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r[i] = b;
        }
        return r;
    }

    private TextView pdJudul(LinearLayout parent, String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(20f);
        tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
        tv.setPadding(0, (int) (18 * getResources().getDisplayMetrics().density), 0, 4);
        ViewCompat.setAccessibilityHeading(tv, true);
        parent.addView(tv);
        return tv;
    }

    private void openPotong() {
        Clip c = current();
        if (c == null) { say("Belum ada video. Tekan Tambah video dulu."); return; }
        if (c.isImage) { say("Klip ini foto. Pilih klip video."); return; }
        if (exporting) { say("Sedang mengekspor."); return; }
        if (potongDialog != null && potongDialog.isShowing()) return;
        applyPreview(c);

        android.app.Dialog d = new android.app.Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);

        TextView judul = new TextView(this);
        judul.setText("Potong sambil mendengarkan");
        judul.setTextSize(22f);
        judul.setTypeface(judul.getTypeface(), android.graphics.Typeface.BOLD);
        ViewCompat.setAccessibilityHeading(judul, true);
        col.addView(judul);

        potongStatus = new TextView(this);
        potongStatus.setTextSize(17f);
        potongStatus.setTypeface(potongStatus.getTypeface(), android.graphics.Typeface.BOLD);
        potongStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        potongStatus.setPadding(0, 8, 0, 8);
        potongStatus.setText("Tekan Putar, lalu tandai bagian yang dimaksud.");
        col.addView(potongStatus);

        potongPos = new TextView(this);
        potongPos.setTextSize(16f);
        col.addView(potongPos);

        pdJudul(col, "Putar");
        Button[] r1 = pdBaris(col, "Putar", this::playClip, "Jeda", this::pauseClip);
        Button[] r2 = pdBaris(col, "Lanjut", this::resumeClip, "Berhenti", this::stopClip);
        pdPutar = r1[0]; pdJeda = r1[1]; pdLanjut = r2[0]; pdBerhenti = r2[1];

        pdJudul(col, "Geser posisi (persen)");
        pdSeekLabel = new TextView(this);
        pdSeekLabel.setTextSize(16f);
        col.addView(pdSeekLabel);
        pdSeek = new SeekBar(this);
        pdSeek.setMax(100);
        pdSeek.setContentDescription("Posisi video");
        int sp = (int) (12 * getResources().getDisplayMetrics().density);
        pdSeek.setPadding(sp * 2, sp * 2, sp * 2, sp * 2);
        pdSeek.setMinimumHeight((int) (64 * getResources().getDisplayMetrics().density));
        pdSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (!fromUser) return;
                Clip cc = current();
                if (cc == null) return;
                long pos = cc.startMs + Math.round((cc.endMs - cc.startMs) * p / 100.0);
                player.seekTo(pos);
                ViewCompat.setStateDescription(sb, pdSeekText(cc, p));
                if (pdSeekLabel != null) pdSeekLabel.setText("Posisi " + p + " persen dari potongan");
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { pdSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                pdSeeking = false;
                configureSeek(); updateInfo();
                Clip cc = current();
                if (cc != null) say(pdSeekText(cc, sb.getProgress()) + ".");
            }
        });
        col.addView(pdSeek, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        pdJudul(col, "Maju dan mundur");
        pdBaris(col, "Mundur 15 detik", () -> step(-15000), "Maju 15 detik", () -> step(15000));
        pdBaris(col, "Mundur 5 detik", () -> step(-5000), "Maju 5 detik", () -> step(5000));
        pdBaris(col, "Mundur 1 detik", () -> step(-1000), "Maju 1 detik", () -> step(1000));
        pdBaris(col, "Mundur 0,1 detik", () -> step(-100), "Maju 0,1 detik", () -> step(100));
        pdBaris(col, "Ke awal potongan", () -> goToEdge(false), "Ke akhir potongan", () -> goToEdge(true));
        pdTombol(col, "Baca posisi dan tanda sekarang", this::readPosition);
        pdBaris(col, "Volume turun", () -> changeVolume(false), "Volume naik", () -> changeVolume(true));

        pdJudul(col, "Potong cepat");
        pdTombol(col, "Buang bagian depan sampai posisi ini", this::markStart);
        pdTombol(col, "Buang bagian belakang dari posisi ini", this::markEnd);

        pdJudul(col, "Tandai bagian");
        pdBaris(col, "Tandai mulai di sini", this::markSelA, "Tandai akhir di sini", this::markSelB);
        pdTombol(col, "Dengarkan bagian terpilih", this::listenSel);
        pdTombol(col, "Hapus tanda bagian", () -> clearSel(true));

        pdJudul(col, "Lalu pilih");
        pdTombol(col, "Simpan bagian ini saja (potong)", this::keepSel);
        pdTombol(col, "Buang bagian ini (sisanya disambung)", this::removeSel);

        pdJudul(col, "Simpan hasil potongan jadi file video");
        pdTombol(col, "Ekspor video hasil potongan (Gabungkan dan ekspor)", () -> {
            if (clips.isEmpty()) { say("Belum ada video."); return; }
            d.dismiss();
            onExportClicked(false);
        });

        pdJudul(col, "Selesai");
        pdTombol(col, "Tutup, kembali ke layar utama", () -> d.dismiss());

        d.setContentView(sv);
        d.setOnDismissListener(x -> {
            try { player.pause(); } catch (Exception ignored) { }
            listenStopAt = -1;
            potongDialog = null;
            potongStatus = null;
            potongPos = null;
            pdSeek = null;
            pdSeekLabel = null;
            pdSeeking = false;
            updatePlayLabel();
            configureSeek(); updateInfo();
            say("Kembali ke layar utama.");
        });
        potongDialog = d;
        d.show();
        d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        refreshPotong();
    }

    // ---------- tahap 36: potong sambil mendengarkan ----------
    // Tanda mulai dan akhir bagian disimpan dulu (belum memotong), bisa didengarkan, lalu dipilih:
    // simpan bagian itu saja, atau buang bagian itu dan sambung sisanya. Waktu memakai waktu video asli.

    private long selA = -1, selB = -1, listenStopAt = -1;

    private String selText() {
        String a = selA >= 0 ? "Mulai bagian di " + speak(selA) : "Mulai bagian belum ditandai";
        String b = selB >= 0 ? "akhir bagian di " + speak(selB) : "akhir bagian belum ditandai";
        return a + ", " + b + ".";
    }

    private void readPosition() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        say("Posisi " + speak(player.getCurrentPosition()) + " dari " + speak(c.durationMs)
                + ". Potongan dari " + speak(c.startMs) + " sampai " + speak(c.endMs) + ". " + selText());
    }

    private void clearSel(boolean announce) {
        selA = -1; selB = -1; listenStopAt = -1;
        if (announce) say("Tanda mulai dan akhir bagian dihapus.");
    }

    private boolean selInside(Clip c) {
        return (selA < 0 || (selA >= c.startMs && selA <= c.endMs))
                && (selB < 0 || (selB >= c.startMs && selB <= c.endMs));
    }

    private void markSelA() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (c.isImage) { say("Foto tidak bisa ditandai. Pilih klip video."); return; }
        long pos = player.getCurrentPosition();
        if (pos < c.startMs || pos > c.endMs) { say("Posisi di luar potongan klip. Geser posisi dulu."); return; }
        if (selB >= 0 && pos >= selB) {
            say("Mulai harus sebelum akhir. Akhir sekarang di " + speak(selB) + ". Mundurkan posisi dulu.");
            return;
        }
        selA = pos;
        say("Mulai bagian ditandai di " + speak(pos) + ".");
    }

    private void markSelB() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (c.isImage) { say("Foto tidak bisa ditandai. Pilih klip video."); return; }
        long pos = player.getCurrentPosition();
        if (pos < c.startMs || pos > c.endMs) { say("Posisi di luar potongan klip. Geser posisi dulu."); return; }
        if (selA >= 0 && pos <= selA) {
            say("Akhir harus sesudah mulai. Mulai sekarang di " + speak(selA) + ". Putar lebih jauh dulu.");
            return;
        }
        selB = pos;
        say("Akhir bagian ditandai di " + speak(pos) + ".");
    }

    private void listenSel() {
        Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (selA < 0 || selB <= selA) { say("Tandai mulai dan akhir bagian dulu."); return; }
        if (!selInside(c)) { clearSel(false); say("Tanda di luar potongan klip, tanda dihapus. Tandai ulang."); return; }
        player.seekTo(selA);
        listenStopAt = selB;
        player.play();
        updatePlayLabel();
        configureSeek(); updateInfo();
        say("Memutar bagian terpilih, " + speak(selB - selA) + ".");
    }

    /** Simpan bagian terpilih saja. Jika hanya satu tanda: mulai saja = sampai akhir klip, akhir saja = dari awal klip. */
    private void keepSel() {
        Clip c = editable();
        if (c == null) return;
        if (selA < 0 && selB < 0) { say("Tandai mulai atau akhir bagian dulu."); return; }
        if (!selInside(c)) { clearSel(false); say("Tanda di luar potongan klip, tanda dihapus. Tandai ulang."); return; }
        long a = selA >= 0 ? selA : c.startMs;
        long b = selB >= 0 ? selB : c.endMs;
        if (b - a < 200) { say("Bagian terpilih terlalu pendek."); return; }
        TimeSnap sn = takeSnap();
        c.startMs = a;
        c.endMs = b;
        remapItems(sn);
        player.pause();
        player.seekTo(a);
        clearSel(false);
        updatePlayLabel();
        rebuildList(); configureSeek(); updateInfo();
        say("Klip dipotong, hanya bagian dari " + speak(a) + " sampai " + speak(b)
                + " yang disimpan. Bisa dikembalikan dengan Urungkan.");
    }

    /** Buang bagian terpilih; bagian sebelum dan sesudahnya disambung (klip dipisah jadi dua). */
    private void removeSel() {
        Clip c = editable();
        if (c == null) return;
        if (selA < 0 || selB <= selA) { say("Tandai mulai dan akhir bagian dulu."); return; }
        if (!selInside(c)) { clearSel(false); say("Tanda di luar potongan klip, tanda dihapus. Tandai ulang."); return; }
        long a = selA, b = selB;
        if (a <= c.startMs + 100 && b >= c.endMs - 100) {
            say("Bagian terpilih mencakup seluruh klip. Gunakan Hapus klip terpilih bila ingin membuangnya.");
            return;
        }
        TimeSnap sn = takeSnap();
        if (a <= c.startMs + 100) {
            c.startMs = b;
        } else if (b >= c.endMs - 100) {
            c.endMs = a;
        } else {
            Clip second = c.copy();
            second.startMs = b;
            second.fadeInMs = 0;
            second.title = "";
            c.endMs = a;
            c.fadeOutMs = 0;
            clips.add(selected + 1, second);
        }
        remapItems(sn);
        player.pause();
        player.seekTo(Math.max(c.startMs, Math.min(c.endMs, a - 1000)));
        clearSel(false);
        updatePlayLabel();
        rebuildList(); configureSeek(); updateInfo();
        say("Bagian dari " + speak(a) + " sampai " + speak(b) + " dibuang, sisanya disambung. Sekarang "
                + clips.size() + " klip. Bisa dikembalikan dengan Urungkan.");
    }

    private void resetClip() {
        Clip c = editable();
        if (c == null) return;
        TimeSnap sn = takeSnap();
        c.startMs = 0;
        c.endMs = c.isImage ? Math.min(c.durationMs, 4000) : c.durationMs;
        remapItems(sn);
        rebuildList(); configureSeek(); updateInfo();
        say("Potongan dikembalikan penuh.");
    }

    private void deleteClip() {
        Clip c = editable();
        if (c == null) return;
        TimeSnap sn = takeSnap();
        clips.remove(selected);
        remapItems(sn);
        if (clips.isEmpty()) {
            selected = -1;
            player.clearMediaItems();
            rebuildList(); configureSeek(); updateInfo(); updatePlayLabel();
        } else {
            select(Math.min(selected, clips.size() - 1));
        }
        say("Klip dihapus. Sisa " + clips.size() + " klip.");
    }

    // ---------- efek, susun, musik ----------

    interface IntPick { void pick(int which); }

    private static final float[] SPEEDS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f};
    private static final String[] SPEED_LABELS = {"0,5 kali, lebih lambat", "0,75 kali", "1 kali, normal",
            "1,25 kali", "1,5 kali", "2 kali", "3 kali, cepat"};
    private static final float[] VOLS = {0f, 0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 2.5f, 3f};
    private static final String[] VOL_LABELS = {"0 persen, senyap", "25 persen", "50 persen", "75 persen",
            "100 persen, normal", "150 persen", "200 persen",
            "250 persen", "300 persen"};
    private static final long[] FADES = {0, 500, 1000, 2000, 3000, 5000};
    private static final String[] FADE_LABELS = {"Tanpa fade", "0,5 detik", "1 detik", "2 detik", "3 detik", "5 detik"};

    private static int indexOf(float[] arr, float v) {
        for (int i = 0; i < arr.length; i++) if (Math.abs(arr[i] - v) < 0.001f) return i;
        return -1;
    }

    private void choose(String title, String[] labels, int checked, IntPick pick) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(labels, checked, (d, which) -> { d.dismiss(); pick.pick(which); })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void applyPreview(Clip c) {
        player.setPlaybackParameters(new PlaybackParameters(c.speed, c.pitch));
        player.setVolume(c.muted ? 0f : Math.min(1f, c.volume));
    }

    private String effectSummary(Clip c) {
        StringBuilder sb = new StringBuilder();
        if (c.isImage) sb.append(", foto");
        if (Math.abs(c.speed - 1f) > 0.001f) {
            String n = c.speed == Math.floor(c.speed) ? String.valueOf((int) c.speed)
                    : String.valueOf(c.speed).replace('.', ',');
            sb.append(", kecepatan ").append(n).append(" kali");
        }
        if (c.muted) sb.append(", suara dibisukan");
        else if (Math.abs(c.volume - 1f) > 0.001f) sb.append(", volume ").append(Math.round(c.volume * 100)).append(" persen");
        if (c.fadeInMs > 0) sb.append(", fade masuk ").append(speak(c.fadeInMs));
        if (c.fadeOutMs > 0) sb.append(", fade keluar ").append(speak(c.fadeOutMs));
        if (c.rotationCw != 0) sb.append(", diputar ").append(c.rotationCw).append(" derajat");
        if (c.flipH) sb.append(", dibalik kiri kanan");
        if (c.flipV) sb.append(", dibalik atas bawah");
        if (Math.abs(c.zoom - 1f) > 0.001f) {
            sb.append(", zoom ").append(String.valueOf(c.zoom).replace(".0", "").replace('.', ',')).append(" kali");
        }
        if (c.filter > 0) sb.append(", filter ").append(FILTER_LABELS[c.filter].toLowerCase());
        if (Math.abs(c.saturation) > 0.001f) sb.append(", saturasi ").append(pct(c.saturation));
        if (Math.abs(c.hue) > 0.001f) sb.append(", rona digeser ").append(Math.round(c.hue)).append(" derajat");
        if (Math.abs(c.warmth) > 0.001f) sb.append(c.warmth > 0 ? ", lebih hangat" : ", lebih dingin");
        if (c.focus != 4) sb.append(", fokus zoom ").append(ANCHOR_LABELS[c.focus].toLowerCase());
        if (c.motion != 0) sb.append(", gerak kamera ").append(MOTION_LABELS[c.motion].toLowerCase());
        if (c.audioFx != 0) sb.append(", efek suara ").append(AUDFX_LABELS[c.audioFx].toLowerCase());
        if (Math.abs(c.pitch - 1f) > 0.001f) sb.append(c.pitch > 1f ? ", suara lebih tinggi" : ", suara lebih rendah");
        if (c.stabLevel > 0) sb.append(", stabilisasi ").append(STAB_NAMES[c.stabLevel]);
        if (Math.abs(c.brightness) > 0.001f) sb.append(", kecerahan ").append(pct(c.brightness));
        if (Math.abs(c.contrast) > 0.001f) sb.append(", kontras ").append(pct(c.contrast));
        if (c.title != null && !c.title.isEmpty()) {
            sb.append(", teks judul ").append(c.title);
            if (c.titleColor > 0) sb.append(" warna ").append(COLOR_LABELS[c.titleColor].toLowerCase());
        }
        return sb.toString();
    }

    private long totalOutMs() {
        long t = 0;
        for (Clip c : clips) t += c.outDurationMs();
        return t;
    }

    private void duplicateClip() {
        Clip c = editable();
        if (c == null) return;
        TimeSnap sn = takeSnap();
        clips.add(selected + 1, c.copy());
        remapItems(sn);
        rebuildList(); updateInfo();
        say("Klip diduplikat. Salinan ada di urutan " + (selected + 2) + ". Total " + clips.size() + " klip.");
    }

    private void moveClip(int dir) {
        Clip c = editable();
        if (c == null) return;
        int target = selected + dir;
        if (target < 0) { say("Klip sudah di urutan paling atas."); return; }
        if (target >= clips.size()) { say("Klip sudah di urutan paling bawah."); return; }
        TimeSnap sn = takeSnap();
        Collections.swap(clips, selected, target);
        selected = target;
        remapItems(sn);
        rebuildList(); updateInfo();
        say("Klip dipindah ke urutan " + (selected + 1) + " dari " + clips.size() + ".");
    }

    private void chooseSpeed() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        choose("Kecepatan klip", SPEED_LABELS, indexOf(SPEEDS, c.speed), which -> {
            TimeSnap sn = takeSnap();
            c.speed = SPEEDS[which];
            remapItems(sn);
            applyPreview(c); rebuildList(); updateInfo();
            say("Kecepatan klip diatur " + SPEED_LABELS[which] + ".");
        });
    }

    private void chooseVolume() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        choose("Volume klip", VOL_LABELS, indexOf(VOLS, c.volume), which -> {
            c.volume = VOLS[which];
            c.muted = false;
            applyPreview(c); rebuildList(); updateInfo();
            say("Volume klip diatur " + VOL_LABELS[which] + ".");
        });
    }

    private void toggleMute() {
        Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        c.muted = !c.muted;
        applyPreview(c); rebuildList(); updateInfo();
        say(c.muted ? "Suara klip dibisukan." : "Suara klip diaktifkan.");
    }

    private void chooseFade(final boolean fadeIn) {
        final Clip c = editable();
        if (c == null) return;
        long cur = fadeIn ? c.fadeInMs : c.fadeOutMs;
        int checked = 0;
        for (int i = 0; i < FADES.length; i++) if (FADES[i] == cur) checked = i;
        choose(fadeIn ? "Fade masuk klip" : "Fade keluar klip", FADE_LABELS, checked, which -> {
            long ms = FADES[which];
            if (ms > c.outDurationMs() / 2) { say("Fade terlalu panjang untuk klip ini."); return; }
            if (fadeIn) c.fadeInMs = ms; else c.fadeOutMs = ms;
            rebuildList(); updateInfo();
            say((fadeIn ? "Fade masuk " : "Fade keluar ") + FADE_LABELS[which] + ".");
        });
    }

    private void onMusicPicked(Uri u) {
        if (u == null) return;
        long d = durationOf(u);
        if (d <= 0) { say("File musik tidak bisa dibaca."); return; }
        persist(u);
        musicUri = u;
        musicName = nameOf(u);
        musicDurMs = d;
        musicStartMs = 0;
        updateMusicInfo();
        say("Musik latar dipilih: " + musicName + ".");
    }

    private void chooseMusicVolume() {
        choose("Volume musik latar", VOL_LABELS, indexOf(VOLS, musicVolume), which -> {
            musicVolume = VOLS[which];
            updateMusicInfo();
            say("Volume musik latar diatur " + VOL_LABELS[which] + ".");
        });
    }

    private void chooseMusicDuck() {
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        choose("Musik turun otomatis saat ada suara bicara", DUCK_LABELS, duckLevel, which -> {
            duckLevel = which;
            updateMusicInfo();
            say("Musik turun otomatis: " + DUCK_LABELS[which] + ". Terdengar pada hasil ekspor.");
        });
    }

    private void chooseMusicDuckSens() {
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        choose("Kepekaan deteksi suara bicara", DUCK_SENS_LABELS, duckSens, which -> {
            duckSens = which;
            updateMusicInfo();
            say("Kepekaan deteksi bicara: " + DUCK_SENS_LABELS[which] + ". Terdengar pada hasil ekspor, dan hanya bila musik turun otomatis menyala.");
        });
    }

    private void chooseMusicDuckRel() {
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        choose("Kecepatan musik naik lagi", DUCK_REL_LABELS, duckRel, which -> {
            duckRel = which;
            updateMusicInfo();
            say("Kecepatan musik naik lagi: " + DUCK_REL_LABELS[which] + ". Terdengar pada hasil ekspor, dan hanya bila musik turun otomatis menyala.");
        });
    }

    private void chooseMusicStart() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        askSeconds("Mulai musik dari detik", "Detik pada file musik, durasi penuh " + speak(musicDurMs),
                musicStartMs, sec -> {
                    long ms = (long) (sec * 1000);
                    if (ms < 0 || ms > musicDurMs - 1000) {
                        say("Harus antara 0 dan " + speak(Math.max(0, musicDurMs - 1000)) + ".");
                        return;
                    }
                    musicStartMs = ms;
                    updateMusicInfo();
                    say("Musik dimulai dari " + speak(ms) + ".");
                });
    }

    private void chooseMusicFade(final boolean fadeIn) {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        long cur = fadeIn ? musicFadeInMs : musicFadeOutMs;
        int checked = 0;
        for (int i = 0; i < FADES.length; i++) if (FADES[i] == cur) checked = i;
        choose(fadeIn ? "Fade masuk musik" : "Fade keluar musik", FADE_LABELS, checked, which -> {
            if (fadeIn) musicFadeInMs = FADES[which]; else musicFadeOutMs = FADES[which];
            updateMusicInfo();
            say((fadeIn ? "Fade masuk musik " : "Fade keluar musik ") + FADE_LABELS[which] + ".");
        });
    }

    private void removeMusic() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (musicUri == null) { say("Belum ada musik latar."); return; }
        musicUri = null;
        musicStartMs = 0; musicFadeInMs = 0; musicFadeOutMs = 0; duckLevel = 0; duckSens = 0; duckRel = 1;
        updateMusicInfo();
        say("Musik latar dihapus.");
    }

    private void updateMusicInfo() {
        if (musicUri == null) {
            musicInfo.setText("Musik latar: tidak ada.");
        } else {
            String extra = "";
            if (musicStartMs > 0) extra += ", mulai dari detik " + sec1(musicStartMs);
            if (musicFadeInMs > 0) extra += ", fade masuk " + speak(musicFadeInMs);
            if (musicFadeOutMs > 0) extra += ", fade keluar " + speak(musicFadeOutMs);
            if (duckLevel > 0) extra += ", turun otomatis saat bicara ke " + Math.round(DUCK_GAIN[duckLevel] * 100) + " persen"
                    + ", kepekaan " + DUCK_SENS_LABELS[duckSens].split(",")[0].toLowerCase(java.util.Locale.ROOT)
                    + ", naik lagi " + DUCK_REL_LABELS[duckRel].split(",")[0].toLowerCase(java.util.Locale.ROOT);
            musicInfo.setText("Musik latar: " + musicName + ", durasi " + speak(musicDurMs)
                    + ", volume " + Math.round(musicVolume * 100) + " persen" + extra + ".");
        }
    }

    // ---------- visual ----------

    private static final float[] ZOOMS = {1f, 1.25f, 1.5f, 2f, 3f};
    private static final String[] ZOOM_LABELS = {"1 kali, normal", "1,25 kali", "1,5 kali", "2 kali", "3 kali"};
    private static final float[] ADJ = {-0.5f, -0.25f, 0f, 0.25f, 0.5f};
    private static final String[] ADJ_LABELS = {"Kurangi 50 persen", "Kurangi 25 persen", "Normal",
            "Tambah 25 persen", "Tambah 50 persen"};
    private static final String[] FILTER_LABELS = {"Asli", "Hitam putih", "Hangat", "Dingin", "Negatif",
            "Sepia, foto lama", "Cerah dan hidup", "Retro pudar", "Sinematik"};
    private static final int[] COLORS = {Color.WHITE, Color.YELLOW, Color.CYAN, Color.GREEN, 0xFFFFA500};
    private static final String[] COLOR_LABELS = {"Putih", "Kuning", "Biru muda", "Hijau", "Oranye"};
    private static final int[] SUB_SIZES = {44, 64, 96};
    private static final float[] SUB_Y = {0.6f, 0f, -0.6f};
    private static final String[] SUB_BG_LABELS = {"Dengan latar hitam", "Tanpa latar"};
    private static final String[] POS_LABELS = {"Atas", "Tengah", "Bawah"};
    private static final String[] SIZE_LABELS = {"Kecil", "Sedang", "Besar"};
    private static final String[] RATIO_LABELS = {"Asli", "16:9 isi penuh, crop tengah", "16:9 muat, bingkai hitam",
            "9:16 isi penuh, crop tengah", "9:16 muat, bingkai hitam", "1:1 isi penuh, crop tengah",
            "1:1 muat, bingkai hitam", "4:3 isi penuh, crop tengah"};
    private static final float[] RATIO_VALUES = {0f, 16f / 9f, 16f / 9f, 9f / 16f, 9f / 16f, 1f, 1f, 4f / 3f};
    private static final boolean[] RATIO_CROP = {false, true, false, true, false, true, false, true};

    private String pct(float v) {
        return (v > 0 ? "tambah " : "kurang ") + Math.round(Math.abs(v) * 100) + " persen";
    }

    private void updateRatioInfo() {
        ratioInfo.setText("Rasio layar hasil: " + RATIO_LABELS[ratioIndex] + ". Latar buram: "
                + (blurBg ? "hidup" : "mati") + ".");
    }

    private void addVisualEffects(List<Effect> vfx, Clip c, long fIn, long fOut, long offsetMs) {
        if (c.stabLevel > 0 && c.stabPath != null && !c.isImage) {
            vfx.add(new StabilizeMatrix(c.stabPath, c.stabStart, c.stabStep, c.startMs, c.speed, c.stabLevel));
        }
        boolean usePan = c.focus != 4 || c.motion != 0;
        if (usePan) {
            vfx.add(new PanZoomMatrix(c.outDurationMs() * 1000, c.zoom, c.focus, c.motion));
        }
        float zs = usePan ? 1f : c.zoom;
        if (c.rotationCw != 0 || Math.abs(zs - 1f) > 0.001f || c.flipH || c.flipV) {
            vfx.add(new ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(-c.rotationCw)
                    .setScale(c.flipH ? -zs : zs, c.flipV ? -zs : zs)
                    .build());
        }
        if (c.filter == 1) {
            vfx.add(RgbFilter.createGrayscaleFilter());
        } else if (c.filter == 2) {
            vfx.add(new RgbAdjustment.Builder().setRedScale(1.2f).setBlueScale(0.85f).build());
        } else if (c.filter == 3) {
            vfx.add(new RgbAdjustment.Builder().setRedScale(0.85f).setBlueScale(1.2f).build());
        } else if (c.filter == 4) {
            vfx.add(RgbFilter.createInvertedFilter());
        }
        if (c.filter == 5) {
            vfx.add(new SepiaMatrix());
        } else if (c.filter == 6) {
            vfx.add(new HslAdjustment.Builder().adjustSaturation(35f).build());
            vfx.add(new Contrast(0.12f));
        } else if (c.filter == 7) {
            vfx.add(new HslAdjustment.Builder().adjustSaturation(-30f).build());
            vfx.add(new RgbAdjustment.Builder().setRedScale(1.08f).setBlueScale(0.92f).build());
            vfx.add(new Brightness(0.06f));
        } else if (c.filter == 8) {
            vfx.add(new HslAdjustment.Builder().adjustSaturation(-15f).build());
            vfx.add(new RgbAdjustment.Builder().setRedScale(0.95f).setBlueScale(1.08f).build());
            vfx.add(new Contrast(0.2f));
        }
        if (Math.abs(c.saturation) > 0.001f || Math.abs(c.hue) > 0.001f) {
            HslAdjustment.Builder hb = new HslAdjustment.Builder();
            if (Math.abs(c.saturation) > 0.001f) hb.adjustSaturation(c.saturation * 100f);
            if (Math.abs(c.hue) > 0.001f) hb.adjustHue(c.hue);
            vfx.add(hb.build());
        }
        if (Math.abs(c.warmth) > 0.001f) {
            vfx.add(new RgbAdjustment.Builder()
                    .setRedScale(1f + c.warmth).setBlueScale(1f - c.warmth).build());
        }
        if (Math.abs(c.brightness) > 0.001f) vfx.add(new Brightness(c.brightness));
        if (Math.abs(c.contrast) > 0.001f) vfx.add(new Contrast(c.contrast));
        if (ratioIndex > 0) {
            if (blurBg && !RATIO_CROP[ratioIndex]) {
                vfx.add(new BlurFitEffect(RATIO_VALUES[ratioIndex]));
            } else {
                vfx.add(Presentation.createForAspectRatio(RATIO_VALUES[ratioIndex],
                        RATIO_CROP[ratioIndex] ? Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                                : Presentation.LAYOUT_SCALE_TO_FIT));
            }
        }
        if (resIndex > 0) vfx.add(Presentation.createForHeight(RES_VALUES[resIndex]));
        if (c.title != null && !c.title.isEmpty()) {
            SpannableString ss = new SpannableString(c.title);
            int len = ss.length();
            ss.setSpan(new AbsoluteSizeSpan(96), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            ss.setSpan(new ForegroundColorSpan(COLORS[c.titleColor]), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            ss.setSpan(new BackgroundColorSpan(0x99000000), 0, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            float y = c.titlePos == 0 ? 0.8f : (c.titlePos == 1 ? 0f : -0.8f);
            float sc = c.titleSize == 0 ? 0.6f : (c.titleSize == 1 ? 1f : 1.5f);
            OverlaySettings os = new OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(0f, y)
                    .setOverlayFrameAnchor(0f, 0f)
                    .setScale(sc, sc)
                    .build();
            TextureOverlay overlay = TextOverlay.createStaticTextOverlay(ss, os);
            vfx.add(new OverlayEffect(ImmutableList.of(overlay)));
        }
        long clipOut = c.outDurationMs();
        List<long[]> times = new ArrayList<>();
        List<String> texts = new ArrayList<>();
        for (SubtitleItem sb : subs) {
            long st = sb.startMs - offsetMs;
            long en = sb.endMs - offsetMs;
            if (en <= 0 || st >= clipOut) continue;
            times.add(new long[]{Math.max(0, st) * 1000, Math.min(clipOut, en) * 1000});
            texts.add(sb.text);
        }
        if (!times.isEmpty()) {
            OverlaySettings subSettings = new OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(0f, SUB_Y[subPos])
                    .setOverlayFrameAnchor(0f, 0f)
                    .build();
            vfx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(
                    new SubtitleOverlay(times, texts, subSettings,
                            SUB_SIZES[subSize], COLORS[subColor], subBg))));
        }
        List<TextureOverlay> layer = new ArrayList<>();
        for (OverlayItem oi : overlays) {
            long st = oi.startMs - offsetMs;
            long en = oi.endMs - offsetMs;
            if (en <= 0 || st >= clipOut) continue;
            // anchor = baris * 3 + kolom; baris 0 atas, kolom 0 kiri
            int r = oi.anchor / 3;
            int cc = oi.anchor % 3;
            float bx = cc == 0 ? -0.95f : (cc == 1 ? 0f : 0.95f);
            float ox = cc == 0 ? -1f : (cc == 1 ? 0f : 1f);
            float by = r == 0 ? 0.92f : (r == 1 ? 0f : -0.92f);
            float oy = r == 0 ? 1f : (r == 1 ? 0f : -1f);
            int px = oi.kind == 1 ? STICKER_SIZES[oi.size] : OV_SIZES[oi.size];
            layer.add(new TimedOverlay(Math.max(0, st) * 1000, Math.min(clipOut, en) * 1000,
                    oi.text, px, COLORS[oi.color], oi.bg, bx, by, ox, oy, oi.anim));
        }
        for (ImageItem im : images) {
            long st = im.startMs - offsetMs;
            long en = im.endMs - offsetMs;
            if (en <= 0 || st >= clipOut) continue;
            Bitmap bmp = loadImage(im.uri);
            if (bmp == null) continue;
            int r = im.anchor / 3;
            int cc = im.anchor % 3;
            layer.add(new TimedImageOverlay(bmp, Math.max(0, st) * 1000, Math.min(clipOut, en) * 1000,
                    cc == 0 ? -0.95f : (cc == 1 ? 0f : 0.95f), r == 0 ? 0.92f : (r == 1 ? 0f : -0.92f),
                    cc == 0 ? -1f : (cc == 1 ? 0f : 1f), r == 0 ? 1f : (r == 1 ? 0f : -1f),
                    IMG_SCALES[im.size], IMG_OPACITY[im.opacity], im.anim));
        }
        if (!layer.isEmpty()) {
            vfx.add(new OverlayEffect(ImmutableList.copyOf(layer)));
        }
        if ((fIn > 0 || fOut > 0) && fadeWhite) {
            vfx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(
                    new FadeColorOverlay(Color.WHITE, clipOut * 1000, fIn * 1000, fOut * 1000))));
        } else if (fIn > 0 || fOut > 0) {
            vfx.add(new FadeBlackMatrix(clipOut * 1000, fIn * 1000, fOut * 1000));
        }
    }

    private void rotateClip() {
        Clip c = editable();
        if (c == null) return;
        c.rotationCw = (c.rotationCw + 90) % 360;
        rebuildList(); updateInfo();
        say(c.rotationCw == 0 ? "Putaran klip kembali normal."
                : "Klip diputar " + c.rotationCw + " derajat searah jarum jam.");
    }

    private void chooseZoom() {
        final Clip c = editable();
        if (c == null) return;
        choose("Zoom klip", ZOOM_LABELS, indexOf(ZOOMS, c.zoom), which -> {
            c.zoom = ZOOMS[which];
            rebuildList(); updateInfo();
            say("Zoom klip diatur " + ZOOM_LABELS[which] + ".");
        });
    }

    private void chooseAdjust(final boolean bright) {
        final Clip c = editable();
        if (c == null) return;
        float cur = bright ? c.brightness : c.contrast;
        choose(bright ? "Kecerahan klip" : "Kontras klip", ADJ_LABELS, indexOf(ADJ, cur), which -> {
            if (bright) c.brightness = ADJ[which]; else c.contrast = ADJ[which];
            rebuildList(); updateInfo();
            say((bright ? "Kecerahan: " : "Kontras: ") + ADJ_LABELS[which] + ".");
        });
    }

    private void chooseFilter() {
        final Clip c = editable();
        if (c == null) return;
        choose("Filter warna klip", FILTER_LABELS, c.filter, which -> {
            c.filter = which;
            rebuildList(); updateInfo();
            say("Filter warna: " + FILTER_LABELS[which] + ".");
        });
    }

    private void editTitle() {
        final Clip c = editable();
        if (c == null) return;
        final EditText et = new EditText(this);
        et.setHint("Teks judul, kosongkan untuk menghapus");
        et.setText(c.title);
        et.setSingleLine(true);
        et.setPadding(48, 32, 48, 32);
        new AlertDialog.Builder(this)
                .setTitle("Teks judul klip")
                .setView(et)
                .setPositiveButton("Simpan", (d, w) -> {
                    c.title = et.getText().toString().trim();
                    rebuildList(); updateInfo();
                    say(c.title.isEmpty() ? "Teks judul dihapus." : "Teks judul disimpan: " + c.title + ".");
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** mode 0 = posisi, 1 = ukuran, 2 = warna. */
    private void chooseTitleOption(final int mode) {
        final Clip c = editable();
        if (c == null) return;
        final String[] labels = mode == 0 ? POS_LABELS : (mode == 1 ? SIZE_LABELS : COLOR_LABELS);
        final String title = mode == 0 ? "Posisi teks judul" : (mode == 1 ? "Ukuran teks judul" : "Warna teks judul");
        int checked = mode == 0 ? c.titlePos : (mode == 1 ? c.titleSize : c.titleColor);
        choose(title, labels, checked, which -> {
            if (mode == 0) c.titlePos = which;
            else if (mode == 1) c.titleSize = which;
            else c.titleColor = which;
            rebuildList(); updateInfo();
            say(title + ": " + labels[which] + ".");
        });
    }

    private void flipClip(boolean horizontal) {
        Clip c = editable();
        if (c == null) return;
        if (horizontal) c.flipH = !c.flipH; else c.flipV = !c.flipV;
        boolean on = horizontal ? c.flipH : c.flipV;
        rebuildList(); updateInfo();
        say((horizontal ? "Balik kiri kanan " : "Balik atas bawah ") + (on ? "aktif." : "dimatikan."));
    }

    private static final String[] STAB_LABELS = {"Mati", "Ringan, goyang kecil", "Sedang, jalan kaki atau genggam", "Kuat, goyang besar"};
    private static final String[] STAB_NAMES = {"mati", "ringan", "sedang", "kuat"};

    private void chooseStabilize() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        final Clip c = current();
        if (c == null) { say("Belum ada video."); return; }
        if (c.isImage) { say("Stabilisasi hanya untuk klip video, bukan foto."); return; }
        choose("Stabilisasi video klip", STAB_LABELS, c.stabLevel, which -> {
            if (which == 0) {
                c.stabLevel = 0;
                rebuildList(); updateInfo();
                say("Stabilisasi dimatikan.");
                return;
            }
            boolean covered = c.stabPath != null && c.stabStart <= c.startMs + c.stabStep
                    && c.stabEnd >= c.endMs - c.stabStep;
            if (covered) {
                c.stabLevel = which;
                rebuildList(); updateInfo();
                say("Stabilisasi " + STAB_NAMES[which] + " aktif. Terlihat pada hasil ekspor, bukan pada pratinjau. "
                        + "Gambar diperbesar sedikit supaya tepi tidak terlihat.");
                return;
            }
            startStabAnalysis(c, which);
        });
    }

    private void startStabAnalysis(final Clip c, final int level) {
        long dur = Math.max(1, c.endMs - c.startMs);
        final long step = Math.max(100, dur / 3000);
        final int count = (int) (dur / step) + 1;
        final long start = c.startMs;
        final android.net.Uri uri = c.uri;
        stabBusy = true;
        say("Menganalisis gerak kamera, " + speak(dur) + " video. Mohon tunggu.");
        new Thread(() -> {
            float[] path = StabilizeAnalyzer.analyze(this, uri, start, step, count,
                    pct -> runOnUiThread(() -> sayQuiet("Analisis stabilisasi " + pct + " persen.")), null);
            runOnUiThread(() -> {
                stabBusy = false;
                if (path == null) { say("Analisis stabilisasi gagal. Video ini mungkin tidak bisa dibaca per bingkai."); return; }
                c.stabPath = path;
                c.stabStart = start;
                c.stabStep = step;
                c.stabEnd = start + (count - 1) * step;
                c.stabLevel = level;
                if (clips.contains(c)) { rebuildList(); updateInfo(); }
                say("Analisis selesai. Stabilisasi " + STAB_NAMES[level] + " aktif. Terlihat pada hasil ekspor, bukan pada pratinjau. "
                        + "Gambar diperbesar sedikit supaya tepi tidak terlihat.");
            });
        }).start();
    }

    private void chooseRatio() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Rasio layar hasil dan crop tengah", RATIO_LABELS, ratioIndex, which -> {
            ratioIndex = which;
            updateRatioInfo();
            say("Rasio layar hasil: " + RATIO_LABELS[which] + ".");
        });
    }

    // ---------- transisi, kualitas, subtitle, proyek ----------

    private static final long[] TRANS_MS = {0, 500, 1000, 2000};
    private static final String[] TRANS_LABELS = {"Tanpa transisi", "Memudar ke hitam 0,5 detik",
            "Memudar ke hitam 1 detik", "Memudar ke hitam 2 detik"};
    private static final int[] RES_VALUES = {0, 480, 720, 1080, 1280, 1920};
    private static final String[] RES_LABELS = {"Asli", "Tinggi 480 piksel", "Tinggi 720 piksel",
            "Tinggi 1080 piksel", "Tinggi 1280 piksel", "Tinggi 1920 piksel"};
    private static final int[] QUAL_BPS = {0, 1000000, 4000000, 8000000, 16000000};
    private static final String[] QUAL_LABELS = {"Otomatis", "Rendah, 1 Mbps", "Sedang, 4 Mbps",
            "Tinggi, 8 Mbps", "Sangat tinggi, 16 Mbps"};

    private static final String[] CODEC_MIMES = {MimeTypes.VIDEO_H264, MimeTypes.VIDEO_H265};
    private static final String[] CODEC_LABELS = {"H.264, paling kompatibel", "H.265 HEVC, file lebih kecil"};

    private void updateExportInfo() {
        exportInfo.setText("Transisi: " + TRANS_LABELS[transIndex] + ". Resolusi: " + RES_LABELS[resIndex]
                + ". Kualitas: " + QUAL_LABELS[qualIndex] + ". Format: " + CODEC_LABELS[codecIndex]
                + ". Batas ukuran file: " + (targetMb > 0 ? "sekitar " + targetMb + " MB" : "tanpa batas") + ".");
    }

    // Template media sosial: mengatur rasio layar, resolusi, kualitas, latar buram, dan batas ukuran sekaligus.
    private static final String[] TPL_LABELS = {
            "Reels, TikTok, YouTube Shorts: 9:16 isi penuh, tinggi 1920, kualitas tinggi",
            "Story dan Status WhatsApp: 9:16 muat dengan latar buram, tinggi 1280, kualitas sedang",
            "YouTube biasa: 16:9 isi penuh, tinggi 1080, kualitas tinggi",
            "Instagram kotak: 1:1 isi penuh, tinggi 1080, kualitas tinggi",
            "Kirim lewat WhatsApp, file kecil: rasio asli, tinggi 720, sekitar 16 MB",
            "Kembalikan ke pengaturan asli"};
    // ratioIndex, resIndex, qualIndex, blurBg (1 = hidup), targetMb
    private static final int[][] TPL_VALUES = {
            {3, 5, 3, 0, 0}, {4, 4, 2, 1, 0}, {1, 3, 3, 0, 0}, {5, 3, 3, 0, 0}, {0, 2, 0, 0, 16}, {0, 0, 0, 0, 0}};

    // ---------- tahap 25: ekspor siap pakai, satu tombol sesuai tujuan ----------

    private static final String[] QUICK_LABELS = {
            "Kirim lewat WhatsApp: file kecil, maksimal sekitar 16 MB",
            "Status WhatsApp: 9:16 dengan latar buram, tinggi 1280",
            "YouTube: 16:9, tinggi 1080, kualitas tinggi",
            "Shorts, Reels, TikTok: 9:16, tinggi 1920, kualitas tinggi",
            "Instagram kotak: 1:1, tinggi 1080, kualitas tinggi",
            "Hemat kuota: tinggi 480, maksimal sekitar 8 MB"};
    // ratioIndex, resIndex, qualIndex, blurBg (1 = hidup), targetMb
    private static final int[][] QUICK_VALUES = {
            {0, 2, 0, 0, 16}, {4, 4, 2, 1, 0}, {1, 3, 3, 0, 0}, {3, 5, 3, 0, 0}, {5, 3, 3, 0, 0}, {0, 1, 0, 0, 8}};

    private void chooseQuickExport() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (clips.isEmpty()) { say("Belum ada klip untuk diekspor."); return; }
        choose("Ekspor siap pakai, pilih tujuan", QUICK_LABELS, -1, which -> {
            int[] t = QUICK_VALUES[which];
            ratioIndex = t[0]; resIndex = t[1]; qualIndex = t[2]; blurBg = t[3] == 1; targetMb = t[4];
            codecIndex = 0;   // H.264 paling kompatibel untuk dibagikan
            updateRatioInfo(); updateExportInfo();
            String note = "";
            long totalMs = totalOutMs();
            if (targetMb > 0 && totalMs > 0) {
                double bps = targetMb * 1048576.0 * 8 * 0.92 / (totalMs / 1000.0) - 128000;
                if (bps < 600000) {
                    note = " Peringatan: video panjang untuk batas " + targetMb
                            + " MB, kualitas gambar akan rendah. Pertimbangkan memotong atau membagi video.";
                }
            }
            if (which == 1 && totalMs > STATUS_LIMIT_MS) {
                note += " Catatan: Status WhatsApp membatasi tiap video sampai 90 detik, video lebih panjang bisa terpotong. Pakai Potong otomatis untuk membaginya per 90 detik.";
            }
            say("Pengaturan " + QUICK_LABELS[which] + ". Ekspor dimulai." + note);
            onExportClicked(false);
        });
    }

    private void chooseTemplate() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Template media sosial", TPL_LABELS, -1, which -> {
            int[] t = TPL_VALUES[which];
            ratioIndex = t[0]; resIndex = t[1]; qualIndex = t[2]; blurBg = t[3] == 1; targetMb = t[4];
            updateRatioInfo(); updateExportInfo();
            say("Template dipakai: " + TPL_LABELS[which] + ".");
        });
    }

    private long sourceBytes(Uri u) {
        try (Cursor cur = getContentResolver().query(u, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !cur.isNull(i)) return cur.getLong(i);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    /** Kompres cepat: resolusi tetap asli, ukuran file diturunkan lewat batas ukuran, lalu langsung ekspor. */
    private void quickCompress() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        if (clips.isEmpty()) { say("Belum ada klip untuk dikompres."); return; }
        double origBytes = 0;
        for (Clip c : clips) {
            if (c.isImage || c.durationMs <= 0) continue;
            long sz = sourceBytes(c.uri);
            if (sz > 0) origBytes += sz * (double) (c.endMs - c.startMs) / c.durationMs;
        }
        final double origMb = origBytes / 1048576.0;
        final double sec = Math.max(1, totalOutMs()) / 1000.0;
        final List<String> labels = new ArrayList<>();
        final List<Integer> values = new ArrayList<>();
        if (origMb >= 2) {
            double[] fr = {0.7, 0.5, 0.3, 0.15};
            String[] nm = {"70 persen dari asli", "Setengah dari asli", "30 persen dari asli", "15 persen dari asli"};
            for (int i = 0; i < fr.length; i++) addCompressOption(labels, values, nm[i], (int) Math.max(1, Math.round(origMb * fr[i])), sec);
            int[] fixed = {25, 16, 8};
            for (int f : fixed) {
                if (f < origMb * 0.85) addCompressOption(labels, values, "Batas " + f + " MB", f, sec);
            }
        } else {
            int[] fixed = origMb > 0 ? new int[]{1} : new int[]{8, 16, 25, 50};
            for (int f : fixed) addCompressOption(labels, values, "Batas " + f + " MB", f, sec);
        }
        String title = origMb > 0
                ? "Kompres cepat. Ukuran asli sekitar " + Math.round(origMb) + " MB, resolusi tetap"
                : "Kompres cepat. Ukuran asli tidak diketahui, resolusi tetap";
        choose(title, labels.toArray(new String[0]), -1, which -> {
            resIndex = 0; qualIndex = 0; targetMb = values.get(which);
            updateExportInfo();
            say("Kompres cepat: resolusi asli, ukuran sekitar " + targetMb + " MB. Ekspor dimulai. "
                    + "Format H.265 membuat file lebih kecil pada kualitas sama, ubah di Format kompresi video jika perlu.");
            onExportClicked(false);
        });
    }

    private void addCompressOption(List<String> labels, List<Integer> values, String name, int mb, double sec) {
        double kbps = mb * 1048576.0 * 8 * 0.92 / sec / 1000.0 - 128;
        String q = kbps < 1000 ? ", kualitas rendah" : (kbps < 3000 ? ", kualitas sedang" : ", kualitas baik");
        labels.add(name + ", sekitar " + mb + " MB" + q);
        values.add(mb);
    }

    private static final int[] SIZE_MB = {0, 8, 16, 25, 50, 100};
    private static final String[] SIZE_LABELS_MB = {"Tanpa batas", "Sekitar 8 MB", "Sekitar 16 MB, batas WhatsApp",
            "Sekitar 25 MB, batas email", "Sekitar 50 MB", "Sekitar 100 MB"};

    private void chooseSizeLimit() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Batas ukuran file hasil", SIZE_LABELS_MB, indexOfInt(SIZE_MB, targetMb), which -> {
            targetMb = SIZE_MB[which]; updateExportInfo();
            say("Batas ukuran file: " + SIZE_LABELS_MB[which] + ". Bitrate dihitung dari durasi video, jadi hasil mendekati batas, bukan pasti.");
        });
    }

    private static int indexOfInt(int[] arr, int v) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return 0;
    }

    private void chooseCodec() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Format kompresi video", CODEC_LABELS, codecIndex, which -> {
            codecIndex = which; updateExportInfo();
            say("Format: " + CODEC_LABELS[which] + ".");
        });
    }

    private void chooseTransition() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Transisi antar klip", TRANS_LABELS, transIndex, which -> {
            transIndex = which; updateExportInfo();
            say("Transisi: " + TRANS_LABELS[which] + ".");
        });
    }

    private void chooseResolution() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Resolusi hasil", RES_LABELS, resIndex, which -> {
            resIndex = which; updateExportInfo();
            say("Resolusi: " + RES_LABELS[which] + ".");
        });
    }

    private void chooseQuality() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Kualitas video hasil", QUAL_LABELS, qualIndex, which -> {
            qualIndex = which; updateExportInfo();
            say("Kualitas: " + QUAL_LABELS[which] + ".");
        });
    }

    private void persist(Uri u) {
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
    }

    private long outputPositionMs() {
        Clip c = current();
        if (c == null) return 0;
        long off = 0;
        for (int i = 0; i < selected; i++) off += clips.get(i).outDurationMs();
        long within = (long) ((player.getCurrentPosition() - c.startMs) / c.speed);
        return off + Math.max(0, within);
    }

    private void addSubtitle() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (current() == null) { say("Belum ada video."); return; }
        long st = outputPositionMs();
        showSubtitleDialog(null, st, st + 3000);
    }

    private double parseSec(String t) {
        try { return Double.parseDouble(t.trim().replace(',', '.')); } catch (Exception e) { return -1; }
    }

    private void showSubtitleDialog(final SubtitleItem existing, long defStart, long defEnd) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        final EditText etText = new EditText(this);
        etText.setHint("Teks subtitle");
        final EditText etStart = new EditText(this);
        etStart.setHint("Mulai, dalam detik");
        etStart.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText etEnd = new EditText(this);
        etEnd.setHint("Selesai, dalam detik");
        etEnd.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (existing != null) etText.setText(existing.text);
        final String shownStart = String.format(Locale.US, "%.1f", defStart / 1000.0);
        final String shownEnd = String.format(Locale.US, "%.1f", defEnd / 1000.0);
        etStart.setText(shownStart);
        etEnd.setText(shownEnd);
        box.addView(etText);
        box.addView(etStart);
        box.addView(etEnd);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Tambah subtitle" : "Ubah subtitle")
                .setView(box)
                .setPositiveButton("Simpan", (d, w) -> {
                    String text = etText.getText().toString().trim();
                    double s1 = parseSec(etStart.getText().toString());
                    double s2 = parseSec(etEnd.getText().toString());
                    if (text.isEmpty()) { say("Teks subtitle kosong, tidak disimpan."); return; }
                    if (s1 < 0 || s2 <= s1) { say("Waktu tidak valid. Selesai harus setelah mulai."); return; }
                    if (existing == null) {
                        subs.add(new SubtitleItem((long) (s1 * 1000), (long) (s2 * 1000), text));
                    } else {
                        existing.text = text;
                        // Waktu yang tidak diubah pengguna dipertahankan sampai milidetik (kolom hanya menampilkan 0,1 detik).
                        if (!etStart.getText().toString().equals(shownStart)) existing.startMs = (long) (s1 * 1000);
                        if (!etEnd.getText().toString().equals(shownEnd)) existing.endMs = (long) (s2 * 1000);
                    }
                    Collections.sort(subs, (x, y) -> Long.compare(x.startMs, y.startMs));
                    rebuildSubs();
                    say("Subtitle disimpan. Total " + subs.size() + " subtitle.");
                })
                .setNegativeButton("Batal", null);
        if (existing != null) {
            b.setNeutralButton("Hapus", (d, w) -> deleteSubtitle(existing));
        }
        b.show();
    }

    private void updateSubStyleInfo() {
        subStyleInfo.setText("Gaya subtitle: ukuran " + SIZE_LABELS[subSize].toLowerCase()
                + ", posisi " + POS_LABELS[subPos].toLowerCase()
                + ", warna " + COLOR_LABELS[subColor].toLowerCase()
                + ", " + SUB_BG_LABELS[subBg ? 0 : 1].toLowerCase() + ".");
    }

    /** mode 0 = ukuran, 1 = posisi, 2 = warna, 3 = latar. */
    private void chooseSubStyle(final int mode) {
        if (exporting) { say("Sedang mengekspor."); return; }
        final String[] labels = mode == 0 ? SIZE_LABELS : (mode == 1 ? POS_LABELS
                : (mode == 2 ? COLOR_LABELS : SUB_BG_LABELS));
        final String title = mode == 0 ? "Ukuran teks subtitle" : (mode == 1 ? "Posisi subtitle"
                : (mode == 2 ? "Warna teks subtitle" : "Latar subtitle"));
        int checked = mode == 0 ? subSize : (mode == 1 ? subPos : (mode == 2 ? subColor : (subBg ? 0 : 1)));
        choose(title, labels, checked, which -> {
            if (mode == 0) subSize = which;
            else if (mode == 1) subPos = which;
            else if (mode == 2) subColor = which;
            else subBg = (which == 0);
            updateSubStyleInfo();
            say(title + ": " + labels[which] + ".");
        });
    }

    private void clearSubs() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (subs.isEmpty()) { say("Belum ada subtitle."); return; }
        int n = subs.size();
        subs.clear();
        rebuildSubs();
        say(n + " subtitle dihapus. Bisa dikembalikan dengan Urungkan.");
    }

    private void onSaveSrt(Uri u) {
        if (u == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(u)) {
            if (os == null) throw new java.io.IOException("berkas tujuan tidak bisa dibuka");
            os.write(SrtUtil.format(subs).getBytes("UTF-8"));
            say("Subtitle diekspor ke file SRT, " + subs.size() + " baris.");
        } catch (Exception e) {
            say("Gagal mengekspor subtitle: " + e.getMessage());
        }
    }

    private void onOpenSrt(Uri u) {
        if (u == null) return;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (InputStream is = getContentResolver().openInputStream(u)) {
                copy(is, bos);
            }
            List<SubtitleItem> got = SrtUtil.parse(bos.toString("UTF-8"));
            if (got.isEmpty()) { say("Tidak ada subtitle yang terbaca dari file itu."); return; }
            subs.addAll(got);
            Collections.sort(subs, (x, y) -> Long.compare(x.startMs, y.startMs));
            rebuildSubs();
            say(got.size() + " subtitle diimpor. Total " + subs.size() + " subtitle.");
        } catch (Exception e) {
            say("Gagal membaca file SRT: " + e.getMessage());
        }
    }

    private void rebuildSubs() {
        subList.removeAllViews();
        if (subs.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Belum ada subtitle.");
            t.setTextSize(16);
            subList.addView(t);
            return;
        }
        for (int i = 0; i < subs.size(); i++) {
            final SubtitleItem si = subs.get(i);
            final int num = i + 1;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = 8;
            row.setLayoutParams(rlp);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setText("Subtitle " + num + ", dari " + speak(si.startMs) + " sampai " + speak(si.endMs)
                    + ": " + si.text);
            b.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            b.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                showSubtitleDialog(si, si.startMs, si.endMs);
            });
            row.addView(b);
            Button del = new Button(this);
            del.setAllCaps(false);
            del.setText("Hapus");
            del.setContentDescription("Hapus subtitle " + num
                    + (cutsVideo(si) ? " dan potong videonya" : ""));
            del.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                deleteSubtitle(si);
            });
            row.addView(del);
            subList.addView(row);
        }
    }

    // ---------- tahap 29: edit lewat teks, hapus kalimat memotong video ----------

    /** Tanda susunan klip sekarang (sumber, awal, akhir, kecepatan, urutan). */
    private long timelineSig() {
        long h = 1125899906842597L;
        for (Clip c : clips) {
            String t = c.uri + "|" + c.startMs + "|" + c.endMs + "|" + c.speed + "|" + c.isImage + "#";
            for (int i = 0; i < t.length(); i++) h = 31 * h + t.charAt(i);
        }
        return h == 0 ? 1 : h;
    }

    private boolean cutsVideo(SubtitleItem si) {
        return si.auto && prefs().getBoolean("sub_cut", true) && si.sig == timelineSig();
    }

    private void updateSubCutButton() {
        Button b = findViewById(R.id.btnSubCutMode);
        if (b == null) return;
        b.setText("Edit lewat teks: hapus kalimat memotong video, "
                + (prefs().getBoolean("sub_cut", true) ? "aktif" : "mati"));
    }

    private void toggleSubCut() {
        boolean now = !prefs().getBoolean("sub_cut", true);
        prefs().edit().putBoolean("sub_cut", now).apply();
        updateSubCutButton();
        rebuildSubs();
        say(now ? "Edit lewat teks aktif. Menghapus kalimat dari subtitle otomatis ikut memotong video di bagian itu."
                : "Edit lewat teks mati. Menghapus subtitle hanya menghapus teksnya, video tidak dipotong.");
    }

    private void deleteSubtitle(SubtitleItem si) {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy && cutsVideo(si)) { say(BUSY_MSG); return; }
        if (!subs.contains(si)) return;
        if (si.auto && prefs().getBoolean("sub_cut", true) && si.sig != timelineSig()) {
            subs.remove(si);
            rebuildSubs();
            say("Subtitle dihapus, tetapi video tidak dipotong. Susunan klip sudah berubah sejak subtitle otomatis dibuat, "
                    + "jadi waktunya tidak cocok lagi. Buat ulang subtitle otomatis agar edit lewat teks tepat.");
            return;
        }
        if (!cutsVideo(si)) {
            subs.remove(si);
            rebuildSubs();
            say("Subtitle dihapus. Sisa " + subs.size() + " subtitle.");
            return;
        }
        long total = totalOutMs();
        long a = Math.max(0, Math.min(total, si.startMs));
        long b = Math.max(0, Math.min(total, si.endMs));
        if (b <= a) {
            subs.remove(si);
            rebuildSubs();
            say("Subtitle dihapus. Waktunya di luar video, jadi video tidak dipotong.");
            return;
        }
        if (b - a >= total - 50) {
            say("Kalimat ini mencakup seluruh video. Tidak dipotong dan tidak dihapus.");
            return;
        }
        final long ca = a, cb = b;
        final String text = si.text.replace('\n', ' ');
        subs.remove(si);
        int keep = selected;
        long removed = cutTimeline(ca, cb);
        rebuildSubs(); rebuildOverlays(); rebuildImages(); rebuildSfx();
        updateExportInfo();
        if (!clips.isEmpty()) select(Math.max(0, Math.min(keep, clips.size() - 1)));
        else { rebuildList(); configureSeek(); updateInfo(); }
        say("Kalimat dihapus dan video dipotong " + speak(removed) + ", dari " + speak(ca) + " sampai " + speak(cb)
                + ". Total video sekarang " + speak(totalOutMs()) + ". Sisa " + subs.size()
                + " subtitle. Bisa dikembalikan dengan Urungkan. Kalimat: " + text);
    }

    private static final long CUT_MIN_PIECE_MS = 80;

    // ---------- tahap 31: item waktu ikut bergeser saat klip diubah ----------

    /** Keadaan garis waktu sebelum sebuah perubahan klip, untuk memindahkan subtitle, teks, gambar, dan efek suara. */
    private static final class TimeSnap {
        final List<Clip> refs = new ArrayList<>();
        final List<Clip> copies = new ArrayList<>();
        final List<Long> offs = new ArrayList<>();
        long total = 0;
        long sig = 0;
    }

    private TimeSnap takeSnap() {
        TimeSnap s = new TimeSnap();
        long off = 0;
        for (Clip c : clips) {
            s.refs.add(c);
            s.copies.add(c.copy());
            s.offs.add(off);
            off += c.outDurationMs();
        }
        s.total = off;
        s.sig = timelineSig();
        return s;
    }

    /** Hasil pemetaan satu waktu. exact=false berarti isi di waktu itu sudah dibuang (dipindah ke tepi terdekat). */
    private static final class Mapped {
        long t;
        boolean exact;
    }

    private Mapped mapTime(TimeSnap s, long t, boolean isEnd, long[] newOff, long[] newDur, long newTotal) {
        Mapped r = new Mapped();
        r.exact = true;
        if (t <= 0) { r.t = Math.max(0, t); return r; }
        if (t >= s.total) { r.t = t - s.total + newTotal; return r; }
        int idx = -1;
        for (int i = 0; i < s.copies.size(); i++) {
            long off = s.offs.get(i), d = s.copies.get(i).outDurationMs();
            if (isEnd ? (t > off && t <= off + d) : (t >= off && t < off + d)) { idx = i; break; }
        }
        if (idx < 0) { r.t = t; return r; }
        Clip oc = s.copies.get(idx);
        long src = oc.startMs + Math.round((t - s.offs.get(idx)) * (double) oc.speed);
        String uri = oc.uri.toString();
        int hit = -1;
        for (int k = 0; k < clips.size(); k++) {
            if (clips.get(k) == s.refs.get(idx) && src >= clips.get(k).startMs && src <= clips.get(k).endMs) { hit = k; break; }
        }
        if (hit < 0) {
            for (int k = 0; k < clips.size(); k++) {
                Clip nc = clips.get(k);
                if (nc.uri.toString().equals(uri) && src >= nc.startMs && src <= nc.endMs) { hit = k; break; }
            }
        }
        if (hit >= 0) {
            Clip nc = clips.get(hit);
            long within = Math.round((src - nc.startMs) / (double) nc.speed);
            r.t = newOff[hit] + Math.max(0, Math.min(newDur[hit], within));
            return r;
        }
        r.exact = false;
        long bestDist = Long.MAX_VALUE;
        long bestT = -1;
        for (int k = 0; k < clips.size(); k++) {
            Clip nc = clips.get(k);
            if (!nc.uri.toString().equals(uri)) continue;
            long dist = src < nc.startMs ? nc.startMs - src : src - nc.endMs;
            if (dist < bestDist) {
                bestDist = dist;
                bestT = src < nc.startMs ? newOff[k] : newOff[k] + newDur[k];
            }
        }
        if (bestT >= 0) { r.t = bestT; return r; }
        // Klip itu dihapus seluruhnya: pakai awal klip berikutnya yang masih ada.
        for (int i = idx + 1; i < s.refs.size(); i++) {
            int k = clips.indexOf(s.refs.get(i));
            if (k >= 0) { r.t = newOff[k]; return r; }
        }
        r.t = newTotal;
        return r;
    }

    /** Memindahkan semua subtitle, teks, gambar tempel, dan efek suara mengikuti isi videonya setelah klip berubah. */
    private void remapItems(TimeSnap s) {
        long[] newOff = new long[clips.size()];
        long[] newDur = new long[clips.size()];
        long acc = 0;
        for (int i = 0; i < clips.size(); i++) {
            newOff[i] = acc;
            newDur[i] = clips.get(i).outDurationMs();
            acc += newDur[i];
        }
        final long newTotal = acc;
        final long newSig = timelineSig();
        if (newSig == s.sig) return;
        for (int i = subs.size() - 1; i >= 0; i--) {
            SubtitleItem it = subs.get(i);
            long ns = mapTime(s, it.startMs, false, newOff, newDur, newTotal).t;
            long ne = mapTime(s, it.endMs, true, newOff, newDur, newTotal).t;
            if (ne - ns < Math.min(100, (it.endMs - it.startMs) / 2)) { subs.remove(i); continue; }
            it.startMs = ns; it.endMs = ne;
            if (it.auto && it.sig == s.sig) it.sig = newSig;
        }
        for (int i = overlays.size() - 1; i >= 0; i--) {
            OverlayItem it = overlays.get(i);
            long ns = mapTime(s, it.startMs, false, newOff, newDur, newTotal).t;
            long ne = mapTime(s, it.endMs, true, newOff, newDur, newTotal).t;
            if (ne - ns < Math.min(100, (it.endMs - it.startMs) / 2)) { overlays.remove(i); continue; }
            it.startMs = ns; it.endMs = ne;
        }
        for (int i = images.size() - 1; i >= 0; i--) {
            ImageItem it = images.get(i);
            long ns = mapTime(s, it.startMs, false, newOff, newDur, newTotal).t;
            long ne = mapTime(s, it.endMs, true, newOff, newDur, newTotal).t;
            if (ne - ns < Math.min(100, (it.endMs - it.startMs) / 2)) { images.remove(i); continue; }
            it.startMs = ns; it.endMs = ne;
        }
        for (int i = sfxList.size() - 1; i >= 0; i--) {
            SfxItem it = sfxList.get(i);
            Mapped m = mapTime(s, it.atMs, false, newOff, newDur, newTotal);
            if (!m.exact) { sfxList.remove(i); continue; }
            it.atMs = m.t;
        }
        Collections.sort(subs, (x, y) -> Long.compare(x.startMs, y.startMs));
        Collections.sort(overlays, (x, y) -> Long.compare(x.startMs, y.startMs));
        Collections.sort(images, (x, y) -> Long.compare(x.startMs, y.startMs));
        Collections.sort(sfxList, (x, y) -> Long.compare(x.atMs, y.atMs));
        duckReady = false;
        duckSegs = null;
        rebuildSubs(); rebuildOverlays(); rebuildImages(); rebuildSfx();
    }

    /** Buang bagian a..b (milidetik, garis waktu hasil akhir) dari semua klip dan geser semua item di sesudahnya. */
    private long cutTimeline(long a, long b) {
        final long before = totalOutMs();
        final TimeSnap snap = takeSnap();
        List<Clip> out = new ArrayList<>();
        long pos = 0;
        for (Clip c : clips) {
            long d = c.outDurationMs();
            long cs = pos, ce = pos + d;
            pos = ce;
            if (ce <= a || cs >= b) { out.add(c); continue; }
            long ia = Math.max(a, cs), ib = Math.min(b, ce);
            long srcA = c.startMs + Math.round((ia - cs) * (double) c.speed);
            long srcB = c.startMs + Math.round((ib - cs) * (double) c.speed);
            srcA = Math.max(c.startMs, Math.min(c.endMs, srcA));
            srcB = Math.max(c.startMs, Math.min(c.endMs, srcB));
            boolean left = srcA - c.startMs >= CUT_MIN_PIECE_MS;
            boolean right = c.endMs - srcB >= CUT_MIN_PIECE_MS;
            if (left && right) {
                Clip r = c.copy();
                r.startMs = srcB; r.fadeInMs = 0; r.title = "";
                c.endMs = srcA; c.fadeOutMs = 0;
                out.add(c); out.add(r);
            } else if (left) {
                c.endMs = srcA; c.fadeOutMs = 0;
                out.add(c);
            } else if (right) {
                c.startMs = srcB; c.fadeInMs = 0;
                out.add(c);
            }
        }
        clips.clear();
        clips.addAll(out);
        long removed = before - totalOutMs();
        long gap = b - a;
        remapItems(snap);
        duckReady = false;
        duckSegs = null;
        return removed > 0 ? removed : gap;
    }

    private JSONObject projectToJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("versi", 2);
        JSONArray ca = new JSONArray();
        for (Clip c : clips) {
            JSONObject j = new JSONObject();
            j.put("uri", c.uri.toString());
            j.put("name", c.name);
            j.put("dur", c.durationMs);
            j.put("start", c.startMs);
            j.put("end", c.endMs);
            j.put("speed", (double) c.speed);
            j.put("volume", (double) c.volume);
            j.put("muted", c.muted);
            j.put("fadeIn", c.fadeInMs);
            j.put("fadeOut", c.fadeOutMs);
            j.put("rot", c.rotationCw);
            j.put("zoom", (double) c.zoom);
            j.put("bright", (double) c.brightness);
            j.put("contrast", (double) c.contrast);
            j.put("filter", c.filter);
            j.put("title", c.title);
            j.put("titlePos", c.titlePos);
            j.put("titleSize", c.titleSize);
            j.put("titleColor", c.titleColor);
            j.put("flipH", c.flipH);
            j.put("flipV", c.flipV);
            j.put("sat", (double) c.saturation);
            j.put("hue", (double) c.hue);
            j.put("warm", (double) c.warmth);
            j.put("pitch", (double) c.pitch);
            j.put("focus", c.focus);
            j.put("motion", c.motion);
            j.put("audioFx", c.audioFx);
            j.put("isImage", c.isImage);
            j.put("stab", c.stabLevel);
            if (c.stabPath != null) {
                j.put("stabStart", c.stabStart);
                j.put("stabStep", c.stabStep);
                j.put("stabEnd", c.stabEnd);
                JSONArray sp = new JSONArray();
                for (float f : c.stabPath) sp.put(Math.round(f * 10000) / 10000.0);
                j.put("stabPath", sp);
            }
            ca.put(j);
        }
        o.put("clips", ca);
        o.put("music", musicUri == null ? "" : musicUri.toString());
        o.put("musicName", musicName);
        o.put("musicDur", musicDurMs);
        o.put("musicVolume", (double) musicVolume);
        o.put("musicStart", musicStartMs);
        o.put("musicFadeIn", musicFadeInMs);
        o.put("musicFadeOut", musicFadeOutMs);
        o.put("musicDuck", duckLevel);
        o.put("musicDuckSens", duckSens);
        o.put("musicDuckRel", duckRel);
        o.put("ratio", ratioIndex);
        o.put("res", resIndex);
        o.put("qual", qualIndex);
        o.put("targetMb", targetMb);
        o.put("trans", transIndex);
        o.put("codec", codecIndex);
        o.put("subSize", subSize);
        o.put("subPos", subPos);
        o.put("subColor", subColor);
        o.put("subBg", subBg);
        JSONArray sa = new JSONArray();
        for (SubtitleItem si : subs) {
            JSONObject j = new JSONObject();
            j.put("start", si.startMs);
            j.put("end", si.endMs);
            j.put("text", si.text);
            if (si.auto) { j.put("auto", true); j.put("sig", si.sig); }
            sa.put(j);
        }
        o.put("subs", sa);
        JSONArray oa = new JSONArray();
        for (OverlayItem oi : overlays) {
            JSONObject j = new JSONObject();
            j.put("kind", oi.kind);
            j.put("text", oi.text);
            j.put("start", oi.startMs);
            j.put("end", oi.endMs);
            j.put("anchor", oi.anchor);
            j.put("size", oi.size);
            j.put("color", oi.color);
            j.put("bg", oi.bg);
            j.put("anim", oi.anim);
            oa.put(j);
        }
        o.put("overlays", oa);
        JSONArray sfxArrOut = new JSONArray();
        for (SfxItem sfxOut : sfxList) {
            JSONObject sfxJ = new JSONObject();
            sfxJ.put("uri", sfxOut.uri.toString());
            sfxJ.put("name", sfxOut.name);
            sfxJ.put("at", sfxOut.atMs);
            sfxJ.put("dur", sfxOut.durMs);
            sfxJ.put("volume", (double) sfxOut.volume);
            sfxArrOut.put(sfxJ);
        }
        o.put("sfx", sfxArrOut);
        o.put("blurBg", blurBg);
        JSONArray ia = new JSONArray();
        for (ImageItem im : images) {
            JSONObject j = new JSONObject();
            j.put("uri", im.uri.toString());
            j.put("name", im.name);
            j.put("start", im.startMs);
            j.put("end", im.endMs);
            j.put("anchor", im.anchor);
            j.put("size", im.size);
            j.put("opacity", im.opacity);
            j.put("anim", im.anim);
            ia.put(j);
        }
        o.put("images", ia);
        o.put("fadeWhite", fadeWhite);
        return o;
    }

    private void onSaveProject(Uri u) {
        if (u == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(u)) {
            if (os == null) throw new java.io.IOException("berkas tujuan tidak bisa dibuka");
            os.write(projectToJson().toString(2).getBytes("UTF-8"));
            say("Proyek disimpan.");
        } catch (Exception e) {
            say("Gagal menyimpan proyek: " + e.getMessage());
        }
    }

    private void onOpenProject(Uri u) {
        if (u == null) return;
        if (restorePending) { say(RESTORE_MSG); return; }
        if (stabBusy) { say(BUSY_MSG); return; }
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (InputStream is = getContentResolver().openInputStream(u)) {
                copy(is, bos);
            }
            JSONObject o = new JSONObject(bos.toString("UTF-8"));
            int missing = applyJson(o, true);
            if (missing < 0) {
                say("Tidak ada video proyek yang bisa dibuka. File video mungkin sudah dipindah.");
                return;
            }
            say("Proyek dibuka dengan " + clips.size() + " klip"
                    + (missing > 0 ? ", " + missing + " video hilang dan dilewati" : "")
                    + ". Bisa dibatalkan dengan Urungkan.");
        } catch (Exception e) {
            say("Gagal membuka proyek: " + e.getMessage());
        }
    }

    /**
     * Memasang isi proyek dari JSON. probe=true: durasi file dibaca ulang dan file yang
     * hilang dilewati (buka proyek, pulihkan simpanan otomatis). probe=false: JSON dipercaya
     * apa adanya (urungkan/ulangi). Mengembalikan jumlah file hilang, atau -1 bila tidak ada
     * satu pun klip yang bisa dimuat dari JSON yang berisi klip.
     */
    private int applyJson(JSONObject o, boolean probe) throws Exception {
        JSONArray ca = o.getJSONArray("clips");
        List<Clip> loaded = new ArrayList<>();
        int missing = 0;
        for (int i = 0; i < ca.length(); i++) {
            JSONObject j = ca.getJSONObject(i);
            Uri cu = Uri.parse(j.getString("uri"));
            boolean img = j.optBoolean("isImage", false);
            long d = img ? j.optLong("dur", 30000) : (probe ? durationOf(cu) : j.optLong("dur", 0));
            if (d <= 0) { missing++; continue; }
            long st = Math.max(0, Math.min(d, j.optLong("start", 0)));
            long en = Math.max(0, Math.min(d, j.optLong("end", d)));
            if (en <= st) { st = 0; en = d; }
            Clip c = new Clip(cu, j.optString("name", "video"), d, st, en);
            c.isImage = img;
            c.speed = img ? 1f : (float) j.optDouble("speed", 1);
            c.volume = (float) j.optDouble("volume", 1);
            c.muted = j.optBoolean("muted", false);
            c.fadeInMs = j.optLong("fadeIn", 0);
            c.fadeOutMs = j.optLong("fadeOut", 0);
            c.rotationCw = j.optInt("rot", 0);
            c.zoom = (float) j.optDouble("zoom", 1);
            c.brightness = (float) j.optDouble("bright", 0);
            c.contrast = (float) j.optDouble("contrast", 0);
            c.filter = Math.max(0, Math.min(FILTER_LABELS.length - 1, j.optInt("filter", 0)));
            c.title = j.optString("title", "");
            c.titlePos = Math.max(0, Math.min(2, j.optInt("titlePos", 2)));
            c.titleSize = Math.max(0, Math.min(2, j.optInt("titleSize", 1)));
            c.titleColor = Math.max(0, Math.min(COLORS.length - 1, j.optInt("titleColor", 0)));
            c.flipH = j.optBoolean("flipH", false);
            c.flipV = j.optBoolean("flipV", false);
            c.saturation = (float) Math.max(-1, Math.min(1, j.optDouble("sat", 0)));
            c.hue = (float) Math.max(0, Math.min(360, j.optDouble("hue", 0)));
            c.warmth = (float) Math.max(-0.5, Math.min(0.5, j.optDouble("warm", 0)));
            c.pitch = (float) Math.max(0.5, Math.min(2, j.optDouble("pitch", 1)));
            c.focus = Math.max(0, Math.min(8, j.optInt("focus", 4)));
            c.motion = Math.max(0, Math.min(MOTION_LABELS.length - 1, j.optInt("motion", 0)));
            c.audioFx = j.optInt("audioFx", 0);
            if (c.audioFx < 0 || c.audioFx >= AUDFX_LABELS.length) c.audioFx = 0; // pilihan lama yang sudah dihapus jadi Normal
            JSONArray spj = j.optJSONArray("stabPath");
            if (spj != null && spj.length() >= 2 && spj.length() % 2 == 0) {
                float[] sp = new float[spj.length()];
                for (int q = 0; q < sp.length; q++) sp[q] = (float) spj.optDouble(q, 0);
                c.stabPath = sp;
                c.stabStart = j.optLong("stabStart", 0);
                c.stabStep = Math.max(1, j.optLong("stabStep", 100));
                c.stabEnd = j.optLong("stabEnd", c.stabStart + (sp.length / 2 - 1) * c.stabStep);
                c.stabLevel = Math.max(0, Math.min(3, j.optInt("stab", 0)));
            }
            loaded.add(c);
        }
        if (loaded.isEmpty() && ca.length() > 0) return -1;

        boolean wasRestoring = restoring;
        restoring = true;
        try {
            int keep = probe ? 0 : Math.max(0, selected);
            clips.clear();
            clips.addAll(loaded);
            subs.clear();
            JSONArray sa = o.optJSONArray("subs");
            if (sa != null) {
                for (int i = 0; i < sa.length(); i++) {
                    JSONObject j = sa.getJSONObject(i);
                    SubtitleItem sLoaded = new SubtitleItem(j.optLong("start", 0), j.optLong("end", 0), j.optString("text", ""));
                    sLoaded.auto = j.optBoolean("auto", false);
                    sLoaded.sig = j.optLong("sig", 0);
                    subs.add(sLoaded);
                }
            }
            fadeWhite = o.optBoolean("fadeWhite", false);
            images.clear();
            JSONArray ia = o.optJSONArray("images");
            if (ia != null) {
                for (int i = 0; i < ia.length(); i++) {
                    JSONObject j = ia.getJSONObject(i);
                    ImageItem im = new ImageItem(Uri.parse(j.optString("uri", "")),
                            j.optString("name", "gambar"), j.optLong("start", 0), j.optLong("end", 0));
                    im.anchor = Math.max(0, Math.min(8, j.optInt("anchor", 2)));
                    im.size = Math.max(0, Math.min(IMG_SCALES.length - 1, j.optInt("size", 1)));
                    im.opacity = Math.max(0, Math.min(IMG_OPACITY.length - 1, j.optInt("opacity", 3)));
                    im.anim = Math.max(0, Math.min(3, j.optInt("anim", 0)));
                    if (j.optString("uri", "").length() > 0 && im.endMs > im.startMs) images.add(im);
                }
            }
            sfxList.clear();
            JSONArray sfxArrIn = o.optJSONArray("sfx");
            if (sfxArrIn != null) {
                for (int sfxIdx = 0; sfxIdx < sfxArrIn.length(); sfxIdx++) {
                    JSONObject sfxJ = sfxArrIn.getJSONObject(sfxIdx);
                    String sfxU = sfxJ.optString("uri", "");
                    if (sfxU.isEmpty()) continue;
                    SfxItem sfxIt = new SfxItem(Uri.parse(sfxU), sfxJ.optString("name", "efek suara"),
                            sfxJ.optLong("at", 0), sfxJ.optLong("dur", 0));
                    sfxIt.volume = (float) sfxJ.optDouble("volume", 1);
                    sfxList.add(sfxIt);
                }
            }
            blurBg = o.optBoolean("blurBg", false);
            overlays.clear();
            JSONArray oa = o.optJSONArray("overlays");
            if (oa != null) {
                for (int i = 0; i < oa.length(); i++) {
                    JSONObject j = oa.getJSONObject(i);
                    OverlayItem oi = new OverlayItem(Math.max(0, Math.min(1, j.optInt("kind", 0))),
                            j.optString("text", ""), j.optLong("start", 0), j.optLong("end", 0));
                    oi.anchor = Math.max(0, Math.min(8, j.optInt("anchor", 4)));
                    oi.size = Math.max(0, Math.min(3, j.optInt("size", 1)));
                    oi.color = Math.max(0, Math.min(COLORS.length - 1, j.optInt("color", 0)));
                    oi.bg = j.optBoolean("bg", false);
                    oi.anim = Math.max(0, Math.min(3, j.optInt("anim", 0)));
                    if (!oi.text.isEmpty() && oi.endMs > oi.startMs) overlays.add(oi);
                }
            }
            musicUri = null;
            musicName = "";
            musicDurMs = 0;
            String mu = o.optString("music", "");
            if (!mu.isEmpty()) {
                Uri m = Uri.parse(mu);
                long md = probe ? durationOf(m) : o.optLong("musicDur", 0);
                if (md > 0) {
                    musicUri = m;
                    musicDurMs = md;
                    musicName = o.optString("musicName", "musik");
                }
            }
            musicVolume = (float) o.optDouble("musicVolume", 0.5);
            musicStartMs = Math.max(0, o.optLong("musicStart", 0));
            if (musicUri != null && musicStartMs > musicDurMs - 1000) musicStartMs = 0;
            musicFadeInMs = Math.max(0, o.optLong("musicFadeIn", 0));
            musicFadeOutMs = Math.max(0, o.optLong("musicFadeOut", 0));
            duckLevel = Math.max(0, Math.min(DUCK_GAIN.length - 1, o.optInt("musicDuck", 0)));
            duckSens = DuckDetect.clampSens(o.optInt("musicDuckSens", 0));
            duckRel = DuckDetect.clampRel(o.optInt("musicDuckRel", 1));
            ratioIndex = Math.max(0, Math.min(RATIO_LABELS.length - 1, o.optInt("ratio", 0)));
            resIndex = Math.max(0, Math.min(RES_LABELS.length - 1, o.optInt("res", 0)));
            qualIndex = Math.max(0, Math.min(QUAL_LABELS.length - 1, o.optInt("qual", 0)));
            targetMb = Math.max(0, o.optInt("targetMb", 0));
            transIndex = Math.max(0, Math.min(TRANS_LABELS.length - 1, o.optInt("trans", 0)));
            codecIndex = Math.max(0, Math.min(CODEC_LABELS.length - 1, o.optInt("codec", 0)));
            subSize = Math.max(0, Math.min(SIZE_LABELS.length - 1, o.optInt("subSize", 1)));
            subPos = Math.max(0, Math.min(POS_LABELS.length - 1, o.optInt("subPos", 2)));
            subColor = Math.max(0, Math.min(COLORS.length - 1, o.optInt("subColor", 0)));
            subBg = o.optBoolean("subBg", true);

            if (clips.isEmpty()) {
                selected = -1;
                player.clearMediaItems();
                player.setPlaybackParameters(new PlaybackParameters(1f));
                player.setVolume(1f);
                rebuildList(); configureSeek(); updateInfo(); updatePlayLabel();
            } else {
                selected = -1;
                select(Math.min(keep, clips.size() - 1));
            }
            updateMusicInfo(); updateRatioInfo(); updateExportInfo(); updateSubStyleInfo(); rebuildSubs(); rebuildOverlays(); rebuildImages(); rebuildSfx();
        } finally {
            restoring = wasRestoring;
        }
        return missing;
    }

    // ---------- urungkan, ulangi, simpan otomatis, proyek baru ----------

    private File autosaveFile() {
        return new File(getFilesDir(), "autosave.json");
    }

    private void trackChange() {
        if (restoring || queueRunning) return;
        String now;
        try {
            now = projectToJson().toString();
        } catch (Exception e) {
            return;
        }
        if (now.equals(currentJson)) return;
        undoStack.addLast(currentJson);
        while (undoStack.size() > 50) undoStack.removeFirst();
        redoStack.clear();
        currentJson = now;
        writeAutosave(now);
    }

    private void writeAutosave(String json) {
        if (true) return; // tahap 40: simpan otomatis dimatikan
        try {
            File tmp = new File(getFilesDir(), "autosave.tmp");
            try (OutputStream os = new FileOutputStream(tmp)) {
                os.write(json.getBytes("UTF-8"));
            }
            if (!tmp.renameTo(autosaveFile())) {
                autosaveFile().delete();
                tmp.renameTo(autosaveFile());
            }
        } catch (Exception ignored) { }
    }

    private void restoreAutosave() {
        JSONObject parsed = null;
        try {
            // tahap 40: simpan otomatis dimatikan; sisa berkas lama dihapus dan tidak dipulihkan.
            File f = autosaveFile();
            if (f.exists()) f.delete();
            new File(getFilesDir(), "autosave.tmp").delete();
        } catch (Exception ignored) { }
        try {
            currentJson = projectToJson().toString();
        } catch (Exception e) {
            currentJson = "";
        }
        if (parsed == null) return;
        final JSONObject o = parsed;
        // Durasi file dibaca di latar belakang supaya aplikasi tidak macet saat dibuka dengan banyak klip.
        final List<Uri> uris = new ArrayList<>();
        try {
            JSONArray ca = o.optJSONArray("clips");
            if (ca != null) {
                for (int i = 0; i < ca.length(); i++) {
                    JSONObject j = ca.getJSONObject(i);
                    if (!j.optBoolean("isImage", false)) uris.add(Uri.parse(j.getString("uri")));
                }
            }
            String mu = o.optString("music", "");
            if (!mu.isEmpty()) uris.add(Uri.parse(mu));
        } catch (Exception ignored) { }
        restorePending = true;
        sayQuiet("Memulihkan proyek terakhir.");
        new Thread(() -> {
            final java.util.HashMap<String, Long> map = new java.util.HashMap<>();
            for (Uri u : uris) {
                if (!map.containsKey(u.toString())) map.put(u.toString(), durationOf(u));
            }
            runOnUiThread(() -> finishRestore(o, map));
        }).start();
    }

    private void finishRestore(JSONObject o, java.util.Map<String, Long> map) {
        if (isFinishing() || isDestroyed()) return;
        String msg = null;
        restoring = true;
        durCache = map;
        try {
            int missing = applyJson(o, true);
            if (missing >= 0 && !clips.isEmpty()) {
                msg = "Proyek terakhir dipulihkan, " + clips.size() + " klip"
                        + (missing > 0 ? ", " + missing + " video hilang dan dilewati" : "") + ".";
            }
        } catch (Exception ignored) {
        } finally {
            durCache = null;
            restoring = false;
            restorePending = false;
        }
        try {
            currentJson = projectToJson().toString();
        } catch (Exception e) {
            currentJson = "";
        }
        sayQuiet(msg != null ? msg : "Proyek baru.");
        if (deferredIntent != null) {
            Intent d = deferredIntent;
            deferredIntent = null;
            handleIncoming(d);
        }
    }

    private void undo() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (restorePending) { say(RESTORE_MSG); return; }
        if (stabBusy) { say(BUSY_MSG); return; }
        if (undoStack.isEmpty()) { say("Tidak ada yang bisa diurungkan."); return; }
        String prev = undoStack.removeLast();
        if (!restoreSnapshot(prev)) {
            undoStack.addLast(prev);
            say("Gagal mengurungkan.");
            return;
        }
        redoStack.addLast(currentJson);
        currentJson = prev;
        writeAutosave(prev);
        sayQuiet("Dibatalkan. " + undoStack.size() + " langkah lagi bisa diurungkan, "
                + redoStack.size() + " bisa diulangi.");
    }

    private void redo() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say(BUSY_MSG); return; }
        if (redoStack.isEmpty()) { say("Tidak ada yang bisa diulangi."); return; }
        String next = redoStack.removeLast();
        if (!restoreSnapshot(next)) {
            redoStack.addLast(next);
            say("Gagal mengulangi.");
            return;
        }
        undoStack.addLast(currentJson);
        currentJson = next;
        writeAutosave(next);
        sayQuiet("Diulangi. " + undoStack.size() + " langkah bisa diurungkan, "
                + redoStack.size() + " lagi bisa diulangi.");
    }

    private boolean restoreSnapshot(String json) {
        try {
            if (json == null || json.isEmpty()) {
                json = "{\"clips\":[]}";
            }
            applyJson(new JSONObject(json), false);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void newProject() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (restorePending) { say(RESTORE_MSG); return; }
        if (stabBusy) { say(BUSY_MSG); return; }
        if (recorder != null) stopRecording();
        clips.clear();
        subs.clear();
        overlays.clear();
        sfxList.clear();
        blurBg = false;
        images.clear();
        fadeWhite = false;
        musicUri = null; musicName = ""; musicDurMs = 0; musicVolume = 0.5f;
        musicStartMs = 0; musicFadeInMs = 0; musicFadeOutMs = 0; duckLevel = 0; duckSens = 0; duckRel = 1;
        ratioIndex = 0; resIndex = 0; qualIndex = 0; targetMb = 0; transIndex = 0; codecIndex = 0;
        subSize = 1; subPos = 2; subColor = 0; subBg = true;
        selected = -1;
        player.clearMediaItems();
        player.setPlaybackParameters(new PlaybackParameters(1f));
        player.setVolume(1f);
        rebuildList(); configureSeek(); updateInfo(); updatePlayLabel();
        updateMusicInfo(); updateRatioInfo(); updateExportInfo(); updateSubStyleInfo(); rebuildSubs(); rebuildOverlays(); rebuildImages(); rebuildSfx();
        say("Proyek baru, semuanya dikosongkan. Bisa dikembalikan dengan Urungkan.");
    }

    private void showSummary() {
        StringBuilder sb = new StringBuilder();
        if (clips.isEmpty()) {
            sb.append("Belum ada klip.\n");
        } else {
            sb.append(clips.size()).append(" klip, total durasi hasil sekitar ")
                    .append(speak(totalOutMs())).append(".\n");
            for (int i = 0; i < clips.size(); i++) {
                Clip c = clips.get(i);
                sb.append("Klip ").append(i + 1).append(": ").append(c.name)
                        .append(", durasi hasil ").append(speak(c.outDurationMs()))
                        .append(effectSummary(c)).append(".\n");
            }
        }
        sb.append(musicInfo.getText()).append("\n");
        sb.append(subs.isEmpty() ? "Belum ada subtitle." : subs.size() + " subtitle.").append("\n");
        sb.append(overlays.isEmpty() ? "Belum ada teks atau stiker berlapis." : overlays.size() + " teks dan stiker berlapis.").append("\n");
        sb.append(sfxList.isEmpty() ? "Belum ada efek suara tambahan." : sfxList.size() + " efek suara tambahan.").append("\n");
        sb.append(images.isEmpty() ? "Belum ada gambar tempel." : images.size() + " gambar tempel.").append("\n");
        sb.append("Rasio layar: ").append(RATIO_LABELS[ratioIndex]).append(". Latar buram ").append(blurBg ? "hidup" : "mati").append(".\n");
        sb.append(exportInfo.getText());
        say("Ringkasan proyek ditampilkan.");
        new AlertDialog.Builder(this)
                .setTitle("Ringkasan proyek")
                .setMessage(sb.toString())
                .setPositiveButton("Tutup", null)
                .show();
    }


    // ---------- tahap 6: penyesuaian warna, nada suara, teks dan stiker berlapis ----------

    private static final float[] SATS = {-1f, -0.5f, 0f, 0.25f, 0.5f, 1f};
    private static final String[] SAT_LABELS = {"Tanpa warna, hitam putih", "Kurangi 50 persen", "Normal",
            "Tambah 25 persen", "Tambah 50 persen", "Tambah 100 persen"};
    private static final float[] HUES = {0f, 30f, 60f, 90f, 180f, 270f, 330f};
    private static final String[] HUE_LABELS = {"Normal", "Geser 30 derajat", "Geser 60 derajat",
            "Geser 90 derajat", "Balik warna, geser 180 derajat", "Geser 270 derajat", "Geser 330 derajat"};
    private static final float[] WARMS = {-0.2f, -0.1f, 0f, 0.1f, 0.2f};
    private static final String[] WARM_LABELS = {"Sangat dingin, kebiruan", "Sedikit dingin", "Normal",
            "Sedikit hangat", "Sangat hangat, kekuningan"};
    private static final float[] PITCHES = {0.7f, 0.85f, 1f, 1.2f, 1.4f};
    private static final String[] PITCH_LABELS = {"Sangat rendah, suara berat", "Rendah", "Normal",
            "Tinggi", "Sangat tinggi, suara cempreng"};
    private static final int[] OV_SIZES = {48, 72, 110, 160};
    private static final int[] STICKER_SIZES = {110, 170, 250, 340};
    private static final String[] OV_SIZE_LABELS = {"Kecil", "Sedang", "Besar", "Sangat besar"};
    private static final String[] ANCHOR_LABELS = {"Kiri atas", "Tengah atas", "Kanan atas",
            "Kiri tengah", "Tengah layar", "Kanan tengah", "Kiri bawah", "Tengah bawah", "Kanan bawah"};
    private static final String[] ANIM_LABELS = {"Langsung muncul", "Muncul dan hilang perlahan",
            "Geser naik", "Zoom masuk"};
    private static final String[] STICKERS = {
            "\ud83d\ude00",
            "\ud83d\ude02",
            "\ud83d\ude0d",
            "\ud83d\ude0e",
            "\ud83d\ude22",
            "\ud83d\ude21",
            "\ud83d\udc4d",
            "\ud83d\udc4f",
            "\ud83d\ude4f",
            "\ud83d\udd25",
            "\u2764\ufe0f",
            "\u2b50",
            "\ud83c\udf89",
            "\ud83c\udfb5",
            "\ud83d\udccd",
            "\u26a0\ufe0f",
            "\u2705",
            "\u274c",
            "\u27a1\ufe0f",
            "\u2b05\ufe0f",
            "\u2b06\ufe0f",
            "\u2b07\ufe0f",
            "\ud83d\udcaf",
            "\ud83c\udfac"};
    private static final String[] STICKER_NAMES = {
            "Senyum",
            "Tertawa",
            "Suka sekali",
            "Keren",
            "Sedih",
            "Marah",
            "Jempol",
            "Tepuk tangan",
            "Terima kasih",
            "Api",
            "Hati",
            "Bintang",
            "Pesta",
            "Musik",
            "Lokasi",
            "Peringatan",
            "Centang",
            "Silang",
            "Panah kanan",
            "Panah kiri",
            "Panah atas",
            "Panah bawah",
            "Seratus",
            "Klapper film"};

    private void choosePitch() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        choose("Nada suara klip", PITCH_LABELS, indexOf(PITCHES, c.pitch), which -> {
            c.pitch = PITCHES[which];
            rebuildList(); updateInfo();
            applyPreview(c);
            say("Nada suara: " + PITCH_LABELS[which] + ".");
        });
    }

    /** mode 0 = saturasi, 1 = rona, 2 = suhu warna. */
    private void chooseColorTweak(final int mode) {
        final Clip c = editable();
        if (c == null) return;
        final float[] vals = mode == 0 ? SATS : (mode == 1 ? HUES : WARMS);
        final String[] labels = mode == 0 ? SAT_LABELS : (mode == 1 ? HUE_LABELS : WARM_LABELS);
        final String title = mode == 0 ? "Saturasi warna klip" : (mode == 1 ? "Rona warna klip" : "Suhu warna klip");
        float cur = mode == 0 ? c.saturation : (mode == 1 ? c.hue : c.warmth);
        choose(title, labels, indexOf(vals, cur), which -> {
            if (mode == 0) c.saturation = vals[which];
            else if (mode == 1) c.hue = vals[which];
            else c.warmth = vals[which];
            rebuildList(); updateInfo();
            say(title + ": " + labels[which] + ".");
        });
    }

    private void addOverlay(int kind) {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (current() == null) { say("Belum ada video."); return; }
        long st = outputPositionMs();
        showOverlayDialog(null, kind, st, st + 3000);
    }

    private Spinner addSpinner(LinearLayout box, String label, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(16);
        t.setPadding(0, 16, 0, 0);
        box.addView(t);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        sp.setSelection(sel);
        sp.setContentDescription(label);
        box.addView(sp);
        return sp;
    }

    private void showOverlayDialog(final OverlayItem existing, final int kind, long defStart, long defEnd) {
        final boolean sticker = existing != null ? existing.kind == 1 : kind == 1;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        final EditText etText = new EditText(this);
        etText.setHint(sticker ? "Emoji stiker" : "Teks");
        if (existing != null) etText.setText(existing.text);
        box.addView(etText);
        if (sticker) {
            Button pick = new Button(this);
            pick.setAllCaps(false);
            pick.setText("Pilih stiker dari daftar");
            pick.setOnClickListener(v -> choose("Pilih stiker", STICKER_NAMES, -1,
                    which -> etText.setText(STICKERS[which])));
            box.addView(pick);
        }
        final EditText etStart = new EditText(this);
        etStart.setHint("Mulai, dalam detik");
        etStart.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etStart.setText(String.format(Locale.US, "%.1f", defStart / 1000.0));
        final EditText etEnd = new EditText(this);
        etEnd.setHint("Selesai, dalam detik");
        etEnd.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etEnd.setText(String.format(Locale.US, "%.1f", defEnd / 1000.0));
        box.addView(etStart);
        box.addView(etEnd);
        final Spinner spPos = addSpinner(box, "Posisi", ANCHOR_LABELS,
                existing != null ? existing.anchor : (sticker ? 2 : 7));
        final Spinner spSize = addSpinner(box, "Ukuran", OV_SIZE_LABELS,
                existing != null ? existing.size : (sticker ? 1 : 1));
        final Spinner spColor = addSpinner(box, "Warna teks", COLOR_LABELS, existing != null ? existing.color : 0);
        final Spinner spAnim = addSpinner(box, "Animasi masuk", ANIM_LABELS, existing != null ? existing.anim : 0);
        final CheckBox cbBg = new CheckBox(this);
        cbBg.setText("Latar hitam di belakang teks");
        cbBg.setChecked(existing != null ? existing.bg : !sticker);
        box.addView(cbBg);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? (sticker ? "Tambah stiker" : "Tambah teks") : "Ubah teks atau stiker")
                .setView(sv)
                .setPositiveButton("Simpan", (d, w) -> {
                    String text = etText.getText().toString().trim();
                    double s1 = parseSec(etStart.getText().toString());
                    double s2 = parseSec(etEnd.getText().toString());
                    if (text.isEmpty()) { say("Isi kosong, tidak disimpan."); return; }
                    if (s1 < 0 || s2 <= s1) { say("Waktu tidak valid. Selesai harus setelah mulai."); return; }
                    OverlayItem oi = existing != null ? existing : new OverlayItem(sticker ? 1 : 0, text, 0, 0);
                    oi.text = text;
                    oi.startMs = (long) (s1 * 1000);
                    oi.endMs = (long) (s2 * 1000);
                    oi.anchor = spPos.getSelectedItemPosition();
                    oi.size = spSize.getSelectedItemPosition();
                    oi.color = spColor.getSelectedItemPosition();
                    oi.anim = spAnim.getSelectedItemPosition();
                    oi.bg = cbBg.isChecked();
                    if (existing == null) overlays.add(oi);
                    Collections.sort(overlays, (x, y) -> Long.compare(x.startMs, y.startMs));
                    rebuildOverlays();
                    say("Disimpan. Total " + overlays.size() + " teks dan stiker berlapis.");
                })
                .setNegativeButton("Batal", null);
        if (existing != null) {
            b.setNeutralButton("Hapus", (d, w) -> {
                overlays.remove(existing);
                rebuildOverlays();
                say("Dihapus. Sisa " + overlays.size() + " teks dan stiker berlapis.");
            });
        }
        b.show();
    }

    private void rebuildOverlays() {
        overlayList.removeAllViews();
        if (overlays.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Belum ada teks atau stiker berlapis.");
            t.setTextSize(16);
            overlayList.addView(t);
            return;
        }
        for (int i = 0; i < overlays.size(); i++) {
            final OverlayItem oi = overlays.get(i);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setText((oi.kind == 1 ? "Stiker " : "Teks ") + (i + 1) + ", dari " + speak(oi.startMs)
                    + " sampai " + speak(oi.endMs) + ", " + ANCHOR_LABELS[oi.anchor].toLowerCase()
                    + ", " + ANIM_LABELS[oi.anim].toLowerCase() + ": " + oi.text);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                showOverlayDialog(oi, oi.kind, oi.startMs, oi.endMs);
            });
            overlayList.addView(b);
        }
    }

    private void clearOverlays() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (overlays.isEmpty()) { say("Belum ada teks atau stiker berlapis."); return; }
        int n = overlays.size();
        overlays.clear();
        rebuildOverlays();
        say(n + " teks dan stiker dihapus. Bisa dikembalikan dengan Urungkan.");
    }


    // ---------- tahap 7: gambar tempel ----------

    private static final float[] IMG_SCALES = {0.15f, 0.3f, 0.5f, 1f};
    private static final String[] IMG_SIZE_LABELS = {"Kecil, seperti logo", "Sedang", "Besar", "Penuh lebar layar"};
    private static final float[] IMG_OPACITY = {0.25f, 0.5f, 0.75f, 1f};
    private static final String[] IMG_OPACITY_LABELS = {"25 persen, sangat samar", "50 persen, transparan",
            "75 persen", "100 persen, jelas"};

    private Bitmap loadImage(Uri u) {
        String key = u.toString();
        Bitmap cached = imgCache.get(key);
        if (cached != null) return cached;
        try {
            BitmapFactory.Options bo = new BitmapFactory.Options();
            bo.inJustDecodeBounds = true;
            try (InputStream is = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(is, null, bo);
            }
            if (bo.outWidth <= 0 || bo.outHeight <= 0) return null;
            int sample = 1;
            while (bo.outWidth / (sample * 2) >= 720) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap raw;
            try (InputStream is = getContentResolver().openInputStream(u)) {
                raw = BitmapFactory.decodeStream(is, null, o2);
            }
            if (raw == null) return null;
            int w = 720;
            int h = Math.max(1, Math.round(raw.getHeight() * (w / (float) raw.getWidth())));
            Bitmap out = Bitmap.createScaledBitmap(raw, w, h, true);
            imgCache.put(key, out);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    private void onImagePicked(Uri u) {
        if (u == null) return;
        persist(u);
        ImageItem im = new ImageItem(u, nameOf(u), pendingImgStartMs, pendingImgStartMs + 4000);
        showImageDialog(im, true);
    }

    private void showImageDialog(final ImageItem im, final boolean isNew) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        TextView nm = new TextView(this);
        nm.setText("Gambar: " + im.name);
        nm.setTextSize(16);
        box.addView(nm);
        final EditText etStart = new EditText(this);
        etStart.setHint("Mulai, dalam detik");
        etStart.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etStart.setText(String.format(Locale.US, "%.1f", im.startMs / 1000.0));
        final EditText etEnd = new EditText(this);
        etEnd.setHint("Selesai, dalam detik");
        etEnd.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etEnd.setText(String.format(Locale.US, "%.1f", im.endMs / 1000.0));
        box.addView(etStart);
        box.addView(etEnd);
        final Spinner spPos = addSpinner(box, "Posisi", ANCHOR_LABELS, im.anchor);
        final Spinner spSize = addSpinner(box, "Ukuran", IMG_SIZE_LABELS, im.size);
        final Spinner spOp = addSpinner(box, "Transparansi", IMG_OPACITY_LABELS, im.opacity);
        final Spinner spAnim = addSpinner(box, "Animasi masuk", ANIM_LABELS, im.anim);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(isNew ? "Tambah gambar tempel" : "Ubah gambar tempel")
                .setView(sv)
                .setPositiveButton("Simpan", (d, w) -> {
                    double s1 = parseSec(etStart.getText().toString());
                    double s2 = parseSec(etEnd.getText().toString());
                    if (s1 < 0 || s2 <= s1) { say("Waktu tidak valid. Selesai harus setelah mulai."); return; }
                    im.startMs = (long) (s1 * 1000);
                    im.endMs = (long) (s2 * 1000);
                    im.anchor = spPos.getSelectedItemPosition();
                    im.size = spSize.getSelectedItemPosition();
                    im.opacity = spOp.getSelectedItemPosition();
                    im.anim = spAnim.getSelectedItemPosition();
                    if (isNew) images.add(im);
                    Collections.sort(images, (x, y) -> Long.compare(x.startMs, y.startMs));
                    rebuildImages();
                    say("Gambar tempel disimpan. Total " + images.size() + " gambar.");
                })
                .setNegativeButton("Batal", null);
        if (!isNew) {
            b.setNeutralButton("Hapus", (d, w) -> {
                images.remove(im);
                rebuildImages();
                say("Gambar tempel dihapus. Sisa " + images.size() + " gambar.");
            });
        }
        b.show();
    }

    private void rebuildImages() {
        imageList.removeAllViews();
        if (images.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Belum ada gambar tempel.");
            t.setTextSize(16);
            imageList.addView(t);
            return;
        }
        for (int i = 0; i < images.size(); i++) {
            final ImageItem im = images.get(i);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setText("Gambar " + (i + 1) + ", dari " + speak(im.startMs) + " sampai " + speak(im.endMs)
                    + ", " + ANCHOR_LABELS[im.anchor].toLowerCase() + ": " + im.name);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (exporting) { say("Sedang mengekspor."); return; }
                showImageDialog(im, false);
            });
            imageList.addView(b);
        }
    }

    private void clearImages() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (images.isEmpty()) { say("Belum ada gambar tempel."); return; }
        int n = images.size();
        images.clear();
        rebuildImages();
        say(n + " gambar tempel dihapus. Bisa dikembalikan dengan Urungkan.");
    }


    // ---------- tahap 8: fokus zoom, gerak kamera, efek suara ----------

    private static final String[] MOTION_LABELS = {"Tanpa gerak", "Zoom masuk perlahan", "Zoom keluar perlahan",
            "Geser kiri ke kanan", "Geser kanan ke kiri"};
    private static final String[] AUDFX_LABELS = {"Normal", "Bass kuat", "Jernih, treble naik", "Suara radio",
            "Gema", "Suara tegas untuk bicara", "Penstabil volume, suara pelan jadi jelas",
            "Pembersih derau, redam desis saat jeda bicara",
            "Pembersih suara angin, redam dengung rendah"};

    private void chooseFocus() {
        final Clip c = editable();
        if (c == null) return;
        choose("Titik fokus zoom klip", ANCHOR_LABELS, c.focus, which -> {
            c.focus = which;
            rebuildList(); updateInfo();
            say("Titik fokus zoom: " + ANCHOR_LABELS[which] + "."
                    + (c.zoom <= 1.001f && c.motion == 0 ? " Atur zoom klip lebih dari 1 kali agar terlihat." : ""));
        });
    }

    private void chooseMotion() {
        final Clip c = editable();
        if (c == null) return;
        choose("Gerak kamera klip", MOTION_LABELS, c.motion, which -> {
            c.motion = which;
            rebuildList(); updateInfo();
            say("Gerak kamera: " + MOTION_LABELS[which] + ".");
        });
    }

    private void chooseAudioFx() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        choose("Efek suara klip", AUDFX_LABELS, c.audioFx, which -> {
            c.audioFx = which;
            rebuildList(); updateInfo();
            say("Efek suara: " + AUDFX_LABELS[which] + ". Terdengar pada hasil ekspor.");
        });
    }


    // ---------- tahap 9: kecepatan bertahap, gaya cepat, salin tampilan, subtitle dari teks ----------

    private static final String[] RAMP_LABELS = {"Lambat di tengah (1x, 0,5x, 1x)",
            "Cepat di tengah (1x, 2x, 1x)", "Makin cepat (1x, 1,5x, 2x)", "Makin lambat (2x, 1,5x, 1x)",
            "Dramatis (1x, 0,25x, 1,5x)"};
    private static final float[][] RAMPS = {{1f, 0.5f, 1f}, {1f, 2f, 1f}, {1f, 1.5f, 2f},
            {2f, 1.5f, 1f}, {1f, 0.5f, 1.5f}};

    private void chooseSpeedRamp() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara atau kecepatan. Gunakan Durasi foto."); return; }
        if (c.endMs - c.startMs < 3000) {
            say("Klip terlalu pendek, minimal 3 detik untuk dibagi tiga bagian.");
            return;
        }
        choose("Kecepatan bertahap, klip dibagi 3 bagian", RAMP_LABELS, -1, which -> {
            float[] r = RAMPS[which];
            TimeSnap sn = takeSnap();
            long origEnd = c.endMs;
            long origFadeOut = c.fadeOutMs;
            long d = origEnd - c.startMs;
            long t1 = c.startMs + d / 3;
            long t2 = c.startMs + 2 * d / 3;
            Clip b = c.copy();
            Clip e = c.copy();
            c.endMs = t1;
            c.fadeOutMs = 0;
            c.speed = r[0];
            b.startMs = t1; b.endMs = t2; b.fadeInMs = 0; b.fadeOutMs = 0; b.title = ""; b.speed = r[1];
            e.startMs = t2; e.endMs = origEnd; e.fadeInMs = 0; e.fadeOutMs = origFadeOut; e.title = ""; e.speed = r[2];
            clips.add(selected + 1, b);
            clips.add(selected + 2, e);
            remapItems(sn);
            applyPreview(c);
            rebuildList(); configureSeek(); updateInfo();
            say("Klip dibagi tiga bagian dengan kecepatan bertahap. Sekarang " + clips.size() + " klip.");
        });
    }

    // ---------- tahap 24: hapus bagian hening otomatis ----------

    private static final String[] SILENCE_LABELS = {"Jeda lebih dari 0,5 detik", "Jeda lebih dari 1 detik",
            "Jeda lebih dari 2 detik"};
    private static final long[] SILENCE_MS = {500, 1000, 2000};
    private boolean silenceBusy = false;

    private void chooseSilenceCut() {
        final Clip c = editable();
        if (c == null) return;
        if (c.isImage) { say("Foto tidak punya suara."); return; }
        if (silenceBusy) { say("Masih menganalisis jeda hening."); return; }
        if (c.endMs - c.startMs < 2000) { say("Klip terlalu pendek, minimal 2 detik."); return; }
        choose("Hapus bagian hening klip terpilih", SILENCE_LABELS, -1, which -> {
            final long minMs = SILENCE_MS[which];
            final long s0 = c.startMs, e0 = c.endMs;
            final Clip snap = c.copy();
            silenceBusy = true;
            say("Menganalisis jeda hening. Mohon tunggu.");
            new Thread(() -> {
                long[][] r = null;
                try { r = SpeechMap.keepRanges(VideoLabActivity.this, snap, minMs, 150); } catch (Exception ignored) { }
                final long[][] res = r;
                runOnUiThread(() -> {
                    silenceBusy = false;
                    applySilenceCut(c, s0, e0, res);
                });
            }).start();
        });
    }

    private void applySilenceCut(Clip c, long s0, long e0, long[][] r) {
        if (r == null) { say("Analisis suara gagal. Klip tidak diubah."); return; }
        int pos = clips.indexOf(c);
        if (pos < 0 || c.startMs != s0 || c.endMs != e0 || exporting) {
            say("Klip berubah saat dianalisis. Ulangi lagi.");
            return;
        }
        if (r.length == 0) { say("Seluruh klip terdeteksi hening. Klip tidak diubah."); return; }
        long keptMs = 0;
        for (long[] x : r) keptMs += x[1] - x[0];
        long removed = (e0 - s0) - keptMs;
        if (r.length == 1 && removed < 300) { say("Tidak ada jeda hening yang cukup panjang."); return; }
        TimeSnap sn = takeSnap();
        Clip base = c.copy();
        int n = r.length;
        for (int i = 0; i < n; i++) {
            Clip x = (i == 0) ? c : base.copy();
            x.startMs = r[i][0];
            x.endMs = r[i][1];
            if (i > 0) { x.fadeInMs = 0; x.title = ""; }
            x.fadeOutMs = (i < n - 1) ? 0 : base.fadeOutMs;
            if (i > 0) clips.add(pos + i, x);
        }
        remapItems(sn);
        applyPreview(c);
        rebuildList(); configureSeek(); updateInfo();
        say("Bagian hening dibuang sepanjang " + speak(removed) + ". Klip dibagi menjadi " + n
                + " bagian. Bisa dikembalikan dengan Urungkan.");
    }

    // ---------- tahap 27: samakan volume antar klip ----------

    private static final String[] NORM_LABELS = {"Samakan ke tingkat tengah semua klip",
            "Samakan ke suara bicara jelas, target tetap"};
    private static final float NORM_MIN = 0.2f, NORM_MAX = 3.0f;

    private void chooseNormalize() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        final List<Clip> targets = new ArrayList<>();
        for (Clip c : clips) if (!c.isImage && !c.muted) targets.add(c);
        if (targets.size() < 1) { say("Belum ada klip bersuara."); return; }
        choose("Samakan volume klip", NORM_LABELS, -1, which -> startNormalize(targets, which == 1));
    }

    private void startNormalize(final List<Clip> targets, final boolean fixedTarget) {
        final List<Clip> snaps = new ArrayList<>();
        for (Clip c : targets) snaps.add(c.copy());
        stabBusy = true;
        say("Mengukur kerasnya suara " + targets.size() + " klip. Mohon tunggu.");
        new Thread(() -> {
            final double[] lv = new double[snaps.size()];
            for (int i = 0; i < lv.length; i++) {
                try { lv[i] = SpeechMap.loudness(VideoLabActivity.this, snaps.get(i)); } catch (Exception e) { lv[i] = -1; }
            }
            runOnUiThread(() -> {
                stabBusy = false;
                applyNormalize(targets, lv, fixedTarget);
            });
        }).start();
    }

    private void applyNormalize(List<Clip> targets, double[] lv, boolean fixedTarget) {
        if (exporting) { say("Sedang mengekspor. Volume tidak diubah."); return; }
        List<Double> valid = new ArrayList<>();
        for (double v : lv) if (v > 0) valid.add(v);
        if (valid.isEmpty()) { say("Tidak ada suara yang cukup untuk diukur. Volume tidak diubah."); return; }
        double target;
        if (fixedTarget) {
            target = 0.1;   // sekitar minus 20 dB dari penuh, tingkat umum suara bicara yang enak didengar
        } else {
            Collections.sort(valid);
            target = valid.get(valid.size() / 2);
        }
        int changed = 0, skipped = 0;
        float lo = NORM_MAX, hi = NORM_MIN;
        for (int i = 0; i < targets.size(); i++) {
            Clip c = targets.get(i);
            if (!clips.contains(c)) continue;
            if (lv[i] <= 0) { skipped++; continue; }
            float g = (float) (target / lv[i]);
            g = Math.max(NORM_MIN, Math.min(NORM_MAX, g));
            g = Math.round(g * 100f) / 100f;
            c.volume = g;
            lo = Math.min(lo, g); hi = Math.max(hi, g);
            changed++;
        }
        Clip cur = current();
        if (cur != null) applyPreview(cur);
        rebuildList(); updateInfo();
        say("Volume " + changed + " klip disamakan, berkisar " + Math.round(lo * 100) + " sampai "
                + Math.round(hi * 100) + " persen."
                + (skipped > 0 ? " " + skipped + " klip dilewati karena suaranya terlalu sedikit." : "")
                + (fixedTarget ? "" : " Target mengikuti klip tengah.")
                + " Bisa dikembalikan dengan Urungkan.");
    }

    private static final String[] STYLE_LABELS = {"Sinematik", "Vlog cerah", "Retro film",
            "Hitam putih dramatis", "Sepia klasik", "Hapus semua gaya warna"};

    private void chooseStyle() {
        if (clips.isEmpty()) { say("Belum ada klip."); return; }
        choose("Gaya warna cepat untuk semua klip", STYLE_LABELS, -1, which -> {
            for (Clip c : clips) {
                c.hue = 0f; c.brightness = 0f; c.contrast = 0f; c.saturation = 0f; c.warmth = 0f; c.filter = 0;
                if (which == 0) { c.filter = 8; }
                else if (which == 1) { c.filter = 6; c.warmth = 0.1f; c.saturation = 0.25f; }
                else if (which == 2) { c.filter = 7; c.warmth = 0.1f; c.contrast = 0.25f; }
                else if (which == 3) { c.filter = 1; c.contrast = 0.25f; }
                else if (which == 4) { c.filter = 5; c.contrast = 0.25f; }
            }
            rebuildList(); updateInfo();
            say("Gaya " + STYLE_LABELS[which].toLowerCase() + " diterapkan ke " + clips.size() + " klip.");
        });
    }

    private void copyLookToAll() {
        final Clip c = editable();
        if (c == null) return;
        if (clips.size() < 2) { say("Hanya ada satu klip."); return; }
        for (Clip o : clips) {
            if (o == c) continue;
            o.filter = c.filter; o.saturation = c.saturation; o.hue = c.hue; o.warmth = c.warmth;
            o.brightness = c.brightness; o.contrast = c.contrast;
            o.volume = c.volume; o.muted = c.muted; o.pitch = c.pitch; o.audioFx = c.audioFx;
        }
        rebuildList(); updateInfo();
        say("Warna, volume, nada suara, dan efek suara klip ini disalin ke " + (clips.size() - 1) + " klip lain.");
    }

    private void subtitlesFromText() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (current() == null) { say("Belum ada video."); return; }
        long st = outputPositionMs();
        long def = Math.max(3000, totalOutMs() - st);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        final EditText etText = new EditText(this);
        etText.setHint("Tempel teks. Satu baris atau satu kalimat jadi satu subtitle");
        etText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etText.setMinLines(4);
        etText.setGravity(Gravity.TOP);
        final EditText etStart = new EditText(this);
        etStart.setHint("Mulai, dalam detik");
        etStart.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etStart.setText(String.format(Locale.US, "%.1f", st / 1000.0));
        final EditText etDur = new EditText(this);
        etDur.setHint("Total durasi seluruh teks, dalam detik");
        etDur.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etDur.setText(String.format(Locale.US, "%.1f", def / 1000.0));
        box.addView(etText);
        box.addView(etStart);
        box.addView(etDur);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("Subtitle dari teks, waktu dibagi otomatis")
                .setView(sv)
                .setPositiveButton("Buat", (d, w) -> {
                    String raw = etText.getText().toString().trim();
                    double s1 = parseSec(etStart.getText().toString());
                    double dur = parseSec(etDur.getText().toString());
                    if (raw.isEmpty()) { say("Teks kosong."); return; }
                    if (s1 < 0 || dur < 1) { say("Waktu tidak valid."); return; }
                    List<String> parts = new ArrayList<>();
                    String[] lines = raw.split("\\r?\\n");
                    for (String ln : lines) {
                        ln = ln.trim();
                        if (ln.isEmpty()) continue;
                        if (lines.length == 1) {
                            for (String sen : ln.split("(?<=[.!?])\\s+")) {
                                if (!sen.trim().isEmpty()) parts.add(sen.trim());
                            }
                        } else {
                            parts.add(ln);
                        }
                    }
                    if (parts.isEmpty() || parts.size() > 300) { say("Jumlah baris tidak valid."); return; }
                    double sum = 0;
                    for (String t : parts) sum += Math.max(8, t.length());
                    double cur = s1 * 1000;
                    for (String t : parts) {
                        double share = dur * 1000 * Math.max(8, t.length()) / sum;
                        subs.add(new SubtitleItem((long) cur, (long) (cur + share), t));
                        cur += share;
                    }
                    Collections.sort(subs, (x, y) -> Long.compare(x.startMs, y.startMs));
                    rebuildSubs();
                    say(parts.size() + " subtitle dibuat dari teks. Total " + subs.size() + " subtitle.");
                })
                .setNegativeButton("Batal", null)
                .show();
    }


    // ---------- tahap 10: foto dan slideshow ----------

    private static final long[] PHOTO_DURS = {2000, 3000, 4000, 5000, 7000, 10000, 15000, 20000, 30000};
    private static final String[] PHOTO_DUR_LABELS = {"2 detik", "3 detik", "4 detik", "5 detik", "7 detik",
            "10 detik", "15 detik", "20 detik", "30 detik"};

    private boolean readableImage(Uri u) {
        try {
            BitmapFactory.Options bo = new BitmapFactory.Options();
            bo.inJustDecodeBounds = true;
            try (InputStream is = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(is, null, bo);
            }
            return bo.outWidth > 0 && bo.outHeight > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void onPhotosPicked(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        if (restorePending) { say(RESTORE_MSG); return; }
        int added = 0;
        TimeSnap sn = takeSnap();
        for (Uri u : uris) {
            persist(u);
            if (!readableImage(u)) continue;
            clips.add(new Clip(u, nameOf(u), 30000, 0, 4000));
            clips.get(clips.size() - 1).isImage = true;
            added++;
        }
        if (added == 0) { say("Foto tidak bisa dibaca."); return; }
        remapItems(sn);
        if (selected < 0) {
            select(0);
        } else {
            rebuildList();
        }
        say(added + " foto ditambahkan, masing-masing 4 detik. Total " + clips.size()
                + " klip. Atur durasi dengan tombol Durasi foto, dan pilih rasio layar agar ukuran seragam.");
    }

    private void choosePhotoDuration() {
        final Clip c = editable();
        if (c == null) return;
        if (!c.isImage) { say("Klip ini video, bukan foto. Gunakan tombol potong untuk durasi video."); return; }
        choose("Durasi foto", PHOTO_DUR_LABELS, -1, which -> {
            TimeSnap sn = takeSnap();
            c.startMs = 0;
            c.endMs = PHOTO_DURS[which];
            remapItems(sn);
            rebuildList(); configureSeek(); updateInfo();
            say("Durasi foto " + PHOTO_DUR_LABELS[which] + ".");
        });
    }


    // ---------- tahap 11: warna fade ----------

    private void chooseFadeColor() {
        if (exporting) { say("Sedang mengekspor."); return; }
        choose("Warna fade dan transisi", new String[]{"Hitam", "Putih"}, fadeWhite ? 1 : 0, which -> {
            fadeWhite = which == 1;
            updateExportInfo();
            say("Warna fade dan transisi: " + (fadeWhite ? "putih" : "hitam") + ".");
        });
    }

    // ---------- rekam narasi ----------

    private void toggleRecord() {
        if (recorder != null) { stopRecording(); return; }
        if (exporting) { say("Sedang mengekspor."); return; }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO);
            return;
        }
        startRecording();
    }

    private void startRecording() {
        if (recorder != null) return;
        player.pause();
        updatePlayLabel();
        MediaRecorder r = null;
        try {
            File dir = new File(getFilesDir(), "rekaman");
            dir.mkdirs();
            recordFile = new File(dir, "narasi_" + System.currentTimeMillis() + ".m4a");
            r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioSamplingRate(44100);
            r.setAudioEncodingBitRate(128000);
            r.setOutputFile(recordFile.getAbsolutePath());
            r.prepare();
            r.start();
            recorder = r;
            btnRecord.setText("Berhenti merekam narasi");
            say("Merekam. Bicaralah sekarang. Tekan Berhenti merekam narasi jika selesai.");
        } catch (Exception e) {
            if (r != null) { try { r.release(); } catch (Exception ignored) { } }
            recorder = null;
            if (recordFile != null) recordFile.delete();
            say("Gagal mulai merekam: " + e.getMessage());
        }
    }

    private void stopRecording() {
        MediaRecorder r = recorder;
        recorder = null;
        btnRecord.setText("Rekam narasi sebagai musik latar");
        if (r == null) return;
        boolean ok = true;
        try {
            r.stop();
        } catch (RuntimeException e) {
            ok = false;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        if (!ok || recordFile == null) {
            if (recordFile != null) recordFile.delete();
            say("Rekaman terlalu singkat, dibatalkan.");
            return;
        }
        Uri u = Uri.fromFile(recordFile);
        long d = durationOf(u);
        if (d <= 0) { say("Rekaman tidak bisa dibaca."); return; }
        musicUri = u;
        musicName = "Rekaman narasi";
        musicDurMs = d;
        musicVolume = 1f;
        musicStartMs = 0;
        musicFadeInMs = 0;
        musicFadeOutMs = 0;
        updateMusicInfo();
        say("Rekaman selesai, " + speak(d) + ". Dipakai sebagai musik latar, volume 100 persen, "
                + "mulai dari awal video, menggantikan musik sebelumnya.");
    }

    // ---------- simpan gambar dari video, bagikan hasil ----------

    private void onSnapClicked() {
        if (current() == null) { say("Belum ada video."); return; }
        if (Build.VERSION.SDK_INT < 29
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            pendingCapture = true;
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return;
        }
        captureFrame();
    }

    private void captureFrame() {
        Clip c = current();
        if (c == null) return;
        final Uri src = c.uri;
        final long posUs = player.getCurrentPosition() * 1000;
        say("Mengambil gambar.");
        new Thread(() -> {
            String result;
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            try {
                mr.setDataSource(this, src);
                Bitmap bmp = mr.getFrameAtTime(posUs, MediaMetadataRetriever.OPTION_CLOSEST);
                if (bmp == null) throw new Exception("gambar tidak tersedia di posisi ini");
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String name = "VideoLab_" + stamp + ".jpg";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/VideoLab");
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new java.io.IOException("penyimpanan menolak berkas baru");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new java.io.IOException("berkas tujuan tidak bisa dibuka");
                        if (!bmp.compress(Bitmap.CompressFormat.JPEG, 95, os)) {
                            throw new java.io.IOException("gambar gagal ditulis");
                        }
                    } catch (Exception e) {
                        try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        throw e;
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_PICTURES), "VideoLab");
                    dir.mkdirs();
                    File dst = new File(dir, name);
                    try (OutputStream os = new FileOutputStream(dst)) {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 95, os);
                    }
                    MediaScannerConnection.scanFile(this, new String[]{dst.getAbsolutePath()},
                            new String[]{"image/jpeg"}, null);
                }
                result = "Gambar disimpan di folder Pictures, VideoLab, dengan nama " + name + ".";
            } catch (Exception e) {
                result = "Gagal menyimpan gambar: " + e.getMessage();
            } finally {
                try { mr.release(); } catch (Exception ignored) { }
            }
            final String r = result;
            runOnUiThread(() -> say(r));
        }).start();
    }

    private void shareLast() {
        Uri u = lastSavedUri;
        if (u == null) { say("Belum ada hasil ekspor pada sesi ini."); return; }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(lastSavedMime);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Bagikan hasil ekspor"));
            say("Memilih aplikasi untuk berbagi.");
        } catch (Exception e) {
            say("Tidak bisa membagikan: " + e.getMessage());
        }
    }

    // ---------- tahap 43: potong otomatis untuk Status WhatsApp ----------

    private static final long STATUS_LIMIT_MS = 90000;   // batas durasi satu video Status WhatsApp saat ini
    private static final String[] SPLIT_LABELS = {"90 detik, pas batas Status WhatsApp (disarankan)",
            "30 detik", "1 menit", "2 menit", "3 menit", "5 menit", "10 menit", "Atur sendiri, menit dan detik"};
    private static final long[] SPLIT_MS = {STATUS_LIMIT_MS, 30000, 60000, 120000, 180000, 300000, 600000};
    private static final int SHARE_BATCH = 30;
    private static final String[] WA_PACKAGES = {"com.whatsapp", "com.whatsapp.w4b"};
    private static final String[] WA_LABELS = {"WhatsApp", "WhatsApp Business"};

    private StatusSplitter splitter;
    private List<Uri> splitUris = new ArrayList<>();
    private int splitNext = 0;
    private int batchNext = 0;         // posisi untuk cara lama (kirim sekaligus lewat aplikasi lain)
    private int sharePending = -1;     // bagian yang baru dibuka di WhatsApp dan belum dikonfirmasi terkirim
    private String splitPkg = null;    // WhatsApp yang dipakai untuk kiriman satu per satu ini
    private long[][] pendingPlan;

    private final ActivityResultLauncher<String> splitPerm =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted && pendingPlan != null) beginSplit();
                else { pendingPlan = null; say("Izin penyimpanan ditolak, pemotongan dibatalkan."); }
            });

    private void chooseSplit() {
        if (exporting || queueRunning) { say("Sedang mengekspor, tunggu sampai selesai."); return; }
        if (restorePending) { say(RESTORE_MSG); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan, tunggu sampai selesai."); return; }
        Clip c = current();
        if (c == null || c.isImage) {
            say("Pilih dulu klip video yang mau dipotong di daftar klip.");
            return;
        }
        askSplitMinutes();
    }

    private void chooseSplitFromList() {
        choose("Potong otomatis, durasi tiap potongan", SPLIT_LABELS, -1, which -> {
            if (which < SPLIT_MS.length) confirmSplit(SPLIT_MS[which]);
            else askSplitMinutes();
        });
    }

    /**
     * Menjumlahkan kolom menit dan kolom detik menjadi milidetik. Kolom kosong dihitung 0.
     * Boleh desimal (koma atau titik). Mengembalikan -1 kalau ada isi yang bukan angka atau negatif.
     */
    static long splitTotalMs(String minText, String secText) {
        try {
            double m = parseNum(minText);
            double sec = parseNum(secText);
            if (m < 0 || sec < 0) return -1;
            return Math.round((m * 60 + sec) * 1000);
        } catch (Exception e) {
            return -1;
        }
    }

    private static double parseNum(String t) {
        if (t == null) return 0;
        t = t.trim().replace(',', '.');
        if (t.isEmpty()) return 0;
        double v = Double.parseDouble(t);
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new NumberFormatException();
        return v;
    }

    private void askSplitMinutes() {
        long lastSec = prefs().getLong("split_last_sec", 90);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(48, 16, 48, 16);

        TextView lm = new TextView(this);
        lm.setText("Menit");
        lm.setTextSize(16f);
        final EditText etMin = new EditText(this);
        etMin.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789,."));
        etMin.setHint("Menit, boleh kosong");
        etMin.setContentDescription("Kolom menit. Boleh dikosongkan.");
        etMin.setText(lastSec / 60 > 0 ? String.valueOf(lastSec / 60) : "");

        TextView ls = new TextView(this);
        ls.setText("Detik");
        ls.setTextSize(16f);
        final EditText etSec = new EditText(this);
        etSec.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789,."));
        etSec.setHint("Detik, boleh kosong");
        etSec.setContentDescription("Kolom detik. Boleh dikosongkan.");
        etSec.setText(lastSec % 60 > 0 ? String.valueOf(lastSec % 60) : "");

        box.addView(lm);
        box.addView(etMin);
        box.addView(ls);
        box.addView(etSec);

        new AlertDialog.Builder(this)
                .setTitle("Durasi tiap potongan")
                .setMessage("Isi kolom Menit dan kolom Detik, nanti dijumlahkan. Contoh: Detik 30 berarti 30 detik; "
                        + "Detik 90 atau Menit 1 dan Detik 30 berarti 90 detik; Menit 2 berarti 2 menit. "
                        + "Batas video Status WhatsApp sekarang 90 detik.")
                .setView(box)
                .setPositiveButton("Lanjut", (d, w) -> {
                    long ms = splitTotalMs(etMin.getText().toString(), etSec.getText().toString());
                    if (ms < 0) { say("Isian tidak valid. Tulis angka saja di kolom menit dan kolom detik."); return; }
                    if (ms < 6000) { say("Durasi terlalu pendek, minimal 6 detik."); return; }
                    prefs().edit().putLong("split_last_sec", Math.round(ms / 1000.0)).apply();
                    confirmSplit(ms);
                })
                .setNeutralButton("Pilih dari daftar", (d, w) -> chooseSplitFromList())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void confirmSplit(long pieceMs) {
        Clip c = current();
        if (c == null || c.isImage) return;
        long len = c.endMs - c.startMs;
        if (len <= pieceMs) {
            say("Bagian video yang dipotong hanya " + speak(len) + ", tidak lebih panjang dari "
                    + speak(pieceMs) + ". Pilih durasi potongan yang lebih pendek.");
            return;
        }
        final long[][] plan = StatusSplitter.plan(c.startMs, c.endMs, pieceMs);
        String msg = "Video dari " + speak(c.startMs) + " sampai " + speak(c.endMs) + " (" + speak(len)
                + ") akan dipotong menjadi " + plan.length + " bagian, masing-masing sekitar "
                + speak(pieceMs) + ".";
        if (pieceMs > STATUS_LIMIT_MS) {
            msg += " Perhatian: tiap potongan lebih panjang dari 90 detik, batas video Status WhatsApp saat ini. "
                    + "WhatsApp bisa meminta dipangkas lagi. Disarankan pilih 90 detik atau lebih pendek.";
        } else {
            msg += " Tiap potongan tidak melebihi " + speak(pieceMs) + ", jadi muat di batas Status WhatsApp "
                    + "yang sekarang 90 detik. Kalau ada sisa pendek di akhir, dua bagian terakhir dibagi rata.";
        }
        msg += " Hanya rentang potongan klip yang dipakai, efek seperti kecepatan, filter, dan teks tidak ikut."
                + " Hasil disimpan di folder Film, VideoLab, Status WhatsApp, dalam subfolder baru bernama tanggal dan jam potongan, jadi tidak tercampur dengan potongan sebelumnya. Nama berkas diawali Bagian 1, Bagian 2, dan seterusnya.";
        new AlertDialog.Builder(this)
                .setTitle("Potong menjadi " + plan.length + " bagian?")
                .setMessage(msg)
                .setPositiveButton("Mulai potong", (d, w) -> startSplitJob(plan))
                .setNegativeButton("Batal", null)
                .show();
    }

    private void startSplitJob(long[][] plan) {
        pendingPlan = plan;
        if (Build.VERSION.SDK_INT < 29
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            splitPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return;
        }
        beginSplit();
    }

    private void beginSplit() {
        Clip c = current();
        long[][] plan = pendingPlan;
        pendingPlan = null;
        if (c == null || plan == null || exporting) return;
        if (player != null) { player.pause(); updatePlayLabel(); }
        String stamp = new SimpleDateFormat("dd-MM-yyyy 'jam' HH.mm.ss", Locale.US).format(new Date());
        lastAnnounced = 0;
        lastNotifPct = -1;
        setBusy(true);
        ExportService.start(this);
        splitter = new StatusSplitter(this, new StatusSplitter.Callback() {
            @Override
            public void onPartSaved(int done, int total) {
                say("Bagian " + done + " dari " + total + " selesai.");
            }

            @Override
            public void onFinished(List<Uri> saved, int total, boolean cancelled, String error) {
                finishSplit(saved, total, cancelled, error);
            }
        });
        say("Pemotongan dimulai, " + plan.length + " bagian.");
        splitter.start(c.copy(), plan, stamp);
    }

    private void finishSplit(List<Uri> saved, int total, boolean cancelled, String error) {
        setBusy(false);
        splitter = null;
        splitUris = new ArrayList<>(saved);
        splitNext = 0;
        sharePending = -1;
        splitPkg = null;
        saveSplitUris();
        saveSplitNext();
        String text;
        if (error != null) {
            text = "Pemotongan berhenti: " + error + "."
                    + (saved.isEmpty() ? "" : " " + saved.size() + " bagian sudah tersimpan.");
        } else if (cancelled) {
            text = "Pemotongan dibatalkan. " + saved.size() + " dari " + total + " bagian sudah tersimpan.";
        } else {
            text = "Selesai. Video dipotong menjadi " + saved.size()
                    + " bagian dan disimpan di folder Film, VideoLab, Status WhatsApp, subfolder bernama tanggal dan jam potongan.";
        }
        say(text);
        if (!visible) ExportNotifier.finished(this, error == null && !cancelled, text);
        if (!saved.isEmpty() && !isFinishing()) showSplitDone(text);
    }

    private void showSplitDone(String text) {
        new AlertDialog.Builder(this)
                .setTitle("Potongan selesai")
                .setMessage(text + " Tekan Kirim satu per satu. Tiap kali WhatsApp terbuka dengan satu potongan, "
                        + "urut dari bagian 1. Pilih Status saya, kirim, tunggu sampai terkirim, lalu kembali ke "
                        + "VideoLab untuk lanjut ke bagian berikutnya. Posisi terakhir diingat, jadi bisa dilanjut nanti."
                        + (installedWhatsApp().size() > 1
                        ? " Untuk mengirim juga ke akun satunya (WhatsApp dan WhatsApp Business), ulangi dari bagian 1 "
                        + "dan pilih yang lain." : ""))
                .setPositiveButton("Kirim satu per satu ke Status WhatsApp", (d, w) -> shareSplitToStatus())
                .setNeutralButton("Bagikan lewat aplikasi lain", (d, w) -> {
                    if (splitUris.isEmpty()) return;
                    batchNext = 0;
                    sendSplitBatch(null);
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private List<Integer> installedWhatsApp() {
        List<Integer> r = new ArrayList<>();
        for (int i = 0; i < WA_PACKAGES.length; i++) {
            try {
                getPackageManager().getPackageInfo(WA_PACKAGES[i], 0);
                r.add(i);
            } catch (Exception ignored) { }
        }
        return r;
    }

    /** Kirim ke Status WhatsApp satu potongan demi satu potongan, urut, lanjut dari posisi terakhir. */
    private void shareSplitToStatus() {
        if (exporting) { say("Sedang memproses, tunggu sampai selesai."); return; }
        if (splitUris.isEmpty()) loadSplitUris();
        if (splitUris.isEmpty()) {
            say("Belum ada hasil potongan untuk dibagikan. Pakai Potong otomatis dulu.");
            return;
        }
        final int total = splitUris.size();
        if (splitNext >= total) {
            new AlertDialog.Builder(this)
                    .setTitle("Semua bagian sudah dikirim")
                    .setMessage("Semua " + total + " bagian sudah dikirim. Mulai lagi dari bagian 1, misalnya untuk "
                            + "akun WhatsApp yang satunya?")
                    .setPositiveButton("Mulai dari bagian 1", (d, w) -> { splitNext = 0; splitPkg = null; saveSplitNext(); shareSplitToStatus(); })
                    .setNegativeButton("Tutup", null)
                    .show();
            return;
        }
        if (splitNext > 0) {
            String[] opts = {"Lanjut dari bagian " + (splitNext + 1) + " dari " + total, "Mulai lagi dari bagian 1"};
            choose("Kirim ke Status WhatsApp", opts, 0, which -> {
                if (which == 1) { splitNext = 0; splitPkg = null; saveSplitNext(); }
                pickWhatsAppAndSendOne();
            });
        } else {
            pickWhatsAppAndSendOne();
        }
    }

    private void pickWhatsAppAndSendOne() {
        if (splitPkg != null && splitNext > 0) { sendOnePart(splitPkg); return; }
        final List<Integer> wa = installedWhatsApp();
        if (wa.isEmpty()) {
            say("WhatsApp tidak ditemukan di HP ini. Memilih aplikasi lain.");
            sendOnePart(null);
        } else if (wa.size() == 1) {
            sendOnePart(WA_PACKAGES[wa.get(0)]);
        } else {
            String[] labels = new String[wa.size()];
            for (int i = 0; i < labels.length; i++) labels[i] = WA_LABELS[wa.get(i)];
            String last = prefs().getString("split_wa_pkg", "");
            int pre = -1;
            for (int i = 0; i < wa.size(); i++) if (WA_PACKAGES[wa.get(i)].equals(last)) pre = i;
            choose("Kirim lewat WhatsApp yang mana", labels, pre, which -> {
                prefs().edit().putString("split_wa_pkg", WA_PACKAGES[wa.get(which)]).apply();
                sendOnePart(WA_PACKAGES[wa.get(which)]);
            });
        }
    }

    private String waLabel(String pkg) {
        for (int k = 0; pkg != null && k < WA_PACKAGES.length; k++) if (WA_PACKAGES[k].equals(pkg)) return WA_LABELS[k];
        return "pilihan aplikasi";
    }

    private void sendOnePart(String pkg) {
        final int i = splitNext;
        if (i < 0 || i >= splitUris.size()) { say("Tidak ada potongan yang tersisa untuk dikirim."); return; }
        try {
            Uri u = splitUris.get(i);
            Intent it = new Intent(Intent.ACTION_SEND);
            it.setType("video/*");
            it.putExtra(Intent.EXTRA_STREAM, u);
            it.setClipData(android.content.ClipData.newRawUri("video", u));
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (pkg != null) {
                it.setPackage(pkg);
                startActivity(it);
            } else {
                startActivity(Intent.createChooser(it, "Bagikan potongan video"));
            }
            splitPkg = pkg;
            sharePending = i;
            say("Membuka " + waLabel(pkg) + " dengan bagian " + (i + 1) + " dari " + splitUris.size()
                    + ". Pilih Status saya lalu kirim, tunggu sampai terkirim, lalu kembali ke VideoLab.");
        } catch (Exception e) {
            say("Tidak bisa membuka WhatsApp untuk bagian " + (i + 1) + ": " + e.getMessage());
        }
    }

    /** Dipanggil saat kembali dari WhatsApp: tanya apakah bagian tadi sudah terkirim sebelum lanjut. */
    private void askShareConfirm() {
        final int i = sharePending;
        if (i < 0 || isFinishing() || i >= splitUris.size()) { sharePending = -1; return; }
        sharePending = -1;
        final int total = splitUris.size();
        final boolean last = i == total - 1;
        String text = "Bagian " + (i + 1) + " dari " + total + " sudah terkirim ke Status? "
                + "Kalau jaringan kurang bagus, tunggu dulu sampai di Status terlihat terkirim, supaya urutannya tetap benar.";
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Bagian " + (i + 1) + " dari " + total)
                .setMessage(text)
                .setPositiveButton(last ? "Sudah terkirim, selesai" : "Sudah terkirim, lanjut bagian " + (i + 2), (d, w) -> {
                    splitNext = i + 1;
                    saveSplitNext();
                    if (splitNext >= total) {
                        splitPkg = null;
                        say("Selesai. Semua " + total + " bagian sudah dikirim.");
                    } else {
                        sendOnePart(splitPkg);
                    }
                })
                .setNegativeButton("Kirim ulang bagian " + (i + 1), (d, w) -> {
                    splitNext = i;
                    saveSplitNext();
                    sendOnePart(splitPkg);
                })
                .setNeutralButton("Lanjut nanti", (d, w) -> {
                    splitNext = i;
                    saveSplitNext();
                    say("Berhenti di bagian " + (i + 1) + ". Tekan Kirim potongan ke Status WhatsApp untuk melanjutkan "
                            + "dari bagian ini.");
                });
        b.setOnCancelListener(d -> { splitNext = i; saveSplitNext(); });
        b.show();
    }

    private void sendSplitBatch(String pkg) {
        int from = batchNext;
        int to = Math.min(splitUris.size(), from + SHARE_BATCH);
        if (from >= to) { say("Tidak ada potongan yang tersisa untuk dibagikan."); batchNext = 0; return; }
        ArrayList<Uri> part = new ArrayList<>(splitUris.subList(from, to));
        try {
            Intent i;
            if (part.size() == 1) {
                i = new Intent(Intent.ACTION_SEND);
                i.putExtra(Intent.EXTRA_STREAM, part.get(0));
            } else {
                i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, part);
            }
            i.setType("video/*");
            android.content.ClipData cd = android.content.ClipData.newRawUri("video", part.get(0));
            for (int k = 1; k < part.size(); k++) cd.addItem(new android.content.ClipData.Item(part.get(k)));
            i.setClipData(cd);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (pkg != null) {
                i.setPackage(pkg);
                startActivity(i);
            } else {
                startActivity(Intent.createChooser(i, "Bagikan potongan video"));
            }
            String app = "pilihan aplikasi";
            for (int k = 0; pkg != null && k < WA_PACKAGES.length; k++) if (WA_PACKAGES[k].equals(pkg)) app = WA_LABELS[k];
            String m = "Membuka " + app + " dengan potongan "
                    + (from + 1) + " sampai " + to + " dari " + splitUris.size() + ".";
            if (to < splitUris.size()) {
                batchNext = to;
                m += " Setelah selesai, tekan lagi Bagikan potongan terakhir ke Status WhatsApp untuk "
                        + "kelompok berikutnya, maksimal " + SHARE_BATCH + " potongan tiap kali kirim.";
            } else {
                batchNext = 0;
            }
            say(m);
        } catch (Exception e) {
            say("Tidak bisa membagikan: " + e.getMessage());
        }
    }

    private void saveSplitUris() {
        StringBuilder sb = new StringBuilder();
        for (Uri u : splitUris) sb.append(u.toString()).append('\n');
        prefs().edit().putString("split_uris", sb.toString()).apply();
    }

    private void saveSplitNext() {
        prefs().edit().putInt("split_next", splitNext).apply();
    }

    private void loadSplitUris() {
        splitUris = new ArrayList<>();
        splitNext = Math.max(0, prefs().getInt("split_next", 0));
        String s = prefs().getString("split_uris", "");
        if (s == null || s.isEmpty()) return;
        for (String line : s.split("\n")) {
            if (!line.trim().isEmpty()) splitUris.add(Uri.parse(line.trim()));
        }
        if (splitNext > splitUris.size()) splitNext = 0;
    }

    // ---------- ekspor ----------

    private void onExportClicked(boolean audioOnly) {
        if (exporting || queueRunning) return;
        if (restorePending) { say(RESTORE_MSG); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan, tunggu sampai selesai."); return; }
        if (clips.isEmpty()) { say("Belum ada klip untuk diekspor."); return; }
        pendingAudioOnly = audioOnly;
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notifAsked = true;
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS);
            return;
        }
        if (Build.VERSION.SDK_INT < 29
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return;
        }
        startExport(audioOnly);
    }

    private void startExport(boolean audioOnly) {
        if (exporting || clips.isEmpty()) return;
        if (!subMode && musicUri != null && duckLevel > 0 && !duckReady) {
            if (duckBusy) { say("Masih menganalisis suara bicara."); return; }
            duckBusy = true;
            say("Menganalisis suara bicara agar musik turun otomatis. Mohon tunggu.");
            final List<Clip> snap = new ArrayList<>();
            for (Clip q : clips) snap.add(q.copy());
            new Thread(() -> {
                long[][] segs = null;
                try { segs = SpeechMap.analyze(VideoLabActivity.this, snap, audioOnly, duckSens, duckRel); } catch (Exception ignored) { }
                final long[][] fs = segs;
                runOnUiThread(() -> {
                    duckBusy = false;
                    duckSegs = fs;
                    if (fs == null) say("Analisis suara gagal, musik tidak diturunkan otomatis.");
                    duckReady = true;
                    try { startExport(audioOnly); } finally { duckReady = false; }
                    if (queueRunning && !exporting && !duckBusy) onQueueItemDone(false);
                });
            }).start();
            return;
        }
        exportAudioOnly = audioOnly;
        final boolean sub = subMode;
        exportForSubs = sub;
        subMode = false;
        if (sub) {
            subSig = timelineSig();
            subMap.clear();
            long aPos = 0, oPos = 0;
            for (Clip q : clips) {
                long d = q.outDurationMs();
                if (!q.isImage) { subMap.add(new long[]{aPos, oPos, d}); aPos += d; }
                oPos += d;
            }
        }
        player.pause();
        updatePlayLabel();

        List<EditedMediaItem> items = new ArrayList<>();
        for (int idx = 0; idx < clips.size(); idx++) {
            Clip c = clips.get(idx);
            long offsetMs = 0;
            for (int k = 0; k < idx; k++) offsetMs += clips.get(k).outDurationMs();
            long tIn = idx > 0 ? TRANS_MS[transIndex] : 0;
            long tOut = idx < clips.size() - 1 ? TRANS_MS[transIndex] : 0;
            long half = c.outDurationMs() / 2;
            long fIn = Math.min(Math.max(c.fadeInMs, tIn), half);
            long fOut = Math.min(Math.max(c.fadeOutMs, tOut), half);
            if (c.isImage) {
                if (audioOnly) continue;
                List<Effect> ivfx = new ArrayList<>();
                addVisualEffects(ivfx, c, fIn, fOut, offsetMs);
                MediaItem imi = new MediaItem.Builder().setUri(c.uri).build();
                items.add(new EditedMediaItem.Builder(imi)
                        .setDurationUs((c.endMs - c.startMs) * 1000)
                        .setFrameRate(30)
                        .setEffects(new Effects(new ArrayList<AudioProcessor>(), ivfx))
                        .build());
                continue;
            }
            MediaItem mi = new MediaItem.Builder()
                    .setUri(c.uri)
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(c.startMs)
                            .setEndPositionMs(c.endMs)
                            .build())
                    .build();
            List<AudioProcessor> aps = new ArrayList<>();
            List<Effect> vfx = new ArrayList<>();
            boolean speedOn = Math.abs(c.speed - 1f) > 0.001f;
            boolean pitchOn = Math.abs(c.pitch - 1f) > 0.001f;
            if (speedOn || pitchOn) {
                SonicAudioProcessor sonic = new SonicAudioProcessor();
                sonic.setSpeed(c.speed);
                sonic.setPitch(c.pitch);
                aps.add(sonic);
                if (speedOn && !audioOnly) vfx.add(new SpeedChangeEffect(c.speed));
            }
            if (!audioOnly) addVisualEffects(vfx, c, fIn, fOut, offsetMs);
            if (!sub && c.audioFx > 0) aps.add(new VoiceFxProcessor(c.audioFx));
            if (!sub && (c.muted || Math.abs(c.volume - 1f) > 0.001f || fIn > 0 || fOut > 0)) {
                aps.add(new GainFadeProcessor(c.muted ? 0f : c.volume, fIn, fOut, c.outDurationMs()));
            }
            items.add(new EditedMediaItem.Builder(mi)
                    .setRemoveVideo(audioOnly)
                    .setEffects(new Effects(aps, vfx))
                    .build());
        }

        if (items.isEmpty()) {
            say("Tidak ada klip video untuk diekspor sebagai audio.");
            return;
        }
        EditedMediaItemSequence mainSeq = new EditedMediaItemSequence.Builder(items).build();
        List<EditedMediaItemSequence> extraSeqs = new ArrayList<>();
        if (!sub && musicUri != null && musicDurMs <= 0) {
            say("Durasi musik latar tidak terbaca, musik dilewati. Pilih ulang musiknya bila ingin ikut diekspor.");
        }
        if (!sub && musicUri != null && musicDurMs > 0) {
            long total = totalOutMs();
            long mStart = Math.max(0, Math.min(musicStartMs, musicDurMs - 1000));
            long avail = musicDurMs - mStart;
            long clipEnd = mStart + Math.min(avail, total);
            MediaItem mm = new MediaItem.Builder()
                    .setUri(musicUri)
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(mStart)
                            .setEndPositionMs(clipEnd)
                            .build())
                    .build();
            List<AudioProcessor> maps = new ArrayList<>();
            if (duckLevel > 0 && duckSegs != null && duckSegs.length > 0) {
                maps.add(new DuckProcessor(duckSegs, DUCK_GAIN[duckLevel], 0.03, DuckDetect.releaseTc(duckRel)));
            }
            maps.add(new GainFadeProcessor(musicVolume,
                    Math.min(musicFadeInMs, total / 2), Math.min(musicFadeOutMs, total / 2), total));
            EditedMediaItem musicItem = new EditedMediaItem.Builder(mm)
                    .setRemoveVideo(true)
                    .setEffects(new Effects(maps, new ArrayList<Effect>()))
                    .build();
            EditedMediaItemSequence.Builder mb = new EditedMediaItemSequence.Builder(musicItem);
            if (avail < total) mb.setIsLooping(true);
            extraSeqs.add(mb.build());
        }
        if (!sub && !sfxList.isEmpty()) {
            try {
                File bed = SfxMixer.buildBed(this, sfxList, totalOutMs(),
                        new File(getCacheDir(), "sfx_" + System.currentTimeMillis() + ".wav"));
                if (bed != null) {
                    sfxBedFile = bed;
                    EditedMediaItem bedItem = new EditedMediaItem.Builder(
                            new MediaItem.Builder().setUri(Uri.fromFile(bed)).build())
                            .setRemoveVideo(true)
                            .build();
                    extraSeqs.add(new EditedMediaItemSequence.Builder(bedItem).build());
                }
            } catch (Exception e) {
                say("Efek suara tambahan dilewati: " + e.getMessage());
            }
        }
        Composition composition;
        try {
            composition = new Composition.Builder(mainSeq,
                    extraSeqs.toArray(new EditedMediaItemSequence[0])).build();
        } catch (RuntimeException e) {
            if (sfxBedFile != null) { sfxBedFile.delete(); sfxBedFile = null; }
            say("Ekspor gagal disiapkan: " + e.getMessage());
            return;
        }

        outFile = new File(getCacheDir(), sub ? "subs_" + System.currentTimeMillis() + ".m4a"
                : "export_" + System.currentTimeMillis() + ".mp4");
        Transformer.Builder tb = new Transformer.Builder(this)
                .setVideoMimeType(CODEC_MIMES[codecIndex])
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition comp, ExportResult result) {
                        if (exportForSubs) {
                            final File af = outFile;
                            setBusy(false);
                            transcribeFile(af);
                        } else {
                            saveToGallery(outFile, exportAudioOnly);
                        }
                    }

                    @Override
                    public void onError(Composition comp, ExportResult result, ExportException e) {
                        if (outFile != null) outFile.delete();
                        setBusy(false);
                        say("Ekspor gagal: " + e.getMessage());
                        if (queueRunning) { onQueueItemDone(false); return; }
                        if (!visible) ExportNotifier.finished(VideoLabActivity.this, false,
                                "Ekspor gagal: " + e.getMessage());
                    }
                });
        int bps = qualIndex > 0 ? QUAL_BPS[qualIndex] : 0;
        if (targetMb > 0) {
            long totalMsForSize = totalOutMs();
            if (totalMsForSize > 0) {
                long b = (long) (targetMb * 1048576.0 * 8 * 0.92 / (totalMsForSize / 1000.0)) - 128000;
                bps = (int) Math.max(300000L, Math.min(16000000L, b));
            }
        }
        if (sub) {
            tb.setEncoderFactory(new DefaultEncoderFactory.Builder(this)
                    .setRequestedAudioEncoderSettings(new AudioEncoderSettings.Builder().setBitrate(48000).build())
                    .build());
        } else if (bps > 0) {
            tb.setEncoderFactory(new DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder()
                            .setBitrate(bps).build())
                    .build());
        }
        transformer = tb.build();

        lastAnnounced = 0;
        setBusy(true);
        say(sub ? "Menyiapkan audio untuk dikenali." : "Ekspor dimulai.");
        lastNotifPct = -1;
        if (!sub) ExportService.start(this);
        try {
            transformer.start(composition, outFile.getAbsolutePath());
        } catch (RuntimeException e) {
            // Galat saat memulai tidak boleh menutup aplikasi.
            if (outFile != null) outFile.delete();
            setBusy(false);
            say("Ekspor gagal dimulai: " + e.getMessage());
            if (!queueRunning && !visible) ExportNotifier.finished(VideoLabActivity.this, false,
                    "Ekspor gagal dimulai: " + e.getMessage());
        }
    }

    // ---------- subtitle otomatis lewat Groq ----------

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences("videolab_prefs", MODE_PRIVATE);
    }

    private void editGroqKey(final boolean thenStart) {
        final EditText et = new EditText(this);
        et.setHint("Kunci API Groq, diawali gsk_");
        et.setSingleLine(true);
        et.setText(prefs().getString("groq_key", ""));
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Kunci API Groq")
                .setMessage("Kunci disimpan hanya di HP ini dan dipakai khusus untuk subtitle otomatis.")
                .setView(et)
                .setPositiveButton("Simpan", (d, w) -> {
                    String k = et.getText().toString().trim();
                    prefs().edit().putString("groq_key", k).apply();
                    if (k.isEmpty()) { say("Kunci API dikosongkan."); return; }
                    say("Kunci API Groq disimpan, berakhiran " + k.substring(Math.max(0, k.length() - 4)) + ".");
                    if (thenStart) startAutoSubtitles();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void chooseGroqModel() {
        choose("Model suara Groq", GROQ_MODEL_LABELS, prefs().getInt("groq_model", 0), which -> {
            prefs().edit().putInt("groq_model", which).apply();
            say("Model suara: " + GROQ_MODEL_LABELS[which] + ".");
        });
    }

    private void chooseGroqLang() {
        choose("Bahasa yang diucapkan di video", LANG_LABELS, prefs().getInt("groq_lang", 0), which -> {
            prefs().edit().putInt("groq_lang", which).apply();
            say("Bahasa suara: " + LANG_LABELS[which] + ".");
        });
    }

    // ---------- tahap 28: antrean ekspor ----------

    private final List<String[]> exportQueue = new ArrayList<>();   // {label, isi proyek}
    private boolean queueRunning = false;
    private String queueResume = null;
    private int queueDone = 0, queueFail = 0, queueTotal = 0, queueIndex = 0;

    private void queueAdd() {
        if (exporting || queueRunning) { say("Sedang mengekspor."); return; }
        if (clips.isEmpty()) { say("Belum ada klip untuk dimasukkan ke antrean."); return; }
        try {
            String json = projectToJson().toString();
            String label = "Proyek " + (exportQueue.size() + 1) + ": " + clips.size() + " klip, "
                    + speak(totalOutMs()) + ", dimulai dari " + clips.get(0).name;
            exportQueue.add(new String[]{label, json});
            say("Proyek ini ditambahkan ke antrean ekspor beserta pengaturannya. Sekarang " + exportQueue.size()
                    + " proyek di antrean. Silakan buat proyek berikutnya, lalu tambahkan lagi, atau mulai antrean.");
        } catch (Exception e) {
            say("Gagal menambahkan ke antrean.");
        }
    }

    private void queueManage() {
        if (queueRunning) { say("Antrean ekspor sedang berjalan."); return; }
        if (exportQueue.isEmpty()) { say("Antrean ekspor kosong."); return; }
        final int n = exportQueue.size();
        String[] labels = new String[n + 1];
        for (int i = 0; i < n; i++) labels[i] = "Hapus " + exportQueue.get(i)[0];
        labels[n] = "Kosongkan seluruh antrean";
        choose("Antrean ekspor, " + n + " proyek", labels, -1, which -> {
            if (which == n) {
                exportQueue.clear();
                say("Antrean ekspor dikosongkan.");
            } else if (which >= 0 && which < exportQueue.size()) {
                exportQueue.remove(which);
                say("Proyek dihapus dari antrean. Sisa " + exportQueue.size() + " proyek.");
            }
        });
    }

    private void queueStart() {
        if (exporting || queueRunning) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        if (exportQueue.isEmpty()) { say("Antrean ekspor kosong. Tambahkan proyek dulu."); return; }
        if (Build.VERSION.SDK_INT < 29
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            say("Izin penyimpanan belum diberikan. Ekspor satu video biasa dulu agar izin diminta.");
            return;
        }
        try { queueResume = projectToJson().toString(); } catch (Exception e) { queueResume = currentJson; }
        queueRunning = true;
        queueDone = 0; queueFail = 0; queueIndex = 0;
        queueTotal = exportQueue.size();
        say("Antrean ekspor dimulai, " + queueTotal + " proyek. Biarkan aplikasi berjalan. "
                + "Ada pemberitahuan saat semua selesai.");
        runNextQueue();
    }

    private void runNextQueue() {
        if (!queueRunning) return;
        if (exportQueue.isEmpty()) { finishQueue(true); return; }
        String[] it = exportQueue.remove(0);
        queueIndex++;
        if (!restoreSnapshot(it[1]) || clips.isEmpty()) {
            queueFail++;
            say("Proyek " + queueIndex + " tidak bisa dibuka, dilewati.");
            handler.post(this::runNextQueue);
            return;
        }
        say("Mengekspor proyek " + queueIndex + " dari " + queueTotal + ".");
        startExport(false);
        if (!exporting && !duckBusy) {
            queueFail++;
            say("Proyek " + queueIndex + " gagal dimulai, dilewati.");
            handler.post(this::runNextQueue);
        }
    }

    private void onQueueItemDone(boolean ok) {
        if (!queueRunning) return;
        if (ok) queueDone++; else queueFail++;
        handler.post(this::runNextQueue);
    }

    private void stopQueue() {
        say("Antrean dihentikan. Sisa " + exportQueue.size() + " proyek tetap di antrean.");
        finishQueue(false);
    }

    private void finishQueue(boolean completed) {
        queueRunning = false;
        ExportService.stop(this);
        if (queueResume != null) {
            restoreSnapshot(queueResume);
            queueResume = null;
        }
        try { currentJson = projectToJson().toString(); } catch (Exception e) { currentJson = ""; }
        writeAutosave(currentJson);
        if (completed) {
            String msg = "Antrean ekspor selesai. " + queueDone + " berhasil"
                    + (queueFail > 0 ? ", " + queueFail + " gagal" : "")
                    + ". Proyek yang tadi Anda edit sudah dibuka kembali. Hasil ada di folder Movies, VideoLab.";
            say(msg);
            ExportNotifier.finished(this, queueFail == 0, msg);
        }
    }

    // ---------- tahap 26: terjemahan subtitle lewat Groq ----------

    private static final String[] TR_LABELS = {"Indonesia", "Inggris", "Arab", "Jawa", "Sunda", "Melayu",
            "Mandarin", "Jepang", "Korea", "Spanyol", "Prancis", "Jerman", "Portugis", "Rusia", "Hindi", "Turki"};
    private static final String[] TR_MODE = {"Ganti teks subtitle dengan terjemahan",
            "Dua bahasa: asli di atas, terjemahan di bawah"};

    private void chooseTranslate() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        if (subs.isEmpty()) { say("Belum ada subtitle untuk diterjemahkan."); return; }
        if (prefs().getString("groq_key", "").trim().isEmpty()) {
            say("Kunci API Groq belum diisi. Isi dulu lewat tombol Kunci API Groq.");
            editGroqKey(false);
            return;
        }
        choose("Terjemahkan subtitle ke bahasa", TR_LABELS, -1, lang -> {
            choose("Hasil terjemahan", TR_MODE, -1, mode -> startTranslate(TR_LABELS[lang], mode == 1));
        });
    }

    private void startTranslate(final String language, final boolean bilingual) {
        final String key = prefs().getString("groq_key", "").trim();
        final List<SubtitleItem> snap = new ArrayList<>(subs);
        final List<String> src = new ArrayList<>();
        for (SubtitleItem si : snap) src.add(si.text);
        stabBusy = true;
        say("Menerjemahkan " + snap.size() + " subtitle ke bahasa " + language + ". Mohon tunggu.");
        new Thread(() -> {
            GroqTranslator.Result res = null;
            String err = null;
            try {
                res = GroqTranslator.translate(key, src, language);
            } catch (Exception e) {
                err = e.getMessage() == null ? "Gagal terhubung ke Groq. Periksa internet." : e.getMessage();
            }
            final GroqTranslator.Result rr = res;
            final String error = err;
            runOnUiThread(() -> {
                stabBusy = false;
                if (error != null) { say("Terjemahan gagal. " + error + " Subtitle tidak diubah."); return; }
                if (rr == null || rr.failed >= snap.size()) { say("Tidak ada baris yang berhasil diterjemahkan. Subtitle tidak diubah."); return; }
                for (int i = 0; i < snap.size(); i++) {
                    SubtitleItem si = snap.get(i);
                    if (!subs.contains(si)) continue;
                    String t = rr.texts.get(i);
                    si.text = (bilingual && !t.equals(src.get(i))) ? src.get(i) + "\n" + t : t;
                }
                rebuildSubs();
                say("Subtitle diterjemahkan ke bahasa " + language + (bilingual ? ", dua bahasa" : "") + "."
                        + (rr.failed > 0 ? " " + rr.failed + " baris gagal dan tetap berbahasa asli." : "")
                        + " Bisa dikembalikan dengan Urungkan.");
            });
        }).start();
    }

    private void startAutoSubtitles() {
        if (exporting) { say("Sedang mengekspor."); return; }
        if (stabBusy) { say("Proses analisis atau pengenalan suara masih berjalan."); return; }
        boolean hasAudio = false;
        for (Clip c : clips) if (!c.isImage) hasAudio = true;
        if (!hasAudio) { say("Belum ada klip video untuk dikenali suaranya."); return; }
        String key = prefs().getString("groq_key", "").trim();
        if (key.isEmpty()) { editGroqKey(true); return; }
        if (subs.isEmpty()) { beginSubExport(false); return; }
        choose("Sudah ada " + subs.size() + " subtitle", new String[]{"Ganti semua subtitle", "Tambahkan di samping yang ada"}, -1,
                which -> beginSubExport(which == 0));
    }

    private void beginSubExport(boolean replace) {
        subReplace = replace;
        subMode = true;
        startExport(true);
        subMode = false; // jaga-jaga jika ekspor tidak jadi dimulai
    }

    private void transcribeFile(final File f) {
        final String key = prefs().getString("groq_key", "").trim();
        final String model = GROQ_MODELS[Math.max(0, Math.min(GROQ_MODELS.length - 1, prefs().getInt("groq_model", 0)))];
        final String lang = LANG_CODES[Math.max(0, Math.min(LANG_CODES.length - 1, prefs().getInt("groq_lang", 0)))];
        if (f == null || !f.exists() || f.length() == 0) { say("Audio tidak berhasil disiapkan."); return; }
        if (f.length() > GroqTranscriber.MAX_BYTES) {
            f.delete();
            say("Audio terlalu besar untuk satu kiriman ke Groq, sekitar lebih dari 70 menit. Potong video menjadi bagian lebih pendek.");
            return;
        }
        stabBusy = true; // memakai penjaga yang sama agar ekspor tidak jalan bersamaan
        say("Mengirim audio ke Groq dan menunggu hasil. Mohon tunggu.");
        new Thread(() -> {
            List<SubtitleItem> got = null;
            String err = null;
            try {
                got = GroqTranscriber.transcribe(key, model, lang, f);
            } catch (Exception e) {
                err = e.getMessage() == null ? "Gagal terhubung ke Groq. Periksa internet." : e.getMessage();
            } finally {
                f.delete();
            }
            final List<SubtitleItem> res = got;
            final String error = err;
            runOnUiThread(() -> {
                stabBusy = false;
                if (error != null) { say("Subtitle otomatis gagal. " + error); return; }
                if (res == null || res.isEmpty()) { say("Tidak ada ucapan yang dikenali. Periksa bahasa suara dan volume video."); return; }
                List<SubtitleItem> mapped = new ArrayList<>();
                for (SubtitleItem it : res) {
                    long shift = 0;
                    for (long[] m : subMap) {
                        if (it.startMs >= m[0]) shift = m[1] - m[0];
                    }
                    SubtitleItem mi = new SubtitleItem(it.startMs + shift, it.endMs + shift, it.text);
                    mi.auto = true;
                    mi.sig = subSig;
                    mapped.add(mi);
                }
                if (subReplace) subs.clear();
                subs.addAll(mapped);
                Collections.sort(subs, (x, y) -> Long.compare(x.startMs, y.startMs));
                say("Subtitle otomatis selesai, " + mapped.size() + " baris ditambahkan. Total " + subs.size()
                        + " subtitle. Periksa dan ubah teks yang salah di daftar subtitle."
                        + (prefs().getBoolean("sub_cut", true)
                        ? " Edit lewat teks aktif: tombol Hapus pada sebuah kalimat ikut memotong video di bagian itu."
                        : ""));
            });
        }).start();
    }

    private void cancelExport() {
        if (splitter != null && splitter.isRunning()) {
            say("Membatalkan pemotongan.");
            splitter.cancel();
            return;
        }
        if (!exporting || transformer == null) return;
        transformer.cancel();
        if (outFile != null) outFile.delete();
        setBusy(false);
        say("Ekspor dibatalkan.");
        if (queueRunning) stopQueue();
    }

    private void setBusy(boolean busy) {
        exporting = busy;
        if (!busy) {
            if (!queueRunning) ExportService.stop(this);
            if (sfxBedFile != null) { sfxBedFile.delete(); sfxBedFile = null; }
        }
        btnExport.setEnabled(!busy);
        btnCancel.setVisibility(busy ? View.VISIBLE : View.GONE);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        progress.setProgress(0);
        if (busy) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void saveToGallery(final File src, final boolean audio) {
        say("Menyimpan hasil ekspor.");
        new Thread(() -> {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String name = "VideoLab_" + stamp + (audio ? ".m4a" : ".mp4");
            String mime = audio ? "audio/mp4" : "video/mp4";
            String folder = audio ? "Music/VideoLab" : "Movies/VideoLab";
            String result;
            Uri savedUri = null;
            Uri pendingUri = null;
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri collection = audio ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                            : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    Uri uri = getContentResolver().insert(collection, v);
                    if (uri == null) throw new java.io.IOException("penyimpanan menolak berkas baru");
                    pendingUri = uri;
                    try (OutputStream os = getContentResolver().openOutputStream(uri);
                         InputStream is = new FileInputStream(src)) {
                        if (os == null) throw new java.io.IOException("berkas tujuan tidak bisa dibuka");
                        copy(is, os);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    lastSavedUri = uri;
                    lastSavedMime = mime;
                    savedUri = uri;
                    pendingUri = null;
                } else {
                    File base = Environment.getExternalStoragePublicDirectory(
                            audio ? Environment.DIRECTORY_MUSIC : Environment.DIRECTORY_MOVIES);
                    File dir = new File(base, "VideoLab");
                    dir.mkdirs();
                    File dst = new File(dir, name);
                    try (OutputStream os = new FileOutputStream(dst);
                         InputStream is = new FileInputStream(src)) {
                        copy(is, os);
                    }
                    final String mimeFinal = mime;
                    MediaScannerConnection.scanFile(this, new String[]{dst.getAbsolutePath()},
                            new String[]{mime}, (path, scanned) -> {
                                lastSavedUri = scanned;
                                lastSavedMime = mimeFinal;
                                if (scanned != null) {
                                    final Uri sc = scanned;
                                    runOnUiThread(() -> {
                                        if (!isFinishing() && !queueRunning) results.show(results.describe(sc, audio),
                                                "Selesai. " + (audio ? "Audio" : "Video") + " disimpan di folder "
                                                        + folder.replace("/", ", ") + ", dengan nama " + name + ".");
                                    });
                                }
                            });
                }
                result = "Selesai. " + (audio ? "Audio" : "Video") + " disimpan di folder "
                        + folder.replace("/", ", ") + ", dengan nama " + name + ".";
            } catch (Exception e) {
                result = "Gagal menyimpan: " + e.getMessage();
                if (pendingUri != null) {
                    try { getContentResolver().delete(pendingUri, null, null); } catch (Exception ignored) { }
                }
            }
            src.delete();
            final String r = result;
            final Uri su = savedUri;
            runOnUiThread(() -> {
                setBusy(false);
                say(r);
                if (queueRunning) { onQueueItemDone(r.startsWith("Selesai")); return; }
                if (su != null && !isFinishing()) results.show(results.describe(su, audio), r);
                if (!visible) ExportNotifier.finished(VideoLabActivity.this, r.startsWith("Selesai"), r);
            });
        }).start();
    }

    private static void copy(InputStream is, OutputStream os) throws java.io.IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
    }
}
