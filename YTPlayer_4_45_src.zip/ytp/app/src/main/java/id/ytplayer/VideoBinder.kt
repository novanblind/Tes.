package id.ytplayer

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat

/** Mengisi kartu video (item_video) dan memasang aksi aksesibilitas TalkBack. */
object VideoBinder {
    private val handler = Handler(Looper.getMainLooper())
    private var prefetchTask: Runnable? = null

    /**
     * Video yang fokusnya bertahan ±0,45 detik (TalkBack berhenti di kartu itu) diambil infonya
     * lebih awal (hanya data, tidak memutar apa pun). Hanya satu video, yaitu yang sedang difokuskan.
     * Menggeser cepat melewati banyak kartu tidak memicu apa-apa, dan prefetch lama yang belum mulai
     * dibatalkan.
     */
    private fun schedulePrefetch(url: String) {
        prefetchTask?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            Repo.cancelQueuedPrefetch()
            Repo.prefetch(url)
        }
        prefetchTask = r
        handler.postDelayed(r, 450)
    }

    fun bind(
        root: View, item: VideoItem,
        onRemove: ((VideoItem) -> Unit)? = null,
        onOpen: (VideoItem, Boolean?) -> Unit
    ) {
        root.findViewById<ImageView>(R.id.thumb).let { ImageLoader.load(it, item.thumb) }
        root.findViewById<TextView>(R.id.duration).apply {
            if (item.isLive) {
                text = "LANGSUNG"
                visibility = View.VISIBLE
            } else if (item.durationSec > 0) {
                text = Fmt.clock(item.durationSec)
                visibility = View.VISIBLE
            } else {
                visibility = View.GONE
            }
        }
        root.findViewById<TextView>(R.id.title).text = item.title
        root.findViewById<TextView>(R.id.meta).text = item.meta()

        // Satu elemen fokus per video, dibacakan lengkap oleh TalkBack.
        root.contentDescription = item.spoken()
        root.setOnClickListener { onOpen(item, null) }
        root.setOnLongClickListener { onOpen(item, true); true }

        // Fokus TalkBack di kartu ini → siapkan aliran videonya di latar belakang.
        // (Delegasi dipasang lebih dulu, sebelum addAccessibilityAction di bawah.)
        ViewCompat.setAccessibilityDelegate(root, object : AccessibilityDelegateCompat() {
            override fun sendAccessibilityEvent(host: View, eventType: Int) {
                super.sendAccessibilityEvent(host, eventType)
                if (eventType == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED) {
                    schedulePrefetch(item.url)
                }
            }
        })

        // Aksi khusus (menu "Tindakan" TalkBack).
        ViewCompat.addAccessibilityAction(
            root, root.context.getString(R.string.action_play_audio)
        ) { _, _ -> onOpen(item, true); true }
        ViewCompat.addAccessibilityAction(
            root, root.context.getString(R.string.action_play_video)
        ) { _, _ -> onOpen(item, false); true }

        if (onRemove != null) {
            ViewCompat.addAccessibilityAction(root, "Hapus dari riwayat") { _, _ ->
                onRemove(item); true
            }
        }

        // Favorit dan bagikan lewat menu "Tindakan" TalkBack.
        val ctx = root.context
        ViewCompat.addAccessibilityAction(root, ctx.getString(R.string.action_favorite)) { _, _ ->
            val added = Store.toggleFavorite(ctx, item)
            Toast.makeText(
                ctx, if (added) "Ditambahkan ke favorit" else "Dihapus dari favorit", Toast.LENGTH_SHORT
            ).show()
            true
        }
        ViewCompat.addAccessibilityAction(root, ctx.getString(R.string.action_share)) { _, _ ->
            shareLink(ctx, item.title, item.url); true
        }

        // Unduh cepat lewat menu "Tindakan" TalkBack (audio M4A / video MP4 kualitas terbaik ≤ 1080p).
        val act = Downloads.findActivity(root.context)
        if (act != null) {
            ViewCompat.addAccessibilityAction(
                root, root.context.getString(R.string.action_download_audio)
            ) { _, _ -> Downloads.request(act, item.url, item.title, DownloadOptions.KEY_AUDIO); true }
            ViewCompat.addAccessibilityAction(
                root, root.context.getString(R.string.action_download_mp3)
            ) { _, _ -> Downloads.request(act, item.url, item.title, DownloadOptions.KEY_MP3_BEST); true }
            ViewCompat.addAccessibilityAction(
                root, root.context.getString(R.string.action_download_video)
            ) { _, _ -> Downloads.request(act, item.url, item.title, DownloadOptions.KEY_VIDEO_BEST); true }
        }
    }

    fun shareLink(ctx: Context, title: String, url: String) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, title)
            .putExtra(Intent.EXTRA_TEXT, if (title.isBlank()) url else "$title\n$url")
        ctx.startActivity(
            Intent.createChooser(send, "Bagikan tautan video").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
