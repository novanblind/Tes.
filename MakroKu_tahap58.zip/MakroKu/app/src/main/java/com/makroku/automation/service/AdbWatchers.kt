package com.makroku.automation.service

import android.content.Context
import android.os.PowerManager
import com.makroku.automation.adb.AdbBackend
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.AppCrashTrigger
import com.makroku.automation.model.AppRunningTrigger
import com.makroku.automation.model.ForegroundAdbTrigger
import com.makroku.automation.model.LogcatTrigger
import com.makroku.automation.model.MacroTrigger
import com.makroku.automation.model.NewFileTrigger
import com.makroku.automation.model.TriggerEvent
import java.util.concurrent.ConcurrentHashMap

/**
 * Pemantau yang membaca keadaan ponsel lewat ADB bawaan (tahap 37):
 * aplikasi mulai atau berhenti berjalan, aplikasi di depan berubah, berkas baru di folder, dan aplikasi berhenti sendiri.
 * Satu utas saja, hanya hidup bila ada makro aktif yang memakai salah satu pemicunya dan ADB sudah dipasangkan.
 * Bacaan pertama hanya menjadi acuan dan tidak memicu.
 */
class AdbWatchers(private val ctx: Context, private val engine: MacroEngine) {
    @Volatile private var runPkgs: Set<String> = emptySet()
    @Volatile private var dirs: Set<String> = emptySet()
    @Volatile private var fgOn = false
    @Volatile private var crashOn = false
    @Volatile private var alive = false
    @Volatile private var logNeedles: List<String> = emptyList()
    private var logSeen: Set<String>? = null
    private var lastLog = 0L
    private val logTagRe = Regex("^\\S+\\s+\\S+\\s+\\w/(.+?)\\(\\s*\\d+\\):")
    private var thread: Thread? = null

    private val runPrev = ConcurrentHashMap<String, Boolean>()
    private val dirSeen = ConcurrentHashMap<String, Set<String>>()
    private var fgPrev: String? = null
    private var crashSeen: Set<String>? = null
    private var lastRun = 0L
    private var lastFg = 0L
    private var lastDir = 0L
    private var lastCrash = 0L

    private val pkgRe = Regex("[A-Za-z0-9_.]+")

    private fun dirOk(x: String): Boolean {
        val awalOk = x == "/sdcard" || x.startsWith("/sdcard/") || x.startsWith("/storage/emulated/0/") || x.startsWith("/data/local/tmp/")
        return awalOk && !x.contains("..") && !x.contains('\n')
    }

    private fun sq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun update(list: List<MacroTrigger>) {
        runPkgs = list.filterIsInstance<AppRunningTrigger>().map { it.pkg.trim() }.filter { pkgRe.matches(it) }.toSet()
        dirs = list.filterIsInstance<NewFileTrigger>().map { it.watchDir.trim().trimEnd('/') }.filter { dirOk(it) }.toSet()
        fgOn = list.any { it is ForegroundAdbTrigger }
        crashOn = list.any { it is AppCrashTrigger }
        logNeedles = list.filterIsInstance<LogcatTrigger>().map { it.contains.trim().lowercase() }.filter { it.isNotEmpty() }.distinct()
        if (runPkgs.isNotEmpty() || dirs.isNotEmpty() || fgOn || crashOn || logNeedles.isNotEmpty()) start() else stop()
    }

    fun stop() {
        runPkgs = emptySet()
        dirs = emptySet()
        fgOn = false
        crashOn = false
        logNeedles = emptyList()
        logSeen = null
        alive = false
        thread?.interrupt()
        thread = null
        runPrev.clear()
        dirSeen.clear()
        fgPrev = null
        crashSeen = null
    }

    private fun start() {
        if (alive) return
        alive = true
        val th = Thread {
            while (alive) {
                try {
                    if (AdbBackend.dipasangkan(ctx)) tick()
                    Thread.sleep(1500)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                }
            }
        }
        th.isDaemon = true
        th.name = "makroku-adb-watch"
        th.start()
        thread = th
    }

    private fun tick() {
        val now = System.currentTimeMillis()

        val pk = runPkgs
        runPrev.keys.retainAll(pk)
        if (pk.isNotEmpty() && now - lastRun >= 10_000L) {
            lastRun = now
            for (p in pk) runCatching { cekJalan(p) }
        }

        if (fgOn) {
            if (now - lastFg >= 4_000L) {
                lastFg = now
                runCatching { cekDepan() }
            }
        } else {
            fgPrev = null
        }

        val dr = dirs
        dirSeen.keys.retainAll(dr)
        if (dr.isNotEmpty() && now - lastDir >= 10_000L) {
            lastDir = now
            for (d in dr) runCatching { cekBerkas(d) }
        }

        if (crashOn) {
            if (now - lastCrash >= 15_000L) {
                lastCrash = now
                runCatching { cekCrash() }
            }
        } else {
            crashSeen = null
        }

        if (logNeedles.isNotEmpty()) {
            if (now - lastLog >= 5_000L) {
                lastLog = now
                runCatching { cekLogcat() }
            }
        } else {
            logSeen = null
        }
    }

    private fun cekLogcat() {
        val needles = logNeedles
        val out = AdbBackend.shell(ctx, "logcat -d -v time -t 300", 20)
        val baris = out.lineSequence().filter { it.length > 18 && it[2] == '-' }.toList()
        val sebelum = logSeen
        logSeen = baris.toHashSet()
        if (sebelum == null) return
        var n = 0
        for (ln in baris) {
            if (ln in sebelum) continue
            val low = ln.lowercase()
            if (needles.none { low.contains(it) }) continue
            val tag = logTagRe.find(ln)?.groupValues?.get(1).orEmpty()
            engine.dispatch(TriggerEvent("logcat", mapOf("log_line" to ln.take(500), "log_tag" to tag)))
            n++
            if (n >= 10) break
        }
    }

    private fun cekJalan(p: String) {
        val out = AdbBackend.shell(ctx, "pidof $p", 10).trim()
        val jalan = out.isNotEmpty() && out.first().isDigit()
        val sebelum = runPrev.put(p, jalan)
        if (sebelum != null && sebelum != jalan) {
            engine.dispatch(TriggerEvent("app_running", mapOf("app_pkg" to p, "running" to jalan.toString())))
        }
    }

    private fun cekDepan() {
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (pm == null || !pm.isInteractive) return
        val out = AdbBackend.shell(ctx, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", 10)
        val re = Regex("([A-Za-z0-9_.]+)/([A-Za-z0-9_.\\$]+)")
        val m = out.lineSequence().mapNotNull { re.find(it) }.firstOrNull() ?: return
        val pkg = m.groupValues[1]
        val act = m.groupValues[2]
        val sebelum = fgPrev
        fgPrev = pkg
        if (sebelum != null && sebelum != pkg) {
            engine.dispatch(TriggerEvent("foreground_adb", mapOf("app_pkg" to pkg, "app_activity" to act)))
        }
    }

    private fun cekBerkas(dir: String) {
        val out = AdbBackend.shell(ctx, "ls -1 " + sq(dir) + " 2>/dev/null", 15)
        val nama = out.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        val sebelum = dirSeen.put(dir, nama) ?: return
        for (n in (nama - sebelum).sorted().take(5)) {
            engine.dispatch(TriggerEvent("new_file", mapOf("watch_dir" to dir, "file_name" to n, "file_path" to "$dir/$n")))
        }
    }

    private fun cekCrash() {
        val out = AdbBackend.shell(ctx, "logcat -b crash -d -v time -t 300", 20)
        val re = Regex("(\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+)\\s+\\S/AndroidRuntime\\(\\s*\\d+\\): Process: ([A-Za-z0-9_.]+), PID: (\\d+)")
        val sekarang = HashMap<String, String>()
        for (ln in out.lineSequence()) {
            val m = re.find(ln) ?: continue
            sekarang[m.groupValues[1] + "|" + m.groupValues[2] + "|" + m.groupValues[3]] = m.groupValues[2]
        }
        val sebelum = crashSeen
        crashSeen = sekarang.keys.toSet()
        if (sebelum == null) return
        for ((k, pkg) in sekarang) {
            if (k in sebelum) continue
            engine.dispatch(TriggerEvent("app_crash", mapOf("app_pkg" to pkg)))
        }
    }
}
