package com.makroku.automation.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.model.*
import java.util.Calendar

class ConstraintChecker(private val ctx: Context, private val repo: MacroRepository) {

    fun batteryLevel(): Int =
        ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    private fun isCharging(): Boolean {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val s = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun onWifi(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    /** [data] = data kejadian (mis. trigger_kind) untuk batasan yang butuh konteks pemicu. */
    fun check(c: MacroConstraint, data: Map<String, String> = emptyMap()): Boolean = when (c) {
        is OffConstraint -> true
        is BatteryTempConstraint -> {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tc = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
            if (c.below) tc <= c.celsius else tc >= c.celsius
        }
        is StorageFreeConstraint -> {
            val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
            val mb = st.availableBytes / (1024 * 1024)
            if (c.below) mb <= c.mb else mb >= c.mb
        }
        is ChargerTypeConstraint -> {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val p = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
            when (c.plugType) {
                "ac" -> p and BatteryManager.BATTERY_PLUGGED_AC != 0
                "usb" -> p and BatteryManager.BATTERY_PLUGGED_USB != 0
                "wireless" -> p and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0
                else -> p != 0
            }
        }
        is LogicConstraint -> {
            val rs = c.constraints.filter { it !is OffConstraint }.map { check(it, data) }
            when (c.logic) {
                "OR" -> rs.any { it }
                "XOR" -> rs.count { it } == 1
                "NOT" -> rs.none { it }
                else -> rs.all { it }
            }
        }
        is TriggerKindConstraint -> data["trigger_kind"] == c.triggerKind
        is TriggerIndexConstraint -> data["trigger_index"]?.toIntOrNull() == c.triggerNumber - 1
        is DarkThemeConstraint -> ((ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES) == c.on
        is MusicActiveConstraint -> ctx.getSystemService(android.media.AudioManager::class.java).isMusicActive == c.playing
        is CallStateConstraint -> {
            val mode = ctx.getSystemService(android.media.AudioManager::class.java).mode
            val now = when (mode) {
                android.media.AudioManager.MODE_RINGTONE -> "ringing"
                android.media.AudioManager.MODE_IN_CALL, android.media.AudioManager.MODE_IN_COMMUNICATION -> "in_call"
                else -> "idle"
            }
            now == c.callState
        }
        is VpnConstraint -> {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            (cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) == c.connected
        }
        is AdbOnConstraint ->
            (com.makroku.automation.adb.AdbBackend.dipasangkan(ctx) && com.makroku.automation.adb.AdbBackend.tersambung(ctx)) == c.connected
        is AppInstalledConstraint -> {
            val p = c.pkg.trim()
            val lewatPm = { runCatching { ctx.packageManager.getPackageInfo(p, 0); true }.getOrDefault(false) }
            val ada = if (p.isEmpty() || !Regex("[A-Za-z0-9_.]+").matches(p)) false
            else if (com.makroku.automation.adb.AdbBackend.dipasangkan(ctx)) {
                runCatching { com.makroku.automation.adb.AdbBackend.shell(ctx, "pm path $p", 15).contains("package:") }.getOrElse { lewatPm() }
            } else lewatPm()
            ada == c.installed
        }
        is ShellOutputConstraint -> runCatching {
            val out = com.makroku.automation.adb.AdbBackend.shell(ctx, c.command.trim(), 15)
            if (c.contains.isBlank()) out.isNotBlank() else out.contains(c.contains, ignoreCase = true)
        }.getOrDefault(false)
        is VolumeLevelConstraint -> {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val st = when (c.stream) {
                "ring" -> android.media.AudioManager.STREAM_RING
                "alarm" -> android.media.AudioManager.STREAM_ALARM
                "notification" -> android.media.AudioManager.STREAM_NOTIFICATION
                "system" -> android.media.AudioManager.STREAM_SYSTEM
                "voice" -> android.media.AudioManager.STREAM_VOICE_CALL
                else -> android.media.AudioManager.STREAM_MUSIC
            }
            val mx = am.getStreamMaxVolume(st).coerceAtLeast(1)
            val persen = am.getStreamVolume(st) * 100 / mx
            if (c.below) persen <= c.percent else persen >= c.percent
        }
        is OrientationConstraint -> {
            val rot = ctx.getSystemService(android.hardware.display.DisplayManager::class.java)
                ?.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.rotation ?: android.view.Surface.ROTATION_0
            val mendatar = rot == android.view.Surface.ROTATION_90 || rot == android.view.Surface.ROTATION_270
            mendatar == c.landscape
        }
        is DefaultKeyboardConstraint -> {
            val cur = android.provider.Settings.Secure.getString(ctx.contentResolver, "default_input_method").orEmpty()
            c.imeContains.isBlank() || cur.contains(c.imeContains.trim(), ignoreCase = true)
        }
        is A11yServiceConstraint -> {
            val list = android.provider.Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services").orEmpty()
            (c.component.isNotBlank() && list.contains(c.component.trim(), ignoreCase = true)) == c.enabled
        }
        is NotificationPresentConstraint -> {
            val l = com.makroku.automation.service.MacroNotificationListener.instance
            if (l == null) false else {
                val paket = c.pkgs.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                val re = Regex(c.contains.split('*').joinToString(".*") { Regex.escape(it) }, setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                val ada = runCatching { l.activeNotifications.toList() }.getOrDefault(emptyList()).any { sbn ->
                    if (sbn.packageName == ctx.packageName) return@any false
                    if (paket.isNotEmpty() && sbn.packageName !in paket) return@any false
                    if (c.contains.isBlank()) return@any true
                    val ex = sbn.notification.extras
                    val gabung = listOf(android.app.Notification.EXTRA_TITLE, android.app.Notification.EXTRA_TEXT, android.app.Notification.EXTRA_BIG_TEXT)
                        .joinToString("\n") { ex.getCharSequence(it)?.toString().orEmpty() }
                    // "*teks*" = mengandung teks; tanpa bintang = mengandung juga (bukan sama persis).
                    val polos = c.contains.trim('*')
                    if (polos.contains('*')) re.containsMatchIn(gabung) else gabung.contains(polos, ignoreCase = true)
                }
                ada == c.present
            }
        }
        is AppRunningConstraint -> {
            val p = c.pkg.trim()
            if (!Regex("[A-Za-z0-9_.]+").matches(p)) false else runCatching {
                val out = com.makroku.automation.adb.AdbBackend.shell(ctx, "pidof $p", 10).trim()
                (out.isNotEmpty() && out.first().isDigit()) == c.running
            }.getOrDefault(false)
        }
        is RamLevelConstraint -> {
            val mi = android.app.ActivityManager.MemoryInfo()
            ctx.getSystemService(android.app.ActivityManager::class.java).getMemoryInfo(mi)
            val persen = if (mi.totalMem > 0) (mi.availMem * 100 / mi.totalMem).toInt() else 0
            if (c.below) persen <= c.ramPercent else persen >= c.ramPercent
        }
        is PermissionGrantedConstraint -> {
            val p = c.pkg.trim()
            val izin = c.permission.trim()
            if (!Regex("[A-Za-z0-9_.]+").matches(p) || !Regex("[A-Za-z0-9_.]+").matches(izin)) false else runCatching {
                com.makroku.automation.adb.AdbBackend.izinDiberi(ctx, p, izin) == c.granted
            }.getOrDefault(false)
        }
        is TimeRangeConstraint -> {
            val cal = Calendar.getInstance()
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val from = c.fromHour * 60 + c.fromMinute
            val to = c.toHour * 60 + c.toMinute
            if (from <= to) now in from..to else now >= from || now <= to
        }
        is DayConstraint -> Calendar.getInstance().get(Calendar.DAY_OF_WEEK) in c.days
        is BatteryConstraint -> batteryLevel().let { if (c.below) it <= c.level else it >= c.level }
        is ChargingConstraint -> isCharging() == c.charging
        is ScreenConstraint -> ctx.getSystemService(PowerManager::class.java).isInteractive == c.on
        is WifiConstraint -> onWifi() == c.connected
        is VariableConstraint -> repo.variables.value[c.name].orEmpty() == c.value
        is VariableCompareConstraint -> Compare.test(repo.variables.value[c.name].orEmpty(), c.cmp, c.value)
        is StringCompareConstraint -> Compare.teks(
            Magic.expand(c.left, data, repo.variables.value), c.textCmp,
            Magic.expand(c.right, data, repo.variables.value), c.regex, c.ignoreCase,
        )
        is AirplaneConstraint ->
            (android.provider.Settings.Global.getInt(ctx.contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1) == c.on
        is BluetoothConstraint ->
            (ctx.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter?.isEnabled == true) == c.enabled
        is RingerConstraint -> {
            val mode = ctx.getSystemService(android.media.AudioManager::class.java).ringerMode
            val want = when (c.ringerMode) {
                "silent" -> android.media.AudioManager.RINGER_MODE_SILENT
                "vibrate" -> android.media.AudioManager.RINGER_MODE_VIBRATE
                else -> android.media.AudioManager.RINGER_MODE_NORMAL
            }
            mode == want
        }
        is DayOfMonthConstraint -> Calendar.getInstance().get(Calendar.DAY_OF_MONTH).let { d ->
            if (c.fromDay <= c.toDay) d in c.fromDay..c.toDay else d >= c.fromDay || d <= c.toDay
        }
        is HeadphoneConstraint -> {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val has = am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).any {
                it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET ||
                    it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
            }
            has == c.plugged
        }
        is InternetConstraint -> {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true) == c.connected
        }
        is LockedConstraint ->
            ctx.getSystemService(android.app.KeyguardManager::class.java).isKeyguardLocked == c.locked
        is CellularConstraint -> {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) == c.connected
        }
        is WifiSsidConstraint -> {
            @Suppress("DEPRECATION")
            val cur = ctx.applicationContext.getSystemService(android.net.wifi.WifiManager::class.java)
                ?.connectionInfo?.ssid.orEmpty().trim('"')
            val same = cur.isNotEmpty() && !cur.contains("unknown ssid") &&
                (c.ssid.isBlank() || cur.equals(c.ssid.trim('"'), ignoreCase = true))
            same == c.connected
        }
        is ForegroundAppConstraint ->
            c.pkg.isBlank() || com.makroku.automation.service.MacroAccessibilityService.currentPkg == c.pkg.trim()
        is SyncConstraint -> android.content.ContentResolver.getMasterSyncAutomatically() == c.on
        is PowerSaveConstraint -> ctx.getSystemService(PowerManager::class.java).isPowerSaveMode == c.on
        is DndConstraint ->
            (ctx.getSystemService(android.app.NotificationManager::class.java).currentInterruptionFilter !=
                android.app.NotificationManager.INTERRUPTION_FILTER_ALL) == c.on
    }
}
