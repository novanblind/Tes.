package com.novan.filemanagermax

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.DateFormat
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.net.Uri
import android.media.MediaScannerConnection
import android.text.InputType
import androidx.appcompat.view.ActionMode
import androidx.core.content.FileProvider
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Date
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Perpustakaan: daftar berkas menurut jenis (gambar, audio, video, dokumen, dst). */
class LibraryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_FOLDER = "folder"
        const val IMAGES = "images"
        const val AUDIO = "audio"
        const val VIDEO = "video"
        const val DOCS = "docs"
        const val DOWNLOADS = "downloads"
        const val APKS = "apks"
        const val ARCHIVES = "archives"
        const val ZIPS = "zips"
        const val RECENT = "recent"
        const val LARGE = "large"

        fun label(kind: String): Int = when (kind) {
            IMAGES -> R.string.lib_images
            AUDIO -> R.string.lib_audio
            VIDEO -> R.string.lib_video
            DOCS -> R.string.lib_docs
            DOWNLOADS -> R.string.lib_downloads
            APKS -> R.string.lib_apks
            ZIPS -> R.string.lib_zips
            RECENT -> R.string.lib_recent
            LARGE -> R.string.lib_large
            else -> R.string.lib_archives
        }

        fun icon(kind: String): Int = when (kind) {
            IMAGES -> R.drawable.ic_image
            AUDIO -> R.drawable.ic_audio
            VIDEO -> R.drawable.ic_video
            DOCS -> R.drawable.ic_file
            DOWNLOADS -> R.drawable.ic_download
            APKS -> R.drawable.ic_apk
            ZIPS -> R.drawable.ic_archive
            RECENT -> R.drawable.ic_clock
            LARGE -> R.drawable.ic_chart
            else -> R.drawable.ic_archive
        }

        val DOC_EXT = listOf(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt",
            "ods", "odp", "csv", "epub", "html", "htm", "xml", "json", "md"
        )
        val APK_EXT = listOf("apk", "apk+", "apks", "xapk", "apkm")
        val ARCHIVE_EXT = listOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz")
        val ZIP_EXT = listOf("zip")
        private const val LIMIT = 1500
        private const val ZIP_DEPTH = 12
        private const val ZIP_MAX = 5000

        /**
         * Semua berkas .zip di penyimpanan internal dan kartu memori, dibaca langsung dari
         * folder agar tidak ada yang terlewat walau MediaStore belum memuatnya. Folder
         * Android/data dan Android/obb dilewati (tidak bisa dibaca aplikasi lain).
         */
        private fun zipFiles(c: android.content.Context, hidden: Boolean): List<File> {
            val out = ArrayList<File>()
            fun scan(dir: File, depth: Int) {
                if (out.size >= ZIP_MAX) return
                val list = try { dir.listFiles() } catch (e: Exception) { null } ?: return
                for (f in list) {
                    if (out.size >= ZIP_MAX) return
                    if (!hidden && f.name.startsWith(".")) continue
                    if (f.name == ".FileManagerMaxTrash") continue
                    if (f.isDirectory) {
                        if (depth <= 0) continue
                        val path = f.absolutePath
                        if (path.endsWith("/Android/data") || path.endsWith("/Android/obb")) continue
                        scan(f, depth - 1)
                    } else if (f.extension.equals("zip", ignoreCase = true)) out.add(f)
                }
            }
            for (v in Volumes.list(c)) scan(v.root, ZIP_DEPTH)
            return out
        }

        /** Akar media WhatsApp dan WhatsApp Business, relatif ke akar penyimpanan. */
        private val WA_ROOTS = listOf(
            "Android/media/com.whatsapp/WhatsApp/Media" to "WhatsApp",
            "Android/media/com.whatsapp.w4b/WhatsApp Business/Media" to "WhatsApp Business",
            "WhatsApp/Media" to "WhatsApp",
            "WhatsApp Business/Media" to "WhatsApp Business"
        )
        private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic")
        private val VID_EXT = setOf("mp4", "3gp", "mkv", "webm", "mov", "avi")
        private val AUD_EXT = setOf("opus", "m4a", "aac", "mp3", "ogg", "oga", "amr", "wav", "flac", "wma", "mka")
        private const val WA_DEPTH = 4

        /** Nama folder media WhatsApp (tanpa awalan "WhatsApp ") untuk tiap kategori. */
        private fun waFolders(kind: String): List<String> = when (kind) {
            IMAGES -> listOf("Images")
            VIDEO -> listOf("Video", "Animated Gifs")
            AUDIO -> listOf("Voice Notes", "Audio")
            else -> emptyList()
        }

        private fun walk(dir: File, exts: Set<String>, depth: Int, out: MutableList<File>) {
            val list = try { dir.listFiles() } catch (e: Exception) { null } ?: return
            for (f in list) {
                if (f.name.startsWith(".")) continue
                if (f.isDirectory) {
                    if (depth > 0) walk(f, exts, depth - 1, out)
                } else if (f.extension.lowercase() in exts) out.add(f)
            }
        }

        /**
         * Media WhatsApp (gambar, video, catatan suara, audio) dan status. MediaStore sering
         * tidak memuatnya (folder Android/media, berkas .opus, atau ada .nomedia), jadi dibaca
         * langsung dari folder. Folder media selalu disertakan; status (.Statuses, tersembunyi)
         * hanya saat "tampilkan file tersembunyi" aktif.
         */
        fun hiddenExtras(c: android.content.Context, kind: String, hidden: Boolean): List<File> {
            if (kind == ZIPS) return zipFiles(c, hidden)
            if (kind != IMAGES && kind != VIDEO && kind != AUDIO) return emptyList()
            val exts = when (kind) {
                IMAGES -> IMG_EXT
                AUDIO -> AUD_EXT
                else -> VID_EXT
            }
            val out = ArrayList<File>()
            for (v in Volumes.list(c)) {
                for ((rel, brand) in WA_ROOTS) {
                    val base = File(v.root, rel)
                    if (!base.isDirectory) continue
                    for (name in waFolders(kind)) {
                        walk(File(base, "$brand $name"), exts, WA_DEPTH, out)
                    }
                    if (hidden) {
                        val st = try { File(base, ".Statuses").listFiles() } catch (e: Exception) { null }
                        if (st != null) for (f in st) if (f.isFile && f.extension.lowercase() in exts) out.add(f)
                    }
                }
            }
            return out
        }

        /** Gambar, audio, video, dokumen, dan ZIP ditampilkan per folder; ketuk folder untuk melihat isinya. */
        fun foldered(kind: String): Boolean =
            kind == IMAGES || kind == AUDIO || kind == VIDEO || kind == DOCS || kind == ZIPS

        fun hiddenFor(c: android.content.Context, kind: String): Boolean =
            if (foldered(kind)) Prefs.libHidden(c, kind) else Prefs.showHidden(c)

        /** Jumlah ukuran dan banyak berkas untuk satu jenis, dipakai di layar awal. */
        fun stats(c: android.content.Context, kind: String): Pair<Long, Int> {
            val ff = MediaStore.Files.FileColumns.DATA
            val mt = MediaStore.Files.FileColumns.MEDIA_TYPE
            var sel: String? = null
            var args: Array<String>? = null
            fun byExt(exts: List<String>) {
                sel = exts.joinToString(" OR ") { "$ff LIKE ?" }
                args = exts.map { "%.$it" }.toTypedArray()
            }
            when (kind) {
                IMAGES -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}"
                AUDIO -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}"
                VIDEO -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}"
                DOCS -> byExt(DOC_EXT)
                APKS -> byExt(APK_EXT)
                ARCHIVES -> byExt(ARCHIVE_EXT)
                ZIPS -> byExt(ZIP_EXT)
                RECENT -> {
                    sel = "${MediaStore.Files.FileColumns.DATE_MODIFIED}>=?"
                    args = arrayOf(((System.currentTimeMillis() / 1000) - 7L * 86400L).toString())
                }
                DOWNLOADS -> {
                    sel = "$ff LIKE ?"
                    args = arrayOf("%/Download/%")
                }
            }
            var size = 0L
            var count = 0
            val hidden = hiddenFor(c, kind)
            val seen = HashSet<String>()
            try {
                c.contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(ff, MediaStore.Files.FileColumns.SIZE), sel, args, null
                )?.use { cur ->
                    while (cur.moveToNext()) {
                        val p = cur.getString(0) ?: continue
                        if (p.contains("/.FileManagerMaxTrash/")) continue
                        if (!hidden && p.contains("/.")) continue
                        seen.add(p)
                        if (kind == RECENT && p.contains("/Android/")) continue
                        if (kind == DOCS || kind == APKS || kind == ARCHIVES || kind == ZIPS || kind == RECENT || kind == DOWNLOADS) {
                            if (!File(p).isFile) continue
                        }
                        size += cur.getLong(1)
                        count++
                    }
                }
            } catch (e: Exception) {
                // abaikan
            }
            for (f in hiddenExtras(c, kind, hidden)) {
                if (seen.add(f.absolutePath)) {
                    size += f.length()
                    count++
                }
            }
            return size to count
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private lateinit var kind: String
    private var files: List<File> = emptyList()
    private var folder: String? = null
    private var inFolderList = false
    private var folderDirs: List<File> = emptyList()
    private var actionMode: ActionMode? = null

    private class Act(val label: String, val run: () -> Unit)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        kind = intent.getStringExtra(EXTRA_KIND) ?: IMAGES
        folder = intent.getStringExtra(EXTRA_FOLDER)
        inFolderList = foldered(kind) && folder == null
        title = folder?.let { File(it).name } ?: getString(label(kind))

        empty = findViewById(R.id.empty)
        empty.setText(R.string.lib_empty)
        rowAdapter = RowAdapter(onClick = { onClickRow(it) }, onLong = { onRowLong(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.adapter = rowAdapter
        applyViewMode()
        findViewById<android.widget.Button>(R.id.pasteDo).setOnClickListener {
            folder?.let { paste(File(it)) }
        }
        findViewById<android.widget.Button>(R.id.pasteCancel).setOnClickListener {
            Clipboard.clear()
            invalidateOptionsMenu()
        }
    }

    private fun gridable(): Boolean = kind == IMAGES || kind == VIDEO

    /** Gambar dan Video tampil sebagai kisi secara bawaan; pengguna bisa memilih daftar. */
    private fun applyViewMode() {
        val list = findViewById<RecyclerView>(R.id.list)
        val grid = gridable() && Prefs.libGrid(this, kind)
        rowAdapter.grid = grid
        list.layoutManager = if (grid) {
            val dp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
            androidx.recyclerview.widget.GridLayoutManager(this, (dp / 110).toInt().coerceAtLeast(2))
        } else {
            LinearLayoutManager(this)
        }
    }

    private fun showViewDialog() {
        val labels = arrayOf(getString(R.string.view_grid), getString(R.string.view_list))
        val now = if (Prefs.libGrid(this, kind)) 0 else 1
        AlertDialog.Builder(this)
            .setTitle(R.string.view_title)
            .setSingleChoiceItems(labels, now) { dialog, which ->
                Prefs.setLibGrid(this, kind, which == 0)
                dialog.dismiss()
                applyViewMode()
                rowAdapter.notifyDataSetChanged()
                load()
            }
            .show()
    }

    override fun onStart() {
        super.onStart()
        OpService.listeners.add(opListener)
    }

    override fun onStop() {
        super.onStop()
        OpService.listeners.remove(opListener)
    }

    override fun onResume() {
        super.onResume()
        invalidateOptionsMenu()
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        opDialog?.dismiss()
        executor.shutdownNow()
    }

    private fun load() {
        val hidden = hiddenFor(this, kind)
        if (inFolderList) { loadFolders(hidden); return }
        executor.execute {
            val out = query(hidden)
            val rows = out.map { toRow(it) }
            main.post {
                if (isFinishing || isDestroyed) return@post
                files = out
                actionMode?.finish()
                rowAdapter.submit(rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                supportActionBar?.subtitle = getString(R.string.items_count, rows.size)
            }
        }
    }

    /** Daftar folder yang berisi file kategori ini, lengkap dengan jumlah dan ukuran. */
    private fun loadFolders(hidden: Boolean) {
        executor.execute {
            val ff = MediaStore.Files.FileColumns.DATA
            val mt = MediaStore.Files.FileColumns.MEDIA_TYPE
            val exts = when (kind) {
                DOCS -> DOC_EXT
                ZIPS -> ZIP_EXT
                else -> null
            }
            val sel: String
            val selArgs: Array<String>?
            if (exts != null) {
                sel = exts.joinToString(" OR ") { "$ff LIKE ?" }
                selArgs = exts.map { "%.$it" }.toTypedArray()
            } else {
                val type = when (kind) {
                    IMAGES -> MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                    AUDIO -> MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO
                    else -> MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                }
                sel = "$mt=$type"
                selArgs = null
            }
            val groups = HashMap<String, LongArray>()
            val seen = HashSet<String>()
            try {
                contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(ff, MediaStore.Files.FileColumns.SIZE), sel, selArgs, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val p = c.getString(0) ?: continue
                        if (p.contains("/.FileManagerMaxTrash/")) continue
                        if (!hidden && p.contains("/.")) continue
                        val lm = File(p).lastModified()
                        if (lm == 0L) continue
                        seen.add(p)
                        val parent = p.substringBeforeLast('/', "")
                        if (parent.isEmpty()) continue
                        val g = groups.getOrPut(parent) { LongArray(3) }
                        g[0]++
                        g[1] += c.getLong(1)
                        if (lm > g[2]) g[2] = lm
                    }
                }
            } catch (e: Exception) {
                // izin belum diberikan atau penyedia gagal: tampil kosong
            }
            for (f in hiddenExtras(this, kind, hidden)) {
                if (!seen.add(f.absolutePath)) continue
                val g = groups.getOrPut(f.parent ?: continue) { LongArray(3) }
                g[0]++
                g[1] += f.length()
                if (f.lastModified() > g[2]) g[2] = f.lastModified()
            }
            // Folder yang berisi berkas terbaru ada di paling atas.
            val dirs = groups.keys.map { File(it) }.filter { it.isDirectory }
                .sortedWith(
                    compareByDescending<File> { groups[it.absolutePath]?.get(2) ?: 0L }
                        .thenBy { it.name.lowercase() }
                )
            val rows = dirs.map { d ->
                val g = (groups[d.absolutePath] ?: LongArray(3))
                val count = getString(R.string.items_count, g[0].toInt())
                val size = Util.formatSize(this, g[1])
                Row(
                    R.drawable.ic_folder, d.name, "$count, $size, ${d.parent ?: ""}",
                    "${d.name}, $count, $size", d.absolutePath
                )
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                folderDirs = dirs
                actionMode?.finish()
                rowAdapter.submit(rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                supportActionBar?.subtitle = getString(R.string.items_count, rows.size)
            }
        }
    }

    private fun query(hidden: Boolean): List<File> {
        val ff = MediaStore.Files.FileColumns.DATA
        val mt = MediaStore.Files.FileColumns.MEDIA_TYPE
        var sel = ""
        var args: Array<String>? = null
        fun byExt(exts: List<String>) {
            sel = exts.joinToString(" OR ") { "$ff LIKE ?" }
            args = exts.map { "%.$it" }.toTypedArray()
        }
        when (kind) {
            IMAGES -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}"
            AUDIO -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}"
            VIDEO -> sel = "$mt=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}"
            DOCS -> byExt(DOC_EXT)
            APKS -> byExt(APK_EXT)
            ARCHIVES -> byExt(ARCHIVE_EXT)
            ZIPS -> byExt(ZIP_EXT)
            RECENT -> {
                sel = "${MediaStore.Files.FileColumns.DATE_MODIFIED}>=?"
                args = arrayOf(((System.currentTimeMillis() / 1000) - 7L * 86400L).toString())
            }
            LARGE -> {
                sel = "${MediaStore.Files.FileColumns.SIZE}>=?"
                args = arrayOf((50L * 1024 * 1024).toString())
            }
            DOWNLOADS -> {
                sel = "$ff LIKE ?"
                args = arrayOf("%/Download/%")
            }
        }
        val inDir = folder
        if (inDir != null) {
            sel = "($sel) AND $ff LIKE ?"
            args = (args?.toList() ?: emptyList()).plus("$inDir/%").toTypedArray()
        }
        val out = ArrayList<File>()
        try {
            contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                arrayOf(ff), sel, args,
                if (kind == LARGE) "${MediaStore.Files.FileColumns.SIZE} DESC"
                else "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < LIMIT) {
                    val p = c.getString(0) ?: continue
                    if (p.contains("/.FileManagerMaxTrash/")) continue
                    if (!hidden && p.contains("/.")) continue
                    if (kind == RECENT && p.contains("/Android/")) continue
                    if (inDir != null && p.substringBeforeLast('/', "") != inDir) continue
                    val f = File(p)
                    if (f.isFile) out.add(f)
                }
            }
        } catch (e: Exception) {
            // izin belum diberikan atau penyedia gagal: tampil kosong
        }
        val extras = hiddenExtras(this, kind, hidden).filter { inDir == null || it.parent == inDir }
        if (extras.isNotEmpty()) {
            val have = out.mapTo(HashSet()) { it.absolutePath }
            for (f in extras) if (have.add(f.absolutePath)) out.add(f)
        }
        if (kind == LARGE) return out
        // Urut dari yang paling baru di atas ke yang paling lama di bawah, memakai waktu ubah
        // berkas sebenarnya (tanggal di MediaStore kadang tidak mutakhir).
        return out.map { it to it.lastModified() }
            .sortedWith(compareByDescending<Pair<File, Long>> { it.second }.thenBy { it.first.name.lowercase() })
            .map { it.first }
    }

    private fun toRow(f: File): Row {
        val size = Util.formatSize(this, f.length())
        val date = DateFormat.getMediumDateFormat(this).format(Date(f.lastModified()))
        val where = f.parentFile?.name ?: ""
        val detail = if (folder != null) "$size, $date" else "$size, $date, $where"
        val thumb = if (gridable() && Prefs.showThumbs(this)) f.absolutePath else null
        return Row(icon(kind), f.name, detail, "${f.name}, $detail", f.absolutePath, null, thumb)
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun openFolder(d: File) {
        startActivity(
            Intent(this, LibraryActivity::class.java)
                .putExtra(EXTRA_KIND, kind)
                .putExtra(EXTRA_FOLDER, d.absolutePath)
        )
    }

    private fun items(): List<File> = if (inFolderList) folderDirs else files

    private fun onClickRow(i: Int) {
        if (actionMode != null) { toggle(i); return }
        if (inFolderList) {
            if (i in folderDirs.indices) openFolder(folderDirs[i])
            return
        }
        if (i !in files.indices) return
        if (!Util.openSmart(this, files[i], files)) say(getString(R.string.cannot_open))
    }

    private fun onRowLong(i: Int) {
        if (i !in items().indices) return
        if (actionMode != null) toggle(i) else showActions(i)
    }

    private fun showActions(i: Int) {
        val f = items().getOrNull(i) ?: return
        val acts = ArrayList<Act>()
        acts.add(Act(getString(R.string.menu_select)) { startSelection(i) })
        acts.add(Act(getString(R.string.act_open)) { onClickRow(i) })
        if (f.isDirectory && Clipboard.size > 0) {
            acts.add(Act(getString(R.string.paste_here, Clipboard.size)) { paste(f) })
        }
        acts.add(Act(getString(R.string.action_copy)) { toClipboard(listOf(f), false) })
        acts.add(Act(getString(R.string.action_cut)) { toClipboard(listOf(f), true) })
        acts.add(Act(getString(R.string.act_rename)) { promptRename(f) })
        acts.add(Act(getString(R.string.act_compress)) { promptCompress(listOf(f)) })
        acts.add(Act(getString(R.string.action_delete)) { confirmDelete(listOf(f)) })
        if (f.isFile) {
            acts.add(Act(getString(R.string.action_share)) { share(listOf(f)) })
            acts.add(Act(getString(R.string.action_share_doc)) { shareDoc(listOf(f)) })
            acts.add(Act(getString(R.string.act_open_with)) {
                if (!Util.openWith(this, f)) say(getString(R.string.cannot_open))
            })
        }
        acts.add(Act(getString(if (f.isDirectory) R.string.lib_browse_folder else R.string.act_show_in_folder)) {
            val p = if (f.isDirectory) f else f.parentFile
            if (p != null) {
                startActivity(
                    Intent(this, BrowserActivity::class.java)
                        .putExtra(BrowserActivity.EXTRA_ROOT, p.absolutePath)
                        .putExtra(BrowserActivity.EXTRA_TITLE, p.name)
                )
            }
        })
        acts.add(Act(getString(R.string.act_properties)) { showProperties(f) })
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(acts.map { it.label }.toTypedArray()) { _, which -> acts[which].run() }
            .show()
    }

    // ---------------------------------------------------------------- mode pilih

    private val modeCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            menuInflater.inflate(R.menu.library_selection_menu, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.sel_all -> { rowAdapter.setAllSelected(true); updateModeTitle() }
                R.id.sel_copy -> withSelection { toClipboard(it, false); mode.finish() }
                R.id.sel_cut -> withSelection { toClipboard(it, true); mode.finish() }
                R.id.sel_delete -> withSelection { confirmDelete(it) }
                R.id.sel_share -> withSelection { share(it) }
                R.id.sel_share_doc -> withSelection { shareDoc(it) }
                R.id.sel_compress -> withSelection { promptCompress(it) }
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            actionMode = null
            rowAdapter.setAllSelected(null)
        }
    }

    private fun startSelection(initial: Int?) {
        if (actionMode != null) return
        actionMode = startSupportActionMode(modeCallback)
        rowAdapter.setAllSelected(false)
        if (initial != null) rowAdapter.setSelected(initial, true)
        updateModeTitle()
    }

    private fun toggle(i: Int) {
        if (i !in rowAdapter.rows.indices) return
        rowAdapter.setSelected(i, rowAdapter.rows[i].selected != true)
        updateModeTitle()
    }

    private fun updateModeTitle() {
        actionMode?.title = getString(R.string.n_selected, rowAdapter.selectedIndices().size)
    }

    private fun withSelection(block: (List<File>) -> Unit) {
        val all = items()
        val sel = rowAdapter.selectedIndices().filter { it in all.indices }.map { all[it] }
        if (sel.isNotEmpty()) block(sel)
    }

    // ---------------------------------------------------------------- operasi

    private fun filesUnder(list: List<File>): List<String> {
        val out = ArrayList<String>()
        for (f in list) {
            if (f.isDirectory) f.walkTopDown().filter { it.isFile }.forEach { out.add(it.absolutePath) }
            else out.add(f.absolutePath)
        }
        return out
    }

    /**
     * Menjalankan operasi berkas di latar belakang. [before] adalah berkas/folder yang akan
     * berubah (jalur lamanya dipindai ulang agar hilang dari MediaStore); [work] mengembalikan
     * pesan hasil dan lokasi barunya (dipindai agar muncul di MediaStore).
     */
    private fun runTask(msgRes: Int?, before: List<File>, work: () -> Pair<String, List<File>>) {
        val dlg = msgRes?.let { AlertDialog.Builder(this).setMessage(it).setCancelable(false).show() }
        executor.execute {
            val old = filesUnder(before)
            var news: List<File> = emptyList()
            val result = try {
                val r = work()
                news = r.second
                r.first
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            val paths = (old + filesUnder(news)).distinct()
            main.post {
                if (isDestroyed) return@post
                dlg?.dismiss()
                actionMode?.finish()
                say(result)
                invalidateOptionsMenu()
                load()
            }
            if (paths.isNotEmpty()) {
                val left = AtomicInteger(paths.size)
                MediaScannerConnection.scanFile(this, paths.toTypedArray(), null) { _, _ ->
                    if (left.decrementAndGet() == 0) {
                        main.post { if (!isFinishing && !isDestroyed) load() }
                    }
                }
            }
        }
    }

    private var opSeen = OpService.version

    private val notifPermLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    private val opListener: (String) -> Unit = { msg ->
        if (!isDestroyed) {
            opSeen = OpService.version
            actionMode?.finish()
            say(msg)
            invalidateOptionsMenu()
            load()
        }
    }

    /** Menjalankan operasi di layanan latar depan agar tetap jalan walau layar atau aplikasi ditutup. */
    private fun startOp(job: OpService.Job) {
        if (OpService.needsNotifPermission(this) && !libNotifAsked) {
            libNotifAsked = true
            notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        actionMode?.finish()
        OpService.enqueue(this, job)
        opDialog?.dismiss()
        opDialog = OpDialog(this, job) { say(getString(R.string.op_hidden)) }.also { it.show() }
    }

    private var opDialog: OpDialog? = null

    private fun toClipboard(list: List<File>, cut: Boolean) {
        Clipboard.set(list, cut)
        invalidateOptionsMenu()
        say(getString(if (cut) R.string.clip_cut_lib else R.string.clip_copy_lib, list.size))
    }

    private fun paste(dest: File) {
        val cut = Clipboard.cut
        val title = getString(if (cut) R.string.op_moving else R.string.op_copying)
        val zip = Clipboard.zipArchive
        val target = dest
        val files = Clipboard.files.toList()
        val zipEntries = Clipboard.zipEntries
        val zipTops = Clipboard.zipTops
        val conflicts = if (zip != null) Conflicts.forZip(zipTops, zipEntries, target)
        else Conflicts.forFiles(files, cut, target)
        val go = { actions: Map<String, ConflictAction> ->
            val job = if (zip != null) {
                OpJobs.pasteZip(zip, zipEntries, zipTops, cut, target, title, actions)
            } else {
                OpJobs.paste(files, cut, target, title, actions)
            }
            // Setelah ditempel, papan klip kosong lagi dan tombol Tempel hilang.
            Clipboard.clear()
            invalidateOptionsMenu()
            startOp(job)
        }
        if (conflicts.isEmpty()) {
            go(emptyMap())
        } else {
            // Papan klip tetap utuh bila pengguna menekan Batal.
            Conflicts.ask(this, conflicts) { actions -> if (actions != null) go(actions) }
        }
    }

    private fun confirmDelete(list: List<File>) {
        DeleteDialog.show(this, list) { toTrash -> doDelete(list, toTrash) }
    }

    private fun doDelete(list: List<File>, toTrash: Boolean) {
        startOp(OpJobs.delete(list, toTrash, getString(R.string.op_deleting)))
    }

    private fun promptName(titleRes: Int, initial: String, onOk: (String) -> Unit) {
        val edit = EditText(this).apply {
            setText(initial)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            hint = getString(R.string.name_hint)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(edit)
        }
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(edit.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun validName(name: String): Boolean =
        name.isNotEmpty() && !name.contains('/') && name != "." && name != ".."

    private fun promptRename(f: File) {
        promptName(R.string.act_rename, f.name) { newName ->
            if (!validName(newName)) { say(getString(R.string.invalid_name)); return@promptName }
            if (newName == f.name) return@promptName
            val target = File(f.parentFile, newName)
            if (target.exists()) { say(getString(R.string.already_exists)); return@promptName }
            runTask(null, listOf(f)) {
                if (f.renameTo(target)) getString(R.string.renamed) to listOf(target)
                else getString(R.string.rename_failed) to emptyList()
            }
        }
    }

    private fun promptCompress(list: List<File>) {
        val dir = list[0].parentFile ?: return
        val labels = arrayOf(
            getString(R.string.fmt_zip), getString(R.string.fmt_targz), getString(R.string.fmt_7z),
            getString(R.string.fmt_zip_split)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.compress_format)
            .setItems(labels) { _, format ->
                val base = if (list.size == 1) list[0].name else dir.name
                CompressLevel.pick(this) { level ->
                  CompressLevel.askPassword(this, format == ArchiveOps.OUT_ZIP || format == ArchiveOps.OUT_ZIP_SPLIT) { password ->
                   SplitSize.pick(this, format == ArchiveOps.OUT_ZIP_SPLIT) { split ->
                    promptName(R.string.act_compress, base) { name ->
                        if (!validName(name)) { say(getString(R.string.invalid_name)); return@promptName }
                        val out = FileOps.uniqueTarget(dir, name + ArchiveOps.outExt(format))
                        startOp(OpJobs.compress(list, format, out, getString(R.string.op_compressing), level, password, split))
                    }
                   }
                  }
                }
            }
            .show()
    }

    private fun share(list: List<File>) {
        val fs = list.filter { it.isFile }
        if (fs.isEmpty()) { say(getString(R.string.no_files_share)); return }
        try {
            val intent = if (fs.size == 1) {
                Intent(Intent.ACTION_SEND)
                    .setType(Util.mimeOf(fs[0]))
                    .putExtra(Intent.EXTRA_STREAM, Util.uriOf(this, fs[0]))
            } else {
                val uris = ArrayList<Uri>(fs.map { Util.uriOf(this, it) })
                Intent(Intent.ACTION_SEND_MULTIPLE)
                    .setType("*/*")
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
        } catch (e: Exception) {
            say(getString(R.string.op_failed, e.message ?: ""))
        }
    }

    private fun shareDoc(list: List<File>) {
        val fs = list.filter { it.isFile }
        if (fs.isEmpty()) { say(getString(R.string.no_files_share)); return }
        if (!Util.shareAsDocument(this, fs)) say(getString(R.string.cannot_open))
    }

    private fun showProperties(f: File) {
        PropsDialog.showFile(this, f)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.library_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_lib_hidden)?.apply {
            isVisible = foldered(kind)
            isChecked = Prefs.libHidden(this@LibraryActivity, kind)
        }
        menu.findItem(R.id.action_lib_select)?.isVisible = true
        menu.findItem(R.id.action_lib_view)?.isVisible = gridable()
        val canPaste = folder != null && Clipboard.size > 0
        menu.findItem(R.id.action_lib_paste)?.apply {
            isVisible = canPaste
            title = getString(R.string.menu_paste_count, Clipboard.size)
        }
        findViewById<View>(R.id.pasteBar).visibility = if (canPaste) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.pasteInfo).text = getString(
            if (Clipboard.cut) R.string.paste_bar_move else R.string.paste_bar_copy,
            Clipboard.size
        )
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        android.R.id.home -> { finish(); true }
        R.id.action_lib_select -> { if (items().isNotEmpty()) startSelection(null); true }
        R.id.action_lib_paste -> { folder?.let { paste(File(it)) }; true }
        R.id.action_lib_view -> { showViewDialog(); true }
        R.id.action_lib_hidden -> {
            Prefs.setLibHidden(this, kind, !Prefs.libHidden(this, kind))
            invalidateOptionsMenu()
            load()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}

private var libNotifAsked = false
