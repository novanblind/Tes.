package com.novan.filemanagermax

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import java.io.File

/** Daftar penyimpanan yang bisa dibaca: internal, kartu SD, dan flashdisk USB. */
object Volumes {
    class Vol(val label: String, val root: File)

    fun list(c: Context): List<Vol> {
        val out = ArrayList<Vol>()
        val seen = HashSet<String>()
        val usbOn = Prefs.usbConnect(c)

        fun canon(f: File): String = try { f.canonicalPath } catch (e: Exception) { f.absolutePath }

        fun add(label: String, root: File) {
            val key = canon(root)
            if (!seen.add(key)) return
            // dua penyimpanan bernama sama dibedakan dengan nama folder akarnya
            val unique = if (out.any { it.label == label }) "$label (${root.name})" else label
            out.add(Vol(unique, root))
        }

        val primary = Environment.getExternalStorageDirectory()
        add(c.getString(R.string.internal_storage), primary)
        seen.add(canon(File("/storage/self/primary")))

        // Cara lama: kartu memori yang dilaporkan sistem lewat folder data aplikasi.
        val dirs = c.getExternalFilesDirs(null)
        for (i in 1 until dirs.size) {
            val d = dirs[i] ?: continue
            val idx = d.absolutePath.indexOf("/Android/data")
            if (idx <= 0) continue
            val root = File(d.absolutePath.substring(0, idx))
            if (!root.exists() || !root.canRead()) continue
            if (!usbOn && looksLikeUsb(c, root)) continue
            add(labelFor(c, root), root)
        }

        // Sambung USB: flashdisk, kartu OTG, dan penyimpanan lepasan lain yang tidak
        // dilaporkan lewat cara lama.
        if (usbOn) {
            try {
                findRemovable(c, ::add)
            } catch (e: Exception) {
                // abaikan, penyimpanan lain tetap tampil
            }
        }
        return out
    }

    /** Penyimpanan lepasan yang sedang terpasang menurut StorageManager, lalu pemindaian /storage. */
    private fun findRemovable(c: Context, add: (String, File) -> Unit) {
        val sm = c.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        for (sv in sm.storageVolumes) {
            if (sv.isPrimary) continue
            val st = sv.state
            if (st != Environment.MEDIA_MOUNTED && st != Environment.MEDIA_MOUNTED_READ_ONLY) continue
            val dir = pathOf(sv) ?: continue
            if (!dir.exists() || !dir.canRead()) continue
            add(describe(c, sv, dir), dir)
        }
        // Sebagian ponsel tidak melaporkan flashdisk OTG ke StorageManager, tetapi
        // memasangnya sebagai folder di /storage (mis. /storage/XXXX-XXXX atau /storage/usbotg).
        for (base in listOf("/storage", "/mnt/usb_storage", "/mnt/usbhost", "/mnt/otg")) {
            val kids = File(base).listFiles() ?: continue
            for (d in kids) {
                val n = d.name
                if (n == "emulated" || n == "self" || n.startsWith(".")) continue
                if (!d.isDirectory || !d.canRead()) continue
                // folder pengait kosong (tidak ada isi dan tidak bisa didaftar) dilewati
                if (d.listFiles() == null) continue
                add(labelFor(c, d, usbHint = true), d)
            }
        }
    }

    private fun pathOf(sv: StorageVolume): File? {
        if (Build.VERSION.SDK_INT >= 30) return sv.directory
        return try {
            val p = StorageVolume::class.java.getMethod("getPath").invoke(sv) as? String
            if (p.isNullOrBlank()) null else File(p)
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(c: Context, sv: StorageVolume, dir: File): String {
        val desc = try { sv.getDescription(c) } catch (e: Exception) { null }
        if (!desc.isNullOrBlank()) return desc
        return c.getString(R.string.usb_drive)
    }

    private fun looksLikeUsb(c: Context, root: File): Boolean {
        val n = root.name.lowercase()
        if (n.contains("usb") || n.contains("otg")) return true
        return try {
            val sm = c.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            sm.getStorageVolume(root)?.getDescription(c)?.lowercase()?.contains("usb") == true
        } catch (e: Exception) {
            false
        }
    }

    /** Nama dari sistem (mis. "Penyimpanan USB" atau "Kartu SD"); bila kosong pakai nama bawaan. */
    private fun labelFor(c: Context, root: File, usbHint: Boolean = false): String {
        val fallback = if (usbHint) c.getString(R.string.usb_drive) else c.getString(R.string.sd_card)
        return try {
            val sm = c.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            sm.getStorageVolume(root)?.getDescription(c)?.takeIf { it.isNotBlank() } ?: fallback
        } catch (e: Exception) {
            fallback
        }
    }
}
