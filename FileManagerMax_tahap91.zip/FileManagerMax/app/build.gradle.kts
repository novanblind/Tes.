plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.novan.filemanagermax"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.novan.filemanagermax"
        minSdk = 26
        targetSdk = 34
        versionCode = 89
        versionName = "0.89.0"

        // Satu APK untuk HP 32-bit (armeabi-v7a) dan 64-bit (arm64-v8a). x86 dan x86_64 (emulator, Chromebook) dibuang
        // supaya pustaka native (libarchive, OCR) tidak dikemas empat kali.
        ndk {
            abiFilters += setOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        // Pustaka native (.so) dikompresi di dalam APK (minSdk 26 secara bawaan menyimpannya tanpa kompresi).
        // Saat dipasang, Android mengekstraknya. Tanpa R8 / minify.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*",
                "META-INF/INDEX.LIST", "META-INF/*.kotlin_module", "META-INF/versions/**",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/MANIFEST.MF"
            )
        }
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.viewpager:viewpager:1.0.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("org.apache.commons:commons-compress:1.26.2")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.junrar:junrar:7.5.5")
    implementation("net.lingala.zip4j:zip4j:2.11.5")
    implementation("me.zhanghai.android.libarchive:library:1.1.6")
    implementation("commons-net:commons-net:3.11.1")
    implementation("com.github.mwiede:jsch:0.2.19")
    implementation("com.hierynomus:smbj:0.13.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // pdfbox-android membawa BouncyCastle versi jdk15to18 yang bentrok dengan jdk18on milik smbj,
    // jadi dikecualikan dan diganti satu set jdk18on saja.
    implementation("com.tom-roush:pdfbox-android:2.0.27.0") {
        exclude(group = "org.bouncycastle", module = "bcprov-jdk15to18")
        exclude(group = "org.bouncycastle", module = "bcpkix-jdk15to18")
        exclude(group = "org.bouncycastle", module = "bcutil-jdk15to18")
    }
    implementation("org.bouncycastle:bcprov-jdk18on:1.75")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.75")
    // OCR offline (tahap 79): model teks Latin ikut di dalam aplikasi, jadi tanpa internet dan tanpa
    // Google Play Services. Pustaka native tersedia untuk armeabi-v7a (32 bit), arm64-v8a (64 bit),
    // x86 dan x86_64; tidak ada abiFilters sehingga semuanya ikut dikemas.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
