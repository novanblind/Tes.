package com.novan.filemanagerpro

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Date
import java.util.concurrent.Executors

/** Menjelajahi lokasi jarak jauh: buka, unduh, unggah, folder baru, ganti nama, hapus. */
class RemoteBrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "id"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private lateinit var cfg: RemoteConfig
    private var client: RemoteClient? = null
    private var rootPath = "/"
    private var cur = "/"
    private var entries: List<RemoteEntry> = emptyList()
    private var afterPick: ((File) -> Unit)? = null

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) afterPick?.invoke(File(p))
            afterPick = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val c = RemoteStore.get(this, intent.getStringExtra(EXTRA_ID) ?: "")
        if (c == null) { finish(); return }
        cfg = c
        title = cfg.name
        empty = findViewById(R.id.empty)
        rowAdapter = RowAdapter(onClick = { onRowClick(it) }, onLong = { showActions(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goUp()
        })
        loadDir(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        val cl = client
        client = null
        executor.execute { try { cl?.close() } catch (e: Exception) { } }
        executor.shutdown()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun goUp() {
        if (cur == rootPath || cur == "/") finish() else loadDir(parentPath(cur))
    }

    private fun ensureClient(): RemoteClient {
        client?.let { return it }
        val cl = cfg.openClient()
        try {
            cl.connect()
        } catch (e: Throwable) {
            try { cl.close() } catch (x: Exception) { }
            throw e
        }
        client = cl
        rootPath = cl.startPath()
        return cl
    }

    private fun errText(e: Throwable): String = e.message ?: e.javaClass.simpleName

    private fun resetClient() {
        val cl = client
        client = null
        try { cl?.close() } catch (e: Exception) { }
    }

    /** [path] null berarti jalur awal. */
    private fun loadDir(path: String?) {
        empty.setText(R.string.remote_loading)
        empty.visibility = View.VISIBLE
        executor.execute {
            try {
                val cl = ensureClient()
                val target = path ?: cl.startPath()
                val list = cl.list(target).sortedWith(
                    compareBy<RemoteEntry>({ !it.isDir }, { it.name.lowercase() })
                )
                val rows = list.map { e ->
                    val detail = if (e.isDir) getString(R.string.folder) else {
                        Formatter.formatFileSize(this, e.size) +
                            (if (e.time > 0) ", " + DateFormat.getMediumDateFormat(this).format(Date(e.time)) else "")
                    }
                    Row(
                        if (e.isDir) R.drawable.ic_folder else R.drawable.ic_file,
                        e.name, detail, "${e.name}, $detail", e
                    )
                }
                main.post {
                    if (isFinishing || isDestroyed) return@post
                    cur = target
                    entries = list
                    rowAdapter.submit(rows)
                    empty.setText(R.string.empty_folder)
                    empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                    supportActionBar?.subtitle = target
                }
            } catch (e: Throwable) {
                resetClient()
                main.post {
                    if (isFinishing || isDestroyed) return@post
                    empty.setText(R.string.remote_failed_short)
                    empty.visibility = View.VISIBLE
                    say(getString(R.string.remote_failed, errText(e)))
                }
            }
        }
    }

    private fun runTask(msg: Int, reload: Boolean, work: (RemoteClient) -> String) {
        val dlg = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        executor.execute {
            val result = try {
                work(ensureClient())
            } catch (e: Throwable) {
                resetClient()
                getString(R.string.remote_failed, errText(e))
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                say(result)
                if (reload) loadDir(cur)
            }
        }
    }

    private fun onRowClick(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        if (e.isDir) { loadDir(joinPath(cur, e.name)); return }
        val dir = File(cacheDir, "remote").also { it.mkdirs() }
        val dest = File(dir, e.name)
        val dlg = AlertDialog.Builder(this).setMessage(R.string.remote_downloading).setCancelable(false).show()
        executor.execute {
            val err = try {
                ensureClient().download(joinPath(cur, e.name), dest)
                null
            } catch (t: Throwable) {
                resetClient()
                errText(t)
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                if (err != null) say(getString(R.string.remote_failed, err))
                else if (!Util.openSmart(this, dest, listOf(dest))) say(getString(R.string.cannot_open))
            }
        }
    }

    private fun showActions(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        val labels = ArrayList<String>()
        if (!e.isDir) labels.add(getString(R.string.remote_download))
        labels.add(getString(R.string.act_rename))
        labels.add(getString(R.string.action_delete))
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setItems(labels.toTypedArray()) { _, which ->
                val label = labels[which]
                when (label) {
                    getString(R.string.remote_download) -> downloadTo(e)
                    getString(R.string.act_rename) -> promptName(R.string.act_rename, e.name) { rename(e, it) }
                    else -> confirmDelete(e)
                }
            }
            .show()
    }

    private fun pick(mode: String, title: Int, then: (File) -> Unit) {
        afterPick = then
        pickLauncher.launch(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_ROOT, "/storage/emulated/0")
                .putExtra(BrowserActivity.EXTRA_TITLE, getString(title))
                .putExtra(BrowserActivity.EXTRA_MODE, mode)
        )
    }

    private fun downloadTo(e: RemoteEntry) {
        pick(BrowserActivity.MODE_PICK_FOLDER, R.string.remote_pick_folder) { dir ->
            runTask(R.string.remote_downloading, false) { cl ->
                val target = FileOps.uniqueTarget(dir, e.name)
                cl.download(joinPath(cur, e.name), target)
                getString(R.string.remote_downloaded, target.absolutePath)
            }
        }
    }

    private fun upload() {
        pick(BrowserActivity.MODE_PICK_FILE, R.string.remote_pick_file) { f ->
            runTask(R.string.remote_uploading, true) { cl ->
                cl.upload(f, joinPath(cur, f.name))
                getString(R.string.remote_uploaded, f.name)
            }
        }
    }

    private fun rename(e: RemoteEntry, newName: String) {
        if (newName.isBlank() || newName.contains("/")) { say(getString(R.string.remote_bad_name)); return }
        runTask(R.string.remote_working, true) { cl ->
            cl.rename(joinPath(cur, e.name), joinPath(cur, newName))
            getString(R.string.remote_done)
        }
    }

    private fun confirmDelete(e: RemoteEntry) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_confirm_title)
            .setMessage(getString(R.string.remote_delete_item, e.name))
            .setPositiveButton(R.string.action_delete) { _, _ ->
                runTask(R.string.remote_working, true) { cl ->
                    cl.delete(joinPath(cur, e.name), e.isDir)
                    getString(R.string.remote_done)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun promptName(titleRes: Int, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.setText(initial)
        input.setSelection(initial.length)
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(input.text.toString().trim()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun newFolder(name: String) {
        if (name.isBlank() || name.contains("/")) { say(getString(R.string.remote_bad_name)); return }
        runTask(R.string.remote_working, true) { cl ->
            cl.mkdir(joinPath(cur, name))
            getString(R.string.remote_done)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.remote_browser_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> goUp()
            R.id.action_remote_upload -> upload()
            R.id.action_remote_newfolder -> promptName(R.string.menu_new_folder, "") { newFolder(it) }
            R.id.action_remote_refresh -> loadDir(cur)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
