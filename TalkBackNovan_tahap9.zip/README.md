# TalkBack Novan

Pembaca layar Android buatan Novan. Paket: `com.novan.talkbacknovan`.
Kode ditulis baru (Java, tanpa dependensi luar), terinspirasi fitur Jieshuo Lite.

## Membangun APK (tanpa Android Studio)
1. Unggah isi folder ini ke repo GitHub.
2. Buka tab Actions, jalankan "Bangun APK" (otomatis saat push).
3. Unduh artefak `TalkBackNovan` (berisi `TalkBackNovan.apk`).
APK memakai kunci tanda tangan tetap `app/novan.jks`, sehingga bisa dipasang sebagai pembaruan.
minSdk 30, targetSdk 36. Tidak ada kode native, jadi satu APK berjalan di 32-bit dan 64-bit.

## Tahap 1
- Layanan aksesibilitas dengan mode jelajah sentuh
- Ucapan: fokus, jendela/dialog, status sakelar, notifikasi dan toast, live region
- Gema ketikan (karakter/kata), pembacaan kursor
- Gestur: geser kanan/kiri, beranda, kembali, aplikasi terbaru, notifikasi, ketuk dua jari = diam
- Pengaturan: kecepatan, nada, pilihan mesin TTS, umpan balik, getar

## Tahap 2 (ini)
- Granularitas: geser bawah/atas mengganti cara pindah. Pilihan: item, judul, tautan, tombol,
  kolom isian, kotak centang dan sakelar, gambar, karakter, kata, kalimat, paragraf.
  Geser kanan/kiri lalu pindah menurut pilihan itu (per teks juga menggeser kursor di kolom isian).
- Gestur dua jari (bisa diganti di Pengaturan): usap atas = gulir maju, bawah = gulir mundur,
  kiri = halaman berikutnya, kanan = halaman sebelumnya, ketuk dua kali = baca seluruh layar.
- Gestur tiga jari (bisa diganti): ketuk = jam dan baterai, atas = pengaturan cepat,
  bawah = notifikasi, kiri = ulangi ucapan terakhir, kanan = baca dari item ini.
- Tombol volume: tekan lama volume atas = ketuk elemen terfokus, volume bawah = baca dari item ini
  (bisa diganti atau dimatikan). Tekan singkat tetap mengatur volume.
- Ucapan posisi saat daftar digulir ("item 5 sampai 10 dari 30").
- Ada 22 aksi yang bisa dipasang ke gestur/tombol (lihat `Aksi.java`).

## Tahap 3 (ini)
- Pendengar notifikasi: membaca nama aplikasi, judul, dan isi (aktifkan lewat tombol "Beri akses notifikasi"); toast tetap dibaca lewat layanan aksesibilitas
- Daftar hitam notifikasi dan daftar hitam bacaan otomatis (perubahan isi, gulir, pengumuman) per aplikasi
- Ganti nama elemen: aksi "Ganti nama elemen terfokus" (pasang ke gestur/tombol) atau ubah aturan di Pengaturan

## Tahap 4 (ini)
- Salin, tempel, potong, dan pilih semua teks (aksi yang bisa dipasang ke gestur/tombol)
- Menu elemen terfokus (bawaan: ketuk dua kali tiga jari): ketuk, ketuk lama, salin, tempel, aksi khusus aplikasi, baca dari sini, ganti nama
- Mode baca: aksi "Tampilkan teks layar" membuka halaman berisi seluruh teks layar, bisa dijelajahi per karakter/kata/paragraf, disalin, atau dibagikan

## Tahap 5 (ini)
- OCR memakai Gemini dan Groq lewat API (tanpa pustaka tambahan, butuh internet dan kunci API sendiri)
- Aksi "OCR seluruh layar" dan "OCR elemen terfokus" (pasang ke gestur/tombol; OCR elemen juga ada di menu elemen)
- Bagikan gambar dari aplikasi lain ke "OCR TalkBack Novan" untuk mengenali teksnya
- Mesin utama bisa dipilih; bila gagal, mesin lain dicoba otomatis. Nama model bisa diubah di Pengaturan
  (bawaan: gemini-2.5-flash dan qwen/qwen3.8-27b)

## Tahap 6 (ini)
- Perintah suara (bawaan: ketuk empat jari): memakai pengenal suara bawaan sistem. Contoh: "beranda", "kembali",
  "aplikasi terbaru", "notifikasi", "baca layar", "baca dari sini", "salin", "tempel", "gulir ke bawah",
  "berikutnya", "ocr", "menu", "jam", "buka WhatsApp" (membuka aplikasi menurut nama)
- Gestur kustom: 12 kombinasi usapan satu jari, ketuk tiga kali dua/tiga/empat jari, ketuk satu/dua kali dan usap empat jari,
  semuanya bisa diberi aksi apa pun di Pengaturan (sebelumnya empat kombinasi tertanam: beranda, kembali, terbaru, notifikasi)

## Tahap 7 (ini)
- Efek suara buatan kode (tanpa berkas audio): fokus, ketuk, ketuk lama, ganti jendela, gulir, batas daftar, salin. Volume dan sakelar di Pengaturan
- Kecilkan audio lain saat berbicara (audio focus)
- Berhenti bicara saat sensor jarak tertutup, dan saat layar disentuh (keduanya opsional)
- Volume ucapan terpisah, kekuatan dan lama getar bisa diatur

## Tahap 8 (ini)
- Tombol volume: tekan dua/tiga kali (atas dan bawah) bisa diberi aksi. Tanpa aksi, volume tetap berubah seperti biasa
- Tombol headset: klik, klik dua kali, tahan (aktifkan di Pengaturan)
- Aksi baru: percepat/perlambat bicara, tangkapan layar, menu daya, bisukan suara, salin ucapan terakhir, baca papan klip

## Tahap 8b (ini): tema suara
- Tema suara memakai berkas suara yang sama dengan JieShuo Lite (res/raw): fokus 0-4, klik, klik lama, ganti jendela, gulir atas/bawah, beep (akhir daftar), batal (kembali)
- Pemilihan suara fokus mengikuti aslinya: tombol/centang/isian = fokus1, papan ketik = fokus3, lainnya = fokus2; ganti granularitas = fokus0
- Belum ada: fokus4 (area tak terfokus), gestur tepi, tik/jam (menunggu timer), paket tema suara kustom

## Tahap 9 (ini): emoji Indonesia dan menu pengaturan bertingkat
- Emoji dibacakan dengan nama bahasa Indonesia dari `assets/emoji_id.txt` (3988 entri, termasuk warna kulit dan gabungan ZWJ; pencocokan terpanjang dulu). Sakelar di Pengaturan pengucapan konten (bawaan aktif)
- Pengaturan dibuat bertingkat seperti JieShuo Lite: Pengaturan umum, teks ke ucapan, umpan balik, tindakan (gestur satu/dua/tiga jari, volume, headset), pengucapan konten, pemberitahuan, lanjutan (OCR, metode masukan), aksesibilitas, bantuan
- Belum ada: Cari pengaturan, profil per aplikasi, plugin, gestur tepi dan multipart

## Usulan tahap berikutnya
9. Baca otomatis pesan chat per aplikasi, info penelepon, jam bicara dan timer, aturan ucapan (regex, simbol, emoji)
10. Mode edit lanjutan, terjemahan, deskripsi gambar otomatis
11. Profil per aplikasi, pencadangan pengaturan, log
