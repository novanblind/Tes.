package com.novan.filemanagermax

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityViewCommand
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors

/**
 * Penampil gambar bergaya galeri (tahap 83): satu halaman per gambar di dalam ViewPager klasik (sama
 * seperti File Manager asli), jadi bisa diusap ke kiri atau kanan (dengan TalkBack: usap dua jari) untuk
 * pindah ke gambar sebelum atau sesudahnya. Judul "2 dari 19" dengan nama berkas di bawahnya. Tombol OCR
 * di bilah atas; tombol Bagikan, Hapus, Info, dan Lainnya di bilah bawah. Bilah atas dan bawah transparan mengambang di atas gambar layar penuh;
 * ketuk gambar untuk menyembunyikan atau menampilkannya. Cubit atau ketuk dua kali untuk
 * memperbesar. Tombol Putar sudah dihapus.
 */
class ImageViewerActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var pager: ViewPager
    private val adapter: PageAdapter = PageAdapter()
    private var paths: MutableList<String> = ArrayList()
    private var uri: Uri? = null
    private var index = 0
    private var shownIndex = -1
    private val shownName: String by lazy { uri?.let { Util.displayName(this, it) } ?: "" }

    private var slideshow = false
    private val slideTick = object : Runnable {
        override fun run() {
            if (!slideshow) return
            if (paths.size > 1) pager.setCurrentItem((index + 1) % paths.size, true)
            main.postDelayed(this, 4000)
        }
    }

    private fun setSlideshow(on: Boolean) {
        slideshow = on
        main.removeCallbacks(slideTick)
        if (on) main.postDelayed(slideTick, 4000)
        say(getString(if (on) R.string.slideshow_started else R.string.slideshow_stopped))
    }

    override fun onPause() {
        super.onPause()
        if (slideshow) {
            slideshow = false
            main.removeCallbacks(slideTick)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Sama seperti File Manager asli: bilah atas dan bawah mengambang transparan di atas gambar layar penuh
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_viewer)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setBackgroundDrawable(ColorDrawable(0x66000000))
        applyChrome()
        pager = findViewById(R.id.imagePager)

        val arr = intent.getStringArrayExtra(Util.EXTRA_PATHS)
        if (arr != null && arr.isNotEmpty()) {
            paths = arr.toMutableList()
            index = savedInstanceState?.getInt("index") ?: intent.getIntExtra(Util.EXTRA_INDEX, 0)
        } else {
            val d = intent.data
            if (d != null && d.scheme == "file" && d.path != null) paths = arrayListOf(d.path!!) else uri = d
        }
        index = index.coerceIn(0, (count() - 1).coerceAtLeast(0))

        pager.adapter = adapter
        pager.setCurrentItem(index, false)
        shownIndex = index
        pager.pageMargin = (resources.displayMetrics.density * 8).toInt()
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                index = position
                updateTitle()
                if (position != shownIndex) {
                    shownIndex = position
                    pager.announceForAccessibility(labelOf(position))
                }
            }
        })
        updateTitle()

        val hasFile = paths.isNotEmpty()
        findViewById<View>(R.id.btnShare).apply {
            visibility = if (hasFile || uri != null) View.VISIBLE else View.GONE
            setOnClickListener { shareNow() }
        }
        findViewById<View>(R.id.btnDelete).apply {
            visibility = if (hasFile) View.VISIBLE else View.GONE
            setOnClickListener { deleteNow() }
        }
        findViewById<View>(R.id.btnInfo).apply {
            visibility = if (hasFile) View.VISIBLE else View.GONE
            setOnClickListener { infoNow() }
        }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMore(it) }
        // tekan lama tombol bawah: tampilkan namanya
        for (id in intArrayOf(R.id.btnShare, R.id.btnDelete, R.id.btnInfo, R.id.btnMore)) {
            findViewById<TextView>(id).setOnLongClickListener {
                Toast.makeText(this, (it as TextView).text, Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    private var chromeShown = true

    /** Tampilkan atau sembunyikan bilah atas, bilah bawah, dan bilah sistem. */
    private fun applyChrome() {
        if (chromeShown) supportActionBar?.show() else supportActionBar?.hide()
        findViewById<View?>(R.id.imageBar)?.visibility = if (chromeShown) View.VISIBLE else View.GONE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (chromeShown) 1792 else 3846
    }

    private fun toggleChrome() {
        chromeShown = !chromeShown
        applyChrome()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("index", index)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun count(): Int = if (paths.isNotEmpty()) paths.size else if (uri != null) 1 else 0

    private fun nameAt(i: Int): String =
        if (paths.isNotEmpty()) File(paths[i.coerceIn(0, paths.size - 1)]).name
        else uri?.let { shownName } ?: ""

    private fun labelOf(i: Int): String =
        if (count() > 1) getString(R.string.image_position, nameAt(i), i + 1, count()) else nameAt(i)

    private fun updateTitle() {
        if (count() > 1) {
            title = getString(R.string.image_count_title, index + 1, count())
            supportActionBar?.subtitle = nameAt(index)
        } else {
            title = nameAt(index)
            supportActionBar?.subtitle = null
        }
    }

    // ------------------------------------------------------------------ tombol bawah

    private fun shareNow() {
        if (paths.isNotEmpty()) {
            if (!Util.share(this, File(paths[index]))) say(getString(R.string.cannot_open))
            return
        }
        val u = uri ?: return
        try {
            val i = android.content.Intent(android.content.Intent.ACTION_SEND)
                .setType(contentResolver.getType(u) ?: "image/*")
                .putExtra(android.content.Intent.EXTRA_STREAM, u)
                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(android.content.Intent.createChooser(i, getString(R.string.share_chooser)))
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    private fun infoNow() {
        if (paths.isNotEmpty()) PropsDialog.showFile(this, File(paths[index]))
    }

    private fun deleteNow() {
        if (paths.isEmpty()) return
        val f = File(paths[index])
        DeleteDialog.show(this, listOf(f)) { toTrash ->
            val pos = index
            Thread {
                val ok = try {
                    if (toTrash) TrashManager.trash(f) else f.delete()
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    try {
                        MediaScannerConnection.scanFile(applicationContext, arrayOf(f.absolutePath), null, null)
                    } catch (e: Exception) {
                        // abaikan
                    }
                }
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    if (!ok) {
                        say(getString(R.string.image_delete_failed))
                        return@runOnUiThread
                    }
                    if (pos in paths.indices) paths.removeAt(pos)
                    if (paths.isEmpty()) {
                        finish()
                        return@runOnUiThread
                    }
                    val ni = pos.coerceAtMost(paths.size - 1)
                    index = ni
                    adapter.notifyDataSetChanged()
                    pager.setCurrentItem(ni, false)
                    shownIndex = ni
                    updateTitle()
                    say(getString(if (toTrash) R.string.image_trashed else R.string.image_deleted))
                }
            }.start()
        }
    }

    private fun showMore(@Suppress("UNUSED_PARAMETER") anchor: View) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (paths.isNotEmpty()) {
            labels.add(getString(R.string.action_share_doc))
            actions.add {
                if (!Util.shareAsDocument(this, listOf(File(paths[index])))) say(getString(R.string.cannot_open))
            }
            labels.add(getString(R.string.set_as))
            actions.add { chooseSetAs() }
            labels.add(getString(R.string.act_open_with))
            actions.add {
                if (!Util.openWith(this, File(paths[index]))) say(getString(R.string.cannot_open))
            }
        }
        if (labels.isEmpty()) return
        android.app.AlertDialog.Builder(this)
            .setTitle(R.string.img_btn_more)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun chooseSetAs() {
        if (paths.isEmpty()) return
        val f = File(paths[index])
        val labels = arrayOf(
            getString(R.string.wall_home), getString(R.string.wall_lock),
            getString(R.string.wall_both), getString(R.string.wall_other_app)
        )
        android.app.AlertDialog.Builder(this)
            .setTitle(R.string.set_as)
            .setItems(labels) { _, which ->
                if (which == 3) setAsOther(f) else setWallpaper(f, which)
            }
            .show()
    }

    private fun setAsOther(f: File) {
        try {
            startActivity(
                android.content.Intent.createChooser(
                    android.content.Intent(android.content.Intent.ACTION_ATTACH_DATA)
                        .setDataAndType(Util.uriOf(this, f), Util.mimeOf(f))
                        .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION),
                    getString(R.string.set_as)
                )
            )
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    /** which: 0 layar utama, 1 layar kunci, 2 keduanya. */
    private fun setWallpaper(f: File, which: Int) {
        say(getString(R.string.wall_working))
        Thread {
            val ok = try {
                val wm = android.app.WallpaperManager.getInstance(this)
                val flag = when (which) {
                    0 -> android.app.WallpaperManager.FLAG_SYSTEM
                    1 -> android.app.WallpaperManager.FLAG_LOCK
                    else -> android.app.WallpaperManager.FLAG_SYSTEM or android.app.WallpaperManager.FLAG_LOCK
                }
                f.inputStream().use { wm.setStream(it, null, true, flag) }
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (!isDestroyed) say(getString(if (ok) R.string.wall_done else R.string.wall_failed))
            }
        }.start()
    }

    /** Baca tulisan di gambar yang sedang tampil (OCR offline, ML Kit). */
    private fun startOcr() {
        val i = android.content.Intent(this, OcrActivity::class.java)
        val p = paths.getOrNull(index)
        if (p != null) {
            i.putExtra(OcrActivity.EXTRA_PATH, p)
        } else {
            val u = uri ?: return
            i.action = android.content.Intent.ACTION_VIEW
            i.data = u
            i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(i)
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    // ------------------------------------------------------------------ halaman

    private inner class PageAdapter : PagerAdapter() {

        override fun getCount(): Int = this@ImageViewerActivity.count()

        override fun isViewFromObject(view: View, obj: Any): Boolean = view === obj

        override fun getItemPosition(obj: Any): Int = POSITION_NONE

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val iv = ZoomImageView(container.context)
            iv.onTap = { toggleChrome() }
            iv.contentDescription = labelOf(position)
            iv.tag = position
            ViewCompat.addAccessibilityAction(iv, getString(R.string.image_prev), AccessibilityViewCommand { _, _ ->
                val cur: Int = pager.currentItem
                if (cur > 0) pager.setCurrentItem(cur - 1, true)
                cur > 0
            })
            ViewCompat.addAccessibilityAction(iv, getString(R.string.image_next), AccessibilityViewCommand { _, _ ->
                val cur: Int = pager.currentItem
                val last: Int = this@ImageViewerActivity.count() - 1
                if (cur < last) pager.setCurrentItem(cur + 1, true)
                cur < last
            })
            container.addView(
                iv,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            val path = paths.getOrNull(position)
            val u = uri
            executor.execute {
                val bmp = try {
                    if (path != null) decode({ File(path).inputStream() }, path, null)
                    else decode({ contentResolver.openInputStream(u!!) }, null, u)
                } catch (e: Throwable) {
                    null
                }
                main.post {
                    if (isFinishing || isDestroyed || iv.tag != position) return@post
                    if (bmp != null) {
                        iv.setImageBitmap(bmp)
                    } else {
                        say(getString(R.string.image_failed))
                    }
                }
            }
            return iv
        }

        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            val iv = obj as? ZoomImageView
            if (iv != null) {
                iv.tag = -1
                iv.setImageBitmap(null)
                container.removeView(iv)
            }
        }
    }

    private fun decode(open: () -> InputStream?, path: String?, u: Uri?): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = try {
            if (path != null) ExifInterface(path).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            ) else open()?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            else -> return bmp
        }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        return bmp
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.image_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_ocr).isVisible = count() > 0
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_ocr -> startOcr()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
