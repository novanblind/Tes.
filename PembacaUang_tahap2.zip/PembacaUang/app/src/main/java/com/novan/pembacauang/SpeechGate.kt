package com.novan.pembacauang

import android.os.SystemClock

/**
 * Pencegah pengulangan suara. Selama uang yang sama terus terbaca dengan jeda
 * antar-deteksi tidak lebih dari 1 detik, nominal tidak diucapkan lagi.
 * Pecahan baru, atau uang yang sama setelah >1 detik tidak terbaca, boleh diucapkan.
 * (Waktu deteksi terakhir selalu diperbarui, persis seperti aplikasi acuan.)
 */
class SpeechGate(
    private val repeatWindowMs: Long = 1000L,
    private val clock: () -> Long = { SystemClock.elapsedRealtime() },
) {
    private var lastKey: Int = 0
    private var lastTime: Long = 0L

    fun shouldSpeak(key: Int): Boolean {
        val now = clock()
        val sameAsBefore = key == lastKey && (now - lastTime) <= repeatWindowMs
        lastKey = key
        lastTime = now
        return !sameAsBefore
    }
}
