package com.makroku.automation.adb

import android.content.Context

/**
 * Mode tanpa Wi-Fi: setelah tersambung lewat Debugging nirkabel (butuh Wi-Fi satu kali),
 * adbd dipindah ke TCP 5555 dan aplikasi menyambung lewat 127.0.0.1. Wi-Fi boleh dimatikan.
 * Mode TCP hilang saat HP restart; setelah itu cukup nyalakan Wi-Fi, aplikasi menyambung dan pindah lagi sendiri.
 */
object Lokal {
    const val PORT = 5555

    @Volatile @JvmField var viaLokal = false

    private fun prefs(c: Context) = c.getSharedPreferences("adb_makroku", Context.MODE_PRIVATE)

    @JvmStatic fun modeAktif(c: Context): Boolean = prefs(c).getBoolean("tcp", false)

    /** Sambung lewat loopback (tidak butuh Wi-Fi). Hanya berhasil bila adbd sedang dalam mode TCP. */
    @JvmStatic fun sambungLokal(a: Adb): Boolean {
        try { a.connect("127.0.0.1", PORT) } catch (_: Throwable) {}
        viaLokal = a.isConnected
        return viaLokal
    }

    /** Pindahkan adbd ke TCP 5555 lalu sambung ulang lewat 127.0.0.1. Dipanggil saat sedang tersambung lewat Wi-Fi. */
    @JvmStatic fun aktifkanModeTanpaWifi(c: Context, a: Adb): String {
        try {
            if (!a.isConnected) return "Sambungkan dulu lewat Debugging nirkabel (Wi-Fi perlu aktif satu kali)."
            try { AdbBackend.jalankanPublik(a, "tcpip:$PORT") } catch (_: Throwable) {}
            try { a.disconnect() } catch (_: Throwable) {}
            for (k in 0 until 10) {
                try { Thread.sleep(1500) } catch (_: InterruptedException) { break }
                if (sambungLokal(a)) {
                    prefs(c).edit().putBoolean("tcp", true).apply()
                    return "Mode tanpa Wi-Fi aktif (127.0.0.1:$PORT). Berlaku sampai HP restart."
                }
            }
            try { a.sambungTls(c, 8000L) } catch (_: Throwable) {}
            return "Gagal pindah ke 127.0.0.1:$PORT. Sambungan tetap lewat Wi-Fi."
        } catch (e: Throwable) {
            return "Gagal mengaktifkan mode tanpa Wi-Fi: $e"
        }
    }
}
