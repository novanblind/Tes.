package com.makroku.automation.engine

/** Perbandingan angka (bila keduanya angka) atau teks, dipakai If/Else dan batasan variabel. */
object Compare {
    fun test(cur: String, cmp: String, value: String): Boolean {
        val a = cur.trim().toDoubleOrNull()
        val b = value.trim().toDoubleOrNull()
        val num = a != null && b != null
        return when (cmp) {
            "==" -> if (num) a == b else cur == value
            "!=" -> if (num) a != b else cur != value
            ">" -> num && a!! > b!!
            "<" -> num && a!! < b!!
            ">=" -> num && a!! >= b!!
            "<=" -> num && a!! <= b!!
            "mengandung" -> cur.contains(value, ignoreCase = true)
            else -> cur == value
        }
    }

    /** Perbandingan dua teks untuk batasan "Bandingkan dua teks". Regex memakai pencarian (find), bukan cocok penuh. */
    fun teks(a: String, cmp: String, b: String, regex: Boolean, ignoreCase: Boolean): Boolean {
        fun rx(): Boolean = runCatching {
            Regex(b, if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()).containsMatchIn(a)
        }.getOrDefault(false)
        return when (cmp) {
            "sama" -> a.equals(b, ignoreCase)
            "beda" -> !a.equals(b, ignoreCase)
            "mengandung" -> if (regex) rx() else a.contains(b, ignoreCase)
            "tidak_mengandung" -> if (regex) !rx() else !a.contains(b, ignoreCase)
            "diawali" -> a.startsWith(b, ignoreCase)
            "diakhiri" -> a.endsWith(b, ignoreCase)
            "cocok" -> rx()
            "tidak_cocok" -> !rx()
            else -> false
        }
    }
}
