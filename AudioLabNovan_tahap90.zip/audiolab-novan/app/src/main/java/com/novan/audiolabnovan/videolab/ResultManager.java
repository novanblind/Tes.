package com.novan.audiolabnovan.videolab;

import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

/**
 * Pemutar dan pengelola hasil ekspor di folder Movies/VideoLab dan Music/VideoLab.
 * Tombol: putar, jeda, lanjutkan, mundur cepat, maju cepat, bagikan, ubah nama, hapus.
 */
public final class ResultManager {

    public static final class Item {
        Uri uri;
        String name;
        boolean audio;
    }

    private final VideoLabActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ExoPlayer exo;
    private AlertDialog dialog;
    private TextView statusView;
    private TextView timeView;
    private TextView titleView;
    private SeekBar seekBar;
    private Button btnPlay;
    private Item item;
    private long durationMs = 0;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshTime();
            if (exo != null) ui.postDelayed(this, 500);
        }
    };

    public ResultManager(VideoLabActivity host) {
        this.host = host;
    }

    // ---------- daftar hasil ----------

    public void showList() {
        final ArrayList<Item> items = query();
        if (items.isEmpty()) {
            host.notice("Belum ada hasil ekspor di folder VideoLab.");
            return;
        }
        String[] names = new String[items.size()];
        for (int i = 0; i < names.length; i++) {
            Item it = items.get(i);
            names[i] = (it.audio ? "Audio: " : "Video: ") + it.name;
        }
        new AlertDialog.Builder(host)
                .setTitle("Pilih hasil ekspor")
                .setItems(names, (d, which) -> show(items.get(which), null))
                .setNegativeButton("Tutup", null)
                .show();
    }

    @SuppressWarnings("deprecation")
    private ArrayList<Item> query() {
        ArrayList<Item> out = new ArrayList<>();
        for (int k = 0; k < 2; k++) {
            boolean audio = k == 1;
            Uri coll = audio ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            String folder = audio ? "Music/VideoLab" : "Movies/VideoLab";
            String sel;
            String[] args;
            if (Build.VERSION.SDK_INT >= 29) {
                sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
                args = new String[]{folder + "/%"};
            } else {
                sel = MediaStore.MediaColumns.DATA + " LIKE ?";
                args = new String[]{"%/" + folder + "/%"};
            }
            try (Cursor c = host.getContentResolver().query(coll,
                    new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME},
                    sel, args, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
                if (c == null) continue;
                while (c.moveToNext()) {
                    Item it = new Item();
                    it.uri = ContentUris.withAppendedId(coll, c.getLong(0));
                    it.name = c.getString(1);
                    it.audio = audio;
                    out.add(it);
                }
            } catch (Exception ignored) {
                // izin tidak ada atau penyimpanan tidak bisa dibaca: daftar dilewati
            }
        }
        return out;
    }

    public Item describe(Uri uri, boolean audio) {
        Item it = new Item();
        it.uri = uri;
        it.audio = audio;
        String n = nameOf(uri);
        it.name = n != null ? n : (audio ? "hasil.m4a" : "hasil.mp4");
        return it;
    }

    private String nameOf(Uri uri) {
        try (Cursor c = host.getContentResolver().query(uri,
                new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    @SuppressWarnings("deprecation")
    private String pathOf(Uri uri) {
        try (Cursor c = host.getContentResolver().query(uri,
                new String[]{MediaStore.MediaColumns.DATA}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    // ---------- pemutar ----------

    public void show(Item it, String intro) {
        dismiss();
        item = it;
        durationMs = 0;
        host.pauseMain();
        float dp = host.getResources().getDisplayMetrics().density;

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * dp);
        col.setPadding(pad, pad / 2, pad, pad / 2);

        titleView = new TextView(host);
        titleView.setTextSize(16);
        titleView.setText(it.name);
        col.addView(titleView);

        exo = new ExoPlayer.Builder(host).build();
        if (!it.audio) {
            PlayerView pv = new PlayerView(host);
            pv.setUseController(false);
            pv.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            pv.setPlayer(exo);
            col.addView(pv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, (int) (200 * dp)));
        }

        statusView = new TextView(host);
        statusView.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        statusView.setText(intro != null ? intro : "Siap diputar.");
        col.addView(statusView);

        timeView = new TextView(host);
        timeView.setText("Posisi 0 detik");
        col.addView(timeView);

        seekBar = new SeekBar(host);
        seekBar.setContentDescription("Posisi putar");
        seekBar.setMax(1000);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (fromUser && exo != null) {
                    exo.seekTo(progress);
                    refreshTime();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(seekBar);

        btnPlay = addButton(col, "Putar", v -> togglePlay());
        addButton(col, "Mundur cepat 10 detik", v -> seekBy(-10000));
        addButton(col, "Maju cepat 10 detik", v -> seekBy(10000));
        addButton(col, "Bagikan", v -> share());
        addButton(col, "Ubah nama", v -> askRename());
        addButton(col, "Hapus", v -> askDelete());
        addButton(col, "Tutup", v -> dismiss());

        exo.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (exo == null) return;
                if (state == Player.STATE_READY) {
                    long d = exo.getDuration();
                    if (d > 0) {
                        durationMs = d;
                        seekBar.setMax((int) Math.min(d, Integer.MAX_VALUE));
                    }
                }
                if (state == Player.STATE_ENDED) say("Selesai diputar. Tekan Putar dari awal untuk mengulang.");
                updatePlayLabel();
            }

            @Override
            public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                if (exo == null) return;
                updatePlayLabel();
                if (playWhenReady) say("Memutar.");
                else say("Dijeda di " + spoken(exo.getCurrentPosition()) + ".");
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                say("Gagal memutar: " + error.getMessage());
            }
        });

        exo.setMediaItem(MediaItem.fromUri(it.uri));
        exo.prepare();

        ScrollView sv = new ScrollView(host);
        sv.addView(col);
        dialog = new AlertDialog.Builder(host)
                .setTitle("Hasil ekspor")
                .setView(sv)
                .create();
        dialog.setOnDismissListener(d -> release());
        dialog.show();
        ui.post(tick);
    }

    private Button addButton(LinearLayout col, String text, View.OnClickListener l) {
        Button b = new Button(host);
        b.setText(text);
        b.setOnClickListener(l);
        col.addView(b, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return b;
    }

    private void togglePlay() {
        if (exo == null) return;
        if (exo.getPlaybackState() == Player.STATE_ENDED) {
            exo.seekTo(0);
            exo.play();
            say("Memutar dari awal.");
        } else if (exo.getPlayWhenReady()) {
            exo.pause();
        } else {
            exo.play();
        }
        updatePlayLabel();
    }

    private void seekBy(long deltaMs) {
        if (exo == null) return;
        long pos = exo.getCurrentPosition() + deltaMs;
        long max = durationMs > 0 ? durationMs : Math.max(0, pos);
        if (pos < 0) pos = 0;
        if (pos > max) pos = max;
        exo.seekTo(pos);
        say((deltaMs < 0 ? "Mundur ke " : "Maju ke ") + spoken(pos) + ".");
        refreshTime();
    }

    private void updatePlayLabel() {
        if (exo == null || btnPlay == null) return;
        String t;
        int st = exo.getPlaybackState();
        if (st == Player.STATE_ENDED) t = "Putar dari awal";
        else if (exo.getPlayWhenReady() && st != Player.STATE_IDLE) t = "Jeda";
        else t = exo.getCurrentPosition() > 500 ? "Lanjutkan" : "Putar";
        btnPlay.setText(t);
    }

    private void refreshTime() {
        if (exo == null || timeView == null) return;
        long p = exo.getCurrentPosition();
        if (seekBar != null) seekBar.setProgress((int) Math.min(p, Integer.MAX_VALUE));
        timeView.setText("Posisi " + spoken(p) + (durationMs > 0 ? " dari " + spoken(durationMs) : ""));
    }

    private void say(String s) {
        if (statusView != null) statusView.setText(s);
        else host.notice(s);
    }

    private static String spoken(long ms) {
        if (ms < 60000) return String.format(new Locale("id"), "%.1f detik", ms / 1000.0);
        long total = ms / 1000;
        long m = total / 60, s = total % 60;
        return s == 0 ? m + " menit" : m + " menit " + s + " detik";
    }

    // ---------- bagikan ----------

    private void share() {
        if (item == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(item.audio ? "audio/mp4" : "video/mp4");
            i.putExtra(Intent.EXTRA_STREAM, item.uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            host.startActivity(Intent.createChooser(i, "Bagikan hasil ekspor"));
            say("Memilih aplikasi untuk berbagi.");
        } catch (Exception e) {
            say("Tidak bisa membagikan: " + e.getMessage());
        }
    }

    // ---------- ubah nama ----------

    private void askRename() {
        if (item == null) return;
        final EditText et = new EditText(host);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setContentDescription("Nama baru tanpa akhiran file");
        String base = item.name;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        et.setText(base);
        et.setSelection(base.length());
        new AlertDialog.Builder(host)
                .setTitle("Ubah nama")
                .setView(et)
                .setPositiveButton("Ubah", (d, w) -> rename(et.getText().toString(), false))
                .setNegativeButton("Batal", null)
                .show();
    }

    @SuppressWarnings("deprecation")
    private void rename(final String raw, boolean retried) {
        if (item == null) return;
        final String ext = item.audio ? ".m4a" : ".mp4";
        String clean = raw.replaceAll("[\\\\/:*?\"<>|]", "").trim();
        if (clean.toLowerCase(Locale.ROOT).endsWith(ext)) clean = clean.substring(0, clean.length() - ext.length()).trim();
        if (clean.isEmpty()) { say("Nama kosong, tidak diubah."); return; }
        final String newName = clean + ext;
        if (newName.equals(item.name)) { say("Nama sama, tidak diubah."); return; }

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                int n = host.getContentResolver().update(item.uri, v, null, null);
                if (n > 0) {
                    String real = nameOf(item.uri);
                    item.name = real != null ? real : newName;
                    if (titleView != null) titleView.setText(item.name);
                    say("Nama diubah menjadi " + item.name + ".");
                } else {
                    say("Gagal mengubah nama.");
                }
            } catch (SecurityException e) {
                if (Build.VERSION.SDK_INT >= 30 && !retried) {
                    PendingIntent pi = MediaStore.createWriteRequest(host.getContentResolver(),
                            Collections.singletonList(item.uri));
                    final String again = raw;
                    host.requestGrant(pi.getIntentSender(), () -> rename(again, true));
                } else {
                    say("Tidak diizinkan mengubah nama: " + e.getMessage());
                }
            } catch (Exception e) {
                say("Gagal mengubah nama: " + e.getMessage());
            }
        } else {
            String path = pathOf(item.uri);
            if (path == null) { say("Berkas tidak ditemukan."); return; }
            File old = new File(path);
            File nw = new File(old.getParentFile(), newName);
            if (nw.exists()) { say("Nama itu sudah dipakai."); return; }
            if (!old.renameTo(nw)) { say("Gagal mengubah nama."); return; }
            MediaScannerConnection.scanFile(host, new String[]{old.getAbsolutePath()}, null, null);
            MediaScannerConnection.scanFile(host, new String[]{nw.getAbsolutePath()}, null,
                    (p, u) -> ui.post(() -> {
                        if (u != null) {
                            item.uri = u;
                            if (exo != null) {
                                long pos = exo.getCurrentPosition();
                                boolean pw = exo.getPlayWhenReady();
                                exo.setMediaItem(MediaItem.fromUri(u), pos);
                                exo.setPlayWhenReady(pw);
                                exo.prepare();
                            }
                        }
                        item.name = newName;
                        if (titleView != null) titleView.setText(newName);
                        say("Nama diubah menjadi " + newName + ".");
                    }));
        }
    }

    // ---------- hapus ----------

    private void askDelete() {
        if (item == null) return;
        new AlertDialog.Builder(host)
                .setTitle("Hapus hasil ekspor")
                .setMessage("Hapus " + item.name + "? Berkas yang dihapus tidak bisa dikembalikan.")
                .setPositiveButton("Hapus", (d, w) -> delete(false))
                .setNegativeButton("Batal", null)
                .show();
    }

    @SuppressWarnings("deprecation")
    private void delete(boolean retried) {
        if (item == null) return;
        final Uri uri = item.uri;
        final String name = item.name;
        final Runnable finished = () -> {
            host.forgetSaved(uri);
            dismiss();
            host.notice("Hasil ekspor dihapus: " + name + ".");
        };
        if (exo != null) exo.pause();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                int n = host.getContentResolver().delete(uri, null, null);
                if (n > 0) finished.run();
                else say("Tidak ada berkas yang dihapus.");
            } else {
                String path = pathOf(uri);
                if (path == null) { say("Berkas tidak ditemukan."); return; }
                boolean ok = new File(path).delete();
                MediaScannerConnection.scanFile(host, new String[]{path}, null, null);
                if (ok) finished.run();
                else say("Gagal menghapus berkas.");
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 30 && !retried) {
                PendingIntent pi = MediaStore.createDeleteRequest(host.getContentResolver(),
                        Collections.singletonList(uri));
                host.requestGrant(pi.getIntentSender(), finished);
            } else {
                say("Tidak diizinkan menghapus: " + e.getMessage());
            }
        } catch (Exception e) {
            say("Gagal menghapus: " + e.getMessage());
        }
    }

    // ---------- bersih-bersih ----------

    public void dismiss() {
        if (dialog != null) {
            AlertDialog d = dialog;
            dialog = null;
            try { d.dismiss(); } catch (Exception ignored) { }
        }
        release();
    }

    private void release() {
        ui.removeCallbacks(tick);
        if (exo != null) {
            ExoPlayer p = exo;
            exo = null;
            p.release();
        }
        statusView = null;
        timeView = null;
        titleView = null;
        seekBar = null;
        btnPlay = null;
    }
}
