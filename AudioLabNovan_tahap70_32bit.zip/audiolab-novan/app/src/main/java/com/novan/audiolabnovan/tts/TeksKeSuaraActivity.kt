package com.novan.audiolabnovan.tts

import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.Opts
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.R
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Tahap 51: Teks ke Suara.
 *
 * Mesin suara memakai mesin Text-to-Speech bawaan HP (Google, Samsung, RHVoice, dan lain-lain, sesuai yang terpasang).
 * Pengguna memilih mesin, suara, kecepatan bicara, dan nada, bisa mencoba suaranya, memasang efek, lalu menyimpan
 * hasilnya sebagai MP3 (bawaan), M4A, FLAC, atau WAV.
 *
 * Panjang teks tidak dibatasi: teks dipecah per kalimat jadi bagian-bagian kecil (mesin suara menolak masukan yang
 * terlalu panjang), tiap bagian disintesis ke berkas WAV sementara, lalu semua bagian disambung dan diberi efek oleh FFmpeg.
 */
class TeksKeSuaraActivity : AppCompatActivity() {

    private class PilihanSuara(val label: String, val voice: Voice?, val locale: Locale?)

    private class Efek(val nama: String, val voice: Int = 0, val pitch: Int = 0, val ekstra: List<String> = emptyList())

    private val daftarEfek = listOf(
        Efek("Tanpa efek (suara asli mesin)"),
        Efek("Tupai (nada tinggi)", voice = 1),
        Efek("Raksasa (nada rendah)", voice = 2),
        Efek("Robot", voice = 3),
        Efek("Radio atau telepon", voice = 4),
        Efek("Bergetar", voice = 5),
        Efek("Anak kecil", pitch = 4),
        Efek("Suara berat", pitch = -3),
        Efek("Paduan suara (chorus)", ekstra = listOf("chorus=0.7:0.9:55:0.4:0.25:2"))
    )
    private val daftarRuang = listOf(
        "Tanpa gema", "Ruang kecil", "Aula", "Gema (echo)", "Studio vokal",
        "Karaoke", "Katedral", "Kamar mandi", "Panggung konser"
    )
    private val daftarBass = listOf(0, 3, 6, 9, 12)
    private val daftarVolume = listOf(-6, -3, 0, 3, 6, 9)
    private val daftarKbps = listOf(64, 96, 128, 192, 256, 320)
    private val daftarFormat = OutFmt.values().toList()   // MP3 paling atas, jadi MP3 terpilih bawaan

    private val pref by lazy { getSharedPreferences("tts", MODE_PRIVATE) }

    // ----- Mesin suara -----
    private var tts: TextToSpeech? = null
    private var siap = false
    private var generasi = 0
    private var mesinAktif: String? = null
    private var daftarMesin: List<TextToSpeech.EngineInfo> = emptyList()
    private var daftarSuara: List<PilihanSuara> = emptyList()

    // ----- Penantian sintesis (dipakai thread kerja) -----
    @Volatile private var kunci: CountDownLatch? = null
    @Volatile private var idSintesis: String = ""
    @Volatile private var sintesisOk = false

    // ----- Proses -----
    @Volatile private var batal = false
    @Volatile private var sibuk = false
    @Volatile private var sesi: FFmpegSession? = null
    private var player: MediaPlayer? = null
    private var hasilFile: File? = null
    private var hasilUri: Uri? = null
    private var hasilFmt: OutFmt = OutFmt.MP3
    private var hasilNama: String = ""
    private val dialogHasil by lazy { DialogHasil(this) }

    // ----- Tes suara: satu tombol yang berganti Tes suara, Batalkan contoh, Jeda, Lanjutkan -----
    private enum class Tes { DIAM, MENYIAPKAN, MAIN, JEDA }
    private var tes = Tes.DIAM
    private var tesLangsung = false          // true: mesin suara membacakan langsung; false: contoh berefek diputar dari berkas
    private var tesPotongan: List<String> = emptyList()
    private var tesIndeks = 0
    private var tesSeq = 0
    private var tesGalatBeruntun = 0
    @Volatile private var tesIdAktif = ""
    private var teksBerkas: String? = null   // teks sangat besar dari berkas; tidak dimuat penuh ke kotak ketik

    // ----- Tampilan -----
    private lateinit var etTeks: EditText
    private lateinit var tvHitung: TextView
    private lateinit var spMesin: Spinner
    private lateinit var spSuara: Spinner
    private lateinit var seekKecepatan: SeekBar
    private lateinit var seekNada: SeekBar
    private lateinit var tvKecepatan: TextView
    private lateinit var tvNada: TextView
    private lateinit var btnTes: Button
    private lateinit var btnBerhenti: Button
    private lateinit var spEfek: Spinner
    private lateinit var spRuang: Spinner
    private lateinit var spBass: Spinner
    private lateinit var spVolume: Spinner
    private lateinit var cbRata: CheckBox
    private lateinit var spFormat: Spinner
    private lateinit var spKbps: Spinner
    private lateinit var btnBuat: Button
    private lateinit var btnBuka: Button
    private lateinit var btnHapus: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView
    private lateinit var panelHasil: LinearLayout
    private lateinit var tvHasil: TextView
    private lateinit var btnPutar: Button
    private lateinit var btnBagikan: Button
    private lateinit var btnSimpan: Button
    private var terakhirUmum = -1

    private val bukaBerkas = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) muatBerkasTeks(uri)
    }

    private val simpanSebagai = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val f = hasilFile
        if (r.resultCode == RESULT_OK && uri != null && f != null && f.exists()) {
            thread {
                val err = try { Converter.copyTo(this, f, uri); null } catch (e: Exception) { e.message ?: "galat" }
                runOnUiThread {
                    if (err == null) {
                        hasilUri = uri
                        btnBagikan.isEnabled = true
                        status("Berkas tersimpan.")
                    } else status("Gagal menyimpan: $err")
                }
            }
        } else status("Penyimpanan dibatalkan.")
    }

    private val pendengar = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            if (utteranceId == idSintesis) { sintesisOk = true; kunci?.countDown() }
            if (utteranceId != null && utteranceId == tesIdAktif) runOnUiThread { tesBagianSelesai(utteranceId, true) }
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            if (utteranceId == idSintesis) kunci?.countDown()
            if (utteranceId != null && utteranceId == tesIdAktif) runOnUiThread { tesBagianSelesai(utteranceId, false) }
        }
        override fun onError(utteranceId: String?, errorCode: Int) {
            if (utteranceId == idSintesis) kunci?.countDown()
            if (utteranceId != null && utteranceId == tesIdAktif) runOnUiThread { tesBagianSelesai(utteranceId, false) }
        }
        override fun onStop(utteranceId: String?, interrupted: Boolean) {
            if (utteranceId == idSintesis) kunci?.countDown()
        }
    }

    // =====================================================================================
    //  Tampilan
    // =====================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun LinearLayout.tambah(v: View) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun judul(teks: String, untuk: View? = null): TextView = TextView(this).apply {
        text = teks
        textSize = 16f
        setPadding(0, dp(14), 0, dp(2))
        if (untuk != null) {
            if (untuk.id == View.NO_ID) untuk.id = View.generateViewId()
            labelFor = untuk.id
        }
    }

    private fun subjudul(teks: String): TextView = TextView(this).apply {
        text = teks
        textSize = 20f
        setPadding(0, dp(22), 0, dp(4))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun tombol(teks: String, aksi: () -> Unit): Button = Button(this).apply {
        text = teks
        minHeight = dp(48)
        isAllCaps = false
        setOnClickListener { aksi() }
    }

    private fun spinner(items: List<String>, awal: Int = 0, saatPilih: (Int) -> Unit = {}): Spinner {
        val sp = Spinner(this)
        sp.minimumHeight = dp(48)
        isiSpinner(sp, items, awal)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { saatPilih(position) }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun isiSpinner(sp: Spinner, items: List<String>, pilih: Int) {
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        if (items.isNotEmpty()) sp.setSelection(pilih.coerceIn(0, items.size - 1), false)
    }

    private fun seek(maks: Int, awal: Int, nama: String, format: (Int) -> String, label: TextView, saatUbah: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = maks
        s.progress = awal.coerceIn(0, maks)
        s.minimumHeight = dp(48)
        s.contentDescription = nama
        fun segarkan(p: Int) {
            label.text = "$nama: ${format(p)}"
            ViewCompat.setStateDescription(s, format(p))
        }
        segarkan(s.progress)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { segarkan(p); saatUbah(p) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun kecepatan(p: Int) = 0.5 + p * 0.05    // 0..30 -> 0,5x .. 2,0x
    private fun nada(p: Int) = 0.5 + p * 0.05
    private fun fmtX(v: Double) = String.format(Locale("id", "ID"), "%.2f kali", v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.judul_tts)

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(akar) })

        // ----- Teks -----
        akar.tambah(subjudul("Teks"))
        etTeks = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            hint = "Ketik atau tempel tulisan di sini. Panjang tulisan tidak dibatasi."
            setHorizontallyScrolling(false)
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        akar.tambah(judul("Tulisan yang akan dibacakan", etTeks))
        akar.tambah(etTeks)
        tvHitung = TextView(this).apply { setPadding(0, dp(4), 0, 0) }
        akar.tambah(tvHitung)
        etTeks.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { segarkanHitung() }
        })
        btnBuka = tombol("Buka tulisan dari berkas (.txt)") { bukaBerkas.launch(arrayOf("text/*")) }
        akar.tambah(btnBuka)
        btnHapus = tombol("Hapus semua tulisan") { hapusTeks() }
        akar.tambah(btnHapus)

        // ----- Suara -----
        akar.tambah(subjudul("Suara"))
        spMesin = spinner(listOf("Memuat…")) { pos ->
            val m = daftarMesin.getOrNull(pos)
            if (m != null && m.name != mesinAktif && !sibuk) {
                pref.edit().putString("mesin", m.name).putString("suara", "").apply()
                mulaiMesin(m.name)
            }
        }
        akar.tambah(judul("Mesin suara", spMesin))
        akar.tambah(spMesin)
        spSuara = spinner(listOf("Memuat…")) { pos ->
            val p = daftarSuara.getOrNull(pos)
            if (p != null) terapkanSuara(p, true)
        }
        akar.tambah(judul("Pilihan suara", spSuara))
        akar.tambah(spSuara)

        tvKecepatan = judul("")
        akar.tambah(tvKecepatan)
        seekKecepatan = seek(30, pref.getInt("kecepatan", 10), "Kecepatan bicara", { fmtX(kecepatan(it)) }, tvKecepatan) {
            pref.edit().putInt("kecepatan", it).apply()
        }
        akar.tambah(seekKecepatan)
        tvNada = judul("")
        akar.tambah(tvNada)
        seekNada = seek(30, pref.getInt("nada", 10), "Nada suara", { fmtX(nada(it)) }, tvNada) {
            pref.edit().putInt("nada", it).apply()
        }
        akar.tambah(seekNada)


        // ----- Efek -----
        akar.tambah(subjudul("Efek suara"))
        spEfek = spinner(daftarEfek.map { it.nama }, pref.getInt("efek", 0)) { pref.edit().putInt("efek", it).apply() }
        akar.tambah(judul("Pengubah suara", spEfek))
        akar.tambah(spEfek)
        spRuang = spinner(daftarRuang, pref.getInt("ruang", 0)) { pref.edit().putInt("ruang", it).apply() }
        akar.tambah(judul("Efek ruang dan gema", spRuang))
        akar.tambah(spRuang)
        spBass = spinner(daftarBass.map { if (it == 0) "Mati" else "Plus $it dB" }, pref.getInt("bass", 0)) {
            pref.edit().putInt("bass", it).apply()
        }
        akar.tambah(judul("Penguat bass", spBass))
        akar.tambah(spBass)
        spVolume = spinner(daftarVolume.map { if (it == 0) "Normal" else if (it > 0) "Plus $it dB" else "Minus ${-it} dB" }, pref.getInt("volume", 2)) {
            pref.edit().putInt("volume", it).apply()
        }
        akar.tambah(judul("Volume hasil", spVolume))
        akar.tambah(spVolume)
        cbRata = CheckBox(this).apply {
            text = "Ratakan volume (normalisasi)"
            minHeight = dp(48)
            isChecked = pref.getBoolean("rata", false)
            setOnCheckedChangeListener { _, c -> pref.edit().putBoolean("rata", c).apply() }
        }
        akar.tambah(cbRata)

        // ----- Format -----
        akar.tambah(subjudul("Format audio"))
        spFormat = spinner(daftarFormat.map { it.label }, pref.getInt("format", 0)) {
            pref.edit().putInt("format", it).apply()
            spKbps.isEnabled = daftarFormat[it].lossy && !sibuk
        }
        akar.tambah(judul("Format hasil (bawaan MP3)", spFormat))
        akar.tambah(spFormat)
        spKbps = spinner(daftarKbps.map { "$it kbps" }, pref.getInt("kbps", 2)) { pref.edit().putInt("kbps", it).apply() }
        akar.tambah(judul("Kualitas (bitrate)", spKbps))
        akar.tambah(spKbps)
        spKbps.isEnabled = daftarFormat[spFormat.selectedItemPosition.coerceAtLeast(0)].lossy

        // ----- Buat -----
        akar.tambah(subjudul("Tes dan buat audio"))
        btnTes = tombol("Tes suara") { klikTes() }
        akar.tambah(btnTes)
        btnBerhenti = tombol("Berhenti") { hentikanSemua() }
        akar.tambah(btnBerhenti)
        btnBuat = tombol("Ubah tulisan jadi audio") { buatAudio() }
        akar.tambah(btnBuat)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        akar.tambah(progress)
        tvProgress = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, dp(4), 0, 0)
        }
        akar.tambah(tvProgress)
        tvStatus = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            textSize = 16f
            setPadding(0, dp(8), 0, 0)
        }
        akar.tambah(tvStatus)

        // ----- Hasil -----
        panelHasil = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        panelHasil.tambah(subjudul("Hasil"))
        tvHasil = TextView(this).apply { textSize = 16f }
        panelHasil.tambah(tvHasil)
        btnPutar = tombol("Buka menu hasil: putar, jeda, bagikan, ubah nama, hapus") { bukaMenuHasil() }
        panelHasil.tambah(btnPutar)
        btnBagikan = tombol("Bagikan") { bagikan() }
        panelHasil.tambah(btnBagikan)
        btnSimpan = tombol("Simpan sebagai…") { simpanKeLokasi() }
        panelHasil.tambah(btnSimpan)
        akar.tambah(panelHasil)

        segarkanHitung()
        segarkanTombol()

        // Teks yang dibagikan dari aplikasi lain (menu Bagikan, jenis teks).
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.let { etTeks.setText(it) }
        }

        mulaiMesin(pref.getString("mesin", null)?.takeIf { it.isNotEmpty() })
    }

    // =====================================================================================
    //  Mesin dan suara
    // =====================================================================================

    private fun mulaiMesin(paket: String?) {
        hentikanTes()
        generasi++
        val g = generasi
        siap = false
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        segarkanTombol()
        status("Memuat mesin suara…")
        val pendengarInit = TextToSpeech.OnInitListener { st -> runOnUiThread { if (g == generasi) mesinSiap(st, paket) } }
        tts = try {
            if (paket == null) TextToSpeech(applicationContext, pendengarInit)
            else TextToSpeech(applicationContext, pendengarInit, paket)
        } catch (e: Exception) {
            null
        }
        if (tts == null) status("Mesin suara tidak bisa dimulai di HP ini.")
    }

    private fun mesinSiap(st: Int, paket: String?) {
        val t = tts ?: return
        if (st != TextToSpeech.SUCCESS) {
            try { t.shutdown() } catch (_: Exception) { }
            tts = null
            if (paket != null) {
                status("Mesin suara pilihan tidak bisa dimulai. Memakai mesin bawaan HP.")
                pref.edit().remove("mesin").remove("suara").apply()
                mulaiMesin(null)
            } else {
                status("Mesin suara bawaan HP tidak bisa dimulai. Pastikan ada mesin Text-to-Speech terpasang dan aktif di pengaturan HP (Pengaturan, Bahasa, Keluaran text-to-speech).")
            }
            return
        }
        t.setOnUtteranceProgressListener(pendengar)
        mesinAktif = paket ?: try { t.defaultEngine } catch (_: Exception) { null }
        siap = true

        // Daftar mesin yang terpasang.
        daftarMesin = try { t.engines.toList() } catch (_: Exception) { emptyList() }
        if (daftarMesin.isNotEmpty()) {
            val label = daftarMesin.map { it.label?.toString().orEmpty().ifBlank { it.name } }
            isiSpinner(spMesin, label, daftarMesin.indexOfFirst { it.name == mesinAktif }.coerceAtLeast(0))
        } else {
            isiSpinner(spMesin, listOf("Mesin bawaan HP"), 0)
        }

        // Daftar suara milik mesin ini.
        val suara = try { t.voices?.toList().orEmpty() } catch (_: Exception) { emptyList() }
        val dipakai = suara
            .filter { it.features?.contains("notInstalled") != true }
            .sortedWith(compareBy({ it.locale.displayName }, { it.name }))
        daftarSuara = if (dipakai.isNotEmpty()) {
            dipakai.map {
                val net = if (it.isNetworkConnectionRequired) ", perlu internet" else ""
                PilihanSuara("${it.locale.displayName}, ${it.name}$net", it, it.locale)
            }
        } else {
            // Mesin yang tidak melaporkan daftar suara: tawarkan bahasa umum yang tersedia.
            listOf(
                Locale("id", "ID"), Locale.US, Locale.UK, Locale("ms", "MY"), Locale("jv", "ID"), Locale("su", "ID"),
                Locale.FRANCE, Locale.GERMANY, Locale.JAPAN, Locale.KOREA, Locale.CHINA, Locale("ar"), Locale("es", "ES"),
                Locale("pt", "BR"), Locale("hi", "IN"), Locale("ru", "RU"), Locale("nl", "NL"), Locale("it", "IT")
            ).filter {
                try { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE } catch (_: Exception) { false }
            }.map { PilihanSuara(it.displayName, null, it) }
        }
        if (daftarSuara.isEmpty()) {
            isiSpinner(spSuara, listOf("Tidak ada suara tersedia"), 0)
            status("Mesin ini belum punya data suara. Buka pengaturan text-to-speech HP untuk mengunduh suara, atau pilih mesin lain.")
            segarkanTombol()
            return
        }
        val tersimpan = pref.getString("suara", "").orEmpty()
        var awal = daftarSuara.indexOfFirst { it.voice?.name == tersimpan && tersimpan.isNotEmpty() }
        if (awal < 0) {
            val bawaan = try { t.defaultVoice?.name } catch (_: Exception) { null }
            awal = daftarSuara.indexOfFirst { it.voice?.name == bawaan }
        }
        if (awal < 0) awal = daftarSuara.indexOfFirst { it.locale?.language == "in" || it.locale?.language == "id" }
        if (awal < 0) awal = 0
        isiSpinner(spSuara, daftarSuara.map { it.label }, awal)
        terapkanSuara(daftarSuara[awal], false)
        status("Mesin suara siap. ${daftarSuara.size} suara tersedia. Tulis teks, lalu tekan Tes suara atau Ubah tulisan jadi audio.")
        segarkanTombol()
    }

    private fun terapkanSuara(p: PilihanSuara, simpan: Boolean) {
        val t = tts ?: return
        try {
            if (p.voice != null) t.setVoice(p.voice) else if (p.locale != null) t.setLanguage(p.locale)
        } catch (_: Exception) { }
        if (simpan && p.voice != null) pref.edit().putString("suara", p.voice.name).apply()
    }

    private fun terapkanParam(t: TextToSpeech) {
        t.setSpeechRate(kecepatan(seekKecepatan.progress).toFloat())
        t.setPitch(nada(seekNada.progress).toFloat())
        val p = daftarSuara.getOrNull(spSuara.selectedItemPosition)
        if (p != null) terapkanSuara(p, false)
    }

    // =====================================================================================
    //  Teks
    // =====================================================================================

    private fun ambilTeks(): String = teksBerkas ?: etTeks.text.toString()

    private fun segarkanHitung() {
        val n = teksBerkas?.length ?: etTeks.text.length
        val bagian = (n + 899) / 900
        tvHitung.text = if (n == 0) "Belum ada tulisan." else "%,d karakter, kira-kira %,d bagian proses.".format(Locale("id", "ID"), n, bagian)
    }

    private fun hapusTeks() {
        teksBerkas = null
        etTeks.isEnabled = true
        etTeks.setText("")
        segarkanHitung()
        status("Tulisan dikosongkan.")
    }

    private fun muatBerkasTeks(uri: Uri) {
        status("Membaca berkas teks…")
        thread {
            val isi = try {
                contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (isi.isNullOrBlank()) {
                    status("Berkas kosong atau tidak bisa dibaca sebagai teks.")
                } else if (isi.length > 200_000) {
                    // Terlalu besar untuk kotak ketik: simpan utuh di memori, tampilkan awalnya saja.
                    teksBerkas = isi
                    etTeks.isEnabled = false
                    etTeks.setText(isi.take(2000) + "\n…\n(Tulisan besar dari berkas, hanya awalnya yang ditampilkan. Seluruhnya tetap dibacakan.)")
                    status("Berkas dimuat: %,d karakter. Tekan Hapus semua tulisan bila ingin mengetik sendiri.".format(Locale("id", "ID"), isi.length))
                } else {
                    teksBerkas = null
                    etTeks.isEnabled = true
                    etTeks.setText(isi)
                    status("Berkas dimuat: %,d karakter.".format(Locale("id", "ID"), isi.length))
                }
                segarkanHitung()
            }
        }
    }

    /** Pecah teks per kalimat (atau baris, koma, spasi bila kalimat terlalu panjang) menjadi bagian sepanjang paling [maks] karakter. */
    private fun pecahTeks(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        val n = teks.length
        var i = 0
        while (i < n) {
            while (i < n && teks[i].isWhitespace()) i++
            if (i >= n) break
            var akhir = minOf(i + maks, n)
            if (akhir < n) {
                akhir = cariBatas(teks, i, akhir)
            }
            val potong = teks.substring(i, akhir).trim()
            if (potong.any { it.isLetterOrDigit() }) hasil += potong
            i = akhir
        }
        return hasil
    }

    private fun cariBatas(teks: String, dari: Int, ke: Int): Int {
        val n = teks.length
        val batasBawah = dari + (ke - dari) / 3
        // 1) akhir kalimat atau baris
        for (k in ke - 1 downTo batasBawah) {
            val c = teks[k]
            val akhirKalimat = c == '!' || c == '?' || c == '\n' || c == '…' || c == '。' || c == '！' || c == '？' ||
                (c == '.' && (k + 1 >= n || teks[k + 1].isWhitespace()))
            if (akhirKalimat) return k + 1
        }
        // 2) koma, titik koma, titik dua
        for (k in ke - 1 downTo batasBawah) {
            val c = teks[k]
            if (c == ',' || c == ';' || c == ':' || c == '，' || c == '、') return k + 1
        }
        // 3) spasi
        for (k in ke - 1 downTo batasBawah) {
            if (teks[k].isWhitespace()) return k + 1
        }
        // 4) terpaksa potong di sini (jangan membelah pasangan pengganti)
        return if (ke > dari + 1 && Character.isHighSurrogate(teks[ke - 1])) ke - 1 else ke
    }

    // =====================================================================================
    //  Tes suara
    // =====================================================================================

    private fun efekAktif(): Boolean {
        val e = daftarEfek[spEfek.selectedItemPosition.coerceIn(0, daftarEfek.size - 1)]
        return e.voice != 0 || e.pitch != 0 || e.ekstra.isNotEmpty() || spRuang.selectedItemPosition != 0 ||
            spBass.selectedItemPosition != 0 || daftarVolume[spVolume.selectedItemPosition.coerceAtLeast(0)] != 0 || cbRata.isChecked
    }

    /** Satu tombol: Tes suara, lalu Jeda, lalu Lanjutkan. Saat contoh berefek disiapkan, tombolnya jadi Batalkan contoh. */
    private fun klikTes() {
        when (tes) {
            Tes.DIAM -> mulaiTes()
            Tes.MENYIAPKAN -> hentikanSemua()
            Tes.MAIN -> jedaTes()
            Tes.JEDA -> lanjutTes()
        }
    }

    private fun mulaiTes() {
        val t = tts
        if (t == null || !siap) { status("Mesin suara belum siap."); return }
        dialogHasil.hentikanSuara()
        hentikanPutar()
        terapkanParam(t)
        val semua = ambilTeks()
        if (!efekAktif()) {
            // Tanpa efek: mesin suara membacakan langsung dari awal tulisan, kalimat demi kalimat, jadi bisa dijeda kapan saja.
            val bagian = pecahTeks(semua, 220)
            tesPotongan = if (bagian.isEmpty()) listOf("Halo, ini contoh suara saya. Bagaimana menurut Anda?") else bagian
            tesIndeks = 0
            tesGalatBeruntun = 0
            tesLangsung = true
            tes = Tes.MAIN
            segarkanTombol()
            status("Memutar tes suara dari awal tulisan, ${tesPotongan.size} bagian. Tombol Tes suara sekarang jadi Jeda.")
            bicaraiBagian()
        } else {
            // Dengan efek: suara disintesis dulu, diberi efek, lalu diputar, supaya yang terdengar sama dengan hasil akhir.
            // Hanya bagian awal tulisan yang dicoba, supaya cepat.
            val contoh = pecahTeks(semua, 250).take(2).joinToString(" ")
                .ifBlank { "Halo, ini contoh suara saya. Bagaimana menurut Anda?" }
            tesLangsung = false
            jalankan(contoh, true)
        }
    }

    private fun bicaraiBagian() {
        val t = tts ?: return
        if (tesIndeks >= tesPotongan.size) { tesBerakhir("Tes suara selesai."); return }
        val id = "tes" + (++tesSeq)
        tesIdAktif = id
        val r = try { t.speak(tesPotongan[tesIndeks], TextToSpeech.QUEUE_FLUSH, null, id) } catch (e: Exception) { TextToSpeech.ERROR }
        if (r != TextToSpeech.SUCCESS) {
            tesIdAktif = ""
            tesBerakhir("Mesin suara menolak memutar contoh ini.")
        }
    }

    /** Dipanggil di thread utama saat satu bagian selesai dibacakan ([ok] false bila mesin melaporkan galat). */
    private fun tesBagianSelesai(id: String, ok: Boolean) {
        if (id != tesIdAktif || tes != Tes.MAIN || !tesLangsung) return
        if (ok) tesGalatBeruntun = 0 else tesGalatBeruntun++
        if (tesGalatBeruntun >= 3) {
            tesIdAktif = ""
            tesBerakhir("Mesin suara berkali-kali gagal membacakan tulisan ini. Coba pilih suara atau mesin lain.")
            return
        }
        tesIndeks++
        bicaraiBagian()
    }

    private fun tesBerakhir(pesan: String) {
        tesIdAktif = ""
        tes = Tes.DIAM
        segarkanTombol()
        status(pesan)
    }

    private fun jedaTes() {
        if (tes != Tes.MAIN) return
        tes = Tes.JEDA
        if (tesLangsung) {
            tesIdAktif = ""      // callback susulan dari bagian yang dipotong diabaikan
            try { tts?.stop() } catch (_: Exception) { }
            status("Dijeda pada bagian ${tesIndeks + 1} dari ${tesPotongan.size}. Tekan Lanjutkan, kalimat itu diulang dari awalnya.")
        } else {
            try { player?.pause() } catch (_: Exception) { }
            status("Contoh dijeda. Tekan Lanjutkan untuk meneruskan.")
        }
        segarkanTombol()
    }

    private fun lanjutTes() {
        if (tes != Tes.JEDA) return
        tes = Tes.MAIN
        if (tesLangsung) {
            val t = tts
            if (t != null) terapkanParam(t)
            status("Dilanjutkan dari bagian ${tesIndeks + 1} dari ${tesPotongan.size}.")
            segarkanTombol()
            bicaraiBagian()
        } else {
            try { player?.start() } catch (_: Exception) { }
            status("Contoh dilanjutkan.")
            segarkanTombol()
        }
    }

    /** Hentikan total tes suara (bicara langsung maupun contoh berefek) dan kembalikan tombol ke Tes suara. */
    private fun hentikanTes() {
        tesIdAktif = ""
        if (tesLangsung && tes != Tes.DIAM) { try { tts?.stop() } catch (_: Exception) { } }
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        if (tes != Tes.MENYIAPKAN) tes = Tes.DIAM
        if (::btnTes.isInitialized) segarkanTombol()
    }

    // =====================================================================================
    //  Buat audio
    // =====================================================================================

    private fun buatAudio() {
        val t = tts
        if (t == null || !siap) { status("Mesin suara belum siap."); return }
        if (ambilTeks().none { it.isLetterOrDigit() }) { status("Tulis dulu teks yang mau diubah jadi suara."); return }
        hentikanTes()
        dialogHasil.hentikanSuara()
        terapkanParam(t)
        jalankan(ambilTeks(), false)
    }

    private fun buatOpts(teks: String, pratinjau: Boolean): Opts {
        val e = daftarEfek[spEfek.selectedItemPosition.coerceIn(0, daftarEfek.size - 1)]
        val judulBerkas = teks.trim().lineSequence().firstOrNull().orEmpty().take(60)
        return Opts(
            normalize = cbRata.isChecked,
            gainDb = daftarVolume[spVolume.selectedItemPosition.coerceIn(0, daftarVolume.size - 1)],
            pitchSemi = e.pitch,
            bassDb = daftarBass[spBass.selectedItemPosition.coerceIn(0, daftarBass.size - 1)],
            echoMode = spRuang.selectedItemPosition.coerceIn(0, daftarRuang.size - 1),
            voice = e.voice,
            sampleRate = 44100,
            channels = 1,
            title = if (pratinjau) "" else judulBerkas,
            artist = if (pratinjau) "" else "AudioLab novan",
            album = if (pratinjau) "" else "Teks ke Suara"
        )
    }

    /** Sintesis satu bagian ke berkas WAV. Mengembalikan true bila berkas jadi. Dipanggil dari thread kerja. */
    private fun sintesis(t: TextToSpeech, teks: String, keluar: File, id: String): Boolean {
        val k = CountDownLatch(1)
        keluar.delete()
        idSintesis = id
        sintesisOk = false
        kunci = k
        val r = try { t.synthesizeToFile(teks, Bundle(), keluar, id) } catch (e: Exception) { TextToSpeech.ERROR }
        if (r != TextToSpeech.SUCCESS) return false
        val batasMs = (30_000L + teks.length * 100L)
        val mulai = System.currentTimeMillis()
        while (!k.await(250, TimeUnit.MILLISECONDS)) {
            if (batal) return false
            if (System.currentTimeMillis() - mulai > batasMs) {
                try { t.stop() } catch (_: Exception) { }
                return false
            }
        }
        return sintesisOk && keluar.length() > 44
    }

    /** Lama WAV (ms) dari kepala berkas; 0 bila tidak terbaca. */
    private fun lamaWav(f: File): Long {
        return try {
            f.inputStream().use { s ->
                val h = ByteArray(44)
                if (s.read(h) < 44) return 0L
                val br = (h[28].toInt() and 255) or ((h[29].toInt() and 255) shl 8) or
                    ((h[30].toInt() and 255) shl 16) or ((h[31].toInt() and 255) shl 24)
                if (br <= 0) 0L else (f.length() - 44) * 1000L / br
            }
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Inti proses. [pratinjau] = true: hanya contoh pendek, hasil WAV sementara langsung diputar.
     * Tahap 1 (0 sampai 60 persen): mesin suara membuat WAV tiap bagian. Tahap 2 (60 sampai 100 persen): FFmpeg menyambung,
     * memberi efek, dan menyandi ke format pilihan.
     */
    private fun jalankan(teks: String, pratinjau: Boolean) {
        val t = tts ?: return
        val batasMesin = try { TextToSpeech.getMaxSpeechInputLength() } catch (_: Throwable) { 4000 }
        val maks = minOf(batasMesin - 50, 1200).coerceAtLeast(200)
        val potongan = pecahTeks(teks, maks)
        if (potongan.isEmpty()) { status("Tulis dulu teks yang mau diubah jadi suara."); return }

        val fmt = if (pratinjau) OutFmt.WAV else daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val kbps = daftarKbps[spKbps.selectedItemPosition.coerceIn(0, daftarKbps.size - 1)]
        val opts = buatOpts(teks, pratinjau)
        val e = daftarEfek[spEfek.selectedItemPosition.coerceIn(0, daftarEfek.size - 1)]
        val saringan = ArrayList<String>()
        saringan += Converter.pitchFilters(opts)
        saringan += Converter.voiceFilters(opts)
        saringan += e.ekstra
        saringan += Converter.tailFilters(opts, 0.0)

        hapusHasil()
        batal = false
        if (pratinjau) tes = Tes.MENYIAPKAN
        setSibuk(true)
        progres(0, if (pratinjau) "Menyiapkan contoh suara" else "Menyiapkan")
        status(if (pratinjau) "Membuat contoh suara dengan efek…" else "Mengubah tulisan jadi suara. Biarkan layar menyala sampai selesai.")

        val dir = File(cacheDir, "tts_" + System.currentTimeMillis()).also { it.mkdirs() }
        thread {
            val bagian = ArrayList<File>()
            var dilewati = 0
            for ((i, c) in potongan.withIndex()) {
                if (batal) break
                val f = File(dir, String.format(Locale.US, "bagian_%05d.wav", i))
                if (sintesis(t, c, f, "u$i")) bagian += f else if (!batal) dilewati++
                val p = (i + 1) * 60 / potongan.size
                runOnUiThread { progres(p, "Membuat suara, bagian ${i + 1} dari ${potongan.size}") }
            }
            if (batal) {
                dir.deleteRecursively()
                runOnUiThread { selesaiGagal("Dibatalkan.") }
                return@thread
            }
            if (bagian.isEmpty()) {
                dir.deleteRecursively()
                runOnUiThread {
                    selesaiGagal("Mesin suara gagal membuat suara dari tulisan ini. Coba pilih suara atau mesin lain, atau periksa data suara di pengaturan text-to-speech HP.")
                }
                return@thread
            }
            val totalMs = bagian.sumOf { lamaWav(it) }
            val daftar = File(dir, "daftar.txt")
            daftar.writeText(bagian.joinToString("\n") { "file '" + it.absolutePath.replace("'", "'\\''") + "'" } + "\n")
            val dest = File(cacheDir, "tts_hasil_" + System.currentTimeMillis() + "." + fmt.ext)

            val args = ArrayList<String>()
            args += listOf("-y", "-nostdin", "-f", "concat", "-safe", "0", "-i", daftar.absolutePath, "-vn")
            if (saringan.isNotEmpty()) args += listOf("-af", saringan.joinToString(","))
            args += opts.audioFormatArgs()
            args += fmt.codecArgs(kbps)
            if (!pratinjau) args += opts.metadataArgs()
            args += dest.absolutePath

            runOnUiThread { progres(60, "Menerapkan efek dan menyandi ke ${fmt.label}") }
            sesi = FFmpegKit.executeWithArgumentsAsync(
                args.toTypedArray(),
                { s ->
                    dir.deleteRecursively()
                    when {
                        ReturnCode.isCancel(s.returnCode) -> {
                            dest.delete()
                            runOnUiThread { selesaiGagal("Dibatalkan.") }
                        }
                        ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> {
                            if (pratinjau) {
                                runOnUiThread { selesaiPratinjau(dest) }
                            } else {
                                simpanDanTampilkan(dest, fmt, dilewati)
                            }
                        }
                        else -> {
                            dest.delete()
                            val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                            runOnUiThread { selesaiGagal("FFmpeg gagal (kode ${s.returnCode}): $log") }
                        }
                    }
                },
                null,
                { st ->
                    if (totalMs > 0) {
                        val p = 60 + (st.time.toLong() * 40L / totalMs).toInt().coerceIn(0, 39)
                        runOnUiThread { progres(p, "Menerapkan efek dan menyandi ke ${fmt.label}") }
                    }
                }
            )
        }
    }

    private fun selesaiGagal(pesan: String) {
        if (tes == Tes.MENYIAPKAN) tes = Tes.DIAM
        setSibuk(false)
        progres(0, "")
        status(pesan)
    }

    private fun selesaiPratinjau(f: File) {
        tes = Tes.DIAM
        setSibuk(false)
        progres(100, "Contoh siap")
        hasilFile = f
        hasilUri = null
        mainkan(f)
        if (tes == Tes.MAIN) status("Memutar contoh suara dengan efek, dari bagian awal tulisan. Tombol Tes suara sekarang jadi Jeda.")
    }

    private fun simpanDanTampilkan(f: File, fmt: OutFmt, dilewati: Int) {
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val nama = "TeksKeSuara_$stempel.${fmt.ext}"
        var uri: Uri? = null
        var galat: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { uri = simpanOtomatis(f, nama, fmt) } catch (e: Exception) { galat = e.message ?: "galat" }
        }
        val u = uri
        val g = galat
        runOnUiThread {
            hasilFile = f
            hasilUri = u
            hasilFmt = fmt
            setSibuk(false)
            progres(100, "Selesai")
            panelHasil.visibility = View.VISIBLE
            val catatan = if (dilewati > 0) " $dilewati bagian teks dilewati karena mesin suara menolaknya." else ""
            val lama = Converter.durasiTeks(lamaFile(f) / 1000.0)
            tvHasil.text = when {
                u != null -> "Selesai, lama $lama. Tersimpan di folder Musik, AudioLab Novan, Teks ke Suara, dengan nama $nama.$catatan"
                g != null -> "Selesai, lama $lama, tetapi tidak bisa disimpan otomatis ($g). Tekan Simpan sebagai.$catatan"
                else -> "Selesai, lama $lama. Tekan Simpan sebagai untuk memilih lokasi simpan.$catatan"
            }
            status(tvHasil.text.toString())
            btnBagikan.isEnabled = u != null
            hasilNama = if (u != null) nama else f.name
            segarkanTombol()
            bukaMenuHasil()
        }
    }

    /** Dialog menu hasil: putar, jeda, lanjutkan, bagikan, ubah nama, hapus. Muncul otomatis saat selesai. */
    private fun bukaMenuHasil() {
        val f = hasilFile
        val u = hasilUri ?: f?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        if (u == null) { status("Belum ada hasil."); return }
        dialogHasil.tombolStatusWa = true
        dialogHasil.saatDiubah = { h ->
            if (h.uri.scheme == "file") hasilFile = File(h.uri.path ?: "") else hasilUri = h.uri
            hasilNama = h.nama
            tvHasil.text = "Nama berkas sekarang ${h.nama}."
        }
        dialogHasil.saatDihapus = {
            hasilUri = null
            hasilFile?.delete()
            hasilFile = null
            panelHasil.visibility = View.GONE
            status("Hasil sudah dihapus.")
        }
        dialogHasil.tampilkan(u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }, hasilFmt.mime)
    }

    private fun lamaFile(f: File): Long = try {
        val d = com.arthenica.ffmpegkit.FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation?.duration
        ((d?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
    } catch (_: Throwable) { 0L }

    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanOtomatis(src: File, nama: String, fmt: OutFmt): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, nama)
            put(MediaStore.Audio.Media.MIME_TYPE, fmt.mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioLab Novan/Teks ke Suara")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val koleksi = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            val selesai = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            contentResolver.update(u, selesai, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    // =====================================================================================
    //  Hasil: putar, bagikan, simpan
    // =====================================================================================

    private fun hapusHasil() {
        dialogHasil.hentikanSuara()
        hentikanTes()
        hasilFile?.delete()
        hasilFile = null
        hasilUri = null
        panelHasil.visibility = View.GONE
    }

    private fun mainkan(f: File) {
        hentikanPutar()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                hentikanPutar()
                status("Contoh selesai.")
            }
            mp.prepare()
            mp.start()
            player = mp
            tes = Tes.MAIN
        } catch (e: Exception) {
            status("Tidak bisa memutar: ${e.message}")
        }
        segarkanTombol()
    }

    private fun hentikanPutar() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        if (!tesLangsung && (tes == Tes.MAIN || tes == Tes.JEDA)) tes = Tes.DIAM
        if (::btnPutar.isInitialized) segarkanTombol()
    }

    private fun bagikan() {
        val u = hasilUri
        if (u == null) { status("Simpan dulu hasilnya dengan tombol Simpan sebagai."); return }
        try {
            val kirim = Intent(Intent.ACTION_SEND).apply {
                type = hasilFmt.mime
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(kirim, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            status("Menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    private fun simpanKeLokasi() {
        val f = hasilFile
        if (f == null || !f.exists()) { status("Belum ada hasil untuk disimpan."); return }
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = hasilFmt.mime
            putExtra(Intent.EXTRA_TITLE, "TeksKeSuara_$stempel.${hasilFmt.ext}")
        }
        simpanSebagai.launch(i)
    }

    // =====================================================================================
    //  Status, progres, tombol
    // =====================================================================================

    private fun status(t: String) { tvStatus.text = t }

    private fun progres(p: Int, teks: String) {
        progress.progress = p
        tvProgress.text = if (teks.isEmpty()) "" else "$teks, $p persen."
        // Umumkan ke pembaca layar tiap kelipatan 10 persen saja, agar tidak berisik.
        val kelompok = p / 10
        if (kelompok == terakhirUmum) tvProgress.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_NONE
        else tvProgress.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        terakhirUmum = kelompok
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        if (s) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        segarkanTombol()
    }

    private fun segarkanTombol() {
        if (!::btnBuat.isInitialized) return
        val bisa = siap && !sibuk
        btnBuat.isEnabled = bisa
        btnTes.isEnabled = siap && (!sibuk || tes == Tes.MENYIAPKAN)
        btnTes.text = when (tes) {
            Tes.DIAM -> "Tes suara"
            Tes.MENYIAPKAN -> "Batalkan contoh"
            Tes.MAIN -> "Jeda"
            Tes.JEDA -> "Lanjutkan"
        }
        btnBerhenti.isEnabled = sibuk || tes != Tes.DIAM || player != null
        spMesin.isEnabled = !sibuk
        spSuara.isEnabled = siap && !sibuk
        spEfek.isEnabled = !sibuk
        spRuang.isEnabled = !sibuk
        spBass.isEnabled = !sibuk
        spVolume.isEnabled = !sibuk
        cbRata.isEnabled = !sibuk
        spFormat.isEnabled = !sibuk
        spKbps.isEnabled = !sibuk && daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)].lossy
        btnBuka.isEnabled = !sibuk
        btnHapus.isEnabled = !sibuk
        etTeks.isEnabled = !sibuk && teksBerkas == null
        btnSimpan.isEnabled = !sibuk
    }

    private fun hentikanSemua() {
        if (sibuk) {
            batal = true
            try { tts?.stop() } catch (_: Exception) { }
            try { sesi?.cancel() } catch (_: Exception) { }
            status("Membatalkan…")
        }
        val adaTes = tes != Tes.DIAM || player != null
        hentikanTes()
        if (adaTes && !sibuk) status("Tes suara dihentikan.")
        segarkanTombol()
    }

    override fun onStop() {
        super.onStop()
        // Suara contoh jangan berlanjut saat layar ditinggalkan; proses pembuatan audio dibiarkan jalan.
        if (!sibuk) {
            hentikanTes()
            dialogHasil.hentikanSuara()
        }
    }

    override fun onDestroy() {
        batal = true
        try { sesi?.cancel() } catch (_: Exception) { }
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        siap = false
        dialogHasil.lepas()
        hentikanPutar()
        // Berkas sementara hasil yang belum disimpan ke Musik boleh dihapus; yang sudah di Musik tidak terpengaruh.
        if (!isChangingConfigurations) {
            hasilFile?.delete()
            cacheDir.listFiles { f -> f.name.startsWith("tts_") }?.forEach { it.deleteRecursively() }
        }
        super.onDestroy()
    }
}
