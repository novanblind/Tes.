package com.makroku.automation.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.provider.Telephony
import android.telephony.TelephonyManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.makroku.automation.MakroApp
import com.makroku.automation.engine.ContactLookup
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.IntentTrigger
import com.makroku.automation.model.TriggerEvent
import com.makroku.automation.ui.MainActivity
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Layanan latar depan yang mendaftarkan penerima broadcast sistem untuk semua pemicu. */
class AutomationService : Service() {
    private val scope = MainScope()
    private var systemReceiver: BroadcastReceiver? = null
    private var customReceiver: BroadcastReceiver? = null
    private var monitors: ExtraMonitors? = null
    private var lastMacros: List<com.makroku.automation.model.Macro> = emptyList()
    private var playbackCb: android.media.AudioManager.AudioPlaybackCallback? = null
    @Volatile private var lastMusic: Boolean? = null
    @Volatile private var lastNight: Boolean? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun isNight(c: android.content.res.Configuration) =
        (c.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** Tema gelap sistem berubah: kirim kejadian bila nilainya benar-benar berbeda. */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val malam = isNight(newConfig)
        val sebelum = lastNight
        lastNight = malam
        if (sebelum != null && sebelum != malam) {
            (application as MakroApp).engine.dispatch(TriggerEvent("dark_theme", mapOf("on" to malam.toString())))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = Notification.Builder(this, MakroApp.CHANNEL_SERVICE)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("MakroKu aktif")
            .setContentText("Memantau pemicu makro")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        val type = if (android.os.Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)

        lastNight = isNight(resources.configuration)
        val app = application as MakroApp
        registerSystem(app.engine)
        registerPlayback(app.engine)
        monitors = ExtraMonitors(this, app.engine)
        scope.launch {
            app.repo.macros.collect { lastMacros = it; monitors?.update(it) }
        }
        scope.launch {
            app.repo.macros
                .map { list ->
                    list.filter { it.enabled }.flatMap { it.triggers }
                        .filterIsInstance<IntentTrigger>().map { it.action }.filter { it.isNotBlank() }.toSet()
                }
                .distinctUntilChanged()
                .collect { registerCustom(app.engine, it) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // dipanggil ulang setelah izin baru diberikan → daftar ulang agar SMS/telepon aktif
        registerSystem((application as MakroApp).engine)
        monitors?.update(lastMacros)
        return START_STICKY
    }

    private fun registerSystem(engine: MacroEngine) {
        systemReceiver?.let { runCatching { unregisterReceiver(it) } }
        val r = SystemEventReceiver(engine)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
            addAction(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(android.media.AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(android.os.PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_SHUTDOWN)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction("android.hardware.usb.action.USB_STATE")
            addAction(android.app.NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(android.location.LocationManager.MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_DREAMING_STARTED)
            addAction(Intent.ACTION_DREAMING_STOPPED)
            addAction(android.os.PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED)
            addAction(Intent.ACTION_LOCALE_CHANGED)
            addAction(Intent.ACTION_DOCK_EVENT)
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction(android.nfc.NfcAdapter.ACTION_ADAPTER_STATE_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
            addAction(android.app.AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
        }
        ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_EXPORTED)
        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, r, pf, ContextCompat.RECEIVER_EXPORTED)
        systemReceiver = r
    }

    /** Memantau musik mulai atau berhenti diputar (untuk pemicu Musik diputar). */
    private fun registerPlayback(engine: MacroEngine) {
        if (playbackCb != null) return
        val am = getSystemService(android.media.AudioManager::class.java)
        lastMusic = am.isMusicActive
        val cb = object : android.media.AudioManager.AudioPlaybackCallback() {
            override fun onPlaybackConfigChanged(configs: MutableList<android.media.AudioPlaybackConfiguration>?) {
                val on = am.isMusicActive
                val prev = lastMusic
                lastMusic = on
                if (prev != null && prev != on) engine.dispatch(TriggerEvent("music", mapOf("playing" to on.toString())))
            }
        }
        am.registerAudioPlaybackCallback(cb, android.os.Handler(android.os.Looper.getMainLooper()))
        playbackCb = cb
    }

    private fun registerCustom(engine: MacroEngine, actions: Set<String>) {
        customReceiver?.let { runCatching { unregisterReceiver(it) } }
        customReceiver = null
        if (actions.isEmpty()) return
        val r = SystemEventReceiver(engine)
        val f = IntentFilter().apply { actions.forEach { addAction(it) } }
        ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_EXPORTED)
        customReceiver = r
    }

    override fun onDestroy() {
        playbackCb?.let { cb -> runCatching { getSystemService(android.media.AudioManager::class.java).unregisterAudioPlaybackCallback(cb) } }
        playbackCb = null
        systemReceiver?.let { runCatching { unregisterReceiver(it) } }
        customReceiver?.let { runCatching { unregisterReceiver(it) } }
        monitors?.stop()
        scope.cancel()
        super.onDestroy()
    }
}

/** Mengubah broadcast sistem menjadi [TriggerEvent]. */
class SystemEventReceiver(private val engine: MacroEngine) : BroadcastReceiver() {
    private var lastPlug = -1
    private var lastFull = false

    override fun onReceive(context: Context, i: Intent) {
        fun fire(kind: String, vararg kv: Pair<String, String>) = engine.dispatch(TriggerEvent(kind, mapOf(*kv)))
        when (i.action) {
            Intent.ACTION_BATTERY_CHANGED -> {
                val level = i.getIntExtra("level", -1)
                val scale = i.getIntExtra("scale", 100)
                if (level >= 0 && scale > 0) fire("battery", "level" to (level * 100 / scale).toString())
                val tenths = i.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                if (tenths != Int.MIN_VALUE) fire("battery_temp", "temp" to (tenths / 10).toString())
                val penuh = i.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) == android.os.BatteryManager.BATTERY_STATUS_FULL
                if (penuh && !lastFull) fire("battery_full")
                lastFull = penuh
                val plug = i.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)
                if (plug != lastPlug) {
                    if (lastPlug == 0 && plug != 0) {
                        val nama = when {
                            plug and android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "wireless"
                            plug and android.os.BatteryManager.BATTERY_PLUGGED_USB != 0 -> "usb"
                            plug and android.os.BatteryManager.BATTERY_PLUGGED_AC != 0 -> "ac"
                            else -> "lain"
                        }
                        fire("charger_type", "plug" to nama)
                    }
                    lastPlug = plug
                }
            }
            Intent.ACTION_SHUTDOWN -> fire("shutdown")
            Intent.ACTION_TIMEZONE_CHANGED -> fire("timezone_changed")
            Intent.ACTION_TIME_CHANGED -> fire("time_changed")
            Intent.ACTION_POWER_CONNECTED -> fire("power", "connected" to "true")
            Intent.ACTION_POWER_DISCONNECTED -> fire("power", "connected" to "false")
            Intent.ACTION_SCREEN_ON, Intent.ACTION_SCREEN_OFF -> {
                fire("screen", "on" to (i.action == Intent.ACTION_SCREEN_ON).toString())
                // tombol daya: tiap tekan = satu kejadian layar; beruntun bila jeda paling lama 3 detik
                val now = android.os.SystemClock.elapsedRealtime()
                tapCount = if (now - lastScreenEvt <= 3000L) tapCount + 1 else 1
                lastScreenEvt = now
                if (tapCount >= 2) fire("power_taps", "count" to tapCount.toString())
            }
            WifiManager.WIFI_STATE_CHANGED_ACTION -> when (i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)) {
                WifiManager.WIFI_STATE_ENABLED -> fire("wifi", "enabled" to "true")
                WifiManager.WIFI_STATE_DISABLED -> fire("wifi", "enabled" to "false")
            }
            BluetoothAdapter.ACTION_STATE_CHANGED -> when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_ON -> fire("bluetooth", "enabled" to "true")
                BluetoothAdapter.STATE_OFF -> fire("bluetooth", "enabled" to "false")
            }
            Intent.ACTION_AIRPLANE_MODE_CHANGED -> fire("airplane", "on" to i.getBooleanExtra("state", false).toString())
            Intent.ACTION_HEADSET_PLUG -> fire("headphone", "plugged" to (i.getIntExtra("state", 0) == 1).toString())
            TelephonyManager.ACTION_PHONE_STATE_CHANGED -> {
                val st = i.getStringExtra(TelephonyManager.EXTRA_STATE)
                @Suppress("DEPRECATION")
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
                if (st == TelephonyManager.EXTRA_STATE_RINGING) {
                    lastCallNumber = num
                    fire("call", "call_number" to num, "call_name" to ContactLookup.name(context, num))
                } else if (st == TelephonyManager.EXTRA_STATE_IDLE && lastCallState != null &&
                    lastCallState != TelephonyManager.EXTRA_STATE_IDLE
                ) {
                    if (lastCallState == TelephonyManager.EXTRA_STATE_RINGING) {
                        fire("missed_call", "call_number" to lastCallNumber, "call_name" to ContactLookup.name(context, lastCallNumber))
                    }
                    fire("call_end", "call_number" to lastCallNumber, "call_name" to ContactLookup.name(context, lastCallNumber))
                } else if (st == TelephonyManager.EXTRA_STATE_OFFHOOK && lastCallState != TelephonyManager.EXTRA_STATE_OFFHOOK) {
                    if (lastCallState == null || lastCallState == TelephonyManager.EXTRA_STATE_IDLE) fire("call_out")
                    if (lastCallState != TelephonyManager.EXTRA_STATE_RINGING) lastCallNumber = ""
                    fire("call_active", "call_number" to lastCallNumber, "call_name" to ContactLookup.name(context, lastCallNumber))
                }
                lastCallState = st
            }
            Intent.ACTION_USER_PRESENT -> fire("unlock")
            Intent.ACTION_PACKAGE_ADDED ->
                if (!i.getBooleanExtra(Intent.EXTRA_REPLACING, false))
                    fire("package", "installed" to "true", "app_pkg" to (i.data?.schemeSpecificPart ?: ""))
                else
                    fire("package_updated", "app_pkg" to (i.data?.schemeSpecificPart ?: ""))
            Intent.ACTION_PACKAGE_REMOVED ->
                if (!i.getBooleanExtra(Intent.EXTRA_REPLACING, false))
                    fire("package", "installed" to "false", "app_pkg" to (i.data?.schemeSpecificPart ?: ""))
            android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED ->
                fire("bt_device", "connected" to "true", "bt_name" to btName(i))
            android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED ->
                fire("bt_device", "connected" to "false", "bt_name" to btName(i))
            Telephony.Sms.Intents.SMS_RECEIVED_ACTION -> {
                val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
                if (!msgs.isNullOrEmpty()) {
                    fire(
                        "sms",
                        "sms_sender" to (msgs[0].originatingAddress ?: ""),
                        "sms_body" to msgs.joinToString("") { it.messageBody ?: "" },
                    )
                }
            }
            android.media.AudioManager.RINGER_MODE_CHANGED_ACTION -> fire(
                "ringer",
                "mode" to when (i.getIntExtra(android.media.AudioManager.EXTRA_RINGER_MODE, -1)) {
                    android.media.AudioManager.RINGER_MODE_SILENT -> "silent"
                    android.media.AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
                    else -> "normal"
                },
            )
            android.os.PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> fire(
                "power_save",
                "on" to context.getSystemService(android.os.PowerManager::class.java).isPowerSaveMode.toString(),
            )
            android.app.NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> fire(
                "dnd",
                "on" to (context.getSystemService(android.app.NotificationManager::class.java).currentInterruptionFilter !=
                    android.app.NotificationManager.INTERRUPTION_FILTER_ALL).toString(),
            )
            Intent.ACTION_DATE_CHANGED -> fire("date_changed")
            "android.hardware.usb.action.USB_STATE" -> {
                val on = i.getBooleanExtra("connected", false)
                val prev = lastUsb
                lastUsb = on
                // siaran ini "lengket": abaikan nilai pertama, picu hanya saat berubah
                if (prev != null && prev != on) fire("usb", "connected" to on.toString())
            }
            android.location.LocationManager.MODE_CHANGED_ACTION -> fire(
                "gps",
                "on" to context.getSystemService(android.location.LocationManager::class.java).isLocationEnabled.toString(),
            )
            Intent.ACTION_DREAMING_STARTED -> fire("daydream", "on" to "true")
            Intent.ACTION_DREAMING_STOPPED -> fire("daydream", "on" to "false")
            android.os.PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED -> fire(
                "doze",
                "on" to context.getSystemService(android.os.PowerManager::class.java).isDeviceIdleMode.toString(),
            )
            Intent.ACTION_LOCALE_CHANGED -> fire("locale_changed")
            Intent.ACTION_DOCK_EVENT -> {
                val on = i.getIntExtra(Intent.EXTRA_DOCK_STATE, Intent.EXTRA_DOCK_STATE_UNDOCKED) != Intent.EXTRA_DOCK_STATE_UNDOCKED
                val prev = lastDock
                lastDock = on
                // siaran ini lengket: abaikan nilai pertama, picu hanya saat berubah
                if (prev != null && prev != on) fire("dock", "docked" to on.toString())
            }
            "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
                val st = i.getIntExtra("wifi_state", -1)
                if (st == 13) fire("hotspot", "on" to "true") else if (st == 11) fire("hotspot", "on" to "false")
            }
            android.nfc.NfcAdapter.ACTION_ADAPTER_STATE_CHANGED -> {
                when (i.getIntExtra(android.nfc.NfcAdapter.EXTRA_ADAPTER_STATE, -1)) {
                    android.nfc.NfcAdapter.STATE_ON -> fire("nfc_state", "on" to "true")
                    android.nfc.NfcAdapter.STATE_OFF -> fire("nfc_state", "on" to "false")
                }
            }
            "android.media.VOLUME_CHANGED_ACTION" -> {
                val aliran = when (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)) {
                    android.media.AudioManager.STREAM_MUSIC -> "music"
                    android.media.AudioManager.STREAM_RING -> "ring"
                    android.media.AudioManager.STREAM_ALARM -> "alarm"
                    android.media.AudioManager.STREAM_NOTIFICATION -> "notification"
                    android.media.AudioManager.STREAM_SYSTEM -> "system"
                    android.media.AudioManager.STREAM_VOICE_CALL -> "voice"
                    else -> ""
                }
                if (aliran.isNotEmpty()) {
                    fire("volume_changed", "stream" to aliran, "volume" to i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1).toString())
                }
            }
            android.app.AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED -> fire(
                "next_alarm",
                "next_alarm" to (context.getSystemService(android.app.AlarmManager::class.java).nextAlarmClock?.triggerTime ?: 0L).toString(),
            )
            null -> {}
            else -> fire("intent", "action" to i.action!!)
        }
    }

    private companion object {
        @Volatile var lastCallState: String? = null
        @Volatile var lastCallNumber: String = ""
        @Volatile var lastUsb: Boolean? = null
        @Volatile var lastDock: Boolean? = null
        @Volatile var lastScreenEvt: Long = 0L
        @Volatile var tapCount: Int = 0
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun btName(i: Intent): String = try {
        val dev = if (android.os.Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(android.bluetooth.BluetoothDevice.EXTRA_DEVICE, android.bluetooth.BluetoothDevice::class.java)
        else i.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE)
        dev?.name.orEmpty()
    } catch (e: SecurityException) {
        ""
    }
}
