package id.ytplayer

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.exceptions.SignInConfirmNotBotException
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

/**
 * Layanan unduhan (foreground, berantrean satu per satu).
 * Hasil disimpan ke Music/YTPlayer (audio) atau Movies/YTPlayer (video).
 */
class DownloadService : Service() {

    companion object {
        private const val CHANNEL = "downloads"
        private const val FG_ID = 1500 // jangan 1001: itu ID notifikasi media Media3, bentrok dengan notifikasi putar/jeda
        private const val ACTION_CANCEL = "id.ytplayer.CANCEL_DOWNLOAD"
        private const val X_URL = "url"
        private const val X_TITLE = "title"
        private const val X_KEY = "key"
        private const val CHUNK = 4L * 1024 * 1024
        private const val X_PLAYLIST = "playlist"
        private const val MAX_PLAYLIST = 1000
        private const val INFO_TRIES = 4          // percobaan mengambil info video/daftar playlist
        private const val RETRY_ROUNDS = 2        // putaran ulang untuk video playlist yang gagal
        private const val RESUME_WINDOW_MS = 6L * 60 * 60 * 1000

        /** Batalkan unduhan yang sedang berjalan (sama dengan tombol Batal di notifikasi). */
        fun cancelCurrent(ctx: Context) {
            ctx.startService(Intent(ctx, DownloadService::class.java).setAction(ACTION_CANCEL))
        }

        fun start(ctx: Context, url: String, title: String, key: String) {
            val i = Intent(ctx, DownloadService::class.java)
                .putExtra(X_URL, url)
                .putExtra(X_TITLE, title)
                .putExtra(X_KEY, key)
            ContextCompat.startForegroundService(ctx, i)
        }

        /** Unduh seluruh isi playlist YouTube, satu video demi satu, dengan kunci format yang sama. */
        fun startPlaylist(ctx: Context, playlistUrl: String, playlistTitle: String, key: String) {
            val i = Intent(ctx, DownloadService::class.java)
                .putExtra(X_URL, playlistUrl)
                .putExtra(X_TITLE, playlistTitle)
                .putExtra(X_KEY, key)
                .putExtra(X_PLAYLIST, true)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    /** Keadaan satu unduhan playlist yang sedang berjalan (notifikasi ringkas, hitungan hasil). */
    private class Batch(val name: String, val total: Int) {
        @Volatile var index = 0
        @Volatile var round = 0
        var ok = 0
        var skipped = 0
        val failures = ArrayList<String>()
    }

    /** Satu video dalam antrean playlist. */
    private class Todo(val v: StreamInfoItem, val prefix: String, val n: Int)

    private class Cancelled : IOException("Unduhan dibatalkan")

    /** Kegagalan tetap (video privat/dihapus, tidak ada aliran, ruang penuh): mengulang tidak membantu. */
    private class Permanent(message: String) : IOException(message)
    private class Expired(code: Int) : IOException("Tautan unduhan kedaluwarsa (HTTP $code)")

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager

    private var active = 0 // hanya diakses dari thread utama
    private var doneId = 2000
    @Volatile private var cancel = false
    @Volatile private var lastPct = -10
    @Volatile private var cancelAll = false
    @Volatile private var playlistActive = false
    @Volatile private var batch: Batch? = null
    @Volatile private var subDir = ""
    @Volatile private var curId = 0L // id catatan DownloadLog untuk pekerjaan yang sedang jalan

    // Hasil unduhan satu video saat berjalan di dalam playlist (dibaca oleh runPlaylist).
    @Volatile private var jobOk = false
    @Volatile private var jobErr: String? = null
    @Volatile private var jobRetry = true

    // Pengaturan laju: bila YouTube membatasi permintaan, semua permintaan berikutnya menunggu.
    @Volatile private var coolUntil = 0L
    @Volatile private var throttleHits = 0
    @Volatile private var throttled = false
    @Volatile private var gapMs = 700L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Unduhan", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    /**
     * Android 15+: layanan latar depan jenis sinkronisasi data dibatasi sekitar 6 jam per 24 jam.
     * Saat batas habis layanan wajib berhenti segera (bila tidak, aplikasi ditutup paksa).
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        cancel = true
        cancelAll = true
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancel = true
            if (playlistActive) cancelAll = true
            return START_NOT_STICKY
        }
        val url = intent?.getStringExtra(X_URL).orEmpty()
        val title = intent?.getStringExtra(X_TITLE).orEmpty()
        val key = intent?.getStringExtra(X_KEY).orEmpty()

        // Wajib segera menjadi foreground setelah startForegroundService().
        ServiceCompat.startForeground(
            this, FG_ID, progressNotif("Menyiapkan unduhan…", title, 0, true),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )

        if (url.isEmpty() || key.isEmpty()) {
            if (active == 0) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        active++
        val isPlaylist = intent?.getBooleanExtra(X_PLAYLIST, false) == true
        toast(
            if (isPlaylist) "Mulai mengunduh playlist: ${title.ifEmpty { "playlist" }}"
            else "Mulai mengunduh: ${title.ifEmpty { "video" }}"
        )
        val logId = DownloadLog.enqueue(applicationContext, url, title, key, isPlaylist)
        worker.execute {
            curId = logId
            DownloadLog.running(logId)
            try {
                if (isPlaylist) runPlaylist(url, title, key) else runJob(url, title, key)
            } finally {
                DownloadLog.settle(logId)
                main.post {
                    active--
                    if (active <= 0) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ playlist

    /**
     * Unduh semua video dalam playlist, berurutan. Berkas diberi nomor urut ("01 - Judul") dan
     * disimpan di subfolder bernama playlist (Music/YTPlayer/<playlist> atau Movies/YTPlayer/<playlist>).
     *
     * Pengaman: daftar playlist diambil dengan coba ulang (halaman lanjutan yang gagal tidak
     * membatalkan video yang sudah terkumpul); jeda antar video menyesuaikan diri bila YouTube
     * membatasi permintaan; menunggu internet bila putus; video yang gagal diulang sampai
     * [RETRY_ROUNDS] putaran lagi sesudah yang lain selesai (kecuali yang memang tidak bisa:
     * privat/dihapus); dan video yang sudah berhasil dicatat sehingga menjalankan playlist yang
     * sama lagi (dalam 6 jam) hanya mengulang yang belum selesai.
     */
    private fun runPlaylist(plUrl: String, fallbackName: String, key: String) {
        cancelAll = false
        cancel = false
        playlistActive = true
        throttled = false
        throttleHits = 0
        coolUntil = 0L
        gapMs = 700L
        val plWl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytplayer:playlist")
        try {
            plWl.setReferenceCounted(false)
            plWl.acquire(6L * 60 * 60 * 1000)
        } catch (_: Exception) {
        }
        try {
            update("Mengambil daftar playlist…", fallbackName, 0, true)
            val items = ArrayList<StreamInfoItem>()
            val seen = HashSet<String>()
            var skippedLive = 0
            fun add(list: List<StreamInfoItem>?) {
                for (v in list.orEmpty()) {
                    val live = v.streamType == StreamType.LIVE_STREAM ||
                        v.streamType == StreamType.AUDIO_LIVE_STREAM
                    if (live) { skippedLive++; continue }
                    val u = v.url
                    if (u.isNullOrEmpty() || !seen.add(u)) continue
                    items += v
                }
            }
            val info = retryNet(fallbackName) { PlaylistInfo.getInfo(ServiceList.YouTube, plUrl) }
            val name = (info.name ?: fallbackName).ifBlank { "Playlist" }
            add(info.relatedItems)
            var next: Page? = info.nextPage
            var truncated = false
            var partial = false
            while (Page.isValid(next)) {
                if (cancelAll) break
                if (items.size >= MAX_PLAYLIST) { truncated = true; break }
                update("Mengambil daftar playlist… (${items.size} video)", name, 0, true)
                val page = try {
                    retryNet(name) { PlaylistInfo.getMoreItems(ServiceList.YouTube, plUrl, next) }
                } catch (e: Cancelled) {
                    throw e
                } catch (e: Exception) {
                    // Halaman lanjutan gagal terus: pakai video yang sudah terkumpul, jangan gagal total.
                    partial = true
                    break
                }
                add(page.items)
                next = page.nextPage
            }
            if (cancelAll) {
                DownloadLog.finish(curId, DownloadLog.CANCELLED, "Dibatalkan.")
                toast("Unduhan playlist dibatalkan")
                return
            }
            val list = if (items.size > MAX_PLAYLIST) items.subList(0, MAX_PLAYLIST) else items
            if (list.isEmpty()) {
                throw IOException("Playlist kosong atau tidak bisa dibuka (mungkin privat).")
            }

            val b = Batch(name, list.size)
            batch = b
            subDir = safeName(name)
            val width = maxOf(2, list.size.toString().length)
            val stateKey = "$plUrl|$key"
            val doneSet = loadDone(stateKey)
            var pending: List<Todo> = list.mapIndexed { i, v ->
                Todo(v, String.format(java.util.Locale.US, "%0${width}d - ", i + 1), i + 1)
            }
            var round = 0
            try {
                while (pending.isNotEmpty() && !cancelAll) {
                    if (round > 0) {
                        b.round = round
                        update("Mengulang ${pending.size} video yang gagal…", name, 0, true)
                        pause(20_000L * round)
                    }
                    val again = ArrayList<Todo>()
                    for (t in pending) {
                        if (cancelAll) break
                        b.index = t.n
                        val u = t.v.url.orEmpty()
                        if (round == 0 && u in doneSet) {
                            b.skipped++
                            b.ok++
                            continue
                        }
                        runJob(u, t.v.name.orEmpty(), key, t.prefix)
                        if (cancelAll) break
                        if (jobOk) {
                            b.ok++
                            doneSet.add(u)
                            saveDone(stateKey, doneSet)
                        } else if (jobRetry && round < RETRY_ROUNDS) {
                            again += t
                        } else {
                            b.failures += (jobErr ?: "${t.v.name.orEmpty().ifEmpty { "Video" }}: gagal")
                        }
                        // Jeda antar video: melebar bila YouTube membatasi, menyempit lagi bila lancar.
                        if (throttled) {
                            gapMs = minOf(gapMs * 2, 8000L)
                            throttled = false
                        } else if (jobOk) {
                            gapMs = maxOf(700L, gapMs * 3 / 4)
                        }
                        pause(gapMs)
                    }
                    pending = again
                    round++
                }
            } catch (e: Cancelled) {
                cancelAll = true
            }
            // Catatan "sudah selesai" hanya disimpan bila masih ada yang gagal (supaya bisa dilanjutkan).
            if (cancelAll || b.failures.isEmpty()) clearDone(stateKey)
            summary(b, cancelAll, truncated, skippedLive, partial)
        } catch (e: Cancelled) {
            batch = null
            DownloadLog.finish(curId, DownloadLog.CANCELLED, "Dibatalkan.")
            toast("Unduhan playlist dibatalkan")
        } catch (e: IOException) {
            batch = null
            val net = e is java.net.UnknownHostException || e is java.net.SocketException ||
                e is java.net.SocketTimeoutException || e is javax.net.ssl.SSLException
            fail(fallbackName, if (net) Repo.friendly(e) else (e.message ?: Repo.friendly(e)))
        } catch (e: Exception) {
            batch = null
            fail(fallbackName, Repo.friendly(e))
        } finally {
            batch = null
            subDir = ""
            playlistActive = false
            cancelAll = false
            throttled = false
            throttleHits = 0
            coolUntil = 0L
            try { if (plWl.isHeld) plWl.release() } catch (_: Exception) {}
        }
    }

    // ------------------------------------------------------------------ pengaman jaringan

    private fun online(): Boolean {
        return try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            val c = if (n != null) cm.getNetworkCapabilities(n) else null
            c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true // tidak bisa memeriksa: anggap tersambung
        }
    }

    /** Menunggu sampai ada internet (maks. [maxMs]). True bila sudah tersambung. */
    private fun waitOnline(title: String, maxMs: Long = 10L * 60 * 1000): Boolean {
        if (online()) return true
        var waited = 0L
        while (waited < maxMs) {
            update("Menunggu koneksi internet…", title, 0, true)
            pause(3000)
            waited += 3000
            if (online()) return true
        }
        return false
    }

    /** Tidur yang bisa dibatalkan kapan saja (tombol Batal / layanan dihentikan). */
    private fun pause(ms: Long) {
        var left = ms
        while (left > 0) {
            if (cancel || cancelAll) throw Cancelled()
            val s = minOf(500L, left)
            try {
                Thread.sleep(s)
            } catch (e: InterruptedException) {
                cancel = true
                cancelAll = true
                throw Cancelled()
            }
            left -= s
        }
    }

    private fun isPermanent(e: Throwable): Boolean {
        // Verifikasi bot dan pembatasan YouTube hanya sementara; selebihnya "konten tidak tersedia" tetap.
        if (e is SignInConfirmNotBotException || e is ReCaptchaException) return false
        return e is ContentNotAvailableException || e is Permanent
    }

    private fun isThrottle(e: Throwable): Boolean =
        e is SignInConfirmNotBotException || e is ReCaptchaException ||
            (e.message?.contains("429") == true)

    /** YouTube membatasi: semua permintaan menunggu 15 → 30 → 60 → 120 detik (makin sering makin lama). */
    private fun noteThrottle() {
        throttled = true
        throttleHits = minOf(throttleHits + 1, 4)
        val until = System.currentTimeMillis() + 15_000L * (1L shl (throttleHits - 1))
        if (until > coolUntil) coolUntil = until
    }

    private fun waitCool(title: String) {
        val left = coolUntil - System.currentTimeMillis()
        if (left > 0) {
            update("YouTube membatasi permintaan, menunggu ${left / 1000 + 1} detik…", title, 0, true)
            pause(left)
        }
    }

    /**
     * Menjalankan permintaan ke YouTube dengan coba ulang: menunggu internet bila putus, menunggu
     * masa tenang bila dibatasi, jeda bertahap untuk galat sementara lainnya. Galat tetap
     * (video privat/dihapus) langsung dilempar.
     */
    private fun <T> retryNet(title: String, tries: Int = INFO_TRIES, block: () -> T): T {
        var last: Exception? = null
        for (i in 1..tries) {
            if (cancel || cancelAll) throw Cancelled()
            waitCool(title)
            try {
                if (!online()) waitOnline(title)
                val r = block()
                throttleHits = 0
                return r
            } catch (e: Cancelled) {
                throw e
            } catch (e: Exception) {
                if (isPermanent(e)) throw e
                last = e
                if (isThrottle(e)) noteThrottle()
                else if (i < tries) pause(1500L * i)
            }
        }
        throw last ?: IOException("Gagal mengambil data dari YouTube.")
    }

    /** Info video YouTube (dari simpanan bila ada, kecuali [fresh]) dengan coba ulang. */
    private fun loadInfo(url: String, title: String, fresh: Boolean = false): StreamInfo {
        if (!fresh) StreamCache.get(url)?.let { return it }
        StreamCache.remove(url)
        update("Mengambil info video…", title, 0, true)
        return retryNet(title) {
            StreamInfo.getInfo(ServiceList.YouTube, url).also { StreamCache.put(url, it) }
        }
    }

    // ------------------------------------------------------------------ catatan playlist (lanjutkan)

    private fun prefs() = getSharedPreferences("dlstate", MODE_PRIVATE)

    private fun loadDone(key: String): MutableSet<String> {
        return try {
            val p = prefs()
            val t = p.getLong("t:$key", 0L)
            if (System.currentTimeMillis() - t > RESUME_WINDOW_MS) {
                clearDone(key)
                HashSet<String>()
            } else {
                HashSet(p.getStringSet("s:$key", emptySet()) ?: emptySet())
            }
        } catch (e: Exception) {
            HashSet<String>()
        }
    }

    private fun saveDone(key: String, set: Set<String>) {
        try {
            prefs().edit().putStringSet("s:$key", HashSet(set)).putLong("t:$key", System.currentTimeMillis()).apply()
        } catch (_: Exception) {
        }
    }

    private fun clearDone(key: String) {
        try {
            prefs().edit().remove("s:$key").remove("t:$key").apply()
        } catch (_: Exception) {
        }
    }

    private fun summary(b: Batch, cancelled: Boolean, truncated: Boolean, skippedLive: Int, partial: Boolean = false) {
        val failed = b.failures.size
        val head = if (cancelled) "Unduhan playlist dibatalkan" else "Unduhan playlist selesai"
        val text = "${b.name}: ${b.ok} berhasil, $failed gagal dari ${b.total} video"
        val sb = StringBuilder(text)
        if (truncated) sb.append("\nHanya $MAX_PLAYLIST video pertama yang diunduh.")
        if (partial) sb.append("\nDaftar playlist terputus di tengah; sisa video belum terdaftar. Jalankan lagi untuk melanjutkan.")
        if (b.skipped > 0) sb.append("\n${b.skipped} video dilewati karena sudah diunduh sebelumnya.")
        if (skippedLive > 0) sb.append("\n$skippedLive siaran langsung dilewati.")
        if (failed > 0) {
            sb.append("\n\nYang gagal:")
            b.failures.take(15).forEach { sb.append("\n- ").append(it) }
            if (failed > 15) sb.append("\n(dan ${failed - 15} lainnya)")
            sb.append("\n\nUnduh playlist yang sama lagi (dalam 6 jam) untuk mengulang yang gagal; yang sudah berhasil dilewati.")
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(head)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString()))
            .setContentIntent(openDownloadsPi())
            .setAutoCancel(true)
            .build()
        nm.notify(doneId++, n)
        val logStatus = when {
            cancelled -> DownloadLog.CANCELLED
            failed > 0 || partial -> DownloadLog.FAILED
            else -> DownloadLog.DONE
        }
        val logText = StringBuilder(text)
        if (partial) logText.append(". Daftar playlist terputus di tengah.")
        if (failed > 0) logText.append(". Ketuk untuk mengulang yang gagal (yang sudah berhasil dilewati).")
        DownloadLog.finish(curId, logStatus, logText.toString(), title = b.name)
        toast("$head. $text")
    }

    // ------------------------------------------------------------------ pekerjaan

    private fun runJob(url: String, fallbackTitle: String, key: String, prefix: String = "") {
        cancel = cancelAll
        jobOk = false
        jobErr = null
        jobRetry = true
        val temps = ArrayList<File>()
        var title = fallbackTitle
        // Jaga CPU tetap aktif (layar mati) selama unduh + konversi supaya tidak terhenti di tengah.
        val wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytplayer:download")
        try {
            wl.setReferenceCounted(false)
            wl.acquire(60 * 60 * 1000L)
        } catch (_: Exception) {
        }
        try {
            // Alur: tautan TikTok → runTikTokJob; tautan YouTube → info video → M4A / MP3 / MP4.
            if (key.startsWith(TikTokResolver.PREFIX)) {
                runTikTokJob(url, title, key, temps)
                return
            }
            // Tautan Facebook memakai alur yang sama dengan TikTok (kunci "fb:..." diubah menjadi "tt:...").
            if (key.startsWith(FacebookResolver.PREFIX)) {
                runTikTokJob(url, title, TikTokResolver.PREFIX + key.removePrefix(FacebookResolver.PREFIX), temps)
                return
            }
            val info = loadInfo(url, title)
            title = info.name ?: fallbackTitle
            if (info.streamType == StreamType.LIVE_STREAM || info.streamType == StreamType.AUDIO_LIVE_STREAM) {
                throw Permanent("Siaran langsung tidak bisa diunduh.")
            }
            val base = prefix + safeName(title)
            val dir = externalCacheDir ?: cacheDir

            if (key.startsWith(DownloadOptions.MP3_PREFIX)) {
                val kbps = key.removePrefix(DownloadOptions.MP3_PREFIX).toIntOrNull() ?: 192
                runMp3(url, info, title, base, dir, kbps, temps)
            } else if (key == DownloadOptions.KEY_AUDIO || key.startsWith(DownloadOptions.M4A_PREFIX)) {
                runM4a(url, info, key, title, base, dir, temps)
            } else {
                runVideo(url, info, key, title, base, dir, temps)
            }
        } catch (e: Cancelled) {
            if (batch == null) {
                DownloadLog.finish(curId, DownloadLog.CANCELLED, "Dibatalkan.")
                toast("Unduhan dibatalkan")
            }
        } catch (e: LinkageError) {
            fail(title, "Pustaka MP3 tidak bisa dimuat di HP ini. Pakai audio M4A.", retry = false)
        } catch (e: IOException) {
            // Pesan IOException buatan sendiri (mis. "Tidak ada aliran audio") jangan disamarkan
            // sebagai masalah internet; hanya galat jaringan sungguhan yang diterjemahkan.
            val net = e is java.net.UnknownHostException || e is java.net.SocketException ||
                e is java.net.SocketTimeoutException || e is javax.net.ssl.SSLException
            fail(title, if (net) Repo.friendly(e) else (e.message ?: Repo.friendly(e)), retry = !isPermanent(e))
        } catch (e: Exception) {
            fail(title, "${Repo.friendly(e)} (${e.javaClass.simpleName})", retry = !isPermanent(e))
        } finally {
            try { if (wl.isHeld) wl.release() } catch (_: Exception) {}
            temps.forEach { it.delete() }
        }
    }

    /**
     * Unduh audio M4A asli YouTube: unduhan per potongan dengan coba ulang dan pembaruan tautan,
     * hingga 3 kali percobaan penuh (info video diambil ulang), dan berkas dicek sebelum disimpan.
     */
    private fun runM4a(
        url: String, first: StreamInfo, key: String, title: String, base: String, dir: File,
        temps: MutableList<File>
    ) {
        var info = first
        var lastErr: Exception? = null
        for (attempt in 1..3) {
            if (cancel) throw Cancelled()
            if (attempt > 1) {
                update("Mencoba lagi ($attempt dari 3)…", title, 0, true)
                pause(2000)
                info = try { loadInfo(url, title, true) } catch (e: Cancelled) { throw e } catch (e: Exception) { info }
            }
            val a = DownloadOptions.audioFor(info, key)
                ?: throw Permanent("Tidak ada aliran audio untuk video ini.")
            val ext = a.format?.suffix ?: "m4a"
            val tmp = File(dir, "dl_${System.nanoTime()}.$ext").also { temps += it }
            try {
                fetch(a.content, tmp, title, "Mengunduh audio", 0, 100, emptyMap()) { refreshAudioUrl(url, a) }
                checkAudio(tmp, ext)
                val mime = audioMime(ext)
                val tag = if (key.startsWith(DownloadOptions.M4A_PREFIX) && a.averageBitrate > 0) " (${a.averageBitrate}kbps)" else ""
                val uri = publish(tmp, base + tag, ext, mime, true, tagTitle(title, info.uploaderName), tagArtist(title, info.uploaderName))
                done(title, "Audio tersimpan di Music/YTPlayer", uri, mime)
                return
            } catch (e: Cancelled) {
                throw e
            } catch (e: Permanent) {
                throw e
            } catch (e: IOException) {
                lastErr = e
            }
            try { tmp.delete() } catch (_: Exception) {}
        }
        throw lastErr ?: IOException("Unduhan audio gagal.")
    }

    /** Pastikan berkas audio hasil unduhan benar-benar M4A/WebM (bukan halaman galat atau berkas rusak). */
    private fun checkAudio(f: File, ext: String) {
        if (f.length() < 1024) throw IOException("Berkas audio yang diterima terlalu kecil.")
        val h = ByteArray(12)
        val n = f.inputStream().use { it.read(h) }
        if (n < 8) throw IOException("Berkas audio yang diterima rusak.")
        val ok = when (ext) {
            "webm" -> h[0] == 0x1A.toByte() && h[1] == 0x45.toByte() && h[2] == 0xDF.toByte() && h[3] == 0xA3.toByte()
            "m4a", "mp4" -> String(h, 4, 4, Charsets.ISO_8859_1) in
                listOf("ftyp", "moov", "mdat", "free", "wide", "skip", "styp", "sidx")
            else -> true
        }
        if (!ok) throw IOException("Berkas audio yang diterima rusak atau bukan audio.")
    }

    /** Ambil tautan audio baru (tautan YouTube kedaluwarsa) untuk format yang sama dengan [old]. */
    private fun refreshAudioUrl(url: String, old: AudioStream): String {
        val info = loadInfo(url, "", true)
        val cands = DownloadOptions.mp3Candidates(info)
        val same = cands.firstOrNull { it.format == old.format && it.averageBitrate == old.averageBitrate }
        // Wajib aliran yang sama: menukar format di tengah unduhan akan merusak berkas.
        return (same ?: throw IOException("Tautan audio tidak bisa diperbarui.")).content
    }

    /**
     * Unduh MP3 dengan beberapa lapis pengaman: unduhan per potongan dengan coba ulang dan
     * pembaruan tautan, hingga 3 kali percobaan penuh (info video diambil ulang). Konversi hanya lewat FFmpeg;
     * bila tetap gagal, unduhan dinyatakan gagal (tidak ada cadangan).
     */
    private fun runMp3(
        url: String, first: StreamInfo, title: String, base: String, dir: File, kbps: Int,
        temps: MutableList<File>
    ) {
        var info = first
        var lastErr: Exception? = null
        for (attempt in 1..3) {
            if (cancel) throw Cancelled()
            if (attempt > 1) {
                update("Mencoba lagi ($attempt dari 3)…", title, 0, true)
                pause(2000)
                info = try { loadInfo(url, title, true) } catch (e: Cancelled) { throw e } catch (e: Exception) { info }
            }
            val cands = DownloadOptions.mp3Candidates(info)
            if (cands.isEmpty()) throw Permanent("Tidak ada aliran audio untuk video ini.")
            val a = cands[0]
            val ext = a.format?.suffix ?: "m4a"
            val stamp = System.nanoTime()
            val src = File(dir, "dl_$stamp.$ext").also { temps += it }
            val mp3 = File(dir, "dl_$stamp.mp3").also { temps += it }
            try {
                fetch(a.content, src, title, "Mengunduh audio", 0, 50, emptyMap()) { refreshAudioUrl(url, a) }
                checkAudio(src, ext)
                toMp3(src, mp3, kbps, title, 50, 100)
                val uri = publish(mp3, "$base (${kbps}kbps)", "mp3", "audio/mpeg", true, tagTitle(title, info.uploaderName), tagArtist(title, info.uploaderName))
                done(title, "MP3 tersimpan di Music/YTPlayer", uri, "audio/mpeg")
                return
            } catch (e: Cancelled) {
                throw e
            } catch (e: Mp3UnavailableException) {
                // Pustaka MP3 tidak ada di HP ini: mengulang tidak akan membantu.
                lastErr = e
                break
            } catch (e: LinkageError) {
                lastErr = Mp3UnavailableException("Pustaka MP3 gagal dimuat: ${e.message}")
                break
            } catch (e: IOException) {
                lastErr = e
            } catch (e: RuntimeException) {
                lastErr = IOException("Konversi gagal: ${e.message ?: e.javaClass.simpleName}", e)
            }
            try { mp3.delete() } catch (_: Exception) {}
        }

        throw lastErr ?: IOException("Unduhan MP3 gagal.")
    }

    /** Tautan baru untuk video yang sama dan kualitas yang sama (tautan lama kedaluwarsa). */
    private fun refreshPlan(url: String, key: String, old: DownloadOptions.VideoPlan, audioIdx: Int = 0): DownloadOptions.VideoPlan {
        val info = loadInfo(url, "", true)
        val p = DownloadOptions.planFor(info, key, audioIdx)
            ?: throw IOException("Tautan video tidak bisa diperbarui.")
        // Wajib aliran yang sama; menukar aliran di tengah unduhan merusak berkas.
        if (p.height != old.height || (old.sizeBytes > 0 && p.sizeBytes > 0 && p.sizeBytes != old.sizeBytes)) {
            throw IOException("Tautan video tidak bisa diperbarui.")
        }
        return p
    }

    /**
     * Unduh video MP4 dengan pengaman: cek ruang kosong lebih dulu, unduhan per potongan dengan
     * coba ulang dan pembaruan tautan, serta hingga 3 kali percobaan penuh (info video diambil ulang).
     */
    private fun runVideo(
        url: String, first: StreamInfo, key: String, title: String, base: String, dir: File,
        temps: MutableList<File>
    ) {
        val p0 = DownloadOptions.planFor(first, key)
            ?: throw Permanent("Kualitas video yang dipilih tidak tersedia.")
        if (p0.sizeBytes > 0) {
            val need = p0.sizeBytes * (if (p0.audioUrl != null) 2 else 1) + 30L * 1024 * 1024
            val free = try { dir.usableSpace } catch (e: Exception) { Long.MAX_VALUE }
            if (free < need) {
                throw Permanent(
                    "Ruang penyimpanan tidak cukup: butuh sekitar ${need / 1048576} MB, tersedia ${free / 1048576} MB."
                )
            }
        }
        var info = first
        var lastErr: Exception? = null
        for (attempt in 1..3) {
            if (cancel) throw Cancelled()
            if (attempt > 1) {
                update("Mencoba lagi ($attempt dari 3)…", title, 0, true)
                pause(2000)
                info = try { loadInfo(url, title, true) } catch (e: Cancelled) { throw e } catch (e: Exception) { info }
            }
            // Percobaan ke-2/3 memakai jalur audio cadangan bila hasil gabungan sebelumnya tidak bersuara.
            val aIdx = attempt - 1
            val plan = DownloadOptions.planFor(info, key, aIdx)
                ?: throw Permanent("Kualitas video yang dipilih tidak tersedia.")
            val stamp = System.nanoTime()
            val out = File(dir, "dl_${stamp}_out.mp4").also { temps += it }
            val v = File(dir, "dl_${stamp}_v.mp4").also { temps += it }
            val a = File(dir, "dl_${stamp}_a.m4a").also { temps += it }
            try {
                if (plan.audioUrl == null) {
                    fetch(plan.videoUrl, out, title, "Mengunduh video ${plan.height}p", 0, 100, emptyMap()) {
                        refreshPlan(url, key, plan, aIdx).videoUrl
                    }
                } else {
                    fetch(plan.videoUrl, v, title, "Mengunduh video ${plan.height}p", 0, 80, emptyMap()) {
                        refreshPlan(url, key, plan, aIdx).videoUrl
                    }
                    fetch(plan.audioUrl, a, title, "Mengunduh audio", 80, 95, emptyMap()) {
                        refreshPlan(url, key, plan, aIdx).audioUrl ?: throw IOException("Tautan audio tidak bisa diperbarui.")
                    }
                    update("Menggabungkan video dan audio…", title, 95, true)
                    mux(v, a, out)
                    checkHasAudio(out)
                }
                checkMp4(out)
                val uri = publish(out, "$base (${plan.height}p)", "mp4", "video/mp4", false, tagTitle(title, info.uploaderName), tagArtist(title, info.uploaderName))
                done(title, "Video tersimpan di Movies/YTPlayer", uri, "video/mp4")
                return
            } catch (e: Cancelled) {
                throw e
            } catch (e: IOException) {
                lastErr = e
            } catch (e: RuntimeException) {
                lastErr = IOException("Penggabungan video gagal: ${e.message ?: e.javaClass.simpleName}", e)
            }
            // Hapus sisa percobaan ini agar ruang kosong tidak habis sebelum percobaan berikutnya.
            for (f in listOf(out, v, a)) { try { f.delete() } catch (_: Exception) {} }
        }
        throw lastErr ?: IOException("Unduhan video gagal.")
    }

    /** Urutan percobaan kualitas: yang diminta dulu, lalu sisanya (terbaik → terendah). */
    private fun orderQualities(list: List<TikTokResolver.Quality>, wantH: Int, lowest: Boolean): List<TikTokResolver.Quality> {
        if (lowest) return list.reversed()
        val pick = list.firstOrNull { wantH > 0 && it.height == wantH } ?: list.first()
        return listOf(pick) + list.filter { it !== pick }
    }

    /** Pastikan berkas hasil unduhan benar-benar video MP4 (bukan halaman galat berisi teks). */
    private fun checkMp4(f: File, minSize: Long = 20_000L) {
        if (f.length() < minSize) throw IOException("Berkas yang diterima terlalu kecil, bukan video.")
        val h = ByteArray(12)
        val n = f.inputStream().use { it.read(h) }
        val box = if (n >= 8) String(h, 4, 4, Charsets.ISO_8859_1) else ""
        if (box !in listOf("ftyp", "moov", "mdat", "free", "wide", "skip")) {
            throw IOException("Berkas yang diterima bukan video MP4.")
        }
    }

    /** Mengambil data video dari situs yang sesuai: Facebook bila tautannya Facebook, selain itu TikTok. */
    private fun resolveSite(link: String, fresh: Boolean = false): TikTokResolver.Info =
        if (FacebookLink.isFacebook(link)) FacebookResolver.resolve(link, fresh) else TikTokResolver.resolve(link, fresh)

    private fun siteName(link: String): String = if (FacebookLink.isFacebook(link)) "Facebook" else "TikTok"

    /**
     * Unduh video TikTok dengan banyak cadangan: tiap alamat alternatif dari TikTok dicoba, lalu
     * kualitas lain, lalu seluruh proses diulang dengan data video yang diambil ulang (alamat
     * TikTok cepat kedaluwarsa), sampai 3 putaran. Berkas dicek agar benar-benar MP4.
     * [lowest] = mulai dari kualitas terendah (untuk mengambil suaranya saja, lebih hemat kuota).
     */
    private fun fetchTikTok(
        link: String, first: TikTokResolver.Info, wantH: Int, lowest: Boolean, dest: File,
        title: String, label: String, from: Int, to: Int, audioDest: File? = null
    ): TikTokResolver.Quality {
        var t = first
        var lastErr: Exception? = null
        for (attempt in 1..3) {
            if (cancel) throw Cancelled()
            if (attempt > 1) {
                update("Mencoba lagi ($attempt dari 3)…", title, 0, true)
                pause(1500L * (attempt - 1))
                t = try {
                    resolveSite(link, fresh = true)
                } catch (e: Exception) {
                    lastErr = e
                    continue
                }
            }
            for (q in orderQualities(t.qualities, wantH, lowest)) {
                if (cancel) throw Cancelled()
                val aUrl = q.audioUrl
                if (lowest && aUrl != null) {
                    // Video dan suara terpisah (DASH) dan hanya suaranya yang perlu: ambil trek suaranya saja,
                    // jauh lebih kecil daripada videonya.
                    try {
                        fetch(aUrl, dest, title, label.replace("video", "suara"), from, to, t.headers, maxFailures = 2)
                        checkMp4(dest, 1_000L)
                        return q
                    } catch (e: Cancelled) {
                        throw e
                    } catch (e: IOException) {
                        lastErr = e
                    }
                    continue
                }
                // Bila suaranya terpisah dan perlu digabung: video memakai sampai 80%, suara sisanya.
                val vTo = if (aUrl != null && audioDest != null) minOf(to, 80) else to
                for (u in listOf(q.url) + q.alts) {
                    if (cancel) throw Cancelled()
                    try {
                        fetch(u, dest, title, label, from, vTo, t.headers, maxFailures = 2)
                        checkMp4(dest)
                        if (aUrl != null && audioDest != null) {
                            fetch(
                                aUrl, audioDest, title, label.replace("video", "suara"),
                                vTo, maxOf(vTo, to - 5), t.headers, maxFailures = 2
                            )
                            checkMp4(audioDest, 1_000L)
                        }
                        return q
                    } catch (e: Cancelled) {
                        throw e
                    } catch (e: IOException) {
                        lastErr = e
                    }
                }
            }
        }
        throw lastErr ?: IOException("Unduhan ${siteName(link)} gagal.")
    }

    /** Unduhan TikTok: MP4 tanpa watermark, atau suaranya saja (M4A / MP3) dari video itu. */
    private fun runTikTokJob(link: String, fallbackTitle: String, key: String, temps: MutableList<File>) {
        update("Mengambil info video ${siteName(link)}…", fallbackTitle, 0, true)
        if (!online()) waitOnline(fallbackTitle)
        val t = resolveSite(link)
        val title = t.displayName().ifBlank { fallbackTitle }
        val base = safeName(if (t.author.isBlank()) title else "@${t.author} $title")
        val dir = externalCacheDir ?: cacheDir
        val stamp = System.nanoTime()

        when {
            key.startsWith(TikTokResolver.KEY_MP4) -> {
                val h = key.removePrefix(TikTokResolver.KEY_MP4).toIntOrNull() ?: 0
                val out = File(dir, "dl_${stamp}_tt.mp4").also { temps += it }
                val aud = File(dir, "dl_${stamp}_tta.mp4").also { temps += it }
                val q = fetchTikTok(link, t, h, false, out, title, "Mengunduh video ${siteName(link)}", 0, 100, aud)
                var result = out
                if (q.audioUrl != null && aud.length() > 0) {
                    // Video dan suara datang terpisah (DASH): gabungkan tanpa mengubah kualitas.
                    update("Menggabungkan video dan audio…", title, 95, true)
                    val merged = File(dir, "dl_${stamp}_ttm.mp4").also { temps += it }
                    try {
                        mux(out, aud, merged)
                    } catch (e: RuntimeException) {
                        throw IOException("Penggabungan video gagal: ${e.message ?: e.javaClass.simpleName}", e)
                    }
                    checkMp4(merged)
                    checkHasAudio(merged)
                    result = merged
                }
                val tag = if (q.height > 2) " (${q.height}p)" else ""
                val uri = publish(result, base + tag, "mp4", "video/mp4", false, title, t.author)
                done(title, "Video tersimpan di Movies/YTPlayer", uri, "video/mp4")
            }
            key == TikTokResolver.KEY_M4A -> {
                val src = File(dir, "dl_${stamp}_tt.mp4").also { temps += it }
                fetchTikTok(link, t, 0, true, src, title, "Mengunduh video ${siteName(link)}", 0, 85)
                val m4a = File(dir, "dl_${stamp}_tt.m4a").also { temps += it }
                extractAudio(src, m4a, title)
                val uri = publish(m4a, base, "m4a", "audio/mp4", true, title, t.author)
                done(title, "Audio tersimpan di Music/YTPlayer", uri, "audio/mp4")
            }
            key.startsWith(TikTokResolver.KEY_MP3) -> {
                // Mekanisme sama dengan YouTube: ambil audio M4A lebih dulu, lalu konversi ke MP3
                // sampai 3 percobaan (percobaan 3 mengunduh ulang dengan data video baru).
                // Hanya FFmpeg; gagal semua: unduhan gagal.
                val kbps = key.removePrefix(TikTokResolver.KEY_MP3).toIntOrNull() ?: 192
                var cur = t
                var audioFile: File? = null   // M4A hasil salinan trek suara (atau MP4 bila salinan gagal)
                var lastErr: Exception? = null
                for (attempt in 1..3) {
                    if (cancel) throw Cancelled()
                    val mp3 = File(dir, "dl_${stamp}_tt$attempt.mp3").also { temps += it }
                    try {
                        if (audioFile == null || attempt == 3) {
                            if (attempt > 1) {
                                update("Mencoba lagi ($attempt dari 3)…", title, 0, true)
                                pause(2000)
                                cur = try {
                                    resolveSite(link, fresh = true)
                                } catch (e: Cancelled) { throw e } catch (e: Exception) { cur }
                            }
                            val src = File(dir, "dl_${stamp}_tt$attempt.mp4").also { temps += it }
                            fetchTikTok(link, cur, 0, true, src, title, "Mengunduh video ${siteName(link)}", 0, 45)
                            val aud = File(dir, "dl_${stamp}_tt$attempt.m4a").also { temps += it }
                            audioFile = try {
                                extractAudio(src, aud, title)
                                aud
                            } catch (e: Cancelled) {
                                throw e
                            } catch (e: Exception) {
                                try { aud.delete() } catch (_: Exception) {}
                                src // konversi langsung dari MP4
                            }
                        } else {
                            update("Mencoba lagi ($attempt dari 3)…", title, 45, true)
                        }
                        toMp3(audioFile!!, mp3, kbps, title, 45, 100)
                        val uri = publish(mp3, "$base (${kbps}kbps)", "mp3", "audio/mpeg", true, title, t.author)
                        done(title, "MP3 tersimpan di Music/YTPlayer", uri, "audio/mpeg")
                        return
                    } catch (e: Cancelled) {
                        throw e
                    } catch (e: Mp3UnavailableException) {
                        lastErr = e
                        break
                    } catch (e: Exception) {
                        lastErr = e
                    }
                    try { mp3.delete() } catch (_: Exception) {}
                }
                throw lastErr ?: IOException("Konversi MP3 gagal.")
            }
            else -> throw IOException("Format unduhan TikTok tidak dikenal.")
        }
    }

    /** Menyalin trek suara dari sebuah MP4 ke berkas M4A tanpa mengubah kualitas. */
    private fun extractAudio(src: File, dest: File, title: String) {
        update("Mengambil suara dari video…", title, 90, true)
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(src.absolutePath)
            val t = findTrack(ex, "audio/")
            if (t < 0) throw IOException("Video ini tidak punya suara.")
            ex.selectTrack(t)
            val m = MediaMuxer(dest.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val idx = m.addTrack(ex.getTrackFormat(t))
            m.start()
            started = true
            val buf = ByteBuffer.allocate(1024 * 1024)
            val bi = MediaCodec.BufferInfo()
            while (true) {
                if (cancel) throw Cancelled()
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                bi.offset = 0
                bi.size = size
                bi.presentationTimeUs = maxOf(0L, ex.sampleTime)
                bi.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                m.writeSampleData(idx, buf, bi)
                ex.advance()
            }
            m.stop()
            started = false
        } finally {
            try { ex.release() } catch (_: Exception) {}
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    /** Ukuran total aliran YouTube dari parameter clen di alamatnya; -1 bila tidak ada. */
    private fun clenOf(u: String): Long =
        Regex("[?&]clen=(\\d+)").find(u)?.groupValues?.get(1)?.toLongOrNull() ?: -1L

    /**
     * Unduh per potongan 4 MB (Range) agar tidak dicekik server. Bila putus: tunggu internet bila
     * perlu, coba lagi dengan jeda yang makin lama (sampai 5 kali berturut-turut) dan lanjut dari
     * byte terakhir. Bila YouTube menolak header Range (HTTP 403), potongan diminta lewat parameter
     * "range" di alamat (cara yang juga dipakai pemutar YouTube). Bila tautan kedaluwarsa
     * (HTTP 403/404/410) atau gagal terus, [refresh] dipanggil untuk mengambil tautan baru
     * (maks. 3 kali) lalu unduhan dilanjutkan dari posisi terakhir.
     */
    private fun fetch(
        url: String, dest: File, title: String, label: String, from: Int, to: Int,
        headers: Map<String, String> = emptyMap(), maxFailures: Int = 5,
        refresh: (() -> String)? = null
    ) {
        var cur = url
        var pos = 0L
        var total = -1L
        var failures = 0
        var refreshes = 0
        var offlineWaits = 0
        var viaParam = false
        var paramTried = false
        lastPct = from - 10
        update("$label…", title, from, true)

        FileOutputStream(dest).use { out ->
            val buf = ByteArray(64 * 1024)
            while (total < 0 || pos < total) {
                if (cancel) throw Cancelled()
                val reqUrl = if (viaParam) {
                    cur + (if (cur.contains('?')) "&" else "?") + "range=$pos-${pos + CHUNK - 1}"
                } else cur
                val conn = URL(reqUrl).openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 30_000
                    conn.readTimeout = 30_000
                    conn.setRequestProperty("User-Agent", DownloaderImpl.USER_AGENT)
                    headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
                    if (!viaParam) conn.setRequestProperty("Range", "bytes=$pos-${pos + CHUNK - 1}")
                    val code = conn.responseCode
                    if (code == 416) break
                    if (code == 403 || code == 404 || code == 410) throw Expired(code)
                    if (code != 200 && code != 206) throw IOException("Server menolak unduhan (HTTP $code)")
                    val whole = code == 200 && !viaParam
                    total = if (viaParam) {
                        clenOf(cur).takeIf { it > 0 } ?: total
                    } else if (whole) conn.contentLengthLong
                    else conn.getHeaderField("Content-Range")
                        ?.substringAfter('/')?.trim()?.toLongOrNull() ?: total

                    // Server mengabaikan Range dan mengirim dari awal: lewati byte yang sudah ada.
                    var toSkip = if (whole) pos else 0L
                    val start = pos
                    conn.inputStream.use { input ->
                        while (true) {
                            if (cancel) throw Cancelled()
                            val n = input.read(buf)
                            if (n < 0) break
                            var off = 0
                            if (toSkip > 0) {
                                val d = minOf(n.toLong(), toSkip).toInt()
                                toSkip -= d
                                off = d
                            }
                            if (n > off) {
                                out.write(buf, off, n - off)
                                pos += (n - off)
                                report(pos, total, label, title, from, to)
                            }
                        }
                    }
                    failures = 0
                    if (whole || pos == start) break
                    if (total < 0 && pos - start < CHUNK) break
                } catch (e: Cancelled) {
                    throw e
                } catch (e: IOException) {
                    // Internet putus: tunggu sampai tersambung, itu bukan kegagalan unduhan.
                    if (e !is Expired && offlineWaits < 20 && !online()) {
                        offlineWaits++
                        if (waitOnline(title)) continue
                    }
                    failures++
                    if (e is Expired && !viaParam && !paramTried && refresh != null &&
                        cur.contains("googlevideo.com") && !cur.contains("range=")
                    ) {
                        // Header Range ditolak: coba minta potongan lewat parameter "range" dulu.
                        paramTried = true
                        viaParam = true
                        failures = 0
                        continue
                    }
                    if (e is Expired || failures > maxFailures) {
                        val fresh = if (refresh != null && refreshes < 3) {
                            try { refresh() } catch (x: Cancelled) { throw x } catch (x: Exception) { null }
                        } else null
                        if (fresh == null) throw e
                        refreshes++
                        cur = fresh
                        failures = 0
                        viaParam = false
                        paramTried = false
                    } else {
                        pause(minOf(1000L shl (failures - 1), 8000L))
                    }
                } finally {
                    conn.disconnect()
                }
            }
        }
        if (total >= 0 && pos < total) throw IOException("Unduhan terputus sebelum selesai.")
        if (pos == 0L) throw IOException("Tidak ada data yang diterima.")
    }

    private fun report(pos: Long, total: Long, label: String, title: String, from: Int, to: Int) {
        if (total <= 0) return
        val pct = from + ((to - from) * pos / total).toInt()
        if (pct >= lastPct + 2) {
            lastPct = pct
            update("$label… $pct%", title, pct, false)
        }
    }

    /** Konversi ke MP3 lewat pustaka native ramping (FFmpeg + LAME). Tidak ada jalur cadangan: bila gagal, galat dilempar. */
    private fun toMp3(src: File, dest: File, kbps: Int, title: String, from: Int, to: Int) {
        lastPct = from - 10
        update("Mengonversi ke MP3…", title, from, true)
        val ok = FfmpegMp3.convert(src, dest, kbps, { cancel }) { p ->
            val pct = from + (to - from) * p / 100
            if (pct >= lastPct + 2) {
                lastPct = pct
                update("Mengonversi ke MP3… $pct%", title, pct, false)
            }
        }
        if (!ok) throw Cancelled()
    }

    /**
     * Menggabung video H.264 + audio AAC ke satu MP4 tanpa mengubah kualitas.
     *
     * Penting: akhir data ditandai dengan sampleTrackIndex < 0, BUKAN dengan sampleTime < 0. Audio AAC
     * dari sebagian lagu (mis. YouTube Musik / "Topic") dimulai dengan stempel waktu negatif akibat
     * penundaan encoder; bila negatif dianggap "habis", seluruh audio terlewat dan trek suara dibuang
     * pada hasil akhir. Stempel waktu negatif digeser ke 0 per trek.
     */
    private fun mux(video: File, audio: File, out: File) {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            vEx.setDataSource(video.absolutePath)
            aEx.setDataSource(audio.absolutePath)
            val vt = findTrack(vEx, "video/")
            val at = findTrack(aEx, "audio/")
            if (vt < 0 || at < 0) throw IOException("Berkas video atau audio tidak bisa dibaca.")
            vEx.selectTrack(vt)
            aEx.selectTrack(at)

            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val vi = m.addTrack(vEx.getTrackFormat(vt))
            val ai = m.addTrack(aEx.getTrackFormat(at))
            m.start()
            started = true

            val buf = ByteBuffer.allocate(8 * 1024 * 1024)
            val bi = MediaCodec.BufferInfo()
            var vLive = vEx.sampleTrackIndex >= 0
            var aLive = aEx.sampleTrackIndex >= 0
            val vShift = if (vLive) minOf(0L, vEx.sampleTime) else 0L
            val aShift = if (aLive) minOf(0L, aEx.sampleTime) else 0L
            var vN = 0
            var aN = 0
            var lastV = 0L
            var lastA = 0L
            while (vLive || aLive) {
                if (cancel) throw Cancelled()
                val vTime = if (vLive) vEx.sampleTime - vShift else Long.MAX_VALUE
                val aTime = if (aLive) aEx.sampleTime - aShift else Long.MAX_VALUE
                val useVideo = vLive && (!aLive || vTime <= aTime)
                val ex = if (useVideo) vEx else aEx
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) {
                    if (useVideo) vLive = false else aLive = false
                    continue
                }
                var t = (if (useVideo) vTime else aTime)
                // Pastikan tidak mundur (muxer menolak/membuang sampel yang mundur).
                if (useVideo) { if (t < lastV) t = lastV; lastV = t } else { if (t < lastA) t = lastA; lastA = t }
                bi.offset = 0
                bi.size = size
                bi.presentationTimeUs = t
                bi.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                m.writeSampleData(if (useVideo) vi else ai, buf, bi)
                if (useVideo) vN++ else aN++
                ex.advance()
                if (useVideo) vLive = vEx.sampleTrackIndex >= 0 else aLive = aEx.sampleTrackIndex >= 0
            }
            m.stop()
            started = false
            if (aN == 0) throw IOException("Penggabungan gagal: tidak ada sampel audio yang terbaca (video $vN sampel).")
        } finally {
            try { vEx.release() } catch (_: Exception) {}
            try { aEx.release() } catch (_: Exception) {}
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    /** Pastikan MP4 hasil gabungan punya trek suara yang berisi data (bukan senyap). */
    private fun checkHasAudio(f: File) {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.absolutePath)
            val t = findTrack(ex, "audio/")
            if (t < 0) throw IOException("Hasil gabungan tidak punya suara.")
            ex.selectTrack(t)
            var count = 0
            var bytes = 0L
            val buf = ByteBuffer.allocate(1024 * 1024)
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                count++
                bytes += n
                ex.advance()
            }
            if (count < 10 || bytes < 2048) throw IOException("Hasil gabungan tidak punya suara.")
        } finally {
            try { ex.release() } catch (_: Exception) {}
        }
    }

    private fun findTrack(ex: MediaExtractor, mimePrefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
            if (mime != null && mime.startsWith(mimePrefix)) return i
        }
        return -1
    }

    // ------------------------------------------------------------------ penyimpanan

    private fun tagTitle(videoTitle: String, channel: String?) =
        AudioTags.fromVideo(videoTitle, artistOf(channel)).first

    private fun tagArtist(videoTitle: String, channel: String?) =
        AudioTags.fromVideo(videoTitle, artistOf(channel)).second

    /** Nama artis dari nama kanal: buang akhiran " - Topic" dan "VEVO". */
    private fun artistOf(name: String?): String =
        Regex("(?i)\\s*-\\s*topic$").replace(name.orEmpty().trim(), "")
            .let { Regex("(?i)\\s*vevo$").replace(it, "") }.trim()

    /**
     * Simpan hasil unduhan. Audio (MP3/M4A) diberi tag judul + artis di dalam berkas; judul + artis juga
     * dicatat di MediaStore. Tidak ada gambar sampul. Bila tag gagal ditulis, berkas disimpan apa adanya.
     */
    private fun publish(
        src: File, base: String, ext: String, mime: String, audio: Boolean,
        title: String? = null, artist: String? = null
    ): Uri? {
        var tagged: File? = null
        try {
            if (audio && !title.isNullOrBlank()) tagged = AudioTags.tag(src, ext, title, artist.orEmpty())
            return publishFile(tagged ?: src, base, ext, mime, audio, title, artist)
        } finally {
            try { tagged?.delete() } catch (_: Exception) {}
        }
    }

    private fun publishFile(
        src: File, base: String, ext: String, mime: String, audio: Boolean,
        title: String?, artist: String?
    ): Uri? {
        val display = "$base.$ext"
        if (Build.VERSION.SDK_INT >= 29) {
            val collection = if (audio) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, display)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeDir(audio))
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                if (!title.isNullOrBlank()) put(MediaStore.MediaColumns.TITLE, title)
                if (!artist.isNullOrBlank()) put(MediaStore.MediaColumns.ARTIST, artist)
            }
            val uri = contentResolver.insert(collection, values)
                ?: throw IOException("Gagal membuat berkas di penyimpanan.")
            try {
                val os = contentResolver.openOutputStream(uri)
                    ?: throw IOException("Gagal menulis berkas di penyimpanan.")
                os.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                return uri
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        }

        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            throw IOException("Izin penyimpanan belum diberikan.")
        }
        @Suppress("DEPRECATION")
        val root = Environment.getExternalStoragePublicDirectory(
            if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        val dir = if (subDir.isEmpty()) File(root, "YTPlayer") else File(File(root, "YTPlayer"), subDir)
        dir.mkdirs()
        var f = File(dir, display)
        var n = 1
        while (f.exists()) {
            f = File(dir, "$base ($n).$ext")
            n++
        }
        FileOutputStream(f).use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
        MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), arrayOf(mime), null)
        return null
    }

    private fun relativeDir(audio: Boolean): String {
        val root = if (audio) "Music/YTPlayer" else "Movies/YTPlayer"
        val sub = subDir
        return if (sub.isEmpty()) root else "$root/$sub"
    }

    private fun safeName(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.')
        return cleaned.take(80).trim().ifEmpty { "video" }
    }

    private fun audioMime(ext: String) = when (ext) {
        "webm" -> "audio/webm"
        "mp3" -> "audio/mpeg"
        else -> "audio/mp4"
    }

    // ------------------------------------------------------------------ notifikasi

    /** Ketuk notifikasi membuka layar Unduhan. */
    private fun openDownloadsPi(): PendingIntent = PendingIntent.getActivity(
        this, 2,
        Intent(this, DownloadsActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun progressNotif(text: String, title: String, pct: Int, indeterminate: Boolean): Notification {
        val cancelPi = PendingIntent.getService(
            this, 1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = batch
        val heading = if (b != null) {
            "${b.name} (${b.index}/${b.total})" + (if (b.round > 0) " – ulang" else "")
        } else title.ifEmpty { "YT Player" }
        val body = if (b != null && title.isNotEmpty()) "${title.take(60)}: $text" else text
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(heading)
            .setContentText(body)
            .setOngoing(true)
            .setContentIntent(openDownloadsPi())
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), indeterminate)
            .addAction(0, "Batal", cancelPi)
            .build()
    }

    private fun update(text: String, title: String, pct: Int, indeterminate: Boolean) {
        val b = batch
        val logText = if (b != null) {
            "Video ${b.index} dari ${b.total}" + (if (b.round > 0) " (ulang)" else "") +
                (if (title.isNotEmpty()) ": ${title.take(60)}" else "") + ". $text"
        } else text
        DownloadLog.progress(curId, logText, if (indeterminate) 0 else pct)
        nm.notify(FG_ID, progressNotif(text, title, pct, indeterminate))
    }

    private fun done(title: String, text: String, uri: Uri?, mime: String) {
        if (batch != null) {
            jobOk = true // dihitung oleh runPlaylist
            return
        }
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Unduhan selesai")
            .setContentText("$title — $text")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title\n$text"))
            .setAutoCancel(true)
        if (uri != null) {
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            b.setContentIntent(
                PendingIntent.getActivity(this, doneId, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        }
        nm.notify(doneId++, b.build())
        DownloadLog.finish(curId, DownloadLog.DONE, text, uri?.toString(), mime, title = title)
        toast("Selesai: $title. $text")
    }

    private fun fail(title: String, message: String, retry: Boolean = true) {
        if (batch != null) {
            jobErr = "${title.ifEmpty { "Video" }}: $message"
            jobRetry = retry // dicatat & diulang oleh runPlaylist
            return
        }
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Unduhan gagal")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${title.ifEmpty { "Video" }}\n$message"))
            .setContentIntent(openDownloadsPi())
            .setAutoCancel(true)
        nm.notify(doneId++, b.build())
        DownloadLog.finish(curId, DownloadLog.FAILED, message, retry = retry, title = title)
        toast("Unduhan gagal: $message")
    }

    private fun toast(text: String) {
        main.post { Toast.makeText(applicationContext, text, Toast.LENGTH_LONG).show() }
    }
}
