package com.makroku.automation.service

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.makroku.automation.MakroApp
import com.makroku.automation.model.TileTrigger
import com.makroku.automation.model.TriggerEvent

/** Ubin Pengaturan Cepat: mengetuknya menjalankan makro dengan pemicu "Ubin Pengaturan Cepat" bernomor sama. */
abstract class MacroTileBase(private val index: Int) : TileService() {
    private fun owner() = (applicationContext as MakroApp).repo.macros.value
        .firstOrNull { m -> m.enabled && m.triggers.any { it is TileTrigger && it.tile == index } }

    override fun onStartListening() {
        val t = qsTile ?: return
        val m = owner()
        t.label = m?.name ?: "MakroKu $index"
        t.state = if (m != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.contentDescription = if (m != null) "${m.name}, ketuk untuk menjalankan makro" else "MakroKu $index, belum ada makro"
        t.subtitle = if (m != null) "Ketuk untuk jalankan" else "Belum ada makro"
        t.updateTile()
    }

    override fun onClick() {
        (applicationContext as MakroApp).engine.dispatch(TriggerEvent("tile", mapOf("tile" to index.toString())))
        android.widget.Toast.makeText(this, owner()?.let { it.name + " dijalankan" } ?: "Belum ada makro untuk ubin ini", android.widget.Toast.LENGTH_SHORT).show()
    }
}

class MacroTile1 : MacroTileBase(1)
class MacroTile2 : MacroTileBase(2)
class MacroTile3 : MacroTileBase(3)
