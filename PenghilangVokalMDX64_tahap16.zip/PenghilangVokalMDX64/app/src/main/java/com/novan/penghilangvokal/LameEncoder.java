package com.novan.penghilangvokal;

import java.io.IOException;

/** Penyandi MP3 (LAME) lewat JNI. Stereo, VBR. */
final class LameEncoder implements AutoCloseable {

    static {
        System.loadLibrary("lamejni");
    }

    private long handle;

    /** vbrQuality: 0 (terbaik, ~245 kbps) sampai 9 (terkecil). quality: kecepatan/mutu algoritma LAME, 2 = tinggi. */
    LameEncoder(int sampleRate, int vbrQuality, int quality) throws IOException {
        handle = nativeInit(sampleRate, vbrQuality, quality);
        if (handle == 0) throw new IOException("LAME gagal diinisialisasi");
    }

    /** Ukuran buffer keluaran yang aman untuk 'frames' frame sekali panggil. */
    static int ukuranBuffer(int frames) {
        return (int) (frames * 1.25) + 7200;
    }

    /** pcm: stereo interleaved 16-bit. Mengembalikan jumlah byte MP3 yang tertulis di out. */
    int encode(short[] pcm, int frames, byte[] out) throws IOException {
        int n = nativeEncode(handle, pcm, frames, out);
        if (n < 0) throw new IOException("penyandian MP3 gagal (kode " + n + ")");
        return n;
    }

    int flush(byte[] out) throws IOException {
        int n = nativeFlush(handle, out);
        if (n < 0) throw new IOException("penutupan MP3 gagal (kode " + n + ")");
        return n;
    }

    /** Bingkai penanda VBR (durasi dan pencarian posisi); tulis di awal berkas setelah flush. */
    int lameTag(byte[] out) throws IOException {
        int n = nativeLameTag(handle, out);
        if (n < 0) throw new IOException("bingkai VBR gagal dibuat (kode " + n + ")");
        return n;
    }

    @Override
    public void close() {
        if (handle != 0) {
            nativeClose(handle);
            handle = 0;
        }
    }

    private static native long nativeInit(int sampleRate, int vbrQuality, int quality);

    private static native int nativeEncode(long h, short[] pcm, int frames, byte[] out);

    private static native int nativeFlush(long h, byte[] out);

    private static native int nativeLameTag(long h, byte[] out);

    private static native void nativeClose(long h);
}
