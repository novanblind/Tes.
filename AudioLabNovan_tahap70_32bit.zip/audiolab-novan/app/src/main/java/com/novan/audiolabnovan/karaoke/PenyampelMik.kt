package com.novan.audiolabnovan.karaoke

import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Pengubah laju sampel mono yang berjalan blok demi blok (interpolasi linear), dipakai untuk menyimpan vokal
 * dengan laju 44,1 kHz walaupun mikrofon dibaca dengan laju asli HP (biasanya 48 kHz) demi jalur pantauan cepat.
 * Sampel terakhir blok sebelumnya diingat, jadi sambungan antarblok mulus. Murni hitungan.
 */
class PenyampelMik(private val dari: Int, private val ke: Int) {
    /** Berapa sampel sumber per satu sampel keluaran. */
    private val langkah = dari.toDouble() / ke.toDouble()
    private var posisi = 0.0
    private var terakhir = 0

    /** Jumlah sampel keluaran paling banyak untuk [masuk] sampel masukan. */
    fun ukuranKeluar(masuk: Int): Int = (masuk.toLong() * ke / dari).toInt() + 4

    /** Mengubah [n] sampel di [masuk] ke [keluar]; mengembalikan banyaknya sampel keluaran yang terisi. */
    fun proses(masuk: ShortArray, n: Int, keluar: ShortArray): Int {
        if (n <= 0) return 0
        var k = 0
        while (k < keluar.size) {
            val i0 = floor(posisi).toInt()
            if (i0 + 1 > n - 1) break
            val a = if (i0 < 0) terakhir else masuk[i0].toInt()
            val b = masuk[i0 + 1].toInt()
            val t = posisi - i0
            keluar[k++] = (a + (b - a) * t).roundToInt().toShort()
            posisi += langkah
        }
        terakhir = masuk[n - 1].toInt()
        posisi -= n
        return k
    }
}
