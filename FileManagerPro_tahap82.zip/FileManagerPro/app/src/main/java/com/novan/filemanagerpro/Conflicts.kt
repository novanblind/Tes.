package com.novan.filemanagerpro

import android.app.Activity
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.button.MaterialButton
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pilihan pengguna saat nama berkas tujuan sudah dipakai. */
enum class ConflictAction { OVERWRITE, RENAME, SKIP, MERGE }

/** Satu berkas/folder yang namanya sudah ada di folder tujuan. [key] dipakai sebagai kunci hasil pilihan. */
class ConflictItem(
    val key: String,
    val name: String,
    val srcIsDir: Boolean,
    val srcSize: Long,
    val srcTime: Long,
    val tgtIsDir: Boolean,
    val tgtSize: Long,
    val tgtTime: Long,
    /** true bila sumber dan sasaran sama-sama folder: dialognya Gabung / Lewati / Batal. */
    val merge: Boolean = false,
    /** Konflik berkas di dalam folder; baru dicari setelah pengguna memilih Gabung. */
    val nested: (() -> List<ConflictItem>)? = null
) {
    /** Sasaran berupa berkas/folder biasa di penyimpanan. */
    constructor(
        key: String, name: String, srcIsDir: Boolean, srcSize: Long, srcTime: Long, target: File
    ) : this(
        key, name, srcIsDir, srcSize, srcTime,
        target.isDirectory, if (target.isFile) target.length() else 0L, target.lastModified()
    )
}

/** Dialog "sudah ada, timpa?" untuk salin dan pindah. */
object Conflicts {

    /** Mencari berkas biasa di [items] yang namanya sudah ada di [dest]. */
    fun forFiles(items: List<File>, cut: Boolean, dest: File): List<ConflictItem> {
        val out = ArrayList<ConflictItem>()
        val destCanon = try { dest.canonicalPath } catch (e: Exception) { return out }
        for (f in items) {
            try {
                if (!f.exists()) continue
                // Menyalin ke folder yang sama tetap membuat "nama (1)"; memindah ke folder sama tidak berbuat apa-apa.
                if (f.parentFile?.canonicalPath == destCanon) continue
                // Folder tidak bisa ditempel ke dalam dirinya sendiri.
                if (f.isDirectory && (destCanon + "/").startsWith(f.canonicalPath + "/")) continue
                val t = File(dest, f.name)
                if (!t.exists()) continue
                if (t.canonicalPath == f.canonicalPath) continue
                if (f.isDirectory && t.isDirectory) {
                    out.add(
                        ConflictItem(
                            f.absolutePath, f.name, true, 0L, f.lastModified(),
                            true, 0L, t.lastModified(), true
                        ) { nestedFiles(f, t) }
                    )
                    continue
                }
                out.add(
                    ConflictItem(
                        f.absolutePath, f.name, f.isDirectory,
                        if (f.isFile) f.length() else 0L, f.lastModified(), t
                    )
                )
            } catch (e: Exception) {
                // abaikan; pekerjaan akan melaporkan gagal sendiri
            }
        }
        return out
    }

    /** Berkas di dalam [src] yang namanya sudah ada di [tgt]; folder kembar langsung digabung tanpa bertanya. */
    fun nestedFiles(src: File, tgt: File): List<ConflictItem> {
        val out = ArrayList<ConflictItem>()
        val kids = src.listFiles()?.sortedBy { it.name } ?: return out
        for (c in kids) {
            try {
                val t = File(tgt, c.name)
                if (!t.exists()) continue
                if (c.isDirectory && t.isDirectory) {
                    out.addAll(nestedFiles(c, t))
                } else {
                    out.add(
                        ConflictItem(
                            c.absolutePath, c.name, c.isDirectory,
                            if (c.isFile) c.length() else 0L, c.lastModified(), t
                        )
                    )
                }
            } catch (e: Exception) {
                // abaikan
            }
        }
        return out
    }

    /** Sama seperti [forFiles] tetapi untuk entri tingkat atas di dalam zip. */
    fun forZip(tops: List<String>, entries: List<ArchiveOps.Edit>, dest: File): List<ConflictItem> {
        val out = ArrayList<ConflictItem>()
        for (top in tops) {
            val name = top.substringAfterLast('/')
            val t = File(dest, name)
            if (!t.exists()) continue
            val e = entries.firstOrNull { it.path == top }
            val isDir = e?.isDir ?: true
            if (isDir && t.isDirectory) {
                out.add(
                    ConflictItem(
                        name, name, true, 0L, e?.time ?: 0L,
                        true, 0L, t.lastModified(), true
                    ) {
                        val res = ArrayList<ConflictItem>()
                        for (en in entries.filter { it.path.startsWith("$top/") }.sortedBy { it.path }) {
                            val t2 = File(t, en.path.removePrefix("$top/"))
                            if (!t2.exists()) continue
                            if (en.isDir && t2.isDirectory) continue
                            res.add(
                                ConflictItem(
                                    en.path, en.path.substringAfterLast('/'), en.isDir,
                                    if (en.isDir) 0L else en.size.coerceAtLeast(0L), en.time, t2
                                )
                            )
                        }
                        res
                    }
                )
                continue
            }
            out.add(
                ConflictItem(
                    name, name, isDir,
                    if (isDir) 0L else (e?.size ?: 0L).coerceAtLeast(0L),
                    e?.time ?: 0L, t
                )
            )
        }
        return out
    }

    /**
     * Menanyakan satu per satu. [onDone] menerima peta kunci → pilihan, atau null bila pengguna menekan Batal.
     * Folder kembar: Gabung / Lewati. Bila memilih Gabung, berkas kembar di dalamnya ditanyakan juga.
     * Kotak "Terapkan ke semua" berlaku terpisah untuk folder dan untuk berkas.
     */
    fun ask(activity: Activity, list: List<ConflictItem>, onDone: (Map<String, ConflictAction>?) -> Unit) {
        val result = HashMap<String, ConflictAction>()
        val queue = ArrayList<ConflictItem>(list)
        var folderAll: ConflictAction? = null
        var fileAll: ConflictAction? = null
        var mergedAny = false
        fun step(i: Int) {
            if (i >= queue.size) {
                onDone(result)
                return
            }
            val item = queue[i]
            fun decided(act: ConflictAction) {
                result[item.key] = act
                if (act == ConflictAction.MERGE) {
                    mergedAny = true
                    val n = try { item.nested?.invoke().orEmpty() } catch (e: Exception) { emptyList() }
                    queue.addAll(i + 1, n)
                }
                step(i + 1)
            }
            val preset = if (item.merge) folderAll else fileAll
            if (preset != null) {
                decided(preset)
                return
            }
            val rest = queue.subList(i + 1, queue.size)
            val canAll = if (item.merge) rest.any { it.merge } else (rest.isNotEmpty() || mergedAny)
            show(activity, item, canAll) { act, all ->
                if (act == null) {
                    onDone(null)
                } else {
                    if (all) {
                        if (item.merge) folderAll = act else fileAll = act
                    }
                    decided(act)
                }
            }
        }
        step(0)
    }

    private fun show(
        activity: Activity, item: ConflictItem, canApplyAll: Boolean,
        onPick: (ConflictAction?, Boolean) -> Unit
    ) {
        val dp = activity.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val title = TextView(activity).apply {
            textSize = 18f
            val msg = activity.getString(R.string.conflict_title, item.name)
            val sb = SpannableStringBuilder(msg)
            val at = msg.indexOf(item.name)
            if (at >= 0) sb.setSpan(StyleSpan(Typeface.BOLD), at, at + item.name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = sb
        }

        fun info(label: String, isDir: Boolean, size: Long, time: Long): TextView = TextView(activity).apply {
            textSize = 14f
            setPadding(px(10), px(8), px(10), px(8))
            val sb = StringBuilder(label)
            sb.append('\n').append(if (isDir) activity.getString(R.string.conflict_folder) else Util.formatSize(activity, size))
            if (time > 0) {
                val d = Date(time)
                sb.append('\n').append(SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID")).format(d))
                sb.append('\n').append(SimpleDateFormat("HH.mm", Locale("id", "ID")).format(d))
            }
            val ss = SpannableStringBuilder(sb.toString())
            ss.setSpan(StyleSpan(Typeface.BOLD), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = ss
            setBackgroundColor(0x33808080)
        }

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { l: Int, r: Int ->
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    leftMargin = l; rightMargin = r
                }
            }
            addView(
                info(activity.getString(R.string.conflict_source), item.srcIsDir, item.srcSize, item.srcTime),
                lp(0, px(4))
            )
            addView(
                info(activity.getString(R.string.conflict_target), item.tgtIsDir, item.tgtSize, item.tgtTime),
                lp(px(4), 0)
            )
        }

        val all = CheckBox(activity).apply {
            text = activity.getString(if (item.merge) R.string.conflict_apply_all_folder else R.string.conflict_apply_all)
            textSize = 16f
            visibility = if (canApplyAll) android.view.View.VISIBLE else android.view.View.GONE
        }

        var dialog: AlertDialog? = null
        fun btn(textRes: Int, outlined: Boolean, act: ConflictAction?): MaterialButton =
            (if (outlined) MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            else MaterialButton(activity)).apply {
                setText(textRes)
                setOnClickListener {
                    val applyAll = all.isChecked && act != null
                    dialog?.dismiss()
                    onPick(act, applyAll)
                }
            }

        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(20), px(24), px(8))
            addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (!item.merge) {
                addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = px(16)
                })
            }
            addView(all, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = px(8)
            })
            val choices = if (item.merge) listOf(
                Triple(R.string.conflict_merge, false, ConflictAction.MERGE as ConflictAction?),
                Triple(R.string.conflict_skip, false, ConflictAction.SKIP as ConflictAction?),
                Triple(R.string.cancel, true, null as ConflictAction?)
            ) else listOf(
                Triple(R.string.conflict_overwrite, false, ConflictAction.OVERWRITE as ConflictAction?),
                Triple(R.string.conflict_rename, false, ConflictAction.RENAME as ConflictAction?),
                Triple(R.string.conflict_skip, false, ConflictAction.SKIP as ConflictAction?),
                Triple(R.string.cancel, true, null as ConflictAction?)
            )
            for ((res, outlined, act) in choices) {
                addView(btn(res, outlined, act), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = px(8)
                    gravity = Gravity.CENTER_HORIZONTAL
                })
            }
        }

        val dlg = AlertDialog.Builder(activity)
            .setView(ScrollView(activity).apply { addView(box) })
            .create()
        dialog = dlg
        dlg.setOnCancelListener { onPick(null, false) }
        dlg.show()
    }
}
