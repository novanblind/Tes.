package com.novan.pisahsuara

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.function.Consumer

/**
 * Tampilan mengikuti One UI Samsung "Pisahkan suara aplikasi", dengan daftar centang:
 * aplikasi yang dicentang di "speaker HP" dan aplikasi yang dicentang di "speaker Bluetooth".
 * Aplikasi yang tidak dicentang mengikuti sistem.
 */
class MainActivity : Activity() {
    private lateinit var swUtama: Switch
    private lateinit var rowHp: TextView
    private lateinit var rowBt: TextView
    private lateinit var rowDevice: TextView
    private lateinit var rowAdb: TextView
    private lateinit var rowBaterai: TextView
    private lateinit var btnIzin: Button
    private lateinit var status: TextView
    private var apps: List<Pair<String, String>> = emptyList() // paket to label
    private var updating = false
    private var adbPesan = ""
    private val handler = Handler(Looper.getMainLooper())
    private var statusTeks = "Status: memeriksa..."
    private val sedangPeriksa = java.util.concurrent.atomic.AtomicBoolean(false)
    private var terakhirBangkit = 0L
    private val pantau = object : Runnable {
        override fun run() { periksaStatus(); handler.postDelayed(this, 3000) }
    }

    /** Periksa keadaan nyata (di thread terpisah) lalu tampilkan. Hanya memperbarui layar bila teksnya berubah. */
    private fun periksaStatus() {
        if (!sedangPeriksa.compareAndSet(false, true)) return
        val app = applicationContext
        Thread {
            val t = try { AudioRouter.statusNyata(app) } catch (e: Throwable) { "Gagal memeriksa: ${e.javaClass.simpleName}: ${e.message}" }
            // Server mati / tak berdenyut saat layar terbuka: bangkitkan lagi (jarak minimal 20 detik), tanpa menunggu penjaga.
            if (Rules.active(app) && t.startsWith("Pemisahan suara BELUM BERJALAN") &&
                android.os.SystemClock.elapsedRealtime() - terakhirBangkit > 20000) {
                terakhirBangkit = android.os.SystemClock.elapsedRealtime()
                try { Kompat.mulaiLayanan(app, Intent(app, RoutingService::class.java)) } catch (_: Throwable) {}
            }
            runOnUiThread {
                val baru = "Status: $t"
                if (baru != statusTeks) { statusTeks = baru; refresh() }
            }
            sedangPeriksa.set(false)
        }.start()
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = refresh()
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun twoLine(title: String, summary: String): CharSequence {
        val sb = SpannableStringBuilder(title)
        sb.setSpan(RelativeSizeSpan(1.15f), 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("\n").append(summary)
        return sb
    }

    private fun makeRow(onClick: () -> Unit) = TextView(this).apply {
        minHeight = dp(64)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(12), dp(20), dp(12))
        isClickable = true
        isFocusable = true
        val tv = android.util.TypedValue()
        if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) setBackgroundResource(tv.resourceId)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Pisahkan suara aplikasi"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val judul = TextView(this).apply {
            text = "Pisahkan suara aplikasi"
            textSize = 28f
            setPadding(dp(20), dp(24), dp(20), dp(12))
            setTypeface(typeface, Typeface.BOLD)
            isFocusable = true
            if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
        }

        rowAdb = makeRow { aksiAdb() }
        rowBaterai = makeRow { aksiBaterai() }

        btnIzin = Button(this).apply {
            text = "Beri izin Shizuku"
            setOnClickListener { requestShizuku() }
        }

        swUtama = Switch(this).apply {
            textSize = 18f
            minHeight = dp(72)
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setOnCheckedChangeListener { _, checked ->
                if (updating) return@setOnCheckedChangeListener
                Rules.setEnabled(this@MainActivity, checked)
                startRouting()
                refresh()
            }
        }

        rowHp = makeRow { showChecklist("Aplikasi di speaker HP", { Rules.hp(this) }, { Rules.setHp(this, it) },
            { Rules.bt(this) }, "speaker Bluetooth") }
        rowBt = makeRow { showChecklist("Aplikasi di speaker Bluetooth", { Rules.bt(this) }, { Rules.setBt(this, it) },
            { Rules.hp(this) }, "speaker HP") }
        rowDevice = makeRow { showDeviceChooser() }

        val info = TextView(this).apply {
            text = "Centang aplikasi yang suaranya ingin diputar di speaker HP, dan aplikasi yang ingin " +
                "diputar di speaker Bluetooth. Aplikasi yang tidak dicentang mengikuti pengaturan sistem.\n\n" +
                "Putar ulang suara aplikasi yang dipilih agar pengalihan berlaku."
            textSize = 14f
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        status = TextView(this).apply {
            textSize = 12f
            setPadding(dp(20), dp(8), dp(20), dp(24))
        }

        // Saklar paling atas (urutan fokus pertama): pembaca layar langsung menemukan Aktif/Nonaktif.
        root.addView(swUtama)
        root.addView(rowHp)
        root.addView(rowBt)
        root.addView(rowDevice)
        root.addView(rowAdb)
        root.addView(rowBaterai)
        root.addView(btnIzin)
        root.addView(info)
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })

        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) need += Manifest.permission.BLUETOOTH_CONNECT
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 100)

        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (_: Throwable) {}
        loadApps()
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (_: Throwable) {}
        PairHelper.sink = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        PairHelper.sink = Consumer { s -> adbPesan = s; refresh() }
        (getSystemService(AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(deviceCb, handler)
        refresh()
        handler.removeCallbacks(pantau)
        handler.post(pantau)
        // Setelah aplikasi diperbarui atau dimatikan sistem, penjaga dan Server ikut mati: nyalakan lagi
        // begitu aplikasi dibuka (bila Server masih sehat, tidak ada yang diubah).
        if (Rules.active(this)) {
            try { Kompat.mulaiLayanan(this, Intent(this, RoutingService::class.java)) } catch (_: Throwable) {}
        }
    }

    override fun onPause() {
        handler.removeCallbacks(pantau)
        try { (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(deviceCb) } catch (_: Throwable) {}
        super.onPause()
    }

    private fun bebasBaterai(): Boolean = try {
        (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (_: Throwable) { false }

    /** Minta pengecualian penghemat baterai; bila sudah diberikan, buka daftar pengaturan baterai (untuk "Tanpa batasan"). */
    private fun aksiBaterai() {
        try {
            if (!bebasBaterai()) {
                startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    android.net.Uri.parse("package:$packageName")))
                return
            }
        } catch (_: Throwable) {}
        try {
            startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Throwable) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:$packageName")))
            } catch (_: Throwable) { toast("Buka Pengaturan > Baterai > Pisahkan suara aplikasi, pilih Tanpa batasan.") }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku belum berjalan.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Izin Shizuku sudah diberikan")
            } else {
                Shizuku.requestPermission(200)
            }
        } catch (e: Throwable) {
            toast("Shizuku tidak terdeteksi")
        }
    }

    // ---------- Sambungan ADB (tanpa Shizuku) ----------

    /** Android 7-10: tanpa Debugging nirkabel. Komputer (USB) atau HP lain (kabel OTG) menjalankan "adb tcpip 5555" sekali. */
    private fun aksiAdbUsb() {
        if (AdbBackend.tersambung(this)) {
            AlertDialog.Builder(this)
                .setTitle("Sambungan ADB aktif")
                .setMessage("ADB sudah tersambung lewat jalur lokal (127.0.0.1:5555). Sambungan hilang bila HP restart; ulangi langkah di bawah bila perlu:\n\n" + petunjukUsb)
                .setPositiveButton("Tutup", null)
                .show()
            return
        }
        adbPesan = "Menyambung ke 127.0.0.1:5555..."
        refresh()
        Thread {
            PairHelper.connect(applicationContext, true)
            val ok = AdbBackend.tersambung(this)
            if (ok) startRouting()
            runOnUiThread {
                refresh()
                if (!ok) {
                    adbPesan = "Belum tersambung. Ikuti petunjuk, lalu ketuk lagi."
                    AlertDialog.Builder(this)
                        .setTitle("Sambungkan lewat USB")
                        .setMessage(petunjukUsb)
                        .setPositiveButton("Mengerti", null)
                        .setNeutralButton("Buka Opsi pengembang") { _, _ -> bukaOpsiPengembang() }
                        .show()
                    refresh()
                }
            }
        }.start()
    }

    private val petunjukUsb = "Android ${Build.VERSION.RELEASE} belum punya Debugging nirkabel, jadi pengaktifan dilakukan sekali lewat kabel.\n\n" +
        "1. Opsi pengembang > nyalakan Debugging USB.\n" +
        "2. Cara A (komputer): sambungkan HP ke komputer dengan kabel data USB, lalu jalankan:\n    adb tcpip 5555\n" +
        "3. Cara B (tanpa komputer): sambungkan HP ini ke HP kedua dengan kabel OTG. HP kedua menjadi pengganti komputer: " +
        "di HP kedua buka aplikasi ADB lewat USB (misalnya Bugjaeger), pilih HP ini, lalu jalankan perintah yang sama: tcpip 5555.\n" +
        "4. Bila muncul 'Izinkan debugging USB?' di HP ini, centang Selalu izinkan lalu ketuk Izinkan.\n" +
        "5. Cabut kabel, buka aplikasi ini, ketuk baris Sambungan ADB. Aplikasi menyambung sendiri ke 127.0.0.1:5555.\n\n" +
        "Mode ini hilang bila HP restart; ulangi langkah 2 atau 3 setelah restart."

    private fun aksiAdb() {
        if (!Kompat.adaNirkabel()) { aksiAdbUsb(); return }
        if (!AdbBackend.tersambung(this)) {
            // Kunci ADB aplikasi ini tetap: HP yang pernah dipasangkan menyambung tanpa kode (juga setelah pasang ulang).
            adbPesan = "Di Opsi pengembang, nyalakan Debugging nirkabel. Aplikasi menyambung sendiri, tanpa kode."
            refresh()
            bukaOpsiPengembang()
            Thread {
                PairHelper.sambungTanpaKode(applicationContext)
                if (AdbBackend.tersambung(this)) startRouting()
                runOnUiThread { refresh() }
            }.start()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Sambungan ADB aktif")
                .setMessage("ADB sudah tersambung. Pasangkan ulang bila sambungan bermasalah.")
                .setPositiveButton("Tutup", null)
                .setNegativeButton("Pasangkan ulang") { _, _ ->
                    getSharedPreferences("adb_pisah", MODE_PRIVATE).edit().putBoolean("paired", false).apply()
                    PairHelper.startDiscovery(applicationContext)
                    refresh()
                }
                .show()
        }
    }

    private fun bukaOpsiPengembang() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            try { startActivity(Intent(android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS)) }
            catch (e2: Exception) { toast("Buka Pengaturan > Opsi pengembang secara manual") }
        }
    }

    // ---------- Daftar aplikasi ----------

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val result = pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
                .map { it.packageName to it.loadLabel(pm).toString() }
                .sortedBy { it.second.lowercase() }
            runOnUiThread {
                apps = result
                refresh()
            }
        }.start()
    }

    private fun appLabel(pkg: String): String =
        apps.firstOrNull { it.first == pkg }?.second ?: try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

    private fun ringkas(set: Set<String>): String {
        if (set.isEmpty()) return "Belum ada yang dicentang"
        val nama = set.map { appLabel(it) }.sortedBy { it.lowercase() }
        return "${set.size} aplikasi: " + nama.take(3).joinToString(", ") + if (nama.size > 3) ", dan lainnya" else ""
    }

    private fun refresh() {
        runOnUiThread {
            val shizukuAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            val shizukuOk = AudioRouter.shizukuReady()
            btnIzin.visibility = if (shizukuAlive && !shizukuOk) View.VISIBLE else View.GONE

            val on = Rules.enabled(this)
            updating = true
            swUtama.isChecked = on
            swUtama.text = twoLine("Pisahkan suara aplikasi", if (on) "Aktif" else "Nonaktif")
            updating = false

            rowHp.text = twoLine("Aplikasi di speaker HP", ringkas(Rules.hp(this)))
            rowBt.text = twoLine("Aplikasi di speaker Bluetooth", ringkas(Rules.bt(this)))

            val outs = AudioRouter.external(this)
            val dev = outs.firstOrNull { AudioRouter.key(it) == Rules.device(this) }
            val devSummary = when {
                Rules.device(this) == null -> "Otomatis" + (outs.firstOrNull()?.let { ": ${AudioRouter.label(it)}" } ?: " (belum ada yang tersambung)")
                dev != null -> AudioRouter.label(dev)
                else -> "Perangkat tidak tersambung"
            }
            rowDevice.text = twoLine("Perangkat Bluetooth", devSummary)

            val adbRingkas = when {
                shizukuOk -> "Memakai Shizuku"
                !AdbBackend.dipasangkan(this) && !Kompat.adaNirkabel() -> "Belum tersambung. Ketuk untuk petunjuk USB (komputer / kabel OTG)"
                !AdbBackend.dipasangkan(this) -> "Belum tersambung. Ketuk untuk membuka Opsi pengembang; kode 6 angka hanya diminta sekali"
                AdbBackend.tersambung(this) -> if (Lokal.viaLokal) "Tersambung (jalur lokal, tanpa Wi-Fi)" else "Tersambung (lewat Wi-Fi)"
                !Kompat.adaNirkabel() -> "Terputus (mode USB hilang saat HP restart). Ketuk untuk petunjuk"
                else -> "Terputus. Ketuk untuk membuka Opsi pengembang dan menyambung tanpa kode"
            }
            rowAdb.text = twoLine("Sambung tanpa kode Wi-Fi (tanpa Shizuku)", adbRingkas)
            rowBaterai.text = twoLine("Izin latar belakang (baterai)",
                if (bebasBaterai()) "Tidak dibatasi. Ketuk untuk membuka pengaturan baterai."
                else "Dibatasi sistem. Ketuk untuk mengizinkan agar Pisahkan suara aplikasi tidak dimatikan di latar belakang.")

            for (r in listOf(rowHp, rowBt, rowDevice)) {
                r.isEnabled = on
                r.alpha = if (on) 1f else 0.4f
            }
            status.text = statusTeks + if (adbPesan.isNotEmpty()) "\nADB: $adbPesan" else ""
        }
    }

    // ---------- Dialog daftar centang ----------

    private fun showChecklist(
        judul: String,
        ambil: () -> Set<String>,
        simpan: (Set<String>) -> Unit,
        ambilLain: () -> Set<String>,
        namaLain: String
    ) {
        if (apps.isEmpty()) {
            toast("Daftar aplikasi masih dimuat, coba lagi sebentar")
            return
        }
        val pm = packageManager
        val tampil = apps.toMutableList()

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cari = EditText(this).apply {
            hint = "Cari aplikasi"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine()
        }
        val lv = ListView(this)
        box.addView(cari, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val adapter = object : ArrayAdapter<Pair<String, String>>(this, 0, tampil) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val (pkg, label) = getItem(position)!!
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    minimumHeight = dp(64)
                }
                val icon = ImageView(context).apply {
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    try { setImageDrawable(pm.getApplicationIcon(pkg)) } catch (_: Exception) {}
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val dipilih = ambil()
                val sedangDiLain = pkg in ambilLain() && pkg !in dipilih
                val name = TextView(context).apply {
                    text = if (sedangDiLain) "$label\nSaat ini di $namaLain" else label
                    textSize = 16f
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    setPadding(dp(16), 0, dp(8), 0)
                }
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val cb = CheckBox(context).apply {
                    isChecked = pkg in dipilih
                    isClickable = false
                    isFocusable = false
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }
                row.addView(cb)
                row.contentDescription = label + (if (pkg in dipilih) ", dicentang" else ", tidak dicentang") +
                    (if (sedangDiLain) ", saat ini di $namaLain" else "")
                return row
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, i, _ ->
            val pkg = adapter.getItem(i)!!.first
            val baru = ambil().toMutableSet()
            if (!baru.add(pkg)) baru.remove(pkg)
            simpan(baru) // tersimpan langsung; tombol Kembali menutup daftar
            adapter.notifyDataSetChanged()
            refresh()
            terapkanSegera() // langsung berlaku, tidak menunggu daftar ditutup
        }
        cari.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                adapter.clear()
                adapter.addAll(if (q.isEmpty()) apps else apps.filter { it.second.lowercase().contains(q) })
            }
        })

        AlertDialog.Builder(this)
            .setTitle(judul)
            .setView(box)
            .setOnDismissListener { startRouting(); refresh() }
            .show()
    }

    private fun showDeviceChooser() {
        val outs = AudioRouter.external(this)
        val names = (listOf("Otomatis (perangkat luar pertama yang tersambung)") + outs.map { AudioRouter.label(it) }).toTypedArray()
        val checked = if (Rules.device(this) == null) 0 else outs.indexOfFirst { AudioRouter.key(it) == Rules.device(this) } + 1
        AlertDialog.Builder(this)
            .setTitle("Perangkat Bluetooth")
            .setSingleChoiceItems(names, checked) { d, which ->
                Rules.setDevice(this, if (which == 0) null else AudioRouter.key(outs[which - 1]))
                d.dismiss()
                startRouting()
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private val tundaTerapkan = Runnable { startRouting() }

    /** Terapkan perubahan centang segera (digabung bila beberapa centang diketuk berurutan). */
    private fun terapkanSegera() {
        handler.removeCallbacks(tundaTerapkan)
        handler.postDelayed(tundaTerapkan, 300)
    }

    private fun startRouting() {
        Kompat.mulaiLayanan(this, Intent(this, RoutingService::class.java))
        handler.postDelayed({ periksaStatus() }, 1500)
        handler.postDelayed({ periksaStatus() }, 4000)
        handler.postDelayed({ periksaStatus() }, 8000)
    }
}
