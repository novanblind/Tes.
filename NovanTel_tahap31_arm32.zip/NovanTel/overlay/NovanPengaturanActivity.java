package org.telegram.messenger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Novan Tel - layar "Pengaturan Novan Tel", versi ringkas untuk pembaca layar.
 *
 * Layar utama hanya berisi daftar kategori berbentuk tombol (judul dan pilihan sekarang, misalnya "Gema: Mati").
 * Mengetuk satu kategori membuka dialog kecil berisi pilihannya: pilihan tunggal (radio) atau beberapa sakelar (centang).
 * Pilihan disimpan di SharedPreferences "novan_mod" dan langsung berlaku.
 */
public class NovanPengaturanActivity extends Activity {

    private static final int IZIN_MIKROFON = 77;

    private SharedPreferences pref;
    private volatile boolean ujiBerjalan = false;
    private final ArrayList<Baris> semuaBaris = new ArrayList<Baris>();

    private interface Nilai {
        String ambil();
    }

    /** Satu tombol kategori: teksnya "judul: nilai sekarang". */
    private class Baris {
        Button tombol;
        String judul;
        Nilai nilai;

        void segarkan() {
            String t = nilai == null ? judul : judul + ": " + nilai.ambil();
            tombol.setText(t);
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Pengaturan Novan Tel");
        pref = getSharedPreferences(NovanMod.PREF, Context.MODE_PRIVATE);
        NovanMod.muat(getApplicationContext());

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        root.setPadding(p, p, p, p);
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });

        judul(root, "Pengaturan Novan Tel", 24);
        teks(root, "Ketuk satu kategori untuk membuka pilihannya. Perubahan langsung berlaku, tanpa membangun ulang aplikasi.");

        // ---------------------------------------------------------------- latar belakang dan baterai
        judul(root, "Latar belakang dan baterai", 20);
        teks(root, "Agar Novan Tel tetap tersambung ke internet saat layar mati dan tidak terus \"Menghubungkan...\" ketika dibuka, "
                + "izinkan aplikasi berjalan di latar belakang tanpa pembatasan baterai. Di HP Oppo/ColorOS, lanjutkan dengan tombol "
                + "kedua: buka Info aplikasi, pilih Penggunaan baterai lalu Tanpa batasan, dan nyalakan Mulai otomatis.");
        baris(root, "Izin latar belakang (baterai tidak dibatasi)", new Nilai() {
            @Override
            public String ambil() {
                return bebasBaterai() ? "Sudah diizinkan" : "Belum diizinkan, ketuk untuk mengizinkan";
            }
        }, new Runnable() {
            @Override
            public void run() {
                bukaIzinLatar();
            }
        });
        baris(root, "Buka Info aplikasi (baterai dan mulai otomatis)", null, new Runnable() {
            @Override
            public void run() {
                dialogLatarLanjut();
            }
        });

        // ---------------------------------------------------------------- kategori halaman utama
        judul(root, "Kategori halaman utama", 20);
        teks(root, "Menambah tab Grup, Pribadi, dan Channel di daftar obrolan, tepat setelah tab Semua Obrolan. Pindah tab dengan mengetuk namanya "
                + "atau usap dua jari ke kiri dan kanan. Folder buatan Anda yang jenisnya sama persis, misalnya Grup, dipakai ulang dan tidak digandakan. "
                + "Jangan ubah atau hapus tab bawaan ini di Folder Obrolan; matikan lewat sini.");
        baris(root, "Kategori halaman utama", new Nilai() {
            @Override
            public String ambil() {
                return NovanKategori.nyala() ? NovanKategori.status() : "Mati";
            }
        }, new Runnable() {
            @Override
            public void run() {
                dialogKategori();
            }
        });

        // ---------------------------------------------------------------- mode hantu
        judul(root, "Mode hantu", 20);
        teks(root, "Untuk menandai terbaca sendiri, tekan-tahan obrolan di daftar lalu pilih Tandai sebagai dibaca.");
        baris(root, "Mode hantu", centangNilai(
                new String[]{"hantu_baca", "hantu_mengetik", "hantu_online", "hantu_cerita", "hantu_konten"},
                new boolean[]{NovanMod.HANTU_BACA, NovanMod.HANTU_MENGETIK, NovanMod.HANTU_ONLINE, NovanMod.HANTU_CERITA, NovanMod.HANTU_KONTEN}),
                new Runnable() {
                    @Override
                    public void run() {
                        dialogCentang("Mode hantu",
                                new String[]{
                                        "Jangan tandai pesan terbaca: lawan bicara tidak melihat pesan sudah dibaca",
                                        "Sembunyikan sedang mengetik dan merekam",
                                        "Sembunyikan status online dan terakhir dilihat",
                                        "Lihat cerita tanpa jejak",
                                        "Dengar pesan suara dan video bulat tanpa jejak"},
                                new String[]{"hantu_baca", "hantu_mengetik", "hantu_online", "hantu_cerita", "hantu_konten"},
                                new boolean[]{NovanMod.HANTU_BACA, NovanMod.HANTU_MENGETIK, NovanMod.HANTU_ONLINE, NovanMod.HANTU_CERITA, NovanMod.HANTU_KONTEN});
                    }
                });

        // ---------------------------------------------------------------- pesan suara
        judul(root, "Pesan suara", 20);
        baris(root, "Kualitas pesan suara", new Nilai() {
            @Override
            public String ambil() {
                return labelKualitas(pref.getString("kualitas_suara", NovanMod.KUALITAS_SUARA));
            }
        }, new Runnable() {
            @Override
            public void run() {
                final String[] nilai = {"terendah", "hemat", "sedang", "tinggi", "asli"};
                final String[] label = {
                        "Terendah: 18 kb/s, berkas paling kecil, suara lebih kasar",
                        "Hemat: 32 kb/s (bawaan)",
                        "Sedang: 48 kb/s",
                        "Tinggi: 64 kb/s, lebih jernih, berkas lebih besar",
                        "Asli Telegram: tidak diubah"};
                dialogPilih("Kualitas pesan suara", label, nilai, "kualitas_suara", NovanMod.KUALITAS_SUARA, null);
            }
        });
        baris(root, "Pilihan pesan suara", centangNilai(
                new String[]{"unduh_suara", "simpan_unduhan"},
                new boolean[]{NovanMod.UNDUH_SUARA, NovanMod.SIMPAN_UNDUHAN}),
                new Runnable() {
                    @Override
                    public void run() {
                        dialogCentang("Pilihan pesan suara",
                                new String[]{
                                        "Unduh otomatis pesan suara masuk, lewat Wi-Fi, data seluler, dan roaming",
                                        "Baris Simpan ke Unduhan di menu pesan (folder " + NovanMod.FOLDER_UNDUHAN + " di Download)"},
                                new String[]{"unduh_suara", "simpan_unduhan"},
                                new boolean[]{NovanMod.UNDUH_SUARA, NovanMod.SIMPAN_UNDUHAN});
                    }
                });

        // ---------------------------------------------------------------- transkripsi suara (Groq)
        judul(root, "Transkripsi pesan suara", 20);
        teks(root, "Menu tekan-tahan pesan suara dan video bulat mendapat baris Transkripsi. Audio dikirim ke Groq memakai kunci API milik Anda. "
                + "Bila bahasa suara berbeda dari bahasa terjemahan, teks langsung diterjemahkan.");
        baris(root, "Kunci API Groq", new Nilai() {
            @Override
            public String ambil() {
                return NovanTranskripsi.statusKunci();
            }
        }, new Runnable() {
            @Override
            public void run() {
                NovanTranskripsi.dialogKunci(NovanPengaturanActivity.this, new Runnable() {
                    @Override
                    public void run() {
                        segarkanSemua();
                    }
                });
            }
        });
        baris(root, "Pilihan transkripsi", centangNilai(
                new String[]{"transkripsi", "transkripsi_terjemah_otomatis"},
                new boolean[]{NovanMod.TRANSKRIPSI, true}),
                new Runnable() {
                    @Override
                    public void run() {
                        dialogCentang("Pilihan transkripsi",
                                new String[]{
                                        "Baris Transkripsi di menu tekan-tahan pesan suara dan video bulat",
                                        "Terjemahkan otomatis setelah transkripsi bila bahasa suara berbeda dari bahasa terjemahan"},
                                new String[]{"transkripsi", "transkripsi_terjemah_otomatis"},
                                new boolean[]{NovanMod.TRANSKRIPSI, true});
                    }
                });
        baris(root, "Bahasa terjemahan", new Nilai() {
            @Override
            public String ambil() {
                String k = pref.getString("transkripsi_bahasa_tujuan", "id");
                String[] kode = NovanTranskripsi.kodeBahasa(false);
                String[] label = NovanTranskripsi.labelBahasaDaftar(false);
                for (int i = 0; i < kode.length; i++) {
                    if (kode[i].equals(k)) {
                        return label[i];
                    }
                }
                return "Indonesia";
            }
        }, new Runnable() {
            @Override
            public void run() {
                dialogPilih("Bahasa terjemahan", NovanTranskripsi.labelBahasaDaftar(false), NovanTranskripsi.kodeBahasa(false),
                        "transkripsi_bahasa_tujuan", "id", null);
            }
        });
        baris(root, "Bahasa dalam pesan suara", new Nilai() {
            @Override
            public String ambil() {
                String k = pref.getString("transkripsi_bahasa_suara", "auto");
                String[] kode = NovanTranskripsi.kodeBahasa(true);
                String[] label = NovanTranskripsi.labelBahasaDaftar(true);
                for (int i = 0; i < kode.length; i++) {
                    if (kode[i].equals(k)) {
                        return label[i];
                    }
                }
                return label[0];
            }
        }, new Runnable() {
            @Override
            public void run() {
                dialogPilih("Bahasa dalam pesan suara", NovanTranskripsi.labelBahasaDaftar(true), NovanTranskripsi.kodeBahasa(true),
                        "transkripsi_bahasa_suara", "auto", null);
            }
        });

        // ---------------------------------------------------------------- efek pesan suara
        if (NovanMod.EFEK_SUARA) {
            judul(root, "Efek pesan suara", 20);
            teks(root, "Tiap kategori punya satu pilihan, atau Mati. Beberapa kategori boleh dipakai bersamaan. "
                    + "Berlaku untuk rekaman berikutnya, dan ikut masuk ke berkas suara yang terkirim. Tidak berlaku untuk video bulat.");
            for (int i = 0; i < NovanEfek.KAT_ID.length; i++) {
                final int k = i;
                baris(root, NovanEfek.KAT_JUDUL[i], new Nilai() {
                    @Override
                    public String ambil() {
                        return NovanEfek.labelPilihan(NovanEfek.KAT_ID[k]);
                    }
                }, new Runnable() {
                    @Override
                    public void run() {
                        dialogEfek(k);
                    }
                });
            }
            baris(root, "Coba efek: rekam 4 detik lalu putar hasilnya", null, new Runnable() {
                @Override
                public void run() {
                    ujiEfek();
                }
            });
            baris(root, "Matikan semua efek", null, new Runnable() {
                @Override
                public void run() {
                    SharedPreferences.Editor e = pref.edit();
                    for (String kat : NovanEfek.KAT_ID) {
                        e.putString("efek_kat_" + kat, "mati");
                    }
                    e.apply();
                    segarkanSemua();
                    Toast.makeText(NovanPengaturanActivity.this, "Semua efek dimatikan", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---------------------------------------------------------------- privasi
        judul(root, "Privasi akun", 20);
        baris(root, "Pintasan privasi Telegram", null, new Runnable() {
            @Override
            public void run() {
                dialogPrivasi();
            }
        });

        // ---------------------------------------------------------------- konfirmasi
        judul(root, "Konfirmasi", 20);
        teks(root, "Dialog Yakin sebelum tindakan yang mudah salah ketuk. Semuanya mati secara bawaan.");
        baris(root, "Konfirmasi sebelum", centangNilai(
                new String[]{"konfirmasi_telepon", "konfirmasi_stiker", "konfirmasi_suara"},
                new boolean[]{false, false, false}),
                new Runnable() {
                    @Override
                    public void run() {
                        dialogCentang("Konfirmasi sebelum",
                                new String[]{
                                        "Menelepon: tanya dulu sebelum panggilan suara atau video ke satu orang",
                                        "Mengirim stiker atau GIF",
                                        "Mengirim pesan suara: pilih Batal untuk membuang rekaman"},
                                new String[]{"konfirmasi_telepon", "konfirmasi_stiker", "konfirmasi_suara"},
                                new boolean[]{false, false, false});
                    }
                });

        // ---------------------------------------------------------------- lainnya
        judul(root, "Lainnya", 20);
        baris(root, "Fitur tambahan", centangNilai(
                new String[]{"anti_hapus", "blokir_iklan", "teruskan_tanpa_kutipan", "salin_sebagian", "rapikan_pengaturan"},
                new boolean[]{NovanMod.ANTI_HAPUS, NovanMod.BLOKIR_IKLAN, NovanMod.TERUSKAN_TANPA_KUTIPAN, NovanMod.SALIN_SEBAGIAN, true}),
                new Runnable() {
                    @Override
                    public void run() {
                        dialogCentang("Fitur tambahan",
                                new String[]{
                                        "Anti hapus: pesan yang dihapus lawan bicara untuk semua orang tetap ada di HP Anda",
                                        "Blokir pesan bersponsor (bisa dianggap melanggar ketentuan API Telegram)",
                                        "Teruskan tanpa nama pengirim, bisa diubah per pesan di layar teruskan",
                                        "Baris Salin sebagian teks di menu tekan-tahan pesan",
                                        "Rapikan Pengaturan Telegram: sembunyikan Dompet, Premium, Bintang, Bisnis, dan Kirim Hadiah (berlaku setelah membuka ulang Pengaturan)"},
                                new String[]{"anti_hapus", "blokir_iklan", "teruskan_tanpa_kutipan", "salin_sebagian", "rapikan_pengaturan"},
                                new boolean[]{NovanMod.ANTI_HAPUS, NovanMod.BLOKIR_IKLAN, NovanMod.TERUSKAN_TANPA_KUTIPAN, NovanMod.SALIN_SEBAGIAN, true});
                    }
                });

        segarkanSemua();
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        segarkanSemua();
    }

    private void segarkanSemua() {
        for (Baris b : semuaBaris) {
            b.segarkan();
        }
    }

    // ------------------------------------------------------------ izin latar belakang / baterai
    private boolean bebasBaterai() {
        try {
            if (Build.VERSION.SDK_INT < 23) {
                return true;
            }
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Throwable e) {
            return false;
        }
    }

    /** Tombol utama: minta pengecualian baterai (dialog sistem). Bila sudah diizinkan, tampilkan pilihan lanjutan. */
    private void bukaIzinLatar() {
        if (bebasBaterai()) {
            kabar("Sudah diizinkan berjalan di latar belakang tanpa pembatasan baterai.");
            dialogLatarLanjut();
            return;
        }
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        } catch (Throwable e) {
            // lanjut ke daftar pengecualian baterai
        }
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            kabar("Cari Novan Tel di daftar ini, lalu pilih Tidak dioptimalkan atau Izinkan.");
            return;
        } catch (Throwable e) {
            // lanjut ke info aplikasi
        }
        bukaInfoAplikasi();
    }

    private void bukaInfoAplikasi() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Throwable e) {
            kabar("Tidak bisa membuka Info aplikasi. Buka Pengaturan HP, Aplikasi, Novan Tel, lalu Baterai.");
        }
    }

    private void dialogLatarLanjut() {
        final String[] label = {
                "Buka Info aplikasi: pilih Penggunaan baterai lalu Tanpa batasan",
                "Buka pengaturan Mulai otomatis (Oppo, Realme, Vivo, Xiaomi, Huawei)",
                "Buka daftar pengecualian optimasi baterai"};
        new AlertDialog.Builder(this)
                .setTitle("Izin latar belakang")
                .setItems(label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            bukaInfoAplikasi();
                        } else if (which == 1) {
                            bukaMulaiOtomatis();
                        } else {
                            try {
                                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                            } catch (Throwable e) {
                                bukaInfoAplikasi();
                            }
                        }
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    /** Coba layar Mulai otomatis milik beberapa merek; bila tidak ada yang terbuka, buka Info aplikasi. */
    private void bukaMulaiOtomatis() {
        String[][] kandidat = {
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"}};
        for (String[] k : kandidat) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(k[0], k[1]));
                startActivity(i);
                return;
            } catch (Throwable e) {
                // coba kandidat berikutnya
            }
        }
        kabar("Layar Mulai otomatis tidak ditemukan di HP ini. Dibuka Info aplikasi: cari Mulai otomatis atau Penggunaan baterai.");
        bukaInfoAplikasi();
    }

    // ------------------------------------------------------------ tampilan dasar
    private void judul(LinearLayout root, String t, int ukuran) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(ukuran);
        v.setPadding(0, dp(18), 0, dp(6));
        v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= 28) {
            v.setAccessibilityHeading(true);
        }
        root.addView(v);
    }

    private void teks(LinearLayout root, String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(14);
        v.setPadding(0, 0, 0, dp(6));
        root.addView(v);
    }

    private void baris(LinearLayout root, String judul, Nilai nilai, final Runnable aksi) {
        Baris b = new Baris();
        b.judul = judul;
        b.nilai = nilai;
        b.tombol = new Button(this);
        b.tombol.setAllCaps(false);
        b.tombol.setTextSize(17);
        b.tombol.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.tombol.setMinHeight(dp(56));
        b.tombol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aksi.run();
            }
        });
        semuaBaris.add(b);
        root.addView(b.tombol, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void kabar(final String t) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(NovanPengaturanActivity.this, t, Toast.LENGTH_LONG).show();
            }
        });
    }

    // ------------------------------------------------------------ dialog pilihan
    /** Teks nilai untuk kelompok sakelar, misalnya "3 dari 5 nyala". */
    private Nilai centangNilai(final String[] kunci, final boolean[] bawaan) {
        return new Nilai() {
            @Override
            public String ambil() {
                int n = 0;
                for (int i = 0; i < kunci.length; i++) {
                    if (pref.getBoolean(kunci[i], bawaan[i])) {
                        n++;
                    }
                }
                return n + " dari " + kunci.length + " nyala";
            }
        };
    }

    /** Dialog beberapa sakelar (centang). Setiap ketukan langsung tersimpan. */
    private void dialogCentang(String judul, String[] label, final String[] kunci, boolean[] bawaan) {
        final boolean[] cek = new boolean[kunci.length];
        for (int i = 0; i < kunci.length; i++) {
            cek[i] = pref.getBoolean(kunci[i], bawaan[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle(judul)
                .setMultiChoiceItems(label, cek, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean nyala) {
                        pref.edit().putBoolean(kunci[which], nyala).apply();
                        NovanMod.muat(getApplicationContext());
                    }
                })
                .setPositiveButton("Selesai", null)
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface d) {
                        segarkanSemua();
                    }
                })
                .show();
    }

    /** Dialog pilihan tunggal (radio). Mengetuk satu pilihan menyimpan dan menutup dialog. */
    private void dialogPilih(String judul, final String[] label, final String[] nilai, final String kunci, String bawaan,
                             final Runnable setelah) {
        String sekarang = pref.getString(kunci, bawaan);
        int pilih = -1;
        for (int i = 0; i < nilai.length; i++) {
            if (nilai[i].equals(sekarang)) {
                pilih = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(judul)
                .setSingleChoiceItems(label, pilih, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        pref.edit().putString(kunci, nilai[which]).apply();
                        NovanMod.muat(getApplicationContext());
                        if (setelah != null) {
                            setelah.run();
                        }
                        d.dismiss();
                        segarkanSemua();
                        Toast.makeText(NovanPengaturanActivity.this, label[which], Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    /** Dialog Nyala/Mati untuk kategori halaman utama. Berlaku langsung pada semua akun. */
    private void dialogKategori() {
        String[] label = new String[]{"Nyala", "Mati"};
        int pilih = NovanKategori.nyala() ? 0 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Kategori halaman utama")
                .setSingleChoiceItems(label, pilih, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        pref.edit().putBoolean(NovanKategori.KUNCI, which == 0).apply();
                        NovanKategori.terapkanSemua();
                        d.dismiss();
                        segarkanSemua();
                        Toast.makeText(NovanPengaturanActivity.this, which == 0 ? "Nyala" : "Mati", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private String labelKualitas(String k) {
        if ("terendah".equals(k)) {
            return "Terendah 18 kb/s";
        }
        if ("sedang".equals(k)) {
            return "Sedang 48 kb/s";
        }
        if ("tinggi".equals(k)) {
            return "Tinggi 64 kb/s";
        }
        if ("asli".equals(k)) {
            return "Asli Telegram";
        }
        return "Hemat 32 kb/s";
    }

    /** Dialog satu kategori efek: Mati dan pilihan-pilihannya. */
    private void dialogEfek(final int k) {
        final String kat = NovanEfek.KAT_ID[k];
        final String[][] opsi = NovanEfek.KAT[k];
        final String[] label = new String[opsi.length + 1];
        final String[] nilai = new String[opsi.length + 1];
        label[0] = "Mati: tanpa efek";
        nilai[0] = "mati";
        for (int i = 0; i < opsi.length; i++) {
            nilai[i + 1] = opsi[i][0];
            label[i + 1] = opsi[i][1];
        }
        String sekarang = NovanEfek.terpilih(kat);
        int pilih = 0;
        for (int i = 0; i < nilai.length; i++) {
            if (nilai[i].equals(sekarang)) {
                pilih = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(NovanEfek.KAT_JUDUL[k])
                .setSingleChoiceItems(label, pilih, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        pref.edit().putString("efek_kat_" + kat, nilai[which]).apply();
                        d.dismiss();
                        segarkanSemua();
                        Toast.makeText(NovanPengaturanActivity.this, NovanEfek.KAT_JUDUL[k] + ": " + label[which], Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    // ------------------------------------------------------------ privasi
    private void dialogPrivasi() {
        final String[] label = {
                "Nomor telepon: siapa yang bisa melihat",
                "Siapa yang bisa menemukan saya lewat nomor",
                "Terakhir dilihat dan online",
                "Foto profil",
                "Bio",
                "Tanggal lahir",
                "Pesan yang diteruskan",
                "Panggilan",
                "Siapa yang bisa mengundang saya ke grup dan kanal",
                "Pesan suara",
                "Siapa yang bisa mengirim pesan kepada saya",
                "Hadiah",
                "Semua pengaturan Privasi dan Keamanan Telegram"};
        final int[] jenis = {
                ContactsController.PRIVACY_RULES_TYPE_PHONE,
                ContactsController.PRIVACY_RULES_TYPE_ADDED_BY_PHONE,
                ContactsController.PRIVACY_RULES_TYPE_LASTSEEN,
                ContactsController.PRIVACY_RULES_TYPE_PHOTO,
                ContactsController.PRIVACY_RULES_TYPE_BIO,
                ContactsController.PRIVACY_RULES_TYPE_BIRTHDAY,
                ContactsController.PRIVACY_RULES_TYPE_FORWARDS,
                ContactsController.PRIVACY_RULES_TYPE_CALLS,
                ContactsController.PRIVACY_RULES_TYPE_INVITE,
                ContactsController.PRIVACY_RULES_TYPE_VOICE_MESSAGES,
                ContactsController.PRIVACY_RULES_TYPE_MESSAGES,
                ContactsController.PRIVACY_RULES_TYPE_GIFTS};
        new AlertDialog.Builder(this)
                .setTitle("Pintasan privasi Telegram")
                .setItems(label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which < jenis.length) {
                            bukaFragmen(new org.telegram.ui.PrivacyControlActivity(jenis[which]));
                        } else {
                            bukaFragmen(new org.telegram.ui.PrivacySettingsActivity());
                        }
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    /** Buka layar bawaan Telegram di atas aplikasi, lalu tutup layar Novan ini supaya layar tujuan tampak. */
    private void bukaFragmen(org.telegram.ui.ActionBar.BaseFragment fragmen) {
        org.telegram.ui.LaunchActivity la = org.telegram.ui.LaunchActivity.instance;
        if (la == null) {
            Toast.makeText(this, "Buka aplikasi Novan Tel dulu, lalu coba lagi dari Pengaturan.", Toast.LENGTH_LONG).show();
            return;
        }
        la.presentFragment(fragmen);
        finish();
    }

    // ------------------------------------------------------------ uji efek (rekam 4 detik, putar hasilnya)
    private void ujiEfek() {
        if (ujiBerjalan) {
            kabar("Uji sedang berjalan, tunggu sampai selesai.");
            return;
        }
        boolean ada = false;
        for (String kat : NovanEfek.KAT_ID) {
            if (!"mati".equals(NovanEfek.terpilih(kat))) {
                ada = true;
            }
        }
        if (!ada) {
            kabar("Belum ada efek dipilih. Pilih satu efek dulu, lalu coba lagi.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, IZIN_MIKROFON);
            return;
        }
        mulaiUji();
    }

    @Override
    public void onRequestPermissionsResult(int kode, String[] izin, int[] hasil) {
        super.onRequestPermissionsResult(kode, izin, hasil);
        if (kode == IZIN_MIKROFON) {
            if (hasil != null && hasil.length > 0 && hasil[0] == PackageManager.PERMISSION_GRANTED) {
                mulaiUji();
            } else {
                kabar("Izin mikrofon ditolak, uji efek tidak bisa dijalankan.");
            }
        }
    }

    private void mulaiUji() {
        ujiBerjalan = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int laju = 16000;
                try {
                    kabar("Siap. Setelah terdengar nada, bicaralah selama 4 detik.");
                    Thread.sleep(3500);
                    ToneGenerator nada = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
                    nada.startTone(ToneGenerator.TONE_PROP_BEEP, 150);
                    Thread.sleep(400);
                    nada.release();
                    int min = AudioRecord.getMinBufferSize(laju, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    AudioRecord ar = new AudioRecord(MediaRecorder.AudioSource.MIC, laju, AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 16000));
                    if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                        ar.release();
                        kabar("Mikrofon tidak bisa dipakai. Mungkin sedang dipakai aplikasi lain.");
                        return;
                    }
                    short[] rek = new short[laju * 4];
                    int baca = 0;
                    ar.startRecording();
                    while (baca < rek.length) {
                        int n = ar.read(rek, baca, Math.min(1600, rek.length - baca));
                        if (n <= 0) {
                            break;
                        }
                        baca += n;
                    }
                    ar.stop();
                    ar.release();
                    if (baca < laju) {
                        kabar("Rekaman terlalu pendek, coba lagi.");
                        return;
                    }
                    short[] hasil = NovanEfek.uji(java.util.Arrays.copyOf(rek, baca), laju);
                    kabar("Memutar hasil dengan efek.");
                    Thread.sleep(1500);
                    AudioTrack at = new AudioTrack(AudioManager.STREAM_MUSIC, laju, AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, hasil.length * 2, AudioTrack.MODE_STATIC);
                    at.write(hasil, 0, hasil.length);
                    at.play();
                    Thread.sleep(hasil.length * 1000L / laju + 300);
                    at.stop();
                    at.release();
                    kabar("Selesai. Bila suara tadi berubah, efeknya bekerja.");
                } catch (Throwable t) {
                    kabar("Uji gagal: " + t.getClass().getSimpleName());
                } finally {
                    ujiBerjalan = false;
                }
            }
        }).start();
    }
}
