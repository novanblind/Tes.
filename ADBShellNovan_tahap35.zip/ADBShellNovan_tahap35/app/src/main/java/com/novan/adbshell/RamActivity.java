package com.novan.adbshell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Daftar aplikasi yang sedang berjalan beserta pemakaian RAM (PSS), diurutkan dari yang terbesar. */
public class RamActivity extends Activity {
    private static final Pattern PROSES = Pattern.compile(
            "^\\s*([\\d.,]+)K:\\s+(.+?)\\s+\\(pid\\s+(\\d+)(?:\\s*/\\s*([^)]*))?\\)");
    private static final Pattern RAM = Pattern.compile("^\\s*(Total|Free|Used) RAM:\\s*([\\d.,]+)K");

    static class Proses {
        String nama, status;
        int pid;
        long kb;
        boolean aktivitas;
    }

    static class Baris {
        String pkg, label;
        long kb;
        boolean native_, aktivitas;
        List<Proses> proses = new ArrayList<>();
        String text() {
            return label + ": " + mb(kb) + ", " + proses.size() + " proses"
                    + (aktivitas ? ", sedang dipakai" : ", latar belakang");
        }
    }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Baris> all = new ArrayList<>();
    private final List<Baris> shown = new ArrayList<>();
    private boolean hanyaLatar = true, tampilNative = false;
    private String ringkasan = "";
    private volatile String pesanTunda;
    private Button btnLatar, btnNative;
    private EditText etCari;
    private TextView tvRingkas, tvStatus;
    private ArrayAdapter<String> adapter;

    static String mb(long kb) {
        return String.format(Locale.getDefault(), "%.1f MB", kb / 1024.0);
    }

    static long angka(String s) {
        try { return Long.parseLong(s.replace(",", "").replace(".", "")); }
        catch (Exception e) { return 0; }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Aplikasi berjalan dan pemakaian RAM");
        int pad = (int) (12 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView help = new TextView(this);
        help.setText("Daftar diurutkan dari pemakaian RAM terbesar. Ketuk sebuah aplikasi untuk melihat rincian proses, menghentikan paksa, atau menonaktifkannya.");
        root.addView(help);

        tvRingkas = new TextView(this);
        root.addView(tvRingkas);

        btnLatar = new Button(this);
        btnLatar.setOnClickListener(v -> { hanyaLatar = !hanyaLatar; refreshList(true); });
        root.addView(btnLatar);

        btnNative = new Button(this);
        btnNative.setOnClickListener(v -> { tampilNative = !tampilNative; refreshList(true); });
        root.addView(btnNative);

        etCari = new EditText(this);
        etCari.setHint("Cari nama atau paket");
        etCari.setContentDescription("Cari nama atau paket aplikasi");
        etCari.setInputType(InputType.TYPE_CLASS_TEXT);
        etCari.setSingleLine(true);
        etCari.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void afterTextChanged(Editable e) { refreshList(false); }
        });
        root.addView(etCari);

        Button btnMuat = new Button(this);
        btnMuat.setText("Muat ulang");
        btnMuat.setOnClickListener(v -> load());
        root.addView(btnMuat);

        tvStatus = new TextView(this);
        tvStatus.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(tvStatus);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < shown.size()) rincian(shown.get(pos));
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        PairHelper.sink = s -> status(s);
        updateTombol();
        load();
    }

    private void status(final String s) {
        runOnUiThread(() -> {
            tvStatus.setText(s);
            tvStatus.announceForAccessibility(s);
        });
    }

    private void updateTombol() {
        btnLatar.setText(hanyaLatar ? "Tampilkan: hanya latar belakang (ketuk untuk semua)"
                : "Tampilkan: semua aplikasi (ketuk untuk hanya latar belakang)");
        btnNative.setText(tampilNative ? "Proses sistem inti: ditampilkan (ketuk untuk sembunyikan)"
                : "Proses sistem inti: disembunyikan (ketuk untuk tampilkan)");
    }

    private void load() {
        if (pesanTunda == null) status("Membaca pemakaian RAM, mohon tunggu beberapa detik...");
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) {
                    status("Menyambung...");
                    PairHelper.connect(this, true);
                }
                if (!a.isConnected()) {
                    status("Belum tersambung. Sambungkan dulu di layar utama, lalu muat ulang.");
                    return;
                }
                String out = Shell.run(a, "shell:dumpsys meminfo", null);
                parseDanSimpan(out);
            } catch (Throwable e) {
                status("Gagal membaca RAM: " + e);
            }
        });
    }

    private void parseDanSimpan(String out) {
        long total = 0, bebas = 0, terpakai = 0;
        List<Proses> daftar = new ArrayList<>();
        boolean dalam = false;
        for (String line : out.split("\\r?\\n")) {
            Matcher mr = RAM.matcher(line);
            if (mr.find()) {
                long v = angka(mr.group(2));
                if (mr.group(1).equals("Total")) total = v;
                else if (mr.group(1).equals("Free")) bebas = v;
                else terpakai = v;
                continue;
            }
            if (line.startsWith("Total PSS by process")) { dalam = true; continue; }
            if (!dalam) continue;
            if (line.trim().isEmpty()) { if (!daftar.isEmpty()) break; else continue; }
            Matcher m = PROSES.matcher(line);
            if (!m.find()) { if (!daftar.isEmpty()) break; else continue; }
            Proses p = new Proses();
            p.kb = angka(m.group(1));
            p.nama = m.group(2).trim();
            p.pid = Integer.parseInt(m.group(3));
            String st = m.group(4) == null ? "" : m.group(4).trim();
            p.aktivitas = st.toLowerCase(Locale.ROOT).contains("activit");
            p.status = st.isEmpty() ? "latar belakang" : st;
            daftar.add(p);
        }
        if (daftar.isEmpty()) {
            status("Daftar proses tidak ditemukan pada keluaran perangkat.");
            return;
        }
        PackageManager pm = getPackageManager();
        Map<String, Baris> peta = new LinkedHashMap<>();
        for (Proses p : daftar) {
            String pkg = p.nama.split(":")[0];
            Baris r = peta.get(pkg);
            if (r == null) {
                r = new Baris();
                r.pkg = pkg;
                r.label = pkg;
                boolean ketemu = false;
                try {
                    @SuppressWarnings("deprecation")
                    CharSequence l = pm.getApplicationLabel(
                            pm.getApplicationInfo(pkg, PackageManager.GET_UNINSTALLED_PACKAGES));
                    if (l != null && l.length() > 0) { r.label = l.toString(); ketemu = true; }
                } catch (Throwable ignored) {}
                if (pkg.equals("system")) r.label = "Sistem Android (system)";
                r.native_ = pkg.startsWith("/") || (!ketemu && !pkg.contains(".") && !pkg.equals("system"));
                peta.put(pkg, r);
            }
            r.kb += p.kb;
            r.aktivitas |= p.aktivitas;
            r.proses.add(p);
        }
        final List<Baris> hasil = new ArrayList<>(peta.values());
        Collections.sort(hasil, (x, y) -> Long.compare(y.kb, x.kb));
        final String ring = total > 0
                ? "RAM total " + mb(total) + ", terpakai " + mb(terpakai) + ", bebas " + mb(bebas) + "."
                : "";
        runOnUiThread(() -> {
            all.clear();
            all.addAll(hasil);
            ringkasan = ring;
            String pt = pesanTunda;
            pesanTunda = null;
            refreshList(pt == null);
            if (pt != null) status(pt + " " + shown.size() + " aplikasi pada daftar.");
        });
    }

    private void refreshList(boolean umumkan) {
        updateTombol();
        tvRingkas.setText(ringkasan);
        String q = etCari.getText().toString().trim().toLowerCase(Locale.ROOT);
        shown.clear();
        adapter.clear();
        long jumlahKb = 0;
        for (Baris r : all) {
            if (hanyaLatar && r.aktivitas) continue;
            if (!tampilNative && r.native_) continue;
            if (!q.isEmpty() && !r.label.toLowerCase(Locale.ROOT).contains(q)
                    && !r.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(r);
            adapter.add(r.text());
            jumlahKb += r.kb;
        }
        adapter.notifyDataSetChanged();
        if (umumkan) status(shown.size() + " aplikasi, total " + mb(jumlahKb) + ". " + ringkasan);
    }

    // ---------- Daftar aplikasi yang dibatasi (henti kuat) ----------
    private SharedPreferences prefs() { return getSharedPreferences("henti_kuat", MODE_PRIVATE); }

    private boolean dibatasi(String pkg) {
        return prefs().getStringSet("pkg", new HashSet<String>()).contains(pkg);
    }

    private void tandaiBatas(String pkg, boolean ya) {
        Set<String> set = new HashSet<>(prefs().getStringSet("pkg", new HashSet<String>()));
        if (ya) set.add(pkg); else set.remove(pkg);
        prefs().edit().putStringSet("pkg", set).apply();
    }

    private void rincian(final Baris r) {
        StringBuilder sb = new StringBuilder();
        sb.append("Paket: ").append(r.pkg).append("\nTotal RAM: ").append(mb(r.kb)).append("\n");
        for (Proses p : r.proses) {
            sb.append("\n").append(p.nama).append("\n  pid ").append(p.pid)
                    .append(", ").append(mb(p.kb)).append(", ").append(p.status);
        }
        boolean boleh = !r.native_ && r.pkg.contains(".") && !r.pkg.equals(getPackageName());
        boolean batas = boleh && dibatasi(r.pkg);
        if (batas) sb.append("\n\nStatus: dibatasi, tidak bisa jalan sendiri di latar belakang.");
        AlertDialog.Builder d = new AlertDialog.Builder(this)
                .setTitle(r.label)
                .setMessage(sb.toString());
        if (batas) d.setNeutralButton("Lepas pembatasan", (x, w) -> lepas(r));
        else d.setNeutralButton("Tutup", null);
        if (boleh) {
            d.setPositiveButton("Paksa berhenti (kuat)", (x, w) -> konfirmasi(r, true));
            d.setNegativeButton("Nonaktifkan", (x, w) -> konfirmasi(r, false));
        }
        d.show();
    }

    private void konfirmasi(final Baris r, final boolean henti) {
        boolean inti = AppManagerActivity.INTI.contains(r.pkg) || r.pkg.startsWith("com.android.providers.");
        String msg = henti
                ? "Paksa berhenti " + r.label + " (" + r.pkg + ")? Aplikasi ditutup, RAM dibebaskan, lalu "
                  + "dilarang berjalan sendiri di latar belakang (tidak bangun lagi oleh aplikasi lain, alarm, atau layanan). "
                  + "Aplikasi baru berjalan lagi kalau Anda membukanya sendiri. Selama dibatasi, notifikasi dari aplikasi ini "
                  + "bisa tidak masuk. Pembatasan bisa dilepas lewat rincian aplikasi ini, tombol Lepas pembatasan."
                : "Nonaktifkan " + r.label + " (" + r.pkg + ")? Aplikasi juga dihentikan dan tidak bisa berjalan "
                  + "sampai diaktifkan kembali lewat Kelola aplikasi, daftar Dinonaktifkan.";
        if (inti) {
            msg += "\n\nPERINGATAN KERAS: ini paket inti sistem. Salah langkah bisa membuat HP "
                    + "bermasalah atau layar tidak berfungsi.";
        }
        new AlertDialog.Builder(this)
                .setTitle(inti ? "Peringatan" : "Konfirmasi")
                .setMessage(msg)
                .setPositiveButton(henti ? "Paksa berhenti" : "Nonaktifkan", (x, w) -> jalankan(r, henti))
                .setNegativeButton("Batal", null)
                .show();
    }

    private void jalankan(final Baris r, final boolean henti) {
        status("Memproses " + r.label + "...");
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) PairHelper.connect(this, true);
                if (!a.isConnected()) { status("Belum tersambung."); return; }
                String out;
                if (henti) {
                    StringBuilder sbo = new StringBuilder();
                    // 1) larang jalan di latar belakang (aplikasi tetap bisa dibuka manual)
                    for (String op : new String[]{"RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND"})
                        sbo.append(Shell.run(a, "shell:cmd appops set " + r.pkg + " " + op + " ignore", null));
                    // pengunci tambahan (tidak bangun saat HP menyala dan lewat alarm); kalau tidak didukung, diabaikan
                    for (String op : new String[]{"BOOT_COMPLETED", "SCHEDULE_EXACT_ALARM"})
                        Shell.run(a, "shell:cmd appops set " + r.pkg + " " + op + " ignore", null);
                    Shell.run(a, "shell:am set-inactive " + r.pkg + " true", null);
                    // 2) hentikan paksa (dua kali supaya proses turunan ikut mati)
                    sbo.append(Shell.run(a, "shell:am force-stop " + r.pkg, null));
                    // 3) bucket paling terbatas (Android 9+); kalau tidak didukung, diabaikan
                    Shell.run(a, "shell:am set-standby-bucket " + r.pkg + " restricted", null);
                    Shell.run(a, "shell:am force-stop " + r.pkg, null);
                    out = sbo.toString();
                    if (!out.toLowerCase(Locale.ROOT).contains("error")
                            && !out.toLowerCase(Locale.ROOT).contains("exception")) tandaiBatas(r.pkg, true);
                } else {
                    out = Shell.run(a, "shell:pm disable-user --user 0 " + r.pkg, null);
                    Shell.run(a, "shell:am force-stop " + r.pkg, null);
                }
                String t = out == null ? "" : out.trim();
                String low = t.toLowerCase(Locale.ROOT);
                boolean gagal = low.contains("exception") || low.contains("error")
                        || low.contains("failure") || low.contains("unknown package");
                pesanTunda = gagal ? "Gagal: " + t
                        : r.label + (henti ? " dihentikan paksa dan dibatasi, tidak jalan lagi kecuali Anda buka." : " dinonaktifkan.");
                runOnUiThread(this::load);
            } catch (Throwable e) {
                status("Gagal: " + e);
            }
        });
    }

    private void lepas(final Baris r) {
        status("Melepas pembatasan " + r.label + "...");
        io.execute(() -> {
            try {
                Adb a = Adb.get(this);
                if (!a.isConnected()) PairHelper.connect(this, true);
                if (!a.isConnected()) { status("Belum tersambung."); return; }
                for (String op : new String[]{"RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND", "BOOT_COMPLETED", "SCHEDULE_EXACT_ALARM"})
                    Shell.run(a, "shell:cmd appops set " + r.pkg + " " + op + " allow", null);
                Shell.run(a, "shell:am set-inactive " + r.pkg + " false", null);
                Shell.run(a, "shell:am set-standby-bucket " + r.pkg + " active", null);
                tandaiBatas(r.pkg, false);
                pesanTunda = "Pembatasan " + r.label + " dilepas.";
                runOnUiThread(this::load);
            } catch (Throwable e) {
                status("Gagal: " + e);
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
