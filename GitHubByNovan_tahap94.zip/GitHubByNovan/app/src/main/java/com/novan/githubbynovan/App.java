package com.novan.githubbynovan;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

/** Menampilkan hasil pembangunan APK yang selesai saat aplikasi di latar belakang. */
public class App extends Application {
    static volatile int started = 0;

    /** True bila ada layar aplikasi yang sedang tampil di depan. */
    static boolean visible() { return started > 0; }

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle s) { }
            @Override public void onActivityStarted(Activity a) { started++; }
            @Override public void onActivityResumed(Activity a) { ApkTools.tampilkanHasilTertunda(a); }
            @Override public void onActivityPaused(Activity a) { }
            @Override public void onActivityStopped(Activity a) { if (started > 0) started--; }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle s) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });
    }
}
