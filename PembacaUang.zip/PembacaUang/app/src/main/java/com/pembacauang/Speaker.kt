package com.pembacauang

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import java.util.Locale

/**
 * Pengucap suara. Memakai Text-to-Speech bawaan perangkat; bila TalkBack aktif
 * (mode jelajah sentuh) pengumuman dikirim lewat TalkBack agar tidak bertabrakan.
 */
object Speaker : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var toast: Toast? = null
    private var announceView: View? = null

    fun setAnnounceView(view: View?) {
        announceView = view
    }

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        engine.language = Locale("id", "ID")
        ready = true
        pending?.let {
            pending = null
            engine.speak(it, TextToSpeech.QUEUE_FLUSH, null, "PENDING")
        }
    }

    private fun isTouchExploration(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        return am?.isTouchExplorationEnabled == true
    }

    /** Pesan umum: tampil sebagai toast dan diucapkan (kecuali TalkBack aktif). */
    fun say(context: Context, text: String, duration: Int = Toast.LENGTH_SHORT) {
        val app = context.applicationContext
        toast?.cancel()
        toast = Toast.makeText(app, text, duration).also { it.show() }
        if (!isTouchExploration(app)) {
            init(app)
            speak(text)
        }
    }

    /** Nominal uang: tidak memotong ucapan yang sedang berjalan. */
    fun sayNominal(context: Context, text: String) {
        val app = context.applicationContext
        val view = announceView
        val am = app.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        if (am != null && am.isTouchExplorationEnabled && view != null) {
            am.interrupt()
            view.announceForAccessibility(text)
            return
        }
        init(app)
        speakIdle(text)
    }

    private fun speak(text: String) {
        val engine = tts
        if (ready && engine != null) {
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SAY")
        } else {
            pending = text
        }
    }

    private fun speakIdle(text: String) {
        val engine = tts
        if (ready && engine != null) {
            if (!engine.isSpeaking) {
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "MONEY_TTS")
            }
        } else {
            pending = text
        }
    }

    fun stop() {
        toast?.cancel()
        tts?.stop()
        pending = null
    }
}
