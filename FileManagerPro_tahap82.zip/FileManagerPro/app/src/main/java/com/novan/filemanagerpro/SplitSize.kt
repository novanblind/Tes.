package com.novan.filemanagerpro

import android.content.Context
import androidx.appcompat.app.AlertDialog

/** Dialog pilihan ukuran tiap bagian untuk memecah arsip atau berkas. */
object SplitSize {
    private const val MB = 1024L * 1024L

    fun pick(c: Context, enabled: Boolean, onPick: (Long) -> Unit) {
        if (!enabled) { onPick(0L); return }
        val sizes = longArrayOf(10 * MB, 25 * MB, 50 * MB, 100 * MB, 500 * MB, 1024 * MB)
        val labels = arrayOf("10 MB", "25 MB", "50 MB", "100 MB", "500 MB", "1 GB", c.getString(R.string.split_custom))
        AlertDialog.Builder(c)
            .setTitle(R.string.split_size_title)
            .setItems(labels) { _, which ->
                if (which < sizes.size) onPick(sizes[which]) else custom(c, onPick)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun custom(c: Context, onPick: (Long) -> Unit) {
        val input = android.widget.EditText(c)
        input.hint = c.getString(R.string.split_custom_hint)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        AlertDialog.Builder(c)
            .setTitle(R.string.split_size_title)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val mb = input.text.toString().toLongOrNull() ?: 0L
                if (mb >= 1L && mb <= 4000L) onPick(mb * MB)
                else android.widget.Toast.makeText(c, R.string.split_custom_bad, android.widget.Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
