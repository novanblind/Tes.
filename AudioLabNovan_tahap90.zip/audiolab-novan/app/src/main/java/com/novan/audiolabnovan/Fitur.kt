package com.novan.audiolabnovan

/**
 * Tahap 76: daftar fitur untuk halaman utama berbentuk kisi tombol (seperti AudioLab asli).
 * Fitur yang punya [tujuan] membuka layar mandiri; sisanya membuka MainActivity dalam mode fitur
 * yang hanya menampilkan kolom yang diperlukan fitur itu.
 */
object Fitur {
    const val EXTRA = "fitur"
    const val SEMUA = "semua"

    class Def(
        val id: String,
        val judul: String,
        val simbol: String,
        val petunjuk: String = "",
        val tujuan: Class<*>? = null,
        val grup: List<Int> = emptyList(),
        val gabung: Boolean = false,
        val campur: Boolean = false,
        val rekam: Boolean = false,
        val tanpaBerkas: Boolean = false
    )

    /** Semua grup kolom di MainActivity yang bisa disembunyikan; layoutMix dan layoutOrder diatur sendiri. */
    val semuaGrup = listOf(
        R.id.gGabungCek, R.id.gSamakan, R.id.gFormat, R.id.gChannel,
        R.id.gPotongDengar, R.id.gTrim, R.id.gCutMid, R.id.gSpeed, R.id.gPitch, R.id.gSilEdge, R.id.gSilMid,
        R.id.gNormal, R.id.gBassTreble, R.id.gEq, R.id.gComp, R.id.gLoud,
        R.id.secClean,
        R.id.gEcho, R.id.gSpasial, R.id.gDeEcho, R.id.gVocalCut, R.id.gReverse, R.id.gLoops, R.id.gVoice,
        R.id.gSplit, R.id.gSplitAt, R.id.gFade,
        R.id.secTag,
        R.id.gShare, R.id.gRing,
        R.id.secRec, R.id.secHist
    )

    /** Bagian yang dibuka bersama kolomnya; dibuka semua dalam mode fitur, lalu grupnya yang dipilih. */
    val semuaBagian = listOf(
        R.id.secFmt, R.id.secCut, R.id.secVol, R.id.secClean, R.id.secFx,
        R.id.secFade, R.id.secTag, R.id.secSave, R.id.secRec, R.id.secHist
    )

    val semuaTombolBagian = listOf(
        R.id.btnSecFiles, R.id.btnSecFmt, R.id.btnSecCut, R.id.btnSecVol, R.id.btnSecClean,
        R.id.btnSecFx, R.id.btnSecFade, R.id.btnSecTag, R.id.btnSecSave, R.id.btnSecRec, R.id.btnSecHist
    )

    val daftar: List<Def> = listOf(
        Def("potong_lanjut", "Potong Lanjutan", "\u2702",
            "Potong sambil mendengarkan: putar berkas, tandai awal dan akhir, lalu simpan atau buang bagian itu. Bisa juga mengisi waktu mulai dan sampai, atau menghapus bagian tengah.",
            grup = listOf(R.id.gPotongDengar, R.id.gTrim, R.id.gCutMid, R.id.gFormat)),
        Def("potong", "Potong Sederhana", "\u2702",
            "Isi waktu mulai dan sampai, lalu tekan Mulai konversi.",
            grup = listOf(R.id.gTrim, R.id.gFormat)),
        Def("hapus_tengah", "Hapus Bagian Tengah", "\u2194",
            "Buang satu bagian di tengah berkas; sisanya disambung.",
            grup = listOf(R.id.gCutMid, R.id.gFormat)),
        Def("campur", "MIX", "\u21C5",
            "Tumpuk dua berkas atau lebih agar terdengar bersamaan, misalnya suara dan musik latar. Pilih minimal dua berkas; berkas pertama jadi suara utama.",
            grup = listOf(R.id.gSamakan, R.id.gFormat), campur = true),
        Def("tag", "Tag Editor", "\u270E",
            "Isi judul, artis, album, tahun, genre, nomor lagu, komentar, dan gambar sampul pada hasil.",
            grup = listOf(R.id.secTag, R.id.gFormat)),
        Def("gabung", "Gabung (Merge)", "\u2295",
            "Sambung dua berkas atau lebih jadi satu, sesuai urutan di daftar. Pilih minimal dua berkas.",
            grup = listOf(R.id.gSamakan, R.id.gFormat), gabung = true),
        Def("konversi", "Konversi", "\u21C4",
            "Ubah berkas audio atau video ke MP3, M4A, FLAC, atau WAV. Boleh memilih banyak berkas sekaligus.",
            grup = listOf(R.id.gFormat)),
        Def("kompres", "Kompres", "\u21CA",
            "Perkecil ukuran berkas: pilih MP3 atau M4A dengan kualitas (kbps) lebih rendah. Untuk ucapan, 64 sampai 96 kbps sudah cukup jelas.",
            grup = listOf(R.id.gFormat)),
        Def("splitter", "Splitter Sederhana", "\u00F7",
            "Bagi hasil jadi beberapa bagian dengan lama sama, dari 1 sampai 30 menit.",
            grup = listOf(R.id.gSplit, R.id.gFormat)),
        Def("splitter_lanjut", "Splitter Lanjutan", "\u00F7",
            "Bagi hasil di titik waktu yang Anda isi, misalnya 1:30, 4:05, 10:00. Tiga titik waktu menghasilkan empat bagian. Waktu dihitung pada hasil akhir, sesudah potong dan efek.",
            grup = listOf(R.id.gSplitAt, R.id.gFormat)),
        Def("channel", "Manipulasi Channel", "\u25D0",
            "Ubah kanal (mono atau stereo) dan laju sampel.",
            grup = listOf(R.id.gFormat, R.id.gChannel)),
        Def("hening", "Penghapus Keheningan", "\u22EF",
            "Buang hening di awal dan akhir, atau pendekkan jeda panjang di tengah rekaman.",
            grup = listOf(R.id.gSilEdge, R.id.gSilMid, R.id.gFormat)),
        Def("efek", "Efek", "\u2726",
            "Gema dan ruang, pengubah suara ringan, balik audio, ulangi hasil, serta fade masuk dan keluar.",
            grup = listOf(R.id.gEcho, R.id.gVoice, R.id.gReverse, R.id.gLoops, R.id.gFade, R.id.gFormat)),
        Def("equalizer", "Equalizer", "\u2261",
            "Atur bass, treble, dan ekualiser lima pita.",
            grup = listOf(R.id.gBassTreble, R.id.gEq, R.id.gFormat)),
        Def("normalkan", "Normalkan", "\u00B1",
            "Ratakan volume dan atur penguat dalam dB.",
            grup = listOf(R.id.gNormal, R.id.gFormat)),
        Def("mastering", "Sound Mastering", "\u2605",
            "Normalisasi, kompresor dinamika, dan pengeras volume aman sampai 400 persen tanpa suara pecah.",
            grup = listOf(R.id.gNormal, R.id.gComp, R.id.gLoud, R.id.gFormat)),
        Def("pembersih", "Penghapus Noise Audio", "\u2727",
            "Hapus desis latar dan buang dengung rendah.",
            grup = listOf(R.id.secClean, R.id.gFormat)),
        Def("ubah_suara", "Pengubah Suara", "\u263A", tujuan = com.novan.audiolabnovan.ubah.PengubahSuaraActivity::class.java),
        Def("autotune", "Vocal AutoTuner", "\u266D", tujuan = com.novan.audiolabnovan.autotune.VocalAutoTunerActivity::class.java),
        Def("tambah_sfx", "Tambah SFX", "\u2733", tujuan = com.novan.audiolabnovan.sfx.TambahSfxActivity::class.java),
        Def("kecepatan", "Pengubah Kecepatan", "\u00BB",
            "Ubah kecepatan putar 0,5 sampai 2 kali, atau ubah nada tanpa mengubah durasi.",
            grup = listOf(R.id.gSpeed, R.id.gPitch, R.id.gFormat)),
        Def("audio8d", "Audio 8D", "8D",
            "Suara berputar kiri kanan. Pakai headphone.",
            grup = listOf(R.id.gSpasial, R.id.gFormat)),
        Def("hapus_echo", "Penghapus Echo", "\u224B",
            "Kurangi gema ruang pada rekaman suara.",
            grup = listOf(R.id.gDeEcho, R.id.gFormat)),
        Def("balik", "Balik (Reverse)", "\u21BA",
            "Putar audio dari belakang ke depan.",
            grup = listOf(R.id.gReverse, R.id.gFormat)),
        Def("booster", "Volume Booster", "\u25B2",
            "Keraskan suara sampai 400 persen tanpa pecah.",
            grup = listOf(R.id.gLoud, R.id.gFormat)),
        Def("kurangi_vokal", "Kurangi Vokal", "\u266A",
            "Kurangi suara penyanyi asli pada lagu stereo (minus one) untuk karaoke.",
            grup = listOf(R.id.gVocalCut, R.id.gFormat)),
        Def("nada_dering", "Nada Dering", "\u266C",
            "Potong bagian lagu, beri fade, lalu jadikan nada dering, notifikasi, atau alarm (Android 10 ke atas).",
            grup = listOf(R.id.gTrim, R.id.gFade, R.id.gRing, R.id.gFormat)),
        Def("rekam", "Rekam", "\u25CF",
            "Rekam dari mikrofon atau suara internal ponsel. Hasilnya langsung jadi berkas terpilih.",
            grup = listOf(R.id.secRec, R.id.gFormat), rekam = true),
        Def("karaoke", "Karaoke", "\u266B", tujuan = com.novan.audiolabnovan.karaoke.KaraokeActivity::class.java),
        Def("teks_suara", "Teks ke Suara", "\u00B6", tujuan = com.novan.audiolabnovan.tts.TeksKeSuaraActivity::class.java),
        Def("gemini", "Voice Note Gemini", "\u2709", tujuan = com.novan.audiolabnovan.gemini.GeminiSuaraActivity::class.java),
        Def("audio_video", "Audio ke Video", "\u25B6", tujuan = com.novan.audiolabnovan.video.AudioKeVideoActivity::class.java),
        Def("alat_video", "Alat Video", "\u25A6", tujuan = com.novan.audiolabnovan.video.VideoBerandaActivity::class.java),
        Def("editor_video", "Editor Video (VideoLab)", "\u25B6", tujuan = com.novan.audiolabnovan.videolab.VideoLabBerandaActivity::class.java),
        Def("key_bpm", "Pencari Key dan BPM", "\u266F", tujuan = com.novan.audiolabnovan.kunci.KeyBpmActivity::class.java),
        Def("info_media", "Info Media Audio", "\u24D8", tujuan = com.novan.audiolabnovan.info.InfoMediaActivity::class.java),
        Def("riwayat", "Riwayat Konversi", "\u21BA",
            "Baca atau hapus daftar 20 konversi terakhir.",
            grup = listOf(R.id.secHist), tanpaBerkas = true),
        Def(SEMUA, "Semua Pengaturan", "\u2699")
    )

    fun cari(id: String?): Def? = daftar.firstOrNull { it.id == id }
}
