# -*- coding: utf-8 -*-
"""
Novan Tel - penerap editan pada kode sumber Telegram Android resmi (DrKLO/Telegram).

Dipanggil oleh bangun.py. Setiap langkah mencatat hasil ke daftar laporan:
  OK    = berhasil diterapkan
  LEWAT = tidak ditemukan / tidak perlu (build tetap jalan)
  GAGAL = fatal, build dihentikan
Semua pola dibuat longgar karena struktur kode Telegram bisa berubah antar versi.
"""
import json
import os
import re
from pathlib import Path

LAPORAN = []


def catat(status, teks):
    LAPORAN.append((status, teks))
    print("[%s] %s" % (status, teks), flush=True)


class Fatal(Exception):
    pass


def baca(p):
    return Path(p).read_text(encoding="utf-8", errors="replace")


def tulis(p, s):
    Path(p).write_text(s, encoding="utf-8")


def cari(root, pola_nama, abaikan=("build", ".git", ".gradle", "node_modules")):
    hasil = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in abaikan]
        for f in fn:
            if re.fullmatch(pola_nama, f):
                hasil.append(Path(dp) / f)
    return sorted(hasil)


def bool_str(v):
    return "true" if str(v).strip().lower() in ("1", "true", "ya", "yes", "y", "on") else "false"


# ---------------------------------------------------------------- 1. kredensial API
def terapkan_kredensial(up, cfg):
    api_id = str(cfg["api_id"]).strip()
    api_hash = str(cfg["api_hash"]).strip()
    berkas = cari(up, r"BuildVars\.java")
    if not berkas:
        raise Fatal("BuildVars.java tidak ditemukan di kode Telegram. Struktur kode berubah.")
    bv = berkas[0]
    s = baca(bv)
    s, n1 = re.subn(r"(\bAPP_ID\s*=\s*)[^;]+;", lambda m: m.group(1) + api_id + ";", s, count=1)
    s, n2 = re.subn(r'(\bAPP_HASH\s*=\s*)[^;]+;', lambda m: m.group(1) + '"' + api_hash + '";', s, count=1)
    if not n1 or not n2:
        raise Fatal("APP_ID/APP_HASH tidak ditemukan di %s (APP_ID=%d, APP_HASH=%d)." % (bv, n1, n2))
    tulis(bv, s)
    catat("OK", "api_id %s dan api_hash (disembunyikan) dipasang di %s" % (api_id, bv.relative_to(up)))


# ---------------------------------------------------------------- 2. applicationId dan nama
def terapkan_identitas(up, cfg):
    baru = cfg["application_id"].strip()
    total = 0
    for g in cari(up, r"build\.gradle(\.kts)?"):
        s = baca(g)
        s2, n = re.subn(r"""(\bapplicationId\s*=?\s*)(["'])[^"']+\2""",
                        lambda m: m.group(1) + m.group(2) + baru + m.group(2), s)
        if n:
            tulis(g, s2)
            total += n
            catat("OK", "applicationId diganti jadi %s di %s (%d tempat)" % (baru, g.relative_to(up), n))
    # Telegram resmi mengambil nama paket dari APP_PACKAGE di gradle.properties (bukan string di build.gradle)
    for gp in (Path(up) / "gradle.properties",):
        if gp.is_file():
            sp = baca(gp)
            sp2, k = re.subn(r"(?m)^(\s*APP_PACKAGE\s*=\s*).*$", lambda m: m.group(1) + baru, sp)
            if k:
                tulis(gp, sp2)
                total += k
                catat("OK", "APP_PACKAGE diganti jadi %s di gradle.properties" % baru)
    if not total:
        catat("LEWAT", "Tidak ada baris applicationId ditemukan; paket aplikasi tetap bawaan.")

    # izin/otoritas yang ditulis mati dengan nama paket resmi di manifest
    jumlah = 0
    for m in cari(up, r"AndroidManifest\.xml"):
        s = baca(m)
        s2 = re.sub(r"org\.telegram\.messenger(?:\.web|\.beta)?\.permission\.", "${applicationId}.permission.", s)
        s2 = re.sub(r'(android:authorities=")org\.telegram\.messenger(?:\.web|\.beta)?(\.[A-Za-z_.]+")',
                    r"\1${applicationId}\2", s2)
        if s2 != s:
            tulis(m, s2)
            jumlah += 1
    catat("OK" if jumlah else "LEWAT", "Manifest: nama izin/otoritas bawaan disesuaikan di %d berkas" % jumlah)

    nama = cfg["nama_aplikasi"].strip()
    n_str = 0
    for sx in cari(up, r"strings[\w-]*\.xml"):
        s = baca(sx)
        s2 = re.sub(r'(<string\s+name="AppName"[^>]*>)[^<]*(</string>)', lambda m: m.group(1) + nama + m.group(2), s)
        s2 = re.sub(r'(<string\s+name="AppNameBeta"[^>]*>)[^<]*(</string>)', lambda m: m.group(1) + nama + " Beta" + m.group(2), s2)
        if s2 != s:
            tulis(sx, s2)
            n_str += 1
    catat("OK" if n_str else "LEWAT", "Nama aplikasi '%s' dipasang di %d berkas strings" % (nama, n_str))


# ---------------------------------------------------------------- 2b. nomor versi aplikasi
def terapkan_versi(up, cfg):
    """Nama versi dan kode versi aplikasi (supaya APK baru bisa menimpa yang lama, kode harus lebih besar)."""
    nama = str(cfg.get("versi_nama", "13.2.5")).strip()
    kode = str(cfg.get("versi_kode", "130205")).strip()
    if not re.fullmatch(r"\d+(\.\d+){1,3}", nama) or not re.fullmatch(r"\d{1,9}", kode):
        catat("LEWAT", "versi_nama='%s' atau versi_kode='%s' tidak valid; versi bawaan Telegram dipakai" % (nama, kode))
        return
    total = 0
    for bv in cari(up, r"BuildVars\.java"):
        s = baca(bv)
        s, a = re.subn(r"(\bBUILD_VERSION\s*=\s*)\d+\s*;", lambda m: m.group(1) + kode + ";", s)
        s, b = re.subn(r'(\bBUILD_VERSION_STRING\s*=\s*)"[^"]*"\s*;', lambda m: m.group(1) + '"' + nama + '";', s)
        if a or b:
            tulis(bv, s)
            total += a + b
            catat("OK", "Versi di %s: BUILD_VERSION=%s (%d), BUILD_VERSION_STRING=%s (%d)" % (bv.relative_to(up), kode, a, nama, b))
    for gp in (Path(up) / "gradle.properties",):
        if gp.is_file():
            s = baca(gp)
            s, a = re.subn(r"(?m)^(\s*APP_VERSION_NAME\s*=\s*).*$", lambda m: m.group(1) + nama, s)
            s, b = re.subn(r"(?m)^(\s*APP_VERSION_CODE\s*=\s*).*$", lambda m: m.group(1) + kode, s)
            if a or b:
                tulis(gp, s)
                total += a + b
                catat("OK", "Versi di gradle.properties: APP_VERSION_NAME (%d), APP_VERSION_CODE (%d)" % (a, b))
    for g in cari(up, r"build\.gradle(\.kts)?"):
        s = baca(g)
        s, a = re.subn(r"""(\bversionName\s*=?\s*)(["'])[^"']*\2""", lambda m: m.group(1) + m.group(2) + nama + m.group(2), s)
        s, b = re.subn(r"(\bversionCode\s*=?\s*)\d+", lambda m: m.group(1) + kode, s)
        if a or b:
            tulis(g, s)
            total += a + b
            catat("OK", "Versi di %s: versionName (%d), versionCode (%d)" % (g.relative_to(up), a, b))
    if not total:
        catat("LEWAT", "Tidak ada penanda versi ditemukan; versi aplikasi tetap bawaan Telegram")
    else:
        catat("OK", "Versi aplikasi: %s (kode %s)" % (nama, kode))

# ---------------------------------------------------------------- 3. google-services tiruan
def terapkan_google_services(up, cfg):
    baru = cfg["application_id"].strip()
    paket = []
    for p in (baru, baru + ".beta", baru + ".web", "org.telegram.messenger",
              "org.telegram.messenger.beta", "org.telegram.messenger.web"):
        if p not in paket:
            paket.append(p)
    klien = []
    for i, p in enumerate(paket):
        klien.append({
            "client_info": {
                "mobilesdk_app_id": "1:000000000000:android:%016x" % (0x1000 + i),
                "android_client_info": {"package_name": p},
            },
            "oauth_client": [],
            "api_key": [{"current_key": "AIzaSyD0000000000000000000000000000000"}],
            "services": {"appinvite_service": {"other_platform_oauth_client": []}},
        })
    data = {
        "project_info": {
            "project_number": "000000000000",
            "project_id": "novan-tel-tiruan",
            "storage_bucket": "novan-tel-tiruan.appspot.com",
        },
        "client": klien,
        "configuration_version": "1",
    }
    teks = json.dumps(data, indent=2)
    tujuan = set()
    for g in cari(up, r"google-services\.json"):
        tujuan.add(g.parent)
    for g in cari(up, r"build\.gradle(\.kts)?"):
        s = baca(g)
        if "google-services" in s:
            tujuan.add(g.parent)
    # modul aplikasi (com.android.application) juga wajib punya berkas
    for g in cari(up, r"build\.gradle(\.kts)?"):
        if "com.android.application" in baca(g):
            tujuan.add(g.parent)
    tujuan.add(Path(up))
    for d in sorted(tujuan):
        tulis(d / "google-services.json", teks)
    catat("OK", "google-services.json tiruan dipasang di %d folder (notifikasi memakai koneksi latar, bukan FCM)" % len(tujuan))


# ---------------------------------------------------------------- 4. kelas NovanMod + kait
def daftar_model(cfg, kunci, bawaan):
    """Daftar nama model dipisah koma dari properti; hanya karakter nama model yang aman (masuk ke string Java)."""
    nilai = str(cfg.get(kunci, "") or "").strip() or bawaan
    bagian = [b.strip() for b in nilai.split(",") if re.fullmatch(r"[A-Za-z0-9._/:-]+", b.strip())]
    return ",".join(bagian) if bagian else bawaan


def terapkan_novanmod(up, cfg, overlay):
    cm = cari(up, r"ConnectionsManager\.java")
    cm = [c for c in cm if "tgnet" in c.parts]
    if not cm:
        raise Fatal("ConnectionsManager.java tidak ditemukan; titik editan tidak bisa dipasang.")
    cm = cm[0]
    # akar sumber = folder tepat di atas org/
    parts = cm.parts
    idx = len(parts) - 1 - list(reversed(parts)).index("org")
    akar = Path(*parts[:idx])
    tujuan_dir = akar / "org" / "telegram" / "messenger"
    tujuan_dir.mkdir(parents=True, exist_ok=True)

    src = baca(Path(overlay) / "NovanMod.java")
    peta = {
        "__HANTU_BACA__": cfg["hantu_baca"], "__HANTU_MENGETIK__": cfg["hantu_mengetik"],
        "__HANTU_ONLINE__": cfg["hantu_online"], "__HANTU_CERITA__": cfg["hantu_cerita"],
        "__HANTU_KONTEN__": cfg["hantu_konten"], "__BLOKIR_IKLAN__": cfg["blokir_iklan"],
    }
    for k, v in peta.items():
        src = src.replace(k, bool_str(v))
    src = src.replace("__ANTI_HAPUS__", bool_str(cfg.get("anti_hapus", "true")))
    src = src.replace("__UNDUH_SUARA__", bool_str(cfg.get("unduh_suara", "true")))
    src = src.replace("__SIMPAN_UNDUHAN__", bool_str(cfg.get("simpan_unduhan", "true")))
    src = src.replace("__SIMPAN_BANYAK__", bool_str(cfg.get("simpan_banyak", "true")))
    src = src.replace("__TOMBOL_KE_PESAN__", bool_str(cfg.get("tombol_ke_pesan", "true")))
    src = src.replace("__FOLDER_UNDUHAN__", nama_folder(cfg))
    src = src.replace("__TERUSKAN_TANPA_KUTIPAN__", bool_str(cfg.get("teruskan_tanpa_kutipan", "true")))
    src = src.replace("__SALIN_SEBAGIAN__", bool_str(cfg.get("salin_sebagian", "true")))
    src = src.replace("__KUALITAS_SUARA__", nama_kualitas(cfg))
    src = src.replace("__EFEK_SUARA__", bool_str(cfg.get("efek_suara", "true")))
    src = src.replace("__TRANSKRIPSI__", bool_str(cfg.get("transkripsi", "true")))
    tulis(tujuan_dir / "NovanMod.java", src)
    trans = Path(overlay) / "NovanTranskripsi.java"
    if trans.is_file():
        ts = baca(trans)
        ts = ts.replace("__MODEL_SUARA__", daftar_model(cfg, "transkripsi_model_suara", "whisper-large-v3,whisper-large-v3-turbo"))
        ts = ts.replace("__MODEL_CHAT__", daftar_model(cfg, "transkripsi_model_chat", "qwen/qwen3.8-27b,openai/gpt-oss-120b,openai/gpt-oss-20b"))
        tulis(tujuan_dir / "NovanTranskripsi.java", ts)
        catat("OK", "NovanTranskripsi.java dipasang di %s" % (tujuan_dir / "NovanTranskripsi.java").relative_to(up))
    else:
        raise Fatal("overlay/NovanTranskripsi.java tidak ada.")
    layar = Path(overlay) / "NovanPengaturanActivity.java"
    if layar.is_file():
        tulis(tujuan_dir / "NovanPengaturanActivity.java", baca(layar))
        catat("OK", "NovanPengaturanActivity.java dipasang di %s" % (tujuan_dir / "NovanPengaturanActivity.java").relative_to(up))
    efek = Path(overlay) / "NovanEfek.java"
    if efek.is_file():
        tulis(tujuan_dir / "NovanEfek.java", baca(efek))
        catat("OK", "NovanEfek.java dipasang di %s" % (tujuan_dir / "NovanEfek.java").relative_to(up))
    elif bool_str(cfg.get("efek_suara", "true")) == "true":
        raise Fatal("overlay/NovanEfek.java tidak ada padahal efek_suara=true.")
    kat = Path(overlay) / "NovanKategori.java"
    if not kat.is_file():
        raise Fatal("overlay/NovanKategori.java tidak ada.")
    ks = baca(kat).replace("__KATEGORI_UTAMA__", bool_str(cfg.get("kategori_utama", "true")))
    tulis(tujuan_dir / "NovanKategori.java", ks)
    catat("OK", "NovanKategori.java dipasang di %s (kategori_utama=%s)" % ((tujuan_dir / "NovanKategori.java").relative_to(up), bool_str(cfg.get("kategori_utama", "true"))))
    catat("OK", "NovanMod.java dipasang di %s" % (tujuan_dir / "NovanMod.java").relative_to(up))

    s = baca(cm)
    if "NovanMod.blokir" in s:
        catat("LEWAT", "Kait ConnectionsManager sudah ada")
        return
    pola = re.compile(r"(public\s+(?:<[^>(]*>\s*)?(?:final\s+)?int\s+sendRequest(?:Typed|Tmp)?\s*\((?P<p>[^)]*)\)\s*(?:throws[^{]*)?\{)", re.S)
    jumlah = [0]

    def ganti(m):
        mm = re.search(r"(?:TLObject|TLMethod\s*<[^>]*>)\s+(\w+)", m.group("p"))
        if not mm:
            return m.group(0)
        jumlah[0] += 1
        return m.group(1) + "\n        if (org.telegram.messenger.NovanMod.blokir(%s)) { return 0; }" % mm.group(1)

    s2 = pola.sub(ganti, s)
    if not jumlah[0]:
        catat("LEWAT", "Metode sendRequest tidak ditemukan; mode hantu dan blokir iklan TIDAK aktif")
        return
    tulis(cm, s2)
    catat("OK", "Kait NovanMod dipasang di %d metode sendRequest" % jumlah[0])


# ---------------------------------------------------------------- 5. pilih arsitektur
ABI_PETA = {
    "semua": ["armeabi-v7a", "arm64-v8a"],
    "arm64": ["arm64-v8a"],
    "arm32": ["armeabi-v7a"],
}


def _saring_abi(sisa, boleh):
    """Pertahankan hanya ABI yang diinginkan pada sisa baris abiFilters, menyusun ulang daftar
    supaya tidak pernah menyisakan koma berlebih (koma di ujung baris merusak sintaks Groovy)."""
    token = list(re.finditer(r"""(["'])([\w-]+)\1""", sisa))
    if not token:
        return sisa
    simpan = [t for t in token if t.group(2) in boleh]
    if not simpan:
        return sisa
    baru = ", ".join(t.group(0) for t in simpan)
    return sisa[:token[0].start()] + baru + sisa[token[-1].end():]


def terapkan_arm_saja(up, cfg):
    arsitektur = str(cfg.get("arsitektur", "semua")).strip().lower()
    if arsitektur not in ABI_PETA:
        arsitektur = "semua"
    if bool_str(cfg.get("hanya_arm", "true")) != "true" and arsitektur == "semua":
        catat("LEWAT", "hanya_arm=false: semua arsitektur dibangun")
        return
    boleh = ABI_PETA[arsitektur]
    ubah = 0
    for g in cari(up, r"build\.gradle(\.kts)?"):
        baris = baca(g).split("\n")
        berubah = False
        for i, b in enumerate(baris):
            m = re.search(r"abiFilters(?!\w)(.*)$", b)
            if not m or m.group(1).lstrip().startswith("."):
                continue
            nama = re.findall(r"""["']([\w-]+)["']""", m.group(1))
            if not nama or all(n in boleh for n in nama):
                continue
            if not any(n in boleh for n in nama):
                continue  # tidak ada yang cocok: biarkan (jangan jadi kosong = semua arsitektur)
            baris[i] = b[:m.start(1)] + _saring_abi(m.group(1), boleh)
            berubah = True
            ubah += 1
        if berubah:
            tulis(g, "\n".join(baris))
    catat("OK" if ubah else "LEWAT", "Arsitektur '%s' (%s): abiFilters diubah di %d baris" % (arsitektur, ", ".join(boleh), ubah))


# ---------------------------------------------------------------- 6. kualitas pesan suara
KUALITAS_SUARA = {
    "terendah": 18000,  # paling kecil, audio/ogg (Opus) 18 kb/s (pilihan di Pengaturan Novan Tel)
    "hemat": 32000,    # terendah, audio/ogg (Opus) 32 kb/s (bawaan Novan Tel)
    "sedang": 48000,
    "tinggi": 64000,
}


def nama_kualitas(cfg):
    n = str(cfg.get("kualitas_suara", "hemat")).strip().lower()
    return n if n in KUALITAS_SUARA or n == "asli" else "hemat"


def _kurung_seimbang(s, buka):
    """Indeks kurung tutup yang berpasangan dengan kurung buka di posisi 'buka' (-1 bila tidak ada)."""
    d = 0
    for n in range(buka, len(s)):
        if s[n] == "(":
            d += 1
        elif s[n] == ")":
            d -= 1
            if d == 0:
                return n
    return -1


def _kurawal_seimbang(s, buka):
    d = 0
    for n in range(buka, len(s)):
        if s[n] == "{":
            d += 1
        elif s[n] == "}":
            d -= 1
            if d == 0:
                return n
    return -1


def _berkas_perekam(up):
    """Berkas C/C++ milik Telegram (bukan pustaka Opus) yang membuat pengode Opus untuk merekam suara."""
    hasil = []
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in ("build", ".git", ".gradle", "node_modules", "opus", "libopus")]
        for f in fn:
            if not f.lower().endswith((".c", ".cc", ".cpp")):
                continue
            p = Path(dp) / f
            try:
                if p.stat().st_size > 2_000_000:
                    continue
                if "opus_encoder_create" in baca(p):
                    hasil.append(p)
            except OSError:
                continue
    return sorted(hasil)[:3]


PEMBANTU_C = """
/* novan-kualitas-suara: bitrate dibaca dari variabel lingkungan NOVAN_BITRATE (diatur dari Pengaturan Novan Tel) */
#include <stdlib.h>
#include <string.h>
static int novan_bitrate_env(int asli, int bawaan) {
    const char *e = getenv("NOVAN_BITRATE");
    if (e == NULL || e[0] == 0) { return bawaan; }
    if (strcmp(e, "asli") == 0) { return asli; }
    {
        int v = atoi(e);
        if (v >= 6000 && v <= 64000) { return v; }
    }
    return bawaan;
}
"""


def _sisip_pembantu(s):
    """Taruh fungsi pembantu di paling atas berkas, supaya sudah dikenal sebelum dipakai.
    (Versi lama menaruhnya setelah #include terakhir; di audio.c itu ada di tengah berkas, setelah
    pemakaian pertama, sehingga kompiler mengira fungsinya non-static dan galat 'static declaration follows
    non-static declaration'.)"""
    return PEMBANTU_C.lstrip("\n") + "\n" + s


def terapkan_kualitas_suara(up, cfg):
    nama = str(cfg.get("kualitas_suara", "hemat")).strip().lower()
    if nama not in KUALITAS_SUARA and nama != "asli":
        catat("LEWAT", "kualitas_suara='%s' tidak dikenal (pilih terendah/hemat/sedang/tinggi/asli); memakai hemat" % nama)
        nama = "hemat"
    bawaan = KUALITAS_SUARA.get(nama, 32000)
    berkas = _berkas_perekam(up)
    if not berkas:
        catat("LEWAT", "Kode perekam suara (opus_encoder_create) tidak ditemukan; kualitas pesan suara TIDAK diubah")
        return
    diubah = 0
    for p in berkas:
        s = baca(p)
        rel = p.relative_to(up)
        if "novan-kualitas-suara" in s:
            catat("LEWAT", "Kualitas suara sudah ditambal di %s" % rel)
            continue
        n_ganti = 0
        # 1) bila sudah ada OPUS_SET_BITRATE(...), bungkus nilainya
        hasil, pos = [], 0
        for m in re.finditer(r"OPUS_SET_BITRATE\s*\(", s):
            tutup = _kurung_seimbang(s, m.end() - 1)
            if tutup < 0 or m.start() < pos:
                continue
            asli = s[m.end():tutup].strip()
            hasil.append(s[pos:m.start()])
            hasil.append("OPUS_SET_BITRATE(novan_bitrate_env(%s, %d))" % (asli, bawaan))
            pos = tutup + 1
            n_ganti += 1
        hasil.append(s[pos:])
        s2 = "".join(hasil)
        # 2) bila belum ada, sisipkan tepat setelah pembuatan pengode
        if not n_ganti:
            pola = re.compile(r"((\w+)\s*=\s*opus_encoder_create\s*\([^;]*\)\s*;)")

            def sisip(m):
                v = m.group(2)
                return (m.group(1) + "\n    if (%s != NULL) { opus_encoder_ctl(%s, OPUS_SET_BITRATE(novan_bitrate_env(OPUS_AUTO, %d))); }"
                        % (v, v, bawaan))
            s2, n_ganti = pola.subn(sisip, s2)
        if n_ganti:
            s2 = _sisip_pembantu(s2)
            tulis(p, s2)
            diubah += n_ganti
            catat("OK", "Kualitas pesan suara dapat dipilih (bawaan '%s', %d bps) lewat Pengaturan Novan Tel; dipasang di %s (%d tempat)"
                  % (nama, bawaan, rel, n_ganti))
        else:
            catat("LEWAT", "Pola pengode Opus tidak cocok di %s; kualitas pesan suara tidak diubah" % rel)
    if not diubah:
        catat("LEWAT", "Kualitas pesan suara TIDAK berubah")


# ---------------------------------------------------------------- 6a. efek pesan suara (gema, pengubah suara)
_NATIVE_REKAM = re.compile(
    r"(?P<mods>(?:\b(?:public|private|protected|static|final|synchronized)\s+)*)native\s+"
    r"(?:(?:static|final|synchronized)\s+)*(?P<ret>[\w.<>\[\]]+)\s+(?P<nama>writeFrame|startRecord|stopRecord)\s*"
    r"\((?P<par>[^)]*)\)\s*;")


def _nama_param(par):
    """[(tipe, nama), ...] dari daftar parameter Java sederhana."""
    hasil = []
    for bagian in [x.strip() for x in par.split(",") if x.strip()]:
        bagian = re.sub(r"\bfinal\s+", "", bagian)
        t = bagian.split()
        if len(t) < 2:
            return None
        hasil.append((" ".join(t[:-1]), t[-1]))
    return hasil


def _matikan_efek_di_novanmod(up):
    """Tambalan gagal: sembunyikan bagian efek dari layar Pengaturan Novan Tel (kunci EFEK_SUARA jadi false)."""
    for f in cari(up, r"NovanMod\.java"):
        t = baca(f)
        if "EFEK_SUARA = true;" in t:
            tulis(f, t.replace("EFEK_SUARA = true;", "EFEK_SUARA = false;"))


def terapkan_efek_suara(up, cfg):
    """Pasang pembungkus startRecord / writeFrame / stopRecord di MediaController agar PCM rekaman suara
    melewati NovanEfek (gema dan pengubah suara) sebelum dikodekan Opus. Pustaka native tidak berubah."""
    if bool_str(cfg.get("efek_suara", "true")) != "true":
        catat("LEWAT", "efek_suara=false: efek pesan suara tidak dipasang")
        _matikan_efek_di_novanmod(up)
        return
    berkas = [b for b in cari(up, r"MediaController\.java") if "messenger" in b.parts]
    if not berkas:
        catat("LEWAT", "MediaController.java tidak ditemukan; efek pesan suara TIDAK dipasang")
        _matikan_efek_di_novanmod(up)
        return
    f = berkas[0]
    s = baca(f)
    if "novan-efek-suara" in s:
        catat("LEWAT", "Efek pesan suara sudah terpasang di %s" % f.relative_to(up))
        return
    dekl = {}
    for m in _NATIVE_REKAM.finditer(s):
        dekl.setdefault(m.group("nama"), m)
    if "writeFrame" not in dekl or "startRecord" not in dekl:
        catat("LEWAT", "Deklarasi native writeFrame/startRecord tidak cocok di %s; efek pesan suara TIDAK dipasang" % f.relative_to(up))
        _matikan_efek_di_novanmod(up)
        return
    pw = _nama_param(dekl["writeFrame"].group("par"))
    ps = _nama_param(dekl["startRecord"].group("par"))
    # writeFrame wajib (ByteBuffer, int). startRecord boleh punya parameter lain (path, laju sampel, dst.).
    if not pw or len(pw) != 2 or "ByteBuffer" not in pw[0][0] or pw[1][0] != "int" or ps is None:
        catat("LEWAT", "Parameter writeFrame/startRecord tidak seperti yang diduga (%s | %s); efek pesan suara TIDAK dipasang"
              % (dekl["writeFrame"].group("par"), dekl["startRecord"].group("par")))
        _matikan_efek_di_novanmod(up)
        return
    stat_w = "static" in dekl["writeFrame"].group(0).split("native")[0]
    stat_s = "static" in dekl["startRecord"].group(0).split("native")[0]
    if stat_w != stat_s:
        catat("LEWAT", "writeFrame dan startRecord berbeda static; efek pesan suara TIDAK dipasang")
        _matikan_efek_di_novanmod(up)
        return
    # 1) ganti pemanggilan (bukan deklarasi) dengan pembungkus
    jumlah = {"writeFrame": 0, "startRecord": 0, "stopRecord": 0}
    pt = _nama_param(dekl["stopRecord"].group("par")) if "stopRecord" in dekl else None
    ada_stop = "stopRecord" in dekl and pt is not None \
        and ("static" in dekl["stopRecord"].group(0).split("native")[0]) == stat_w

    def ganti(m):
        awal_baris = s.rfind("\n", 0, m.start()) + 1
        if "native" in s[awal_baris:m.start()]:
            return m.group(0)
        if m.start() > 0 and s[m.start() - 1] == ".":
            return m.group(0)
        nama = m.group(1)
        if nama == "stopRecord" and not ada_stop:
            return m.group(0)
        jumlah[nama] += 1
        return "novan" + nama[0].upper() + nama[1:] + "("

    s2 = re.sub(r"(?<![\w$])(writeFrame|startRecord|stopRecord)\s*\(", ganti, s)
    if not jumlah["writeFrame"] or not jumlah["startRecord"]:
        catat("LEWAT", "Pemanggilan writeFrame/startRecord tidak ditemukan di %s; efek pesan suara TIDAK dipasang" % f.relative_to(up))
        _matikan_efek_di_novanmod(up)
        return
    # 2) pembungkus, ditaruh tepat setelah deklarasi native masing-masing (urut dari belakang agar posisi tetap benar)
    pos = {}
    for m in _NATIVE_REKAM.finditer(s2):
        pos.setdefault(m.group("nama"), m)
    st = "static " if stat_w else ""
    pa, pb = pw[0][1], pw[1][1]
    kode = {}
    kode["writeFrame"] = (
        "\n    /* novan-efek-suara */\n"
        "    private %sint novanWriteFrame(%s) {\n"
        "        try { org.telegram.messenger.NovanEfek.proses(%s, %s); } catch (Throwable novanE) { }\n"
        "        return writeFrame(%s, %s);\n    }\n" % (st, dekl["writeFrame"].group("par").strip(), pa, pb, pa, pb))
    ret_s = dekl["startRecord"].group("ret")
    # laju sampel = parameter int pertama startRecord (mis. sampleRate); tanpa itu dianggap 16000 Hz seperti Telegram lama
    laju = next((n for t, n in ps if t == "int"), "16000")
    kode["startRecord"] = (
        "\n    /* novan-efek-suara */\n"
        "    private %s%s novanStartRecord(%s) {\n"
        "        try { org.telegram.messenger.NovanEfek.mulai(%s); } catch (Throwable novanE) { }\n"
        "        %sstartRecord(%s);\n    }\n"
        % (st, ret_s, dekl["startRecord"].group("par").strip(), laju, "" if ret_s == "void" else "return ",
           ", ".join(n for _, n in ps)))
    if ada_stop and jumlah["stopRecord"]:
        ret_t = dekl["stopRecord"].group("ret")
        kode["stopRecord"] = (
            "\n    /* novan-efek-suara */\n"
            "    private %s%s novanStopRecord(%s) {\n"
            "        try {\n"
            "            org.telegram.messenger.NovanEfek.akhiri(new org.telegram.messenger.NovanEfek.Penulis() {\n"
            "                public void tulis(java.nio.ByteBuffer novanB, int novanN) { writeFrame(novanB, novanN); }\n"
            "            });\n"
            "        } catch (Throwable novanE) { }\n"
            "        %sstopRecord(%s);\n    }\n"
            % (st, ret_t, dekl["stopRecord"].group("par").strip(), "" if ret_t == "void" else "return ",
               ", ".join(n for _, n in pt)))
    urut = sorted(((pos[n].end(), n) for n in kode if n in pos), reverse=True)
    for akhir, n in urut:
        s2 = s2[:akhir] + kode[n] + s2[akhir:]
    tulis(f, s2)
    catat("OK", "Efek pesan suara (gema, pengubah suara, kejernihan, volume, bass) dipasang di %s: writeFrame %d, startRecord %d, stopRecord %d tempat"
          % (f.relative_to(up), jumlah["writeFrame"], jumlah["startRecord"], jumlah["stopRecord"] if "stopRecord" in kode else 0))
    if "stopRecord" not in kode:
        catat("LEWAT", "stopRecord tidak dibungkus: ekor gema di akhir rekaman bisa terpotong, efek lain tetap jalan")


# ---------------------------------------------------------------- 6a2. efek pesan suara, kait di kode C (cadangan)
PEMBANTU_EFEK_C = r"""
/* novan-efek-native: panggilan balik ke NovanEfek (Java) sebelum potongan suara dikodekan Opus */
#include <jni.h>
static jclass novan_efek_cls = NULL;
static jmethodID novan_efek_mid_proses = NULL;
static jmethodID novan_efek_mid_mulai = NULL;
static int novan_efek_siap(JNIEnv *env) {
    if (novan_efek_mid_proses != NULL) { return 1; }
    {
        jclass c = (*env)->FindClass(env, "org/telegram/messenger/NovanEfek");
        if (c == NULL) { (*env)->ExceptionClear(env); return 0; }
        novan_efek_cls = (jclass) (*env)->NewGlobalRef(env, c);
        novan_efek_mid_proses = (*env)->GetStaticMethodID(env, novan_efek_cls, "prosesNative", "(Ljava/nio/ByteBuffer;II)V");
        novan_efek_mid_mulai = (*env)->GetStaticMethodID(env, novan_efek_cls, "mulaiNative", "()V");
        if (novan_efek_mid_proses == NULL || novan_efek_mid_mulai == NULL) {
            (*env)->ExceptionClear(env);
            novan_efek_mid_proses = NULL;
            return 0;
        }
    }
    return 1;
}
static void novan_efek_proses(JNIEnv *env, jobject frame, jint len, jint rate) {
    if (frame == NULL || !novan_efek_siap(env)) { return; }
    (*env)->CallStaticVoidMethod(env, novan_efek_cls, novan_efek_mid_proses, frame, len, rate);
    if ((*env)->ExceptionCheck(env)) { (*env)->ExceptionClear(env); }
}
static void novan_efek_mulai(JNIEnv *env) {
    if (!novan_efek_siap(env)) { return; }
    (*env)->CallStaticVoidMethod(env, novan_efek_cls, novan_efek_mid_mulai);
    if ((*env)->ExceptionCheck(env)) { (*env)->ExceptionClear(env); }
}
"""

_JNI_FUNGSI = r"Java_org_telegram_messenger_MediaController_(?P<nama>writeFrame|startRecord)\s*\((?P<par>[^)]*)\)\s*\{"


def _nama_param_c(par):
    """[(tipe, nama), ...] dari daftar parameter C sederhana."""
    hasil = []
    for bagian in [x.strip() for x in par.split(",") if x.strip()]:
        m = re.match(r"^(.*?)([A-Za-z_]\w*)\s*$", bagian)
        if not m:
            return None
        hasil.append((m.group(1).replace("*", " ").strip(), m.group(2)))
    return hasil


def terapkan_efek_native(up, cfg):
    """Kait cadangan di audio.c: JNI writeFrame memanggil NovanEfek.prosesNative sebelum pengodean Opus. Jalur ini dipakai
    kode kualitas suara (sudah terbukti bekerja), jadi pasti terpanggil walau perekam Java berubah bentuk.
    Butuh kompilasi ulang kode native (so_jadi=false)."""
    if bool_str(cfg.get("efek_suara", "true")) != "true" or bool_str(cfg.get("efek_native", "true")) != "true":
        catat("LEWAT", "efek_native: kait efek di kode C tidak dipasang")
        return
    kandidat = []
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in ("build", ".git", ".gradle", "node_modules", "opus", "libopus", "voip", "webrtc")]
        for f in fn:
            if f.lower().endswith((".c", ".cc", ".cpp")):
                pth = Path(dp) / f
                try:
                    if pth.stat().st_size < 3_000_000 and "MediaController_writeFrame" in baca(pth):
                        kandidat.append(pth)
                except OSError:
                    continue
    if not kandidat:
        catat("LEWAT", "JNI MediaController_writeFrame tidak ditemukan di kode C; kait efek native TIDAK dipasang")
        return
    pth = sorted(kandidat)[0]
    t = baca(pth)
    rel = pth.relative_to(up)
    if "novan-efek-native" in t:
        catat("LEWAT", "Kait efek native sudah ada di %s" % rel)
        return
    # variabel laju sampel tingkat berkas (bila ada): dipakai sebagai argumen ketiga
    mlaju = re.search(r"(?m)^(?:static\s+)?(?:const\s+)?(?:opus_int32|int32_t|uint32_t|int|jint|long)\s+(rate|sampleRate|sample_rate)\s*(?:=|;)", t)
    laju = "(jint) %s" % mlaju.group(1) if mlaju else "(jint) 16000"
    hasil = {"writeFrame": 0, "startRecord": 0}

    def ganti(m):
        nama = m.group("nama")
        pr = _nama_param_c(m.group("par"))
        if not pr or len(pr) < 3:
            return m.group(0)
        env = pr[0][1]
        if nama == "writeFrame":
            if len(pr) != 4:
                return m.group(0)
            fr, ln = pr[2][1], pr[3][1]
            hasil[nama] += 1
            return m.group(0) + " novan_efek_proses(%s, %s, %s, %s); /* novan-efek-native */" % (env, fr, ln, laju)
        hasil[nama] += 1
        return m.group(0) + " novan_efek_mulai(%s); /* novan-efek-native */" % env

    t2 = re.sub(_JNI_FUNGSI, ganti, t)
    if not hasil["writeFrame"]:
        catat("LEWAT", "Tanda tangan JNI writeFrame tidak seperti yang diduga di %s; kait efek native TIDAK dipasang" % rel)
        return
    t2 = PEMBANTU_EFEK_C.lstrip("\n") + "\n" + t2
    tulis(pth, t2)
    catat("OK", "Kait efek native dipasang di %s: writeFrame %d, startRecord %d (laju sampel: %s)"
          % (rel, hasil["writeFrame"], hasil["startRecord"], laju))
    # R8/ProGuard tidak boleh membuang atau mengganti nama metode yang hanya dipanggil dari C
    aturan = [x for x in cari(up, r"proguard.*\.pro") if "build" not in x.parts]
    if aturan:
        for a in aturan[:1]:
            tt = baca(a)
            if "NovanEfek" not in tt:
                tulis(a, tt.rstrip("\n") + "\n\n# novan-efek-native\n-keep class org.telegram.messenger.NovanEfek { *; }\n")
                catat("OK", "Aturan -keep NovanEfek ditambahkan ke %s" % a.relative_to(up))
    else:
        catat("LEWAT", "Berkas proguard tidak ditemukan; NovanEfek mungkin diubah namanya oleh R8 (kait native bisa gagal)")


_NATIVE_REKAM_BARU = re.compile(
    r"native\s+(?P<ret>[\w.<>\[\]]+)\s+(?P<nama>nCreate|nWriteFrame)\s*\((?P<par>[^)]*)\)\s*;")


def terapkan_efek_java_perekam_baru(up, cfg):
    """Kait efek di Java untuk perekam suara BARU (AudioRecorderNative): nCreate dan nWriteFrame dibungkus.
    Tidak butuh kompilasi ulang kode native, jadi so_jadi=true (build cepat) tetap bisa dipakai."""
    if bool_str(cfg.get("efek_suara", "true")) != "true":
        return
    berkas = [b for b in cari(up, r"AudioRecorderNative\.java") if "recorder" in b.parts]
    if not berkas:
        catat("LEWAT", "AudioRecorderNative.java tidak ditemukan; kait Java perekam baru TIDAK dipasang")
        return
    f = berkas[0]
    s = baca(f)
    rel = f.relative_to(up)
    if "novan-efek-recorder-java" in s:
        catat("LEWAT", "Kait Java perekam baru sudah ada di %s" % rel)
        return
    dekl = {}
    for m in _NATIVE_REKAM_BARU.finditer(s):
        dekl.setdefault(m.group("nama"), m)
    if "nCreate" not in dekl or "nWriteFrame" not in dekl:
        catat("LEWAT", "Deklarasi nCreate/nWriteFrame tidak cocok di %s; kait Java perekam baru TIDAK dipasang" % rel)
        return
    pc = _nama_param(dekl["nCreate"].group("par"))
    pw = _nama_param(dekl["nWriteFrame"].group("par"))
    if not pc or not pw or len(pw) != 3 or "ByteBuffer" not in pw[1][0] or pw[2][0] != "int":
        catat("LEWAT", "Parameter nCreate/nWriteFrame tidak seperti yang diduga di %s; kait Java perekam baru TIDAK dipasang" % rel)
        return
    laju = next((n for t, n in pc if t == "int"), None)
    if not laju:
        catat("LEWAT", "Parameter laju sampel nCreate tidak ditemukan di %s; kait Java perekam baru TIDAK dipasang" % rel)
        return
    jumlah = {"nCreate": 0, "nWriteFrame": 0}

    def ganti(m):
        awal = s.rfind("\n", 0, m.start()) + 1
        if "native" in s[awal:m.start()]:
            return m.group(0)
        if m.start() > 0 and s[m.start() - 1] == ".":
            return m.group(0)
        jumlah[m.group(1)] += 1
        return "novan" + m.group(1)[0].upper() + m.group(1)[1:] + "("

    s2 = re.sub(r"(?<![\w$])(nCreate|nWriteFrame)\s*\(", ganti, s)
    if not jumlah["nWriteFrame"] or not jumlah["nCreate"]:
        catat("LEWAT", "Pemanggilan nCreate/nWriteFrame tidak ditemukan di %s (%s); kait Java perekam baru TIDAK dipasang" % (rel, jumlah))
        return
    akhir = s2.rstrip().rfind("}")
    if akhir < 0:
        catat("LEWAT", "Akhir kelas tidak ditemukan di %s; kait Java perekam baru TIDAK dipasang" % rel)
        return
    ret_c = dekl["nCreate"].group("ret")
    ret_w = dekl["nWriteFrame"].group("ret")
    kode = (
        "\n    /* novan-efek-recorder-java */\n"
        "    private static %s novanNCreate(%s) {\n"
        "        try { org.telegram.messenger.NovanEfek.mulai(%s); } catch (Throwable novanE) { }\n"
        "        return nCreate(%s);\n    }\n\n"
        "    private static %s novanNWriteFrame(%s) {\n"
        "        try { org.telegram.messenger.NovanEfek.proses(%s, %s); } catch (Throwable novanE) { }\n"
        "        return nWriteFrame(%s);\n    }\n"
        % (ret_c, dekl["nCreate"].group("par").strip(), laju, ", ".join(n for _, n in pc),
           ret_w, dekl["nWriteFrame"].group("par").strip(), pw[1][1], pw[2][1], ", ".join(n for _, n in pw)))
    s2 = s2[:akhir] + kode + s2[akhir:]
    tulis(f, s2)
    catat("OK", "Kait Java perekam baru dipasang di %s: nCreate %d, nWriteFrame %d" % (rel, jumlah["nCreate"], jumlah["nWriteFrame"]))


_JNI_REKAM_BARU = (r"Java_org_telegram_utils_recorder_audio_AudioRecorderNative_(?P<nama>nCreate|nWriteFrame)"
                   r"\s*\((?P<par>[^)]*)\)\s*\{")


def terapkan_efek_native_perekam_baru(up, cfg):
    """Kait efek di perekam suara BARU Telegram (AudioRecorderNative.nCreate / nWriteFrame di audio.c).
    nCreate menyimpan laju sampel dan memberi tanda rekaman baru; nWriteFrame mengolah PCM sebelum dikodekan Opus."""
    if bool_str(cfg.get("efek_suara", "true")) != "true" or bool_str(cfg.get("efek_native", "true")) != "true":
        return
    kandidat = []
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in ("build", ".git", ".gradle", "node_modules", "opus", "libopus", "voip", "webrtc", "third_party")]
        for f in fn:
            if f.lower().endswith((".c", ".cc", ".cpp")):
                pth = Path(dp) / f
                try:
                    if pth.stat().st_size < 3_000_000 and "AudioRecorderNative_nWriteFrame" in baca(pth):
                        kandidat.append(pth)
                except OSError:
                    continue
    if not kandidat:
        catat("LEWAT", "JNI AudioRecorderNative_nWriteFrame tidak ditemukan; kait efek perekam baru TIDAK dipasang")
        return
    pth = sorted(kandidat)[0]
    t = baca(pth)
    rel = pth.relative_to(up)
    if "novan-efek-recorder" in t:
        catat("LEWAT", "Kait efek perekam baru sudah ada di %s" % rel)
        return
    hasil = {"nCreate": 0, "nWriteFrame": 0}

    def ganti(m):
        nama = m.group("nama")
        pr = _nama_param_c(m.group("par"))
        if not pr:
            return m.group(0)
        env = pr[0][1]
        if nama == "nCreate":
            if len(pr) < 4:
                return m.group(0)
            hasil[nama] += 1
            return m.group(0) + " novan_efek_rate_rec = (int) %s; novan_efek_mulai(%s); /* novan-efek-recorder */" % (pr[3][1], env)
        if len(pr) != 5:
            return m.group(0)
        hasil[nama] += 1
        return m.group(0) + " novan_efek_proses(%s, %s, %s, (jint) novan_efek_rate_rec); /* novan-efek-recorder */" % (env, pr[3][1], pr[4][1])

    t2 = re.sub(_JNI_REKAM_BARU, ganti, t)
    if not hasil["nWriteFrame"]:
        catat("LEWAT", "Tanda tangan JNI nWriteFrame tidak seperti yang diduga di %s; kait efek perekam baru TIDAK dipasang" % rel)
        return
    kepala = ""
    if "novan_efek_siap" not in t2:
        kepala += PEMBANTU_EFEK_C.lstrip("\n") + "\n"
    kepala += "static int novan_efek_rate_rec = 48000; /* novan-efek-recorder */\n"
    tulis(pth, kepala + t2)
    catat("OK", "Kait efek perekam baru dipasang di %s: nCreate %d, nWriteFrame %d" % (rel, hasil["nCreate"], hasil["nWriteFrame"]))
    aturan = [x for x in cari(up, r"proguard.*\.pro") if "build" not in x.parts]
    for a in aturan[:1]:
        tt = baca(a)
        if "NovanEfek" not in tt:
            tulis(a, tt.rstrip("\n") + "\n\n# novan-efek-native\n-keep class org.telegram.messenger.NovanEfek { *; }\n")


# ---------------------------------------------------------------- 6b. unduh otomatis pesan suara
def terapkan_unduh_suara(up, cfg):
    """Pesan suara selalu terunduh otomatis (seperti WhatsApp), apa pun jaringan dan jenis obrolannya.
    Kait dipasang di awal metode canDownloadMedia milik DownloadController."""
    if bool_str(cfg.get("unduh_suara", "true")) != "true":
        catat("LEWAT", "unduh_suara=false: pesan suara tidak dipaksa terunduh otomatis")
        return
    berkas = [b for b in cari(up, r"DownloadController\.java") if "messenger" in b.parts]
    if not berkas:
        catat("LEWAT", "DownloadController.java tidak ditemukan; unduh otomatis pesan suara TIDAK dipasang")
        return
    b = berkas[0]
    s = baca(b)
    if "NovanMod.unduhSuara" in s:
        catat("LEWAT", "Kait unduh otomatis pesan suara sudah ada di %s" % b.relative_to(up))
        return
    jumlah = [0]

    def kait_pesan(m):
        tipe, nama = m.group("tipe"), m.group("nama")
        jumlah[0] += 1
        nilai = "1" if tipe == "int" else "true"
        return m.group(0) + "\n        if (org.telegram.messenger.NovanMod.unduhSuara(%s)) { return %s; }" % (nama, nilai)

    for jenis in (r"TLRPC\.Message", r"MessageObject"):
        pola = re.compile(r"(?:public\s+)?(?:final\s+)?(?P<tipe>int|boolean)\s+canDownloadMedia\s*\(\s*(?:final\s+)?"
                          + jenis + r"\s+(?P<nama>\w+)\s*\)\s*(?:throws[^{]*)?\{")
        s = pola.sub(kait_pesan, s)
    # metode berdasarkan jenis berkas: canDownloadMedia(int type, long size)
    if "AUTODOWNLOAD_TYPE_AUDIO" in s:
        def kait_tipe(m):
            jumlah[0] += 1
            nilai = "1" if m.group("tipe") == "int" else "true"
            return (m.group(0) + "\n        if (%s == AUTODOWNLOAD_TYPE_AUDIO && org.telegram.messenger.NovanMod.unduhSuaraAktif()) { return %s; }"
                    % (m.group("t"), nilai))
        pola = re.compile(r"(?:public\s+)?(?:final\s+)?(?P<tipe>int|boolean)\s+canDownloadMedia\s*\(\s*(?:final\s+)?int\s+(?P<t>\w+)\s*,\s*"
                          r"(?:final\s+)?(?:long|int)\s+\w+\s*\)\s*(?:throws[^{]*)?\{")
        s = pola.sub(kait_tipe, s)
    if jumlah[0]:
        tulis(b, s)
        catat("OK", "Pesan suara terunduh otomatis (semua jaringan dan obrolan); kait dipasang di %s (%d metode)"
              % (b.relative_to(up), jumlah[0]))
    else:
        catat("LEWAT", "Metode canDownloadMedia tidak cocok di %s; unduh otomatis pesan suara TIDAK dipasang"
              % b.relative_to(up))


def nama_folder(cfg):
    """Nama folder aman (tanpa karakter terlarang); bawaan Telegram Novan."""
    n = re.sub(r'[\\/:*?"<>|]', "", str(cfg.get("folder_unduhan", "Telegram Novan"))).strip()
    return n or "Telegram Novan"


# ---------------------------------------------------------------- 6c. simpan ke Unduhan (menu tekan-tahan pesan)
def terapkan_simpan_unduhan(up, cfg):
    """Tambah baris 'Simpan ke Unduhan' di menu pesan ChatActivity untuk pesan yang berkasnya sudah ada di HP.
    Dua kait: (1) createMenu menambah baris sebelum menu ditampilkan, (2) processSelectedOption menangani pilihan itu.
    Bila pola tidak cocok, tidak ada yang diubah (build tetap jalan)."""
    if bool_str(cfg.get("simpan_unduhan", "true")) != "true":
        catat("LEWAT", "simpan_unduhan=false: baris Simpan ke Unduhan tidak dipasang")
        return
    berkas = cari(up, r"ChatActivity\.java")
    berkas = [b for b in berkas if "ui" in b.parts]
    if not berkas:
        catat("LEWAT", "ChatActivity.java tidak ditemukan; baris Simpan ke Unduhan TIDAK dipasang")
        return
    b = berkas[0]
    s = baca(b)
    rel = b.relative_to(up)
    if re.search(r"NovanMod\.OPSI_SIMPAN\b", s):
        catat("LEWAT", "Kait Simpan ke Unduhan sudah ada di %s" % rel)
        return
    utama = _createmenu_utama(s)
    if not utama:
        catat("LEWAT", "createMenu utama tidak ditemukan di %s; Simpan ke Unduhan TIDAK dipasang" % rel)
        return
    awal, akhir, badan = utama
    kosong = re.search(r"if\s*\(\s*options\.isEmpty\(\)(?=\s*(?:&&|\|\||\)))", badan)
    ikon = "R.drawable.msg_download" if "msg_download" in s else "0"
    sisipan = ('if (org.telegram.messenger.NovanMod.bisaSimpan(selectedObject)) { '
               'items.add("Simpan ke Unduhan"); options.add(org.telegram.messenger.NovanMod.OPSI_SIMPAN); icons.add(%s); }\n        ' % ikon)
    badan2 = badan[:kosong.start()] + sisipan + badan[kosong.start():]
    s2 = s[:awal] + badan2 + s[akhir + 1:]
    h = re.search(r"\bvoid\s+processSelectedOption\s*\(\s*(?:final\s+)?int\s+(\w+)\s*\)\s*(?:throws[^{]*)?\{", s2)
    if not h:
        catat("LEWAT", "Metode processSelectedOption tidak ditemukan; Simpan ke Unduhan TIDAK dipasang")
        return
    kait = ("\n        if (%s == org.telegram.messenger.NovanMod.OPSI_SIMPAN) { "
            "org.telegram.messenger.NovanMod.simpanKeUnduhan(getParentActivity(), selectedObject); return; }" % h.group(1))
    s2 = s2[:h.end()] + kait + s2[h.end():]
    tulis(b, s2)
    catat("OK", "Baris 'Simpan ke Unduhan' dipasang di menu pesan (%s); muncul untuk pesan yang berkasnya sudah terunduh" % rel)


# ---------------------------------------------------------------- 6c2. simpan banyak pesan + tombol 'Menuju ke pesan' (tahap 15)
def _pasangan(s, buka):
    """Indeks penutup yang berpasangan dengan '{' atau '(' di posisi 'buka', melewati string, karakter, dan komentar."""
    pasang = {"{": "}", "(": ")"}
    o, c = s[buka], pasang[s[buka]]
    d, i, n = 0, buka, len(s)
    while i < n:
        ch = s[i]
        if ch == "/" and s[i + 1:i + 2] == "/":
            j = s.find("\n", i)
            i = n if j < 0 else j
            continue
        if ch == "/" and s[i + 1:i + 2] == "*":
            j = s.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        if ch in "\"'":
            i += 1
            while i < n and s[i] != ch:
                i += 2 if s[i] == "\\" else 1
            i += 1
            continue
        if ch == o:
            d += 1
        elif ch == c:
            d -= 1
            if d == 0:
                return i
        i += 1
    return -1


def _kedalaman(s, pos):
    """Kedalaman kurung kurawal di posisi pos (1 = tubuh kelas utama), melewati string dan komentar."""
    d, i, n = 0, 0, min(pos, len(s))
    while i < n:
        ch = s[i]
        if ch == "/" and s[i + 1:i + 2] == "/":
            j = s.find("\n", i)
            i = n if j < 0 else j
            continue
        if ch == "/" and s[i + 1:i + 2] == "*":
            j = s.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        if ch in "\"'":
            i += 1
            while i < n and s[i] != ch:
                i += 2 if s[i] == "\\" else 1
            i += 1
            continue
        if ch == "{":
            d += 1
        elif ch == "}":
            d -= 1
        i += 1
    return d


def _pisah_argumen(t):
    """Pisahkan argumen pemanggilan metode pada koma tingkat atas."""
    hasil, d, awal, i, n = [], 0, 0, 0, len(t)
    while i < n:
        ch = t[i]
        if ch in "\"'":
            i += 1
            while i < n and t[i] != ch:
                i += 2 if t[i] == "\\" else 1
        elif ch in "([{":
            d += 1
        elif ch in ")]}":
            d -= 1
        elif ch == "," and d == 0:
            hasil.append(t[awal:i].strip())
            awal = i + 1
        i += 1
    hasil.append(t[awal:].strip())
    return hasil


def _cuplikan(s, kata, maks=6):
    """Beberapa baris yang memuat kata tertentu, untuk log diagnosa saat pola tidak cocok."""
    baris = [b.strip() for b in s.splitlines() if re.search(kata, b)]
    return baris[:maks]


def _lapor_cuplikan(rel, s, kata):
    for b in _cuplikan(s, kata):
        catat("LEWAT", "  [DIAGNOSA %s] %s" % (rel.name, b[:200]))


def _penyataan_bersih(s, ls):
    """True bila baris di posisi ls bukan bagian if/else tanpa kurung kurawal (sisipan setelahnya aman)."""
    for b in reversed(s[:ls].splitlines()):
        t = b.strip()
        if not t or t.startswith("//") or t.startswith("*") or t.startswith("/*") or t.endswith("*/"):
            continue
        return t[-1] in ";{}" and not t.endswith("else")
    return False


def _ikon_res(up, kandidat):
    """Nama drawable pertama dari 'kandidat' yang benar-benar ada di res proyek Telegram, atau None."""
    res = Path(up) / "TMessagesProj" / "src" / "main" / "res"
    if not res.is_dir():
        return None
    for nama in kandidat:
        for d in res.glob("drawable*"):
            if any(d.glob(nama + ".*")):
                return nama
    return None


_IKON_TRANSKRIP = ("msg_transcribe", "msg_text", "msg_message", "msg_edit")


def terapkan_simpan_banyak(up, cfg):
    """Item 'Simpan ke Unduhan' di bilah atas ChatActivity saat memilih pesan (tekan-tahan, lalu ketuk pesan lain).
    Tiga titik di ChatActivity: item di action mode, kait klik, dan (bila ada) clearSelectionMode untuk menutup mode pilih.
    Bila salah satu pola tidak cocok, tidak ada yang diubah (build tetap jalan)."""
    if bool_str(cfg.get("simpan_banyak", "true")) != "true":
        catat("LEWAT", "simpan_banyak=false: item Simpan ke Unduhan di bilah atas tidak dipasang")
        return
    berkas = [b for b in cari(up, r"ChatActivity\.java") if "ui" in b.parts]
    if not berkas:
        catat("LEWAT", "ChatActivity.java tidak ditemukan; Simpan ke Unduhan di bilah atas TIDAK dipasang")
        return
    b = berkas[0]
    s = baca(b)
    rel = b.relative_to(up)
    if "OPSI_SIMPAN_BANYAK" in s:
        catat("LEWAT", "Kait Simpan ke Unduhan di bilah atas sudah ada di %s" % rel)
        return
    nm = "org.telegram.messenger.NovanMod"
    # (a) daftar pesan terpilih: harus kolom tingkat kelas
    mf = re.search(r"\bSparseArray\s*(?:<[^;=(){}]*>)?\s*\[\s*\]\s+selectedMessagesIds\b", s)
    if not mf or _kedalaman(s, mf.start()) != 1:
        catat("LEWAT", "Kolom selectedMessagesIds tidak ditemukan seperti dugaan di %s; Simpan ke Unduhan di bilah atas TIDAK dipasang" % rel)
        _lapor_cuplikan(rel, s, r"selectedMessagesIds\s*(=|;)")
        return
    # (b) item action mode: tiru pemanggilan addItemWithWidth milik tombol Hapus/Teruskan/Salin
    ma = None
    for nama in ("delete", "forward", "copy"):
        ma = re.search(r"(\w+)\.addItemWithWidth\s*\(\s*%s\s*," % nama, s)
        if ma:
            break
    if not ma:
        catat("LEWAT", "addItemWithWidth(delete/forward/copy, ...) tidak ditemukan di %s; Simpan ke Unduhan di bilah atas TIDAK dipasang" % rel)
        _lapor_cuplikan(rel, s, r"addItemWithWidth")
        return
    menu = ma.group(1)
    buka = s.index("(", s.index("addItemWithWidth", ma.start()))
    tutup = _pasangan(s, buka)
    argumen = _pisah_argumen(s[buka + 1:tutup]) if tutup > 0 else []
    if len(argumen) not in (3, 4):
        catat("LEWAT", "addItemWithWidth punya %d argumen (dugaan 3 atau 4); Simpan ke Unduhan di bilah atas TIDAK dipasang" % len(argumen))
        return
    ls = s.rfind("\n", 0, ma.start()) + 1
    awalan = s[ls:ma.start()].strip()
    mw = re.fullmatch(r"(?:([\w.]+)\.add\()?\s*(?:[\w.]+\s*=\s*)?", awalan)
    if not mw or not _penyataan_bersih(s, ls):
        catat("LEWAT", "Bentuk pernyataan addItemWithWidth tidak aman disisipi ('%s'); Simpan ke Unduhan di bilah atas TIDAK dipasang" % awalan[:80])
        return
    daftar = mw.group(1)
    j = tutup + 1
    while s[j:j + 1].isspace():
        j += 1
    if daftar:
        if s[j:j + 1] != ")":
            catat("LEWAT", "Penutup actionModeViews.add(...) tidak terbaca; Simpan ke Unduhan di bilah atas TIDAK dipasang")
            return
        j += 1
        while s[j:j + 1].isspace():
            j += 1
    if s[j:j + 1] != ";":
        catat("LEWAT", "Akhir pernyataan addItemWithWidth tidak terbaca; Simpan ke Unduhan di bilah atas TIDAK dipasang")
        return
    akhir_stmt = j + 1
    ikon = "R.drawable.msg_download" if "R.drawable.msg_download" in s else argumen[1]
    baru_arg = ["%s.OPSI_SIMPAN_BANYAK" % nm, ikon, argumen[2]] + (['"Simpan ke Unduhan"'] if len(argumen) == 4 else [])
    sisip_item = ("\n        { final android.view.View novanItem = %s.addItemWithWidth(%s); "
                  "novanItem.setContentDescription(\"Simpan ke Unduhan\"); %s}"
                  % (menu, ", ".join(baru_arg), ("%s.add(novanItem); " % daftar) if daftar else ""))
    kait_transkrip = ""
    kait_judul, hook_pos = "", -1
    kait_sel, mt_sel = "", []
    if bool_str(cfg.get("transkripsi", "true")) == "true":
        nama_ikon = _ikon_res(up, _IKON_TRANSKRIP)
        ikon_t = ("R.drawable.%s" % nama_ikon) if nama_ikon else argumen[1]
        arg_t = ["%s.OPSI_TRANSKRIP_ATAS" % nm, ikon_t, argumen[2]] + (['"Transkripsi"'] if len(argumen) == 4 else [])
        mt = re.search(r"\bvoid\s+updateActionModeTitle\s*\(\s*\)\s*(?:throws[^{]*)?\{", s)
        mt_sel = [m_ for m_ in re.finditer(r"\bvoid\s+addToSelectedMessages\s*\([^)]*\)\s*(?:throws[^{]*)?\{", s) if _kedalaman(s, m_.start()) == 1]
        sembunyi_awal = bool_str(cfg.get("transkripsi_atas_sembunyi", "true")) == "true" and (bool(mt) or bool(mt_sel)) and "perbaruiTranskripsiAtas" not in s
        sisip_item += ("\n        { final android.view.View novanItemT = %s.addItemWithWidth(%s); "
                       "novanItemT.setContentDescription(\"Transkripsi\"); %s%s%s.daftarItemTranskripsi(novanItemT); }"
                       % (menu, ", ".join(arg_t),
                          "",
                          ("%s.add(novanItemT); " % daftar) if daftar else "", nm))
        if sembunyi_awal:
            if mt:
                kait_judul = "\n        %s.perbaruiTranskripsiAtas(actionBar, (Object) selectedMessagesIds);" % nm
                hook_pos = mt.end()
            kait_sel = "\n        %s.jadwalPerbaruiTranskripsi(actionBar, (Object) selectedMessagesIds);" % nm
            catat("INFO", "Kait ikon Transkripsi: updateActionModeTitle=%s, addToSelectedMessages=%d tempat" % ("ya" if mt else "tidak", len(mt_sel)))
        else:
            catat("INFO", "Ikon Transkripsi di bilah atas dibiarkan selalu terlihat (transkripsi_atas_sembunyi=false, atau kait tidak ditemukan)")
        catat("INFO", "Ikon item Transkripsi di bilah atas: %s" % (("R.drawable.%s" % nama_ikon) if nama_ikon else "ikon Salin (cadangan)"))
        kait_transkrip = "TRANSKRIP"
    # (c) kait klik di penangan item ActionBar utama (yang menangani copy/forward/delete)
    kait_pos, id_nama = -1, None
    for mh in re.finditer(r"ActionBarMenuOnItemClick\s*\(\s*\)\s*\{\s*(?:@Override\s*)?public\s+void\s+onItemClick\s*\(\s*(?:final\s+)?int\s+(\w+)\s*\)\s*(?:throws[^{]*)?\{", s):
        ob = mh.end() - 1
        ot = _pasangan(s, ob)
        if ot > 0 and re.search(r"\b%s\s*==\s*(?:copy|forward|delete)\b" % mh.group(1), s[ob:ot]):
            kait_pos, id_nama = mh.end(), mh.group(1)
            break
    if kait_pos < 0:
        catat("LEWAT", "Penangan onItemClick utama ActionBar tidak ditemukan di %s; Simpan ke Unduhan di bilah atas TIDAK dipasang" % rel)
        _lapor_cuplikan(rel, s, r"ActionBarMenuOnItemClick")
        return
    tutup_mode = "clearSelectionMode(); " if re.search(r"\bvoid\s+clearSelectionMode\s*\(\s*\)", s) else ""
    kait = ("\n                if (%s == %s.OPSI_SIMPAN_BANYAK) { %s.simpanTerpilih(getParentActivity(), (Object) selectedMessagesIds); %sreturn; }"
            % (id_nama, nm, nm, tutup_mode))
    # sisipkan dari posisi paling belakang supaya indeks awal tetap benar
    if kait_transkrip:
        kait += ("\n                if (%s == %s.OPSI_TRANSKRIP_ATAS) { %s.transkripsiTerpilih(getParentActivity(), (Object) selectedMessagesIds); %sreturn; }"
                 % (id_nama, nm, nm, tutup_mode))
    daftar_sisip = [(akhir_stmt, sisip_item), (kait_pos, kait)]
    if kait_judul and hook_pos >= 0:
        daftar_sisip.append((hook_pos, kait_judul))
    if kait_sel:
        for m_ in mt_sel:
            daftar_sisip.append((m_.end(), kait_sel))
    sisipan = sorted(daftar_sisip, key=lambda x: -x[0])
    for pos, teks in sisipan:
        s = s[:pos] + teks + s[pos:]
    tulis(b, s)
    catat("OK", "Item 'Simpan ke Unduhan' dipasang di bilah atas mode pilih (%s)%s" % (rel, "" if tutup_mode else "; mode pilih tidak ditutup otomatis"))


def terapkan_tombol_ke_pesan(up, cfg):
    """Tombol 'Menuju ke pesan' di bilah mode pilih daftar Media/Berkas/Musik (SharedMediaLayout, info grup/kanal/profil).
    Dipasang di akhir konstruktor lewat NovanMod.pasangKePesan, memakai kolom yang ditemukan di sumber.
    Bila pola tidak cocok, tidak ada yang diubah."""
    if bool_str(cfg.get("tombol_ke_pesan", "true")) != "true":
        catat("LEWAT", "tombol_ke_pesan=false: tombol Menuju ke pesan tidak dipasang")
        return
    berkas = [b for b in cari(up, r"SharedMediaLayout\.java") if "Components" in b.parts]
    if not berkas:
        catat("LEWAT", "SharedMediaLayout.java tidak ditemukan; tombol Menuju ke pesan TIDAK dipasang")
        return
    b = berkas[0]
    s = baca(b)
    rel = b.relative_to(up)
    if "NovanMod.pasangKePesan" in s:
        catat("LEWAT", "Kait tombol Menuju ke pesan sudah ada di %s" % rel)
        return
    # ada dua konstruktor publik: yang pertama hanya meneruskan ke this(...); pilih yang berisi super(...) (yang asli)
    mk = None
    for mm in re.finditer(r"\bpublic\s+SharedMediaLayout\s*\(([^)]*)\)\s*(?:throws[^{]*)?\{", s, re.S):
        mk = mk or mm
        if re.match(r"\s*super\s*\(", s[mm.end():mm.end() + 40]):
            mk = mm
            break
    if not mk:
        catat("LEWAT", "Konstruktor SharedMediaLayout tidak ditemukan; tombol Menuju ke pesan TIDAK dipasang")
        _lapor_cuplikan(rel, s, r"SharedMediaLayout\s*\(")
        return
    parameter = mk.group(1)

    def kolom(pola):
        m = re.search(pola, s)
        return bool(m) and _kedalaman(s, m.start()) == 1

    bar = "(Object) actionModeLayout" if kolom(r"\bLinearLayout\s+actionModeLayout\s*(?:;|=)") else "null"
    goto = "(Object) gotoItem" if kolom(r"\b\w+\s+gotoItem\s*(?:;|=)") else "null"
    if bar == "null" and goto == "null":
        catat("LEWAT", "Kolom actionModeLayout/gotoItem tidak ditemukan di %s; tombol Menuju ke pesan TIDAK dipasang" % rel)
        _lapor_cuplikan(rel, s, r"actionModeLayout|gotoItem")
        return
    if not kolom(r"\bSparseArray\s*(?:<[^;=(){}]*>)?\s*\[\s*\]\s+selectedFiles\b"):
        catat("LEWAT", "Kolom selectedFiles tidak ditemukan seperti dugaan di %s; tombol Menuju ke pesan TIDAK dipasang" % rel)
        _lapor_cuplikan(rel, s, r"selectedFiles\s*(=|;)")
        return
    mfr = re.search(r"\bBaseFragment\s+(\w+)", parameter)
    if mfr:
        fragmen = mfr.group(1)
    elif kolom(r"\bBaseFragment\s+profileActivity\s*(?:;|=)"):
        fragmen = "profileActivity"
    else:
        fragmen = "null"
    mc = re.search(r"\bContext\s+(\w+)", parameter)
    konteks = mc.group(1) if mc else "getContext()"
    buka = mk.end() - 1
    tutup = _pasangan(s, buka)
    if tutup < 0:
        catat("LEWAT", "Badan konstruktor SharedMediaLayout tidak terbaca; tombol Menuju ke pesan TIDAK dipasang")
        return
    kait = ("\n        try { org.telegram.messenger.NovanMod.pasangKePesan(%s, %s, (Object) selectedFiles, %s, %s); } catch (Throwable novE) { }\n    "
            % (bar, goto, "(Object) " + fragmen if fragmen != "null" else "null", konteks))
    s = s[:tutup] + kait + s[tutup:]
    tulis(b, s)
    catat("OK", "Tombol 'Menuju ke pesan' dipasang di akhir konstruktor %s (bilah=%s, bawaan=%s, fragmen=%s)" % (rel, bar, goto, fragmen))


# ---------------------------------------------------------------- 6d. notifikasi latar dan kunci peta
def terapkan_notifikasi_latar(up, cfg):
    """Tanpa FCM, notifikasi bergantung pada layanan koneksi latar belakang. Bawaannya mati di Telegram resmi;
    di sini bawaannya dinyalakan (pilihan pengguna di Pengaturan Notifikasi tetap menang)."""
    if bool_str(cfg.get("notifikasi_latar", "true")) != "true":
        catat("LEWAT", "notifikasi_latar=false: bawaan layanan koneksi latar tidak diubah")
        return
    total, berkas_ubah = 0, []
    pola = re.compile(r'(getBoolean\(\s*"keepAliveService"\s*,\s*)false(\s*\))')
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in ("build", ".git", ".gradle", "node_modules", "res", "jni")]
        for f in fn:
            if not f.endswith(".java"):
                continue
            p = Path(dp) / f
            try:
                s = baca(p)
            except OSError:
                continue
            if "keepAliveService" not in s:
                continue
            s2, n = pola.subn(r"\1true\2", s)
            if n:
                tulis(p, s2)
                total += n
                berkas_ubah.append(str(p.relative_to(up)))
    if total:
        catat("OK", "Layanan koneksi latar menyala sejak awal (%d tempat: %s)" % (total, ", ".join(berkas_ubah)))
    else:
        catat("LEWAT", "Pola keepAliveService tidak ditemukan; bawaan koneksi latar TIDAK diubah (nyalakan sendiri di Pengaturan > Notifikasi)")


def terapkan_kunci_maps(up, cfg):
    kunci = str(cfg.get("kunci_google_maps", "")).strip()
    if not kunci:
        catat("LEWAT", "kunci_google_maps kosong: peta Google tetap memakai kunci bawaan Telegram (peta bisa kosong)")
        return
    if not re.fullmatch(r"[A-Za-z0-9_\-]{20,80}", kunci):
        catat("LEWAT", "kunci_google_maps tampak tidak valid (hanya huruf, angka, _ dan -); tidak dipasang")
        return
    n_total = 0
    p1 = re.compile(r'(android:name="com\.google\.android\.geo\.API_KEY"\s+android:value=")[^"]*(")')
    p2 = re.compile(r'(android:value=")[^"]*("\s+android:name="com\.google\.android\.geo\.API_KEY")')
    for m in cari(up, r"AndroidManifest\.xml"):
        s = baca(m)
        s2, a = p1.subn(lambda x: x.group(1) + kunci + x.group(2), s)
        s2, b = p2.subn(lambda x: x.group(1) + kunci + x.group(2), s2)
        if a + b:
            tulis(m, s2)
            n_total += a + b
            catat("OK", "Kunci Google Maps Anda dipasang di %s" % m.relative_to(up))
    if not n_total:
        catat("LEWAT", "Baris meta-data com.google.android.geo.API_KEY tidak ditemukan di manifest; kunci peta tidak dipasang")


# ---------------------------------------------------------------- 6e. fitur ala TurboTel (tahap 10)
def terapkan_teruskan_tanpa_kutipan(up, cfg):
    """Nilai awal 'sembunyikan nama pengirim' di layar teruskan jadi nyala (Telegram resmi sudah punya pilihannya,
    tetapi bawaannya mati)."""
    if bool_str(cfg.get("teruskan_tanpa_kutipan", "true")) != "true":
        catat("LEWAT", "teruskan_tanpa_kutipan=false: bawaan layar teruskan tidak diubah")
        return
    pola = re.compile(r"((?:public\s+|private\s+|protected\s+)?(?:static\s+)?boolean\s+hideForwardSendersName)\s*;")
    jumlah, lokasi = 0, []
    for dp, dn, fn in os.walk(up):
        dn[:] = [d for d in dn if d not in ("build", ".git", ".gradle", "node_modules", "res", "jni")]
        for f in fn:
            if not f.endswith(".java"):
                continue
            p = Path(dp) / f
            try:
                s = baca(p)
            except OSError:
                continue
            if "hideForwardSendersName" not in s or "NovanMod.teruskanTanpaKutipan" in s:
                continue
            s2, n = pola.subn(r"\1 = org.telegram.messenger.NovanMod.teruskanTanpaKutipan();", s, count=1)
            if n:
                tulis(p, s2)
                jumlah += n
                lokasi.append(str(p.relative_to(up)))
    if jumlah:
        catat("OK", "Teruskan tanpa nama pengirim jadi bawaan (%s); masih bisa diubah di layar teruskan" % ", ".join(lokasi))
    else:
        catat("LEWAT", "Deklarasi hideForwardSendersName tidak ditemukan; bawaan teruskan TIDAK diubah")


_POLA_CREATEMENU = re.compile(r"\b(?:void|boolean)\s+createMenu\s*\([^)]*\)\s*(?:throws[^{]*)?\{")


def _semua_createmenu(s):
    """Semua overload createMenu: daftar (awal_kurawal, akhir_kurawal, badan)."""
    hasil = []
    for m in _POLA_CREATEMENU.finditer(s):
        awal = m.end() - 1
        akhir = _kurawal_seimbang(s, awal)
        if akhir >= 0:
            hasil.append((awal, akhir, s[awal:akhir + 1]))
    return hasil


def _createmenu_utama(s):
    """Overload createMenu yang benar-benar membangun menu (bukan pembungkus pendek)."""
    for awal, akhir, badan in _semua_createmenu(s):
        if all(k in badan for k in ("items.add(", "options.add(", "icons.add(")) and "selectedObject" in badan \
                and re.search(r"if\s*\(\s*options\.isEmpty\(\)(?=\s*(?:&&|\|\||\)))", badan):
            return awal, akhir, badan
    return None


def _pasang_baris_menu(up, nama, kondisi, judul, konstanta, panggilan, ikon_pilihan):
    """Tambah satu baris ke menu tekan-tahan pesan ChatActivity (pola sama dengan Simpan ke Unduhan)."""
    berkas = [b for b in cari(up, r"ChatActivity\.java") if "ui" in b.parts]
    if not berkas:
        catat("LEWAT", "ChatActivity.java tidak ditemukan; baris %s TIDAK dipasang" % nama)
        return False
    b = berkas[0]
    s = baca(b)
    rel = b.relative_to(up)
    if re.search(r"NovanMod\.%s\b" % re.escape(konstanta), s):
        catat("LEWAT", "Kait %s sudah ada di %s" % (nama, rel))
        return True
    utama = _createmenu_utama(s)
    if not utama:
        catat("LEWAT", "createMenu utama (yang berisi items/options/icons.add dan options.isEmpty) tidak ditemukan; %s TIDAK dipasang" % nama)
        for k, (aw, ak, bd) in enumerate(_semua_createmenu(s)):
            catat("INFO", "overload createMenu #%d: panjang %d, items.add=%d options.add=%d icons.add=%d selectedObject=%d isEmpty=%d" % (
                k, len(bd), bd.count("items.add("), bd.count("options.add("), bd.count("icons.add("), bd.count("selectedObject"), bd.count("options.isEmpty()")))
        _lapor_cuplikan(rel, s, r"createMenu|void\s+processSelectedOption|options\.add\(")
        return False
    awal, akhir, badan = utama
    kosong = re.search(r"if\s*\(\s*options\.isEmpty\(\)(?=\s*(?:&&|\|\||\)))", badan)
    ikon = ikon_pilihan[4:] if ikon_pilihan.startswith("RES:") else (ikon_pilihan if ikon_pilihan.replace("R.drawable.", "") in s else "0")
    sisipan = ('if (%s) { items.add("%s"); options.add(org.telegram.messenger.NovanMod.%s); icons.add(%s); }\n        '
               % (kondisi, judul, konstanta, ikon))
    s2 = s[:awal] + badan[:kosong.start()] + sisipan + badan[kosong.start():] + s[akhir + 1:]
    h = re.search(r"\bvoid\s+processSelectedOption\s*\(\s*(?:final\s+)?int\s+(\w+)\s*\)\s*(?:throws[^{]*)?\{", s2)
    if not h:
        catat("LEWAT", "processSelectedOption tidak ditemukan; %s TIDAK dipasang" % nama)
        _lapor_cuplikan(rel, s2, r"processSelectedOption|void\s+\w*[Ss]electedOption")
        return False
    kait = ("\n        if (%s == org.telegram.messenger.NovanMod.%s) { %s; return; }" % (h.group(1), konstanta, panggilan))
    s2 = s2[:h.end()] + kait + s2[h.end():]
    tulis(b, s2)
    catat("OK", "Baris '%s' dipasang di menu pesan (%s)" % (judul, rel))
    return True


def terapkan_salin_sebagian(up, cfg):
    if bool_str(cfg.get("salin_sebagian", "true")) != "true":
        catat("LEWAT", "salin_sebagian=false: baris Salin sebagian teks tidak dipasang")
        return
    _pasang_baris_menu(
        up, "Salin sebagian teks",
        "org.telegram.messenger.NovanMod.bisaSalinSebagian(selectedObject)",
        "Salin sebagian teks", "OPSI_SALIN",
        "org.telegram.messenger.NovanMod.salinSebagian(getParentActivity(), selectedObject)",
        "R.drawable.msg_copy")


def _tambal_akun_native(up, n):
    """Kode native (tgnet) punya array berukuran MAX_ACCOUNT_COUNT (jniEnv[...]). Bila sisi Java memakai
    lebih banyak akun daripada angka ini, terjadi tulis/baca di luar array dan aplikasi crash (SIGSEGV)
    saat dibuka. Karena itu angkanya harus dinaikkan sama dengan sisi Java."""
    ketemu = [h for h in cari(up, r"Defines\.h") if "tgnet" in h.parts]
    if not ketemu:
        catat("LEWAT", "Defines.h (tgnet) tidak ditemukan; batas akun native tidak diubah (RISIKO crash bila akun > bawaan)")
        return
    h = ketemu[0]
    t = baca(h)
    t2, c = re.subn(r"(#define\s+MAX_ACCOUNT_COUNT\s+)(\d+)", lambda m: m.group(1) + str(max(n, int(m.group(2)))), t, count=1)
    if not c:
        raise Fatal("MAX_ACCOUNT_COUNT tidak ditemukan di %s; menaikkan batas akun di Java tanpa native akan membuat aplikasi crash." % h)
    if t2 != t:
        tulis(h, t2)
    catat("OK", "Batas akun native (MAX_ACCOUNT_COUNT) di %s jadi %d" % (h.relative_to(up), max(n, 0)))
    _tambal_switch_instance(up, n)


def _tambal_switch_instance(up, n):
    """ConnectionsManager::getInstance() di native berupa switch case 0..4 dengan default -> instance4.
    Akun ke-6 dst. akan memakai objek yang sama dengan akun ke-5 (state bentrok, crash null pointer).
    Tambahkan satu instance statis per akun."""
    for cm in cari(up, r"ConnectionsManager\.cpp"):
        if "tgnet" not in cm.parts:
            continue
        t = baca(cm)
        if "novan-instance" in t:
            catat("LEWAT", "getInstance() native sudah ditambal di %s" % cm.relative_to(up))
            return
        pola = re.compile(r"case\s+4\s*:\s*default\s*:\s*static\s+ConnectionsManager\s+instance4\(4\);\s*return\s+instance4;")
        if not pola.search(t):
            raise Fatal("Pola switch getInstance() di %s tidak cocok; akun > 5 akan crash. Sesuaikan tambalan." % cm)
        baris = ["/* novan-instance */"]
        for i in range(4, n):
            baris.append("case %d:" % i)
            if i == n - 1:
                baris.append("default:")
            baris.append("    { static ConnectionsManager instance%d(%d); return instance%d; }" % (i, i, i))
        t2 = pola.sub(lambda m: "\n        ".join(baris), t, count=1)
        tulis(cm, t2)
        catat("OK", "getInstance() native diperluas jadi %d instance di %s" % (n, cm.relative_to(up)))
        return
    raise Fatal("ConnectionsManager.cpp (tgnet) tidak ditemukan; batas akun native tidak bisa ditambal.")


def _potong_baris(teks, maks):
    import textwrap
    baris = [l.rstrip() for l in textwrap.dedent(teks).splitlines() if l.strip()]
    if len(baris) > maks:
        return "\n".join(baris[:maks]) + "\n... (dipotong, %d baris lagi)" % (len(baris) - maks)
    return "\n".join(baris)


def _metode_lengkap(teks, nama, maks, jumlah=2):
    """Ambil metode bernama 'nama' (kepala sampai kurung tutup), maksimal 'jumlah' kemunculan."""
    hasil = []
    pola = re.compile(r"(?:(?:public|private|protected|static|final|synchronized)\s+)*[\w<>\[\].,? ]+?\s+%s\s*\([^;{)]*\)\s*(?:throws[^{;]*)?\{" % re.escape(nama))
    for m in pola.finditer(teks):
        aw = m.end() - 1
        ak = _kurawal_seimbang(teks, aw)
        if ak < 0:
            continue
        hasil.append(_potong_baris(teks[m.start():ak + 1], maks))
        if len(hasil) >= jumlah:
            break
    return hasil


def terapkan_intai_tab(up, cfg):
    """MODE INTAI TAB (tab_intai=true): cetak kode Telegram yang mengatur urutan fokus pembaca layar di halaman utama dan tab folder,
    lalu hentikan build SENGAJA (cepat, tanpa kompilasi). Dipakai agar tambalan urutan fokus ditulis tepat."""
    if bool_str(cfg.get("tab_intai", "false")) != "true":
        return
    def cetak(judul, isi):
        print("[INTAI TAB] ===== %s =====" % judul, flush=True)
        print(isi, flush=True)

    pola_aks = re.compile(r"[Aa]ccessib|requestFocus|setFocusable|setImportantForAccessibility|TraversalBefore|TraversalAfter|announceForAccessibility|descendantFocusability|setNextFocus")

    def konteks(baris, pola, sebelum=2, sesudah=3, maks=140):
        hasil, terakhir = [], -1
        for i, l in enumerate(baris):
            if pola.search(l):
                aw = max(i - sebelum, terakhir + 1)
                hasil.append("--- baris %d ---" % (i + 1))
                hasil.extend(x.rstrip()[:180] for x in baris[aw:i + sesudah + 1])
                terakhir = i + sesudah
        return _potong_baris("\n".join(hasil), maks)

    da = [f for f in cari(up, r"DialogsActivity\.java") if "ui" in f.parts]
    if da:
        t = baca(da[0])
        baris = t.splitlines()
        cetak("DialogsActivity: baris aksesibilitas dan fokus", konteks(baris, pola_aks))
        cetak("DialogsActivity: baris yang menyebut filterTabsView (penambahan ke layar)", _potong_baris("\n".join(
            "%d: %s" % (i + 1, l.strip()[:200]) for i, l in enumerate(baris)
            if "filterTabsView" in l and re.search(r"addView|new FilterTabsView|setVisibility|getParent|indexOfChild|bringToFront", l)), 60))
        for nama, maks in (("onResume", 60), ("onBecomeFullyVisible", 50), ("onTransitionAnimationEnd", 50), ("switchToCurrentSelectedMode", 60)):
            ada = _metode_lengkap(t, nama, maks, 1)
            if ada:
                cetak("DialogsActivity.%s" % nama, ada[0])
    else:
        cetak("DialogsActivity", "(berkas tidak ditemukan)")

    ft = [f for f in cari(up, r"FilterTabsView\.java") if "Components" in f.parts]
    if ft:
        t = baca(ft[0])
        baris = t.splitlines()
        cetak("FilterTabsView: baris aksesibilitas dan fokus", konteks(baris, pola_aks, 3, 6, 160))
        for nama, maks in (("onInitializeAccessibilityNodeInfo", 40), ("selectTab", 40), ("setCurrentTab", 20), ("finishAddingTabs", 40)):
            ada = _metode_lengkap(t, nama, maks, 3)
            if ada:
                cetak("FilterTabsView.%s" % nama, "\n\n".join(ada))
    else:
        cetak("FilterTabsView", "(berkas tidak ditemukan)")

    ac = [f for f in cari(up, r"ActionBar\.java") if "ActionBar" in f.parts]
    if ac:
        cetak("ActionBar.java: baris aksesibilitas", konteks(baca(ac[0]).splitlines(), pola_aks, 1, 2, 40))
    raise Fatal("MODE INTAI TAB (tab_intai=true): build DIHENTIKAN SENGAJA sebelum menambal apa pun. Salin SEMUA baris yang diawali "
                "'[INTAI TAB]' dari log ini (termasuk potongan kode di bawahnya, sampai sebelum pesan ini) dan kirim ke saya. "
                "Setelah tambalan benar, tab_intai=false.")


def terapkan_intai_kategori(up, cfg):
    """MODE INTAI (kategori_intai=true): sebelum menambal apa pun, cetak potongan kode Telegram yang dibutuhkan fitur Kategori
    halaman utama ke log, lalu hentikan build SENGAJA. Cepat (tidak sampai kompilasi) dan memberi kode asli untuk dibaca,
    supaya tambalan berikutnya ditulis dengan tepat, bukan menebak."""
    if bool_str(cfg.get("kategori_intai", "false")) != "true":
        return
    def cetak(judul, isi):
        print("[INTAI KATEGORI] ===== %s =====" % judul, flush=True)
        print(isi, flush=True)

    mc = [f for f in cari(up, r"MessagesController\.java") if "messenger" in f.parts]
    if mc:
        t = baca(mc[0])
        cetak("MessagesController: konstanta dan bidang folder", _potong_baris("\n".join(
            l for l in t.splitlines()
            if "DIALOG_FILTER_FLAG_" in l and "=" in l
            or re.search(r"\b(dialogFilters|dialogFiltersById|selectedDialogFilter|filtersLoaded|dialogFiltersLoaded)\b[^;(]*(=|;)", l) and not l.strip().startswith(("if", "for", "return", "//"))
        ), 40))
        k = re.search(r"class\s+DialogFilter\b[^{]*\{", t)
        if k:
            ak = _kurawal_seimbang(t, k.end() - 1)
            cetak("MessagesController.DialogFilter", _potong_baris(t[k.start():ak + 1 if ak > 0 else k.start() + 6000], 130))
        else:
            cetak("MessagesController.DialogFilter", "(kelas tidak ditemukan)")
        for nama, maks in (("processLoadedDialogFilters", 150), ("sortDialogs", 90), ("getDialogFilters", 25), ("loadRemoteFilters", 45)):
            ada = _metode_lengkap(t, nama, maks)
            cetak("MessagesController.%s" % nama, "\n\n".join(ada) if ada else "(metode tidak ditemukan)")
    else:
        cetak("MessagesController", "(berkas tidak ditemukan)")

    nc = [f for f in cari(up, r"NotificationCenter\.java") if "messenger" in f.parts]
    if nc:
        cetak("NotificationCenter", "\n".join(l.strip() for l in baca(nc[0]).splitlines()
                                              if "dialogFiltersUpdated" in l or "dialogsNeedReload" in l)[:600])

    da = [f for f in cari(up, r"DialogsActivity\.java") if "ui" in f.parts]
    if da:
        t = baca(da[0])
        ada = _metode_lengkap(t, "updateFilterTabs", 130, 1)
        cetak("DialogsActivity.updateFilterTabs", "\n\n".join(ada) if ada else "(metode tidak ditemukan)")
        cetak("DialogsActivity: baris yang menyebut dialogFilters", _potong_baris("\n".join(
            l.strip() for l in t.splitlines() if "dialogFilters" in l or "getDialogFilters" in l), 30))
    ft = [f for f in cari(up, r"FilterTabsView\.java") if "Components" in f.parts]
    if ft:
        cetak("FilterTabsView.addTab", _potong_baris("\n".join(l.strip() for l in baca(ft[0]).splitlines() if re.search(r"\baddTab\s*\(", l)), 6))
    # --- tahap 25: aturan R8/proguard, tempat dialogFilters diisi, dan jalur muat folder
    aturan = [x for x in cari(up, r"proguard.*\.pro") if "build" not in x.parts]
    if not aturan:
        cetak("Proguard", "(berkas proguard tidak ditemukan)")
    for a in aturan[:3]:
        cetak("Proguard %s" % a.relative_to(up), _potong_baris(baca(a), 150))
    for g in cari(up, r"build\.gradle"):
        if "TMessagesProj" in g.parts and "jni" not in g.parts:
            gl = baca(g).splitlines()
            cuplik = []
            for i, l in enumerate(gl):
                if re.search(r"minifyEnabled|proguardFiles|shrinkResources|useProguard|buildTypes|debuggable", l):
                    cuplik.append("%d: %s" % (i + 1, l.strip()[:200]))
            cetak("Gradle %s (minify/proguard)" % g.relative_to(up), "\n".join(cuplik[:40]) or "(tidak ada)")
    if mc:
        t = baca(mc[0])
        konteks = []
        baris = t.splitlines()
        for i, l in enumerate(baris):
            if re.search(r"\b(dialogFilters|frozenDialogFilters)\s*=[^=]", l) or re.search(r"\bdialogFilters\.(add|clear|remove|set)", l):
                konteks.append("--- baris %d ---" % (i + 1))
                konteks.extend(x.rstrip()[:200] for x in baris[max(0, i - 14):i + 6])
        cetak("MessagesController: tempat dialogFilters diisi", _potong_baris("\n".join(konteks), 110))
        for nama, maks in (("applyDialogFilters", 40), ("loadFilters", 40), ("lockFiltersInternal", 30), ("checkLoadedRemoteFilters", 60)):
            ada = _metode_lengkap(t, nama, maks)
            if ada:
                cetak("MessagesController.%s" % nama, "\n\n".join(ada))
    ms = [f for f in cari(up, r"MessagesStorage\.java") if "messenger" in f.parts]
    if ms:
        ts = baca(ms[0])
        for nama, maks in (("checkLoadedRemoteFilters", 80), ("loadDialogFilters", 80)):
            ada = _metode_lengkap(ts, nama, maks, 1)
            cetak("MessagesStorage.%s" % nama, "\n\n".join(ada) if ada else "(metode tidak ditemukan)")
    raise Fatal("MODE INTAI (kategori_intai=true): build DIHENTIKAN SENGAJA sebelum menambal apa pun. Salin SEMUA baris yang diawali "
                "'[INTAI KATEGORI]' dari log ini (termasuk potongan kode di bawahnya, sampai sebelum pesan ini) dan kirim ke saya. "
                "Setelah tambalan benar, kategori_intai=false.")



def terapkan_cek_kategori(up, cfg):
    """Pemeriksaan DINI untuk fitur Kategori halaman utama (tahap 22). NovanKategori bekerja lewat refleksi pada MessagesController
    (dialogFilters, kelas DialogFilter) dan NotificationCenter.dialogFiltersUpdated. Bila nama-nama itu tidak ada di kode Telegram
    yang diunduh, fitur diam-diam tidak jalan dan Anda baru tahu setelah APK jadi. Karena itu build SENGAJA GAGAL di sini dengan
    pesan jelas dan baris DIAGNOSA, supaya log mudah disalin. kategori_utama=false atau kategori_cek=false melewati pemeriksaan."""
    if bool_str(cfg.get("kategori_utama", "true")) != "true" or bool_str(cfg.get("kategori_cek", "true")) != "true":
        catat("LEWAT", "kategori_utama=false atau kategori_cek=false: pemeriksaan kategori dilewati")
        return
    masalah = []
    diag = []

    mc = [f for f in cari(up, r"MessagesController\.java") if "messenger" in f.parts]
    teks_mc = baca(mc[0]) if mc else ""
    if not mc:
        masalah.append("MessagesController.java tidak ditemukan")
    else:
        if not re.search(r"ArrayList\s*<\s*(?:MessagesController\.)?DialogFilter\s*>\s+dialogFilters\b", teks_mc):
            masalah.append("bidang ArrayList<DialogFilter> dialogFilters tidak ada di MessagesController")
        k = re.search(r"class\s+DialogFilter\b[^{]*\{", teks_mc)
        if not k:
            masalah.append("kelas DialogFilter tidak ada di MessagesController")
        else:
            aw = k.end() - 1
            ak = _kurawal_seimbang(teks_mc, aw)
            badan = teks_mc[aw:ak] if ak > 0 else teks_mc[aw:aw + 4000]
            for nama in ("id", "flags"):
                if not re.search(r"\bint\b[^;(){}=]*\b%s\b" % nama, badan):
                    masalah.append("DialogFilter tidak punya bidang int %s" % nama)
            if not re.search(r"\b[A-Za-z_][\w.<>]*\s+name\b[^;(){}]*;", badan):
                masalah.append("DialogFilter tidak punya bidang name")
            diag.append("DialogFilter bidang: " + " | ".join(
                l.strip() for l in badan.splitlines() if re.match(r"\s*(?:public|private|protected)?\s*[\w.<>\[\]]+\s+\w+\s*(?:=[^;]*)?;", l))[:900])
        for kata in ("dialogFiltersById", "sortDialogs", "DIALOG_FILTER_FLAG_GROUPS", "DIALOG_FILTER_FLAG_CHANNELS",
                     "DIALOG_FILTER_FLAG_CONTACTS", "DIALOG_FILTER_FLAG_NON_CONTACTS", "DIALOG_FILTER_FLAG_BOTS", "isDefault", "localId"):
            if kata not in teks_mc:
                diag.append("PERINGATAN (tidak fatal): '%s' tidak ditemukan di MessagesController; fitur tetap jalan dengan nilai cadangan" % kata)
    nc = [f for f in cari(up, r"NotificationCenter\.java") if "messenger" in f.parts]
    if not nc or not re.search(r"\bdialogFiltersUpdated\b", baca(nc[0])):
        masalah.append("NotificationCenter.dialogFiltersUpdated tidak ada")
    da = [f for f in cari(up, r"DialogsActivity\.java") if "ui" in f.parts]
    if da:
        cuplikan = [l.strip() for l in baca(da[0]).splitlines() if "dialogFilters" in l or "getDialogFilters" in l][:6]
        diag.append("DialogsActivity memakai: " + " || ".join(cuplikan))
    for d in diag:
        print("[DIAGNOSA KATEGORI] " + d[:1200], flush=True)
    if masalah:
        raise Fatal("Kategori halaman utama TIDAK bisa dipasang: " + "; ".join(masalah) + ". Salin baris-baris '[DIAGNOSA KATEGORI]' "
                    "di atas dan kirim ke saya. Untuk membangun tanpa fitur ini: kategori_utama=false.")
    catat("OK", "Pemeriksaan kategori lolos: dialogFilters, DialogFilter(id, flags, name), dialogFiltersUpdated ada")


def terapkan_aturan_kategori(up, cfg):
    """NovanKategori memakai bidang Telegram secara langsung (tahan R8). Hanya metode sortDialogs dipanggil lewat refleksi, jadi
    namanya dijaga lewat aturan -keep di TMessagesProj/proguard-rules.pro (bukan berkas proguard contoh di jni)."""
    if bool_str(cfg.get("kategori_utama", "true")) != "true":
        return
    aturan = [x for x in cari(up, r"proguard-rules\.pro") if "build" not in x.parts and len(x.relative_to(up).parts) == 2]
    if not aturan:
        print("[DIAGNOSA KATEGORI] TMessagesProj/proguard-rules.pro tidak ditemukan", flush=True)
        raise Fatal("Aturan -keep kategori TIDAK bisa dipasang: TMessagesProj/proguard-rules.pro tidak ditemukan. "
                    "Untuk membangun tanpa fitur ini: kategori_utama=false.")
    a = aturan[0]
    t = baca(a)
    if "novan-kategori" not in t:
        tulis(a, t.rstrip("\n") + "\n\n# novan-kategori\n"
              "-keepclassmembers class org.telegram.messenger.MessagesController {\n    public void sortDialogs(**);\n}\n")
    if "novan-kategori" not in baca(a):
        raise Fatal("Aturan -keep kategori gagal ditulis ke %s." % a.relative_to(up))
    catat("OK", "Aturan -keep sortDialogs dipasang di %s" % a.relative_to(up))


def terapkan_cek_langsung_kategori(up, cfg):
    """NovanKategori kini memakai bidang Telegram langsung (kompilasi Java), jadi bila salah satu bidang/metode di bawah tidak ada,
    kompilasi akan gagal setelah lama. Pemeriksaan ini gagal DULU (beberapa menit) dengan daftar yang kurang."""
    if bool_str(cfg.get("kategori_utama", "true")) != "true" or bool_str(cfg.get("kategori_cek", "true")) != "true":
        return
    mc = [f for f in cari(up, r"MessagesController\.java") if "messenger" in f.parts]
    kurang = []
    if not mc:
        kurang.append("MessagesController.java")
    else:
        t = baca(mc[0])
        for pola, nama in (
            (r"ArrayList\s*<\s*DialogFilter\s*>\s+dialogFilters\b", "ArrayList<DialogFilter> dialogFilters"),
            (r"SparseArray\s*<\s*DialogFilter\s*>\s+dialogFiltersById\b", "SparseArray<DialogFilter> dialogFiltersById"),
            (r"void\s+sortDialogs\s*\(", "sortDialogs("),
        ):
            if not re.search(pola, t):
                kurang.append(nama)
        for c in ("CONTACTS", "NON_CONTACTS", "GROUPS", "CHANNELS", "BOTS", "EXCLUDE_MUTED", "EXCLUDE_READ", "EXCLUDE_ARCHIVED"):
            if not re.search(r"static\s+(?:final\s+)?int\s+DIALOG_FILTER_FLAG_%s\b" % c, t):
                kurang.append("DIALOG_FILTER_FLAG_" + c)
        k = re.search(r"class\s+DialogFilter\b[^{]*\{", t)
        if not k:
            kurang.append("kelas DialogFilter")
        else:
            ak = _kurawal_seimbang(t, k.end() - 1)
            badan = t[k.end():ak] if ak > 0 else t[k.end():k.end() + 6000]
            for pola, nama in (
                (r"\bint\s+id\b", "int id"), (r"\bint\s+flags\b", "int flags"), (r"\bint\s+order\b", "int order"),
                (r"\bint\s+localId\b", "int localId"), (r"\bString\s+name\b", "String name"),
                (r"ArrayList\s*<\s*Long\s*>\s+alwaysShow\b", "ArrayList<Long> alwaysShow"),
                (r"ArrayList\s*<\s*Long\s*>\s+neverShow\b", "ArrayList<Long> neverShow"),
                (r"boolean\s+isDefault\s*\(", "isDefault()"), (r"boolean\s+isChatlist\s*\(", "isChatlist()"),
            ):
                if not re.search(pola, badan):
                    kurang.append("DialogFilter." + nama)
    nc = [f for f in cari(up, r"NotificationCenter\.java") if "messenger" in f.parts]
    tn = baca(nc[0]) if nc else ""
    for n in ("dialogFiltersUpdated", "dialogsNeedReload"):
        if not re.search(r"static\s+final\s+int\s+%s\b" % n, tn):
            kurang.append("NotificationCenter." + n)
    if kurang:
        print("[DIAGNOSA KATEGORI] kurang: " + "; ".join(kurang), flush=True)
        raise Fatal("Kategori halaman utama TIDAK bisa dikompilasi: tidak ada di kode Telegram: " + "; ".join(kurang)
                    + ". Kirim baris '[DIAGNOSA KATEGORI]' ke saya. Untuk membangun tanpa fitur ini: kategori_utama=false.")
    catat("OK", "Pemeriksaan langsung kategori lolos (bidang publik MessagesController, DialogFilter, NotificationCenter ada)")


def terapkan_transkripsi(up, cfg):
    """Baris 'Transkripsi' di menu tekan-tahan pesan suara dan video bulat (tahap 16). Pola sama dengan Salin sebagian teks."""
    if bool_str(cfg.get("transkripsi", "true")) != "true":
        catat("LEWAT", "transkripsi=false: baris Transkripsi tidak dipasang")
        return
    ok = _pasang_baris_menu(
        up, "Transkripsi",
        "org.telegram.messenger.NovanMod.bisaTranskripsi(selectedObject)",
        "Transkripsi", "OPSI_TRANSKRIP",
        "org.telegram.messenger.NovanMod.transkripsi(getParentActivity(), selectedObject)",
        ("RES:R.drawable.%s" % _ikon_res(up, _IKON_TRANSKRIP)) if _ikon_res(up, _IKON_TRANSKRIP) else "R.drawable.msg_message")
    if not ok:
        raise Fatal("Baris 'Transkripsi' di menu tekan-tahan TIDAK terpasang. Salin baris-baris 'LEWAT' dan 'DIAGNOSA' "
                    "tepat di atas pesan ini dan kirim ke Claude. Setel transkripsi=false di novan-mod.properties bila ingin tetap membangun tanpa baris ini.")


def _titik_koma_tingkat_atas(s, mulai):
    """Posisi ';' pertama di luar kurung/kurawal/string mulai dari 'mulai', atau -1."""
    d, i, n = 0, mulai, len(s)
    while i < n:
        ch = s[i]
        if ch == "/" and s[i + 1:i + 2] == "/":
            j = s.find("\n", i)
            i = n if j < 0 else j
            continue
        if ch == "/" and s[i + 1:i + 2] == "*":
            j = s.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        if ch in "\"'":
            i += 1
            while i < n and s[i] != ch:
                i += 2 if s[i] == "\\" else 1
            i += 1
            continue
        if ch in "({[":
            d += 1
        elif ch in ")}]":
            d -= 1
            if d < 0:
                return -1
        elif ch == ";" and d == 0:
            return i
        i += 1
    return -1


def terapkan_sembunyi_transkrip_bawaan(up, cfg):
    """Sembunyikan tombol transkripsi bawaan Telegram (khusus Premium) dan petunjuk Premium-nya untuk akun non-Premium (tahap 17).
    Transkripsi Novan (menu tekan-tahan) tidak terpengaruh."""
    if bool_str(cfg.get("sembunyi_transkrip_bawaan", "true")) != "true":
        catat("LEWAT", "sembunyi_transkrip_bawaan=false: tombol transkripsi bawaan tidak diubah")
        return
    # 1) tombol di gelembung pesan suara
    sel = [b for b in cari(up, r"ChatMessageCell\.java") if "Cells" in b.parts]
    if not sel:
        catat("LEWAT", "ChatMessageCell.java tidak ditemukan; tombol transkripsi bawaan TIDAK disembunyikan")
    else:
        b = sel[0]
        s = baca(b)
        rel = b.relative_to(up)
        if "novan-sembunyi-transkrip" in s:
            catat("LEWAT", "Tambalan tombol transkripsi bawaan sudah ada di %s" % rel)
        else:
            titik = []
            for m in re.finditer(r"\buseTranscribeButton\s*=\s*(?!=)", s):
                akhir = _titik_koma_tingkat_atas(s, m.end())
                if akhir < 0:
                    continue
                if "Transcri" not in s[m.start():akhir]:
                    continue
                if re.fullmatch(r"useTranscribeButton\s*=\s*(false|true)", s[m.start():akhir].strip()):
                    continue  # penetapan polos, bukan penentu tampil-tidaknya tombol
                titik.append(akhir)
            if not titik:
                catat("LEWAT", "Pernyataan 'useTranscribeButton = ...' tidak ditemukan di %s; tombol bawaan TIDAK disembunyikan" % rel)
                _lapor_cuplikan(rel, s, r"useTranscribeButton")
            else:
                sisip = ("\n        if (!org.telegram.messenger.UserConfig.getInstance(currentAccount).isPremium()) "
                         "{ useTranscribeButton = false; } /* novan-sembunyi-transkrip */")
                for akhir in sorted(titik, reverse=True):
                    s = s[:akhir + 1] + sisip + s[akhir + 1:]
                tulis(b, s)
                catat("OK", "Tombol transkripsi bawaan disembunyikan untuk akun non-Premium (%s, %d tempat)" % (rel, len(titik)))
    # 2) petunjuk/ajakan Premium soal transkripsi
    mc = [b for b in cari(up, r"MessagesController\.java") if "messenger" in b.parts]
    if not mc:
        catat("LEWAT", "MessagesController.java tidak ditemukan; petunjuk Premium transkripsi TIDAK disembunyikan")
        return
    b = mc[0]
    s = baca(b)
    pola = re.compile(r"return\s+transcribeButtonPressed\s*>=\s*2\s*;")
    if len(pola.findall(s)) != 1:
        catat("LEWAT", "Pola 'return transcribeButtonPressed >= 2;' tidak tepat satu di %s; petunjuk Premium TIDAK disembunyikan" % b.relative_to(up))
        _lapor_cuplikan(b.relative_to(up), s, r"transcribeButtonPressed")
        return
    s = pola.sub("return true; /* novan-sembunyi-transkrip */", s, count=1)
    tulis(b, s)
    catat("OK", "Petunjuk Premium transkripsi dimatikan (%s)" % b.relative_to(up))


def terapkan_maks_akun(up, cfg):
    """Naikkan batas jumlah akun (Telegram resmi: 3, Premium: 5)."""
    try:
        n = int(str(cfg.get("maks_akun", "10")).strip())
    except ValueError:
        catat("LEWAT", "maks_akun tidak berupa angka; batas akun tidak diubah")
        return
    if n <= 3:
        catat("LEWAT", "maks_akun=%d: batas akun bawaan tidak diubah" % n)
        return
    n = min(n, 16)
    _tambal_akun_native(up, n)
    berkas = [b for b in cari(up, r"UserConfig\.java") if "messenger" in b.parts]
    if not berkas:
        catat("LEWAT", "UserConfig.java tidak ditemukan; batas akun TIDAK diubah")
        return
    b = berkas[0]
    s = baca(b)
    rel = b.relative_to(up)
    if "novan-maks-akun" in s:
        catat("LEWAT", "Batas akun sudah ditambal di %s" % rel)
        return
    diubah = []
    s, a = re.subn(r"(\bMAX_ACCOUNT_DEFAULT_COUNT\s*=\s*)\d+", lambda m: m.group(1) + str(n), s, count=1)
    if a:
        diubah.append("MAX_ACCOUNT_DEFAULT_COUNT")

    def naik(m):
        return m.group(1) + str(max(n, int(m.group(2))))
    s, c = re.subn(r"(\bMAX_ACCOUNT_COUNT\s*=\s*)(\d+)", naik, s, count=1)
    if c:
        diubah.append("MAX_ACCOUNT_COUNT")
    h = re.search(r"\bstatic\s+int\s+getMaxAccountCount\s*\(\s*\)\s*\{", s)
    if h:
        awal = h.end() - 1
        akhir = _kurawal_seimbang(s, awal)
        if akhir > 0:
            s = s[:awal] + "{ /* novan-maks-akun */ return %d; }" % n + s[akhir + 1:]
            diubah.append("getMaxAccountCount()")
    if diubah:
        tulis(b, s)
        catat("OK", "Batas akun dinaikkan jadi %d (%s di %s)" % (n, ", ".join(diubah), rel))
    else:
        catat("LEWAT", "Batas akun tidak ditemukan di %s; jumlah akun TIDAK berubah" % rel)


# ---------------------------------------------------------------- 7. layar Pengaturan Novan Tel
def terapkan_manifest_pengaturan(up, cfg):
    """Daftarkan NovanPengaturanActivity di manifest. ikon_pengaturan=true: muncul juga sebagai ikon sendiri."""
    ikon = bool_str(cfg.get("ikon_pengaturan", "false")) == "true"
    kandidat = [m for m in cari(up, r"AndroidManifest\.xml")
                if "</application>" in baca(m) and "twidget" not in m.parts and "jni" not in m.parts]
    pilih = None
    for m in kandidat:
        if 'android:name="org.telegram.ui.LaunchActivity"' in baca(m):
            pilih = m
            break
    if pilih is None and kandidat:
        pilih = kandidat[0]
    if pilih is None:
        catat("LEWAT", "AndroidManifest.xml aplikasi tidak ditemukan; layar Pengaturan Novan Tel tidak didaftarkan")
        return False
    s = baca(pilih)
    if "NovanPengaturanActivity" in s:
        catat("LEWAT", "NovanPengaturanActivity sudah terdaftar di manifest")
        return True
    if ikon:
        blok = ('        <activity android:name="org.telegram.messenger.NovanPengaturanActivity" '
                'android:label="Pengaturan Novan Tel" android:exported="true" '
                'android:theme="@android:style/Theme.DeviceDefault">\n'
                '            <intent-filter>\n'
                '                <action android:name="android.intent.action.MAIN" />\n'
                '                <category android:name="android.intent.category.LAUNCHER" />\n'
                '            </intent-filter>\n'
                '        </activity>\n')
    else:
        blok = ('        <activity android:name="org.telegram.messenger.NovanPengaturanActivity" '
                'android:label="Pengaturan Novan Tel" android:exported="false" '
                'android:theme="@android:style/Theme.DeviceDefault" />\n')
    k = s.rfind("</application>")
    ls = s.rfind("\n", 0, k) + 1
    tulis(pilih, s[:ls] + blok + s[ls:])
    catat("OK", "Layar Pengaturan Novan Tel didaftarkan di %s (%s)" % (pilih.relative_to(up), "dengan ikon sendiri" if ikon else "tanpa ikon"))
    return True


def _menu_item_baru(f, s, rel):
    """Telegram 13.x memakai daftar item (SettingCell.Factory.of(id, ...)) + switch(item.id). Sisipkan satu item
    'Pengaturan Novan Tel' setelah item Bahasa (id 10) dan cabang kliknya."""
    if "novan-menu-item" in s:
        return True
    m = re.search(r"^([ \t]*)items\.add\(SettingCell\.Factory\.of\(10,[^\n]*\)\);[ \t]*\n", s, re.M)
    c = re.search(r"^([ \t]*)case\s+10\s*:\s*\n", s, re.M)
    if not m or not c:
        return False
    baris = ('%sitems.add(SettingCell.Factory.of(9001, IconBackgroundColors.PURPLE.top, IconBackgroundColors.PURPLE.bottom, '
             'R.drawable.settings_language, "Pengaturan Novan Tel", "Kualitas suara dan lainnya")); /* novan-menu-item */\n' % m.group(1))
    cabang = ('%scase 9001:\n%s    if (getParentActivity() != null) { getParentActivity().startActivity(new android.content.Intent('
              'getParentActivity(), org.telegram.messenger.NovanPengaturanActivity.class)); }\n%s    break;\n'
              % (c.group(1), c.group(1), c.group(1)))
    # sisipkan cabang dulu (posisinya lebih bawah), lalu barisnya
    s2 = s[:c.start()] + cabang + s[c.start():]
    s2 = s2[:m.end()] + baris + s2[m.end():]
    tulis(f, s2)
    catat("OK", "Baris 'Pengaturan Novan Tel' ditambahkan di %s (gaya item baru, id 9001)" % rel)
    return True


def terapkan_menu_telegram(up, cfg):
    """Tambah baris 'Pengaturan Novan Tel' di Pengaturan Telegram dengan menggandakan baris Bahasa (languageRow)."""
    if bool_str(cfg.get("menu_pengaturan", "true")) != "true":
        catat("LEWAT", "menu_pengaturan=false: baris menu di Pengaturan Telegram tidak ditambahkan")
        return
    berkas = [p for p in cari(up, r"SettingsActivity\.java") if "ui" in p.parts]
    if not berkas:
        catat("LEWAT", "SettingsActivity.java tidak ditemukan; baris menu tidak ditambahkan (layar tetap ada lewat ikon sendiri)")
        return
    f = berkas[0]
    s = baca(f)
    rel = f.relative_to(up)
    if "novanRow" in s:
        catat("LEWAT", "Baris menu Novan sudah ada di %s" % rel)
        return
    # a) deklarasi kolom
    mdek = re.search(r"\bprivate\s+int\s+[^;]*\blanguageRow\b[^;]*;", s)
    # b) penetapan nomor baris
    mset = re.search(r"\blanguageRow\s*=\s*rowCount\+\+\s*;", s)
    if not mdek or not mset:
        if _menu_item_baru(f, s, rel):
            return
        catat("LEWAT", "Pola languageRow tidak cocok di %s (deklarasi=%s, baris=%s); baris menu tidak ditambahkan"
              % (rel, bool(mdek), bool(mset)))
        return
    # c) cabang klik dan cabang tampilan: gandakan blok 'if (position == languageRow) { ... }'
    klik = tampil = None
    for m in re.finditer(r"if\s*\(\s*position\s*==\s*languageRow\s*\)\s*\{", s):
        tutup = _kurawal_seimbang(s, m.end() - 1)
        if tutup < 0:
            continue
        isi = s[m.end():tutup]
        if "presentFragment(" in isi and klik is None:
            klik = (m, tutup, isi)
        elif re.search(r"setTextAndIcon|setText\(", isi) and tampil is None:
            tampil = (m, tutup, isi)
    if not klik or not tampil:
        catat("LEWAT", "Cabang klik/tampilan languageRow tidak ditemukan di %s (klik=%s, tampil=%s); baris menu tidak ditambahkan"
              % (rel, bool(klik), bool(tampil)))
        return
    # isi klik baru
    isi_k = klik[2]
    pf = isi_k.index("presentFragment(")
    pf_tutup = _kurung_seimbang(isi_k, pf + len("presentFragment"))
    if pf_tutup < 0:
        catat("LEWAT", "Pemanggilan presentFragment tidak berpasangan di %s; baris menu tidak ditambahkan" % rel)
        return
    akhir_stmt = pf_tutup + 1
    while akhir_stmt < len(isi_k) and isi_k[akhir_stmt] in " \t":
        akhir_stmt += 1
    if akhir_stmt < len(isi_k) and isi_k[akhir_stmt] == ";":
        akhir_stmt += 1
    isi_k_baru = (isi_k[:pf]
                  + "if (getParentActivity() != null) { getParentActivity().startActivity(new android.content.Intent(getParentActivity(), org.telegram.messenger.NovanPengaturanActivity.class)); }"
                  + isi_k[akhir_stmt:])
    # isi tampilan baru
    isi_t = tampil[2]
    lg = re.search(r"LocaleController\.getString\s*\(", isi_t)
    if not lg:
        catat("LEWAT", "Teks baris Bahasa tidak memakai LocaleController.getString di %s; baris menu tidak ditambahkan" % rel)
        return
    lg_tutup = _kurung_seimbang(isi_t, lg.end() - 1)
    if lg_tutup < 0:
        catat("LEWAT", "Teks baris Bahasa tidak berpasangan di %s; baris menu tidak ditambahkan" % rel)
        return
    isi_t_baru = isi_t[:lg.start()] + '"Pengaturan Novan Tel"' + isi_t[lg_tutup + 1:]
    # d) rantai kondisi (jenis tampilan dan bisa-diklik): tambahkan novanRow di samping languageRow
    n_rantai = [0]

    def tambah1(m):
        n_rantai[0] += 1
        return m.group(1) + " || position == novanRow" + m.group(2)
    s2 = re.sub(r"(\bposition\s*==\s*languageRow)(\s*\|\|)", tambah1, s)
    s2 = re.sub(r"(\|\|\s*position\s*==\s*languageRow)(\s*[)&])", tambah1, s2)
    if not n_rantai[0]:
        catat("LEWAT", "Rantai jenis tampilan languageRow tidak ditemukan di %s; baris menu tidak ditambahkan" % rel)
        return
    # e) terapkan semua perubahan pada teks hasil (posisi blok dihitung ulang setelah langkah d)
    def ganti_blok(teks, isi_lama, isi_baru):
        pola = re.compile(r"if\s*\(\s*position\s*==\s*languageRow\s*\)\s*\{")
        for m in pola.finditer(teks):
            tutup = _kurawal_seimbang(teks, m.end() - 1)
            if tutup >= 0 and teks[m.end():tutup] == isi_lama:
                klon = " else if (position == novanRow) {" + isi_baru + "}"
                return teks[:tutup + 1] + klon + teks[tutup + 1:]
        return None
    s3 = ganti_blok(s2, klik[2], isi_k_baru)
    s3 = ganti_blok(s3, tampil[2], isi_t_baru) if s3 is not None else None
    if s3 is None:
        catat("LEWAT", "Gagal menggandakan cabang languageRow di %s; baris menu tidak ditambahkan" % rel)
        return
    s3 = re.sub(r"\blanguageRow\s*=\s*rowCount\+\+\s*;", lambda m: m.group(0) + "\n        novanRow = rowCount++;", s3, count=1)
    mdek2 = re.search(r"\bprivate\s+int\s+[^;]*\blanguageRow\b[^;]*;", s3)
    s3 = s3[:mdek2.start()] + "private int novanRow = -1;\n    " + s3[mdek2.start():]
    tulis(f, s3)
    catat("OK", "Baris 'Pengaturan Novan Tel' ditambahkan di Pengaturan Telegram (%s; %d rantai kondisi disesuaikan)" % (rel, n_rantai[0]))




def _dalam_perulangan(teks, pos):
    """True bila posisi 'pos' berada di dalam badan perulangan 'for' (supaya 'continue' sah)."""
    awal = max(0, pos - 800)
    cocok = list(re.finditer(r"\bfor\s*\(", teks[awal:pos]))
    for m in reversed(cocok):
        mulai = awal + m.start()
        tutup_kurung = _kurung_seimbang(teks, awal + m.end() - 1)
        if tutup_kurung < 0:
            continue
        sisa = teks[tutup_kurung + 1:tutup_kurung + 40].lstrip()
        if not sisa.startswith("{"):
            continue
        buka = teks.index("{", tutup_kurung)
        akhir = _kurawal_seimbang(teks, buka)
        if akhir > pos:
            return True
    return False

# ---------------------------------------------------------------- 9. anti hapus
def terapkan_anti_hapus(up, cfg):
    """Pasang kait anti hapus di MessagesController (pembaruan dari server dan notifikasi dorong)."""
    berkas = [p for p in cari(up, r"MessagesController\.java") if "messenger" in p.parts]
    if not berkas:
        catat("LEWAT", "MessagesController.java tidak ditemukan; anti hapus TIDAK aktif")
        return
    f = berkas[0]
    s = baca(f)
    rel = f.relative_to(up)
    if "novan-anti-hapus" in s:
        catat("LEWAT", "Kait anti hapus sudah ada di %s" % rel)
        return
    jumlah_a = [0]
    jumlah_b = [0]

    # a) pembaruan dari server: di dalam perulangan 'for' yang membaca baseUpdate
    def sisip_a(m):
        if not _dalam_perulangan(s_sementara[0], m.start()):
            return m.group(0)
        jumlah_a[0] += 1
        return (m.group(0) + "\n                if (org.telegram.messenger.NovanMod.tahanHapus(currentAccount, %s)) { continue; } /* novan-anti-hapus */" % m.group(1))
    s_sementara = [s]
    s2 = re.sub(r"TLRPC\.Update\s+(\w+)\s*=\s*\w+\.get\(\s*\w+\s*\)\s*;", sisip_a, s)

    # b) notifikasi dorong: awal metode deleteMessagesByPush
    def sisip_b(m):
        jumlah_b[0] += 1
        return m.group(1) + "\n        if (org.telegram.messenger.NovanMod.tahanHapus()) { return; } /* novan-anti-hapus */"
    s3 = re.sub(r"((?:public|private|protected)?\s*(?:final\s+)?void\s+deleteMessagesByPush\s*\([^)]*\)\s*\{)", sisip_b, s2)

    # periksa: kait 'continue' hanya valid bila variabelnya memang diperiksa pada 'baseUpdate' (nama bebas, tipe Update)
    if not jumlah_a[0] and not jumlah_b[0]:
        catat("LEWAT", "Pola pembaruan hapus tidak cocok di %s; anti hapus TIDAK aktif" % rel)
        return
    tulis(f, s3)
    catat("OK", "Anti hapus dipasang di %s (%d kait pembaruan server, %d kait notifikasi dorong)" % (rel, jumlah_a[0], jumlah_b[0]))
    if not jumlah_a[0]:
        catat("LEWAT", "Kait pembaruan server TIDAK terpasang: pesan yang dihapus lewat koneksi langsung masih bisa hilang")


NOVAN_A11Y_JAVA = r'''    /* novan-aksesibilitas: perbaikan agar tombol aksi profil terbaca pembaca layar (TalkBack, Jieshuo, dll.) */
    private AccessibilityNodeProvider accessibilityNodeProvider;
    private int novanFocusedId = Integer.MIN_VALUE;

    private RectF novanWindowRect(RectF local) {
        RectF r = new RectF(local);
        View v = this;
        while (true) {
            v.getMatrix().mapRect(r);
            r.offset(v.getLeft(), v.getTop());
            android.view.ViewParent p = v.getParent();
            if (p instanceof View) {
                View pv = (View) p;
                r.offset(-pv.getScrollX(), -pv.getScrollY());
                v = pv;
            } else {
                break;
            }
        }
        return r;
    }

    private Rect novanScreenRect(RectF local) {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        RectF origin = novanWindowRect(new RectF(0, 0, 0, 0));
        RectF r = novanWindowRect(local);
        r.offset(loc[0] - origin.left, loc[1] - origin.top);
        return new Rect(Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom));
    }

    private Action novanFindAction(int id) {
        for (int i = 0; i < actions.size(); ++i) {
            if (actions.get(i).key == id) {
                return actions.get(i);
            }
        }
        return null;
    }

    private CharSequence novanLabel(Action action) {
        CharSequence cs = action.text != null ? action.text.getText() : null;
        return cs == null ? "" : cs;
    }

    private void novanSendEvent(int viewId, int eventType) {
        try {
            AccessibilityManager am = (AccessibilityManager) getContext().getSystemService(Context.ACCESSIBILITY_SERVICE);
            if (am != null && am.isEnabled() && getParent() != null) {
                AccessibilityEvent event = AccessibilityEvent.obtain(eventType);
                event.setPackageName(getContext().getPackageName());
                event.setSource(ProfileActionsView.this, viewId);
                getParent().requestSendAccessibilityEvent(ProfileActionsView.this, event);
            }
        } catch (Throwable ignore) {
        }
    }

    @Override
    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        if (accessibilityNodeProvider == null) {
            accessibilityNodeProvider = new AccessibilityNodeProvider() {
                @Override
                public AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                    if (virtualViewId == AccessibilityNodeProvider.HOST_VIEW_ID) {
                        AccessibilityNodeInfo info = AccessibilityNodeInfo.obtain(ProfileActionsView.this);
                        onInitializeAccessibilityNodeInfo(info);
                        info.setEnabled(true);
                        info.setClickable(false);
                        info.setFocusable(false);
                        info.setClassName("android.view.ViewGroup");
                        for (int i = 0; i < actions.size(); ++i) {
                            Action a = actions.get(i);
                            if (!a.rect.isEmpty()) {
                                info.addChild(ProfileActionsView.this, a.key);
                            }
                        }
                        return info;
                    }
                    Action action = novanFindAction(virtualViewId);
                    if (action == null || action.rect.isEmpty()) return null;

                    CharSequence label = novanLabel(action);
                    AccessibilityNodeInfo info = AccessibilityNodeInfo.obtain();
                    info.setSource(ProfileActionsView.this, virtualViewId);
                    info.setParent(ProfileActionsView.this);
                    info.setPackageName(getContext().getPackageName());
                    info.setClassName(android.widget.Button.class.getName());
                    info.setText(label);
                    info.setContentDescription(label);
                    info.setClickable(true);
                    info.setFocusable(true);
                    info.setEnabled(true);
                    info.setVisibleToUser(true);
                    info.addAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if (novanFocusedId == virtualViewId) {
                        info.setAccessibilityFocused(true);
                        info.addAction(AccessibilityNodeInfo.ACTION_CLEAR_ACCESSIBILITY_FOCUS);
                    } else {
                        info.setAccessibilityFocused(false);
                        info.addAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
                    }

                    Rect inParent = new Rect(
                            (int) action.rect.left, (int) action.rect.top,
                            (int) action.rect.right, (int) action.rect.bottom);
                    info.setBoundsInParent(inParent);
                    info.setBoundsInScreen(novanScreenRect(action.rect));
                    return info;
                }

                @Override
                public java.util.List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                    java.util.ArrayList<AccessibilityNodeInfo> hasil = new java.util.ArrayList<>();
                    if (text == null) return hasil;
                    String cari = text.toLowerCase();
                    for (int i = 0; i < actions.size(); ++i) {
                        Action a = actions.get(i);
                        if (novanLabel(a).toString().toLowerCase().contains(cari)) {
                            AccessibilityNodeInfo info = createAccessibilityNodeInfo(a.key);
                            if (info != null) hasil.add(info);
                        }
                    }
                    return hasil;
                }

                @Override
                public AccessibilityNodeInfo findFocus(int focus) {
                    if (focus == AccessibilityNodeInfo.FOCUS_ACCESSIBILITY && novanFocusedId != Integer.MIN_VALUE) {
                        return createAccessibilityNodeInfo(novanFocusedId);
                    }
                    return null;
                }

                @Override
                public boolean performAction(int virtualViewId, int action, @Nullable Bundle arguments) {
                    if (virtualViewId == AccessibilityNodeProvider.HOST_VIEW_ID) {
                        return performAccessibilityAction(action, arguments);
                    }
                    Action button = novanFindAction(virtualViewId);
                    if (button == null) return false;

                    if (action == AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS) {
                        if (novanFocusedId == virtualViewId) return false;
                        novanFocusedId = virtualViewId;
                        invalidate();
                        novanSendEvent(virtualViewId, AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED);
                        return true;
                    } else if (action == AccessibilityNodeInfo.ACTION_CLEAR_ACCESSIBILITY_FOCUS) {
                        if (novanFocusedId != virtualViewId) return false;
                        novanFocusedId = Integer.MIN_VALUE;
                        invalidate();
                        novanSendEvent(virtualViewId, AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED);
                        return true;
                    } else if (action == AccessibilityNodeInfo.ACTION_CLICK) {
                        if (onActionClickListener != null) {
                            RectF rc = button.rect;
                            onActionClickListener.onClick(virtualViewId, rc.centerX(), rc.centerY());
                        }
                        return true;
                    }
                    return false;
                }
            };
        }
        return accessibilityNodeProvider;
    }
}
'''


def terapkan_aksesibilitas_profil(up, cfg):
    """Tombol aksi di profil (Obrolan, Senyapkan, Hubungi, Hadiah, dst.) digambar dalam satu View khusus dengan
    node aksesibilitas virtual. Ganti implementasinya supaya terbaca pembaca layar: deskripsi konten, posisi layar
    yang benar walau container beranimasi, dan penanganan fokus aksesibilitas yang lengkap."""
    if bool_str(cfg.get("aksesibilitas_profil", "true")) != "true":
        catat("LEWAT", "aksesibilitas_profil=false: tombol profil tidak ditambal")
        return
    berkas = [p for p in cari(up, r"ProfileActionsView\.java") if "Components" in p.parts]
    if not berkas:
        catat("LEWAT", "ProfileActionsView.java tidak ditemukan; aksesibilitas tombol profil tidak ditambal")
        return
    f = berkas[0]
    s = baca(f)
    if "novan-aksesibilitas" in s:
        catat("LEWAT", "Aksesibilitas tombol profil sudah ditambal di %s" % f.relative_to(up))
        return
    a = s.find("private AccessibilityNodeProvider accessibilityNodeProvider;")
    z = s.rfind("}")
    if a < 0 or z < a or "getAccessibilityNodeProvider" not in s[a:]:
        catat("LEWAT", "Pola node aksesibilitas tidak cocok di %s; tombol profil tidak ditambal" % f.relative_to(up))
        return
    for imp in ("import android.graphics.Rect;", "import android.graphics.RectF;", "import android.content.Context;", "import android.os.Bundle;"):
        if imp not in s:
            s = s.replace("import android.view.accessibility.AccessibilityEvent;", imp + "\nimport android.view.accessibility.AccessibilityEvent;", 1)
    a = s.find("private AccessibilityNodeProvider accessibilityNodeProvider;")
    z = s.rfind("}")
    tulis(f, s[:a] + NOVAN_A11Y_JAVA)
    catat("OK", "Aksesibilitas tombol profil diperbaiki di %s" % f.relative_to(up))


def terapkan_tandai_terbaca_manual(up, cfg):
    """Mode hantu memblokir tanda baca. Aksi 'Tandai sebagai dibaca' (daftar obrolan dan tombol di notifikasi)
    adalah perintah sengaja dari pengguna, jadi dilepas sebentar lewat NovanMod.izinkanBaca()."""
    panggil = "org.telegram.messenger.NovanMod.izinkanBaca(); "
    total = 0
    for f in cari(up, r"DialogsActivity\.java"):
        if "ui" not in f.parts:
            continue
        t = baca(f)
        if "izinkanBaca" in t:
            catat("LEWAT", "Tandai terbaca manual sudah ditambal di %s" % f.relative_to(up))
            continue
        pola = "getMessagesController().markDialogAsRead(did, dialog.top_message, dialog.top_message, dialog.last_message_date, false, 0, 0, true, 0);"
        n = t.count(pola)
        if n:
            tulis(f, t.replace(pola, panggil + pola))
            total += n
    for f in cari(up, r"AutoMessageHeardReceiver\.java"):
        t = baca(f)
        if "izinkanBaca" in t:
            continue
        pola = "AccountInstance accountInstance = AccountInstance.getInstance(currentAccount);"
        if pola in t:
            tulis(f, t.replace(pola, panggil + pola, 1))
            total += 1
    if total:
        catat("OK", "Tandai sebagai dibaca manual dilepas dari mode hantu (%d titik)" % total)
    else:
        catat("LEWAT", "Aksi Tandai sebagai dibaca tidak ditemukan; mode hantu akan memblokirnya juga")


def terapkan_penanda_dihapus(up, cfg):
    """Pesan yang ditahan anti hapus diberi awalan 'Sudah dihapus oleh pengirim' pada teks aksesibilitas pesan."""
    for f in cari(up, r"ChatMessageAccessibilityNodeProvider\.java"):
        t = baca(f)
        if "awalanAksesibilitas" in t:
            catat("LEWAT", "Penanda pesan dihapus sudah ada di %s" % f.relative_to(up))
            return
        pola = "cell.accessibilityText = sb;"
        if t.count(pola) != 1:
            catat("LEWAT", "Pola teks aksesibilitas pesan tidak cocok di %s; penanda pesan dihapus tidak dipasang" % f.relative_to(up))
            return
        baru = ("{ CharSequence novanAwalan = org.telegram.messenger.NovanMod.awalanAksesibilitas(cell.currentMessageObject); "
                "if (novanAwalan != null) { sb.insert(0, novanAwalan); } }\n                " + pola)
        tulis(f, t.replace(pola, baru))
        catat("OK", "Penanda pesan dihapus dipasang di %s" % f.relative_to(up))
        return
    catat("LEWAT", "ChatMessageAccessibilityNodeProvider.java tidak ditemukan; penanda pesan dihapus tidak dipasang")


def _sisip_setelah(up, nama_berkas, ciri_dir, tanda, penanda, kode, harus=1):
    """Sisipkan 'kode' tepat setelah baris tanda (mis. kepala metode). Mengembalikan jumlah sisipan."""
    jumlah = 0
    for f in cari(up, nama_berkas):
        if ciri_dir not in f.parts:
            continue
        t = baca(f)
        if penanda in t:
            return -1
        n = t.count(tanda)
        if n:
            tulis(f, t.replace(tanda, tanda + "\n" + kode, harus if harus else n))
            jumlah += min(n, harus) if harus else n
    return jumlah


def terapkan_konfirmasi(up, cfg):
    """Dialog konfirmasi (opsional, mati bawaan) untuk telepon, stiker/GIF, dan pesan suara."""
    nm = "org.telegram.messenger.NovanMod"
    # a) telepon 1:1
    r = _sisip_setelah(up, r"VoIPHelper\.java", "voip",
        "public static void startCall(TLRPC.User user, boolean videoCall, boolean canVideoCall, final Activity activity, TLRPC.UserFull userFull, AccountInstance accountInstance) {",
        "novan-konfirmasi-telepon",
        "\t\tif (%s.tanyaDulu(activity, \"konfirmasi_telepon\", videoCall ? \"Mulai panggilan video?\" : \"Mulai panggilan suara?\", () -> startCall(user, videoCall, canVideoCall, activity, userFull, accountInstance))) { return; } /* novan-konfirmasi-telepon */" % nm)
    catat("OK" if r > 0 else "LEWAT", "Konfirmasi telepon: %s" % ("terpasang" if r > 0 else "sudah ada atau pola tidak cocok"))
    # b) stiker dan GIF, lalu c) pesan suara, di kolom ketik
    f_ok = {"stiker": 0, "gif": 0, "suara": 0}
    for f in cari(up, r"ChatActivityEnterView\.java"):
        if "Components" not in f.parts:
            continue
        t = baca(f)
        if "novan-konfirmasi" in t:
            catat("LEWAT", "Konfirmasi kolom ketik sudah ada di %s" % f.relative_to(up))
            break
        sig_st = "public void onStickerSelected(TLRPC.Document sticker, String query, Object parent, MessageObject.SendAnimationData sendAnimationData, boolean clearsInputField, boolean notify, int scheduleDate, int scheduleRepeatPeriod) {"
        if t.count(sig_st) == 1:
            t = t.replace(sig_st, sig_st + "\n        { final boolean novN = notify; final int novS = scheduleDate; final int novR = scheduleRepeatPeriod; if (%s.tanyaDulu(parentActivity, \"konfirmasi_stiker\", \"Kirim stiker ini?\", () -> onStickerSelected(sticker, query, parent, sendAnimationData, clearsInputField, novN, novS, novR))) { return; } } /* novan-konfirmasi-stiker */" % nm)
            f_ok["stiker"] = 1
        sig_gif = "public void onGifSelected(View view, Object gif, String query, Object parent, boolean notify, int scheduleDate, int scheduleRepeatPeriod, MediaController.PhotoEntry entry, boolean invertMedia) {"
        if t.count(sig_gif) == 1:
            t = t.replace(sig_gif, sig_gif + "\n                { final boolean novN = notify; final int novS = scheduleDate; final int novR = scheduleRepeatPeriod; if (%s.tanyaDulu(parentActivity, \"konfirmasi_stiker\", \"Kirim GIF ini?\", () -> onGifSelected(view, gif, query, parent, novN, novS, novR, entry, invertMedia))) { return; } } /* novan-konfirmasi-gif */" % nm)
            f_ok["gif"] = 1
        kirim = "MediaController.getInstance().stopRecording(isInScheduleMode() ? 3 : 1, true, 0, voiceOnce, 0);"
        n_suara = t.count(kirim)
        if n_suara:
            baru = ("if (!%s.tanyaKirimSuara(parentActivity, () -> MediaController.getInstance().stopRecording(isInScheduleMode() ? 3 : 1, true, 0, voiceOnce, 0), "
                    "() -> MediaController.getInstance().stopRecording(0, false, 0, voiceOnce, 0))) { %s } /* novan-konfirmasi-suara */" % (nm, kirim))
            t = t.replace(kirim, baru)
            f_ok["suara"] = n_suara
        tulis(f, t)
        break
    catat("OK" if f_ok["stiker"] else "LEWAT", "Konfirmasi stiker: %s" % ("terpasang" if f_ok["stiker"] else "pola tidak cocok"))
    catat("OK" if f_ok["gif"] else "LEWAT", "Konfirmasi GIF: %s" % ("terpasang" if f_ok["gif"] else "pola tidak cocok"))
    catat("OK" if f_ok["suara"] else "LEWAT", "Konfirmasi pesan suara: %s" % ("terpasang di %d titik" % f_ok["suara"] if f_ok["suara"] else "pola tidak cocok"))


def terapkan_rapikan_pengaturan(up, cfg):
    """Panggil NovanMod.rapikanPengaturan(items) di akhir penyusunan daftar Pengaturan Telegram."""
    for f in cari(up, r"SettingsActivity\.java"):
        if "ui" not in f.parts:
            continue
        t = baca(f)
        if "rapikanPengaturan" in t:
            catat("LEWAT", "Rapikan Pengaturan sudah terpasang di %s" % f.relative_to(up))
            return
        pola = "items.add(UItem.asCustomShadow(versionView));"
        if t.count(pola) != 1:
            catat("LEWAT", "Pola akhir daftar Pengaturan tidak cocok di %s; Rapikan Pengaturan tidak dipasang" % f.relative_to(up))
            return
        tulis(f, t.replace(pola, "org.telegram.messenger.NovanMod.rapikanPengaturan(items); /* novan-rapikan */\n        " + pola))
        catat("OK", "Rapikan Pengaturan dipasang di %s" % f.relative_to(up))
        return
    catat("LEWAT", "SettingsActivity.java tidak ditemukan; Rapikan Pengaturan tidak dipasang")


def terapkan_izin_baterai(up, cfg):
    """Tombol 'Izin latar belakang' di Pengaturan Novan Tel memakai izin REQUEST_IGNORE_BATTERY_OPTIMIZATIONS; pastikan ada di manifest."""
    izin = "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
    kandidat = [m for m in cari(up, r"AndroidManifest\.xml")
                if "<application" in baca(m) and "twidget" not in m.parts and "jni" not in m.parts]
    pilih = None
    for m in kandidat:
        if 'android:name="org.telegram.ui.LaunchActivity"' in baca(m):
            pilih = m
            break
    if pilih is None and kandidat:
        pilih = kandidat[0]
    if pilih is None:
        catat("LEWAT", "AndroidManifest.xml aplikasi tidak ditemukan; izin baterai tidak ditambahkan")
        return
    s = baca(pilih)
    if izin in s:
        catat("OK", "Izin %s sudah ada di %s (tombol Izin latar belakang siap)" % (izin, pilih.relative_to(up)))
        return
    k = s.find("<application")
    ls = s.rfind("\n", 0, k) + 1
    tulis(pilih, s[:ls] + '    <uses-permission android:name="%s" />\n' % izin + s[ls:])
    catat("OK", "Izin %s ditambahkan di %s" % (izin, pilih.relative_to(up)))


def jalankan(up, cfg, overlay):
    up = Path(up)
    terapkan_intai_tab(up, cfg)
    terapkan_intai_kategori(up, cfg)
    terapkan_kredensial(up, cfg)
    terapkan_identitas(up, cfg)
    terapkan_versi(up, cfg)
    terapkan_google_services(up, cfg)
    terapkan_novanmod(up, cfg, overlay)
    terapkan_cek_kategori(up, cfg)
    terapkan_aturan_kategori(up, cfg)
    terapkan_cek_langsung_kategori(up, cfg)
    terapkan_arm_saja(up, cfg)
    terapkan_kualitas_suara(up, cfg)
    terapkan_efek_suara(up, cfg)
    terapkan_efek_native(up, cfg)
    terapkan_efek_java_perekam_baru(up, cfg)
    terapkan_efek_native_perekam_baru(up, cfg)
    terapkan_unduh_suara(up, cfg)
    terapkan_simpan_unduhan(up, cfg)
    terapkan_simpan_banyak(up, cfg)
    terapkan_tombol_ke_pesan(up, cfg)
    terapkan_notifikasi_latar(up, cfg)
    terapkan_teruskan_tanpa_kutipan(up, cfg)
    terapkan_salin_sebagian(up, cfg)
    terapkan_transkripsi(up, cfg)
    terapkan_sembunyi_transkrip_bawaan(up, cfg)
    terapkan_maks_akun(up, cfg)
    terapkan_kunci_maps(up, cfg)
    terapkan_anti_hapus(up, cfg)
    terapkan_aksesibilitas_profil(up, cfg)
    terapkan_tandai_terbaca_manual(up, cfg)
    terapkan_penanda_dihapus(up, cfg)
    terapkan_konfirmasi(up, cfg)
    terapkan_rapikan_pengaturan(up, cfg)
    terapkan_izin_baterai(up, cfg)
    if terapkan_manifest_pengaturan(up, cfg):
        terapkan_menu_telegram(up, cfg)
    return LAPORAN
