package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.widget.EditText;
import org.json.JSONObject;

public class EditActivity extends Activity {
    private Ui ui;
    private String full, path, sha, token;
    private boolean isNew;
    private EditText editor;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        token = Store.token(this);
        Intent i = getIntent();
        full = i.getStringExtra("repo");
        path = i.getStringExtra("path");
        sha = i.getStringExtra("sha");
        isNew = i.getBooleanExtra("new", false);
        if (isNew) {
            show("");
            return;
        }
        ui = new Ui(this, "Edit: " + shortName());
        ui.label("Memuat isi berkas...");
        Api.request("GET", Api.BASE + "/repos/" + full + "/git/blobs/" + sha, token, null, (ok, res) -> {
            if (!ok) {
                ui.say("Gagal membaca: " + res);
                return;
            }
            try {
                byte[] b = Base64.decode(Api.parse(res).optString("content", "").replace("\n", ""), Base64.DEFAULT);
                String text = new String(b, "UTF-8");
                if (text.indexOf('\u0000') >= 0) {
                    ui.say("Berkas bukan teks, tidak bisa diedit. Gunakan unduh.");
                    return;
                }
                show(text);
            } catch (Exception e) {
                ui.say("Gagal membaca isi berkas.");
            }
        });
    }

    private String shortName() {
        int c = path.lastIndexOf('/');
        return c >= 0 ? path.substring(c + 1) : path;
    }

    private void show(String text) {
        ui = new Ui(this, (isNew ? "Berkas baru: " : "Edit: ") + shortName());
        editor = ui.edit("Isi berkas", "", true, text);
        ui.button("Simpan", v -> save());
        ui.button("Kembali tanpa menyimpan", v -> finish());
    }

    private void save() {
        String content = Base64.encodeToString(editor.getText().toString().getBytes(java.nio.charset.StandardCharsets.UTF_8),
                Base64.NO_WRAP);
        JSONObject body = Api.o("message", (isNew ? "Tambah " : "Perbarui ") + path, "content", content);
        if (sha != null && !sha.isEmpty()) {
            try { body.put("sha", sha); } catch (Exception ignored) { }
        }
        ui.say("Menyimpan...");
        Api.request("PUT", Api.BASE + "/repos/" + full + "/contents/" + Api.enc(path), token, body.toString(),
                (ok, res) -> {
                    if (!ok) {
                        ui.say("Gagal menyimpan: " + res);
                        return;
                    }
                    String newSha = Api.parse(res).optJSONObject("content") != null
                            ? Api.parse(res).optJSONObject("content").optString("sha", "") : "";
                    setResult(RESULT_OK, new Intent().putExtra("sha", newSha));
                    ui.say(isNew ? "Berkas dibuat." : "Perubahan disimpan.");
                    finish();
                });
    }
}
