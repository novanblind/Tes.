package com.makroku.automation.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.heading
import com.makroku.automation.adb.AdbBackend
import com.makroku.automation.adb.Lokal
import com.makroku.automation.adb.PairHelper
import com.makroku.automation.engine.ElevatedPermissions

/** Panduan + status izin yang diberikan lewat ADB (pm grant / appops / cmd / settings put). */
@Composable
fun AdbScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val steps = remember(tick) { ElevatedPermissions.steps(ctx) }
    val status = remember(tick) { steps.map { runCatching { it.granted(ctx) }.getOrDefault(false) } }

    var pesan by remember { mutableStateOf("") }
    var sibuk by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        PairHelper.sink = java.util.function.Consumer<String> { pesan = it; tick++ }
        onDispose { PairHelper.sink = null }
    }
    fun kerja(awal: String, blok: () -> String) {
        if (sibuk) return
        sibuk = true
        pesan = awal
        Thread {
            val hasil = try { blok() } catch (e: Throwable) { "Gagal: ${e.message}" }
            pesan = hasil
            sibuk = false
            tick++
        }.start()
    }

    fun copy(label: String, text: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(ctx, "Perintah disalin ke papan klip", Toast.LENGTH_SHORT).show()
    }

    SubScreen("Izin via ADB", onBack, actions = { TextButton(onClick = { tick++; android.widget.Toast.makeText(ctx, "Status disegarkan", android.widget.Toast.LENGTH_SHORT).show() }) { Text("Segarkan") } }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ADB Wi-Fi bawaan (tanpa PC dan tanpa Shizuku)", style = MaterialTheme.typography.titleSmall, modifier = Modifier.semantics { heading() })
                    val dipasang = AdbBackend.dipasangkan(ctx)
                    val nyambung = AdbBackend.tersambung(ctx)
                    Text(
                        "Status: " + when {
                            nyambung && Lokal.viaLokal -> "tersambung lewat 127.0.0.1:${Lokal.PORT} (Wi-Fi boleh mati)"
                            nyambung -> "tersambung lewat Wi-Fi"
                            dipasang -> "sudah dipasangkan, belum tersambung"
                            else -> "belum dipasangkan"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Sekali saja: nyalakan Wi-Fi dan Debugging nirkabel, ketuk Mulai pairing, buka \"Pasangkan perangkat dengan kode pairing\", " +
                            "lalu ketik kode 6 angka di notifikasi MakroKu. Setelah itu semuanya otomatis.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Button(enabled = !sibuk, onClick = {
                        PairHelper.startDiscovery(ctx)
                        runCatching {
                            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }) { Text("Mulai pairing") }
                    Button(enabled = !sibuk, onClick = {
                        kerja("Menyambung...") {
                            PairHelper.connect(ctx, true)
                            if (AdbBackend.tersambung(ctx)) "Tersambung." else "Belum tersambung. Nyalakan Wi-Fi dan Debugging nirkabel, atau pasangkan dulu."
                        }
                    }) { Text("Sambungkan") }
                    Button(enabled = !sibuk && nyambung, onClick = {
                        kerja("Memberi izin...") { ElevatedPermissions.grantAllViaAdb(ctx) }
                    }) { Text("Beri semua izin otomatis") }
                    OutlinedButton(enabled = !sibuk && nyambung && !Lokal.viaLokal, onClick = {
                        kerja("Pindah ke mode tanpa Wi-Fi...") { Lokal.aktifkanModeTanpaWifi(ctx, com.makroku.automation.adb.Adb.get(ctx)) }
                    }) { Text("Mode tanpa Wi-Fi") }
                    OutlinedButton(enabled = !sibuk && nyambung, onClick = {
                        kerja("Mengetes...") { "Tes: " + AdbBackend.shell(ctx, "id") }
                    }) { Text("Tes perintah (id)") }
                    if (pesan.isNotBlank()) {
                        Text(
                            pesan,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                        )
                    }
                }
            }

            Text("Cara memakai dari PC (alternatif)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
            Text(
                "1. Di HP: nyalakan Debugging USB (Xiaomi/Poco: juga \"USB debugging (Pengaturan keamanan)\").\n" +
                    "2. Sambungkan ke PC, jalankan perintah di bawah.\n" +
                    "3. Kembali ke sini, ketuk Segarkan. Cukup sekali; hilang bila aplikasi dipasang ulang.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { copy("adb", ElevatedPermissions.script(ctx)) }) { Text("Salin semua perintah") }
            }

            val hasSecure = ElevatedPermissions.hasSecureSettings(ctx)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Aktifkan otomatis (tanpa membuka Pengaturan)", style = MaterialTheme.typography.titleSmall, modifier = Modifier.semantics { heading() })
                    Text(
                        if (hasSecure) "WRITE_SECURE_SETTINGS sudah ada — layanan bisa dinyalakan langsung."
                        else "Perlu WRITE_SECURE_SETTINGS (langkah 1) lebih dulu.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(enabled = hasSecure, onClick = {
                            val ok = runCatching { ElevatedPermissions.enableAccessibility(ctx) }.getOrDefault(false)
                            Toast.makeText(ctx, if (ok) "Aksesibilitas diaktifkan" else "Gagal mengaktifkan", Toast.LENGTH_SHORT).show()
                            tick++
                        }) { Text("Aksesibilitas") }
                        FilledTonalButton(enabled = hasSecure, onClick = {
                            val ok = runCatching { ElevatedPermissions.enableNotificationListener(ctx) }.getOrDefault(false)
                            Toast.makeText(ctx, if (ok) "Akses notifikasi diaktifkan" else "Gagal mengaktifkan", Toast.LENGTH_SHORT).show()
                            tick++
                        }) { Text("Akses notifikasi") }
                    }
                }
            }

            var jagaDev by remember { mutableStateOf(com.makroku.automation.adb.AdbBackend.jagaOpsiPengembang(ctx)) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        Modifier.toggleable(
                            value = jagaDev,
                            role = androidx.compose.ui.semantics.Role.Switch,
                            onValueChange = {
                                jagaDev = it
                                com.makroku.automation.adb.AdbBackend.setJagaOpsiPengembang(ctx, it)
                            },
                        ),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Jangan nyalakan Opsi pengembang otomatis", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                        androidx.compose.material3.Switch(jagaDev, null)
                    }
                    Text(
                        "Nyala: Opsi pengembang tidak dinyalakan lagi saat ADB tersambung.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            steps.forEachIndexed { i, s ->
                val ok = status[i]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.semantics(mergeDescendants = true) { heading() }, verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}. ${s.title}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            Text(
                                if (ok) "Aktif" else "Belum aktif",
                                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                        Text(s.desc, style = MaterialTheme.typography.bodySmall)
                        Text(s.commands.joinToString("\n"), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                        TextButton(
                            onClick = { copy(s.title, s.commands.joinToString("\n")) },
                            modifier = Modifier.semantics { contentDescription = "Salin perintah ${s.title}" },
                        ) { Text("Salin perintah") }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
