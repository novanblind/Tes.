/* Konfigurasi minimal LAME untuk Android (pengganti hasil ./configure). Hanya encoder; tanpa dekoder mpglib. */
#ifndef LAME_ANDROID_CONFIG_H
#define LAME_ANDROID_CONFIG_H

#define STDC_HEADERS 1
#define HAVE_STRCHR 1
#define HAVE_MEMCPY 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_LIMITS_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_STDLIB_H 1
#define HAVE_MEMORY_H 1
#define HAVE_LONG_DOUBLE 1
#define HAVE_SYS_TIME_H 1

#define SIZEOF_DOUBLE 8
#define SIZEOF_FLOAT 4
#define SIZEOF_INT 4
#define SIZEOF_LONG 8
#define SIZEOF_LONG_DOUBLE 16
#define SIZEOF_SHORT 2
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_LONG 8
#define SIZEOF_UNSIGNED_SHORT 2

#define PACKAGE "lame"
#define PACKAGE_NAME "lame"
#define PACKAGE_VERSION "3.99.5"
#define VERSION "3.99.5"

#define LAME_LIBRARY_BUILD 1

/* util.h mendeklarasikan fast_log2 dengan tipe ini (di LAME 3.100 ada di machine.h). */
typedef float ieee754_float32_t;

#endif
