package com.novan.audiolabnovan.karaoke

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Larik ShortArray yang tumbuh sendiri (dipakai menampung hasil rekam vokal dan hasil urai lagu). */
class PenampungShort(kapasitasAwal: Int = 1 shl 16) {
    private var data = ShortArray(max(16, kapasitasAwal))
    @Volatile
    var ukuran = 0
        private set

    fun tambah(b: ShortArray, dari: Int, jumlah: Int) {
        if (jumlah <= 0) return
        val perlu = ukuran + jumlah
        if (perlu > data.size) {
            var baru = data.size.toLong()
            while (baru < perlu) baru = baru * 3 / 2 + 1024
            data = data.copyOf(min(baru, Int.MAX_VALUE.toLong() - 8).toInt())
        }
        System.arraycopy(b, dari, data, ukuran, jumlah)
        ukuran = perlu
    }

    operator fun get(i: Int): Short = data[i]

    fun keLarik(): ShortArray = data.copyOf(ukuran)
}

/**
 * Setelan campuran akhir karaoke.
 * [vokalPersen] dan [musikPersen] = volume 0..200. [selarasMs] = seberapa awal vokal digeser (mikrofon selalu
 * terlambat dibanding musik). [efek] dan [vokal] = rantai yang sama dengan perekam suara. [pemoles] = pembatas
 * puncak pada hasil gabungan. [vokalOtomatis] = naikkan atau turunkan vokal supaya kerasnya wajar sebelum diolah.
 * [filter] = filter suara ala StarMaker dan Smule; [nada] = deretan nada hasil menyanyi (untuk penyetel nada
 * otomatis dan harmoni). [rundukDb] = seberapa dalam musik merunduk (dB) saat ada suara penyanyi, 0 = mati.
 * [kekerasan] = penyama kekerasan hasil akhir: 0 mati, 1 sedang (RMS sekitar minus 18 dBFS), 2 keras (sekitar minus 15 dBFS).
 */
class SetelKampur(
    val vokalPersen: Int,
    val musikPersen: Int,
    val selarasMs: Int,
    val efek: KonfigEfek,
    val vokal: KonfigVokal,
    val pemoles: Boolean = true,
    val vokalOtomatis: Boolean = true,
    val filter: KonfigFilter = KonfigFilter.MATI,
    val nada: PemantauNada.Salinan? = null,
    val rundukDb: Double = 0.0,
    val kekerasan: Int = 0
)

/**
 * Mencampur lagu pengiring (stereo) dengan vokal (mono) yang direkam terpisah. Karena keduanya terpisah, vokal bisa
 * diselaraskan dan diberi efek tanpa merusak musik, dan campurannya bisa diulang dengan setelan lain.
 *
 * Murni hitungan, tanpa kelas Android.
 */
object CampurKaraoke {

    private const val BLOK = 2048
    private const val RMS_SASARAN = 2_800.0

    /** RMS sasaran hasil akhir (nilai sampel 16 bit) untuk tingkat kekerasan 1 (sedang) dan 2 (keras). */
    private val RMS_AKHIR = doubleArrayOf(0.0, 4_100.0, 5_800.0)

    /** Suara penyanyi di bawah batas ini dianggap tidak ada (derau mikrofon); di atas batas atas dianggap penuh. */
    private const val RUNDUK_BAWAH = 500.0
    private const val RUNDUK_ATAS = 2_000.0

    /**
     * Menyamakan kekerasan [b] (stereo bergantian) ke RMS [sasaran]. Bagian nyaris senyap tidak dihitung supaya jeda
     * panjang tidak membuat hasil terlalu keras. Penguatan dibatasi turun 4 dB dan naik 12 dB, lalu pembatas puncak
     * dengan langit-langit sama seperti [Pembatas] menahan puncak tanpa memotong gelombang.
     * Mengembalikan penguatan yang dipakai (1.0 bila tidak ada yang diubah).
     */
    fun samakanKeras(b: ShortArray, sr: Int, sasaran: Double): Double {
        val blok = sr / 10 * 2
        if (blok <= 0) return 1.0
        var jum = 0.0
        var banyak = 0L
        var i = 0
        while (i + blok <= b.size) {
            var e = 0.0
            for (k in i until i + blok) {
                val v = b[k].toDouble()
                e += v * v
            }
            if (sqrt(e / blok) > 300.0) {
                jum += e
                banyak += blok
            }
            i += blok
        }
        // Kurang dari 2 detik bersuara: jangan menebak.
        if (banyak < sr.toLong() * 4) return 1.0
        val g = (sasaran / sqrt(jum / banyak)).coerceIn(0.63, 4.0)
        if (abs(g - 1.0) < 0.03) return 1.0
        val aPulih = 1.0 - exp(-1.0 / (0.08 * sr))
        var gl = 1.0
        val frame = b.size / 2
        for (f in 0 until frame) {
            val l = b[f * 2] * g
            val r = b[f * 2 + 1] * g
            val puncak = max(abs(l), abs(r))
            val tuju = if (puncak * gl > 21_500.0) 21_500.0 / puncak else 1.0
            if (tuju < gl) gl = tuju else gl += (1.0 - gl) * aPulih
            b[f * 2] = batasiLembut(l * gl)
            b[f * 2 + 1] = batasiLembut(r * gl)
        }
        return g
    }

    /** Penguat otomatis vokal: kerasnya (RMS bagian yang bersuara) dibawa ke sekitar minus 21 dB, naik paling banyak 18 dB. */
    fun penguatOtomatis(vokal: ShortArray, dari: Int, sampai: Int): Double {
        var jumlah = 0.0
        var banyak = 0L
        for (i in max(0, dari) until min(vokal.size, sampai)) {
            val v = vokal[i].toDouble()
            if (v > 500 || v < -500) {
                jumlah += v * v
                banyak++
            }
        }
        // Terlalu sedikit bagian bersuara: jangan menebak, biarkan apa adanya.
        if (banyak < 4_000) return 1.0
        val rms = sqrt(jumlah / banyak)
        return (RMS_SASARAN / rms).coerceIn(0.5, 8.0)
    }

    /**
     * @param musik lagu stereo bergantian (kiri, kanan, ...); hanya [frame] frame pertama dipakai.
     * @param vokal rekaman mikrofon mono.
     * @param vokalAwal nomor sampel di [vokal] yang terekam tepat saat musik mulai diputar.
     * @return campuran stereo bergantian sepanjang [frame] frame.
     */
    fun campur(
        musik: ShortArray, frame: Int, vokal: ShortArray, vokalAwal: Int, sr: Int, s: SetelKampur,
        progres: ((Int) -> Unit)? = null
    ): ShortArray {
        val n = min(frame, musik.size / 2)
        val keluar = ShortArray(n * 2)
        val geser = vokalAwal + (s.selarasMs.toLong() * sr / 1000L).toInt()
        val penguat = if (s.vokalOtomatis) penguatOtomatis(vokal, geser, geser + n) else 1.0
        val gVokal = s.vokalPersen / 100.0
        val gMusik = s.musikPersen / 100.0

        val olah = if (s.vokal.awalAktif) PengolahVokal(sr, 1, s.vokal) else null
        val gema = if (s.efek.aktif) EfekKaraoke(sr, s.efek) else null
        val batasVokal = if (s.vokal.pembatas) Pembatas(sr, 2) else null
        val pemoles = if (s.pemoles) Pembatas(sr, 2) else null

        val jalur = if (s.filter.perluNada && s.nada != null) JalurKoreksi(s.nada, s.filter) else null
        val fv = if (s.filter.adaSuara) FilterVokal(sr, s.filter, jalur) else null
        val penyetel = if (s.filter.bassDb != 0 || s.filter.jernihDb != 0) {
            PenyetelSuara(sr, 1, s.filter.bassDb, s.filter.jernihDb)
        } else {
            null
        }
        fun ambilVokal(k: Int): Double = if (k >= 0 && k < vokal.size) vokal[k] * penguat else 0.0

        // Musik merunduk saat penyanyi bersuara: pengikut amplitudo (naik cepat 15 md, turun pelan 350 md).
        val runduk = s.rundukDb > 0.0
        val aNaik = 1.0 - exp(-1.0 / (0.015 * sr))
        val aTurun = 1.0 - exp(-1.0 / (0.35 * sr))
        var amplop = 0.0
        val gRunduk = DoubleArray(BLOK)

        val mono = ShortArray(BLOK)
        val vox = ShortArray(BLOK * 2)
        var f = 0
        while (f < n) {
            val b = min(BLOK, n - f)
            for (i in 0 until b) {
                val idx = geser + f + i
                val v = if (fv == null) {
                    ambilVokal(idx)
                } else {
                    fv.proses(idx.toLong(), ambilVokal(idx + fv.lookahead))
                }
                mono[i] = batasiLembut(v)
            }
            olah?.proses(mono, b)
            penyetel?.proses(mono, b)
            if (runduk) {
                for (i in 0 until b) {
                    val a = abs(mono[i].toDouble())
                    amplop += (a - amplop) * (if (a > amplop) aNaik else aTurun)
                    val ada = ((amplop - RUNDUK_BAWAH) / (RUNDUK_ATAS - RUNDUK_BAWAH)).coerceIn(0.0, 1.0)
                    gRunduk[i] = 10.0.pow(-s.rundukDb * ada / 20.0)
                }
            }
            if (gema != null) {
                gema.proses(mono, b, 1, vox, 2)
            } else {
                for (i in 0 until b) {
                    vox[2 * i] = mono[i]
                    vox[2 * i + 1] = mono[i]
                }
            }
            batasVokal?.proses(vox, b * 2)
            // Campuran: musik dan vokal dijumlah dalam bilangan pecahan lalu dibatasi, bukan dipotong keras.
            val baru = ShortArray(b * 2)
            for (i in 0 until b * 2) {
                val m = musik[f * 2 + i] * gMusik * (if (runduk) gRunduk[i / 2] else 1.0)
                val v = vox[i] * gVokal
                baru[i] = batasiLembut(m + v)
            }
            pemoles?.proses(baru, b * 2)
            System.arraycopy(baru, 0, keluar, f * 2, b * 2)
            f += b
            progres?.invoke((f.toLong() * 100L / max(1, n)).toInt())
        }
        // Penyama kekerasan sebelum redaman akhir, supaya redaman tidak ikut terhitung.
        if (s.kekerasan in 1..2) samakanKeras(keluar, sr, RMS_AKHIR[s.kekerasan])
        // Akhir lagu dipotong di tengah (berhenti lebih awal): redupkan 300 milidetik terakhir supaya tidak "klik".
        val redam = min(n, sr * 3 / 10)
        for (i in 0 until redam) {
            val g = i.toDouble() / redam
            val p = (n - 1 - i) * 2
            keluar[p] = (keluar[p] * g).toInt().toShort()
            keluar[p + 1] = (keluar[p + 1] * g).toInt().toShort()
        }
        return keluar
    }
}
