package com.novan.adbshell;

import android.content.Context;
import android.speech.tts.TextToSpeech;

/**
 * Ucapan singkat lewat TextToSpeech saat ADB tersambung/terputus, supaya tidak perlu
 * membuka aplikasi atau menyalakan layar untuk tahu statusnya. Bisa dimatikan lewat
 * tombol "Ucapan status ADB" (disimpan di SharedPreferences "adb", kunci "ucapan").
 *
 * Sengaja tidak memanggil setLanguage/setVoice: konstruktor TextToSpeech(context, listener)
 * tanpa nama paket mesin memakai mesin TTS utama yang sudah dipilih di Pengaturan > Aksesibilitas
 * > Text-to-speech output (mesin yang sama dipakai pembaca layar selama pembaca layar tidak
 * diatur memakai mesin/suara lain secara terpisah di menu suaranya sendiri), dengan suara dan
 * bahasa bawaan mesin itu apa adanya.
 */
final class TtsHelper {
    private static volatile TextToSpeech mesin;
    private static volatile boolean siap;
    private static volatile String tertunda;

    static boolean aktif(Context ctx) {
        return ctx.getApplicationContext()
                .getSharedPreferences("adb", Context.MODE_PRIVATE)
                .getBoolean("ucapan", true);
    }

    static synchronized void speak(Context ctx, String teks) {
        if (!aktif(ctx)) return;
        if (mesin == null) {
            tertunda = teks;
            final Context app = ctx.getApplicationContext();
            mesin = new TextToSpeech(app, status -> {
                siap = status == TextToSpeech.SUCCESS;
                if (!siap) return;
                String t = tertunda;
                if (t != null) ucapkan(t);
            });
            return;
        }
        if (siap) ucapkan(teks); else tertunda = teks;
    }

    private static void ucapkan(String teks) {
        try { mesin.speak(teks, TextToSpeech.QUEUE_ADD, null, String.valueOf(System.nanoTime())); }
        catch (Throwable ignored) {}
    }
}
