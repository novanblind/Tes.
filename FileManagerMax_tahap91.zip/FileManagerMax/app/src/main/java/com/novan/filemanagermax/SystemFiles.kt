package com.novan.filemanagermax

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import java.io.File

/**
 * Android 11 ke atas melarang aplikasi biasa membaca Android/data dan Android/obb,
 * bahkan dengan izin Kelola semua berkas. Aplikasi Files bawaan sistem (DocumentsUI)
 * tetap boleh. Jadi, seperti aplikasi "File" referensi, folder itu dibuka lewat DocumentsUI.
 */
object SystemFiles {
    private const val AUTH = "com.android.externalstorage.documents"
    private const val DIR_TYPE = "vnd.android.document/directory"
    private const val ACTION_BROWSE = "android.provider.action.BROWSE"
    private const val ACTION_BROWSE_ROOT = "android.provider.action.BROWSE_DOCUMENT_ROOT"

    private val PACKAGES = listOf("com.android.documentsui", "com.google.android.documentsui")
    private val COMPONENTS = listOf(
        "com.android.documentsui" to "com.android.documentsui.files.FilesActivity",
        "com.android.documentsui" to "com.android.documentsui.FilesActivity",
        "com.google.android.documentsui" to "com.android.documentsui.files.FilesActivity",
        "com.google.android.documentsui" to "com.android.documentsui.FilesActivity"
    )

    private val PATH_RE = Regex("^(/storage/emulated/\\d+|/storage/[^/]+|/sdcard|/mnt/sdcard)/Android/(data|obb)(/.*)?$")

    /** Jalur ke Android/data atau Android/obb (termasuk isinya) di penyimpanan mana pun. */
    fun isRestricted(f: File): Boolean = Build.VERSION.SDK_INT >= 30 && PATH_RE.matches(f.absolutePath)

    /** Folder Android/data di penyimpanan internal. */
    fun androidData(): File = File(Environment.getExternalStorageDirectory(), "Android/data")

    private class Target(val volumeId: String, val relPath: String)

    private fun targetOf(c: Context, f: File): Target {
        val m = PATH_RE.find(f.absolutePath)
        val volRoot = m?.groupValues?.get(1) ?: Environment.getExternalStorageDirectory().absolutePath
        val rel = f.absolutePath.removePrefix(volRoot).trimStart('/')
        val primary = Environment.getExternalStorageDirectory().absolutePath
        val isPrimary = volRoot == primary || volRoot == "/sdcard" || volRoot == "/mnt/sdcard" ||
            volRoot.startsWith("/storage/emulated/")
        if (isPrimary) return Target("primary", rel)
        val uuid = try {
            (c.getSystemService(Context.STORAGE_SERVICE) as StorageManager)
                .getStorageVolume(File(volRoot))?.uuid
        } catch (e: Exception) {
            null
        } ?: volRoot.substringAfterLast('/')
        return Target(uuid, rel)
    }

    /** Buka folder [dir] di Files bawaan sistem. Mengembalikan false bila tidak ada yang bisa membukanya. */
    fun open(a: Activity, dir: File): Boolean {
        val t = targetOf(a, dir)
        val docUri = DocumentsContract.buildDocumentUri(AUTH, t.volumeId + ":" + t.relPath)
        val rootUri = DocumentsContract.buildRootUri(AUTH, t.volumeId)

        // 1) Langsung ke folder yang dimaksud lewat Files sistem.
        for ((pkg, cls) in COMPONENTS) {
            if (start(a, Intent(Intent.ACTION_VIEW).setDataAndType(docUri, DIR_TYPE)
                    .setComponent(ComponentName(pkg, cls)))) return true
        }
        for (pkg in PACKAGES) {
            if (start(a, Intent(ACTION_BROWSE).setData(docUri).setPackage(pkg))) return true
        }
        // 2) Cadangan seperti aplikasi referensi: buka akar penyimpanan, pengguna masuk sendiri ke Android/data.
        for (pkg in PACKAGES) {
            if (start(a, Intent(ACTION_BROWSE_ROOT).setData(rootUri).setPackage(pkg))) return true
        }
        for ((pkg, cls) in COMPONENTS) {
            if (start(a, Intent(Intent.ACTION_VIEW).setData(rootUri)
                    .setComponent(ComponentName(pkg, cls)))) return true
        }
        return false
    }

    /** Buka Android/data (atau subfolder) dan beri tahu pengguna bila gagal. */
    fun openOrExplain(a: Activity, dir: File, say: (String) -> Unit) {
        if (open(a, dir)) say(a.getString(R.string.android_data_opened_system))
        else say(a.getString(R.string.android_data_failed))
    }

    private fun start(a: Activity, i: Intent): Boolean = try {
        a.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }
}
