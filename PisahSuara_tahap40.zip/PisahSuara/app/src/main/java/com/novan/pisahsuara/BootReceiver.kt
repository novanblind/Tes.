package com.novan.pisahsuara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Setelah HP restart: nyalakan Debugging nirkabel (bila izin ada) dan terapkan lagi pemisahan suara. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val act = i.action
        if (act != Intent.ACTION_BOOT_COMPLETED && act != "android.intent.action.QUICKBOOT_POWERON") return
        if (!Rules.active(c)) return
        AdbBackend.aktifkanDebugging(c)
        try { Kompat.mulaiLayanan(c, Intent(c, RoutingService::class.java)) } catch (_: Exception) {}
    }
}
