package com.makroku.automation.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.makroku.automation.data.MacroRepository
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.ActionBlock
import com.makroku.automation.model.AppJson
import com.makroku.automation.model.Catalog
import com.makroku.automation.model.MacroAction
import com.makroku.automation.model.RunBlockAction
import kotlinx.serialization.json.jsonObject

/** Daftar blok aksi tersimpan. Dibuat dari editor (Pilih beberapa lalu Simpan sebagai blok). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BlocksScreen(repo: MacroRepository, engine: MacroEngine, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val blocks by repo.blocks.collectAsState()
    var menuB by remember { mutableStateOf<ActionBlock?>(null) }
    var infoB by remember { mutableStateOf<ActionBlock?>(null) }
    var renameB by remember { mutableStateOf<ActionBlock?>(null) }

    SubScreen("Blok aksi", onBack) { pad ->
        if (blocks.isEmpty()) {
            Text(
                "Belum ada blok. Di editor makro, tekan tahan aksi, pilih Pilih beberapa, lalu Simpan sebagai blok.",
                Modifier.padding(pad).padding(16.dp),
            )
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(blocks, key = { it.name }) { b ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(onClickLabel = "Lihat isi", onLongClickLabel = "Buka menu", onLongClick = { menuB = b }) { infoB = b }
                                .semantics(mergeDescendants = true) {
                                    customActions = listOf(CustomAccessibilityAction("Buka menu") { menuB = b; true })
                                }
                                .padding(14.dp),
                        ) {
                            Text(b.name, style = MaterialTheme.typography.titleMedium)
                            Text("${b.actions.size} aksi", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    menuB?.let { b ->
        MenuDialog(
            b.name,
            listOf(
                MenuEntry("Lihat isi blok") { infoB = b },
                MenuEntry("Jalankan blok sekarang") {
                    engine.testAction(RunBlockAction(b.name), "Blok ${b.name}")
                    view.announceForAccessibility("Blok ${b.name} dijalankan. Hasilnya ada di Log.")
                },
                MenuEntry("Ganti nama") { renameB = b },
                MenuEntry("Salin penanda nama blok") { copyText(ctx, "Nama blok", b.name) },
                MenuEntry("Hapus blok", true) { repo.deleteBlock(b.name); view.announceForAccessibility("Blok ${b.name} dihapus") },
            ),
        ) { menuB = null }
    }
    infoB?.let { b ->
        InfoDialog(
            "Isi blok ${b.name}",
            b.actions.mapIndexed { i, a -> "Aksi ${i + 1}: " + Catalog.describe(AppJson.encodeToJsonElement(MacroAction.serializer(), a).jsonObject) },
        ) { infoB = null }
    }
    renameB?.let { b ->
        TextInputDialog("Ganti nama blok", "Nama blok", b.name, onDismiss = { renameB = null }) {
            repo.renameBlock(b.name, it); renameB = null
            view.announceForAccessibility("Nama blok diganti menjadi $it")
        }
    }
}
