package com.novan.filemanagermax

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/**
 * Dialog kemajuan untuk satu pekerjaan di [OpService]. Tombol Sembunyikan menutup dialog tanpa
 * menghentikan operasi; hasilnya diumumkan layar lewat pesan di bawah saat selesai.
 */
class OpDialog(private val activity: Activity, private val job: OpService.Job, private val onHide: () -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var dialog: AlertDialog? = null
    private lateinit var text: TextView
    private lateinit var bar: ProgressBar

    private val tick = object : Runnable {
        override fun run() {
            if (job.finished) {
                dismiss()
                return
            }
            update()
            main.postDelayed(this, 300)
        }
    }

    fun show() {
        val pad = (24 * activity.resources.displayMetrics.density).toInt()
        text = TextView(activity).apply { textSize = 16f }
        bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(text, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(bar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog = AlertDialog.Builder(activity)
            .setTitle(job.title)
            .setView(box)
            .setCancelable(false)
            .setPositiveButton(R.string.op_hide) { _, _ -> onHide() }
            .setNegativeButton(R.string.op_cancel, null)
            .create()
        dialog?.setOnShowListener {
            // Batal tidak menutup dialog; dialog tertutup sendiri saat operasi berakhir.
            dialog?.getButton(AlertDialog.BUTTON_NEGATIVE)?.setOnClickListener {
                job.progress.cancelled = true
                it.isEnabled = false
            }
        }
        dialog?.setOnDismissListener { main.removeCallbacks(tick) }
        dialog?.show()
        update()
        main.postDelayed(tick, 300)
    }

    private fun update() {
        val p = job.progress
        val busy = p.busy
        val s = StringBuilder()
        if (busy != 0) s.append(activity.getString(busyRes(busy)))
        else if (p.total > 0) s.append(activity.getString(R.string.op_percent, p.percent()))
        else s.append(activity.getString(R.string.op_waiting))
        if (p.label.isNotEmpty()) s.append("\n").append(p.label)
        if (text.text.toString() != s.toString()) text.text = s.toString()
        val indeterminate = busy != 0 || p.total <= 0L
        if (bar.isIndeterminate != indeterminate) bar.isIndeterminate = indeterminate
        if (!indeterminate) bar.progress = p.percent()
    }

    fun dismiss() {
        main.removeCallbacks(tick)
        try { dialog?.dismiss() } catch (e: Exception) { }
        dialog = null
    }
}
