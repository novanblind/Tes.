package com.novan.adbshell;

import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/** Adapter daftar yang barisnya rapat, supaya lebih banyak nama aplikasi terlihat sekaligus di layar. */
class KompakAdapter extends ArrayAdapter<String> {
    KompakAdapter(Context c) {
        super(c, android.R.layout.simple_list_item_1, new ArrayList<String>());
    }

    @Override public View getView(int pos, View cv, ViewGroup parent) {
        View v = super.getView(pos, cv, parent);
        if (v instanceof TextView) {
            TextView t = (TextView) v;
            float d = getContext().getResources().getDisplayMetrics().density;
            int h = (int) (10 * d), vv = (int) (5 * d);
            t.setMinHeight(0);
            t.setMinimumHeight(0);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding(h, vv, h, vv);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            t.setMaxLines(2);
            t.setEllipsize(TextUtils.TruncateAt.END);
        }
        return v;
    }
}
