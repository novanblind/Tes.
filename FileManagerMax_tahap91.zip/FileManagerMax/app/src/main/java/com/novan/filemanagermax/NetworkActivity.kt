package com.novan.filemanagermax

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

/** Server jaringan: FTP dan HTTP (akses dari PC). */
class NetworkActivity : AppCompatActivity() {

    private lateinit var tvNet: TextView
    private lateinit var tvFtp: TextView
    private lateinit var tvHttp: TextView
    private lateinit var tvRoot: TextView
    private lateinit var etFtpPort: EditText
    private lateinit var etHttpPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var btnFtp: Button
    private lateinit var btnHttp: Button
    private var pendingKind: String? = null

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            pendingKind?.let { doStart(it) }
            pendingKind = null
        }

    private val rootPick =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val p = r.data?.getStringExtra(BrowserActivity.RESULT_PATH)
            if (r.resultCode == RESULT_OK && p != null) {
                Prefs.setServerRoot(this, p)
                refresh()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.net_title)
        tvNet = findViewById(R.id.tvNet)
        tvFtp = findViewById(R.id.tvFtp)
        tvHttp = findViewById(R.id.tvHttp)
        tvRoot = findViewById(R.id.tvRoot)
        etFtpPort = findViewById(R.id.etFtpPort)
        etHttpPort = findViewById(R.id.etHttpPort)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        btnFtp = findViewById(R.id.btnFtp)
        btnHttp = findViewById(R.id.btnHttp)
        etFtpPort.setText(Prefs.ftpPort(this).toString())
        etHttpPort.setText(Prefs.httpPort(this).toString())
        etUser.setText(Prefs.serverUser(this))
        etPass.setText(Prefs.serverPass(this))
        btnFtp.setOnClickListener { toggle(ServerService.FTP) }
        btnHttp.setOnClickListener { toggle(ServerService.HTTP) }
        findViewById<Button>(R.id.btnRoot).setOnClickListener {
            rootPick.launch(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, Prefs.serverRoot(this))
                    .putExtra(BrowserActivity.EXTRA_TITLE, getString(R.string.net_choose_root))
                    .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_PICK_FOLDER)
            )
        }
    }

    override fun onStart() {
        super.onStart()
        ServerService.onChange = { refresh() }
        refresh()
    }

    override fun onStop() {
        super.onStop()
        ServerService.onChange = null
    }

    private fun refresh() {
        val ip = ServerUtil.localIp()
        tvNet.text = if (ip == null) getString(R.string.net_no_ip) else getString(R.string.net_ip, ip)
        tvRoot.text = getString(R.string.net_root, Prefs.serverRoot(this))
        val err = ServerService.error
        fun status(kind: String, scheme: String, tv: TextView, btn: Button, port: Int) {
            if (ServerService.isRunning(kind)) {
                tv.text = getString(R.string.net_running, "$scheme://${ip ?: "?"}:$port")
                btn.setText(if (kind == ServerService.FTP) R.string.net_stop_ftp else R.string.net_stop_http)
            } else {
                tv.text = if (err != null) getString(R.string.net_error, err) else getString(R.string.net_stopped)
                btn.setText(if (kind == ServerService.FTP) R.string.net_start_ftp else R.string.net_start_http)
            }
        }
        status(ServerService.FTP, "ftp", tvFtp, btnFtp, ServerService.ftpPort)
        status(ServerService.HTTP, "http", tvHttp, btnHttp, ServerService.httpPort)
    }

    private fun toggle(kind: String) {
        if (ServerService.isRunning(kind)) {
            startService(
                Intent(this, ServerService::class.java)
                    .setAction(ServerService.ACTION_STOP).putExtra(ServerService.EXTRA_KIND, kind)
            )
            return
        }
        val ip = ServerUtil.localIp()
        if (ip == null) { tvNet.text = getString(R.string.net_no_ip); return }
        val user = etUser.text.toString().trim()
        val pass = etPass.text.toString()
        if (user.isEmpty() || pass.length < 4) { tvNet.text = getString(R.string.net_bad_account); return }
        val port = (if (kind == ServerService.FTP) etFtpPort else etHttpPort).text.toString().toIntOrNull()
        if (port == null || port < 1024 || port > 65535) { tvNet.text = getString(R.string.net_bad_port); return }
        Prefs.setServerAccount(this, user, pass)
        if (kind == ServerService.FTP) Prefs.setFtpPort(this, port) else Prefs.setHttpPort(this, port)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingKind = kind
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else doStart(kind)
    }

    private fun doStart(kind: String) {
        val port = if (kind == ServerService.FTP) Prefs.ftpPort(this) else Prefs.httpPort(this)
        ContextCompat.startForegroundService(
            this,
            Intent(this, ServerService::class.java)
                .setAction(ServerService.ACTION_START)
                .putExtra(ServerService.EXTRA_KIND, kind)
                .putExtra(ServerService.EXTRA_PORT, port)
                .putExtra(ServerService.EXTRA_ROOT, File(Prefs.serverRoot(this)).absolutePath)
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == android.R.id.home) { finish(); true } else super.onOptionsItemSelected(item)
}
