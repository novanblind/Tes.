package com.novan.audiolabnovan.wa;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.AudioRecordingConfiguration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.List;
import java.util.Locale;

/**
 * Mengirim hasil audio sebagai pesan suara WhatsApp / WhatsApp Business:
 * mulai merekam (beberapa cara bergantian, dengan pemeriksaan setiap kali), kunci perekaman,
 * putar audio lewat speaker, lalu tekan kirim.
 */
public class WaAccessibilityService extends AccessibilityService {

    static volatile WaAccessibilityService instance;

    private static final long ARM_TIMEOUT_MS = 300000L;

    private static final String A_HOLD_ACTION = "tahan tombol rekam lalu aksi 'usap ke atas'";
    private static final String A_LONG_ACTION = "tekan lama (aksi) lalu aksi 'usap ke atas'";
    private static final String A_ACTION_ONLY = "aksi 'usap ke atas' saja";
    private static final String A_CLICK = "klik tombol rekam";
    private static final String A_DTAP = "ketuk dua kali lalu tahan dan geser";
    private static final String A_DTAP2 = "ketuk dua kali pelan lalu tahan dan geser";
    private static final String A_SWIPE = "tahan dan geser ke atas";
    private static final String A_SWIPE_SLOW = "tahan lama dan geser pelan";
    private static final String A_LEGACY = "geser lambat (Android 7)";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean armed = false;
    private String targetPkg = null;
    private boolean sawNonChat = false;
    private boolean busy = false;
    private boolean recordingConfirmed = false;
    private int session = 0;
    private MediaPlayer player;

    private float btnX, btnY;
    private final List<String> attempts = new ArrayList<>();
    private int attemptIdx = 0;
    private Set<String> baseline = null;
    private int micBaseline = 0;
    private StringBuilder report = new StringBuilder();
    private long reportStart = 0;

    private final Runnable check = new Runnable() {
        @Override public void run() { checkNow(); }
    };

    private final Runnable timeout = new Runnable() {
        @Override public void run() {
            if (armed && !busy) {
                armed = false;
                Say.say(WaAccessibilityService.this, "Waktu menunggu obrolan WhatsApp habis. Pengiriman otomatis dibatalkan.");
            }
        }
    };

    private interface Pred {
        boolean test(AccessibilityNodeInfo n);
    }

    // ------------------------------------------------------------------
    // Siklus layanan
    // ------------------------------------------------------------------
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        resetState();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        resetState();
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!armed) return;
        if (statusMode && event != null && event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence cn = event.getClassName();
            CharSequence ep = event.getPackageName();
            if (cn != null && ep != null && ep.toString().equals(targetPkg) && cn.toString().contains("Activity")) {
                lastClass = cn.toString();
            }
        }
        if (busy) return;
        if (!sawNonChat) {
            // Tandai segera saat layar tanpa tombol rekam (daftar obrolan) terlihat, supaya tidak terlewat jika
            // pengguna cepat membuka obrolan sebelum pemeriksaan tertunda berjalan.
            AccessibilityNodeInfo r = getRootInActiveWindow();
            CharSequence p = r == null ? null : r.getPackageName();
            if (p != null && (targetPkg == null || targetPkg.equals(p.toString())) && findVoiceButton(r) == null) {
                sawNonChat = true;
            }
        }
        handler.removeCallbacks(check);
        handler.postDelayed(check, 900);
    }

    // ------------------------------------------------------------------
    // Pemicu dari aplikasi / notifikasi
    // ------------------------------------------------------------------
    public static boolean isRunning() {
        return instance != null;
    }

    /** Siaga untuk satu aplikasi WhatsApp saja (com.whatsapp atau com.whatsapp.w4b). */
    public static boolean arm(android.content.Context c, final String targetPackage) {
        final WaAccessibilityService s = instance;
        if (s == null) return false;
        s.handler.post(new Runnable() {
            @Override public void run() { s.doArm(targetPackage); }
        });
        return true;
    }

    public static void disarmFromUi() {
        final WaAccessibilityService s = instance;
        if (s == null) return;
        s.handler.post(new Runnable() {
            @Override public void run() {
                if (s.armed && !s.busy) {
                    s.resetState();
                    Say.say(s, "Pengiriman otomatis dibatalkan.");
                }
            }
        });
    }

    private void doArm(String targetPackage) {
        if (busy) {
            Say.say(this, "Pesan suara sedang dikirim.");
            return;
        }
        if (WaKirim.uriTerakhir(this) == null) {
            Say.say(this, "Belum ada audio yang dibuat.");
            return;
        }
        targetPkg = targetPackage;
        statusMode = false;
        // Pengiriman baru dimulai setelah layar tanpa tombol rekam (daftar obrolan) terlihat dulu, lalu pengguna
        // membuka sebuah obrolan. Ini mencegah WhatsApp yang kebetulan terbuka di obrolan lama langsung merekam.
        sawNonChat = false;
        armed = true;
        handler.removeCallbacks(timeout);
        handler.postDelayed(timeout, ARM_TIMEOUT_MS);
        handler.removeCallbacks(check);
        handler.postDelayed(check, 1800);
    }

    private void resetState() {
        session++;
        statusMode = false;
        holdPhase = 0;
        armed = false;
        busy = false;
        recordingConfirmed = false;
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    // ------------------------------------------------------------------
    // Catatan teknis internal (tidak disimpan)
    // ------------------------------------------------------------------
    private void log(String msg) {
        if (report.length() > 40000) return;
        long t = reportStart == 0 ? 0 : SystemClock.uptimeMillis() - reportStart;
        report.append('[').append(t).append("ms] ").append(msg).append('\n');
    }

    /** Jumlah perekaman mikrofon aktif di sistem (tidak bergantung pada tampilan WhatsApp). -1 jika tidak bisa dibaca. */
    private int micCount() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            List<AudioRecordingConfiguration> l = am.getActiveRecordingConfigurations();
            return l == null ? 0 : l.size();
        } catch (Exception e) {
            return -1;
        }
    }

    private boolean micActive() {
        int c = micCount();
        return c >= 0 && c > micBaseline;
    }

    private String micInfo() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            List<AudioRecordingConfiguration> l = am.getActiveRecordingConfigurations();
            StringBuilder sb = new StringBuilder();
            if (l != null) for (AudioRecordingConfiguration c : l) sb.append(c.getClientAudioSource()).append(' ');
            return "aktif=" + (l == null ? 0 : l.size()) + " dasar=" + micBaseline + " sumber=[" + sb.toString().trim() + "]";
        } catch (Exception e) {
            return "tidak terbaca (" + e + ")";
        }
    }

    private static boolean isWa(AccessibilityNodeInfo root) {
        CharSequence p = root.getPackageName();
        return p != null && p.toString().startsWith("com.whatsapp");
    }

    /** Elemen bagian bawah layar (area ketik/rekam) sebagai himpunan "id|deskripsi|tampak". */
    private Set<String> footerKeys(AccessibilityNodeInfo root) {
        Set<String> keys = new LinkedHashSet<>();
        int top = (int) (getResources().getDisplayMetrics().heightPixels * 0.80f);
        LinkedList<AccessibilityNodeInfo> q = new LinkedList<>();
        q.add(root);
        int visited = 0;
        while (!q.isEmpty() && visited < 800) {
            AccessibilityNodeInfo n = q.removeFirst();
            visited++;
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            String id = n.getViewIdResourceName();
            CharSequence d = n.getContentDescription();
            if (r.top >= top && (id != null || d != null) && (id == null || !id.contains("navigationBar"))) {
                String sid = id == null ? "-" : id.substring(id.indexOf('/') + 1);
                keys.add(sid + "|" + (d == null ? "" : clip(d)) + "|" + (n.isVisibleToUser() ? "tampak" : "tersembunyi"));
            }
            int c = n.getChildCount();
            for (int i = 0; i < c; i++) {
                AccessibilityNodeInfo ch = n.getChild(i);
                if (ch != null) q.add(ch);
            }
        }
        return keys;
    }

    private int footerDiffCount(AccessibilityNodeInfo root) {
        if (baseline == null || !isWa(root)) return 0;
        Set<String> now = footerKeys(root);
        int c = 0;
        for (String k : now) if (!baseline.contains(k)) c++;
        for (String k : baseline) if (!now.contains(k)) c++;
        return c;
    }

    /** Perekaman mulai: tampilan kirim terdeteksi, atau bagian bawah layar berubah dibanding sebelum merekam. */
    private boolean recordingStarted(AccessibilityNodeInfo root) {
        return micActive() || isRecordingUi(root) || footerDiffCount(root) >= 2;
    }

    private void dumpTree(String label) {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) { log(label + ": jendela aktif tidak terbaca"); return; }
            CharSequence pkgCs = root.getPackageName();
            String pkg = pkgCs == null ? "?" : pkgCs.toString();
            StringBuilder sb = new StringBuilder();
            sb.append(label).append(" | paket=").append(pkg).append(" | mikrofon ").append(micInfo()).append('\n');
            if (isWa(root)) {
                Set<String> now = footerKeys(root);
                if (baseline == null) {
                    baseline = now;
                    int n = 0;
                    for (String k : now) { if (n++ < 40) sb.append("  ").append(k).append('\n'); }
                } else {
                    int n = 0;
                    for (String k : now) if (!baseline.contains(k) && n++ < 30) sb.append("  + ").append(k).append('\n');
                    for (String k : baseline) if (!now.contains(k) && n++ < 30) sb.append("  - ").append(k).append('\n');
                    if (n == 0) sb.append("  (bagian bawah layar sama seperti sebelum merekam)\n");
                }
            } else {
                LinkedList<AccessibilityNodeInfo> q = new LinkedList<>();
                q.add(root);
                int shown = 0, visited = 0;
                while (!q.isEmpty() && shown < 30 && visited < 400) {
                    AccessibilityNodeInfo n = q.removeFirst();
                    visited++;
                    CharSequence d = n.getContentDescription();
                    CharSequence tx = n.getText();
                    if (d != null || tx != null) {
                        sb.append("  ");
                        if (d != null) sb.append("d=\"").append(clip(d)).append("\" ");
                        if (tx != null) sb.append("t=\"").append(clip(tx)).append("\" ");
                        sb.append('\n');
                        shown++;
                    }
                    int c = n.getChildCount();
                    for (int i = 0; i < c; i++) {
                        AccessibilityNodeInfo ch = n.getChild(i);
                        if (ch != null) q.add(ch);
                    }
                }
            }
            log(sb.toString());
        } catch (Exception e) {
            log(label + ": gagal membaca layar (" + e + ")");
        }
    }

    private static String clip(CharSequence c) {
        String s = c.toString().replace('\n', ' ');
        return s.length() > 40 ? s.substring(0, 40) + "…" : s;
    }

    private boolean touchExploration() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            return am != null && am.isTouchExplorationEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Alur pengiriman
    // ------------------------------------------------------------------
    private void checkNow() {
        if (!armed || busy) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        CharSequence pkg = root.getPackageName();
        if (pkg == null) return;
        // Hanya aplikasi yang dipilih pengguna (WhatsApp atau WhatsApp Business).
        if (targetPkg != null ? !targetPkg.equals(pkg.toString()) : !pkg.toString().startsWith("com.whatsapp")) return;
        if (statusMode) { checkStatus(root); return; }
        if (findVoiceButton(root) == null) {
            sawNonChat = true; // daftar obrolan / layar lain: pengguna sedang mencari obrolan
            return;
        }
        if (!sawNonChat) return; // masih di obrolan lama yang terbuka; tunggu pengguna memilih obrolan

        busy = true;
        report = new StringBuilder();
        reportStart = SystemClock.uptimeMillis();
        log("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), " + Build.MANUFACTURER + " " + Build.MODEL
                + ", " + pkg + ", pembaca layar/jelajah sentuh=" + touchExploration());
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am != null) {
                for (AccessibilityServiceInfo i : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                    log("layanan aksesibilitas aktif: " + i.getId() + " umpan=" + i.feedbackType + " flags=" + i.flags
                            + " kemampuan=" + i.getCapabilities());
                }
            }
        } catch (Exception e) {
            log("gagal membaca daftar layanan: " + e);
        }
        handler.removeCallbacks(timeout);
        Say.say(this, "Mengirim pesan suara ke obrolan ini. Mohon tunggu.");
        final int sid = session;
        // Beri waktu agar pengumuman pembaca layar selesai sebelum perekaman dimulai.
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) startRecordingFlow(); }
        }, 2400);
    }

    private void startRecordingFlow() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo btn = root == null ? null : findVoiceButton(root);
        if (btn == null) {
            dumpTree("tombol rekam hilang");
            fail("Tombol rekam WhatsApp tidak ditemukan. Pastikan kolom chat kosong.");
            return;
        }
        Rect r = new Rect();
        btn.getBoundsInScreen(r);
        btnX = r.exactCenterX();
        btnY = r.exactCenterY();
        log("tombol rekam di " + r.toShortString());
        log("aksi tombol rekam: " + actionLabels(btn));
        log("deskripsi lengkap tombol rekam: " + btn.getContentDescription());
        baseline = null;
        micBaseline = Math.max(0, micCount());
        dumpTree("sebelum merekam");

        attempts.clear();
        boolean te = touchExploration();
        if (Build.VERSION.SDK_INT >= 26) {
            if (te) {
                attempts.add(A_DTAP);
                attempts.add(A_DTAP2);
                attempts.add(A_SWIPE);
                attempts.add(A_CLICK);
                attempts.add(A_LONG_ACTION);
            } else {
                attempts.add(A_SWIPE);
                attempts.add(A_SWIPE_SLOW);
                attempts.add(A_CLICK);
                attempts.add(A_LONG_ACTION);
            }
        } else {
            attempts.add(A_LEGACY);
            attempts.add(A_CLICK);
        }
        attemptIdx = 0;
        runAttempt();
    }

    private void nextAttempt(final int sid) {
        if (sid != session) return;
        attemptIdx++;
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) runAttempt(); }
        }, 1300);
    }

    private void runAttempt() {
        final int sid = session;
        if (attemptIdx >= attempts.size()) {
            dumpTree("semua cara gagal");
            fail("Perekaman di WhatsApp tidak mau mulai. Pastikan WhatsApp sudah diberi izin mikrofon dan tidak sedang dipakai merekam.");
            return;
        }
        String a = attempts.get(attemptIdx);
        log("percobaan " + (attemptIdx + 1) + ": " + a);

        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo btn = root == null ? null : findVoiceButton(root);
        if (btn == null) {
            if (root != null && recordingStarted(root)) { onRecording(sid); return; }
            dumpTree("tombol rekam tidak ada saat percobaan");
            nextAttempt(sid);
            return;
        }
        Rect r = new Rect();
        btn.getBoundsInScreen(r);
        btnX = r.exactCenterX();
        btnY = r.exactCenterY();

        if (A_HOLD_ACTION.equals(a)) {
            holdThenAction(sid);
        } else if (A_LONG_ACTION.equals(a)) {
            boolean ok = btn.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK);
            log("ACTION_LONG_CLICK hasil=" + ok);
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (sid != session) return;
                    performUpAction();
                    pollRecording(sid, SystemClock.uptimeMillis() + 2000);
                }
            }, 1100);
        } else if (A_ACTION_ONLY.equals(a)) {
            performUpAction();
            pollRecording(sid, SystemClock.uptimeMillis() + 2000);
        } else if (A_CLICK.equals(a)) {
            boolean ok = clickNode(btn);
            log("ACTION_CLICK hasil=" + ok);
            pollRecording(sid, SystemClock.uptimeMillis() + 2200);
        } else if (A_DTAP.equals(a)) {
            focusThen(sid, btn, 120, 1200, 500, 220);
        } else if (A_DTAP2.equals(a)) {
            focusThen(sid, btn, 260, 1500, 700, 240);
        } else if (A_SWIPE.equals(a)) {
            holdSwipe(sid, false, 0, 1100, 450, 200);
        } else if (A_SWIPE_SLOW.equals(a)) {
            holdSwipe(sid, false, 0, 1700, 900, 280);
        } else {
            legacySwipe(sid);
        }
    }

    /** Tahan jari di tombol rekam 1,1 detik, lalu (jari masih menahan) jalankan aksi "usap ke atas". */
    private void holdThenAction(final int sid) {
        float density = getResources().getDisplayMetrics().density;
        final float cx = btnX, cy = btnY;
        final float cancelX = Math.max(cx - 260f * density, 10f * density);
        Path hold = new Path();
        hold.moveTo(cx, cy);
        final GestureDescription.StrokeDescription s1 = new GestureDescription.StrokeDescription(hold, 0, 1100, true);
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(s1).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                performUpAction();
                pollLock(sid, s1, cx, cy, cy, cancelX, SystemClock.uptimeMillis() + 1500);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                log("gerakan tahan dibatalkan sistem");
                nextAttempt(sid);
            }
        }, null);
        log("dispatchGesture tahan (untuk aksi) diterima=" + ok);
        if (!ok) nextAttempt(sid);
    }

    /** Menjalankan aksi aksesibilitas khusus "usap ke atas" (kunci perekaman) pada tombol rekam. */
    private boolean performUpAction() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo btn = root == null ? null : findVoiceButton(root);
        if (btn == null) { log("aksi usap ke atas: tombol rekam tidak ada"); return false; }
        AccessibilityNodeInfo cur = btn;
        for (int i = 0; cur != null && i < 4; i++) {
            for (AccessibilityNodeInfo.AccessibilityAction a : cur.getActionList()) {
                CharSequence l = a.getLabel();
                if (l == null) continue;
                String t = l.toString().toLowerCase(Locale.ROOT);
                if (t.contains("usap ke atas") || t.contains("swipe up") || t.contains("geser ke atas")
                        || t.contains("slide up") || t.contains("kunci") || t.contains("lock")) {
                    boolean ok = cur.performAction(a.getId());
                    log("aksi \"" + l + "\" dijalankan, hasil=" + ok);
                    return ok;
                }
            }
            cur = cur.getParent();
        }
        log("aksi usap ke atas tidak ditemukan; aksi tombol: " + actionLabels(btn));
        return false;
    }

    private static String actionLabels(AccessibilityNodeInfo n) {
        StringBuilder sb = new StringBuilder();
        for (AccessibilityNodeInfo.AccessibilityAction a : n.getActionList()) {
            CharSequence l = a.getLabel();
            sb.append(l != null ? l.toString() : ("#" + a.getId())).append("; ");
        }
        return sb.toString();
    }

    /** Menunggu sampai tampilan perekaman muncul; kalau tidak, lanjut ke cara berikutnya. */
    private void pollRecording(final int sid, final long until) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (sid != session) return;
                AccessibilityNodeInfo root = getRootInActiveWindow();
                if (root != null && recordingStarted(root)) { onRecording(sid); return; }
                if (SystemClock.uptimeMillis() >= until) {
                    log("perekaman tidak terdeteksi");
                    dumpTree("setelah percobaan");
                    nextAttempt(sid);
                    return;
                }
                pollRecording(sid, until);
            }
        }, 250);
    }

    /** Mode jelajah sentuh: beri fokus aksesibilitas ke tombol dulu, lalu ketuk dua kali dan tahan. */
    private void focusThen(final int sid, AccessibilityNodeInfo btn, final long gap, final long hold, final long swipe, final float dist) {
        boolean f = btn.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
        log("fokus aksesibilitas ke tombol rekam hasil=" + f);
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) holdSwipe(sid, true, gap, hold, swipe, dist); }
        }, 500);
    }

    // Tahan tombol rekam (opsional didahului ketuk pertama untuk mode jelajah sentuh), geser ke atas,
    // periksa apakah terkunci, lalu lepas. Jika tidak terkunci, batalkan lewat geser ke kiri supaya tidak terkirim kosong.
    private void holdSwipe(final int sid, boolean doubleTap, long gapMs, long holdMs, final long swipeMs, float distDp) {
        if (Build.VERSION.SDK_INT < 26) { legacySwipe(sid); return; }
        float density = getResources().getDisplayMetrics().density;
        final float cx = btnX, cy = btnY;
        final float endY = Math.max(cy - distDp * density, 30f * density);

        GestureDescription.Builder b = new GestureDescription.Builder();
        long start = 0;
        if (doubleTap) {
            Path tap = new Path();
            tap.moveTo(cx, cy);
            b.addStroke(new GestureDescription.StrokeDescription(tap, 0, 60));
            start = 60 + gapMs;
        }
        // Jari digeser 1 piksel selama menahan supaya sistem membuat kejadian sentuh sepanjang durasi (jalur diam kadang selesai seketika).
        final float cx1 = cx + 1f;
        Path hold = new Path();
        hold.moveTo(cx, cy);
        hold.lineTo(cx1, cy);
        final GestureDescription.StrokeDescription s1 = new GestureDescription.StrokeDescription(hold, start, holdMs, true);
        b.addStroke(s1);
        final float cancelX = Math.max(cx - 260f * density, 10f * density);
        final long t0 = SystemClock.uptimeMillis();
        final long expect = start + holdMs;
        boolean ok = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                log("gerakan tahan selesai setelah " + (SystemClock.uptimeMillis() - t0) + "ms (seharusnya sekitar " + expect + "ms)");
                dumpTree("saat jari menahan tombol");
                afterHold(sid, s1, cx1, cy, endY, swipeMs, cancelX);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                log("gerakan tahan dibatalkan sistem");
                nextAttempt(sid);
            }
        }, null);
        log("dispatchGesture tahan diterima=" + ok);
        if (!ok) nextAttempt(sid);
    }

    private void afterHold(final int sid, GestureDescription.StrokeDescription s1, final float cx, final float cy,
                           final float endY, long swipeMs, final float cancelX) {
        Path up = new Path();
        up.moveTo(cx, cy);
        up.lineTo(cx, endY);
        final GestureDescription.StrokeDescription s2 = s1.continueStroke(up, 0, swipeMs, true);
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(s2).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                pollLock(sid, s2, cx, cy, endY, cancelX, SystemClock.uptimeMillis() + 1300);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                log("gerakan geser dibatalkan sistem");
                nextAttempt(sid);
            }
        }, null);
        log("dispatchGesture geser diterima=" + ok);
        if (!ok) nextAttempt(sid);
    }

    private void pollLock(final int sid, final GestureDescription.StrokeDescription s2, final float cx, final float cy,
                          final float endY, final float cancelX, final long until) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (sid != session) return;
                AccessibilityNodeInfo root = getRootInActiveWindow();
                boolean late = SystemClock.uptimeMillis() >= until;
                boolean started = micActive() || (root != null && (isRecordingUi(root) || (late && recordingStarted(root))));
                if (started) {
                    log("perekaman terdeteksi, jari dilepas | mikrofon " + micInfo());
                    dumpTree("saat melepas jari");
                    Path stay = new Path();
                    stay.moveTo(cx, endY);
                    GestureDescription.StrokeDescription s3 = s2.continueStroke(stay, 0, 40, false);
                    dispatchGesture(new GestureDescription.Builder().addStroke(s3).build(), null, null);
                    // Tanpa pemeriksaan lanjutan: hitung jeda 1 detik sejak perekaman terdeteksi, lalu bunyikan audio.
                    onRecording(sid);
                    return;
                }
                if (SystemClock.uptimeMillis() >= until) {
                    log("tidak terkunci setelah menggeser; membatalkan rekaman");
                    dumpTree("setelah menggeser");
                    Path back = new Path();
                    back.moveTo(cx, endY);
                    back.lineTo(cx, cy);
                    back.lineTo(cancelX, cy);
                    GestureDescription.StrokeDescription s3 = s2.continueStroke(back, 0, 800, false);
                    boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(s3).build(), new GestureResultCallback() {
                        @Override public void onCompleted(GestureDescription g) { nextAttempt(sid); }
                        @Override public void onCancelled(GestureDescription g) { nextAttempt(sid); }
                    }, null);
                    if (!ok) nextAttempt(sid);
                    return;
                }
                pollLock(sid, s2, cx, cy, endY, cancelX, until);
            }
        }, 150);
    }

    /** Setelah jari dilepas: jika perekaman masih berjalan berarti terkunci; jika berhenti berarti tidak terkunci. */
    private void verifyLocked(final int sid) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (sid != session) return;
                AccessibilityNodeInfo root = getRootInActiveWindow();
                boolean unsupported = micCount() < 0;
                boolean locked = unsupported || micActive() || (root != null && isRecordingUi(root));
                if (locked) {
                    log("perekaman masih berjalan setelah jari dilepas: terkunci");
                    onRecording(sid);
                } else {
                    log("perekaman berhenti setelah jari dilepas: tidak terkunci | mikrofon " + micInfo());
                    dumpTree("setelah dilepas");
                    nextAttempt(sid);
                }
            }
        }, 400);
    }

    private void legacySwipe(final int sid) {
        float density = getResources().getDisplayMetrics().density;
        Path p = new Path();
        p.moveTo(btnX, btnY);
        p.lineTo(btnX, Math.max(btnY - 200f * density, 40f * density));
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(p, 0, 1700);
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                pollRecording(sid, SystemClock.uptimeMillis() + 1500);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                nextAttempt(sid);
            }
        }, null);
        if (!ok) nextAttempt(sid);
    }

    private void onRecording(final int sid) {
        if (sid != session || recordingConfirmed) return;
        recordingConfirmed = true;
        log("perekaman WhatsApp berjalan (tampilan kirim terdeteksi)");
        // Jeda sesuai pengaturan (bawaan 500 md) sejak perekaman terdeteksi, lalu putar audio lewat speaker.
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) playAudio(sid); }
        }, Math.max(0, Math.min(10000, getSharedPreferences("wa_kirim", MODE_PRIVATE).getInt("wa_gap_ms", 500))));
    }

    private void playAudio(final int sid) {
        Uri uri = WaKirim.uriTerakhir(this);
        if (uri == null) {
            fail("Berkas audio tidak ditemukan.");
            return;
        }
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            mp.setDataSource(getApplicationContext(), uri);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    try { m.release(); } catch (Exception ignored) { }
                    player = null;
                    log("audio selesai diputar");
                    handler.post(new Runnable() {
                        @Override public void run() { if (sid == session) clickSend(sid, 0); }
                    });
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    fail("Gagal memutar audio untuk direkam.");
                    return true;
                }
            });
            mp.prepare();
            mp.start();
            log("audio mulai diputar");
        } catch (Exception e) {
            log("pemutaran gagal: " + e);
            fail("Gagal memutar audio untuk direkam.");
        }
    }

    private void clickSend(final int sid, final int tries) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo send = root == null ? null : findSendButton(root);
        if (send != null) {
            boolean ok = clickNode(send);
            log("tombol kirim ditemukan, ACTION_CLICK hasil=" + ok);
            if (!ok) {
                Rect r = new Rect();
                send.getBoundsInScreen(r);
                tapAt(r.exactCenterX(), r.exactCenterY());
            }
        } else {
            log("tombol kirim tidak ditemukan; mencoba elemen di posisi tombol rekam semula");
            dumpTree("mencari tombol kirim");
            AccessibilityNodeInfo alt = root == null ? null : byIds(root,
                    "com.whatsapp.w4b:id/voice_note_btn", "com.whatsapp:id/voice_note_btn",
                    "com.whatsapp.w4b:id/conversation_entry_action_button", "com.whatsapp:id/conversation_entry_action_button",
                    "com.whatsapp.w4b:id/send_container", "com.whatsapp:id/send_container");
            boolean okAlt = alt != null && clickNode(alt);
            log("klik elemen alternatif hasil=" + okAlt);
            if (!okAlt) tapAt(btnX, btnY);
        }
        // Tanpa pemeriksaan hasil: begitu audio selesai, tombol kirim ditekan sekali lalu selesai.
        log("tombol kirim ditekan, selesai");
        Say.say(WaAccessibilityService.this, "Pesan suara dikirim.");
        resetState();
    }

    private void tapAt(float x, float y) {
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.Builder gb = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, 60));
            // Mode jelajah sentuh: satu ketukan hanya memilih elemen, jadi ketuk dua kali.
            if (touchExploration()) gb.addStroke(new GestureDescription.StrokeDescription(p, 180, 60));
            GestureDescription g = gb.build();
            boolean ok = dispatchGesture(g, null, null);
            log("ketuk layar di (" + (int) x + "," + (int) y + ") diterima=" + ok);
        } catch (Exception e) {
            log("ketuk layar gagal: " + e);
        }
    }

    private void fail(String msg) {
        log("GAGAL: " + msg);
        String nama = WaKirim.namaTerakhir(this);
        Say.say(this, msg);
        com.novan.audiolabnovan.gemini.GeminiJagaService.selesai(this, "Audio tersimpan: " + nama,
                msg + " Anda bisa mencoba lagi atau membagikan audio ini secara manual.");
        resetState();
    }

    // ------------------------------------------------------------------
    // Pencarian node
    // ------------------------------------------------------------------
    private static AccessibilityNodeInfo byIds(AccessibilityNodeInfo root, String... ids) {
        for (String id : ids) {
            try {
                List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByViewId(id);
                if (list != null) {
                    for (AccessibilityNodeInfo n : list) {
                        if (n != null && n.isVisibleToUser()) return n;
                    }
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static AccessibilityNodeInfo dfs(AccessibilityNodeInfo n, int depth, Pred p) {
        if (n == null || depth > 40) return null;
        if (p.test(n)) return n;
        int count = n.getChildCount();
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo child = n.getChild(i);
            AccessibilityNodeInfo found = dfs(child, depth + 1, p);
            if (found != null) return found;
        }
        return null;
    }

    private static String descOf(AccessibilityNodeInfo n) {
        CharSequence d = n.getContentDescription();
        return d == null ? "" : d.toString().trim().toLowerCase(Locale.ROOT);
    }

    private static boolean descEquals(AccessibilityNodeInfo n, String... options) {
        String s = descOf(n);
        if (s.isEmpty()) return false;
        for (String o : options) {
            if (s.equals(o)) return true;
        }
        return false;
    }

    private static boolean looksLikeSend(AccessibilityNodeInfo n) {
        String s = descOf(n);
        if (s.isEmpty() || s.length() > 30) return false;
        return s.startsWith("kirim") || s.startsWith("send");
    }

    /** Tombol rekam (mikrofon). Node yang sudah berubah menjadi tombol kirim tidak dihitung. */
    private static AccessibilityNodeInfo findVoiceButton(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = byIds(root,
                "com.whatsapp:id/voice_note_btn", "com.whatsapp.w4b:id/voice_note_btn");
        if (n != null && !looksLikeSend(n)) return n;
        return dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                return x.isVisibleToUser() && (x.isClickable() || x.isLongClickable())
                        && descEquals(x, "pesan suara", "voice message", "rekam pesan suara", "record voice message");
            }
        });
    }

    private static AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = byIds(root,
                "com.whatsapp.w4b:id/draft_send_v2", "com.whatsapp:id/draft_send_v2",
                "com.whatsapp.w4b:id/send", "com.whatsapp:id/send",
                "com.whatsapp.w4b:id/voice_note_btn", "com.whatsapp:id/voice_note_btn");
        if (n != null && looksLikeSend(n)) return n;
        return dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                return x.isVisibleToUser() && looksLikeSend(x);
            }
        });
    }

    /** Tampilan perekaman aktif/terkunci: tombol kirim tampak, atau tombol jeda dan hapus tampak tanpa tombol rekam. */
    private static boolean isRecordingUi(AccessibilityNodeInfo root) {
        CharSequence pkg = root.getPackageName();
        if (pkg == null || !pkg.toString().startsWith("com.whatsapp")) return false;
        if (findSendButton(root) != null) return true;
        if (findVoiceButton(root) != null) return false;
        AccessibilityNodeInfo pause = dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                return x.isVisibleToUser() && descEquals(x, "jeda", "pause", "jeda perekaman", "pause recording");
            }
        });
        AccessibilityNodeInfo del = dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                return x.isVisibleToUser() && descEquals(x, "hapus", "delete", "hapus perekaman", "delete recording");
            }
        });
        return pause != null && del != null;
    }

    private static boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; cur != null && i < 5; i++) {
            if (cur.isEnabled() && cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            cur = cur.getParent();
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    // ------------------------------------------------------------------
    // Tahap 62: status WhatsApp berupa pesan suara.
    // Tombol rekam ditahan terus (jari tidak diangkat) selama audio diputar, lalu dilepas dan dikirim.
    // ------------------------------------------------------------------
    private static final String S_HOLD = "tahan tombol rekam status";
    private static final String S_DTAP = "ketuk dua kali lalu tahan (status)";
    private static final String S_DTAP2 = "ketuk dua kali pelan lalu tahan (status)";

    private boolean statusMode = false;
    private String lastClass = null;
    private long holdStartAt = 0, micDetectedAt = 0, playStartAt = 0, tailStartAt = 0, playDurMs = 0;
    private int holdPhase = 0;
    private boolean playEnded = false;
    private int statusAttemptIdx = 0;
    private int tabClicks = 0;
    private final List<String> statusAttempts = new ArrayList<>();

    /** Siaga untuk membuat status suara di satu aplikasi WhatsApp (com.whatsapp atau com.whatsapp.w4b). */
    public static boolean armStatus(android.content.Context c, final String targetPackage) {
        final WaAccessibilityService s = instance;
        if (s == null) return false;
        s.handler.post(new Runnable() {
            @Override public void run() { s.doArmStatus(targetPackage); }
        });
        return true;
    }

    private void doArmStatus(String targetPackage) {
        if (busy) {
            Say.say(this, "Pesan suara sedang dikirim.");
            return;
        }
        if (WaKirim.uriTerakhir(this) == null) {
            Say.say(this, "Belum ada audio yang dibuat.");
            return;
        }
        targetPkg = targetPackage;
        statusMode = true;
        lastClass = null;
        tabClicks = 0;
        sawNonChat = true;
        armed = true;
        handler.removeCallbacks(timeout);
        handler.postDelayed(timeout, ARM_TIMEOUT_MS);
        handler.removeCallbacks(check);
        handler.postDelayed(check, 1800);
    }

    private long gapMs() {
        return Math.max(0, Math.min(10000, getSharedPreferences("wa_kirim", MODE_PRIVATE).getInt("wa_gap_ms", 500)));
    }

    private void stopPlayer() {
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    private void checkStatus(AccessibilityNodeInfo root) {
        if (!isStatusPage(root)) return;
        // Halaman status punya tab Foto, Teks, Suara. Pastikan tab Suara yang terbuka (paling banyak dua kali ketuk).
        AccessibilityNodeInfo tab = findTabByText(root, "suara", "voice");
        if (tab != null && !selectedUp(tab) && tabClicks < 2) {
            tabClicks++;
            boolean okTab = clickNode(tab);
            log("memilih tab Suara hasil=" + okTab);
            handler.removeCallbacks(check);
            handler.postDelayed(check, 1200);
            return;
        }
        AccessibilityNodeInfo btn = findStatusMicButton(root);
        if (btn == null) return;
        busy = true;
        report = new StringBuilder();
        reportStart = SystemClock.uptimeMillis();
        log("Status WhatsApp. Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), "
                + Build.MANUFACTURER + " " + Build.MODEL + ", kelas layar=" + lastClass
                + ", pembaca layar/jelajah sentuh=" + touchExploration());
        handler.removeCallbacks(timeout);
        Say.say(this, "Halaman status suara ditemukan. Tombol mikrofon ditahan, audio diputar, lalu status dikirim. Mohon tunggu.");
        final int sid = session;
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) startStatusFlow(sid); }
        }, 2400);
    }

    /** Halaman pembuat status: nama layar memuat "status", atau ada kolom ketik status. */
    private boolean isStatusPage(AccessibilityNodeInfo root) {
        if (lastClass != null && lastClass.toLowerCase(Locale.ROOT).contains("status")) return true;
        AccessibilityNodeInfo hint = dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                StringBuilder sb = new StringBuilder();
                if (x.getText() != null) sb.append(x.getText()).append(' ');
                if (x.getContentDescription() != null) sb.append(x.getContentDescription()).append(' ');
                if (Build.VERSION.SDK_INT >= 26 && x.getHintText() != null) sb.append(x.getHintText());
                String t = sb.toString().toLowerCase(Locale.ROOT);
                return t.contains("ketik status") || t.contains("type a status");
            }
        });
        if (hint != null) return true;
        // Tampilan status: tab Suara dan Teks terlihat bersama di bagian bawah.
        return findTabByText(root, "suara", "voice") != null && findTabByText(root, "teks", "text") != null;
    }

    private static AccessibilityNodeInfo findTabByText(AccessibilityNodeInfo root, final String... names) {
        return dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                if (!x.isVisibleToUser()) return false;
                String t = x.getText() == null ? "" : x.getText().toString().trim().toLowerCase(Locale.ROOT);
                String d = descOf(x);
                for (String n : names) {
                    if (n.equals(t) || n.equals(d)) return true;
                }
                return false;
            }
        });
    }

    /** Elemen atau induk dekatnya berstatus terpilih. */
    private static boolean selectedUp(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; cur != null && i < 4; i++) {
            if (cur.isSelected()) return true;
            cur = cur.getParent();
        }
        return false;
    }

    private static boolean inCorner(Rect r, int w, int h, float fx, float fy) {
        return r.centerX() > w * fx && r.centerY() > h * fy;
    }

    private static boolean looksLikeMic(AccessibilityNodeInfo n) {
        if (looksLikeSend(n)) return false;
        String s = descOf(n);
        String id = n.getViewIdResourceName();
        String idl = id == null ? "" : id.toLowerCase(Locale.ROOT);
        if (idl.contains("voice") || idl.contains("record") || idl.endsWith("mic") || idl.contains("_mic") || idl.contains("mic_")) {
            return !idl.contains("send") && !idl.contains("cancel") && !idl.contains("delete") && !idl.contains("pause");
        }
        if (s.isEmpty() || s.length() > 40) return false;
        if (s.contains("hapus") || s.contains("delete") || s.contains("jeda") || s.contains("pause")
                || s.contains("batal") || s.contains("cancel")) return false;
        return s.contains("suara") || s.contains("voice") || s.contains("mikrofon") || s.contains("microphone")
                || s.contains("rekam") || s.contains("record");
    }

    /**
     * Tombol mikrofon status: di pojok kanan bawah layar (tab Suara tidak ikut karena ada di tengah bawah).
     * Pertama dicari lewat nama atau id, lalu lewat bentuk: elemen bulat kecil di pojok kanan bawah.
     */
    private AccessibilityNodeInfo findStatusMicButton(AccessibilityNodeInfo root) {
        final int w = getResources().getDisplayMetrics().widthPixels;
        final int h = getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo n = dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                if (!x.isVisibleToUser()) return false;
                Rect r = new Rect();
                x.getBoundsInScreen(r);
                if (r.width() <= 0 || r.height() <= 0) return false;
                return inCorner(r, w, h, 0.60f, 0.80f) && looksLikeMic(x);
            }
        });
        if (n != null) return n;
        return dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                if (!x.isVisibleToUser()) return false;
                Rect r = new Rect();
                x.getBoundsInScreen(r);
                if (r.width() < w * 0.06f || r.width() > w * 0.25f) return false;
                if (r.height() < w * 0.06f || r.height() > w * 0.25f) return false;
                if (!inCorner(r, w, h, 0.75f, 0.88f)) return false;
                if (looksLikeSend(x)) return false;
                return x.isClickable() || x.isLongClickable() || x.getChildCount() == 0;
            }
        });
    }

    private static AccessibilityNodeInfo findStatusSendButton(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = findSendButton(root);
        if (n != null) return n;
        return dfs(root, 0, new Pred() {
            @Override public boolean test(AccessibilityNodeInfo x) {
                if (!x.isVisibleToUser()) return false;
                String s = descOf(x);
                if (s.isEmpty() || s.length() > 30) return false;
                return s.startsWith("kirim") || s.startsWith("send") || s.startsWith("bagikan") || s.startsWith("share")
                        || s.startsWith("posting") || s.startsWith("post") || s.startsWith("unggah");
            }
        });
    }

    /** Tombol rekam yang ditahan: tombol mikrofon status (mode status) atau tombol pesan suara obrolan. */
    private AccessibilityNodeInfo findHoldButton(AccessibilityNodeInfo root) {
        return statusMode ? findStatusMicButton(root) : findVoiceButton(root);
    }

    private void startStatusFlow(int sid) {
        if (Build.VERSION.SDK_INT < 26) {
            fail("Menahan tombol rekam otomatis butuh Android 8 ke atas.");
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo btn = root == null ? null : findHoldButton(root);
        if (btn == null) {
            dumpTree("tombol rekam status hilang");
            fail(statusMode ? "Tombol rekam status tidak ditemukan. Buka halaman status yang ada tombol mikrofonnya." : "Tombol rekam WhatsApp tidak ditemukan. Pastikan kolom chat kosong.");
            return;
        }
        Rect r = new Rect();
        btn.getBoundsInScreen(r);
        btnX = r.exactCenterX();
        btnY = r.exactCenterY();
        log("tombol rekam status di " + r.toShortString() + ", id=" + btn.getViewIdResourceName()
                + ", deskripsi=" + btn.getContentDescription());
        baseline = null;
        micBaseline = Math.max(0, micCount());
        dumpTree("sebelum merekam status");
        statusAttempts.clear();
        if (touchExploration()) {
            statusAttempts.add(S_DTAP);
            statusAttempts.add(S_DTAP2);
            statusAttempts.add(S_HOLD);
        } else {
            statusAttempts.add(S_HOLD);
            statusAttempts.add(S_HOLD);
        }
        statusAttemptIdx = 0;
        runStatusAttempt(sid);
    }

    private void nextStatusAttempt(final int sid) {
        if (sid != session) return;
        statusAttemptIdx++;
        handler.postDelayed(new Runnable() {
            @Override public void run() { if (sid == session) runStatusAttempt(sid); }
        }, 1300);
    }

    private void runStatusAttempt(final int sid) {
        if (statusAttemptIdx >= statusAttempts.size()) {
            dumpTree("semua cara gagal (status)");
            fail("Perekaman di WhatsApp tidak mau mulai. Pastikan WhatsApp sudah diberi izin mikrofon dan tidak sedang dipakai merekam.");
            return;
        }
        String a = statusAttempts.get(statusAttemptIdx);
        log("percobaan status " + (statusAttemptIdx + 1) + ": " + a);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo btn = root == null ? null : findHoldButton(root);
        if (btn == null) {
            dumpTree("tombol rekam status tidak ada saat percobaan");
            nextStatusAttempt(sid);
            return;
        }
        Rect r = new Rect();
        btn.getBoundsInScreen(r);
        btnX = r.exactCenterX();
        btnY = r.exactCenterY();
        if (S_HOLD.equals(a)) {
            startStatusHold(sid, false, 0);
        } else {
            final long gap = S_DTAP2.equals(a) ? 260 : 120;
            boolean f = btn.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
            log("fokus aksesibilitas ke tombol rekam status hasil=" + f);
            handler.postDelayed(new Runnable() {
                @Override public void run() { if (sid == session) startStatusHold(sid, true, gap); }
            }, 500);
        }
    }

    /** Mulai menahan jari di tombol rekam; sesudahnya jari terus ditahan lewat potongan gerakan pendek. */
    private void startStatusHold(final int sid, boolean doubleTap, long gapMs) {
        GestureDescription.Builder b = new GestureDescription.Builder();
        long start = 0;
        if (doubleTap) {
            Path tap = new Path();
            tap.moveTo(btnX, btnY);
            b.addStroke(new GestureDescription.StrokeDescription(tap, 0, 60));
            start = 60 + gapMs;
        }
        // Jari digeser 1 piksel supaya sistem membuat kejadian sentuh sepanjang durasi.
        Path hold = new Path();
        hold.moveTo(btnX, btnY);
        hold.lineTo(btnX + 1f, btnY);
        final GestureDescription.StrokeDescription s1 = new GestureDescription.StrokeDescription(hold, start, 600, true);
        b.addStroke(s1);
        final float endX = btnX + 1f;
        holdStartAt = SystemClock.uptimeMillis();
        holdPhase = 0;
        playEnded = false;
        playDurMs = 0;
        micDetectedAt = 0;
        boolean ok = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                holdLoop(sid, s1, endX);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                holdCancelled(sid);
            }
        }, null);
        log("dispatchGesture tahan status diterima=" + ok);
        if (!ok) nextStatusAttempt(sid);
    }

    private void holdCancelled(int sid) {
        log("gerakan tahan status dibatalkan sistem pada fase " + holdPhase);
        stopPlayer();
        if (holdPhase >= 2) {
            fail("Penekanan tombol rekam terputus saat merekam status. Coba lagi.");
        } else {
            nextStatusAttempt(sid);
        }
    }

    /**
     * Satu putaran: periksa fase, lalu kirim potongan gerakan berikutnya (jari tetap menahan) atau lepas jari.
     * Fase 0 menunggu perekaman mulai, 1 jeda, 2 audio diputar, 3 ekor sesudah audio, 4 lepas dan kirim,
     * 8 lepas karena audio gagal, 9 lepas karena perekaman tidak mulai.
     */
    private void holdLoop(final int sid, GestureDescription.StrokeDescription prev, final float curX) {
        if (sid != session) return;
        long now = SystemClock.uptimeMillis();
        if (now - holdStartAt > 150000L && holdPhase < 4) {
            log("batas waktu menahan terlampaui");
            holdPhase = 8;
        }
        if (holdPhase == 0) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            boolean micOk = micActive() || (micCount() < 0 && now - holdStartAt > 1500)
                    || (root != null && isRecordingUi(root));
            if (micOk) {
                holdPhase = 1;
                micDetectedAt = now;
                log("perekaman status terdeteksi | mikrofon " + micInfo());
            } else if (now - holdStartAt > 3500) {
                log("perekaman status tidak terdeteksi; jari dilepas | mikrofon " + micInfo());
                dumpTree("perekaman status tidak mulai");
                holdPhase = 9;
            }
        }
        if (holdPhase == 1 && now - micDetectedAt >= gapMs()) {
            holdPhase = 2;
            if (!playStatus()) holdPhase = 8;
        } else if (holdPhase == 2) {
            if (playEnded || now > playStartAt + playDurMs + 4000) {
                holdPhase = 3;
                tailStartAt = now;
                log("audio status selesai; menahan sebentar lagi");
            }
        } else if (holdPhase == 3 && now - tailStartAt >= 700) {
            holdPhase = 4;
        }

        final boolean last = holdPhase >= 4;
        final float nextX = curX > btnX + 0.5f ? btnX : btnX + 1f;
        Path p = new Path();
        p.moveTo(curX, btnY);
        p.lineTo(nextX, btnY);
        final GestureDescription.StrokeDescription seg = prev.continueStroke(p, 0, last ? 60 : 400, !last);
        final int phaseNow = holdPhase;
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(seg).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (sid != session) return;
                if (!last) {
                    holdLoop(sid, seg, nextX);
                    return;
                }
                log("jari dilepas pada fase " + phaseNow);
                if (phaseNow == 4) {
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { if (sid == session) statusKirim(sid, 0); }
                    }, 1300);
                } else if (phaseNow == 8) {
                    stopPlayer();
                    fail("Gagal memutar audio untuk direkam.");
                } else {
                    stopPlayer();
                    nextStatusAttempt(sid);
                }
            }
            @Override public void onCancelled(GestureDescription g) {
                if (sid != session) return;
                holdCancelled(sid);
            }
        }, null);
        if (!ok) {
            log("dispatchGesture potongan tahan ditolak");
            holdCancelled(sid);
        }
    }

    private boolean playStatus() {
        Uri uri = WaKirim.uriTerakhir(this);
        if (uri == null) {
            log("berkas audio tidak ditemukan");
            return false;
        }
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            mp.setDataSource(getApplicationContext(), uri);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer m) {
                    try { m.release(); } catch (Exception ignored) { }
                    player = null;
                    playEnded = true;
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer m, int what, int extra) {
                    log("galat pemutar " + what + "/" + extra);
                    try { m.release(); } catch (Exception ignored) { }
                    player = null;
                    playEnded = true;
                    return true;
                }
            });
            mp.prepare();
            playDurMs = Math.max(0, mp.getDuration());
            mp.start();
            playStartAt = SystemClock.uptimeMillis();
            playEnded = false;
            log("audio status mulai diputar, durasi " + playDurMs + "ms");
            return true;
        } catch (Exception e) {
            log("pemutaran status gagal: " + e);
            return false;
        }
    }

    private void statusKirim(final int sid, final int tries) {
        if (sid != session) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo send = root == null ? null : findStatusSendButton(root);
        if (send != null) {
            boolean ok = clickNode(send);
            log("tombol kirim status ditemukan, ACTION_CLICK hasil=" + ok);
            if (!ok) {
                Rect r = new Rect();
                send.getBoundsInScreen(r);
                tapAt(r.exactCenterX(), r.exactCenterY());
            }
            Say.say(this, "Status suara dikirim.");
            resetState();
            return;
        }
        if (tries < 10) {
            handler.postDelayed(new Runnable() {
                @Override public void run() { statusKirim(sid, tries + 1); }
            }, 700);
            return;
        }
        dumpTree("tombol kirim status tidak ditemukan");
        fail("Rekaman status selesai, tetapi tombol kirim tidak ditemukan. Bila status belum terkirim, tekan Kirim di WhatsApp sendiri.");
    }
}
