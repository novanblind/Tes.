package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        TTGuard.periksa(this);
        if (Store.token(this).isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        Ui ui = new Ui(this, "GitHub by novan");
        ui.button("1. Repositori saya", v -> startActivity(new Intent(this, ReposActivity.class)));
        ui.button("2. Cari repositori", v -> startActivity(new Intent(this, SearchActivity.class)));
        ui.button("3. Lihat rilis repositori mana pun (tautan unduhan)", v -> ui.prompt(
                "Rilis repositori", "username/nama-repo atau tautan GitHub-nya", "", t -> {
                    String full = RilisDaftarActivity.parseRepo(t);
                    if (full == null) {
                        ui.say("Format salah. Tulis username/nama-repo, contoh novanblind/Aplikasi-github-Novan.");
                        return;
                    }
                    startActivity(RilisDaftarActivity.of(this, full, full).putExtra("baca", true));
                }));
        ui.button("4. Buat repositori baru", v -> startActivity(new Intent(this, CreateRepoActivity.class)));
        ui.button("5. Situs web (GitHub Pages)", v -> startActivity(new Intent(this, SitusActivity.class)));
        ui.button("6. Salin token saya", v -> Ui.copy(this, "Token GitHub", Store.token(this)));
        ui.button("7. Buat token di web", v -> Ui.browse(this, LoginActivity.URL_TOKEN));
        ui.button("8. Pengaturan bangun APK (tanda tangan dan keamanan bawaan)", v ->
                startActivity(new Intent(this, PengaturanBangunActivity.class)));
        ui.button("9. Keluar akun", Ui.DANGER, v ->
                ui.confirm("Keluar akun?", "Token akan dihapus dari aplikasi ini.", "keluar", () -> {
                    Store.clear(this);
                    ReposActivity.invalidate();
                    startActivity(new Intent(this, LoginActivity.class));
                    finish();
                }));
    }
}
