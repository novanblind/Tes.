package com.novan.filemanagermax

import android.content.Context
import android.net.Uri
import android.text.format.Formatter
import android.util.Base64
import android.webkit.MimeTypeMap
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Server HTTP sederhana untuk mengakses berkas dari peramban PC: lihat folder, unduh,
 * unggah, buat folder, dan hapus. Dilindungi sandi (Basic auth).
 */
class HttpServer(
    private val ctx: Context,
    private val root: File,
    private val port: Int,
    private val user: String,
    private val pass: String
) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        running = true
        pool.execute {
            while (running) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        pool.shutdownNow()
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > 16384) return null
        }
        return sb.toString()
    }

    private fun send(
        o: OutputStream, code: Int, text: String, type: String, body: ByteArray,
        extra: String = ""
    ) {
        val head = "HTTP/1.1 $code $text\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\n" +
            "Connection: close\r\n$extra\r\n"
        o.write(head.toByteArray(Charsets.UTF_8))
        o.write(body)
        o.flush()
    }

    private fun page(o: OutputStream, code: Int, text: String, msg: String, extra: String = "") =
        send(o, code, text, "text/plain; charset=utf-8", msg.toByteArray(Charsets.UTF_8), extra)

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 60000
            val i = sock.getInputStream().buffered()
            val o = sock.getOutputStream().buffered()
            val first = readLine(i) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val headers = HashMap<String, String>()
            while (true) {
                val l = readLine(i) ?: break
                if (l.isEmpty()) break
                val c = l.indexOf(':')
                if (c > 0) headers[l.substring(0, c).trim().lowercase()] = l.substring(c + 1).trim()
            }
            val expected = "Basic " + Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
            if (headers["authorization"] != expected) {
                page(o, 401, "Unauthorized", "Perlu masuk",
                    "WWW-Authenticate: Basic realm=\"File Manager Max\"\r\n")
                return
            }
            val rawTarget = parts[1]
            val q = rawTarget.indexOf('?')
            val rawPath = if (q < 0) rawTarget else rawTarget.substring(0, q)
            val query = if (q < 0) "" else rawTarget.substring(q + 1)
            val vpath = ServerUtil.normalize("/", Uri.decode(rawPath))
            val f = ServerUtil.fileOf(root, vpath)
            when (method) {
                "GET", "HEAD" -> {
                    if (!f.exists()) page(o, 404, "Not Found", "Tidak ditemukan")
                    else if (f.isDirectory) {
                        send(o, 200, "OK", "text/html; charset=utf-8", listing(vpath, f).toByteArray(Charsets.UTF_8))
                    } else sendFile(o, f, headers["range"], method == "HEAD")
                }
                "PUT" -> {
                    val len = headers["content-length"]?.toLongOrNull()
                    if (len == null) { page(o, 411, "Length Required", "Perlu Content-Length"); return }
                    if (f.isDirectory || f.parentFile?.isDirectory != true) {
                        page(o, 409, "Conflict", "Folder tujuan tidak ada"); return
                    }
                    val target = if (f.exists()) FileOps.uniqueTarget(f.parentFile!!, f.name) else f
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var left = len
                        while (left > 0) {
                            val n = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (n < 0) break
                            out.write(buf, 0, n)
                            left -= n
                        }
                    }
                    page(o, 201, "Created", "OK")
                }
                "POST" -> {
                    val name = queryParam(query, "mkdir")
                    if (name.isNullOrBlank() || name.contains("/") || !f.isDirectory) {
                        page(o, 400, "Bad Request", "Permintaan tidak valid")
                    } else if (File(f, name).mkdirs()) page(o, 201, "Created", "OK")
                    else page(o, 409, "Conflict", "Gagal membuat folder")
                }
                "DELETE" -> {
                    if (vpath == "/" || !f.exists()) page(o, 404, "Not Found", "Tidak ditemukan")
                    else {
                        val ok = if (Prefs.useTrash(ctx)) TrashManager.trash(f) else f.deleteRecursively()
                        if (ok) page(o, 200, "OK", "OK") else page(o, 500, "Error", "Gagal menghapus")
                    }
                }
                else -> page(o, 405, "Method Not Allowed", "Tidak didukung")
            }
        } catch (e: Exception) {
            // koneksi putus
        } finally {
            try { sock.close() } catch (e: Exception) { }
        }
    }

    private fun queryParam(query: String, key: String): String? {
        for (p in query.split("&")) {
            val kv = p.split("=", limit = 2)
            if (kv[0] == key) return if (kv.size > 1) Uri.decode(kv[1].replace("+", " ")) else ""
        }
        return null
    }

    private fun sendFile(o: OutputStream, f: File, range: String?, headOnly: Boolean) {
        val total = f.length()
        var start = 0L
        var end = total - 1
        var partial = false
        if (range != null && range.startsWith("bytes=")) {
            val r = range.removePrefix("bytes=").split("-")
            val s = r.getOrNull(0)?.toLongOrNull()
            val e = r.getOrNull(1)?.toLongOrNull()
            if (s != null) { start = s; if (e != null) end = minOf(e, total - 1); partial = true }
            else if (e != null) { start = maxOf(0L, total - e); partial = true }
            if (start > end || start >= total) {
                page(o, 416, "Range Not Satisfiable", "Rentang salah", "Content-Range: bytes */$total\r\n")
                return
            }
        }
        val ext = f.extension.lowercase()
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val len = end - start + 1
        val fname = URLEncoder.encode(f.name, "UTF-8").replace("+", "%20")
        val head = (if (partial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n") +
            "Content-Type: $type\r\nContent-Length: $len\r\nAccept-Ranges: bytes\r\n" +
            (if (partial) "Content-Range: bytes $start-$end/$total\r\n" else "") +
            "Content-Disposition: inline; filename*=UTF-8''$fname\r\nConnection: close\r\n\r\n"
        o.write(head.toByteArray(Charsets.UTF_8))
        if (!headOnly) {
            RandomAccessFile(f, "r").use { raf ->
                raf.seek(start)
                val buf = ByteArray(64 * 1024)
                var left = len
                while (left > 0) {
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n <= 0) break
                    o.write(buf, 0, n)
                    left -= n
                }
            }
        }
        o.flush()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun href(vpath: String): String =
        vpath.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun listing(vpath: String, dir: File): String {
        val kids = (dir.listFiles()?.toList() ?: emptyList())
            .filter { Prefs.showHidden(ctx) || !it.name.startsWith(".") }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
        val base = if (vpath == "/") "/" else "$vpath/"
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html lang=\"id\"><head><meta charset=\"utf-8\">")
        sb.append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
        sb.append("<title>File Manager Max: ${esc(vpath)}</title></head><body>")
        sb.append("<h1>File Manager Max</h1><h2>${esc(vpath)}</h2>")
        if (vpath != "/") {
            val up = ServerUtil.normalize(vpath, "..")
            sb.append("<p><a href=\"${href(if (up == "/") "/" else "$up/")}\">Naik satu folder</a></p>")
        }
        sb.append("<ul>")
        for (k in kids) {
            val link = href(base + k.name) + if (k.isDirectory) "/" else ""
            val info = if (k.isDirectory) "folder" else Formatter.formatFileSize(ctx, k.length())
            sb.append("<li><a href=\"$link\">${esc(k.name)}</a> ($info) ")
            sb.append("<button onclick=\"del('${href(base + k.name)}','${esc(k.name).replace("'", "")}')\">Hapus</button></li>")
        }
        if (kids.isEmpty()) sb.append("<li>Folder kosong</li>")
        sb.append("</ul><h3>Unggah berkas</h3>")
        sb.append("<input type=\"file\" id=\"f\" multiple> <button onclick=\"up()\">Unggah</button>")
        sb.append("<h3>Folder baru</h3><input type=\"text\" id=\"n\" aria-label=\"Nama folder\"> ")
        sb.append("<button onclick=\"mk()\">Buat folder</button><p id=\"s\" role=\"status\"></p>")
        sb.append("<script>var B='${href(base)}';")
        sb.append("function st(t){document.getElementById('s').textContent=t}")
        sb.append("async function up(){var fs=document.getElementById('f').files;if(!fs.length){st('Pilih berkas dulu');return}")
        sb.append("for(var i=0;i<fs.length;i++){st('Mengunggah '+fs[i].name);")
        sb.append("var r=await fetch(B+encodeURIComponent(fs[i].name),{method:'PUT',body:fs[i]});")
        sb.append("if(!r.ok){st('Gagal: '+fs[i].name);return}}st('Selesai');location.reload()}")
        sb.append("async function mk(){var n=document.getElementById('n').value;if(!n){st('Isi nama folder');return}")
        sb.append("var r=await fetch(B+'?mkdir='+encodeURIComponent(n),{method:'POST'});")
        sb.append("if(r.ok)location.reload();else st('Gagal membuat folder')}")
        sb.append("async function del(p,n){if(!confirm('Hapus '+n+'?'))return;")
        sb.append("var r=await fetch(p,{method:'DELETE'});if(r.ok)location.reload();else st('Gagal menghapus')}")
        sb.append("</script></body></html>")
        return sb.toString()
    }
}
