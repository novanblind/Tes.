package com.novan.talkbacknovan;

/** Jenis navigasi untuk usap atas/bawah; usap kiri/kanan bergerak menurut jenis yang dipilih. */
public final class Granularitas {
    public static final int ITEM = 0;          // Default
    public static final int PENGGESER = 1;
    public static final int KARAKTER = 2;
    public static final int KATA = 3;
    public static final int BARIS = 4;
    public static final int PARAGRAF = 5;
    public static final int VOLUME_MEDIA = 6;
    public static final int KECEPATAN = 7;
    public static final int OCR_TERJEMAH = 8;
    // Jenis tambahan (tidak aktif secara bawaan, bisa dinyalakan di pengaturan)
    public static final int JUDUL = 9;
    public static final int TAUTAN = 10;
    public static final int TOMBOL = 11;
    public static final int KOLOM = 12;
    public static final int CENTANG = 13;
    public static final int GAMBAR = 14;
    public static final int KALIMAT = 15;

    public static final String[] NAMA = {
            "Default", "Penggeser", "Karakter", "Kata", "Baris", "Paragraf",
            "Volume media", "Kecepatan ucapan", "OCR dan terjemahan",
            "Judul", "Tautan", "Tombol", "Kolom isian",
            "Kotak centang dan sakelar", "Gambar", "Kalimat"
    };

    /** Jenis yang aktif bila pengguna belum mengubah pilihan. */
    public static final int[] BAWAAN = {ITEM, PENGGESER, KARAKTER, KATA, BARIS, PARAGRAF,
            VOLUME_MEDIA, KECEPATAN, OCR_TERJEMAH};

    /** Jenis yang bergerak per bagian teks pada elemen terfokus. */
    public static boolean teks(int g) {
        return g == KARAKTER || g == KATA || g == BARIS || g == PARAGRAF || g == KALIMAT;
    }

    /** Jenis yang usap kiri/kanannya mengubah nilai, bukan memindah fokus. */
    public static boolean nilai(int g) {
        return g == PENGGESER || g == VOLUME_MEDIA || g == KECEPATAN || g == OCR_TERJEMAH;
    }

    private Granularitas() {}
}
