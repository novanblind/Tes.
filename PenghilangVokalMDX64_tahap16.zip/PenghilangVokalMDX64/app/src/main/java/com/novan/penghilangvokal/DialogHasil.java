package com.novan.penghilangvokal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Dialog hasil: putar, jeda, bagikan, hapus, ubah nama. */
final class DialogHasil {

    private final Activity act;
    private final Runnable onBerubah;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private boolean dijeda;
    private AlertDialog aktif;

    DialogHasil(Activity act, Runnable onBerubah) {
        this.act = act;
        this.onBerubah = onBerubah;
    }

    /** Menampilkan daftar hasil (bila lebih dari satu) lalu menu aksi untuk berkas yang dipilih. */
    void tampil() {
        final List<Penyimpan.Hasil> daftar = new ArrayList<>(ProsesStatus.hasil);
        if (daftar.isEmpty() || act.isFinishing()) return;
        if (daftar.size() == 1) {
            menu(daftar.get(0));
            return;
        }
        String[] nama = new String[daftar.size()];
        for (int i = 0; i < nama.length; i++) nama[i] = daftar.get(i).nama;
        tampilkan(new AlertDialog.Builder(act)
                .setTitle(R.string.dialog_pilih_berkas)
                .setItems(nama, (d, i) -> menu(daftar.get(i)))
                .setNegativeButton(R.string.item_tutup, null)
                .create());
    }

    /** Menutup dialog dan menghentikan pemutaran (dipanggil saat layar ditutup). */
    void tutup() {
        if (aktif != null) {
            try {
                aktif.dismiss();
            } catch (Throwable ignored) { }
            aktif = null;
        }
        hentikan();
    }

    private void tampilkan(AlertDialog d) {
        aktif = d;
        d.show();
    }

    private void menu(final Penyimpan.Hasil h) {
        String[] item = {
                act.getString(R.string.item_putar),
                act.getString(R.string.item_jeda),
                act.getString(R.string.item_bagikan),
                act.getString(R.string.item_hapus),
                act.getString(R.string.item_ubah_nama),
                act.getString(R.string.item_tutup)
        };
        ArrayAdapter<String> ad = new ArrayAdapter<>(act, android.R.layout.simple_list_item_1, item);
        final AlertDialog dlg = new AlertDialog.Builder(act)
                .setTitle(h.nama)
                .setAdapter(ad, null)
                .create();
        dlg.setOnDismissListener(x -> hentikan());
        tampilkan(dlg);
        // Tanpa pendengar di setAdapter, dialog tidak menutup sendiri; jadi Putar dan Jeda bisa bergantian.
        dlg.getListView().setOnItemClickListener((parent, v, pos, id) -> {
            switch (pos) {
                case 0:
                    putar(h, v);
                    break;
                case 1:
                    jeda(v);
                    break;
                case 2:
                    bagikan(h);
                    break;
                case 3:
                    dlg.dismiss();
                    konfirmasiHapus(h);
                    break;
                case 4:
                    dlg.dismiss();
                    ubahNama(h);
                    break;
                default:
                    dlg.dismiss();
                    break;
            }
        });
    }

    // ---------------- Putar / Jeda ----------------

    private void putar(Penyimpan.Hasil h, View v) {
        try {
            if (player != null && dijeda) {
                player.start();
                dijeda = false;
                umumkan(v, act.getString(R.string.memutar));
                return;
            }
            if (player != null && player.isPlaying()) return;
            hentikan();
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(act, h.uri);
            player.setOnCompletionListener(mp -> hentikan());
            player.prepare();
            player.start();
            dijeda = false;
            umumkan(v, act.getString(R.string.memutar));
        } catch (Throwable e) {
            hentikan();
            Toast.makeText(act, act.getString(R.string.gagal_putar, String.valueOf(e.getMessage())),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void jeda(View v) {
        try {
            if (player != null && player.isPlaying()) {
                player.pause();
                dijeda = true;
                umumkan(v, act.getString(R.string.dijeda));
            }
        } catch (Throwable ignored) { }
    }

    private void hentikan() {
        if (player != null) {
            try {
                player.release();
            } catch (Throwable ignored) { }
            player = null;
        }
        dijeda = false;
    }

    private void umumkan(View v, String teks) {
        v.announceForAccessibility(teks);
        Toast.makeText(act, teks, Toast.LENGTH_SHORT).show();
    }

    // ---------------- Bagikan ----------------

    private void bagikan(Penyimpan.Hasil h) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("audio/mpeg");
            i.putExtra(Intent.EXTRA_STREAM, h.uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.startActivity(Intent.createChooser(i, act.getString(R.string.bagikan_judul)));
        } catch (Throwable e) {
            Toast.makeText(act, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    // ---------------- Hapus ----------------

    private void konfirmasiHapus(final Penyimpan.Hasil h) {
        tampilkan(new AlertDialog.Builder(act)
                .setTitle(R.string.item_hapus)
                .setMessage(act.getString(R.string.hapus_konfirmasi, h.nama))
                .setPositiveButton(R.string.ya_hapus, (d, w) -> new Thread(() -> {
                    String pesan;
                    try {
                        Penyimpan.hapus(act, h);
                        ProsesStatus.buang(h);
                        pesan = act.getString(R.string.terhapus, h.nama);
                    } catch (Throwable e) {
                        pesan = act.getString(R.string.gagal_hapus, String.valueOf(e.getMessage()));
                    }
                    final String p = pesan;
                    ui.post(() -> selesaiAksi(p, null));
                }).start())
                .setNegativeButton(R.string.tidak, (d, w) -> menu(h))
                .create());
    }

    // ---------------- Ubah nama ----------------

    private void ubahNama(final Penyimpan.Hasil h) {
        final EditText input = new EditText(act);
        String awal = h.nama;
        if (awal.toLowerCase().endsWith(".mp3")) awal = awal.substring(0, awal.length() - 4);
        input.setText(awal);
        input.setSelectAllOnFocus(true);
        input.setSingleLine(true);
        input.setContentDescription(act.getString(R.string.ubah_nama_judul));
        tampilkan(new AlertDialog.Builder(act)
                .setTitle(R.string.ubah_nama_judul)
                .setView(input)
                .setPositiveButton(R.string.simpan_nama, (d, w) -> {
                    final String baru = input.getText().toString();
                    new Thread(() -> {
                        Penyimpan.Hasil hasilBaru = null;
                        String pesan;
                        try {
                            hasilBaru = Penyimpan.ubahNama(act, h, baru);
                            ProsesStatus.ganti(h, hasilBaru);
                            pesan = act.getString(R.string.nama_berubah, hasilBaru.nama);
                        } catch (Throwable e) {
                            pesan = act.getString(R.string.gagal_ubah, String.valueOf(e.getMessage()));
                        }
                        final String p = pesan;
                        final Penyimpan.Hasil lanjut = hasilBaru != null ? hasilBaru : h;
                        ui.post(() -> selesaiAksi(p, lanjut));
                    }).start();
                })
                .setNegativeButton(R.string.tidak, (d, w) -> menu(h))
                .create());
    }

    /** Menampilkan pesan hasil aksi; bila 'lanjut' ada, buka lagi menunya. */
    private void selesaiAksi(String pesan, Penyimpan.Hasil lanjut) {
        if (act.isFinishing()) return;
        Toast.makeText(act, pesan, Toast.LENGTH_LONG).show();
        act.getWindow().getDecorView().announceForAccessibility(pesan);
        if (onBerubah != null) onBerubah.run();
        if (lanjut != null) menu(lanjut);
    }
}
