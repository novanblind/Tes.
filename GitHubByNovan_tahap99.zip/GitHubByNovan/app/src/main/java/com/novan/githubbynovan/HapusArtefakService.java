package com.novan.githubbynovan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * Menghapus semua artefak di semua repositori milik akun sebagai layanan latar depan, sehingga
 * penghapusan tetap berjalan walaupun pengguna pindah ke aplikasi lain atau layar mati.
 * Kemajuan tampil di notifikasi; ringkasan hasil diberitahukan saat selesai.
 */
public class HapusArtefakService extends Service {

    /** Hasil akhir penghapusan, menunggu ditampilkan. */
    public static class Hasil {
        boolean gagal;
        String message = "";
    }

    public interface Listener {
        void onStatus(String text);
        void onFinished();
    }

    private static final String ACTION_STOP = "com.novan.githubbynovan.STOP_HAPUS_ARTEFAK";
    private static final String CH_PROGRESS = "hapus_artefak";
    private static final String CH_RESULT = "hasil_hapus_artefak";
    private static final int ID_PROGRESS = 45, ID_RESULT = 46;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static volatile Listener listener;
    static volatile String lastText = "";
    static volatile boolean running;
    private static volatile boolean stopFlag;
    private static Hasil pending;

    static synchronized void setPending(Hasil r) { pending = r; }
    static synchronized Hasil takePending() { Hasil r = pending; pending = null; return r; }
    static synchronized boolean hasPending() { return pending != null; }

    private PowerManager.WakeLock lock;
    private Thread worker;

    // ---------- pintu masuk ----------

    public static boolean busy() { return running; }

    public static boolean start(Context c, String token) {
        if (running) return false;
        setPending(null);
        lastText = "";
        stopFlag = false;
        cancelResultNotification(c);
        Intent i = new Intent(c, HapusArtefakService.class).putExtra("token", token);
        try {
            running = true;
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            running = false;
            return false;
        }
    }

    /** Menghentikan penghapusan yang sedang berjalan (artefak yang sudah terhapus tetap terhapus). */
    public static void cancel(Context c) {
        stopFlag = true;
        try {
            c.startService(new Intent(c, HapusArtefakService.class).setAction(ACTION_STOP));
        } catch (Exception ignored) { }
    }

    public static void cancelResultNotification(Context c) {
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_RESULT);
        } catch (Exception ignored) { }
    }

    // ---------- siklus layanan ----------

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopFlag = true;
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        final String token = intent == null ? null : intent.getStringExtra("token");
        if (token == null) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (worker != null && worker.isAlive()) return START_NOT_STICKY;

        running = true;
        Notification n = progressNotification("Memulai...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_PROGRESS, n);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (lock == null) lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "githubbynovan:hapusartefak");
            if (!lock.isHeld()) lock.acquire(60 * 60 * 1000L);
        } catch (Exception ignored) { }

        worker = new Thread(() -> kerja(token), "hapus-artefak");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ---------- pekerjaan ----------

    private void status(String t) {
        lastText = t;
        try {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .notify(ID_PROGRESS, progressNotification(t));
        } catch (Exception ignored) { }
        final Listener l = listener;
        if (l != null) MAIN.post(() -> l.onStatus(t));
    }

    private void kerja(String token) {
        try {
            proses(token);
        } catch (Throwable e) {
            Hasil h = new Hasil();
            h.gagal = true;
            h.message = "Penghapusan berhenti karena galat tak terduga:\n" + e;
            selesai(h);
        }
    }

    private void proses(String token) {
        final List<String> repos = new ArrayList<>();
        int terhapus = 0, gagal = 0, dilewati = 0;
        long bebas = 0;
        String galat = "";

        status("Mengambil daftar repositori...");
        for (int n = 1; n <= 10 && !stopFlag; n++) {
            Api.Result r = Api.requestSync("GET",
                    Api.BASE + "/user/repos?affiliation=owner&per_page=100&page=" + n, token, null);
            if (!r.ok) {
                if (repos.isEmpty()) {
                    Hasil h = new Hasil();
                    h.gagal = true;
                    h.message = "Gagal mengambil daftar repositori:\n" + r.text;
                    selesai(h);
                    return;
                }
                break;
            }
            JSONArray arr = Api.parseArr(r.text);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null && !o.optString("full_name", "").isEmpty()) repos.add(o.optString("full_name"));
            }
            if (arr.length() < 100) break;
        }

        for (int idx = 0; idx < repos.size() && !stopFlag; idx++) {
            final String full = repos.get(idx);
            for (int putaran = 0; putaran < 20 && !stopFlag; putaran++) {
                status("Repositori " + (idx + 1) + " dari " + repos.size() + "\n" + full
                        + "\n\nArtefak dihapus: " + terhapus);
                Api.Result r = Api.requestSync("GET",
                        Api.BASE + "/repos/" + full + "/actions/artifacts?per_page=100", token, null);
                if (!r.ok) {
                    dilewati++;
                    if (galat.isEmpty()) galat = full + ": " + r.text;
                    break;
                }
                JSONArray arts = Api.parse(r.text).optJSONArray("artifacts");
                if (arts == null || arts.length() == 0) break;
                int okPutaran = 0;
                for (int i = 0; i < arts.length() && !stopFlag; i++) {
                    JSONObject it = arts.optJSONObject(i);
                    long id = it == null ? 0 : it.optLong("id", 0);
                    long sz = it == null ? 0 : it.optLong("size_in_bytes", 0);
                    if (id == 0) continue;
                    Api.Result d = Api.requestSync("DELETE",
                            Api.BASE + "/repos/" + full + "/actions/artifacts/" + id, token, null);
                    if (d.ok) {
                        terhapus++;
                        okPutaran++;
                        bebas += sz;
                    } else {
                        gagal++;
                        if (galat.isEmpty()) galat = full + ": " + d.text;
                    }
                    status("Repositori " + (idx + 1) + " dari " + repos.size() + "\n" + full
                            + "\n\nArtefak dihapus: " + terhapus);
                }
                // Cek lagi bila artefaknya lebih dari 100; bila tidak ada yang berhasil, lanjut repo lain.
                if (okPutaran == 0) break;
            }
        }

        Hasil h = new Hasil();
        h.gagal = gagal > 0;
        h.message = (stopFlag ? "Dihentikan sebelum selesai.\n\n" : "")
                + repos.size() + " repositori ditemukan" + (stopFlag ? " (sebagian diperiksa)" : " dan diperiksa") + ".\n"
                + terhapus + " artefak dihapus (sekitar " + Ui.size(bebas) + ").\n"
                + (gagal > 0 ? gagal + " artefak gagal dihapus.\n" : "")
                + (dilewati > 0 ? dilewati + " repositori dilewati (tidak bisa dibaca).\n" : "")
                + (galat.isEmpty() ? "" : "\nGalat pertama:\n" + galat + "\n")
                + "\nKuota GitHub diperbarui tiap 6-12 jam, jadi hasilnya mungkin belum terlihat.";
        selesai(h);
    }

    private void selesai(Hasil h) {
        running = false;
        setPending(h);
        postResultNotification(h);
        final Listener l = listener;
        if (l != null) MAIN.post(l::onFinished);
        stopForeground(true);
        stopSelf();
    }

    // ---------- notifikasi ----------

    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_PROGRESS, "Hapus artefak",
                NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_RESULT, "Hasil hapus artefak",
                NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, 4, i, f);
    }

    private Notification.Builder builder(String channel) {
        ensureChannels();
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification progressNotification(String text) {
        Intent stop = new Intent(this, HapusArtefakService.class).setAction(ACTION_STOP);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPi = PendingIntent.getService(this, 5, stop, f);
        return builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.ic_menu_delete)
                .setContentTitle("Menghapus semua artefak")
                .setContentText(text.replace('\n', ' '))
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setContentIntent(openApp())
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan", stopPi)
                .build();
    }

    private void postResultNotification(Hasil h) {
        try {
            String ringkas = h.message.split("\n\n")[0].replace('\n', ' ');
            Notification n = builder(CH_RESULT)
                    .setSmallIcon(android.R.drawable.ic_menu_delete)
                    .setContentTitle(h.gagal ? "Hapus artefak selesai dengan kendala" : "Hapus artefak selesai")
                    .setContentText(ringkas)
                    .setStyle(new Notification.BigTextStyle().bigText(ringkas))
                    .setAutoCancel(true)
                    .setContentIntent(openApp())
                    .build();
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_RESULT, n);
        } catch (Exception ignored) { }
    }
}
