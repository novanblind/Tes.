package id.ytplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.common.util.concurrent.ListenableFuture

/** Beranda bergaya aplikasi video: cari, kategori, daftar kartu video, mini player. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_QUERY = "query"
        private const val REQ_VOICE = 101
        private const val REC = "@@rekomendasi" // penanda chip Beranda (rekomendasi)
        private const val STALE_MS = 30 * 60_000L // dibuka lagi setelah selama ini: beranda disegarkan
        private const val FAV = "@@favorit" // penanda chip favorit
    }

    private data class Chip(val label: String, val query: String?) // query null = riwayat

    private val ytm: Boolean by lazy { Store.appMode(this) == Store.MODE_YTM }
    private val noun: String get() = if (ytm) "lagu" else "video"

    private val videoChips = listOf(
        Chip("Beranda", REC),
        Chip("Musik", "musik populer Indonesia"),
        Chip("Berita", "berita terkini"),
        Chip("Podcast", "podcast Indonesia"),
        Chip("Game", "gameplay Indonesia"),
        Chip("Belajar", "tutorial belajar"),
        Chip("Ceramah", "kajian ceramah"),
        Chip("Favorit", FAV),
        Chip("Riwayat", null)
    )

    private val musicChips = listOf(
        Chip("Beranda", REC),
        Chip("Populer Indonesia", "lagu populer Indonesia"),
        Chip("Pop", "lagu pop Indonesia"),
        Chip("Dangdut", "lagu dangdut"),
        Chip("Religi", "lagu religi islami"),
        Chip("Barat", "lagu pop barat"),
        Chip("K-pop", "lagu k-pop"),
        Chip("Kenangan", "lagu kenangan Indonesia"),
        Chip("Favorit", FAV),
        Chip("Riwayat", null)
    )

    private val chips: List<Chip> by lazy { if (ytm) musicChips else videoChips }

    /** Filter pencarian YouTube Music (null = pencarian video biasa). */
    private fun filterKey(): String? =
        if (!ytm) null else if (Store.ytmType(this) == 0) "music_songs" else "music_videos"

    private lateinit var searchBox: EditText
    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: VideoAdapter
    private lateinit var chipRow: LinearLayout
    private lateinit var btnCategory: Button
    private lateinit var swAudio: Switch
    private lateinit var btnClear: Button
    private lateinit var btnRefresh: Button
    private lateinit var listWrap: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout

    private lateinit var miniBar: View
    private lateinit var miniOpen: View
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: Button

    private var session: Repo.SearchSession? = null
    private var searchToken = 0
    private var loadingMore = false
    private var chipIndex = 0
    private var refreshChip = 0      // chip aktif (-1 = hasil pencarian ketik)
    private var lastQuery = ""
    private var dateIdx = 0                 // indeks DateFilter.options (0 = kapan saja)
    private lateinit var btnDate: Button
    private var stoppedAt = 0L
    private var currentLabel = ""

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateMini()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        // Pindah YT Player <-> YouTube Musik: tampilan baru dimulai bersih, tanpa memulihkan status lama.
        if (DrawerHelper.switching) return
        super.onSaveInstanceState(outState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DrawerHelper.switching = false
        // Mode Music Player dipilih: tampilan utama aplikasi adalah pemutar musik.
        if (Store.appMode(this) == Store.MODE_MUSIC) {
            startActivity(DrawerHelper.launchIntent(this, Store.MODE_MUSIC))
            finish()
            return
        }
        setContentView(R.layout.activity_main)
        DrawerHelper.setup(this, if (ytm) Store.MODE_YTM else Store.MODE_YT)
        currentLabel = chips[0].label
        if (ytm) {
            findViewById<TextView>(R.id.appTitle).text = "YouTube Music"
            title = "YouTube Music"
        }
        CrashReport.showIfAny(this)

        searchBox = findViewById(R.id.searchBox)
        status = findViewById(R.id.status)
        list = findViewById(R.id.list)
        chipRow = findViewById(R.id.chipRow)
        btnCategory = findViewById(R.id.btnCategory)
        btnCategory.setOnClickListener { showCategoryDialog() }
        swAudio = findViewById(R.id.swAudioOnly)
        btnClear = findViewById(R.id.btnClear)
        btnDate = findViewById(R.id.btnDate)
        btnRefresh = findViewById(R.id.btnRefresh)
        listWrap = findViewById(R.id.listWrap)
        swipe = findViewById(R.id.swipe)
        swipe.setOnRefreshListener { refresh() }
        miniBar = findViewById(R.id.miniBar)
        miniOpen = findViewById(R.id.miniOpen)
        miniTitle = findViewById(R.id.miniTitle)
        miniPlay = findViewById(R.id.miniPlay)

        ViewCompat.setAccessibilityHeading(findViewById(R.id.appTitle), true)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        adapter = VideoAdapter(
            onOpen = { item, audio -> openVideo(item, audio) },
            onRemove = { item ->
                Store.removeHistory(this, item.url)
                adapter.remove(item)
                Toast.makeText(this, "Dihapus dari riwayat", Toast.LENGTH_SHORT).show()
            }
        )
        val lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.adapter = adapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val s = session ?: return
                if (dy > 0 && !loadingMore && !s.loading && s.hasMore &&
                    lm.findLastVisibleItemPosition() >= adapter.itemCount - 10
                ) {
                    loadingMore = true
                    Repo.loadMore(
                        s,
                        onChunk = { items -> if (s === session) adapter.add(items) },
                        onDone = { loadingMore = false }
                    )
                }
            }
        })

        findViewById<Button>(R.id.searchBtn).setOnClickListener { submitSearch() }
        findViewById<Button>(R.id.voiceBtn).setOnClickListener { startVoiceSearch() }
        searchBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                submitSearch(); true
            } else false
        }

        swAudio.isChecked = Store.audioOnly(this)
        swAudio.setOnCheckedChangeListener { _, checked -> Store.setAudioOnly(this, checked) }

        btnRefresh.setOnClickListener { refresh() }
        btnDate.setOnClickListener { showDateDialog() }
        updateDateButton()

        // TalkBack: usap dua jari ke bawah (gulir ke atas) saat daftar sudah di paling atas = segarkan.
        ViewCompat.setAccessibilityDelegate(listWrap, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                if (!list.canScrollVertically(-1)) {
                    info.addAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_SCROLL_BACKWARD)
                    info.isScrollable = true
                }
            }

            override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean {
                if (action == AccessibilityNodeInfoCompat.ACTION_SCROLL_BACKWARD && !list.canScrollVertically(-1)) {
                    refresh()
                    return true
                }
                return super.performAccessibilityAction(host, action, args)
            }
        })

        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Hapus riwayat (tidak bisa dikembalikan)")
                .setItems(
                    arrayOf(
                        "Hapus riwayat tontonan",
                        "Hapus riwayat pencarian",
                        "Hapus semuanya"
                    )
                ) { _, which ->
                    if (which == 0 || which == 2) Store.clearHistory(this)
                    if (which == 1 || which == 2) Store.clearSearches(this)
                    Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                    showHistory()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        buildChips()
        selectChip(0)
        handleIntent(intent)

        miniOpen.setOnClickListener { openCurrentPlayer() }
        miniPlay.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.playWhenReady && c.playbackState != Player.STATE_ENDED) c.pause()
            else {
                if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
                c.play()
            }
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!DrawerHelper.closeIfOpen(this)) super.onBackPressed()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Dibuka dari halaman tonton ("Video lain dari kanal ini"): langsung cari nama kanalnya. */
    private fun handleIntent(i: Intent?) {
        val q = i?.getStringExtra(EXTRA_QUERY)?.trim().orEmpty()
        if (q.isNotEmpty()) {
            i?.removeExtra(EXTRA_QUERY)
            searchBox.setText(q)
            submitSearch()
        }
    }

    /** Muat ulang tampilan yang sedang aktif (kategori, favorit, riwayat, atau hasil pencarian). */
    private fun refresh() {
        swipe.isRefreshing = true
        if (refreshChip >= 0) selectChip(refreshChip)
        else if (lastQuery.isNotEmpty()) runQuery(lastQuery)
        else swipe.isRefreshing = false
        list.scrollToPosition(0)
    }

    private fun endRefresh() {
        swipe.isRefreshing = false
    }

    override fun onStart() {
        super.onStart()
        // Seperti YouTube: dibuka lagi setelah lama ditinggalkan = beranda dimuat ulang dari atas;
        // sebentar saja = tampilan dan posisi gulir dipertahankan. Daftar lokal (favorit, riwayat)
        // selalu diperbarui karena isinya berubah setelah menonton.
        if (stoppedAt > 0 && refreshChip >= 0) {
            val q = chips[refreshChip].query
            if (SystemClock.elapsedRealtime() - stoppedAt > STALE_MS) {
                refresh()
            } else if (q == null) showHistory()
            else if (q == FAV) showFavorites()
        }
        swAudio.isChecked = Store.audioOnly(this)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        controllerFuture = f
        f.addListener({
            try {
                controller = f.get().also { it.addListener(playerListener) }
                updateMini()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        stoppedAt = SystemClock.elapsedRealtime()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onStop()
        DrawerHelper.finishIfLeaving(this)
    }

    // ------------------------------------------------------------------ pencarian

    // ------------------------------------------------------------------ filter tanggal unggah

    private fun maxAge(): Long = if (ytm) 0L else DateFilter.options[dateIdx].maxAgeSec

    private fun dateLabel(): String = DateFilter.options[dateIdx].label

    private fun typeLabel(): String = if (Store.ytmType(this) == 0) "Lagu" else "Video musik"

    private fun updateDateButton() {
        val label = dateLabel()
        if (ytm) {
            btnDate.text = "Jenis hasil: ${typeLabel()}"
            btnDate.contentDescription = "Jenis hasil pencarian, sekarang ${typeLabel()}. Ketuk untuk mengubah"
        } else {
            btnDate.text = "Tanggal unggah: $label"
            btnDate.contentDescription = "Filter tanggal unggah, sekarang $label. Ketuk untuk mengubah"
        }
        // Favorit dan riwayat adalah daftar lokal: filter tanggal / jenis hasil tidak berlaku di sana.
        val local = refreshChip >= 0 && chips[refreshChip].query.let { it == null || it == FAV }
        btnDate.visibility = if (local) View.GONE else View.VISIBLE
    }

    /** Mode YouTube Music: pilih jenis hasil, lagu atau video musik (klip resmi). */
    private fun showTypeDialog() {
        val labels = arrayOf("Lagu", "Video musik")
        AlertDialog.Builder(this)
            .setTitle("Jenis hasil")
            .setSingleChoiceItems(labels, Store.ytmType(this)) { dialog, which ->
                dialog.dismiss()
                if (which != Store.ytmType(this)) {
                    Store.setYtmType(this, which)
                    updateDateButton()
                    reloadCurrent()
                    list.announceForAccessibility("Jenis hasil ${typeLabel()}")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showDateDialog() {
        if (ytm) { showTypeDialog(); return }
        val labels = DateFilter.options.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tanggal unggah")
            .setSingleChoiceItems(labels, dateIdx) { dialog, which ->
                dialog.dismiss()
                if (which != dateIdx) {
                    dateIdx = which
                    updateDateButton()
                    reloadCurrent()
                    list.announceForAccessibility("Filter ${dateLabel()}")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Muat ulang tampilan yang sedang aktif memakai filter tanggal yang baru. */
    private fun reloadCurrent() {
        if (refreshChip >= 0) selectChip(refreshChip)
        else if (lastQuery.isNotEmpty()) runQuery(lastQuery)
    }

    private fun filterNote(): String = if (maxAge() > 0) " (${dateLabel().lowercase()})" else ""

    private fun buildChips() {
        val dp = resources.displayMetrics.density
        chips.forEachIndexed { i, chip ->
            val b = Button(this).apply {
                text = chip.label
                isAllCaps = false
                textSize = 16f
                setBackgroundResource(R.drawable.chip_bg)
                setTextColor(ContextCompat.getColorStateList(this@MainActivity, R.color.chip_text))
                minHeight = (48 * dp).toInt()
                minimumHeight = (48 * dp).toInt()
                minWidth = (64 * dp).toInt()
                setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
                contentDescription = "Kategori ${chip.label}"
                setOnClickListener { onChipTap(i) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = (8 * dp).toInt()
            lp.topMargin = (4 * dp).toInt()
            lp.bottomMargin = (4 * dp).toInt()
            chipRow.addView(b, lp)
        }
    }

    private fun updateCategoryButton(label: String) {
        btnCategory.text = "Kategori: $label  ▾"
        btnCategory.contentDescription = "Kategori: $label. Ketuk untuk mengganti kategori"
    }

    /** Semua kategori dalam satu daftar; memilih kategori yang sedang aktif = ke atas / segarkan. */
    private fun showCategoryDialog() {
        val names = chips.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih kategori")
            .setSingleChoiceItems(names, refreshChip) { d, which ->
                d.dismiss()
                onChipTap(which)
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    /** Seperti tab Beranda YouTube: ketuk sekali = ke atas, ketuk lagi di atas = segarkan. */
    private fun onChipTap(i: Int) {
        if (i == refreshChip) {
            if (list.canScrollVertically(-1)) {
                list.scrollToPosition(0)
                list.announceForAccessibility("Kembali ke atas")
            } else refresh()
        } else selectChip(i)
    }

    private fun selectChip(index: Int) {
        chipIndex = index
        refreshChip = index
        for (i in 0 until chipRow.childCount) {
            val v = chipRow.getChildAt(i)
            v.isSelected = i == index
            ViewCompat.setStateDescription(v, if (i == index) "Terpilih" else "Tidak terpilih")
        }
        val chip = chips[index]
        currentLabel = chip.label
        updateCategoryButton(chip.label)
        updateDateButton()
        val q = chip.query
        when {
            q == null -> showHistory()
            q == FAV -> showFavorites()
            q == REC -> showRecommendations()
            else -> runQuery(q)
        }
    }

    private fun submitSearch() {
        val q = searchBox.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchBox.windowToken, 0)
        for (i in 0 until chipRow.childCount) {
            chipRow.getChildAt(i).isSelected = false
            ViewCompat.setStateDescription(chipRow.getChildAt(i), "Tidak terpilih")
        }
        Store.addSearch(this, q)
        currentLabel = "\"$q\""
        updateCategoryButton("Hasil pencarian")
        refreshChip = -1
        lastQuery = q
        updateDateButton()
        runQuery(q)
    }

    /** Penelusuran suara: memakai pengenal ucapan bawaan perangkat, hasilnya langsung dicari. */
    private fun startVoiceSearch() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (_: ActivityNotFoundException) {
            status.text = getString(R.string.voice_unavailable)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_VOICE || resultCode != RESULT_OK) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) {
            status.text = getString(R.string.voice_no_result)
            return
        }
        searchBox.setText(text)
        searchBox.setSelection(text.length)
        submitSearch()
    }

    private fun showFavorites() {
        endRefresh()
        searchToken++
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        val f = Store.favorites(this)
        adapter.set(f)
        status.text = if (f.isEmpty())
            "Belum ada favorit. Buka sebuah $noun lalu pilih Tambah ke favorit."
        else "${f.size} $noun favorit"
    }

    private fun showHistory() {
        endRefresh()
        searchToken++
        session?.cancelled = true
        session = null
        val h = Store.history(this)
        btnClear.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        adapter.set(h, removable = true)
        status.text = if (h.isEmpty()) "Riwayat masih kosong" else "${h.size} $noun di riwayat"
    }

    /** Beranda: rekomendasi dari riwayat tontonan dan pencarian (video populer bila belum ada riwayat). */
    private fun showRecommendations() {
        val token = ++searchToken
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        if (!swipe.isRefreshing) adapter.set(emptyList())
        status.text = getString(R.string.loading)
        var got = 0
        Repo.recommend(
            this, maxAge(),
            onChunk = { chunk ->
                if (token == searchToken) {
                    if (got == 0) {
                        endRefresh()
                        adapter.set(chunk)
                        list.scrollToPosition(0)
                        status.text = "${chunk.size} $noun pertama tampil, memuat $noun lainnya…"
                    } else adapter.add(chunk)
                    got += chunk.size
                }
            },
            onDone = { personal, err ->
                if (token == searchToken) {
                    endRefresh()
                    if (got == 0) {
                        status.text = err ?: if (maxAge() > 0) "Tidak ada video untuk filter ${dateLabel().lowercase()}" else "Belum ada rekomendasi"
                    } else {
                        val n = adapter.itemCount
                        status.text = if (personal) "$n $noun rekomendasi untuk Anda${filterNote()}, berdasarkan riwayat dan pencarian"
                        else "$n $noun populer${filterNote()}. Rekomendasi akan menyesuaikan setelah Anda memutar atau mencari."
                    }
                }
            },
            filter = filterKey()
        )
    }

    private fun runQuery(query: String) {
        val token = ++searchToken
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        if (!swipe.isRefreshing) adapter.set(emptyList())
        status.text = getString(R.string.loading)
        Repo.startSearch(
            query, maxAge(),
            cb = { s, items, err ->
                if (token != searchToken) {
                    s?.cancelled = true
                } else {
                    endRefresh()
                    if (err != null) {
                        status.text = err
                    } else {
                        session = s
                        adapter.set(items)
                        status.text = if (items.isEmpty()) "Tidak ada hasil untuk $currentLabel${filterNote()}"
                        else "${items.size} $noun pertama tampil untuk $currentLabel${filterNote()}, memuat $noun lainnya…"
                    }
                }
            },
            onMore = { items -> if (token == searchToken) adapter.add(items) },
            onDone = {
                if (token == searchToken && adapter.itemCount > 0) {
                    status.text = "${adapter.itemCount} $noun ditemukan untuk $currentLabel${filterNote()}. Gulir ke bawah untuk memuat lebih banyak."
                }
            },
            filter = filterKey()
        )
    }

    // ------------------------------------------------------------------ tautan di clipboard

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) checkClipboard()
    }

    /** Ada tautan YouTube yang baru disalin: langsung buka halaman pilihan putar/unduh. */
    private fun checkClipboard() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            if (!cm.hasPrimaryClip()) return
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val clipText = clip.getItemAt(0).coerceToText(this)?.toString()
            val link = YtLink.extract(clipText) ?: YtLink.extractPlaylist(clipText) ?: TikTokLink.extract(clipText) ?: FacebookLink.extract(clipText) ?: return
            val stamp = if (Build.VERSION.SDK_INT >= 26) clip.description.timestamp else 0L
            val key = "$link|$stamp"
            if (Store.lastClip(this) == key) return
            Store.setLastClip(this, key)
            startActivity(Intent(this, LinkActivity::class.java).putExtra(LinkActivity.EXTRA_LINK, clipText.orEmpty()))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        if (::adapter.isInitialized) PlayQueue.detachLoader(adapter.sourceId)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Downloads.onPermissionResult(this, requestCode, grantResults)
    }

    // ------------------------------------------------------------------ pemutar

    private fun openVideo(item: VideoItem, audio: Boolean?) {
        if (audio != null) {
            Store.setAudioOnly(this, audio)
            swAudio.isChecked = audio
        }
        // Ambil aliran sekarang, berbarengan dengan layar pemutar yang sedang dibuka.
        Repo.prefetch(item.url)
        // Video berikutnya / sebelumnya mengikuti daftar yang sedang tampil (hasil pencarian dll.).
        PlayQueue.set(adapter.snapshot(), adapter.sourceId) {
            val s = session
            if (s != null && !loadingMore && !s.loading && s.hasMore) {
                loadingMore = true
                Repo.loadMore(
                    s,
                    onChunk = { items -> if (s === session) adapter.add(items) },
                    onDone = { loadingMore = false }
                )
            }
        }
        // Putar langsung lewat sambungan yang sudah ada, tanpa menunggu layar pemutar tersambung.
        controller?.let { c ->
            c.removeListener(playerListener)
            controller = null
            controllerFuture = null
            QuickPlay.start(applicationContext, c, item.url)
        }
        startActivity(PlayerActivity.intent(this, item))
    }

    private fun openCurrentPlayer() {
        val cur = controller?.currentMediaItem ?: return
        val md = cur.mediaMetadata
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_URL, cur.mediaId)
                .putExtra(PlayerActivity.EXTRA_TITLE, md.title?.toString() ?: "")
                .putExtra(PlayerActivity.EXTRA_UPLOADER, md.artist?.toString() ?: "")
                .putExtra(PlayerActivity.EXTRA_FROM_NOTIFICATION, true)
        )
    }

    private fun updateMini() {
        val c = controller
        val cur: MediaItem? = c?.currentMediaItem
        if (c == null || cur == null || c.playbackState == Player.STATE_IDLE && !c.playWhenReady) {
            miniBar.visibility = View.GONE
            return
        }
        val title = cur.mediaMetadata.title?.toString().orEmpty()
        val playing = c.playWhenReady && c.playbackState != Player.STATE_ENDED
        miniBar.visibility = View.VISIBLE
        miniTitle.text = title
        miniOpen.contentDescription = "${getString(R.string.now_playing)}: $title. ${getString(R.string.open_player)}"
        miniPlay.text = getString(if (playing) R.string.pause else R.string.play)
    }
}
