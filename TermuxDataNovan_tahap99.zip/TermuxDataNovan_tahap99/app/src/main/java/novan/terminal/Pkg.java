package novan.terminal;

import android.content.Intent;
import android.os.Build;
import android.system.Os;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.zip.*;

/** Pemasang paket sederhana: unduh .zip atau .tar.gz lalu ekstrak ke folder usr. */
public class Pkg {
    static volatile boolean busy;

    static void out(String s) { MainActivity.H.post(() -> MainActivity.add(s)); }
    static void say(String s) { MainActivity.H.post(() -> MainActivity.say(s)); }

    static String repo() { return MainActivity.ctx.getSharedPreferences("term", 0).getString("repo", ""); }

    static final String HELP = "Perintah pkg:\n"
        + "siap             : siapkan semua alat membangun APK (otomatis saat pertama kali membangun APK)\n"
        + "bangun-gradle <lokasi> [tugas] : bangun proyek Gradle apa saja (.zip atau folder), Android SDK dipasang otomatis\n"
        + "ekspor-alat [lokasi] [--tanpa-pustaka] : kumpulkan semua unduhan alat menjadi satu zip bundel offline di Download\n"
        + "impor-alat [lokasi] : pasang alat dari bundel offline di penyimpanan HP, tanpa internet\n"
        + "pkg bootstrap    : pasang lingkungan Termux (bash, apt, pkg) sekali saja\n"
        + "pkg zip <alamat>   : pasang satu berkas .zip atau .tar.gz\n"
        + "pkg repo <alamat>  : atur alamat repositori (folder berisi index.txt)\n"
        + "pkg list           : daftar paket di repositori\n"
        + "pkg install <nama|alamat .zip/.tar.gz> : pasang paket\n"
        + "pkg installed      : paket terpasang\n"
        + "Format index.txt: satu paket per baris, nama lalu spasi lalu alamat berkas.";

    /** Percobaan otomatis tersisa setelah kegagalan, hanya jalan saat menunggu untuk lanjut bangun-gradle otomatis. */
    static int ulangOtomatis;

    /** Tangani kegagalan penyiapan: coba lagi sendiri (sampai 3 kali, jeda 10 detik) bila pengguna
     *  sedang menunggu pembangunan otomatis, tanpa perlu mengetuk atau mengetik apa pun. Kalau sudah
     *  tidak menunggu, atau percobaan otomatis habis, baru tampilkan pesan gagal biasa (tombol Coba lagi). */
    static void gagal(String pesanDetail, String pesanUcap) {
        out("Gagal: " + pesanDetail); say("Gagal: " + pesanUcap);
        if (MainActivity.tungguBangun && ulangOtomatis < 3) {
            ulangOtomatis++;
            out("Mencoba lagi sendiri (" + ulangOtomatis + " dari 3) dalam 10 detik. Tidak perlu mengetuk atau mengetik apa pun.");
            say("Mencoba lagi sendiri dalam 10 detik");
            Progres.selesai(false, pesanDetail + ". Mencoba lagi sendiri dalam 10 detik (" + ulangOtomatis + " dari 3) — tidak perlu mengetuk apa pun.");
            MainActivity.H.postDelayed(() -> start("siap", ""), 10000);
        } else {
            Progres.selesai(false, pesanDetail + ". Periksa internet lalu tekan Coba lagi.");
            KeepAliveService.selesai(MainActivity.ctx, pesanDetail + ". Buka Termux Data Novan lagi untuk mengulang.");
        }
    }

    static void handle(String a) {
        String[] t = a.trim().split("\\s+", 2);
        String sub = t[0], arg = t.length > 1 ? t[1].trim() : "";
        if (sub.equals("bootstrap")) { start("bootstrap", ""); return; }
        if (sub.equals("siap")) { start("siap", ""); return; }
        if (sub.equals("ekspor")) { start("ekspor", arg); return; }
        if (sub.equals("impor")) {
            if (arg.isEmpty()) {
                File b = Bundel.cari();
                if (b == null) { out("Tulis lokasi bundel: impor-alat <lokasi berkas>, atau salin berkas bundel ke folder Download"); say("Bundel tidak ditemukan di Download"); return; }
                arg = b.getPath();
            }
            start("impor", arg); return;
        }
        if (sub.equals("repo")) {
            if (arg.isEmpty()) { String r = repo(); out(r.isEmpty() ? "Repositori belum diatur. Ketik: pkg repo <alamat>" : "Repositori: " + r); return; }
            while (arg.endsWith("/")) arg = arg.substring(0, arg.length() - 1);
            MainActivity.ctx.getSharedPreferences("term", 0).edit().putString("repo", arg).apply();
            out("Repositori disimpan: " + arg); say("Repositori disimpan");
        } else if (sub.equals("installed")) {
            File f = new File(Env.prefix, "etc/installed.txt");
            if (!f.exists()) { out("Belum ada paket terpasang"); say("Belum ada paket terpasang"); return; }
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String l; int n = 0;
                while ((l = r.readLine()) != null) { out(l); n++; }
                say(n + " paket terpasang");
            } catch (IOException e) { out("Gagal membaca: " + e.getMessage()); }
        } else if (sub.equals("list") || sub.equals("install")) {
            if (sub.equals("install") && arg.isEmpty()) { out("Tulis nama paket atau alamat. Contoh: pkg install jdk"); return; }
            start(sub, arg);
        } else {
            for (String l : HELP.split("\n")) out(l);
            say("Bantuan pkg ditampilkan");
        }
    }

    static void start(String sub, String arg) {
        if (busy) { out("Masih ada proses pkg berjalan"); say("Masih ada proses pkg berjalan"); Progres.buka(); return; }
        busy = true;
        android.content.Context c = MainActivity.ctx;
        KeepAliveService.begin(c);
        if (sub.equals("siap")) Progres.mulai("Menyiapkan alat membangun APK", "Memulai penyiapan", () -> handle("siap"));
        else if (sub.equals("bootstrap")) Progres.mulai("Memasang lingkungan Termux", "Memulai", () -> handle("bootstrap"));
        else if (sub.equals("install")) Progres.mulai("Memasang paket", "Memulai", () -> handle("install " + arg));
        else if (sub.equals("ekspor")) Progres.mulai("Membuat bundel offline", "Memulai", () -> handle("ekspor " + arg));
        else if (sub.equals("impor")) Progres.mulai("Memasang alat dari bundel offline", "Memulai", () -> handle("impor " + arg));
        new Thread(() -> {
            try {
                if (sub.equals("list")) list(); else if (sub.equals("bootstrap")) bootstrap(); else if (sub.equals("siap")) siap(); else if (sub.equals("ekspor")) Bundel.ekspor(arg); else if (sub.equals("impor")) Bundel.impor(new File(arg)); else install(arg);
                if (Progres.aktif) Progres.selesai(true, sub.equals("bootstrap") ? "Lingkungan Termux terpasang." : "Selesai memasang.");
            } catch (Throwable e) {
                String m = e instanceof java.net.UnknownHostException || e instanceof java.net.SocketTimeoutException
                    ? "Tidak ada koneksi internet atau sangat lambat" : String.valueOf(e.getMessage());
                if (Progres.aktif) gagal(m, m); else { out("Gagal: " + m); say("Gagal: " + m); }
            }
            busy = false;
            KeepAliveService.end(c);
        }).start();
    }

    static String httpText(String url) throws IOException {
        HttpURLConnection h = open(url);
        try (BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) {
            StringBuilder b = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) b.append(l).append('\n');
            return b.toString();
        }
    }

    static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(20000); h.setReadTimeout(30000);
        h.setRequestProperty("User-Agent", "TermuxNovan");
        if (h.getResponseCode() != 200) throw new IOException("Server membalas kode " + h.getResponseCode());
        return h;
    }

    static String index() throws IOException {
        String r = repo();
        if (r.isEmpty()) throw new IOException("Repositori belum diatur. Ketik: pkg repo <alamat>");
        return httpText(r + "/index.txt");
    }

    static void list() throws IOException {
        int n = 0;
        for (String l : index().split("\n")) {
            String[] p = l.trim().split("\\s+");
            if (p.length >= 2 && !p[0].startsWith("#")) { out(p[0]); n++; }
        }
        out(n + " paket"); say(n + " paket di repositori");
    }

    static void install(String arg) throws Exception {
        String url, name;
        if (arg.startsWith("http://") || arg.startsWith("https://")) {
            url = arg;
            name = arg.substring(arg.lastIndexOf('/') + 1);
        } else {
            url = null; name = arg;
            for (String l : index().split("\n")) {
                String[] p = l.trim().split("\\s+");
                if (p.length >= 2 && p[0].equals(arg)) { url = p[1]; break; }
            }
            if (url == null) throw new IOException("Paket tidak ditemukan: " + arg);
            if (!url.startsWith("http")) url = repo() + "/" + url;
        }
        Progres.tahap(0, 70, "Mengunduh " + name);
        out("Mengunduh " + name); say("Mengunduh " + name);
        File tmp = new File(Env.tmp, "unduhan.bin");
        download(url, tmp);
        Progres.tahap(70, 98, "Mengekstrak");
        out("Mengekstrak"); say("Mengekstrak");
        int n = extract(tmp, Env.prefix);
        tmp.delete();
        record(name);
        out("Selesai: " + name + ", " + n + " berkas"); say("Selesai memasang " + name);
    }

    static final String SIAP = """
export DEBIAN_FRONTEND=noninteractive
BUNDEL=""
if [ -f "$HOME/.bundel-path" ]; then BUNDEL=$(cat "$HOME/.bundel-path"); fi
if [ -n "$BUNDEL" ] && [ ! -f "$BUNDEL" ]; then echo "Bundel tidak ditemukan lagi di $BUNDEL, memakai internet"; BUNDEL=""; fi
OFFLINE=0
if [ -n "$BUNDEL" ] && [ -d "$HOME/.bundel/apt" ]; then OFFLINE=1; fi
siapkan_offline() {
  local AR LS
  eval "$(apt-config shell AR Dir::Cache::Archives/d LS Dir::State::lists/d)"
  if [ -z "$AR" ]; then AR="$PREFIX/var/cache/apt/archives/"; fi
  if [ -z "$LS" ]; then LS="$PREFIX/var/lib/apt/lists/"; fi
  mkdir -p "$AR" "$LS"
  echo "Memakai bundel offline: $BUNDEL"
  if [ -f "$HOME/.bundel/apt/sources.list" ]; then cp -f "$HOME/.bundel/apt/sources.list" "$PREFIX/etc/apt/sources.list"; fi
  find "$LS" -maxdepth 1 -type f ! -name lock -delete 2>/dev/null || true
  cp -f "$HOME/.bundel/apt/lists/"* "$LS" 2>/dev/null || true
  mv -f "$HOME/.bundel/apt/archives/"*.deb "$AR" 2>/dev/null || true
  echo "Paket di bundel: $(ls "$AR"*.deb 2>/dev/null | wc -l) berkas"
}
if [ "$OFFLINE" = 1 ]; then
  pkg() {
    case "$1" in
      update) return 0 ;;
      install) shift; apt-get -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef install "$@" ;;
      *) command pkg "$@" ;;
    esac
  }
fi
pulihkan_bundel() {
  local f nm isi
  SDK="$HOME/android-sdk"
  isi=$(unzip -Z1 "$BUNDEL" 2>/dev/null)
  f=$(echo "$isi" | grep -E -m1 '^sdk/sdk-.*[.]tar[.]gz$')
  if [ -n "$f" ] && [ ! -d "$SDK/build-tools" ]; then
    echo "Memulihkan Android SDK dari bundel"
    mkdir -p "$SDK"
    unzip -p "$BUNDEL" "$f" | tar -xz -C "$SDK" || echo "Peringatan: SDK dari bundel gagal dipulihkan, nanti diunduh biasa"
  fi
  mkdir -p "$HOME/.gradle-dist"
  for f in $(echo "$isi" | grep -E '^gradle/gradle-.*-bin[.]tar[.]gz$'); do
    nm=$(basename "$f" .tar.gz)
    if [ ! -x "$HOME/.gradle-dist/$nm/bin/gradle" ]; then
      echo "Memulihkan $nm dari bundel"
      unzip -p "$BUNDEL" "$f" | tar -xz -C "$HOME/.gradle-dist" || echo "Peringatan: $nm gagal dipulihkan"
    fi
  done
  mkdir -p "$HOME/.gradle"
  for f in gradle/pembungkus.tar.gz gradle/pustaka.tar.gz; do
    if echo "$isi" | grep -qx "$f"; then
      echo "Memulihkan $(basename "$f" .tar.gz) Gradle dari bundel"
      unzip -p "$BUNDEL" "$f" | tar -xz -C "$HOME/.gradle" || echo "Peringatan: $f gagal dipulihkan"
    fi
  done
}
perbaiki_dpkg() {
  echo "Memperbaiki status paket yang terhenti sebelumnya (dpkg --configure -a)"
  dpkg --configure -a > /dev/null 2>&1 || true
}
perbaiki_skrip() {
  echo "Skrip pemasangan paket ditolak dijalankan dpkg. Memasang paket tanpa skrip, skripnya dijalankan lewat sh"
  echo "Info: LD_PRELOAD=$LD_PRELOAD"
  local AR deb nama ver w k sk
  eval "$(apt-config shell AR Dir::Cache::Archives/d)"
  [ -d "$AR" ] || AR="$PREFIX/../../cache/apt/archives/"
  k="$TMPDIR/rpk"; rm -rf "$k"; mkdir -p "$k/deb" "$k/skrip"
  for deb in "$AR"*.deb; do
    [ -f "$deb" ] || continue
    nama=$(dpkg-deb -f "$deb" Package) || continue
    ver=$(dpkg-deb -f "$deb" Version)
    [ "$(dpkg-query -W -f='${db:Status-Status} ${Version}' "$nama" 2>/dev/null)" = "installed $ver" ] && continue
    dpkg-deb --ctrl-tarfile "$deb" | tar -tf - 2>/dev/null | grep -Eq '(^|/)(preinst|postinst|prerm|postrm)$' || continue
    echo "Mengemas ulang tanpa skrip: $nama $ver"
    w="$k/w"; rm -rf "$w"; mkdir -p "$w"
    dpkg-deb -R "$deb" "$w" || continue
    mkdir -p "$k/skrip/$nama"
    for sk in preinst postinst prerm postrm; do
      if [ -f "$w/DEBIAN/$sk" ]; then
        [ "$sk" = preinst ] || [ "$sk" = postinst ] && cp "$w/DEBIAN/$sk" "$k/skrip/$nama/$sk"
        rm -f "$w/DEBIAN/$sk"
      fi
    done
    dpkg-deb -Zgzip -z1 -b "$w" "$k/deb/${nama}_baru.deb" || true
    rm -rf "$w"
  done
  for sk in "$k"/skrip/*/preinst; do
    [ -f "$sk" ] && { echo "Menjalankan preinst $(basename "$(dirname "$sk")")"; sh "$sk" install || true; }
  done
  ls "$k"/deb/*.deb > /dev/null 2>&1 && dpkg -i --force-confold "$k"/deb/*.deb || true
  for sk in "$k"/skrip/*/postinst; do
    [ -f "$sk" ] && { echo "Menjalankan postinst $(basename "$(dirname "$sk")")"; sh "$sk" configure || true; }
  done
  rm -rf "$k"
  dpkg --configure -a || true
}
pasang() {
  local keluaran status
  keluaran=$(langsung apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef install "$@"); status=$?
  [ $status -eq 0 ] && return 0
  if echo "$keluaran" | grep -qi "dpkg was interrupted"; then
    perbaiki_dpkg
    apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef install "$@" && return 0
  fi
  if echo "$keluaran" | grep -qi "script.*Permission denied\\|unable to execute"; then
    perbaiki_skrip
    apt-get -y -f install || true
    apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef install "$@" && return 0
  fi
  echo "Pemasangan gagal. Memperbaiki paket yang rusak (apt --fix-broken install)"
  apt-get -y -f install || true
  perbaiki_dpkg
  echo "Memperbarui paket yang sudah terpasang"
  apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef full-upgrade || true
  apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef install "$@" && return 0
  echo "Masih gagal. Beralih ke cermin resmi packages.termux.dev lalu mencoba lagi"
  rm -f "$PREFIX/etc/apt/sources.list"
  echo "deb https://packages.termux.dev/apt/termux-main stable main" > "$PREFIX/etc/apt/sources.list"
  apt-get update || true
  apt-get -y -f install || true
  apt-get -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef full-upgrade || true
  apt-get -y install "$@" && return 0
  return 1
}
langsung() {
  # Jalankan perintah, tampilkan keluarannya SAAT ITU JUGA (supaya persen dan teks di dialog bergerak),
  # sambil tetap mengembalikan keluaran penuh lewat stdout-berkas agar bisa diperiksa. Kode keluar asli dipertahankan.
  local log="$TMPDIR/langsung.$$.log" st
  rm -f "$log"
  "$@" 2>&1 | tee "$log" >&2
  st=${PIPESTATUS[0]}
  cat "$log"
  rm -f "$log"
  return $st
}
mkdir -p "$PREFIX/etc/apt/apt.conf.d"
printf 'Acquire::http::Timeout "30";\nAcquire::https::Timeout "30";\nAcquire::Retries "3";\n' > "$PREFIX/etc/apt/apt.conf.d/99novan"
perbaiki_dpkg
perbarui_daftar() {
  local n m keluaran st
  for n in 1 2; do
    if [ "$OFFLINE" = 1 ]; then keluaran=$(langsung pkg update -y); st=$?; else keluaran=$(langsung apt-get update); st=$?; fi
    if [ $st -eq 0 ] && ! echo "$keluaran" | grep -q '^E:'; then return 0; fi
    echo "Daftar paket gagal diunduh (percobaan $n dari 2). Cermin mungkin sedang sinkron. Menghapus daftar lama lalu mencoba lagi"
    rm -rf "$PREFIX/var/lib/apt/lists/"*
    sleep 4
  done
  for m in https://packages.termux.dev/apt/termux-main https://packages-cf.termux.dev/apt/termux-main https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main https://mirrors.ustc.edu.cn/termux/apt/termux-main https://mirrors.bfsu.edu.cn/termux/apt/termux-main; do
    echo "Mencoba cermin lain: $m"
    CERMIN="$m"
    rm -f "$PREFIX/etc/apt/sources.list"
    echo "deb $m stable main" > "$PREFIX/etc/apt/sources.list"
    rm -rf "$PREFIX/var/lib/apt/lists/"*
    keluaran=$(langsung apt-get update); st=$?
    if [ $st -eq 0 ] && ! echo "$keluaran" | grep -q '^E:'; then echo "Cermin ini berhasil"; return 0; fi
    sleep 2
  done
  return 1
}
unduh() {
  local tot sz pid
  tot=$(curl -fsSL -r 0-0 -D - -o /dev/null "$2" 2>/dev/null | tr -d '\\r' | grep -i '^content-range:' | tail -1 | sed 's|.*/||') || tot=0
  [ -n "$tot" ] || tot=0
  curl -fsSL -o "$1" "$2" &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    sz=$(stat -c %s "$1" 2>/dev/null || echo 0)
    if [ "$tot" -gt 0 ] 2>/dev/null; then echo "@@S $((sz*100/tot))"; fi
    echo "@@I Terunduh $((sz/1048576)) MB"
    sleep 1
  done
  wait "$pid"
}
CERMIN=""
kunci_cermin() {
  # Pastikan cermin pilihan tidak berganti sendiri sebelum alat diunduh.
  [ -n "$CERMIN" ] || return 0
  local now
  now=$(awk '/^deb /{print $2; exit}' "$PREFIX/etc/apt/sources.list" 2>/dev/null)
  if [ "$now" != "$CERMIN" ]; then
    echo "Cermin berganti sendiri, dikembalikan ke cermin tercepat: $CERMIN"
    rm -f "$PREFIX/etc/apt/sources.list"
    echo "deb $CERMIN stable main" > "$PREFIX/etc/apt/sources.list"
    apt-get update || true
  fi
}
pilih_cermin() {
  # Uji kecepatan cermin resmi dan cermin Asia (contoh 2 MB). Cermin acak bawaan tidak dipakai.
  command -v curl >/dev/null 2>&1 || return 0
  local arsi m kec res ukr nilai terbaik="" tercepat=0 sekarang resmi
  resmi=https://packages-cf.termux.dev/apt/termux-main
  arsi=$(dpkg --print-architecture 2>/dev/null); [ -n "$arsi" ] || arsi=aarch64
  sekarang=$(awk '/^deb /{print $2; exit}' "$PREFIX/etc/apt/sources.list" 2>/dev/null)
  echo "@@I Menguji kecepatan cermin unduhan"
  echo "Menguji kecepatan cermin unduhan, memilih yang tercepat"
  for m in https://packages.termux.dev/apt/termux-main $resmi https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main https://mirrors.ustc.edu.cn/termux/apt/termux-main https://mirrors.bfsu.edu.cn/termux/apt/termux-main; do
    res=$(curl -sL -m 10 -r 0-2097151 -o /dev/null -w '%{speed_download} %{size_download}' "$m/dists/stable/main/binary-$arsi/Packages.xz" 2>/dev/null)
    kec=${res%% *}; kec=${kec%%.*}; [ -n "$kec" ] || kec=0
    ukr=${res##* }; ukr=${ukr%%.*}; [ -n "$ukr" ] || ukr=0
    [ "$ukr" -ge 100000 ] 2>/dev/null || kec=0
    echo "Cermin $m: $((kec/1024)) KB/detik"
    nilai=$kec
    case "$m" in *packages*.termux.dev*) nilai=$((kec*2)) ;; esac
    if [ "$nilai" -gt "$tercepat" ] 2>/dev/null; then tercepat=$nilai; terbaik=$m; fi
  done
  if [ -z "$terbaik" ]; then
    echo "Uji cermin tidak berhasil, memakai cermin resmi"
    terbaik=$resmi
  fi
  CERMIN="$terbaik"
  echo "Memakai cermin: $terbaik"
  if [ "$terbaik" != "$sekarang" ]; then
    rm -f "$PREFIX/etc/apt/sources.list"
    echo "deb $terbaik stable main" > "$PREFIX/etc/apt/sources.list"
    rm -rf "$PREFIX/var/lib/apt/lists/"*
  fi
}
prefetch() {
  # Unduh paket secara paralel ke cache apt (file besar dipotong 4 bagian).
  # Bila gagal, tidak masalah: apt mengunduh seperti biasa.
  [ "$OFFLINE" = 1 ] && return 0
  command -v curl >/dev/null 2>&1 || return 0
  local AR D url nama ukr hash n=0 tot=0 sz w a b i h f p
  eval "$(apt-config shell AR Dir::Cache::Archives/d)"
  [ -n "$AR" ] || AR="$PREFIX/var/cache/apt/archives/"
  D="$TMPDIR/pf"; rm -rf "$D"; mkdir -p "$D/dl" "$AR"
  apt-get -y --print-uris install "$@" 2>/dev/null | grep "^'" > "$D/daftar"
  : > "$D/perlu"; : > "$D/cfg"
  while read -r url nama ukr hash; do
    url=${url#"'"}; url=${url%"'"}
    [ -n "$nama" ] && [ "$ukr" -gt 0 ] 2>/dev/null || continue
    if [ -f "$AR$nama" ] && [ "$(stat -c %s "$AR$nama")" = "$ukr" ]; then continue; fi
    n=$((n+1)); tot=$((tot+ukr))
    echo "$url $nama $ukr ${hash#SHA256:}" >> "$D/perlu"
  done < "$D/daftar"
  if [ "$n" -eq 0 ]; then rm -rf "$D"; return 0; fi
  echo "Mengunduh $n paket secara paralel, $((tot/1048576)) MB"
  echo "@@I Mengunduh $n paket, $((tot/1048576)) MB, secara paralel"
  while read -r url nama ukr hash; do
    if [ "$ukr" -ge 10485760 ]; then
      w=$((ukr/4))
      for i in 0 1 2 3; do
        a=$((i*w)); b=$((a+w-1)); [ "$i" -eq 3 ] && b=$((ukr-1))
        curl -fsSL --connect-timeout 15 --retry 3 --retry-delay 2 --speed-time 30 --speed-limit 1000 -r "$a-$b" -o "$D/dl/$nama.p$i" "$url" &
      done
    else
      echo 'url = "'"$url"'"' >> "$D/cfg"
      echo 'output = "'"$D/dl/$nama"'"' >> "$D/cfg"
    fi
  done < "$D/perlu"
  if [ -s "$D/cfg" ]; then
    curl -fsSL -Z --parallel-max 6 --connect-timeout 15 --retry 3 --retry-delay 2 --speed-time 30 --speed-limit 1000 -K "$D/cfg" &
  fi
  while [ -n "$(jobs -r)" ]; do
    sz=$(du -sb "$D/dl" 2>/dev/null | cut -f1); [ -n "$sz" ] || sz=0
    echo "@@S $((sz*100/tot))"
    echo "@@I Terunduh $((sz/1048576)) dari $((tot/1048576)) MB"
    sleep 1
  done
  wait
  while read -r url nama ukr hash; do
    f="$D/dl/$nama"
    if [ "$ukr" -ge 10485760 ]; then
      cat "$f".p0 "$f".p1 "$f".p2 "$f".p3 > "$f" 2>/dev/null
      rm -f "$f".p0 "$f".p1 "$f".p2 "$f".p3
    fi
    [ -f "$f" ] && [ "$(stat -c %s "$f")" = "$ukr" ] || { rm -f "$f"; continue; }
    if [ -n "$hash" ]; then
      h=$(sha256sum "$f" 2>/dev/null | cut -d' ' -f1)
      [ "$h" = "$hash" ] || { rm -f "$f"; continue; }
    fi
    mv -f "$f" "$AR$nama"
  done < "$D/perlu"
  rm -rf "$D"
  return 0
}
if [ "$OFFLINE" = 1 ]; then siapkan_offline; else pilih_cermin; fi
echo "@@P 0 8 Memperbarui daftar paket"
echo "1 dari 4: daftar paket"
perbarui_daftar || exit 1
kunci_cermin
echo "@@P 8 45 Memasang python, git, cmake dan alat lain"
echo "2 dari 4: memasang alat"
prefetch python git cmake ninja aapt2 apksigner unzip zip wget curl tar xz-utils
pasang python git cmake ninja aapt2 apksigner unzip zip wget curl tar xz-utils || exit 1
echo "@@P 45 70 Memasang Java (JDK)"
if dpkg -s openjdk-21 >/dev/null 2>&1 || dpkg -s openjdk-17 >/dev/null 2>&1; then
  echo "Java sudah terpasang"
else
  prefetch openjdk-17
  pasang openjdk-17 || pasang openjdk-21 || exit 1
fi
mkdir -p "$HOME/storage"
ln -sfn /sdcard/Download "$HOME/storage/downloads"
ln -sfn /sdcard "$HOME/storage/shared"
echo "@@P 70 72 Memeriksa NDK"
echo "3 dari 4: NDK arm64"
if [ -d "$HOME/android-ndk/toolchains" ]; then
  echo "NDK sudah ada"
else
  zlokal=$(ls -t /sdcard/Download/android-ndk-*aarch64*.tar.xz /sdcard/Download/android-ndk-*aarch64*.zip /sdcard/Download/*ndk*aarch64*.zip /sdcard/Download/*ndk*arm64*.zip 2>/dev/null | head -1)
  rm -rf "$TMPDIR/ndkx"; mkdir -p "$TMPDIR/ndkx"
  ekstrak() {
    case "$1" in
      *.tar.xz) tar -xJf "$1" -C "$TMPDIR/ndkx" ;;
      *.tar.gz|*.tgz) tar -xzf "$1" -C "$TMPDIR/ndkx" ;;
      *) unzip -q -o "$1" -d "$TMPDIR/ndkx" ;;
    esac
  }
  nb=""
  if [ "$OFFLINE" = 1 ]; then nb=$(unzip -Z1 "$BUNDEL" 2>/dev/null | grep -E -m1 '^ndk/.*(tar[.]xz|[.]zip)$'); fi
  if [ -n "$nb" ]; then
    echo "@@P 72 92 Mengekstrak NDK dari bundel offline"
    case "$nb" in
      *.tar.xz) unzip -p "$BUNDEL" "$nb" | tar -xJ -C "$TMPDIR/ndkx" || exit 3 ;;
      *) unzip -p "$BUNDEL" "$nb" > "$TMPDIR/ndk-bundel.zip" && unzip -q -o "$TMPDIR/ndk-bundel.zip" -d "$TMPDIR/ndkx" || exit 3; rm -f "$TMPDIR/ndk-bundel.zip" ;;
    esac
  elif [ -n "$zlokal" ]; then
    echo "Memakai NDK yang sudah ada di Download: $zlokal"
    echo "@@P 72 92 Mengekstrak NDK dari Download"
    ekstrak "$zlokal" || exit 3
  else
    base="https://github.com/lzhiyong/termux-ndk/releases/download/android-ndk"
    url=""
    ada() { curl -fsSL --connect-timeout 8 -m 12 -r 0-0 -o /dev/null "$1" > /dev/null 2>&1; }
    echo "Mencari berkas NDK di GitHub"
    for px in "" https://ghfast.top/ https://gh-proxy.com/; do
      [ -n "$px" ] && echo "Mencoba lewat cermin $px"
      for f in android-ndk-r29-aarch64.tar.xz android-ndk-r29-aarch64.zip; do
        if ada "$px$base/$f"; then url="$px$base/$f"; nf="$f"; break 2; fi
      done
    done
    if [ -z "$url" ]; then
      echo "Diagnosis: kode GitHub = $(curl -sSL --connect-timeout 8 -m 12 -r 0-0 -o /dev/null -w '%{http_code}' "$base/android-ndk-r29-aarch64.tar.xz" 2>&1)"
      echo "NDK tidak ditemukan otomatis."
      echo "Cara mudah: buka https://github.com/lzhiyong/termux-ndk/releases lewat peramban HP, unduh berkas android-ndk-r29-aarch64.tar.xz ke folder Download, lalu ketik: siap"
      exit 3
    fi
    echo "@@P 72 92 Mengunduh NDK, ukuran besar"
    echo "Sumber: $url"
    unduh "$TMPDIR/$nf" "$url" || exit 3
    echo "@@P 92 99 Mengekstrak NDK"
    ekstrak "$TMPDIR/$nf" || exit 3
    rm -f "$TMPDIR/$nf"
  fi
  t=$(find "$TMPDIR/ndkx" -maxdepth 3 -type d -name toolchains | head -1)
  if [ -z "$t" ]; then echo "Isi NDK tidak dikenali"; exit 3; fi
  rm -rf "$HOME/android-ndk"
  mv "$(dirname "$t")" "$HOME/android-ndk"
  rm -rf "$TMPDIR/ndkx"
fi
if [ "$OFFLINE" = 1 ]; then
  echo "@@P 97 99 Memulihkan SDK dan Gradle dari bundel"
  pulihkan_bundel
fi
echo "@@P 99 100 Selesai"
echo "4 dari 4: selesai"
""";

    static final String BANGUN = """
#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$HOME"
TTD_NAMA=""; TTD_P12=""; TTD_SANDI=""; TTD_ALIAS=""; TTD_SIDIK=""
if [ -f "$HOME/.novan-ttd" ]; then . "$HOME/.novan-ttd"; fi
bersih() { sed 's/[^A-Za-z0-9._-]/_/g; s/__*/_/g; s/^_//; s/_$//'; }
nama_apk() {
  # Nama berkas dari isi APK: <nama aplikasi>_v<versi>[_<varian>] tanpa .apk. Kosong bila APK tidak terbaca.
  local info baris p r v c l s n
  info=$(aapt2 dump badging "$1" 2>/dev/null) || return 0
  baris=$(echo "$info" | awk -F"'" '/^package:/{for(i=1;i<NF;i++){if($i=="package: name=")p=$(i+1); if($i ~ /versionName=$/)v=$(i+1); if($i ~ /versionCode=$/)c=$(i+1)} print p "|" v "|" c; exit}')
  p=${baris%%|*}; r=${baris#*|}; v=${r%%|*}; c=${r#*|}
  l=$(echo "$info" | awk -F"'" '/^application-label:/{print $2; exit}' | bersih)
  if [ -z "$l" ]; then l=$(printf '%s' "$p" | bersih); fi
  if [ -z "$l" ]; then return 0; fi
  v=$(printf '%s' "$v" | bersih)
  if [ -n "$v" ]; then n="${l}_v${v}"; elif [ -n "$c" ]; then n="${l}_kode${c}"; else n="$l"; fi
  s=$(printf '%s' "${2:-}" | sed -E 's/-(debug|release|unsigned|signed|aligned)//g; s/^app-?//' | bersih)
  if [ -n "$s" ]; then n="${n}_${s}"; fi
  echo "$n"
}
unduh() {
  local tot sz pid
  tot=$(curl -fsSL -r 0-0 -D - -o /dev/null "$2" 2>/dev/null | tr -d '\\r' | grep -i '^content-range:' | tail -1 | sed 's|.*/||') || tot=0
  [ -n "$tot" ] || tot=0
  curl -fsSL -o "$1" "$2" &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    sz=$(stat -c %s "$1" 2>/dev/null || echo 0)
    if [ "$tot" -gt 0 ] 2>/dev/null; then echo "@@S $((sz*100/tot))"; fi
    echo "@@I Terunduh $((sz/1048576)) MB"
    sleep 1
  done
  wait "$pid"
}
echo "@@P 0 3 Memeriksa Android SDK"
SDK="$HOME/android-sdk"
if [ ! -d "$SDK/build-tools" ] || [ ! -d "$SDK/platforms/android-34" ]; then
  echo "Memasang Android SDK (sekali saja, bisa beberapa ratus MB)"
  echo "@@P 3 10 Mengunduh Android command line tools"
  mkdir -p "$SDK/cmdline-tools"
  if [ ! -d "$SDK/cmdline-tools/latest" ]; then
    unduh "$TMPDIR/cmdtools.zip" "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" || exit 4
    rm -rf "$TMPDIR/cmdtoolsx"; mkdir -p "$TMPDIR/cmdtoolsx"
    unzip -q -o "$TMPDIR/cmdtools.zip" -d "$TMPDIR/cmdtoolsx" || exit 4
    mv "$TMPDIR/cmdtoolsx/cmdline-tools" "$SDK/cmdline-tools/latest"
    rm -f "$TMPDIR/cmdtools.zip"; rm -rf "$TMPDIR/cmdtoolsx"
  fi
  SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
  echo "@@P 10 14 Menyetujui lisensi Android"
  yes | "$SDKM" --sdk_root="$SDK" --licenses > /dev/null 2>&1 || true
  echo "@@P 14 40 Mengunduh dan memasang Android SDK, beberapa menit"
  "$SDKM" --sdk_root="$SDK" "platform-tools" "platforms;android-34" "build-tools;34.0.0" || exit 4
fi
echo "@@P 40 44 Menyiapkan proyek"
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
if [ -f "$HOME/android-ndk/source.properties" ]; then
  nv=$(grep -m1 '^Pkg.Revision' "$HOME/android-ndk/source.properties" | sed 's/.*= *//' | tr -d '\\r ')
  if [ -n "$nv" ] && [ ! -e "$SDK/ndk/$nv" ]; then mkdir -p "$SDK/ndk"; ln -sfn "$HOME/android-ndk" "$SDK/ndk/$nv"; fi
fi

arg="$1"
if [ -z "$arg" ]; then
  z=$(ls -t /sdcard/Download/*.zip 2>/dev/null | head -1)
  [ -n "$z" ] && arg="$z"
fi
if [ -z "$arg" ]; then
  if [ -f "./build.gradle" ] || [ -f "./build.gradle.kts" ] || [ -f "./gradlew" ]; then arg="."; fi
fi
if [ -z "$arg" ]; then
  echo "Tulis lokasi .zip atau folder proyek Gradle: bangun-gradle <lokasi> [tugas]"
  exit 2
fi

key=$(basename "$arg" .zip)
if [ "$key" = "." ]; then key=$(basename "$PWD"); fi
proj=""
if [ -d "$arg" ]; then
  proj="$arg"
elif [ -f "$arg" ]; then
  case "$arg" in
    *.zip)
      nama=$(basename "$arg" .zip)
      dest="$HOME/proyek/$nama"
      rm -rf "$dest"; mkdir -p "$dest"
      unzip -q -o "$arg" -d "$dest" || exit 2
      proj="$dest"
      ;;
    *) echo "Format tidak dikenali, harus folder atau berkas .zip"; exit 2 ;;
  esac
else
  echo "Tidak ditemukan: $arg"; exit 2
fi

aroot=""
if [ -f "$proj/apktool.yml" ] || [ -f "$proj/apktool.json" ]; then
  aroot="$proj"
else
  ay=$(find "$proj" -maxdepth 2 \\( -name apktool.yml -o -name apktool.json \\) -type f 2>/dev/null | head -1)
  if [ -n "$ay" ]; then aroot=$(dirname "$ay"); fi
fi
if [ -n "$aroot" ]; then
  echo "Proyek apktool terdeteksi: $aroot"
  if ! command -v apktool >/dev/null 2>&1; then
    echo "@@P 44 48 Memasang apktool"
    pkg install -y apktool || { echo "Gagal memasang apktool"; exit 2; }
  fi
  aap=$(command -v aapt2 || true)
  if [ -z "$aap" ]; then echo "aapt2 belum terpasang. Ketik: siap"; exit 2; fi
  anama=$(basename "$aroot")
  aout="$TMPDIR/$anama-tanpa-ttd.apk"
  rm -f "$aout"
  abuild="$aroot"
  if [ ! -f "$aroot/apktool.yml" ] && [ -f "$aroot/apktool.json" ]; then
    echo "Format apktool.json (Apktool M) terdeteksi, diubah ke apktool.yml pada salinan sementara"
    if ! command -v python3 >/dev/null 2>&1; then pkg install -y python || { echo "Gagal memasang python"; exit 2; }; fi
    abuild="$TMPDIR/apkproj"
    rm -rf "$abuild"
    cp -r "$aroot" "$abuild" || { echo "Gagal menyalin proyek"; exit 2; }
    python3 - "$abuild/apktool.json" "$abuild/apktool.yml" <<'PYEOF' || { echo "Gagal mengubah apktool.json"; exit 2; }
import json, sys
d = json.load(open(sys.argv[1]))
def q(v):
    return "'" + str(v).replace("'", "''") + "'"
def qn(v):
    t = str(v)
    return t if t.isdigit() else q(v)
def pick(*names):
    for n in names:
        if isinstance(d.get(n), dict):
            return d[n]
    return {}
L = ['version: 2.10.0']
L.append('apkFileName: ' + q(d.get('apkFileName', 'app.apk')))
L.append('isFrameworkApk: ' + str(bool(d.get('isFrameworkApk', False))).lower())
u = pick('UsesFramework', 'usesFramework')
L.append('usesFramework:')
L.append('  ids:')
for i in u.get('ids', [1]):
    L.append('  - ' + str(i))
if u.get('tag'):
    L.append('  tag: ' + q(u['tag']))
s = pick('sdkInfo', 'SdkInfo')
L.append('sdkInfo:')
for k in ('minSdkVersion', 'targetSdkVersion', 'maxSdkVersion'):
    if s.get(k):
        L.append('  ' + k + ': ' + qn(s[k]))
p = pick('PackageInfo', 'packageInfo')
L.append('packageInfo:')
if p.get('forcedPackageId'):
    L.append('  forcedPackageId: ' + qn(p['forcedPackageId']))
v = pick('VersionInfo', 'versionInfo')
L.append('versionInfo:')
if v.get('versionCode'):
    L.append('  versionCode: ' + qn(v['versionCode']))
if v.get('versionName'):
    L.append('  versionName: ' + q(v['versionName']))
L.append('compressionType: ' + str(bool(d.get('compressionType', False))).lower())
L.append('sharedLibrary: ' + str(bool(d.get('sharedLibrary', False))).lower())
L.append('sparseResources: ' + str(bool(d.get('sparseResources', False))).lower())
dn = d.get('doNotCompress') or []
if dn:
    L.append('doNotCompress:')
    for x in dn:
        L.append('- ' + q(x))
uf = d.get('unknownFiles') or {}
if uf:
    L.append('unknownFiles:')
    for k, val in uf.items():
        L.append('  ' + q(k) + ': ' + str(val))
open(sys.argv[2], 'w').write(chr(10).join(L) + chr(10))
PYEOF
  fi
  echo "@@P 48 75 Membangun dengan apktool"
  set -o pipefail
  apktool b -f --aapt "$aap" "$abuild" -o "$aout" 2>&1 | tee "$TMPDIR/apktool.log" || { set +o pipefail; echo "apktool gagal. Periksa log di atas."; exit 1; }
  set +o pipefail
  if ! command -v zipalign >/dev/null 2>&1; then pkg install -y zipalign >/dev/null 2>&1 || true; fi
  if command -v zipalign >/dev/null 2>&1; then
    echo "@@P 75 80 Merapikan APK"
    zipalign -p -f 4 "$aout" "$aout.al" && mv "$aout.al" "$aout" || echo "Perapian dilewati"
  fi
  echo "@@P 80 95 Menandatangani APK"
  mkdir -p "$aroot/build/outputs/apk/release"
  if [ -n "$TTD_P12" ] && [ -f "$TTD_P12" ]; then
    echo "Menandatangani langsung dengan tanda tangan pribadi: $TTD_NAMA"
    nm=$(nama_apk "$aout" ""); if [ -z "$nm" ]; then nm="$anama-apktool"; fi
    afin="$aroot/build/outputs/apk/release/$nm.apk"
    apksigner sign --ks "$TTD_P12" --ks-pass "pass:$TTD_SANDI" --key-pass "pass:$TTD_SANDI" --ks-key-alias "$TTD_ALIAS" --out "$afin" "$aout" || { echo "Gagal menandatangani APK dengan tanda tangan pribadi"; exit 1; }
  else
    aks="$HOME/.novan-debug.jks"
    if [ ! -f "$aks" ]; then
      keytool -genkeypair -keystore "$aks" -storepass android -keypass android -alias novan -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Novan Debug" >/dev/null 2>&1 || { echo "Gagal membuat tanda tangan bawaan"; exit 1; }
    fi
    nm=$(nama_apk "$aout" ""); if [ -z "$nm" ]; then nm="$anama-apktool"; fi
    afin="$aroot/build/outputs/apk/release/$nm.apk"
    apksigner sign --ks "$aks" --ks-pass pass:android --key-pass pass:android --ks-key-alias novan --out "$afin" "$aout" || { echo "Gagal menandatangani APK"; exit 1; }
  fi
  rm -f "$afin.idsig" "$aout"
  if [ "$abuild" != "$aroot" ]; then rm -rf "$abuild"; fi
  echo "@@P 97 99 Menyalin APK ke folder Download"
  mkdir -p /sdcard/Download
  cp "$afin" "/sdcard/Download/$(basename "$afin")"
  echo "Salinan: /sdcard/Download/$(basename "$afin")"
  echo "Selesai membangun proyek apktool"
  exit 0
fi

nroot=""
if [ -f "$proj/package.json" ] && [ -d "$proj/android" ]; then
  nroot="$proj"
elif [ "$(basename "$proj")" = "android" ] && [ -f "$proj/../package.json" ]; then
  nroot=$(cd "$proj/.." && pwd)
elif [ -f "$proj/package.json" ] && [ -f "$proj/config.xml" ]; then
  nroot="$proj"
else
  pj=$(find "$proj" -maxdepth 2 -name package.json -not -path '*/node_modules/*' 2>/dev/null | head -1)
  if [ -n "$pj" ] && { [ -d "$(dirname "$pj")/android" ] || [ -f "$(dirname "$pj")/config.xml" ]; }; then nroot=$(dirname "$pj"); fi
fi
if [ -n "$nroot" ]; then
  echo "Proyek Node terdeteksi: $nroot"
  if ! command -v node >/dev/null 2>&1; then
    echo "@@P 44 46 Memasang Node.js"
    pkg install -y nodejs || { echo "Gagal memasang Node.js"; exit 2; }
  fi
  if [ ! -d "$nroot/node_modules" ]; then
    echo "@@P 46 50 Memasang paket Node proyek, bisa lama"
    ( cd "$nroot" && npm install --no-audit --no-fund ) || { echo "npm install gagal. Periksa log di atas."; exit 2; }
  fi
  if ls "$nroot"/capacitor.config.* >/dev/null 2>&1 && [ -d "$nroot/android" ]; then
    echo "Menyelaraskan Capacitor"
    ( cd "$nroot" && npx --yes cap sync android ) || echo "Penyelarasan Capacitor dilewati"
  fi
  if [ -d "$nroot/android" ]; then
    proj="$nroot/android"
  elif [ -f "$nroot/config.xml" ]; then
    if [ ! -d "$nroot/platforms/android" ]; then
      echo "Menambah platform Android untuk Cordova"
      ( cd "$nroot" && npx --yes cordova platform add android ) || { echo "Gagal menambah platform Android Cordova"; exit 2; }
    fi
    proj="$nroot/platforms/android"
  fi
fi

wfiles=""
for wd in "$proj/.github/workflows" "$proj/../.github/workflows" "${nroot:-$proj}/.github/workflows"; do
  if [ -d "$wd" ]; then wfiles=$(ls "$wd"/*.yml "$wd"/*.yaml 2>/dev/null || true); break; fi
done
wfv=""
wft=""
wfx=""
if [ -n "$wfiles" ]; then
  echo "Berkas workflow GitHub ditemukan, dipakai sebagai petunjuk"
  wfv=$(grep -h 'gradle-version:' $wfiles 2>/dev/null | head -1 | sed 's/.*gradle-version://' | grep -o -E '[0-9]+([.][0-9]+)+' | head -1 || true)
  case "$wfv" in [0-9]*) ;; *) wfv="" ;; esac
  wfts=$(grep -h -o -E 'assemble[A-Z][A-Za-z]*' $wfiles 2>/dev/null | sort -u || true)
  wfn=$(echo "$wfts" | grep -c . || true)
  if [ "$wfn" = "1" ]; then wft="$wfts"
  elif echo "$wfts" | grep -q '^assembleDebug$'; then wft="assembleDebug"
  else wft=$(echo "$wfts" | head -1); fi
  wfx=""
  if grep -q -e '-x lint' $wfiles 2>/dev/null; then wfx="-x lint -x test"; fi
fi
gw="$proj/gradlew"
if [ ! -f "$gw" ]; then
  cand=$(find "$proj" -maxdepth 2 -name gradlew -type f | head -1)
  if [ -n "$cand" ]; then gw="$cand"; proj=$(dirname "$cand"); fi
fi
GR="./gradlew"
if [ -f "$gw" ]; then
  chmod 755 "$gw"
else
  echo "Berkas gradlew tidak ada di proyek. Memakai Gradle yang diunduh sesuai gradle-wrapper.properties."
  if [ ! -f "$proj/settings.gradle" ] && [ ! -f "$proj/settings.gradle.kts" ] && [ ! -f "$proj/build.gradle" ] && [ ! -f "$proj/build.gradle.kts" ]; then
    cand=$(find "$proj" -maxdepth 2 \\( -name settings.gradle -o -name settings.gradle.kts -o -name build.gradle -o -name build.gradle.kts \\) -type f | head -1)
    if [ -n "$cand" ]; then proj=$(dirname "$cand"); fi
  fi
  if [ ! -f "$proj/settings.gradle" ] && [ ! -f "$proj/settings.gradle.kts" ] && [ ! -f "$proj/build.gradle" ] && [ ! -f "$proj/build.gradle.kts" ]; then
    echo "Bukan proyek Gradle: tidak ada build.gradle atau settings.gradle di $proj"
    exit 2
  fi
  wp=$(find "$proj" -maxdepth 4 -name gradle-wrapper.properties -type f | head -1)
  gurl=""
  if [ -n "$wp" ]; then
    gurl=$(grep -m1 '^distributionUrl=' "$wp" | sed 's/^distributionUrl=//; s#https.*://#https://#' | tr -d '[:space:]')
  fi
  if [ -z "$gurl" ] && [ -n "$wfv" ]; then gurl="https://services.gradle.org/distributions/gradle-$wfv-bin.zip"; echo "Versi Gradle dari workflow: $wfv"; fi
  if [ -z "$gurl" ]; then
    agp=$(grep -rhoE 'com[.]android[.](application|library).{0,50}[0-9]+[.][0-9]+[.][0-9]+' --include=build.gradle --include=build.gradle.kts --include=settings.gradle --include=settings.gradle.kts --include=libs.versions.toml "$proj" 2>/dev/null | grep -oE '[0-9]+[.][0-9]+[.][0-9]+' | head -1 || true)
    if [ -z "$agp" ]; then
      agp=$(grep -rhE '^agp *=' --include=libs.versions.toml "$proj" 2>/dev/null | grep -oE '[0-9]+[.][0-9]+[.][0-9]+' | head -1 || true)
    fi
    gv="8.10.2"
    if [ -n "$agp" ]; then
      amaj=${agp%%.*}; arest=${agp#*.}; amin=${arest%%.*}
      if [ "$amaj" -ge 9 ]; then gv="9.3.1"
      elif [ "$amaj" -eq 8 ]; then
        if [ "$amin" -le 2 ]; then gv="8.5"
        elif [ "$amin" -le 5 ]; then gv="8.7"
        elif [ "$amin" -le 8 ]; then gv="8.10.2"
        else gv="8.13"; fi
      elif [ "$amaj" -le 7 ]; then gv="7.6.4"; fi
      echo "Versi AGP terbaca: $agp, memakai Gradle $gv"
    fi
    gurl="https://services.gradle.org/distributions/gradle-$gv-bin.zip"
  fi
  gz=$(basename "$gurl")
  gd="$HOME/.gradle-dist/${gz%.zip}"
  if [ ! -x "$gd/bin/gradle" ]; then
    echo "@@P 40 44 Mengunduh Gradle sekali saja"
    echo "Mengunduh Gradle dari $gurl"
    mkdir -p "$HOME/.gradle-dist"
    unduh "$TMPDIR/$gz" "$gurl" || { echo "Gagal mengunduh Gradle dari $gurl"; exit 2; }
    rm -rf "$TMPDIR/gradlex"; mkdir -p "$TMPDIR/gradlex"
    unzip -q -o "$TMPDIR/$gz" -d "$TMPDIR/gradlex" || { echo "Berkas Gradle rusak, ulangi"; exit 2; }
    gdir=$(find "$TMPDIR/gradlex" -mindepth 1 -maxdepth 1 -type d | head -1)
    rm -rf "$gd"; mv "$gdir" "$gd"
    rm -rf "$TMPDIR/gradlex" "$TMPDIR/$gz"
    chmod 755 "$gd/bin/gradle"
  fi
  GR="$gd/bin/gradle"
  gw="$proj/build.gradle"
  if [ ! -f "$gw" ]; then gw="$proj/settings.gradle"; fi
  if [ ! -f "$gw" ]; then gw="$proj"; fi
fi

if [ ! -f "$proj/local.properties" ] || ! grep -q "^sdk.dir=" "$proj/local.properties" 2>/dev/null; then
  echo "sdk.dir=$SDK" >> "$proj/local.properties"
fi

cm=$(command -v cmake || true)
if [ -z "$cm" ] || ! command -v ninja >/dev/null 2>&1; then
  if grep -rqs "externalNativeBuild" "$proj" --include=build.gradle --include=build.gradle.kts; then
    echo "Memasang cmake dan ninja milik HP (proyek ini memakai kode native)"
    pkg install -y cmake ninja || echo "Gagal memasang cmake dan ninja"
    cm=$(command -v cmake || true)
  fi
fi
cmv=""
if [ -n "$cm" ]; then
  cmv=$("$cm" --version 2>/dev/null | head -1 | grep -o -E '[0-9]+[.][0-9]+([.][0-9]+)?' | head -1 || true)
fi
echo "$cmv" > "$HOME/.novan-cmake-versi"
if [ -n "$cm" ]; then
  touch "$proj/local.properties"
  sed -i '/^cmake.dir=/d' "$proj/local.properties"
  echo "cmake.dir=$(dirname "$(dirname "$cm")")" >> "$proj/local.properties"
  echo "Memakai cmake milik HP $cmv (cmake unduhan Google tidak bisa jalan di HP)"
fi
if grep -rqs "externalNativeBuild" "$proj" --include=build.gradle --include=build.gradle.kts; then
  ck=$(ls "$HOME"/android-ndk/toolchains/llvm/prebuilt/*/bin/clang-[0-9]* 2>/dev/null | grep -v '[.]asli$' | head -1)
  if [ -n "$ck" ] && [ "$(head -c 4 "$ck" 2>/dev/null | tail -c 3)" = "ELF" ]; then
    et=$(od -An -tu1 -j16 -N1 "$ck" 2>/dev/null | tr -d ' ')
    echo "Memeriksa clang milik NDK: $ck (jenis ELF $et)"
    if [ "$et" = "2" ]; then
      echo "clang NDK ini berjenis ET_EXEC (bukan PIE), tidak bisa dijalankan lewat linker Android. Mencoba memakai clang milik HP"
      if ! command -v clang >/dev/null 2>&1; then pkg install -y clang lld || echo "Gagal memasang clang milik HP"; fi
      if command -v clang >/dev/null 2>&1; then
        res=$(ls -d "$(dirname "$(dirname "$ck")")"/lib/clang/* 2>/dev/null | head -1)
        if [ -n "$res" ]; then
          [ -e "$ck.asli" ] || mv "$ck" "$ck.asli"
          cat > "$ck" <<'WRAPEOF'
#!@PRE@/bin/sh
case "$0" in
  *clang++*) exec "@PRE@/bin/clang++" -resource-dir "@RES@" "$@" ;;
  *) exec "@PRE@/bin/clang" -resource-dir "@RES@" "$@" ;;
esac
WRAPEOF
          sed -i "s|@PRE@|$PREFIX|g; s|@RES@|$res|g" "$ck"
          chmod 755 "$ck"
          echo "clang NDK diganti pembungkus yang memakai clang milik HP (asli disimpan sebagai clang-NN.asli)"
        else
          echo "Folder resource clang di NDK tidak ditemukan, clang tidak diganti"
        fi
      fi
    fi
  fi
fi
mkdir -p "$HOME/.gradle/init.d"
cat > "$HOME/.gradle/init.d/novan.gradle" <<'NOVANEOF'
allprojects {
  afterEvaluate { p ->
    def a = p.extensions.findByName('android')
    def home = System.getenv('HOME')
    if (a != null && home != null) {
      def f = new File(home, 'android-ndk/source.properties')
      if (f.exists()) {
        def line = f.readLines().find { it.startsWith('Pkg.Revision') }
        def v = line == null ? null : line.split('=')[1].trim()
        try {
          if (v != null && a.ndkVersion != null && a.ndkVersion != v) {
            println 'NDK proyek ' + a.ndkVersion + ' diganti NDK HP ' + v
            a.ndkVersion = v
          }
        } catch (Throwable e) { }
      }
      def cf = new File(home, '.novan-cmake-versi')
      if (cf.exists()) {
        def cv = cf.text.trim()
        try {
          def cmo = a.externalNativeBuild.cmake
          if (cv != '' && cmo != null && cmo.version != cv) {
            println 'CMake proyek ' + cmo.version + ' diganti CMake HP ' + cv
            cmo.version = cv
          }
        } catch (Throwable e) { }
      }
    }
  }
}
NOVANEOF
dk="$HOME/.android/debug.keystore"
if [ ! -f "$dk" ] && command -v keytool >/dev/null 2>&1; then
  mkdir -p "$HOME/.android"
  keytool -genkeypair -keystore "$dk" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1 || true
fi
if [ -n "$wfiles" ]; then
  wfp=$(grep -h 'sdkmanager' $wfiles 2>/dev/null | grep -o -E '(platforms|build-tools);[A-Za-z0-9._-]+' | sort -u || true)
  for pk in $wfp; do
    if [ ! -d "$SDK/${pk//;//}" ]; then
      echo "Memasang $pk sesuai workflow"
      "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" "$pk" || echo "Gagal memasang $pk, dilewati"
    fi
  done
fi
ap=$(command -v aapt2 || true)
mkdir -p "$HOME/.gradle"
gp="$HOME/.gradle/gradle.properties"
touch "$gp"
if [ -n "$ap" ]; then
  sed -i '/^android.aapt2FromMavenOverride=/d' "$gp"
  echo "android.aapt2FromMavenOverride=$ap" >> "$gp"
  echo "Memakai aapt2 milik HP"
fi
if ! grep -q '^org.gradle.jvmargs=' "$gp" "$proj/gradle.properties" 2>/dev/null; then
  echo "org.gradle.jvmargs=-Xmx1536m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8" >> "$gp"
fi
if ! grep -q '^kotlin.compiler.execution.strategy=' "$gp" "$proj/gradle.properties" 2>/dev/null; then
  echo "kotlin.compiler.execution.strategy=in-process" >> "$gp"
fi
tugas="${2:-${wft:-assembleDebug}}"
echo "Membangun: $proj (tugas: $tugas)"
cd "$proj"
mkdir -p "$HOME/.novan-tugas"
echo "@@T $(cat "$HOME/.novan-tugas/$key.txt" 2>/dev/null || echo 0)"
echo "@@P 44 60 Menyiapkan Gradle dan dependensi"
ttdinit=""
if [ -n "$TTD_P12" ] && [ -f "$TTD_P12" ]; then
  echo "Tanda tangan pribadi $TTD_NAMA dipasang langsung ke Gradle, tanpa tanda tangan ulang"
  cat > "$TMPDIR/novan-ttd.init.gradle" <<EOF
allprojects { p ->
  p.afterEvaluate {
    try {
      def a = p.extensions.findByName('android')
      if (a != null && p.plugins.hasPlugin('com.android.application')) {
        def sc = a.signingConfigs.create('novanTtd')
        sc.storeFile = new File('$TTD_P12')
        sc.storePassword = '$TTD_SANDI'
        sc.keyAlias = '$TTD_ALIAS'
        sc.keyPassword = '$TTD_SANDI'
        sc.storeType = 'pkcs12'
        a.buildTypes.all { it.signingConfig = sc }
        a.productFlavors.all { it.signingConfig = sc }
      }
    } catch (Throwable e) {
      println 'Tanda tangan pribadi gagal dipasang ke Gradle: ' + e.message
    }
  }
}
EOF
  ttdinit="-I $TMPDIR/novan-ttd.init.gradle"
fi
set -o pipefail
"$GR" "$tugas" --no-daemon --console=plain $wfx $ttdinit 2>&1 | tee "$TMPDIR/gradle.log"
set +o pipefail
grep -c '^> Task ' "$TMPDIR/gradle.log" > "$HOME/.novan-tugas/$key.txt" || true
echo "@@P 97 99 Mencari APK hasil"
echo "Mencari APK hasil"
hasil=$(find "$proj" -path "*/build/outputs/apk/*" -name "*.apk" -newer "$gw" 2>/dev/null)
[ -z "$hasil" ] && hasil=$(find "$proj" -path "*/build/outputs/apk/*" -name "*.apk" 2>/dev/null)
if [ -z "$hasil" ]; then
  echo "Tidak ditemukan APK hasil. Periksa log di atas."
  exit 1
fi
echo "@@P 99 100 Menyalin APK ke folder Download"
mkdir -p /sdcard/Download
rm -f "$TMPDIR/novan-ttd.init.gradle"
for f in $hasil; do
  b=$(basename "$f")
  nm=$(nama_apk "$f" "${b%.apk}"); ub="$b"
  if [ -n "$nm" ]; then ub="$nm.apk"; fi
  if [ -n "$TTD_P12" ] && [ -f "$TTD_P12" ]; then
    sj=$(apksigner verify --print-certs "$f" 2>/dev/null | grep -i 'SHA-256 digest' | head -1 | sed 's/.*: *//' | tr -d ': ' | tr 'A-F' 'a-f')
    want=$(echo "$TTD_SIDIK" | tr -d ': ' | tr 'A-F' 'a-f')
    nb="$ub"
    if [ -n "$want" ] && [ "$sj" = "$want" ]; then
      cp "$f" "/sdcard/Download/$nb"
      echo "Salinan: /sdcard/Download/$nb"
      continue
    fi
    echo "APK $b belum memakai tanda tangan pribadi (tidak diterapkan oleh Gradle). Ditandatangani sekali dengan tanda tangan pribadi."
    if apksigner sign --ks "$TTD_P12" --ks-pass "pass:$TTD_SANDI" --key-pass "pass:$TTD_SANDI" --ks-key-alias "$TTD_ALIAS" --out "$TMPDIR/$nb" "$f"; then
      cp "$TMPDIR/$nb" "/sdcard/Download/$nb"
      rm -f "$TMPDIR/$nb" "$TMPDIR/$nb.idsig"
      echo "Salinan: /sdcard/Download/$nb"
      continue
    fi
    echo "Tanda tangan pribadi gagal, APK disalin apa adanya"
  fi
  if [ -f "$dk" ] && ! apksigner verify "$f" >/dev/null 2>&1; then
    echo "APK belum bertanda tangan, ditandatangani dengan kunci bawaan: $b"
    nb="$(echo "${ub%.apk}" | sed 's/-unsigned//')_kunci-bawaan.apk"
    if apksigner sign --ks "$dk" --ks-pass pass:android --key-pass pass:android --ks-key-alias androiddebugkey --out "$TMPDIR/$nb" "$f"; then
      cp "$TMPDIR/$nb" "/sdcard/Download/$nb"
      rm -f "$TMPDIR/$nb" "$TMPDIR/$nb.idsig"
      echo "Salinan: /sdcard/Download/$nb"
      continue
    fi
    echo "Tanda tangan bawaan gagal, APK disalin apa adanya"
  fi
  cp "$f" "/sdcard/Download/$ub"
  echo "Salinan: /sdcard/Download/$ub"
done
echo "Selesai membangun proyek Gradle"
""";

    static boolean sudahSiap() {
        return new File(Env.home, ".siap-selesai").exists() && new File(Env.prefix, "bin/bash").exists();
    }

    /** Menulis skrip bangun-gradle terbaru ke usr/bin (tiap aplikasi dibuka, hanya bila isinya berbeda). */
    static void pasangBangun() {
        Bongkar.pasang();
        try {
            File f = new File(Env.prefix, "bin/bangun-gradle");
            if (f.exists()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = new FileInputStream(f)) { copy(in, bo); }
                if (bo.toString("UTF-8").equals(BANGUN)) { f.setExecutable(true, false); return; }
            }
            if (MainActivity.novanBusy) return;
            Builder.write(f, BANGUN);
            f.setExecutable(true, false);
        } catch (Throwable e) { }
    }

    /** Dipanggil tiap aplikasi dibuka: hanya menulis skrip bangun-gradle. Unduhan alat TIDAK jalan sendiri; baru mulai saat membangun APK. */
    static void otomatis() {
        if (!busy) pasangBangun();
    }

    /** Dipanggil saat Bangun APK ditekan tetapi alat belum siap: pakai bundel offline di Download bila ada, kalau tidak unduh dari internet. */
    static void mulaiSiap() {
        ulangOtomatis = 0;
        Bundel.tautanGagal = false;
        File bd = Bundel.cari();
        if (bd != null) {
            out("Bundel offline ditemukan di Download: " + bd.getName() + ". Alat dipasang dari bundel, tanpa internet.");
            say("Bundel offline ditemukan. Memasang alat tanpa internet.");
            start("impor", bd.getPath());
        } else {
            out("Bundel tidak ada di Download. Bundel alat diunduh dari tautan; bagian yang kurang diunduh dari sumber asli Termux. Butuh waktu agak lama.");
            say("Bundel alat diunduh dari tautan. Tunggu sampai selesai.");
            start("siap", "");
        }
    }

    static void siap() throws Exception {
        pasangBangun();
        // Alat belum ada: pakai bundel di Download bila ada, kalau tidak unduh bundel dari tautan.
        // Bila gagal, lanjut memakai sumber asli Termux (alur biasa di bawah).
        if (!Bundel.penanda().exists() && !sudahSiap()) {
            File b = Bundel.cari();
            if (b == null) b = Bundel.dariTautan();
            if (b != null) { Bundel.impor(b); return; }
        }
        File bash = new File(Env.prefix, "bin/bash");
        if (!bash.exists()) { Progres.window(0, 15); bootstrap(); Progres.window(15, 100); }
        File s = new File(Env.home, "siap.sh");
        Builder.write(s, SIAP);
        int c = Builder.exec(Env.home, bash.getPath(), s.getPath());
        if (c == 0) {
            ulangOtomatis = 0;
            new File(Env.home, ".siap-selesai").createNewFile();
            Bundel.bersihkan();
            autoBangun();
        } else if (c == 3) {
            gagal("Alat terpasang, tetapi NDK belum terpasang", "NDK belum terpasang");
        } else {
            gagal("Penyiapan belum selesai, kode " + c, "Penyiapan belum selesai");
        }
    }

    /** Setelah alat siap: bila sebelumnya tombol Bangun APK ditekan saat alat belum siap, lanjutkan
     *  membangun otomatis tanpa perlu diketik lagi. Kalau tidak, cukup beri tahu cara memakainya. */
    static void autoBangun() throws Exception {
        if (MainActivity.tungguBangun) {
            MainActivity.tungguBangun = false;
            final String lanjut = MainActivity.perintahTunggu == null || MainActivity.perintahTunggu.isEmpty() ? "bangun-gradle" : MainActivity.perintahTunggu;
            MainActivity.perintahTunggu = "";
            out("Alat siap. Melanjutkan otomatis: membangun APK sekarang.");
            say("Alat siap. Melanjutkan otomatis, membangun APK sekarang");
            Progres.selesai(true, "Alat siap. Melanjutkan otomatis: membangun APK sekarang.");
            MainActivity.H.post(new Runnable() {
                int coba = 0;
                @Override public void run() {
                    // Penyiapan masih menandai busy sampai thread-nya benar-benar selesai; tunggu dulu supaya bangun tidak tertahan selamanya.
                    if (busy && coba++ < 100) { MainActivity.H.postDelayed(this, 300); return; }
                    MainActivity.add("$ " + lanjut);
                    MainActivity.run(lanjut);
                }
            });
            return;
        }
        out("Alat siap. Untuk proyek Gradle: taruh berkas .zip proyek di folder Download lalu ketik bangun-gradle (atau ketuk tombol Bangun APK), atau ketik bangun-gradle <lokasi> [tugas]. Android SDK dipasang otomatis saat pertama dipakai.");
        say("Alat siap. Tekan tombol Bangun APK");
        KeepAliveService.selesai(MainActivity.ctx, "Alat siap. Tekan tombol Bangun APK.");
        Progres.selesai(true, "SIAP. Semua alat sudah terpasang. Anda bisa menjalankan perintah, dan membangun proyek dengan bangun-gradle atau tombol Bangun APK.");
    }

    static String bootstrapUrl() throws Exception {
        String arch = Bundel.arsitektur();
        org.json.JSONArray rel = new org.json.JSONArray(httpText("https://api.github.com/repos/termux/termux-packages/releases?per_page=30"));
        String best = null, any = null;
        for (int i = 0; i < rel.length(); i++) {
            org.json.JSONObject r = rel.getJSONObject(i);
            String tag = r.optString("tag_name");
            org.json.JSONArray as = r.optJSONArray("assets");
            if (!tag.startsWith("bootstrap-") || as == null) continue;
            for (int j = 0; j < as.length(); j++) {
                org.json.JSONObject a = as.getJSONObject(j);
                if (!a.optString("name").equals("bootstrap-" + arch + ".zip")) continue;
                String u = a.optString("browser_download_url");
                if (any == null) any = u;
                if (best == null && tag.contains("android-7")) best = u;
            }
        }
        String url = best != null ? best : any;
        if (url == null) throw new IOException("Bootstrap Termux tidak ditemukan");
        out("Sumber: " + url);
        return url;
    }

    /** Berkas bootstrap Termux yang disimpan (dipakai untuk membuat bundel offline). Diunduh bila belum ada. */
    static File bootstrapCache() throws Exception {
        File c = new File(Env.home, ".bundel-cache/bootstrap.zip");
        if (c.isFile() && c.length() > 1000000) return c;
        c.getParentFile().mkdirs();
        String url = bootstrapUrl();
        out("Mengunduh bootstrap"); say("Mengunduh bootstrap");
        File part = new File(c.getPath() + ".part");
        download(url, part);
        if (!part.renameTo(c)) throw new IOException("Bootstrap gagal disimpan");
        return c;
    }

    static void bootstrap() throws Exception {
        File tmp;
        File lokal = new File(Env.home, ".bundel/bootstrap/bootstrap.zip");
        if (lokal.isFile()) {
            Progres.tahap(0, 70, "Memakai bootstrap dari bundel offline");
            out("Memakai bootstrap dari bundel offline"); say("Memakai bootstrap dari bundel");
            tmp = lokal;
        } else {
            Progres.tahap(0, 10, "Mencari bootstrap Termux terbaru");
            out("Mencari bootstrap Termux terbaru"); say("Mencari bootstrap Termux");
            Progres.tahap(10, 70, "Mengunduh bootstrap Termux");
            tmp = bootstrapCache();
        }
        Progres.tahap(70, 90, "Mengekstrak bootstrap");
        out("Mengekstrak"); say("Mengekstrak");
        int n = extractZip(tmp, Env.prefix);
        File ss = new File(Env.prefix, "etc/termux/bootstrap/termux-bootstrap-second-stage.sh");
        if (ss.exists()) {
            Progres.tahap(90, 100, "Tahap kedua pemasangan");
            out("Tahap kedua pemasangan"); say("Tahap kedua pemasangan");
            ss.setExecutable(true, false);
            int c = Builder.exec(Env.home, new File(Env.prefix, "bin/bash").getPath(), ss.getPath());
            if (c != 0) out("Tahap kedua selesai dengan kode " + c);
        }
        record("bootstrap");
        out("Bootstrap selesai: " + n + " berkas"); say("Bootstrap selesai");
    }

    static void download(String url, File dest) throws IOException {
        HttpURLConnection h = open(url);
        long total = h.getContentLengthLong(), got = 0;
        int lastPct = 0;
        try (InputStream in = h.getInputStream(); OutputStream o = new FileOutputStream(dest)) {
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) {
                o.write(b, 0, n); got += n;
                if (total > 0) {
                    int pct = (int) (got * 100 / total);
                    Progres.sub(pct);
                    if (pct >= lastPct + 20) { lastPct = pct - pct % 20; out("Unduh " + lastPct + " persen"); say(lastPct + " persen"); }
                }
            }
        }
    }

    static void record(String name) throws IOException {
        File f = new File(Env.prefix, "etc/installed.txt");
        HashSet<String> s = new LinkedHashSet<>();
        if (f.exists()) try (BufferedReader r = new BufferedReader(new FileReader(f))) { String l; while ((l = r.readLine()) != null) s.add(l); }
        s.add(name);
        try (PrintWriter w = new PrintWriter(new FileWriter(f))) { for (String x : s) w.println(x); }
    }

    static File safe(File dir, String name) throws IOException {
        while (name.startsWith("./")) name = name.substring(2);
        while (name.startsWith("/")) name = name.substring(1);
        File o = new File(dir, name);
        String d = dir.getCanonicalPath();
        String p = o.getCanonicalPath();
        if (!p.equals(d) && !p.startsWith(d + File.separator)) throw new IOException("Jalur berbahaya: " + name);
        return o;
    }

    static boolean execPath(String n) { return n.startsWith("bin/") || n.contains("/bin/") || n.startsWith("libexec/") || n.contains("/libexec/")
        || n.startsWith("lib/apt/methods/") || n.equals("lib/apt/apt-helper"); }

    static int extract(File f, File dir) throws IOException {
        int m1, m2;
        try (InputStream in = new FileInputStream(f)) { m1 = in.read(); m2 = in.read(); }
        if (m1 == 'P' && m2 == 'K') return extractZip(f, dir);
        if (m1 == 0x1f && m2 == 0x8b) return extractTar(f, dir);
        throw new IOException("Format tidak didukung. Gunakan .zip atau .tar.gz");
    }

    static void link(File dir, String target, String path) throws IOException {
        File l = safe(dir, path);
        l.getParentFile().mkdirs();
        l.delete();
        try { Os.symlink(target, l.getPath()); } catch (Exception e) { throw new IOException("Symlink gagal: " + path); }
    }

    static int extractZip(File f, File dir) throws IOException {
        int cnt = 0;
        String links = null;
        try (ZipInputStream z = new ZipInputStream(new BufferedInputStream(new FileInputStream(f)))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String name = e.getName();
                if (name.equals("SYMLINKS.txt")) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    copy(z, bo);
                    links = bo.toString("UTF-8");
                    continue;
                }
                File o = safe(dir, name);
                if (e.isDirectory()) { o.mkdirs(); continue; }
                o.getParentFile().mkdirs();
                try (OutputStream w = new FileOutputStream(o)) { copy(z, w); }
                if (execPath(name)) o.setExecutable(true, false);
                if (++cnt % 300 == 0) out(cnt + " berkas");
            }
        }
        if (links != null) for (String l : links.split("\n")) {
            String[] p = l.trim().split("\u2190");
            if (p.length == 2) { link(dir, p[0], p[1]); cnt++; }
        }
        return cnt;
    }

    static void copy(InputStream in, OutputStream o) throws IOException {
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
    }

    static void skip(InputStream in, long n) throws IOException {
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) { if (in.read() < 0) return; s = 1; }
            n -= s;
        }
    }

    static boolean full(InputStream in, byte[] b) throws IOException {
        int o = 0;
        while (o < b.length) { int n = in.read(b, o, b.length - o); if (n < 0) return false; o += n; }
        return true;
    }

    static String str(byte[] h, int off, int len) {
        int e = off;
        while (e < off + len && h[e] != 0) e++;
        try { return new String(h, off, e - off, "UTF-8"); } catch (Exception x) { return ""; }
    }

    static long oct(byte[] h, int off, int len) {
        String s = str(h, off, len).trim();
        if (s.isEmpty()) return 0;
        try { return Long.parseLong(s, 8); } catch (Exception e) { return 0; }
    }

    static int extractTar(File f, File dir) throws IOException {
        int cnt = 0;
        String longName = null, paxPath = null;
        try (InputStream in = new GZIPInputStream(new BufferedInputStream(new FileInputStream(f), 65536))) {
            byte[] h = new byte[512];
            while (full(in, h)) {
                if (h[0] == 0) break;
                String name = str(h, 0, 100);
                if (str(h, 257, 5).equals("ustar")) { String px = str(h, 345, 155); if (!px.isEmpty()) name = px + "/" + name; }
                if (longName != null) { name = longName; longName = null; }
                if (paxPath != null) { name = paxPath; paxPath = null; }
                long size = oct(h, 124, 12), mode = oct(h, 100, 8);
                int type = h[156];
                long pad = (512 - size % 512) % 512;
                if (type == 'L' || type == 'x' || type == 'g') {
                    byte[] d = new byte[(int) size];
                    if (!full(in, d)) break;
                    skip(in, pad);
                    String s = new String(d, "UTF-8");
                    if (type == 'L') longName = s.trim().replace("\u0000", "");
                    else if (type == 'x') for (String r : s.split("\n")) { int i = r.indexOf(" path="); if (i >= 0) paxPath = r.substring(i + 6); }
                    continue;
                }
                if (type == '5') { safe(dir, name).mkdirs(); skip(in, size + pad); continue; }
                if (type == '2') { link(dir, str(h, 157, 100), name); cnt++; skip(in, size + pad); continue; }
                if (type == '1') {
                    File src = safe(dir, str(h, 157, 100)), o = safe(dir, name);
                    o.getParentFile().mkdirs();
                    if (src.exists()) try (InputStream a = new FileInputStream(src); OutputStream w = new FileOutputStream(o)) { copy(a, w); }
                    if ((mode & 0111) != 0) o.setExecutable(true, false);
                    cnt++; skip(in, size + pad); continue;
                }
                if (type == 0 || type == '0') {
                    File o = safe(dir, name);
                    o.getParentFile().mkdirs();
                    try (OutputStream w = new FileOutputStream(o)) {
                        long left = size;
                        byte[] b = new byte[16384];
                        while (left > 0) {
                            int n = in.read(b, 0, (int) Math.min(b.length, left));
                            if (n < 0) throw new IOException("Arsip terpotong");
                            w.write(b, 0, n); left -= n;
                        }
                    }
                    if ((mode & 0111) != 0 || execPath(name)) o.setExecutable(true, false);
                    skip(in, pad);
                    if (++cnt % 300 == 0) out(cnt + " berkas");
                } else skip(in, size + pad);
            }
        }
        return cnt;
    }
}
