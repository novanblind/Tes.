package com.novan.audiolabnovan.gemini;

import android.content.Context;
import android.content.SharedPreferences;

/** Penyimpanan pengaturan fitur Voice note Gemini (kunci API, pilihan terakhir, daftar model). */
public final class GeminiStore {
    private GeminiStore() {}

    public static final String PREFS_NAME = "gemini_suara_novan_prefs";
    public static final String KEY_PREF = "gemini_api_key";

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static String cleanKey(CharSequence key) {
        return String.valueOf(key).replaceAll("\\s+", "");
    }

    public static String getKey(Context c) {
        return prefs(c).getString(KEY_PREF, "");
    }

    public static void saveKey(Context c, CharSequence key) {
        prefs(c).edit().putString(KEY_PREF, cleanKey(key)).apply();
    }

    public static void resetKey(Context c) {
        prefs(c).edit().remove(KEY_PREF).apply();
    }
}
