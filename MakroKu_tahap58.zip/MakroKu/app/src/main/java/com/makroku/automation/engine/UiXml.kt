package com.makroku.automation.engine

/** Membaca keluaran `uiautomator dump` (XML hierarki layar) untuk mencari elemen berdasarkan tulisannya. */
object UiXml {
    private val node = Regex("<node [^>]*>")
    private val teks = Regex("\\btext=\"([^\"]*)\"")
    private val desk = Regex("content-desc=\"([^\"]*)\"")
    private val batas = Regex("bounds=\"\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]\"")

    private fun baca(s: String) = s
        .replace("&quot;", "\"").replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&#10;", "\n").replace("&amp;", "&")

    /** Titik tengah (x, y) elemen pertama yang tulisan atau deskripsinya mengandung [cari]; null bila tidak ada. */
    fun cari(xml: String, cari: String): Pair<Int, Int>? {
        val n = cari.trim()
        if (n.isEmpty()) return null
        var terbaik: Pair<Int, Int>? = null
        for (m in node.findAll(xml)) {
            val tag = m.value
            val t = baca(teks.find(tag)?.groupValues?.get(1).orEmpty())
            val d = baca(desk.find(tag)?.groupValues?.get(1).orEmpty())
            val cocokPenuh = t.equals(n, ignoreCase = true) || d.equals(n, ignoreCase = true)
            val cocokSebagian = t.contains(n, ignoreCase = true) || d.contains(n, ignoreCase = true)
            if (!cocokPenuh && !cocokSebagian) continue
            val b = batas.find(tag) ?: continue
            val (x1, y1, x2, y2) = b.destructured
            val a = x1.toInt(); val bb = y1.toInt(); val c = x2.toInt(); val dd = y2.toInt()
            if (c <= a || dd <= bb) continue
            val titik = Pair((a + c) / 2, (bb + dd) / 2)
            if (cocokPenuh) return titik
            if (terbaik == null) terbaik = titik
        }
        return terbaik
    }
}
