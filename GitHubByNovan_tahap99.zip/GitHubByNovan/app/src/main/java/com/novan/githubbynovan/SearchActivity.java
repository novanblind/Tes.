package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

public class SearchActivity extends Activity {
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        final Ui ui = new Ui(this, "Cari repositori");
        final EditText q = ui.edit("Kata kunci nama repositori", "Ketik sebagian nama", false, "");
        ui.button("Cari", v -> {
            String k = q.getText().toString().trim();
            if (k.isEmpty()) {
                ui.say("Kata kunci tidak boleh kosong.");
                return;
            }
            startActivity(new Intent(this, ReposActivity.class).putExtra("query", k));
        });
        ui.button("Kembali", v -> finish());
    }
}
