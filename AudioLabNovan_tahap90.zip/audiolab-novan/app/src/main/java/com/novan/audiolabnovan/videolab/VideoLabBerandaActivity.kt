package com.novan.audiolabnovan.videolab

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import com.novan.audiolabnovan.BerandaActivity
import com.novan.audiolabnovan.R
import com.novan.audiolabnovan.video.VideoFitur
import com.novan.audiolabnovan.Fitur as FiturAudio

/**
 * Tahap 87: kisi fitur Editor Video (isi VideoLab tahap 52 dipindahkan ke AudioLab).
 * Tiap tombol membuka [VideoLabActivity] dalam mode fitur itu (hanya bagian yang diperlukan yang tampil),
 * seperti kisi fitur audio. Video yang dibagikan dari pengelola berkas ikut terbawa ke fitur yang diketuk.
 */
class VideoLabBerandaActivity : BerandaActivity() {

    private val video: List<Uri> by lazy {
        val teks = intent.getStringExtra(VideoFitur.EXTRA_URI)
        if (teks.isNullOrEmpty()) emptyList() else listOf(Uri.parse(teks))
    }

    override fun daftarTampil(): List<FiturAudio.Def> =
        Fitur.DAFTAR.map { FiturAudio.Def(it.id, it.judul, it.simbol) }

    override fun tambahHeader(akar: LinearLayout) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(warna(R.color.bar_bg))
            setPadding(dp(8), dp(10), dp(16), dp(10))
        }
        val kembali = TextView(this).apply {
            text = "\u2190"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(warna(R.color.bar_teks))
            contentDescription = "Kembali"
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        bar.addView(kembali, LinearLayout.LayoutParams(dp(48), dp(48)))
        val judul = TextView(this).apply {
            text = "Editor Video"
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(warna(R.color.bar_teks))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        bar.addView(
            judul,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) }
        )
        akar.addView(
            bar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
    }

    override fun buka(d: FiturAudio.Def) {
        val i = Intent(this, VideoLabActivity::class.java).putExtra(Fitur.EXTRA, d.id)
        if (video.isNotEmpty()) {
            val u = video[0]
            i.action = Intent.ACTION_SEND
            i.putExtra(Intent.EXTRA_STREAM, u)
            i.clipData = ClipData.newRawUri("video", u)
            i.type = "video/*"
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(i)
    }
}
