package com.novan.filemanagermax

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import android.text.format.DateFormat
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Date
import java.util.concurrent.Executors

/**
 * Pembersih: berkas sementara, folder kosong, folder besar, dan aplikasi yang jarang dipakai.
 * Tanpa EXTRA_KIND layar ini menampilkan menu pilihan pembersihan.
 */
class CleanActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_KIND = "kind"
        const val TEMP = "temp"
        const val EMPTY = "empty"
        const val BIGDIRS = "bigdirs"
        const val UNUSED = "unused"
        const val CACHE = "cache"
        const val THUMBS = "thumbs"
        const val PARTIAL = "partial"
        const val APKLEFT = "apkleft"
        const val LEFTOVER = "leftover"
        private const val BIG = 100L * 1024 * 1024
        private const val DAY = 86400000L
        private val TEMP_EXT = setOf("tmp", "temp", "log", "bak", "old", "dmp")
        private val PARTIAL_EXT = setOf("crdownload", "part", "partial", "download", "opdownload", "!ut")
        private val APK_EXT = setOf("apk", "apks", "xapk", "apkm", "apk+")
        private val THUMB_DIRS = setOf(".thumbnails", ".thumbs", "LOST.DIR")
    }

    private class Item(
        val file: File?,
        val pkg: String?,
        val label: String,
        val detail: String,
        val size: Long
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var scanToken = 0

    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var kind: String? = null
    private var items: List<Item> = emptyList()
    private var needScan = true
    private var usagePrompted = false

    @Volatile
    private var cacheBlocked = false

    @Volatile
    private var cacheByStats = false
    private var cacheBlockedShown = false
    private val uninstallQueue = ArrayDeque<String>()

    private val uninstallLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { nextUninstall() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        kind = intent.getStringExtra(EXTRA_KIND)
        empty = findViewById(R.id.empty)
        rowAdapter = RowAdapter(onClick = { onClickRow(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        title = when (kind) {
            TEMP -> getString(R.string.clean_temp)
            EMPTY -> getString(R.string.clean_empty)
            BIGDIRS -> getString(R.string.clean_big)
            UNUSED -> getString(R.string.clean_unused)
            CACHE -> getString(R.string.clean_cache)
            THUMBS -> getString(R.string.clean_thumbs)
            PARTIAL -> getString(R.string.clean_partial)
            APKLEFT -> getString(R.string.clean_apkleft)
            LEFTOVER -> getString(R.string.clean_leftover)
            else -> getString(R.string.clean_title)
        }
        if (kind == null) showMenuRows()
    }

    override fun onResume() {
        super.onResume()
        if (kind != null && uninstallQueue.isEmpty() && (needScan || kind == UNUSED || (kind == CACHE && (cacheBlocked || cacheByStats)))) scan()
    }

    override fun onDestroy() {
        super.onDestroy()
        scanToken++
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    // ---------------------------------------------------------------- menu pilihan

    private fun showMenuRows() {
        fun row(icon: Int, name: Int, detail: Int, tag: String): Row {
            val n = getString(name)
            val d = getString(detail)
            return Row(icon, n, d, "$n, $d", tag)
        }
        rowAdapter.submit(
            listOf(
                row(R.drawable.ic_clean, R.string.clean_cache, R.string.clean_cache_detail, CACHE),
                row(R.drawable.ic_clean, R.string.clean_temp, R.string.clean_temp_detail, TEMP),
                row(R.drawable.ic_image, R.string.clean_thumbs, R.string.clean_thumbs_detail, THUMBS),
                row(R.drawable.ic_download, R.string.clean_partial, R.string.clean_partial_detail, PARTIAL),
                row(R.drawable.ic_apk, R.string.clean_apkleft, R.string.clean_apkleft_detail, APKLEFT),
                row(R.drawable.ic_folder, R.string.clean_leftover, R.string.clean_leftover_detail, LEFTOVER),
                row(R.drawable.ic_folder, R.string.clean_empty, R.string.clean_empty_detail, EMPTY),
                row(R.drawable.ic_chart, R.string.clean_big, R.string.clean_big_detail, BIGDIRS),
                row(R.drawable.ic_apk, R.string.clean_unused, R.string.clean_unused_detail, UNUSED)
            )
        )
        empty.visibility = View.GONE
    }

    // ---------------------------------------------------------------- pemindaian

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun openUsageSettings() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    private fun fileItem(f: File, size: Long, label: String = f.name): Item {
        val detail = Util.formatSize(this, size) + ", " + (f.parent ?: "")
        return Item(f, null, label, detail, size)
    }

    private fun scan() {
        val k = kind ?: return
        needScan = false
        val tk = ++scanToken
        items = emptyList()
        rowAdapter.submit(emptyList())
        invalidateOptionsMenu()
        if (k == UNUSED && !hasUsageAccess()) {
            empty.setText(R.string.clean_usage_needed)
            empty.visibility = View.VISIBLE
            supportActionBar?.subtitle = null
            if (!usagePrompted) {
                usagePrompted = true
                AlertDialog.Builder(this)
                    .setTitle(R.string.clean_unused)
                    .setMessage(R.string.clean_usage_needed)
                    .setPositiveButton(R.string.clean_usage_open) { _, _ -> openUsageSettings() }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
            return
        }
        empty.setText(R.string.clean_scanning)
        empty.visibility = View.VISIBLE
        supportActionBar?.subtitle = null
        executor.execute {
            val found: List<Item> = try {
                when (k) {
                    TEMP -> scanTemp(tk)
                    CACHE -> scanCache()
                    THUMBS -> scanFind(tk, { it.name in THUMB_DIRS }, { it.name.startsWith("thumbdata") })
                    PARTIAL -> scanFind(tk, { false }, { it.extension.lowercase() in PARTIAL_EXT })
                    APKLEFT -> scanFind(tk, { false }, { it.extension.lowercase() in APK_EXT })
                    LEFTOVER -> scanLeftover(tk)
                    EMPTY -> scanEmpty(tk)
                    BIGDIRS -> scanBig(tk)
                    else -> scanUnused()
                }
            } catch (e: Exception) {
                emptyList()
            }
            main.post {
                if (isFinishing || isDestroyed || tk != scanToken) return@post
                showItems(found)
            }
        }
    }

    private fun walkFind(
        dir: File, out: MutableList<Item>, top: Boolean, tk: Int,
        dirHit: (File) -> Boolean, fileHit: (File) -> Boolean
    ) {
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (tk != scanToken) return
            val n = k.name
            if (k.isDirectory) {
                if (java.nio.file.Files.isSymbolicLink(k.toPath())) continue
                if (top && n == "Android") continue
                if (n == ".FileManagerMaxTrash") continue
                if (dirHit(k)) {
                    val s = FileOps.sizeOf(k)
                    if (s > 0) out.add(fileItem(k, s))
                    continue
                }
                walkFind(k, out, false, tk, dirHit, fileHit)
            } else if (fileHit(k)) {
                out.add(fileItem(k, k.length()))
            }
        }
    }

    private fun scanFind(tk: Int, dirHit: (File) -> Boolean, fileHit: (File) -> Boolean): List<Item> {
        val out = ArrayList<Item>()
        for (v in Volumes.list(this)) walkFind(v.root, out, true, tk, dirHit, fileHit)
        return out.sortedByDescending { it.size }
    }

    private fun scanTemp(tk: Int): List<Item> =
        scanFind(tk, { false }, { it.extension.lowercase() in TEMP_EXT || it.name.endsWith("~") })

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() + " ($pkg)"
    } catch (e: Exception) {
        pkg
    }

    /** Cache tiap aplikasi di Android/data/<paket>/cache, terbesar dulu. */
    private fun scanCache(): List<Item> {
        val out = ArrayList<Item>()
        var readable = false
        for (v in Volumes.list(this)) {
            val apps = File(v.root, "Android/data").listFiles()
            if (apps != null) readable = true
            apps?.forEach { app ->
                val c = File(app, "cache")
                if (c.isDirectory) {
                    val s = FileOps.sizeOf(c)
                    if (s > 0) out.add(Item(c, null, appLabel(app.name), Util.formatSize(this, s) + ", " + v.label, s))
                }
            }
        }
        // Android 11 ke atas melarang membaca Android/data: daftar kosong berarti terhalang, bukan tanpa cache.
        val blocked = out.isEmpty() && !readable && Build.VERSION.SDK_INT >= 30
        cacheByStats = false
        cacheBlocked = blocked
        if (blocked && hasUsageAccess()) {
            val stats = scanCacheStats()
            if (stats != null) {
                cacheByStats = true
                cacheBlocked = false
                return stats
            }
        }
        return out.sortedByDescending { it.size }
    }

    /**
     * Cadangan saat Android/data terhalang: ukuran cache tiap aplikasi dari StorageStatsManager
     * (perlu akses penggunaan). Mengembalikan null bila sistem menolak.
     */
    private fun scanCacheStats(): List<Item>? {
        val ssm = getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val pm = packageManager
        val user = Process.myUserHandle()
        val out = ArrayList<Item>()
        var answered = false
        for (ai in pm.getInstalledApplications(0)) {
            try {
                val c = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, user).cacheBytes
                answered = true
                if (c > 0) {
                    out.add(Item(null, ai.packageName, pm.getApplicationLabel(ai).toString(),
                        Util.formatSize(this, c), c))
                }
            } catch (e: SecurityException) {
                return null
            } catch (e: Exception) {
                // aplikasi ini dilewati
            }
        }
        if (!answered) return null
        return out.sortedByDescending { it.size }
    }

    /** Sisa folder aplikasi yang sudah dicopot: Android/data, Android/obb, Android/media. */
    private fun scanLeftover(tk: Int): List<Item> {
        val out = ArrayList<Item>()
        for (v in Volumes.list(this)) {
            for (sub in listOf("data", "obb", "media")) {
                for (d in File(v.root, "Android/$sub").listFiles() ?: emptyArray()) {
                    if (tk != scanToken) return emptyList()
                    if (!d.isDirectory || !d.name.contains('.')) continue
                    val installed = try { packageManager.getPackageInfo(d.name, 0); true } catch (e: Exception) { false }
                    if (installed) continue
                    out.add(fileItem(d, FileOps.sizeOf(d), d.name))
                }
            }
        }
        return out.sortedByDescending { it.size }
    }

    /** Mengembalikan true bila [d] hanya berisi folder kosong (tanpa berkas satu pun). */
    private fun scanEmptyTree(d: File, out: MutableList<File>, top: Boolean, tk: Int): Boolean {
        val kids = d.listFiles() ?: return false
        var allEmpty = true
        val childEmpty = ArrayList<File>()
        for (k in kids) {
            if (tk != scanToken) return false
            if (k.isFile || java.nio.file.Files.isSymbolicLink(k.toPath())) { allEmpty = false; continue }
            if (k.name.startsWith(".") || (top && k.name == "Android")) { allEmpty = false; continue }
            val sub = ArrayList<File>()
            if (scanEmptyTree(k, sub, false, tk)) childEmpty.add(k)
            else { allEmpty = false; out.addAll(sub) }
        }
        if (!allEmpty) out.addAll(childEmpty)
        return allEmpty
    }

    private fun scanEmpty(tk: Int): List<Item> {
        val found = ArrayList<File>()
        for (v in Volumes.list(this)) scanEmptyTree(v.root, found, true, tk)
        return found.map { fileItem(it, 0L) }.sortedBy { it.file?.absolutePath }
    }

    private fun scanBig(tk: Int): List<Item> {
        val out = ArrayList<Item>()
        for (v in Volumes.list(this)) {
            for (t in v.root.listFiles() ?: emptyArray()) {
                if (tk != scanToken) return emptyList()
                if (!t.isDirectory || t.name == "Android" || t.name == ".FileManagerMaxTrash") continue
                val s = FileOps.sizeOf(t)
                if (s < BIG) continue
                out.add(fileItem(t, s))
                for (c in t.listFiles() ?: emptyArray()) {
                    if (!c.isDirectory) continue
                    val cs = FileOps.sizeOf(c)
                    if (cs >= BIG) out.add(fileItem(c, cs))
                }
            }
        }
        return out.sortedByDescending { it.size }.take(100)
    }

    private fun scanUnused(): List<Item> {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 365 * DAY, now)
        val last = HashMap<String, Long>()
        if (stats != null) {
            for (s in stats) {
                val t = s.lastTimeUsed
                if (t > (last[s.packageName] ?: 0L)) last[s.packageName] = t
            }
        }
        val limit = now - 30 * DAY
        val pm = packageManager
        val out = ArrayList<Pair<Long, Item>>()
        for (ai in pm.getInstalledApplications(0)) {
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (sys || ai.packageName == packageName) continue
            val t = last[ai.packageName] ?: 0L
            if (t >= limit) continue
            val used = if (t == 0L) getString(R.string.clean_never_used)
            else getString(R.string.clean_last_used, DateFormat.getMediumDateFormat(this).format(Date(t)))
            val size = File(ai.sourceDir).length()
            val detail = used + ", " + Util.formatSize(this, size)
            out.add(t to Item(null, ai.packageName, pm.getApplicationLabel(ai).toString(), detail, size))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    // ---------------------------------------------------------------- daftar hasil

    private fun showItems(found: List<Item>) {
        items = found
        val selectable = kind != BIGDIRS && !cacheByStats
        val rows = found.map { it ->
            val icon = when {
                it.pkg != null -> R.drawable.ic_apk
                it.file?.isDirectory == true -> R.drawable.ic_folder
                else -> R.drawable.ic_file
            }
            val spoken = if (it.pkg != null) "${it.label}, ${it.detail}"
            else "${getString(if (it.file?.isDirectory == true) R.string.folder else R.string.file)} ${it.label}, ${it.detail}"
            Row(icon, it.label, it.detail, spoken, it.pkg ?: it.file?.absolutePath ?: "", if (selectable) false else null)
        }
        rowAdapter.submit(rows)
        empty.setText(
            when (kind) {
                TEMP -> R.string.clean_none_temp
                EMPTY -> R.string.clean_none_empty
                BIGDIRS -> R.string.clean_none_big
                CACHE -> if (cacheBlocked) R.string.clean_cache_blocked else R.string.clean_none_cache
                THUMBS -> R.string.clean_none_thumbs
                PARTIAL -> R.string.clean_none_partial
                APKLEFT -> R.string.clean_none_apkleft
                LEFTOVER -> R.string.clean_none_leftover
                else -> R.string.clean_none_unused
            }
        )
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        if (kind == CACHE && cacheBlocked && !cacheBlockedShown) {
            cacheBlockedShown = true
            AlertDialog.Builder(this)
                .setTitle(R.string.clean_cache)
                .setMessage(R.string.clean_cache_blocked)
                .setPositiveButton(R.string.clean_cache_open) { _, _ ->
                    SystemFiles.openOrExplain(this, SystemFiles.androidData()) { say(it) }
                }
                .setNegativeButton(R.string.cancel, null)
                .apply {
                    if (!hasUsageAccess()) {
                        setNeutralButton(R.string.clean_usage_open) { _, _ -> openUsageSettings() }
                    }
                }
                .show()
        }
        updateSummary()
        invalidateOptionsMenu()
        val msg = getString(R.string.clean_found, rows.size)
        say(msg)
        empty.announceForAccessibility(msg)
    }

    private fun selectedItems(): List<Item> =
        rowAdapter.selectedIndices().filter { it in items.indices }.map { items[it] }

    private fun updateSummary() {
        val k = kind
        if (k == null) return
        if (k == BIGDIRS) {
            supportActionBar?.subtitle = getString(R.string.items_count, items.size)
            return
        }
        if (k == CACHE && cacheByStats) {
            supportActionBar?.subtitle = getString(
                R.string.clean_cache_stats_summary, items.size, Util.formatSize(this, items.sumOf { it.size })
            )
            return
        }
        val sel = selectedItems()
        supportActionBar?.subtitle = getString(
            R.string.clean_selected, sel.size, Util.formatSize(this, sel.sumOf { it.size })
        )
    }

    private fun onClickRow(i: Int) {
        val k = kind
        if (k == null) {
            val tag = rowAdapter.rows.getOrNull(i)?.tag as? String ?: return
            startActivity(Intent(this, CleanActivity::class.java).putExtra(EXTRA_KIND, tag))
            return
        }
        if (i !in items.indices) return
        if (k == BIGDIRS) {
            val f = items[i].file ?: return
            startActivity(
                Intent(this, BrowserActivity::class.java)
                    .putExtra(BrowserActivity.EXTRA_ROOT, f.absolutePath)
                    .putExtra(BrowserActivity.EXTRA_TITLE, f.name)
            )
            return
        }
        if (k == CACHE && cacheByStats) {
            val pkg = items[i].pkg ?: return
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                )
            } catch (e: Exception) {
                say(getString(R.string.cannot_open))
            }
            return
        }
        rowAdapter.setSelected(i, rowAdapter.rows[i].selected != true)
        updateSummary()
        invalidateOptionsMenu()
    }

    // ---------------------------------------------------------------- aksi

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.clean_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val k = kind
        val selectable = k != null && k != BIGDIRS && !(k == CACHE && cacheByStats)
        val action = menu.findItem(R.id.clean_action)
        action.isVisible = selectable && selectedItems().isNotEmpty()
        action.title = getString(if (k == UNUSED) R.string.clean_uninstall_selected else R.string.clean_delete_selected)
        menu.findItem(R.id.clean_select_all).isVisible = selectable && items.isNotEmpty()
        menu.findItem(R.id.clean_usage).isVisible = (k == UNUSED || (k == CACHE && cacheBlocked)) && !hasUsageAccess()
        menu.findItem(R.id.clean_rescan).isVisible = k != null
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.clean_select_all -> {
                rowAdapter.setAllSelected(true)
                updateSummary()
                invalidateOptionsMenu()
            }
            R.id.clean_usage -> openUsageSettings()
            R.id.clean_rescan -> scan()
            R.id.clean_action -> confirmAction()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun confirmAction() {
        val sel = selectedItems()
        if (sel.isEmpty()) return
        if (kind == UNUSED) {
            AlertDialog.Builder(this)
                .setTitle(R.string.clean_uninstall_selected)
                .setMessage(getString(R.string.clean_confirm_uninstall, sel.size))
                .setPositiveButton(R.string.clean_uninstall_selected) { _, _ ->
                    uninstallQueue.clear()
                    sel.mapNotNull { it.pkg }.forEach { uninstallQueue.addLast(it) }
                    nextUninstall()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
            return
        }
        val total = sel.sumOf { it.size }
        AlertDialog.Builder(this)
            .setTitle(R.string.clean_delete_selected)
            .setMessage(getString(R.string.clean_confirm_delete, sel.size, Util.formatSize(this, total)))
            .setPositiveButton(R.string.action_delete) { _, _ -> deleteItems(sel) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteItems(sel: List<Item>) {
        val dlg = AlertDialog.Builder(this).setMessage(R.string.deleting).setCancelable(false).show()
        executor.execute {
            var freed = 0L
            var ok = 0
            for (it in sel) {
                val f = it.file ?: continue
                if (f.deleteRecursively()) { freed += it.size; ok++ }
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                say(getString(R.string.clean_done, ok, Util.formatSize(this, freed)))
                needScan = true
                scan()
            }
        }
    }

    private fun nextUninstall() {
        val p = uninstallQueue.removeFirstOrNull()
        if (p == null) {
            needScan = true
            scan()
            return
        }
        try {
            uninstallLauncher.launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p")))
        } catch (e: Exception) {
            nextUninstall()
        }
    }
}
