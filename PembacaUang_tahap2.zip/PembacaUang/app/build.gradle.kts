plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.novan.pembacauang"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.novan.pembacauang"
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        // Hanya ABI yang dipakai aplikasi acuan (HP ARM). Membuang x86/x86_64 menghemat
        // belasan MB karena library OCR ML Kit dibawa per ABI.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        // Hanya bahasa yang dipakai; string bahasa lain dari library dibuang.
        resourceConfigurations += listOf("id", "en")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    packaging {
        resources.excludes += listOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/LICENSE*", "/META-INF/NOTICE*")
        jniLibs {
            // true = file .so DIKOMPRES di dalam APK (ukuran APK jauh lebih kecil, ~17,8 MB -> ~7,9 MB
            // untuk dua ABI) dan diekstrak ke penyimpanan saat instal.
            useLegacyPackaging = true
            // .so OCR di src/main/jniLibs (64-bit & 32-bit) dipakai, bukan salinan di dalam library ML Kit.
            pickFirsts += "**/libmlkit_google_ocr_pipeline.so"
        }
    }
}

// Pemeriksaan sebelum build: pastikan kedua .so ada dan arsitekturnya benar.
// Bila salah, build SENGAJA gagal dengan pesan jelas (bukan fitur OCR diam-diam tidak jalan).
val cekSoOcr by tasks.registering {
    val dir = layout.projectDirectory.dir("src/main/jniLibs")
    doLast {
        val cek = mapOf("arm64-v8a" to Pair(2, 183), "armeabi-v7a" to Pair(1, 40))
        cek.forEach { (abi, harapan) ->
            val f = dir.file("$abi/libmlkit_google_ocr_pipeline.so").asFile
            if (!f.exists()) {
                throw GradleException("GAGAL: file $abi/libmlkit_google_ocr_pipeline.so tidak ada di src/main/jniLibs. Kirim pesan ini ke Claude.")
            }
            val h = f.inputStream().use { it.readNBytes(20) }
            val magicOk = h.size == 20 && h[0].toInt() == 0x7f && h[1].toInt() == 'E'.code && h[2].toInt() == 'L'.code && h[3].toInt() == 'F'.code
            val kelas = h[4].toInt()
            val mesin = (h[18].toInt() and 0xff) or ((h[19].toInt() and 0xff) shl 8)
            if (!magicOk || kelas != harapan.first || mesin != harapan.second) {
                throw GradleException("GAGAL: $abi/libmlkit_google_ocr_pipeline.so bukan ELF yang sesuai (kelas=$kelas, mesin=$mesin, harapan kelas=${harapan.first}, mesin=${harapan.second}). Kirim pesan ini ke Claude.")
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(cekSoOcr) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // OCR ML Kit (model Latin sudah ikut di dalam aplikasi, jalan offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")

    testImplementation("junit:junit:4.13.2")
}
