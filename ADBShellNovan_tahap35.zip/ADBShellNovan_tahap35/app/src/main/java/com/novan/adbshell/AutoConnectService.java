package com.novan.adbshell;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.provider.Settings;

/** Setelah HP restart: nyalakan Wireless debugging (jika izin ada) lalu sambung otomatis. */
public class AutoConnectService extends Service {
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        final Context c = getApplicationContext();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("auto", "Sambung otomatis",
                NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "auto")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ADB Shell Novan")
                .setContentText("Menyambung ADB otomatis...")
                .build();
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        new Thread(() -> {
            try {
                Adb a = Adb.get(c);
                // Android mematikan Debugging nirkabel bila belum ada Wi-Fi, dan sebagian ROM
                // mematikan Debugging USB sesaat setelah menyala. Jadi pengaturan dinyalakan
                // ulang tiap putaran sampai benar-benar tersambung (maksimal 10 menit).
                long end = System.currentTimeMillis() + 600000L;
                while (!a.isConnected() && System.currentTimeMillis() < end) {
                    Latar.aktifkanDebugging(c);
                    if (Latar.modeTanpaWifiAktif(c) && Latar.sambungLokal(a)) break;
                    Latar.viaLokal = false;
                    try { a.sambungTls(c, 6000L); } catch (Throwable ignored) {}
                    if (a.isConnected()) break;
                    try { Thread.sleep(4000); } catch (InterruptedException e) { break; }
                }
                if (a.isConnected()) Latar.terapkanOtomatis(c, a);
                String pesan;
                if (a.isConnected()) {
                    pesan = "ADB tersambung otomatis.";
                    TtsHelper.speak(c, "ADB tersambung");
                }
                else if (!Latar.punyaIzinPengaturan(c))
                    pesan = "Gagal menyambung otomatis: izin sambung otomatis belum ada. Sambungkan sekali lewat Wi-Fi di aplikasi, atau tekan Aktifkan sambung otomatis.";
                else
                    pesan = "Gagal menyambung otomatis. Nyalakan Wi-Fi dan sambungkan ke jaringan yang sudah dikenal; Android hanya mengizinkan Debugging nirkabel saat Wi-Fi tersambung.";
                PairHelper.notify(c, pesan, false);
            } catch (Throwable e) {
                PairHelper.notify(c, "Sambung otomatis gagal: " + e, false);
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }).start();
        return START_NOT_STICKY;
    }
}
