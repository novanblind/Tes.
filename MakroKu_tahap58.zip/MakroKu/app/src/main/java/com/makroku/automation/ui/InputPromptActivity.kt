package com.makroku.automation.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import kotlinx.coroutines.CompletableDeferred
import java.util.concurrent.ConcurrentHashMap

/** Jembatan antara aksi "Dialog isian teks" dan activity-nya: aksi menunggu jawaban lewat [pending]. */
object PromptBridge {
    val pending = ConcurrentHashMap<String, CompletableDeferred<String?>>()
}

/** Dialog isian teks dari aksi "Dialog isian teks ke variabel". OK = kirim jawaban, Batal atau tutup = null. */
class InputPromptActivity : Activity() {
    private var id = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        id = intent.getStringExtra("id").orEmpty()
        val judul = intent.getStringExtra("title").orEmpty().ifBlank { "MakroKu" }
        val isi = intent.getStringExtra("text").orEmpty()
        val awal = intent.getStringExtra("default").orEmpty()
        val angka = intent.getBooleanExtra("numeric", false)
        val mode = intent.getStringExtra("mode").orEmpty()
        if (mode == "voice") {
            val i = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, judul)
                .putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, 7001)
            } catch (e: Exception) {
                PromptBridge.pending[id]?.complete(null)
                finish()
            }
            return
        }
        if (mode == "yesno") {
            AlertDialog.Builder(this)
                .setTitle(judul)
                .setMessage(isi)
                .setPositiveButton("Ya") { _, _ ->
                    PromptBridge.pending[id]?.complete("ya")
                    finish()
                }
                .setNegativeButton("Tidak") { _, _ ->
                    PromptBridge.pending[id]?.complete("tidak")
                    finish()
                }
                .setOnCancelListener {
                    PromptBridge.pending[id]?.complete(null)
                    finish()
                }
                .show()
            return
        }
        if (mode == "choice") {
            val daftar = intent.getStringArrayExtra("items") ?: emptyArray()
            AlertDialog.Builder(this)
                .setTitle(if (isi.isBlank()) judul else isi)
                .setItems(daftar) { _, w ->
                    PromptBridge.pending[id]?.complete(daftar[w])
                    finish()
                }
                .setNegativeButton("Batal") { _, _ ->
                    PromptBridge.pending[id]?.complete(null)
                    finish()
                }
                .setOnCancelListener {
                    PromptBridge.pending[id]?.complete(null)
                    finish()
                }
                .show()
            return
        }
        val kolom = EditText(this).apply {
            setText(awal)
            setSelection(awal.length)
            contentDescription = judul
            inputType = if (angka) {
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            } else InputType.TYPE_CLASS_TEXT
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(judul)
            .setMessage(isi)
            .setView(kolom)
            .setPositiveButton("OK") { _, _ ->
                PromptBridge.pending[id]?.complete(kolom.text.toString())
                finish()
            }
            .setNegativeButton("Batal") { _, _ ->
                PromptBridge.pending[id]?.complete(null)
                finish()
            }
            .setOnCancelListener {
                PromptBridge.pending[id]?.complete(null)
                finish()
            }
            .create()
        dlg.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7001) {
            val teks = if (resultCode == RESULT_OK)
                data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.takeIf { it.isNotBlank() }
            else null
            PromptBridge.pending[id]?.complete(teks)
            finish()
        }
    }

    override fun onDestroy() {
        // Bila ditutup tanpa jawaban (mis. layar berputar atau proses diganti), anggap dibatalkan.
        PromptBridge.pending[id]?.complete(null)
        super.onDestroy()
    }
}
