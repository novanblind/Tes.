package com.makroku.automation.adb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayDeque;

import java.util.function.Consumer;

/** Pencarian port pairing (mDNS), notifikasi input kode ala Brevent, pairing, dan sambung. */
public class PairHelper {
    static final String CHANNEL = "adbpair";
    static final int NOTIF_ID = 77;
    public static volatile int pairPort = -1;
    static volatile String pairHost = "127.0.0.1";
    public static volatile Consumer<String> sink;
    private static NsdManager.DiscoveryListener listener;

    // Antrean resolve: Android hanya mengizinkan satu resolveService aktif. Resolve yang
    // bertabrakan (error ALREADY_ACTIVE) dulu diabaikan diam-diam sehingga tombol kode tidak muncul.
    private static final Object kunci = new Object();
    private static final ArrayDeque<NsdServiceInfo> antrian = new ArrayDeque<>();
    private static boolean sibuk = false;
    private static final Handler ui = new Handler(Looper.getMainLooper());

    public static void say(Context c, String text, boolean withInput) {
        Consumer<String> s = sink;
        if (s != null) s.accept(text);
        notify(c, text, withInput);
    }

    static void notify(Context c, String text, boolean withInput) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Pairing ADB MakroKu",
                NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MakroKu")
                .setContentText(text)
                .setOnlyAlertOnce(false);
        if (withInput) {
            Intent i = new Intent(c, PairReceiver.class).setPackage(c.getPackageName());
            PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            RemoteInput ri = new RemoteInput.Builder("code").setLabel("Kode pairing 6 angka").build();
            Notification.Action a = new Notification.Action.Builder(
                    Icon.createWithResource(c, android.R.drawable.ic_menu_send),
                    "Masukkan kode pairing", pi).addRemoteInput(ri).build();
            b.addAction(a);
        }
        try { nm.notify(NOTIF_ID, b.build()); } catch (Exception ignored) {}
    }

    /** Mulai mencari layanan pairing yang muncul saat dialog "Pasangkan dengan kode" terbuka. */
    public static void startDiscovery(final Context ctx) {
        stopDiscovery(ctx);
        pairPort = -1;
        synchronized (kunci) { antrian.clear(); sibuk = false; }
        final NsdManager nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
        listener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) {}
            @Override public void onDiscoveryStopped(String t) {}
            @Override public void onStartDiscoveryFailed(String t, int e) { say(ctx, "Gagal mencari pairing: " + e, false); }
            @Override public void onStopDiscoveryFailed(String t, int e) {}
            @Override public void onServiceLost(NsdServiceInfo s) {}
            @Override public void onServiceFound(NsdServiceInfo si) {
                resolve(ctx, nsd, si);
            }
        };
        nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, listener);
        // Kolom kode langsung tersedia di notifikasi; port dicari di latar belakang.
        say(ctx, "Siap. Buka Opsi pengembang > Wireless debugging > Pasangkan dengan kode pairing, "
                + "lalu ketik kode 6 angka di notifikasi ini.", true);
    }

    private static void resolve(Context ctx, NsdManager nsd, NsdServiceInfo si) {
        synchronized (kunci) {
            if (sibuk) { antrian.add(si); return; }
            sibuk = true;
        }
        jalankanResolve(ctx, nsd, si, 0);
    }

    private static void resolveSelesai(Context ctx, NsdManager nsd) {
        NsdServiceInfo n;
        synchronized (kunci) {
            n = antrian.poll();
            if (n == null) { sibuk = false; return; }
        }
        jalankanResolve(ctx, nsd, n, 0);
    }

    private static void jalankanResolve(final Context ctx, final NsdManager nsd,
                                        final NsdServiceInfo si, final int coba) {
        try {
            nsd.resolveService(si, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo s, int e) {
                    if (coba < 4) ui.postDelayed(() -> jalankanResolve(ctx, nsd, si, coba + 1), 300);
                    else resolveSelesai(ctx, nsd);
                }
                @Override public void onServiceResolved(NsdServiceInfo r) {
                    pairPort = r.getPort();
                    try { if (r.getHost() != null) pairHost = r.getHost().getHostAddress(); } catch (Throwable ignored) {}
                    say(ctx, "Pairing ditemukan (port " + pairPort
                            + "). Ketik kode 6 angka di notifikasi ini.", true);
                    resolveSelesai(ctx, nsd);
                }
            });
        } catch (Throwable t) {
            resolveSelesai(ctx, nsd);
        }
    }

    public static void stopDiscovery(Context ctx) {
        if (listener == null) return;
        try { ((NsdManager) ctx.getSystemService(Context.NSD_SERVICE)).stopServiceDiscovery(listener); }
        catch (Exception ignored) {}
        listener = null;
    }

    /** Pasangkan dengan kode lalu langsung sambung. Panggil dari thread latar. */
    public static void pairAndConnect(Context ctx, int port, String code) {
        if (port <= 0) { say(ctx, "Port pairing belum diketahui.", false); return; }
        try {
            say(ctx, "Memasangkan...", false);
            Adb a = Adb.get(ctx);
            boolean ok;
            try {
                ok = a.pair(pairHost, port, code);
            } catch (Throwable first) {
                if ("127.0.0.1".equals(pairHost)) throw first;
                ok = a.pair("127.0.0.1", port, code);
            }
            if (!ok) { say(ctx, "Pairing gagal. Periksa kode, lalu ulangi.", false); return; }
            ctx.getSharedPreferences("adb_makroku", Context.MODE_PRIVATE).edit().putBoolean("paired", true).apply();
            say(ctx, "Pairing berhasil. Menyambung...", false);
            connect(ctx);
        } catch (Throwable e) {
            say(ctx, "Pairing gagal: " + e, false);
        }
    }

    public static void connect(Context ctx) { connect(ctx, false); }

    static void report(Context c, String t, boolean quiet) {
        if (quiet) { Consumer<String> s = sink; if (s != null) s.accept(t); }
        else say(c, t, false);
    }

    /** Sambung otomatis ke port Wireless debugging (ditemukan lewat mDNS). */
    public static void connect(Context ctx, boolean quiet) {
        try {
            Adb a = Adb.get(ctx);
            if (a.isConnected()) { report(ctx, "Sudah tersambung", quiet); return; }
            if (Lokal.modeAktif(ctx) && Lokal.sambungLokal(a)) {
                report(ctx, "Tersambung tanpa Wi-Fi (127.0.0.1:" + Lokal.PORT + ").", quiet);
                AdbBackend.setelahTersambung(ctx, a);
                return;
            }
            Lokal.viaLokal = false;
            a.sambungTls(ctx, 10000L);
            report(ctx, a.isConnected() ? "Tersambung."
                    : "Gagal menyambung. Pastikan Debugging nirkabel aktif dan Wi-Fi tersambung.", quiet);
            if (a.isConnected()) AdbBackend.setelahTersambung(ctx, a);
        } catch (Throwable e) {
            report(ctx, "Gagal menyambung: " + e, quiet);
        }
    }
}
