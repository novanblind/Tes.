package com.novan.filemanagerpro

import android.content.Context

object Prefs {
    private const val NAME = "settings"

    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** 0 nama, 1 ukuran, 2 tanggal, 3 jenis, 4 tanpa urutan */
    fun sortKey(c: Context): Int = p(c).getInt("sort_key", 0)
    fun sortAsc(c: Context): Boolean = p(c).getBoolean("sort_asc", true)
    fun setSort(c: Context, key: Int, asc: Boolean) {
        p(c).edit().putInt("sort_key", key).putBoolean("sort_asc", asc).apply()
    }

    fun showHidden(c: Context): Boolean = p(c).getBoolean("show_hidden", false)
    fun setShowHidden(c: Context, v: Boolean) {
        p(c).edit().putBoolean("show_hidden", v).apply()
    }

    /** Tampilkan penyimpanan sistem (folder akar "/") di beranda dan menu navigasi. */
    fun showSystem(c: Context): Boolean = p(c).getBoolean("show_system", false)
    fun setShowSystem(c: Context, v: Boolean) {
        p(c).edit().putBoolean("show_system", v).apply()
    }

    /** Sambung USB: flashdisk dan penyimpanan OTG langsung terbaca. Aktif secara bawaan. */
    fun usbConnect(c: Context): Boolean = p(c).getBoolean("usb_connect", true)
    fun setUsbConnect(c: Context, v: Boolean) {
        p(c).edit().putBoolean("usb_connect", v).apply()
    }

    fun useTrash(c: Context): Boolean = p(c).getBoolean("use_trash", true)
    fun setUseTrash(c: Context, v: Boolean) {
        p(c).edit().putBoolean("use_trash", v).apply()
    }

    fun ftpPort(c: Context): Int = p(c).getInt("ftp_port", 2121)
    fun setFtpPort(c: Context, v: Int) { p(c).edit().putInt("ftp_port", v).apply() }
    fun httpPort(c: Context): Int = p(c).getInt("http_port", 8080)
    fun setHttpPort(c: Context, v: Int) { p(c).edit().putInt("http_port", v).apply() }

    fun serverUser(c: Context): String = p(c).getString("server_user", "admin") ?: "admin"

    /** Sandi server dibuat acak sekali, supaya server tidak pernah terbuka tanpa sandi. */
    fun serverPass(c: Context): String {
        val cur = p(c).getString("server_pass", null)
        if (cur != null) return cur
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val gen = (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        p(c).edit().putString("server_pass", gen).apply()
        return gen
    }

    fun setServerAccount(c: Context, user: String, pass: String) {
        p(c).edit().putString("server_user", user).putString("server_pass", pass).apply()
    }

    fun serverRoot(c: Context): String =
        p(c).getString("server_root", null)
            ?: android.os.Environment.getExternalStorageDirectory().absolutePath
    fun setServerRoot(c: Context, v: String) { p(c).edit().putString("server_root", v).apply() }

    /** Tampilkan file tersembunyi per kategori perpustakaan (images, audio, video). */
    fun libHidden(c: Context, kind: String): Boolean = p(c).getBoolean("lib_hidden_$kind", false)
    fun setLibHidden(c: Context, kind: String, v: Boolean) {
        p(c).edit().putBoolean("lib_hidden_$kind", v).apply()
    }

    /** key: image, audio, video, text. Bawaan: mati, dibuka dengan aplikasi lain. */
    fun useInternal(c: Context, key: String): Boolean = p(c).getBoolean("internal_$key", false)
    /** Penampil PDF bawaan: aktif secara bawaan karena ramah pembaca layar. */
    fun usePdf(c: Context): Boolean = p(c).getBoolean("internal_pdf", true)
    fun setUsePdf(c: Context, v: Boolean) {
        p(c).edit().putBoolean("internal_pdf", v).apply()
    }
    /** Penampil dokumen Office bawaan: aktif secara bawaan karena ramah pembaca layar. */
    fun useOffice(c: Context): Boolean = p(c).getBoolean("internal_office", true)
    fun setUseOffice(c: Context, v: Boolean) {
        p(c).edit().putBoolean("internal_office", v).apply()
    }

    fun setUseInternal(c: Context, key: String, v: Boolean) {
        p(c).edit().putBoolean("internal_$key", v).apply()
    }

    /** 0 daftar, 1 rinci, 2 kisi */
    /** Tampilan kategori perpustakaan: true kisi, false daftar. Gambar dan Video kisi secara bawaan. */
    fun libGrid(c: Context, kind: String): Boolean {
        val v = p(c).getInt("lib_view_$kind", -1)
        if (v >= 0) return v == 1
        return kind == LibraryActivity.IMAGES || kind == LibraryActivity.VIDEO
    }
    fun setLibGrid(c: Context, kind: String, grid: Boolean) {
        p(c).edit().putInt("lib_view_$kind", if (grid) 1 else 0).apply()
    }

    fun viewMode(c: Context): Int = p(c).getInt("view_mode", 0)
    fun setViewMode(c: Context, v: Int) { p(c).edit().putInt("view_mode", v).apply() }

    fun showThumbs(c: Context): Boolean = p(c).getBoolean("show_thumbs", true)
    fun setShowThumbs(c: Context, v: Boolean) { p(c).edit().putBoolean("show_thumbs", v).apply() }

    /** 0 otomatis (sistem), 1 biner (1024), 2 desimal (1000) */
    fun sizeUnit(c: Context): Int = p(c).getInt("size_unit", 0)
    fun setSizeUnit(c: Context, v: Int) { p(c).edit().putInt("size_unit", v).apply() }

    fun trashConfirm(c: Context): Boolean = p(c).getBoolean("trash_confirm", true)
    fun setTrashConfirm(c: Context, v: Boolean) { p(c).edit().putBoolean("trash_confirm", v).apply() }

    fun audioShuffle(c: Context): Boolean = p(c).getBoolean("audio_shuffle", false)
    fun setAudioShuffle(c: Context, v: Boolean) { p(c).edit().putBoolean("audio_shuffle", v).apply() }

    /** 0 mati, 1 semua lagu, 2 satu lagu */
    fun audioRepeat(c: Context): Int = p(c).getInt("audio_repeat", 0)
    fun setAudioRepeat(c: Context, v: Int) { p(c).edit().putInt("audio_repeat", v).apply() }

    fun audioSpeed(c: Context): Float = p(c).getFloat("audio_speed", 1.0f)
    fun setAudioSpeed(c: Context, v: Float) { p(c).edit().putFloat("audio_speed", v).apply() }

    fun subsOn(c: Context): Boolean = p(c).getBoolean("subs_on", true)
    fun setSubsOn(c: Context, v: Boolean) { p(c).edit().putBoolean("subs_on", v).apply() }

    /** ukuran teks subtitle dalam sp */
    fun subSize(c: Context): Int = p(c).getInt("sub_size", 20)
    fun setSubSize(c: Context, v: Int) { p(c).edit().putInt("sub_size", v).apply() }

    fun searchHistory(c: Context): List<String> =
        (p(c).getString("search_history", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addSearchHistory(c: Context, q: String) {
        val list = ArrayList(searchHistory(c))
        list.remove(q)
        list.add(0, q)
        p(c).edit().putString("search_history", list.take(15).joinToString("\n")).apply()
    }

    fun clearSearchHistory(c: Context) { p(c).edit().remove("search_history").apply() }
}
