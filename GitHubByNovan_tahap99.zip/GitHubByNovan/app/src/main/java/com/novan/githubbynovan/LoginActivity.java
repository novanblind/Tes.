package com.novan.githubbynovan;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

public class LoginActivity extends Activity {
    static final String URL_TOKEN =
            "https://github.com/settings/tokens/new?description=GitHub+by+novan&scopes=repo,delete_repo,workflow";
    static final String URL_DAFTAR = "https://github.com/signup";

    private Ui ui;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        ui = new Ui(this, "Masuk akun GitHub");
        ui.label("Masukkan token GitHub Anda. Belum punya? Pakai tombol di bawah.");
        final EditText t = ui.edit("Token GitHub", "Tempel token di sini", false, "");
        ui.button("Simpan token dan masuk", v -> {
            final String tk = t.getText().toString().trim();
            if (tk.isEmpty()) {
                ui.say("Token tidak boleh kosong.");
                return;
            }
            ui.say("Memeriksa token...");
            Api.request("GET", Api.BASE + "/user", tk, null, (ok, res) -> {
                if (!ok) {
                    ui.say("Token ditolak. " + res);
                    return;
                }
                Store.setToken(this, tk);
                ui.say("Berhasil masuk sebagai " + Api.parse(res).optString("login", "pengguna") + ".");
                startActivity(new Intent(this, MainActivity.class));
                finish();
            });
        });
        ui.button("Dapatkan token di web", v -> Ui.browse(this, URL_TOKEN));
        ui.button("Buat akun baru", v -> Ui.browse(this, URL_DAFTAR));
    }
}
