package com.novan.filemanagermax

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/**
 * Penampil dokumen Office (tahap 70: Word .docx). Isi dibaca sebagai teks: satu blok
 * per paragraf, judul bertanda judul untuk TalkBack, tabel dibacakan per baris.
 */
class OfficeViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        private const val MAX_COPY_BYTES = 150L * 1024 * 1024
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var list: RecyclerView
    private lateinit var progress: View
    private lateinit var bar: View
    private val blocks = ArrayList<OfficeReader.Block>()
    private val adapter = BlockAdapter()
    private var file: File? = null
    private var srcUri: Uri? = null
    private var tmp: File? = null
    private var cur = 0
    private var touchScroll = false
    private var lastQuery = ""
    private var docName = ""
    private var isSheet = false
    private var isDeck = false
    private var curFormat = "docx"

    private fun listTitle(): Int = when {
        isSheet -> R.string.office_sheets
        isDeck -> R.string.office_slides
        else -> R.string.office_headings
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_office_viewer)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        list = findViewById(R.id.officeList)
        progress = findViewById(R.id.officeProgress)
        bar = findViewById(R.id.officeBar)
        bar.visibility = View.GONE

        val lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.adapter = adapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) touchScroll = true
                else if (newState == RecyclerView.SCROLL_STATE_IDLE) touchScroll = false
            }

            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (touchScroll) {
                    val p = lm.findFirstVisibleItemPosition()
                    if (p >= 0) cur = p
                }
            }
        })
        findViewById<View>(R.id.btnPrevHeading).setOnClickListener { goHeading(-1) }
        findViewById<View>(R.id.btnNextHeading).setOnClickListener { goHeading(1) }

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path != null) {
            file = File(path)
        } else {
            val d = intent.data
            if (d != null && d.scheme == "file" && d.path != null) file = File(d.path!!) else srcUri = d
        }
        docName = file?.name ?: queryName(srcUri) ?: getString(R.string.office_viewer)
        title = docName
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        tmp?.delete()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun queryName(u: Uri?): String? {
        if (u == null) return null
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: u.lastPathSegment
        } catch (e: Exception) {
            u.lastPathSegment
        }
    }

    private fun load() {
        val mime = intent.type ?: srcUri?.let { contentResolver.getType(it) }
        executor.execute {
            var doc: OfficeReader.Doc? = null
            var err: String? = null
            try {
                val fmt = OfficeReader.formatOf(docName, mime)
                    ?: throw IllegalStateException(getString(R.string.office_unsupported))
                var f = file
                if (f == null) {
                    val u = srcUri ?: throw IllegalStateException(getString(R.string.cannot_open))
                    val t = File(cacheDir, "office_view.tmp")
                    var total = 0L
                    contentResolver.openInputStream(u)?.use { ins ->
                        t.outputStream().use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                total += n
                                if (total > MAX_COPY_BYTES) throw IllegalStateException(getString(R.string.office_too_large))
                                out.write(buf, 0, n)
                            }
                        }
                    } ?: throw IllegalStateException(getString(R.string.cannot_open))
                    tmp = t
                    f = t
                }
                doc = OfficeReader.parse(f, fmt, docName)
            } catch (e: IllegalStateException) {
                err = e.message
            } catch (e: Exception) {
                err = getString(R.string.office_unreadable)
            }
            val result = doc
            main.post {
                if (isFinishing || isDestroyed) return@post
                progress.visibility = View.GONE
                val d = result
                if (d != null) show(d) else fail(err ?: getString(R.string.office_unreadable))
            }
        }
    }

    private fun show(doc: OfficeReader.Doc) {
        isSheet = doc.kind == "sheet"
        isDeck = doc.kind == "deck"
        curFormat = doc.format
        val label = doc.typeName + " " + docName
        val base = when {
            isSheet -> getString(R.string.office_summary_xlsx, label, doc.sheets, doc.rows)
            isDeck -> getString(R.string.office_summary_pptx, label, doc.slides, doc.tables, doc.images)
            else -> getString(
                R.string.office_summary, label, doc.paragraphs, doc.headings, doc.tables, doc.images
            )
        }
        val summary = base + if (doc.truncated) " " + getString(R.string.office_truncated) else ""
        if (isSheet) {
            findViewById<android.widget.Button>(R.id.btnPrevHeading).setText(R.string.office_prev_sheet)
            findViewById<android.widget.Button>(R.id.btnNextHeading).setText(R.string.office_next_sheet)
        } else if (isDeck) {
            findViewById<android.widget.Button>(R.id.btnPrevHeading).setText(R.string.office_prev_slide)
            findViewById<android.widget.Button>(R.id.btnNextHeading).setText(R.string.office_next_slide)
        }
        blocks.clear()
        blocks.add(OfficeReader.Block(OfficeReader.K_INFO, 0, summary))
        blocks.addAll(doc.blocks)
        adapter.notifyDataSetChanged()
        bar.visibility = View.VISIBLE
        invalidateOptionsMenu()
        list.announceForAccessibility(summary)
        list.postDelayed({ focusItem(0) }, 400)
    }

    private fun fail(msg: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.office_error_title)
            .setMessage(msg)
            .setPositiveButton(R.string.office_open_other) { _, _ -> openExternal(); finish() }
            .setNegativeButton(R.string.close) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun focusItem(pos: Int, retry: Int = 2) {
        val v = list.findViewHolderForAdapterPosition(pos)?.itemView
        if (v != null) {
            v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
            v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        } else if (retry > 0) {
            list.postDelayed({ focusItem(pos, retry - 1) }, 200)
        }
    }

    private fun jump(pos: Int) {
        if (pos !in blocks.indices) return
        cur = pos
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(pos, 0)
        list.postDelayed({ focusItem(pos) }, 150)
    }

    private fun goHeading(dir: Int) {
        if (blocks.none { it.kind == OfficeReader.K_HEADING }) {
            say(getString(R.string.office_no_headings)); return
        }
        var i = cur + dir
        while (i in blocks.indices) {
            if (blocks[i].kind == OfficeReader.K_HEADING) { jump(i); return }
            i += dir
        }
        say(getString(if (dir > 0) R.string.office_no_next_heading else R.string.office_no_prev_heading))
    }

    private fun showHeadings() {
        val idx = ArrayList<Int>()
        val labels = ArrayList<String>()
        for ((i, b) in blocks.withIndex()) {
            if (b.kind == OfficeReader.K_HEADING) {
                idx.add(i)
                labels.add(if (isSheet || isDeck) b.text else getString(R.string.office_heading_item, b.text, b.level))
            }
        }
        if (idx.isEmpty()) { say(getString(R.string.office_no_headings)); return }
        AlertDialog.Builder(this)
            .setTitle(listTitle())
            .setItems(labels.toTypedArray()) { _, which -> jump(idx[which]) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun promptFind() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.office_search_hint)
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.editor_find)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> find(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun find(q: String) {
        if (q.isEmpty() || blocks.size < 2) return
        lastQuery = q
        invalidateOptionsMenu()
        val n = blocks.size
        for (step in 1..n) {
            val i = (cur + step) % n
            if (i == 0) continue
            if (blocks[i].text.contains(q, ignoreCase = true)) {
                jump(i)
                say(getString(R.string.office_found, i, n - 1))
                return
            }
        }
        say(getString(R.string.editor_not_found))
    }

    private fun copyAll() {
        val sbd = StringBuilder()
        for (b in blocks) {
            if (b.kind == OfficeReader.K_INFO || b.kind == OfficeReader.K_PAGE) continue
            sbd.append(b.text).append("\n\n")
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(docName, sbd.toString().trim()))
        say(getString(R.string.office_copied))
    }

    private fun openExternal() {
        val f = file
        if (f != null) {
            if (!Util.openWith(this, f)) say(getString(R.string.cannot_open))
            return
        }
        val u = srcUri ?: return
        try {
            val base = Intent(Intent.ACTION_VIEW)
                .setDataAndType(u, intent.type ?: OfficeReader.mimeFor(curFormat))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(base, getString(R.string.open_with_title))
                .putExtra(
                    Intent.EXTRA_EXCLUDE_COMPONENTS,
                    arrayOf(ComponentName(this, OfficeViewerActivity::class.java))
                )
            startActivity(chooser)
        } catch (e: Exception) {
            say(getString(R.string.cannot_open))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.office_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val ready = blocks.size > 1
        for (id in listOf(R.id.action_headings, R.id.action_find, R.id.action_top, R.id.action_bottom, R.id.action_copy)) {
            menu.findItem(id).isVisible = ready
        }
        menu.findItem(R.id.action_find_next).isVisible = ready && lastQuery.isNotEmpty()
        menu.findItem(R.id.action_edit_text).isVisible = file != null && curFormat in setOf("csv", "tsv", "rtf")
        menu.findItem(R.id.action_headings).setTitle(listTitle())
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_headings -> showHeadings()
            R.id.action_find -> promptFind()
            R.id.action_find_next -> find(lastQuery)
            R.id.action_top -> jump(0)
            R.id.action_bottom -> jump(blocks.size - 1)
            R.id.action_copy -> copyAll()
            R.id.action_open_with -> openExternal()
            R.id.action_edit_text -> file?.let {
                startActivity(Intent(this, TextEditorActivity::class.java).putExtra(TextEditorActivity.EXTRA_PATH, it.absolutePath))
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private inner class BlockAdapter : RecyclerView.Adapter<BlockAdapter.VH>() {

        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv) {
            init {
                ViewCompat.setAccessibilityDelegate(tv, object : AccessibilityDelegateCompat() {
                    override fun sendAccessibilityEvent(host: View, eventType: Int) {
                        super.sendAccessibilityEvent(host, eventType)
                        if (eventType == AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED) {
                            val p = bindingAdapterPosition
                            if (p >= 0) cur = p
                        }
                    }
                })
            }
        }

        override fun getItemCount() = blocks.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_office_block, parent, false) as TextView
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val b = blocks[position]
            val tv = h.tv
            val dp = resources.displayMetrics.density
            val isHeading = b.kind == OfficeReader.K_HEADING
            tv.text = if (b.kind == OfficeReader.K_LIST) "•  " + b.text else b.text
            tv.setTypeface(
                null,
                if (isHeading || b.kind == OfficeReader.K_TABLE || b.kind == OfficeReader.K_INFO)
                    Typeface.BOLD else Typeface.NORMAL
            )
            val size = if (isHeading) when (b.level) { 1 -> 24f; 2 -> 21f; 3 -> 19f; else -> 17f } else 16f
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            ViewCompat.setAccessibilityHeading(tv, isHeading)
            val start = (16 + (if (b.kind == OfficeReader.K_LIST) b.level.coerceAtMost(5) * 16 else 0)) * dp
            tv.setPadding(start.toInt(), tv.paddingTop, (16 * dp).toInt(), tv.paddingBottom)
            tv.alpha = if (b.kind == OfficeReader.K_PAGE) 0.7f else 1f
        }
    }
}
