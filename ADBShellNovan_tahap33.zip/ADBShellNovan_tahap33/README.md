# ADB Shell Novan (tahap 30)
- Wireless debugging ala Brevent (pairing kode + TLS), pairing cukup sekali.
- Sambung otomatis setelah restart (izin WRITE_SECURE_SETTINGS diberikan lewat ADB sekali).
- Pasang APK, APKS, APKM, XAPK, APK+ (paket bundel/split) lewat ADB dengan pemasang tercatat Google Play Store (com.android.vending); pecahan dipilih sesuai ABI, densitas, dan bahasa HP; OBB/data XAPK ikut disalin.
- Bisa dipilih beberapa berkas sekaligus, dan muncul di menu Buka dengan / Bagikan dari pengelola berkas.
- Kelola aplikasi (sistem dan aplikasi pengguna, ganti lewat tombol cakupan): nonaktifkan, aktifkan kembali, hapus instalan (pm uninstall --user 0), dan kembalikan aplikasi yang sudah dihapus instalan. Paket inti diberi peringatan keras.
- Aplikasi berjalan dan pemakaian RAM: daftar diurutkan dari RAM terbesar, bisa hanya yang di latar belakang, rincian proses per aplikasi, hentikan paksa, dan nonaktifkan.
Build: unggah ke GitHub, Actions -> Build APK -> unduh artefak.
- Mode tanpa Wi-Fi: ADB dipindah ke TCP 5555 dan disambung lewat 127.0.0.1, jadi tetap bisa dipakai saat Wi-Fi putus (hilang setelah restart).
- Bebas baterai: aplikasi dikeluarkan dari penghematan baterai dan pembatasan latar belakang.
- Setelah tersambung lewat Wi-Fi, aplikasi otomatis pindah ke jalur lokal (Wi-Fi boleh dimatikan); bebas baterai otomatis tiap tersambung, termasuk setelah restart.
- Setelah HP restart, Debugging USB dan nirkabel dinyalakan otomatis (perlu izin sambung otomatis sekali); waktu tunggu otorisasi adb dimatikan.
- Izin WRITE_SECURE_SETTINGS diberikan otomatis saat pertama kali tersambung (tombol sambung otomatis hanya cadangan).
- Setelah tersambung, panduan, kolom port/kode pairing, dan tombol pairing disembunyikan agar layar ringkas; muncul lagi saat terputus.
- Fitur yang berjalan otomatis saat tersambung (mode tanpa Wi-Fi, bebas baterai) tidak lagi punya tombol di layar.
- Ucapan status ADB (tersambung/terputus) lewat TTS, otomatis saat terdeteksi berubah (termasuk setelah sambung otomatis di latar belakang); memakai mesin suara utama yang sama dengan pembaca layar dan bahasa bawaannya; ada tombol untuk mematikan/menyalakan.
- Log aplikasi (logcat): pilih aplikasi dari daftar, catatan error (crash) terakhirnya otomatis dicari dan ditampilkan apa adanya; ada tombol Salin keterangan, Cari ulang error, dan Pantau log langsung (selama aplikasi sedang berjalan).
- Tombol "Buka Opsi pengembang" muncul setelah tersambung.
- Tombol "Bersihkan sampah aplikasi (cache semua aplikasi sekaligus)": satu ketukan membersihkan cache SEMUA aplikasi (YouTube, aplikasi ojek online, dll.) lewat satu perintah ADB (pm trim-caches), cepat dan tidak perlu satu per satu; hanya cache yang dihapus, bukan data/akun/login.
- Log aplikasi: setelah memilih aplikasi, keterangan errornya muncul di dialog dengan tombol Salin (dialog tetap terbuka) dan Kembali.
- Aplikasi berjalan (RAM): tombol "Paksa berhenti (kuat)" menutup aplikasi lalu melarangnya berjalan sendiri di latar belakang (appops RUN_IN_BACKGROUND dan RUN_ANY_IN_BACKGROUND, bucket restricted) sehingga baru jalan lagi kalau dibuka manual; ada tombol "Lepas pembatasan" di rincian aplikasi.
- Catatan error lebih akurat: pencocokan paket tepat (tidak tercampur paket berawalan sama), ada waktu kejadian, dan bila log crash kosong dicari juga di DropBox sistem (crash, ANR, crash native). Semua hasil, termasuk "tidak ditemukan" dan kegagalan, tampil di dialog dengan Salin dan Kembali.
- Pantau log langsung dibuat satu ketukan: tombol baru di layar utama "Pantau log langsung" membuka daftar aplikasi dengan mode langsung pantau; ketuk aplikasi (atau tekan lama di mode mana pun) maka aplikasi dibuka otomatis bila belum jalan (monkey), lalu lognya mengalir.
- Saring log: Semua baris, Peringatan (W) ke atas, atau Error (E) saja; bisa diganti saat pemantauan berjalan (pemantauan dimulai ulang otomatis).
- Crash terdeteksi saat dipantau (FATAL EXCEPTION) diumumkan lewat status, lalu catatan error lengkap otomatis muncul di dialog dengan Salin dan Tutup. Teks log dibatasi agar layar tidak berat.
- Pantau log langsung diperbaiki (tahap 21): logcat dijalankan LEBIH DULU, baru aplikasi dibuka, dan penyaringan dilakukan per PID di aplikasi (PID dipelajari dari baris "Start proc"), jadi aplikasi yang langsung crash saat dibuka (misal Mix Live) tetap menampilkan catatan errornya. Pemantauan tidak berhenti saat aplikasi crash; catatan error lengkap otomatis ditambahkan di bawah log dan muncul di dialog (juga untuk crash native dan ANR). Saring log berlaku langsung tanpa memulai ulang.
- Daftar aplikasi lebih lega: di Log aplikasi, daftar memenuhi layar (pengaturan mode/saring/cakupan dipindah ke tombol Pengaturan), log tampil di layar terpisah dengan tombol Kembali ke daftar aplikasi; satu baris satu nama (paket hanya ditambahkan bila ada nama yang sama), baris dirapatkan. Kelola aplikasi juga dipadatkan.
- Tombol Hentikan pemantauan kini juga langsung mencari catatan error terakhir aplikasi, menampilkannya di dialog dan menambahkannya di bawah log langsung (log tidak dihapus).
- Catatan error kini menyebut umurnya ("terjadi sekitar N menit yang lalu") dan memberi tanda LAMA bila lebih dari 10 menit, supaya crash lama tidak disangka crash baru. Log crash Java dibandingkan dengan DropBox (ANR, crash native) dan yang paling baru dipilih.
- Catatan error kini menampilkan tanggal dan jam HP sekarang, waktu kejadian error, dan selisihnya; log pantau langsung diawali baris tanggal dan jam mulai memantau.
- Tombol salin (dialog "Salin semua" dan "Salin semua keterangan") menyalin laporan lengkap: nama aplikasi, tanggal dan jam HP saat disalin, catatan error yang tampil, dan semua catatan error lain yang ditemukan (crash Java lebih lama dan DropBox: ANR, crash native).
- Pemantauan log langsung dibuat akurat (tahap 26): (1) ada "penjaga crash", stream logcat kedua khusus buffer crash yang volumenya kecil, jadi crash tetap terdeteksi walau log utama banjir dan kehilangan baris lewat ADB nirkabel; (2) pembacaan log yang kosong atau gagal diulang sampai 3 kali, dan bila tetap gagal tampil pesan "GAGAL membaca", tidak lagi disangka "tidak ada error"; (3) setelah menekan berhenti memantau ada jeda 0,7 detik sebelum mencari error, supaya stream yang baru ditutup tidak mengganggu; (4) hasil cari error tidak lagi menimpa log langsung, ditambahkan di bawahnya; (5) hasil diberi catatan bila error-nya terjadi SEBELUM pemantauan dimulai, supaya catatan lama (log crash tetap ada walau aplikasinya sudah dihapus dan dipasang ulang) tidak disangka baru.
- Pantau log langsung ramah pembaca layar (tahap 27): selama memantau, kotak log tidak bisa difokus dan tidak dibacakan, jadi baris baru yang terus muncul tidak lagi menarik fokus dari tombol; tombol "Hentikan pemantauan" dipindah ke urutan pertama dan fokus pembaca layar diarahkan ke sana saat pemantauan mulai. Gulir otomatis tidak lagi memakai fullScroll (yang memindahkan fokus). Setelah berhenti, log bisa dibaca, dipilih, dan disalin seperti biasa.
- Tombol "Salin semua" di dialog catatan error (tahap 28) kini ikut menyalin log langsung yang ada di layar, bukan hanya isi dialog. Sebelumnya hasil salin dari dialog tidak berisi baris log pemantauan.
- Pilih banyak aplikasi sekaligus (tahap 30): di Kelola aplikasi, tekan lama (di TalkBack: ketuk dua kali tahan) satu aplikasi, maka aplikasi itu tercentang dan mode pilih terbuka. Ketuk aplikasi lain untuk mencentang atau menghapus centang (dibacakan "dicentang/tidak dicentang" dan jumlah terpilih). Tombol: Pilih semua yang tampil, Batal pilih, lalu tindakan sesuai daftar (Nonaktifkan/Hapus instalan terpilih di Aktif, Aktifkan/Hapus instalan terpilih di Dinonaktifkan, Kembalikan terpilih di Dihapus). Ada konfirmasi dengan daftar nama dan peringatan keras bila ada paket inti; hasil dirangkum (berhasil, gagal, dilewati). Tombol Kembali menutup mode pilih lebih dulu.
- Tema mengikuti sistem (tahap 30): terang atau gelap sesuai pengaturan tema HP (Theme.DeviceDefault.DayNight), termasuk dialog.
- Notifikasi pairing lebih cepat (tahap 31): kolom "Masukkan kode pairing" langsung muncul begitu Mulai pairing ditekan, tidak menunggu port ditemukan. Bila kode diketik sebelum port ditemukan, aplikasi menunggu sampai 25 detik lalu memasangkan sendiri. Pencarian port memakai antrean dengan ulang otomatis (sebelumnya resolve yang bertabrakan gagal diam-diam sehingga tombol baru muncul sangat lama).

## Tahap 32-33 — Tidak minta kode 6 angka setelah dipasang ulang

Brevent memakai kunci ADB tetap, jadi Android yang sudah pernah pairing mengenalinya lagi walau aplikasi dihapus lalu dipasang ulang.
Di sini kuncinya tidak ditulis di kode sumber, tetapi diisi saat build dari GitHub Secret `ADB_KEY_B64`:

1. Di aplikasi ini ketuk tombol **Buat kunci tetap untuk GitHub Secret**: kunci dibuat dan otomatis disalin ke papan klip (tanpa komputer, tanpa Termux).
2. Segera tempel ke GitHub Secret bernama `ADB_KEY_B64` di repo (lewat menu Secrets di GitHubByNovan). Kunci yang sama harus dipakai selamanya; bila Secret hilang, pairing perlu diulang sekali.
3. Bangun APK seperti biasa. Tanpa secret, aplikasi memakai kunci acak per pemasangan (perilaku lama).

Setelah memasang versi ini pairing 6 angka perlu SEKALI lagi. Sesudah itu pasang ulang langsung tersambung.
Catatan: kunci tetap ikut tertanam di APK hasil build, jadi orang yang punya APK itu bisa mengambilnya (sama seperti Brevent); Secret hanya menjaganya tidak ada di kode sumber/repo.
Belum dikompilasi dan belum diuji di perangkat.
