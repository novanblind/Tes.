#define _GNU_SOURCE
/*
 * Library LD_PRELOAD milik Termux Novan.
 * Android 10 ke atas (targetSdk 29+) melarang execve() pada berkas di folder aplikasi.
 * Di sini execve dan sejenisnya disadap: biner ELF dijalankan lewat /system/bin/linker64,
 * skrip dengan interpreter di folder aplikasi dijalankan lewat interpreternya juga.
 */
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <spawn.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

#if defined(__LP64__)
#define LINKER "/system/bin/linker64"
#else
#define LINKER "/system/bin/linker"
#endif

extern char **environ;

static int sistem(const char *p) {
    return !strncmp(p, "/system/", 8) || !strncmp(p, "/apex/", 6) || !strncmp(p, "/vendor/", 8)
        || !strncmp(p, "/product/", 9) || !strncmp(p, "/odm/", 5) || !strncmp(p, "/system_ext/", 12);
}


/* Android tidak punya /usr/bin dan /bin. Tulis ulang ke $PREFIX/bin bila berkas aslinya tidak ada. */
static void petakan(char *abs, size_t cap) {
    const char *pre = getenv("PREFIX"), *rest = NULL;
    char t[PATH_MAX];
    if (!pre || !*pre) pre = "/data/data/com.termux/files/usr";
    if (!strncmp(abs, "/usr/bin/", 9)) rest = abs + 9;
    else if (!strncmp(abs, "/bin/", 5)) rest = abs + 5;
    else if (!strncmp(abs, "/usr/local/bin/", 15)) rest = abs + 15;
    if (!rest || !*rest || access(abs, F_OK) == 0) return;
    if (strlen(pre) + 5 + strlen(rest) >= sizeof(t) || strlen(pre) + 5 + strlen(rest) >= cap) return;
    strcpy(t, pre); strcat(t, "/bin/"); strcat(t, rest);
    if (access(t, F_OK) == 0) strcpy(abs, t);
}

/* Bila perintah perlu ditulis ulang: isi *nargv (hasil malloc) dan kembalikan 1. */
static int tulis_ulang(const char *path, char *const argv[], char ***nargv) {
    char abs[PATH_MAX], h[256], *tok[3];
    int fd, argc = 0, i, k = 0;
    ssize_t n;
    char **na;
    if (!path || !path[0]) return 0;
    if (path[0] == '/') {
        if (strlen(path) >= sizeof(abs)) return 0;
        strcpy(abs, path);
    } else {
        size_t l;
        if (!getcwd(abs, sizeof(abs))) return 0;
        l = strlen(abs);
        if (l + 1 + strlen(path) + 1 > sizeof(abs)) return 0;
        abs[l] = '/';
        strcpy(abs + l + 1, path);
    }
    petakan(abs, sizeof(abs));
    if (sistem(abs)) return 0;
    fd = open(abs, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return 0;
    n = read(fd, h, sizeof(h) - 1);
    close(fd);
    if (n < 4) return 0;
    h[n] = 0;
    while (argv && argv[argc]) argc++;
    if (h[0] == 0x7f && h[1] == 'E' && h[2] == 'L' && h[3] == 'F') {
        na = malloc((argc + 4) * sizeof(char *));
        if (!na) return 0;
        na[k++] = (char *)LINKER;
        na[k++] = strdup(abs);
        for (i = 1; i < argc; i++) na[k++] = argv[i];
        na[k] = NULL;
        *nargv = na;
        return 1;
    }
    if (h[0] == '#' && h[1] == '!') {
        char *p = h + 2, *e = strchr(p, '\n');
        int nt = 0;
        if (e) *e = 0;
        while (*p == ' ' || *p == '\t') p++;
        if (!*p) return 0;
        tok[nt++] = p;
        while (*p && *p != ' ' && *p != '\t') p++;
        if (*p) {
            *p++ = 0;
            while (*p == ' ' || *p == '\t') p++;
            if (*p) {
                char *q = p + strlen(p);
                while (q > p && (q[-1] == ' ' || q[-1] == '\t' || q[-1] == '\r')) *--q = 0;
                if (*p) tok[nt++] = p;
            }
        }
        if (tok[0][0] != '/') return 0;
        {
            static char ip[PATH_MAX];
            if (strlen(tok[0]) < sizeof(ip)) { strcpy(ip, tok[0]); petakan(ip, sizeof(ip)); tok[0] = ip; }
        }
        if (sistem(tok[0])) return 0;
        na = malloc((argc + 6) * sizeof(char *));
        if (!na) return 0;
        na[k++] = (char *)LINKER;
        na[k++] = strdup(tok[0]);
        if (nt > 1) na[k++] = strdup(tok[1]);
        na[k++] = strdup(abs);
        for (i = 1; i < argc; i++) na[k++] = argv[i];
        na[k] = NULL;
        *nargv = na;
        return 1;
    }
    return 0;
}

int execve(const char *path, char *const argv[], char *const envp[]) {
    char **na;
    if (tulis_ulang(path, argv, &na)) {
        int e;
        syscall(__NR_execve, LINKER, na, envp);
        e = errno;
        free(na);
        errno = e;
        return -1;
    }
    return (int)syscall(__NR_execve, path, argv, envp);
}

int execv(const char *path, char *const argv[]) { return execve(path, argv, environ); }

int execvpe(const char *file, char *const argv[], char *const envp[]) {
    const char *pa;
    int eacces = 0;
    if (!file || !*file) { errno = ENOENT; return -1; }
    if (strchr(file, '/')) {
        execve(file, argv, envp);
        if (errno == ENOEXEC) {
            int c = 0, i;
            char **a;
            while (argv[c]) c++;
            a = malloc((c + 3) * sizeof(char *));
            if (a) {
                a[0] = "sh"; a[1] = (char *)file;
                for (i = 1; i < c; i++) a[i + 1] = argv[i];
                a[c + 1 > 1 ? c + 1 : 2] = NULL;
                execve("/system/bin/sh", a, envp);
            }
        }
        return -1;
    }
    pa = getenv("PATH");
    if (!pa) pa = "/system/bin:/system/xbin";
    while (1) {
        char buf[PATH_MAX];
        const char *e = strchr(pa, ':');
        size_t dl = e ? (size_t)(e - pa) : strlen(pa);
        if (dl + 1 + strlen(file) + 1 < sizeof(buf)) {
            if (dl == 0) { buf[0] = '.'; dl = 1; memcpy(buf + 1, "", 1); }
            else memcpy(buf, pa, dl);
            buf[dl] = '/';
            strcpy(buf + dl + 1, file);
            execve(buf, argv, envp);
            if (errno == EACCES) eacces = 1;
            else if (errno == ENOEXEC) {
                int c = 0, i;
                char **a;
                while (argv[c]) c++;
                a = malloc((c + 3) * sizeof(char *));
                if (a) {
                    a[0] = "sh"; a[1] = buf;
                    for (i = 1; i < c; i++) a[i + 1] = argv[i];
                    a[c + 1 > 1 ? c + 1 : 2] = NULL;
                    execve("/system/bin/sh", a, envp);
                }
                return -1;
            } else if (errno != ENOENT && errno != ENOTDIR) return -1;
        }
        if (!e) break;
        pa = e + 1;
    }
    errno = eacces ? EACCES : ENOENT;
    return -1;
}

int execvp(const char *file, char *const argv[]) { return execvpe(file, argv, environ); }

static char **kumpul(const char *first, va_list ap, int *n) {
    va_list c;
    int cnt = 1, i = 1;
    char **a;
    va_copy(c, ap);
    while (va_arg(c, char *)) cnt++;
    va_end(c);
    a = malloc((cnt + 1) * sizeof(char *));
    if (!a) return NULL;
    a[0] = (char *)first;
    while (i < cnt + 0 && 1) { a[i++] = va_arg(ap, char *); }
    a[cnt] = NULL;
    (void)va_arg(ap, char *);
    *n = cnt;
    return a;
}

int execl(const char *path, const char *arg, ...) {
    va_list ap; int n; char **a; int r;
    va_start(ap, arg);
    a = kumpul(arg, ap, &n);
    va_end(ap);
    if (!a) { errno = ENOMEM; return -1; }
    r = execve(path, a, environ);
    free(a);
    return r;
}

int execlp(const char *file, const char *arg, ...) {
    va_list ap; int n; char **a; int r;
    va_start(ap, arg);
    a = kumpul(arg, ap, &n);
    va_end(ap);
    if (!a) { errno = ENOMEM; return -1; }
    r = execvpe(file, a, environ);
    free(a);
    return r;
}

int execle(const char *path, const char *arg, ...) {
    va_list ap; int n; char **a; char **envp; int r;
    va_start(ap, arg);
    a = kumpul(arg, ap, &n);
    envp = va_arg(ap, char **);
    va_end(ap);
    if (!a) { errno = ENOMEM; return -1; }
    r = execve(path, a, envp);
    free(a);
    return r;
}

typedef int (*spawn_fn)(pid_t *, const char *, const posix_spawn_file_actions_t *,
    const posix_spawnattr_t *, char *const[], char *const[]);

int posix_spawn(pid_t *pid, const char *path, const posix_spawn_file_actions_t *fa,
        const posix_spawnattr_t *at, char *const argv[], char *const envp[]) {
    static spawn_fn real;
    char **na;
    if (!real) real = (spawn_fn)dlsym(RTLD_NEXT, "posix_spawn");
    if (!real) return ENOSYS;
    if (tulis_ulang(path, argv, &na)) {
        int r = real(pid, LINKER, fa, at, na, envp);
        free(na);
        return r;
    }
    return real(pid, path, fa, at, argv, envp);
}

int posix_spawnp(pid_t *pid, const char *file, const posix_spawn_file_actions_t *fa,
        const posix_spawnattr_t *at, char *const argv[], char *const envp[]) {
    static spawn_fn realp;
    const char *pa;
    if (!realp) realp = (spawn_fn)dlsym(RTLD_NEXT, "posix_spawnp");
    if (file && *file && !strchr(file, '/')) {
        pa = getenv("PATH");
        if (!pa) pa = "/system/bin:/system/xbin";
        while (1) {
            char buf[PATH_MAX];
            struct stat st;
            const char *e = strchr(pa, ':');
            size_t dl = e ? (size_t)(e - pa) : strlen(pa);
            if (dl > 0 && dl + 1 + strlen(file) + 1 < sizeof(buf)) {
                memcpy(buf, pa, dl);
                buf[dl] = '/';
                strcpy(buf + dl + 1, file);
                if (stat(buf, &st) == 0 && S_ISREG(st.st_mode) && (st.st_mode & 0111))
                    return posix_spawn(pid, buf, fa, at, argv, envp);
            }
            if (!e) break;
            pa = e + 1;
        }
    }
    if (file && strchr(file, '/')) return posix_spawn(pid, file, fa, at, argv, envp);
    if (!realp) return ENOSYS;
    return realp(pid, file, fa, at, argv, envp);
}
