package com.novan.pembacauang

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CurrencyParserTest {

    @Test fun tulisanNominal() {
        assertEquals(Denomination.SERIBU, CurrencyParser.parse("BANK INDONESIA\nSERIBU RUPIAH"))
        assertEquals(Denomination.DUA_RIBU, CurrencyParser.parse("dua ribu rupiah"))
        assertEquals(Denomination.LIMA_RIBU, CurrencyParser.parse("Lima Ribu Rupiah"))
        assertEquals(Denomination.SEPULUH_RIBU, CurrencyParser.parse("sepuluh ribu rupiah"))
        assertEquals(Denomination.DUA_PULUH_RIBU, CurrencyParser.parse("DUA PULUH RIBU RUPIAH"))
        assertEquals(Denomination.LIMA_PULUH_RIBU, CurrencyParser.parse("lima puluh ribu rupiah"))
        assertEquals(Denomination.SERATUS_RIBU, CurrencyParser.parse("SERATUS RIBU RUPIAH"))
        assertEquals(Denomination.TUJUH_PULUH_LIMA_RIBU, CurrencyParser.parse("Rp75.000"))
    }

    @Test fun namaPahlawan() {
        assertEquals(Denomination.SERIBU, CurrencyParser.parse("Kapitan Pattimura"))
        assertEquals(Denomination.DUA_RIBU, CurrencyParser.parse("Pangeran Antasari"))
        assertEquals(Denomination.LIMA_RIBU, CurrencyParser.parse("K.H. Idham Chalid"))
        assertEquals(Denomination.SEPULUH_RIBU, CurrencyParser.parse("Frans Kaisiepo"))
        assertEquals(Denomination.DUA_PULUH_RIBU, CurrencyParser.parse("Otto Iskandar Dinata"))
        assertEquals(Denomination.LIMA_PULUH_RIBU, CurrencyParser.parse("Ir. H. Djuanda Kartawidjaja"))
    }

    @Test fun polaAngkaButuhJumlahNolYangPas() {
        assertEquals(Denomination.SERIBU, CurrencyParser.parse("1000"))
        assertEquals(Denomination.LIMA_RIBU, CurrencyParser.parse("5000"))
        assertEquals(Denomination.SEPULUH_RIBU, CurrencyParser.parse("10000"))
        assertEquals(Denomination.DUA_PULUH_RIBU, CurrencyParser.parse("20000"))
        assertEquals(Denomination.LIMA_PULUH_RIBU, CurrencyParser.parse("50000"))
        assertEquals(Denomination.SERATUS_RIBU, CurrencyParser.parse("100000"))
    }

    @Test fun salahBacaOcr() {
        assertEquals(Denomination.SERIBU, CurrencyParser.parse("000I"))
        assertEquals(Denomination.LIMA_RIBU, CurrencyParser.parse("000S"))
        assertEquals(Denomination.DUA_PULUH_RIBU, CurrencyParser.parse("0000Z"))
        assertEquals(Denomination.LIMA_PULUH_RIBU, CurrencyParser.parse("S0000"))
        assertEquals(Denomination.SEPULUH_RIBU, CurrencyParser.parse("0000I"))
    }

    @Test fun teksTidakRelevan() {
        assertNull(CurrencyParser.parse(""))
        assertNull(CurrencyParser.parse("   "))
        assertNull(CurrencyParser.parse("Selamat pagi"))
        assertNull(CurrencyParser.parse("1000 0")) // empat nol, bukan pola Rp1.000
    }
}
