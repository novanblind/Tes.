package com.novan.audiolabnovan.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/**
 * Tahap 67: gambar bawaan Audio ke Video bila pengguna tidak memilih foto, yaitu lambang robot Android
 * (hijau di atas latar gelap). Digambar lewat kode supaya tidak perlu berkas gambar tambahan dan tajam
 * di resolusi berapa pun.
 */
object LogoAndroid {

    fun buat(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.parseColor("#0B1F1A"))

        // Satuan gambar: sisi pendek layar. Robot dibuat setinggi sekitar 55 persen sisi pendek.
        val u = minOf(w, h) / 100f
        val cx = w / 2f
        val hijau = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3DDC84"); style = Paint.Style.FILL }
        val putih = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        val antena = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = hijau.color; style = Paint.Style.STROKE; strokeWidth = 1.6f * u; strokeCap = Paint.Cap.ROUND
        }

        val atas = h / 2f - 27f * u            // puncak kepala
        val kepalaT = 20f * u                   // tinggi kepala (setengah lingkaran)
        val kepalaR = 18f * u                   // jari-jari kepala
        val badanAtas = atas + kepalaT + 1.8f * u
        val badanT = 24f * u
        val badanL = 32f * u

        // Antena.
        c.drawLine(cx - 9f * u, atas + 2.5f * u, cx - 13f * u, atas - 4f * u, antena)
        c.drawLine(cx + 9f * u, atas + 2.5f * u, cx + 13f * u, atas - 4f * u, antena)

        // Kepala: setengah lingkaran menghadap atas.
        val kepala = Path().apply {
            arcTo(RectF(cx - kepalaR, atas + 2f * u, cx + kepalaR, atas + 2f * u + 2 * kepalaR), 180f, 180f, true)
            close()
        }
        c.drawPath(kepala, hijau)

        // Mata.
        c.drawCircle(cx - 7f * u, atas + 12f * u, 1.7f * u, Paint(putih).apply { color = Color.parseColor("#0B1F1A") })
        c.drawCircle(cx + 7f * u, atas + 12f * u, 1.7f * u, Paint(putih).apply { color = Color.parseColor("#0B1F1A") })

        // Badan.
        c.drawRoundRect(RectF(cx - badanL / 2f, badanAtas, cx + badanL / 2f, badanAtas + badanT), 2.5f * u, 2.5f * u, hijau)
        // Lengan.
        val lenganL = 5.6f * u
        c.drawRoundRect(RectF(cx - badanL / 2f - 2.2f * u - lenganL, badanAtas, cx - badanL / 2f - 2.2f * u, badanAtas + 17f * u), 2.8f * u, 2.8f * u, hijau)
        c.drawRoundRect(RectF(cx + badanL / 2f + 2.2f * u, badanAtas, cx + badanL / 2f + 2.2f * u + lenganL, badanAtas + 17f * u), 2.8f * u, 2.8f * u, hijau)
        // Kaki.
        val kakiL = 5.6f * u
        c.drawRoundRect(RectF(cx - 8.5f * u - kakiL / 2f, badanAtas + badanT - 2f * u, cx - 8.5f * u + kakiL / 2f, badanAtas + badanT + 11f * u), 2.8f * u, 2.8f * u, hijau)
        c.drawRoundRect(RectF(cx + 8.5f * u - kakiL / 2f, badanAtas + badanT - 2f * u, cx + 8.5f * u + kakiL / 2f, badanAtas + badanT + 11f * u), 2.8f * u, 2.8f * u, hijau)
        return bmp
    }
}
