package com.novan.githubbynovan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mengunggah satu atau banyak berkas ke repositori sebagai layanan latar depan, sehingga unggahan besar
 * (sampai 100 MB) tetap berjalan walaupun pengguna pindah ke aplikasi lain atau layar mati. Kemajuan tampil
 * di notifikasi (dengan tombol Batalkan); saat selesai muncul notifikasi hasil, dan rinciannya tampil begitu
 * aplikasi dibuka. Pekerjaan sebenarnya dilakukan oleh {@link MultiUnggah#proses} dan {@link UnggahBesar}.
 */
public class UnggahService extends Service {

    /** Hasil akhir unggahan, menunggu ditampilkan. */
    public static class Hasil {
        MultiUnggah.Hasil h;
        String full = "", token = "", folder = "", target = "";
        long idAwal;
        boolean tunggal;
        /** Pilihan "langsung bangun APK dan pantau" saat unggah. */
        boolean auto;
    }

    /** Bangun otomatis hanya bila unggahan lengkap: semua berkas masuk dan tidak dibatalkan. */
    static boolean layakBangun(MultiUnggah.Hasil h) {
        return h != null && !h.dibatalkan && h.gagal.isEmpty() && h.berhasil > 0 && h.berhasil == h.total;
    }

    public interface Listener {
        /** Dipanggil di thread utama. */
        void onStatus(String text);

        /** Dipanggil di thread utama setelah unggahan selesai, gagal, atau dibatalkan. */
        void onFinished();
    }

    private static final String ACTION_STOP = "com.novan.githubbynovan.STOP_UNGGAH";
    private static final String CH_PROGRESS = "unggah_berkas";
    private static final String CH_RESULT = "hasil_unggah_berkas";
    private static final int ID_PROGRESS = 47, ID_RESULT = 48;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Pattern PERSEN = Pattern.compile("(\\d{1,3})\\s?%");

    static volatile Listener listener;
    static volatile String lastText = "";
    static volatile boolean running;
    /** Nama lengkap repo (pemilik/nama) yang sedang diunggahi, supaya layar repo lain tidak ikut menampilkannya. */
    static volatile String repo = "";
    private static volatile MultiUnggah.Tugas tugas;
    private static Hasil pending;

    static synchronized void setPending(Hasil r) { pending = r; }
    static synchronized Hasil takePending() { Hasil r = pending; pending = null; return r; }
    static synchronized boolean hasPending() { return pending != null; }

    private PowerManager.WakeLock lock;
    private WifiManager.WifiLock wifi;
    private Thread worker;
    private long notifTerakhir;

    // ---------- pintu masuk ----------

    public static boolean busy() { return running; }

    /** True bila unggahan yang sedang berjalan adalah untuk repo ini. */
    public static boolean untuk(String full) { return running && full != null && full.equals(repo); }

    /**
     * Memulai unggahan di latar depan.
     *
     * @param jalurTunggal jalur tujuan penuh untuk unggah SATU berkas; null untuk unggah banyak berkas ke {@code folder}
     * @param idAwal       nomor pembangunan terakhir sebelum unggah (batas untuk "pantau pembangunan APK")
     * @param auto         bila true: komit ditandai [skip ci], lalu setelah SEMUA berkas berhasil, layar membuka
     *                     alur bangun APK (pilih tanda tangan, keamanan, lalu jalan) satu kali
     */
    public static boolean start(Context c, String full, String token, String folder, List<Uri> uris,
                                String jalurTunggal, long idAwal, boolean auto) {
        if (running || uris == null || uris.isEmpty()) return false;
        setPending(null);
        lastText = "";
        tugas = new MultiUnggah.Tugas();
        cancelResultNotification(c);
        Intent i = new Intent(c, UnggahService.class)
                .putExtra("full", full).putExtra("token", token).putExtra("folder", folder == null ? "" : folder)
                .putExtra("idAwal", idAwal).putExtra("auto", auto);
        if (jalurTunggal != null) i.putExtra("target", jalurTunggal);
        // Izin baca berkas dari pemilih diteruskan ke layanan, dan dipertahankan selama unggahan berjalan.
        ClipData cd = null;
        for (Uri u : uris) {
            try { c.getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
            if (cd == null) cd = ClipData.newRawUri("berkas", u); else cd.addItem(new ClipData.Item(u));
        }
        i.setClipData(cd);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            running = true;
            repo = full;
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            running = false;
            repo = "";
            return false;
        }
    }

    /** Membatalkan unggahan yang sedang berjalan. */
    public static void cancel(Context c) {
        MultiUnggah.Tugas t = tugas;
        if (t != null) t.batalkan();
        try {
            c.startService(new Intent(c, UnggahService.class).setAction(ACTION_STOP));
        } catch (Exception ignored) { }
    }

    public static void cancelResultNotification(Context c) {
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_RESULT);
        } catch (Exception ignored) { }
    }

    // ---------- siklus layanan ----------

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            MultiUnggah.Tugas t = tugas;
            if (t != null) t.batalkan();
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        final String full = intent == null ? null : intent.getStringExtra("full");
        final String token = intent == null ? null : intent.getStringExtra("token");
        final ClipData cd = intent == null ? null : intent.getClipData();
        if (full == null || token == null || cd == null || cd.getItemCount() == 0) {
            running = false;
            repo = "";
            stopSelf();
            return START_NOT_STICKY;
        }
        if (worker != null && worker.isAlive()) return START_NOT_STICKY;

        final List<Uri> uris = new ArrayList<>();
        for (int i = 0; i < cd.getItemCount(); i++) {
            Uri u = cd.getItemAt(i).getUri();
            if (u != null) uris.add(u);
        }
        final String folder = intent.getStringExtra("folder") == null ? "" : intent.getStringExtra("folder");
        final String target = intent.getStringExtra("target");
        final long idAwal = intent.getLongExtra("idAwal", 0);
        final boolean auto = intent.getBooleanExtra("auto", false);
        if (tugas == null) tugas = new MultiUnggah.Tugas();
        final MultiUnggah.Tugas tg = tugas;

        running = true;
        repo = full;
        Notification n = progressNotification(full, "Menyiapkan unggahan...", -1);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_PROGRESS, n);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (lock == null) lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "githubbynovan:unggah");
            if (!lock.isHeld()) lock.acquire(90 * 60 * 1000L);
        } catch (Exception ignored) { }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi == null && wm != null) wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "githubbynovan:unggah");
            if (wifi != null && !wifi.isHeld()) wifi.acquire();
        } catch (Exception ignored) { }

        worker = new Thread(() -> kerja(full, token, folder, uris, target, idAwal, tg, auto), "unggah-berkas");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ---------- pekerjaan ----------

    private void status(final String full, final String t) {
        lastText = t;
        long now = System.currentTimeMillis();
        if (now - notifTerakhir >= 800) {
            notifTerakhir = now;
            try {
                ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                        .notify(ID_PROGRESS, progressNotification(full, t, persen(t)));
            } catch (Exception ignored) { }
        }
        final Listener l = listener;
        if (l != null) MAIN.post(() -> l.onStatus(t));
    }

    private static int persen(String t) {
        try {
            Matcher m = PERSEN.matcher(t);
            int p = -1;
            while (m.find()) p = Integer.parseInt(m.group(1));
            return p >= 0 && p <= 100 ? p : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    private void kerja(String full, String token, String folder, List<Uri> uris, String target, long idAwal,
                       MultiUnggah.Tugas tg, boolean auto) {
        Hasil r = new Hasil();
        r.full = full;
        r.token = token;
        r.folder = folder;
        r.target = target == null ? "" : target;
        r.idAwal = idAwal;
        r.tunggal = target != null;
        r.auto = auto;
        try {
            r.h = MultiUnggah.proses(this, full, token, folder, uris, target, tg, t -> status(full, t), auto);
        } catch (Throwable e) {
            MultiUnggah.Hasil h = new MultiUnggah.Hasil();
            h.total = uris.size();
            h.galat = "Unggahan berhenti karena galat tak terduga:\n" + e;
            h.gagal.add(h.galat);
            r.h = h;
        } finally {
            for (Uri u : uris) {
                try { getContentResolver().releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) { }
            }
        }
        selesai(r);
    }

    private void selesai(Hasil r) {
        running = false;
        repo = "";
        tugas = null;
        // Dibatalkan sebelum satu pun berkas masuk: tidak ada yang perlu dilaporkan.
        boolean diam = r.h.dibatalkan && r.h.berhasil == 0;
        if (!diam) {
            setPending(r);
            postResultNotification(r);
        }
        final Listener l = listener;
        if (l != null) MAIN.post(l::onFinished);
        stopForeground(true);
        stopSelf();
    }

    // ---------- notifikasi ----------

    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_PROGRESS, "Unggah berkas",
                NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_RESULT, "Hasil unggah berkas",
                NotificationManager.IMPORTANCE_HIGH));
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, 6, i, f);
    }

    private Notification.Builder builder(String channel) {
        ensureChannels();
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification progressNotification(String full, String text, int persen) {
        Intent stop = new Intent(this, UnggahService.class).setAction(ACTION_STOP);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPi = PendingIntent.getService(this, 7, stop, f);
        Notification.Builder b = builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Mengunggah ke " + full)
                .setContentText(text.replace('\n', ' '))
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setContentIntent(openApp())
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Batalkan unggahan", stopPi);
        if (persen >= 0) b.setProgress(100, persen, false); else b.setProgress(0, 0, true);
        return b.build();
    }

    private void postResultNotification(Hasil r) {
        try {
            MultiUnggah.Hasil h = r.h;
            boolean semuaOk = !h.dibatalkan && h.gagal.isEmpty() && h.berhasil > 0;
            String judul = h.dibatalkan ? "Unggahan dihentikan"
                    : semuaOk ? "Unggahan selesai" : h.berhasil > 0 ? "Unggahan selesai dengan kendala" : "Unggahan gagal";
            String isi;
            if (r.tunggal) {
                isi = semuaOk ? r.target + " berhasil diunggah ke " + r.full + "."
                        : h.dibatalkan ? r.target + " tidak jadi diunggah."
                        : r.target + ": " + (h.galat.isEmpty() ? "gagal diunggah." : h.galat);
            } else {
                isi = "Berhasil " + h.berhasil + " dari " + h.total + " berkas ke " + r.full
                        + (h.gagal.isEmpty() ? "." : ", gagal " + h.gagal.size() + ".");
            }
            if (r.auto && h.berhasil > 0) {
                isi += layakBangun(h) ? " Ketuk untuk membangun APK sesuai Pengaturan bangun APK."
                        : " Bangun otomatis tidak jalan karena unggahan tidak lengkap.";
            }
            if (isi.length() > 300) isi = isi.substring(0, 300) + "...";
            Notification n = builder(CH_RESULT)
                    .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                    .setContentTitle(judul)
                    .setContentText(isi)
                    .setStyle(new Notification.BigTextStyle().bigText(isi + "\n\nKetuk untuk melihat rincian."))
                    .setAutoCancel(true)
                    .setContentIntent(openApp())
                    .build();
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_RESULT, n);
        } catch (Exception ignored) { }
    }
}
