package com.novan.pembacauang

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * OCR ML Kit untuk frame NV21, mengikuti MlKitDetector pada aplikasi acuan:
 *  - hanya lapisan kecerahan (Y) yang dipakai: diubah menjadi bitmap abu-abu ARGB_8888;
 *  - bitmap diberi arah sesuai rotasi kamera lalu dibaca ML Kit (model Latin);
 *  - hasilnya satu teks utuh, dipakai bila tidak kosong setelah di-trim;
 *  - bitmap dibuang setelah selesai.
 * Pembuatan bitmap berjalan di thread latar; [onText] dipanggil di thread utama.
 * [onDone] selalu dipanggil di akhir agar frame berikutnya bisa diproses.
 */
class MoneyRecognizer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val worker = Executors.newSingleThreadExecutor()
    private var px: IntArray? = null

    fun process(
        nv21: ByteArray,
        width: Int,
        height: Int,
        rotationDegrees: Int,
        onText: (String) -> Unit,
        onDone: () -> Unit,
    ) {
        worker.execute {
            var bitmap: Bitmap? = null
            try {
                val bmp = lumaBitmap(nv21, width, height)
                bitmap = bmp
                recognizer.process(InputImage.fromBitmap(bmp, rotationDegrees))
                    .addOnSuccessListener { result ->
                        val text = result.text
                        if (text.trim().isNotEmpty()) onText(text)
                    }
                    .addOnCompleteListener {
                        bmp.recycle()
                        onDone()
                    }
            } catch (e: Throwable) {
                bitmap?.recycle()
                onDone()
            }
        }
    }

    /** Y -> abu-abu: 0xFF000000 | (y * 0x010101). */
    private fun lumaBitmap(nv21: ByteArray, width: Int, height: Int): Bitmap {
        val n = width * height
        var buf = px
        if (buf == null || buf.size != n) {
            buf = IntArray(n)
            px = buf
        }
        for (i in 0 until n) {
            buf[i] = (0xFF000000.toInt()) or ((nv21[i].toInt() and 0xFF) * 0x10101)
        }
        return Bitmap.createBitmap(buf, width, height, Bitmap.Config.ARGB_8888)
    }

    fun close() {
        worker.shutdown()
        recognizer.close()
    }
}
