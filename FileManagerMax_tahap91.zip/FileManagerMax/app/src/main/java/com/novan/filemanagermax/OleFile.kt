package com.novan.filemanagermax

import java.io.File
import java.io.RandomAccessFile

/**
 * Pembaca wadah OLE2 / Compound File (.doc, .xls, .ppt lama) tanpa library tambahan.
 * Hanya membaca; sektor dibaca langsung dari berkas sehingga memori tetap kecil.
 */
class OleFile(file: File) : AutoCloseable {

    class Entry(val name: String, val type: Int, val start: Int, val size: Long)

    private val raf = RandomAccessFile(file, "r")
    private val sectorSize: Int
    private val miniSectorSize: Int
    private val miniCutoff: Long
    private val fat: IntArray
    private val entries = ArrayList<Entry>()
    private var miniFat = IntArray(0)
    private var miniStream: ByteArray? = null

    init {
        try {
            val h = ByteArray(512)
            raf.seek(0)
            raf.readFully(h)
            val magic = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte())
            for (i in 0 until 8) if (h[i] != magic[i]) throw IllegalStateException("bukan OLE")
            val shift = u16(h, 0x1E)
            if (shift != 9 && shift != 12) throw IllegalStateException("bukan OLE")
            sectorSize = 1 shl shift
            miniSectorSize = 1 shl u16(h, 0x20)
            miniCutoff = u32(h, 0x38)
            val numFat = u32(h, 0x2C).toInt()
            val firstDir = u32(h, 0x30).toInt()
            val firstMini = u32(h, 0x3C).toInt()
            val numMini = u32(h, 0x40).toInt()
            var difat = u32(h, 0x44).toInt()
            val numDifat = u32(h, 0x48).toInt()
            if (numFat < 0 || numFat > 100_000) throw IllegalStateException("rusak")

            // daftar sektor FAT
            val fatSectors = ArrayList<Int>()
            for (i in 0 until 109) {
                val s = u32(h, 0x4C + i * 4).toInt()
                if (s >= 0 && fatSectors.size < numFat) fatSectors.add(s)
            }
            var guard = 0
            var left = numDifat
            while (left > 0 && difat >= 0 && fatSectors.size < numFat && guard++ < 10_000) {
                val sec = readSector(difat)
                val per = sectorSize / 4 - 1
                for (i in 0 until per) {
                    val s = u32(sec, i * 4).toInt()
                    if (s >= 0 && fatSectors.size < numFat) fatSectors.add(s)
                }
                difat = u32(sec, per * 4).toInt()
                left--
            }
            val per = sectorSize / 4
            fat = IntArray(fatSectors.size * per)
            for ((idx, s) in fatSectors.withIndex()) {
                val sec = readSector(s)
                for (i in 0 until per) fat[idx * per + i] = u32(sec, i * 4).toInt()
            }

            // direktori
            val dir = readChain(firstDir, -1L)
            var off = 0
            while (off + 128 <= dir.size) {
                val nameLen = u16(dir, off + 64)
                val type = dir[off + 66].toInt()
                val name = if (nameLen >= 2 && nameLen <= 64)
                    String(dir, off, nameLen - 2, Charsets.UTF_16LE) else ""
                val start = u32(dir, off + 116).toInt()
                var size = u32(dir, off + 120)
                if (sectorSize == 512) size = size and 0x7FFFFFFFL
                entries.add(Entry(name, type, start, size))
                off += 128
            }
            if (entries.isEmpty()) throw IllegalStateException("rusak")

            // mini FAT
            if (numMini > 0 && firstMini >= 0) {
                val mf = readChain(firstMini, -1L)
                miniFat = IntArray(mf.size / 4) { u32(mf, it * 4).toInt() }
            }
        } catch (e: Exception) {
            raf.close()
            throw e
        }
    }

    override fun close() {
        try { raf.close() } catch (_: Exception) {}
    }

    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private fun readSector(n: Int): ByteArray {
        val b = ByteArray(sectorSize)
        raf.seek(512L + n.toLong() * sectorSize)
        raf.readFully(b)
        return b
    }

    /** Membaca rantai sektor FAT; size < 0 berarti semua sektor rantai. */
    private fun readChain(start: Int, size: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        var s = start
        var guard = 0
        val maxSectors = fat.size + 1
        while (s >= 0 && s < fat.size && guard++ <= maxSectors) {
            if (size >= 0 && out.size().toLong() >= size) break
            out.write(readSector(s))
            s = fat[s]
        }
        val all = out.toByteArray()
        return if (size >= 0 && all.size > size) all.copyOf(size.toInt()) else all
    }

    private fun readMini(start: Int, size: Long): ByteArray {
        var ms = miniStream
        if (ms == null) {
            val root = entries[0]
            ms = readChain(root.start, root.size)
            miniStream = ms
        }
        val out = java.io.ByteArrayOutputStream()
        var s = start
        var guard = 0
        while (s >= 0 && s < miniFat.size && guard++ <= miniFat.size + 1) {
            if (out.size().toLong() >= size) break
            val o = s.toLong() * miniSectorSize
            if (o + miniSectorSize > ms.size) break
            out.write(ms, o.toInt(), miniSectorSize)
            s = miniFat[s]
        }
        val all = out.toByteArray()
        return if (all.size > size) all.copyOf(size.toInt()) else all
    }

    /** Mencari aliran (stream) menurut nama di mana pun dalam pohon; null bila tidak ada. */
    fun find(name: String): Entry? =
        entries.firstOrNull { it.type == 2 && it.name.equals(name, ignoreCase = true) }

    fun read(e: Entry, maxBytes: Long = 200L * 1024 * 1024): ByteArray {
        if (e.size > maxBytes) throw IllegalStateException("Berkas terlalu besar untuk dibaca")
        return if (e.size < miniCutoff) readMini(e.start, e.size) else readChain(e.start, e.size)
    }

    fun readStream(name: String): ByteArray? = find(name)?.let { read(it) }

    companion object {
        fun isOle(f: File): Boolean = try {
            f.inputStream().use { ins ->
                val b = ByteArray(8)
                ins.read(b) == 8 && b[0] == 0xD0.toByte() && b[1] == 0xCF.toByte() &&
                    b[2] == 0x11.toByte() && b[3] == 0xE0.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }
}
