package com.novan.pisahsuara

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.IBinder
import android.os.IInterface
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper

/** Pengaturan: dua daftar centang (speaker HP / perangkat luar) dan pilihan perangkat luar. */
object Rules {
    private fun sp(c: Context) = c.getSharedPreferences("pisah_suara3", Context.MODE_PRIVATE)
    fun enabled(c: Context) = sp(c).getBoolean("aktif", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("aktif", v).apply()
    fun hp(c: Context): Set<String> = sp(c).getStringSet("hp", emptySet())!!.toSet()
    fun bt(c: Context): Set<String> = sp(c).getStringSet("bt", emptySet())!!.toSet()
    fun setHp(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("hp", v.toSet()).putStringSet("bt", bt(c) - v).apply()
    }
    fun setBt(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("bt", v.toSet()).putStringSet("hp", hp(c) - v).apply()
    }
    /** null = otomatis (perangkat luar pertama yang tersambung). */
    fun device(c: Context): String? = sp(c).getString("perangkat", null)
    fun setDevice(c: Context, v: String?) {
        sp(c).edit().apply { if (v == null) remove("perangkat") else putString("perangkat", v) }.apply()
    }
    fun active(c: Context) = enabled(c) && (hp(c).isNotEmpty() || bt(c).isNotEmpty())
}

object AudioRouter {
    private val allowedTypes = setOf(2, 3, 4, 8, 11, 22, 23, 26, 27, 30)
    private var wrapped = false
    @Volatile var status: String = "Belum diterapkan"
    /** Jam (ms) apply terakhir selesai dan jam apply yang sedang berjalan dimulai (0 = tidak ada), untuk diagnosis dan pengawas. */
    @Volatile var waktuApply = 0L
    @Volatile var mulaiApply = 0L

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun outputs(ctx: Context): List<AudioDeviceInfo> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in allowedTypes }
    }

    fun external(ctx: Context) = outputs(ctx).filter { it.type != 2 }

    fun key(d: AudioDeviceInfo) = "${d.type}|${d.address}"

    fun label(d: AudioDeviceInfo): String {
        if (d.type == 2) return "Speaker HP"
        val jenis = when (d.type) {
            8 -> "Bluetooth"
            26, 27, 30 -> "Bluetooth LE"
            3, 4 -> "Headset kabel"
            22, 11 -> "USB"
            23 -> "Alat bantu dengar"
            else -> "Lainnya"
        }
        return "${d.productName ?: ""} ($jenis)"
    }

    private fun wrapAudioService() {
        if (wrapped) return
        HiddenApiBypass.addHiddenApiExemptions("")
        val amCls = AudioManager::class.java
        val getSvc = amCls.getDeclaredMethod("getService").apply { isAccessible = true }
        val svc = getSvc.invoke(null) as IInterface
        val binder: IBinder = svc.asBinder()
        val stub = Class.forName("android.media.IAudioService\$Stub")
        val newSvc = stub.getMethod("asInterface", IBinder::class.java)
            .invoke(null, ShizukuBinderWrapper(binder))
        val f = amCls.getDeclaredField("sService").apply { isAccessible = true }
        f.set(null, newSvc)
        wrapped = true
    }

    private fun uids(ctx: Context, pkgs: Set<String>): List<Int> = pkgs.mapNotNull {
        try { ctx.packageManager.getApplicationInfo(it, 0).uid } catch (e: Exception) { null }
    }

    fun apply(ctx: Context): String {
        synchronized(this) {
            mulaiApply = System.currentTimeMillis()
            try { return terapkanAturan(ctx) } finally {
                waktuApply = System.currentTimeMillis()
                mulaiApply = 0L
            }
        }
    }

    private fun terapkanAturan(ctx: Context): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val shizuku = shizukuReady()
        if (!Rules.active(ctx)) {
            try { if (shizuku) { wrapAudioService(); Policy.release(am) } } catch (_: Throwable) {}
            if (AdbBackend.dipasangkan(ctx) && AdbBackend.tersambung(ctx)) AdbBackend.hentikan(ctx)
            status = "Pemisahan suara nonaktif"
            return status
        }
        val hp = uids(ctx, Rules.hp(ctx))
        val bt = uids(ctx, Rules.bt(ctx))
        status = if (shizuku) {
            try {
                wrapAudioService()
                Policy.register(ctx.applicationContext, am, hp.toIntArray(), bt.toIntArray(), Rules.device(ctx))
            } catch (e: Throwable) {
                "Gagal: ${e.javaClass.simpleName}: ${e.message}"
            }
        } else {
            // Server sudah hidup: kirim aturan baru (langsung berlaku). Bila tidak, mulai ulang penuh.
            AdbBackend.perbarui(ctx, hp, bt, Rules.device(ctx))
                ?: AdbBackend.terapkan(ctx, hp, bt, Rules.device(ctx))
        }
        return status
    }

    // ---------- Pemeriksaan keadaan nyata ----------

    class Pemain(val uid: Int, val state: Int, val tipe: Int, val alamat: String)
    class Laporan(val waktu: Long, val kebijakan: Boolean, val pemain: List<Pemain>, val galat: String?, val hasil: String?, val vol: String?, val paksa: String? = null, val riwayat: String? = null, val versi: String? = null, val volDiag: String? = null, val dump: String? = null, val cfg: String? = null, val pilihan: String? = null)

    private fun urai(t: String): Laporan? {
        var waktu = 0L
        var kebijakan = false
        var galat: String? = null
        var hasil: String? = null
        var vol: String? = null
        var paksa: String? = null
        var riwayat: String? = null
        var versi: String? = null
        var volDiag: String? = null
        var dump: String? = null
        var cfg: String? = null
        var pilihan: String? = null
        val pemain = ArrayList<Pemain>()
        for (baris in t.lines()) {
            val p = baris.trim().split(" ")
            when (p.firstOrNull()) {
                "T" -> waktu = p.getOrNull(1)?.toLongOrNull() ?: 0L
                "KEBIJAKAN" -> kebijakan = p.getOrNull(1) == "ya"
                "GALAT" -> galat = baris.removePrefix("GALAT").trim()
                "HASIL" -> hasil = baris.removePrefix("HASIL").trim()
                "VOL" -> vol = baris.removePrefix("VOL").trim()
                "PAKSA" -> paksa = baris.removePrefix("PAKSA").trim()
                "RIWAYAT" -> riwayat = baris.removePrefix("RIWAYAT").trim()
                "VERSI" -> versi = baris.removePrefix("VERSI").trim()
                "PILIHAN" -> pilihan = baris.removePrefix("PILIHAN").trim()
                "CFG" -> cfg = baris.removePrefix("CFG").trim()
                "DUMP" -> dump = baris.removePrefix("DUMP").trim()
                "VOLDIAG" -> volDiag = baris.removePrefix("VOLDIAG").trim()
                "P" -> if (p.size >= 6) pemain += Pemain(
                    p[1].toIntOrNull() ?: -1, p[2].toIntOrNull() ?: -1,
                    p[4].toIntOrNull() ?: -1, p[5]
                )
            }
        }
        return if (waktu == 0L) null else Laporan(waktu, kebijakan, pemain, galat, hasil, vol, paksa, riwayat, versi, volDiag, dump, cfg, pilihan)
    }

    /** Ambil laporan nyata. Jalur ADB membaca berkas denyut Server; jalur Shizuku bertanya langsung. Jangan dipanggil di thread utama. */
    private fun ambilLaporan(ctx: Context): Laporan? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return if (shizukuReady()) {
            try { wrapAudioService(); urai(Policy.laporan(am)) } catch (e: Throwable) { null }
        } else {
            AdbBackend.bacaLaporan(ctx)?.let { urai(it) }
        }
    }

    private fun himpunan(s: String): Set<Int> =
        if (s.isEmpty() || s == "-") emptySet() else s.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()

    /** Aturan (UID HP dan Bluetooth) yang dipegang Server sama dengan centang di aplikasi? */
    private fun aturanCocok(ctx: Context, lap: Laporan): Boolean {
        val cfg = lap.cfg ?: return false
        var hp: Set<Int> = emptySet()
        var bt: Set<Int> = emptySet()
        for (b in cfg.split(";")) {
            if (b.startsWith("hp=")) hp = himpunan(b.substring(3))
            else if (b.startsWith("bt=")) bt = himpunan(b.substring(3))
        }
        return hp == uids(ctx, Rules.hp(ctx)).toSet() && bt == uids(ctx, Rules.bt(ctx)).toSet()
    }

    /** True bila kebijakan benar-benar terpasang dan Server masih berdenyut. */
    fun sehat(ctx: Context): Boolean {
        val l = ambilLaporan(ctx) ?: return false
        val segar = shizukuReady() || Math.abs(System.currentTimeMillis() - l.waktu) < 25000
        // Server dari versi aplikasi lama (setelah pembaruan) dianggap tidak sehat supaya dimulai ulang.
        val versiCocok = shizukuReady() || l.versi == AdbBackend.versiApp(ctx)
        return segar && l.kebijakan && versiCocok && (shizukuReady() || aturanCocok(ctx, l))
    }

    private fun labelApp(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
    } catch (e: Exception) { pkg }

    /** Teks status yang jujur: hasil pemeriksaan langsung, bukan sisa hasil terakhir. Jangan dipanggil di thread utama. */
    fun statusNyata(ctx: Context): String {
        if (!Rules.enabled(ctx)) return "Pemisahan suara NONAKTIF: saklar mati."
        if (!Rules.active(ctx)) return "Saklar aktif, tetapi belum ada aplikasi yang dicentang. Pemisahan suara belum berjalan."
        val lap = ambilLaporan(ctx)
        val segar = lap != null && (shizukuReady() || Math.abs(System.currentTimeMillis() - lap.waktu) < 25000)
        if (lap == null || !segar || !lap.kebijakan) {
            val sebab = when {
                lap == null && !shizukuReady() && !Kompat.adaNirkabel() && !AdbBackend.tersambung(ctx) ->
                    "ADB belum tersambung. Android ${android.os.Build.VERSION.RELEASE} butuh 'adb tcpip 5555' dari komputer (USB) atau HP lain (kabel OTG); ketuk baris Sambungan ADB untuk petunjuk. Mode ini hilang saat HP restart."
                lap == null && !shizukuReady() && !AdbBackend.dipasangkan(ctx) -> "ADB belum dipasangkan."
                lap == null && !shizukuReady() && !AdbBackend.tersambung(ctx) -> "ADB terputus."
                lap == null -> "Server pengalih suara belum berjalan."
                !segar -> "Server pengalih suara berhenti (tidak ada denyut)."
                else -> "Kebijakan audio belum terpasang."
            }
            val catatan = if (!shizukuReady() && lap != null) AdbBackend.catatanServer(ctx) else null
            return "Pemisahan suara BELUM BERJALAN. $sebab\nHasil percobaan terakhir: ${lap?.hasil ?: status}" +
                (if (catatan != null) "\nCatatan Server: $catatan" else "")
        }
        if (!shizukuReady() && lap.versi != AdbBackend.versiApp(ctx)) {
            return "Pemisahan suara BELUM BERJALAN. Server pengalih suara masih versi lama (Server ${lap.versi ?: "?"}, aplikasi ${AdbBackend.versiApp(ctx)}); akan dimulai ulang otomatis."
        }
        if (!shizukuReady() && !aturanCocok(ctx, lap)) {
            return "Pemisahan suara BELUM BERJALAN. Aturan di Server (${lap.cfg}) belum sama dengan centang di aplikasi; sedang dikirim ulang." +
                "\nPengiriman terakhir: ${if (waktuApply == 0L) "belum pernah selesai" else "${(System.currentTimeMillis() - waktuApply) / 1000} dtk lalu"}" +
                (if (mulaiApply != 0L) " (sedang berjalan ${(System.currentTimeMillis() - mulaiApply) / 1000} dtk)" else "") +
                " | hasil: $status"
        }
        val ext = if (Rules.device(ctx) == null) external(ctx).firstOrNull()
                  else external(ctx).firstOrNull { key(it) == Rules.device(ctx) }
        val sb = StringBuilder("Pemisahan suara AKTIF (kebijakan terpasang).")
        if (lap.galat != null) sb.append("\nPeringatan: tidak bisa membaca aliran suara (${lap.galat}).")
        val rencana = Rules.hp(ctx).map { it to false } + Rules.bt(ctx).map { it to true }
        for ((pkg, keBt) in rencana.sortedBy { labelApp(ctx, it.first).lowercase() }) {
            val uid = try { ctx.packageManager.getApplicationInfo(pkg, 0).uid } catch (e: Exception) { continue }
            val nama = labelApp(ctx, pkg)
            val target = if (keBt) "speaker Bluetooth" else "speaker HP"
            val main = lap.pemain.filter { it.uid == uid && it.state == 2 }
            if (keBt && ext == null) {
                sb.append("\n- $nama (target $target): perangkat Bluetooth belum tersambung, ikut pengaturan sistem.")
                continue
            }
            if (main.isEmpty()) {
                sb.append("\n- $nama (target $target): sedang tidak memutar suara.")
                continue
            }
            val hasil = main.map { m ->
                when {
                    m.tipe == -1 -> "?"
                    m.tipe == 2 -> "HP"
                    else -> "BT"
                }
            }.toSet()
            val aktual = hasil.joinToString(" dan ") { when (it) { "HP" -> "speaker HP"; "BT" -> "speaker Bluetooth"; else -> "perangkat tidak diketahui" } }
            val benar = hasil == setOf(if (keBt) "BT" else "HP")
            val tak = hasil.contains("?")
            sb.append("\n- $nama (target $target): sedang diputar di $aktual. ")
            sb.append(if (benar) "SESUAI." else if (tak) "Belum bisa dipastikan." else "TIDAK SESUAI, hentikan lalu putar ulang aplikasinya.")
            if (!benar) {
                val m0 = main.first()
                val tujuan = if (keBt) (ext?.let { key(it) } ?: "-") else "2|"
                sb.append(" [terbaca: tipe=${m0.tipe} alamat=${m0.alamat}; tujuan: $tujuan]")
            }
        }
        val vp = lap.vol?.split(" ", limit = 2)
        if (Rules.hp(ctx).isNotEmpty() && vp != null && vp.size == 2 && vp[0] != "-") {
            sb.append(if (vp[1] == "ok") "\nVolume media speaker HP mengikuti tombol volume (tingkat ${vp[0]})."
                      else "\nVolume media speaker HP GAGAL disamakan: ${vp[1]}")
        }
        if (Rules.hp(ctx).isNotEmpty() && !lap.volDiag.isNullOrEmpty() && lap.volDiag != "-")
            sb.append("\nDiagnosis volume: ${lap.volDiag}")
        if (Rules.hp(ctx).isNotEmpty() && !lap.riwayat.isNullOrEmpty())
            sb.append("\nRiwayat volume media (tanda * = saat mesin suara bicara): ${lap.riwayat}")
        if (lap.paksa != null && lap.paksa != "-") sb.append("\nPaksa pindah aliran suara: ${lap.paksa}")
        sb.append("\nAturan di aplikasi: hp=${Rules.hp(ctx).map { try { ctx.packageManager.getApplicationInfo(it, 0).uid } catch (e: Exception) { -1 } }} bt=${Rules.bt(ctx).map { try { ctx.packageManager.getApplicationInfo(it, 0).uid } catch (e: Exception) { -1 } }}")
        sb.append("\nAturan di Server: ${lap.cfg}")
        if (!lap.pilihan.isNullOrEmpty()) sb.append("\nPilihan perangkat media sistem: ${lap.pilihan}")
        if (!lap.hasil.isNullOrEmpty()) sb.append("\nHasil pemasangan kebijakan: ${lap.hasil}")
        if (!lap.dump.isNullOrEmpty() && lap.dump != "-") sb.append("\nDump kebijakan audio: ${lap.dump.take(2200)}")
        if (!shizukuReady()) sb.append("\nVersi Server: ${lap.versi}.")
        sb.append("\nAplikasi yang tidak dicentang mengikuti pengaturan sistem.")
        return sb.toString()
    }
}
