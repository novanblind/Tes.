package com.novan.filemanagerpro

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

/** Daftar lokasi jarak jauh tersimpan (FTP, SFTP, SMB, WebDAV). */
class RemotesActivity : AppCompatActivity() {

    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var remotes: List<RemoteConfig> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.remote_title)
        empty = findViewById(R.id.empty)
        empty.setText(R.string.remote_empty)
        rowAdapter = RowAdapter(onClick = { openItem(it) }, onLong = { showActions(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        remotes = RemoteStore.all(this)
        val rows = remotes.map { r ->
            val detail = "${r.typeLabel()}, ${r.host}"
            Row(R.drawable.ic_storage, r.name, detail, "${r.name}, $detail", r.id)
        }
        rowAdapter.submit(rows)
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = getString(R.string.items_count, rows.size)
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun openItem(i: Int) {
        if (i !in remotes.indices) return
        startActivity(
            Intent(this, RemoteBrowserActivity::class.java)
                .putExtra(RemoteBrowserActivity.EXTRA_ID, remotes[i].id)
        )
    }

    private fun showActions(i: Int) {
        if (i !in remotes.indices) return
        val r = remotes[i]
        AlertDialog.Builder(this)
            .setTitle(r.name)
            .setItems(
                arrayOf(getString(R.string.act_open), getString(R.string.remote_edit), getString(R.string.action_delete))
            ) { _, which ->
                when (which) {
                    0 -> openItem(i)
                    1 -> showEditor(r)
                    2 -> AlertDialog.Builder(this)
                        .setMessage(getString(R.string.remote_delete_confirm, r.name))
                        .setPositiveButton(R.string.action_delete) { _, _ ->
                            RemoteStore.delete(this, r.id)
                            load()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .show()
    }

    private fun field(box: LinearLayout, hintRes: Int, text: String, type: Int): EditText {
        val e = EditText(this)
        e.setHint(hintRes)
        e.setText(text)
        e.inputType = type
        e.minHeight = (56 * resources.displayMetrics.density).toInt()
        box.addView(e)
        return e
    }

    private fun showEditor(existing: RemoteConfig?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        box.setPadding(pad, pad, pad, pad)

        val group = RadioGroup(this)
        val types = listOf("ftp" to "FTP", "sftp" to "SFTP", "smb" to "SMB", "webdav" to "WebDAV", "webdavs" to "WebDAV (HTTPS)")
        val buttons = types.map { (key, label) ->
            RadioButton(this).also {
                it.text = label
                it.id = View.generateViewId()
                it.tag = key
                group.addView(it)
            }
        }
        val curType = existing?.type ?: "ftp"
        buttons.first { it.tag == curType }.isChecked = true
        box.addView(group)

        val txt = InputType.TYPE_CLASS_TEXT
        val name = field(box, R.string.remote_name, existing?.name ?: "", txt)
        val host = field(box, R.string.remote_host, existing?.host ?: "", txt or InputType.TYPE_TEXT_VARIATION_URI)
        val port = field(box, R.string.remote_port, if (existing != null && existing.port > 0) existing.port.toString() else "", InputType.TYPE_CLASS_NUMBER)
        val user = field(box, R.string.remote_user, existing?.user ?: "", txt)
        val pass = field(box, R.string.remote_pass, "", txt or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(PasswordUi.checkBox(this, pass))
        val path = field(box, R.string.remote_path, existing?.path ?: "", txt)

        val sv = ScrollView(this)
        sv.addView(box)
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (existing == null) R.string.remote_add else R.string.remote_edit)
            .setView(sv)
            .setPositiveButton(R.string.remote_save, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val type = buttons.first { it.isChecked }.tag as String
                val h = host.text.toString().trim()
                if (h.isEmpty()) { host.error = getString(R.string.remote_need_host); return@setOnClickListener }
                val prt = port.text.toString().toIntOrNull() ?: 0
                val pw = pass.text.toString()
                val cfg = RemoteConfig(
                    existing?.id ?: RemoteStore.newId(),
                    name.text.toString().trim().ifEmpty { h },
                    type, h, prt, user.text.toString().trim(),
                    if (pw.isEmpty() && existing != null) existing.pass else pw,
                    path.text.toString().trim().ifEmpty { if (type == "smb") "" else "/" }
                )
                if (type == "smb" && cfg.path.trim('/').isEmpty()) {
                    path.error = getString(R.string.remote_need_share)
                    return@setOnClickListener
                }
                RemoteStore.save(this, cfg)
                dlg.dismiss()
                load()
            }
        }
        dlg.show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.remotes_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_add_remote -> showEditor(null)
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
