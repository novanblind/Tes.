package com.novan.filemanagerpro

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.concurrent.Executors

/** Pengelola aplikasi: daftar aplikasi terpasang, buka, cadangkan APK, bagikan, copot, info; bisa pilih beberapa sekaligus. */
class AppsActivity : AppCompatActivity() {

    private class AppItem(val label: String, val pkg: String, val info: ApplicationInfo)

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var rowAdapter: RowAdapter
    private lateinit var empty: TextView
    private var apps: List<AppItem> = emptyList()
    private var showSystem = false
    private var selecting = false
    private val sel = HashSet<String>()
    private var baseRows: List<Row> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.apps_title)
        empty = findViewById(R.id.empty)
        empty.setText(R.string.apps_loading)
        empty.visibility = View.VISIBLE
        rowAdapter = RowAdapter(onClick = { onClickRow(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selecting) stopSelect() else finish()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun say(t: String) =
        Snackbar.make(findViewById(android.R.id.content), t, Snackbar.LENGTH_LONG).show()

    private fun load() {
        val system = showSystem
        executor.execute {
            val pm = packageManager
            val out = ArrayList<AppItem>()
            try {
                for (ai in pm.getInstalledApplications(0)) {
                    val isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                        (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                    if (isSys && !system) continue
                    out.add(AppItem(pm.getApplicationLabel(ai).toString(), ai.packageName, ai))
                }
            } catch (e: Exception) {
                // gagal membaca daftar aplikasi
            }
            out.sortBy { it.label.lowercase() }
            val rows = out.map { a ->
                val ver = try {
                    pm.getPackageInfo(a.pkg, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
                val size = Formatter.formatFileSize(this, File(a.info.sourceDir).length())
                val isSplit = !a.info.splitSourceDirs.isNullOrEmpty()
                val detail = "${a.pkg}, ${getString(R.string.apps_version, ver)}, $size" +
                    (if (isSplit) ", ${getString(R.string.apps_split_tag)}" else "")
                Row(R.drawable.ic_apk, a.label, detail, "${a.label}, $detail", a.pkg)
            }
            main.post {
                if (isFinishing || isDestroyed) return@post
                apps = out
                baseRows = rows
                sel.retainAll(out.map { it.pkg }.toSet())
                refresh()
                empty.setText(R.string.apps_none)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
                updateSubtitle()
            }
        }
    }

    // ---------------------------------------------------------- pilih beberapa

    private fun refresh() {
        rowAdapter.submit(baseRows.map {
            it.copy(selected = if (selecting) (it.tag as String) in sel else null)
        })
    }

    private fun updateSubtitle() {
        supportActionBar?.subtitle =
            if (selecting) getString(R.string.zip_select_count, sel.size)
            else getString(R.string.items_count, baseRows.size)
    }

    private fun startSelect(first: String?) {
        selecting = true
        sel.clear()
        if (first != null) sel.add(first)
        refresh()
        invalidateOptionsMenu()
        updateSubtitle()
        say(getString(R.string.zip_select_on, sel.size))
    }

    private fun stopSelect() {
        selecting = false
        sel.clear()
        refresh()
        invalidateOptionsMenu()
        updateSubtitle()
    }

    private fun toggle(i: Int) {
        if (i !in apps.indices) return
        val pkg = apps[i].pkg
        val now = sel.add(pkg)
        if (!now) sel.remove(pkg)
        rowAdapter.setSelected(i, now)
        updateSubtitle()
        say(getString(R.string.zip_select_count, sel.size))
    }

    private fun selectAll() {
        sel.clear()
        apps.forEach { sel.add(it.pkg) }
        rowAdapter.setAllSelected(true)
        updateSubtitle()
        say(getString(R.string.zip_select_count, sel.size))
    }

    private fun selectedApps(): List<AppItem> = apps.filter { it.pkg in sel }

    private fun onClickRow(i: Int) {
        if (selecting) toggle(i) else showActions(i)
    }

    private fun showActions(i: Int) {
        if (i !in apps.indices) return
        val a = apps[i]
        val labels = arrayOf(
            getString(R.string.act_open), getString(R.string.apps_backup),
            getString(R.string.apps_share), getString(R.string.action_share_doc), getString(R.string.menu_select),
            getString(R.string.apps_uninstall), getString(R.string.apps_info),
            getString(R.string.apps_props), getString(R.string.apps_store)
        )
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> {
                        val li = packageManager.getLaunchIntentForPackage(a.pkg)
                        if (li == null) say(getString(R.string.apps_cannot_launch))
                        else startActivity(li)
                    }
                    1 -> backup(a)
                    2 -> backup(a, share = true)
                    3 -> backup(a, share = true, asDoc = true)
                    4 -> startSelect(a.pkg)
                    5 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                    6 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                    )
                    7 -> PropsDialog.showApp(this, a.pkg)
                    8 -> PropsDialog.openStore(this, a.pkg)
                }
            }
            .show()
    }

    /**
     * Mencadangkan APK ke FileManagerPro/Backup. Bila [share] true, cadangan dibuat di
     * folder sementara lalu langsung dibagikan (mis. ke WhatsApp) dengan nama
     * NamaAplikasi_versi.apk, atau .apk+ untuk aplikasi split.
     */
    private fun backup(a: AppItem, share: Boolean = false, asDoc: Boolean = false) {
        val dlg = AlertDialog.Builder(this).setMessage(R.string.apps_backing_up).setCancelable(false).show()
        executor.execute {
            var made: File? = null
            val msg = try {
                val dir = if (share) File(cacheDir, "share_apk").also { it.deleteRecursively() }
                else File(Environment.getExternalStorageDirectory(), "FileManagerPro/Backup")
                val target = buildBackup(a, dir)
                made = target
                getString(R.string.apps_backup_done, target.absolutePath)
            } catch (e: Exception) {
                getString(R.string.op_failed, e.message ?: "")
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                val shared = made
                if (share && shared != null) {
                    val ok = if (asDoc) Util.shareAsDocument(this, listOf(shared)) else Util.share(this, shared)
                    if (!ok) say(getString(R.string.cannot_open))
                } else {
                    say(msg)
                }
            }
        }
    }

    /** Membuat berkas cadangan [a] di [dir]: .apk biasa, atau .apk+ bila split. Melempar exception bila gagal. */
    private fun buildBackup(a: AppItem, dir: File): File {
                val ver = try {
                    packageManager.getPackageInfo(a.pkg, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
                val safe = a.label.replace(Regex("[^A-Za-z0-9_.-]"), "_")
                dir.mkdirs()
                val splits = a.info.splitSourceDirs
                val target: File
                if (splits == null || splits.isEmpty()) {
                    // APK biasa: tetap satu berkas .apk
                    target = File(dir, "${safe}_$ver.apk") // versi sama: cadangan lama ditimpa
                    File(a.info.sourceDir).copyTo(target, overwrite = true)
                } else {
                    // APK split: format .apk+ (ZIP berisi base.apk, split apk, icon.png, apk+.json)
                    target = File(dir, "${safe}_$ver.apk+") // versi sama: cadangan lama ditimpa
                    try {
                        val pm = packageManager
                        val pi = pm.getPackageInfo(a.pkg, 0)
                        val meta = org.json.JSONObject()
                            .put("name", a.label)
                            .put("package_name", a.pkg)
                            .put("version_name", ver)
                            .put("version_code", androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(pi))
                            .put("min_sdk_version", a.info.minSdkVersion)
                        java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(target.outputStream())).use { zip ->
                            zip.setLevel(java.util.zip.Deflater.NO_COMPRESSION)
                            val used = HashSet<String>()
                            fun entryName(n0: String): String {
                                var n = n0
                                var k = 1
                                while (!used.add(n)) { n = "${k++}_$n0" }
                                return n
                            }
                            fun add(n0: String, src: File) {
                                zip.putNextEntry(java.util.zip.ZipEntry(entryName(n0)))
                                src.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                            add("base.apk", File(a.info.sourceDir))
                            for (sp in splits) add(File(sp).name, File(sp))
                            try {
                                val dr = pm.getApplicationIcon(a.pkg)
                                val bmp = android.graphics.Bitmap.createBitmap(192, 192, android.graphics.Bitmap.Config.ARGB_8888)
                                val cv = android.graphics.Canvas(bmp)
                                dr.setBounds(0, 0, 192, 192)
                                dr.draw(cv)
                                zip.putNextEntry(java.util.zip.ZipEntry(entryName("icon.png")))
                                bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, zip)
                                zip.closeEntry()
                            } catch (e: Exception) {
                                // ikon opsional
                            }
                            zip.putNextEntry(java.util.zip.ZipEntry(entryName("apk+.json")))
                            zip.write(meta.toString().toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    } catch (e: Exception) {
                        target.delete()
                        throw e
                    }
                }
                return target
    }

    /** Mencadangkan (atau membagikan) beberapa aplikasi sekaligus. */
    private fun backupMany(list: List<AppItem>, share: Boolean, asDoc: Boolean = false) {
        if (list.isEmpty()) { say(getString(R.string.zip_select_none)); return }
        val dlg = AlertDialog.Builder(this)
            .setMessage(getString(R.string.apps_backing_up_n, 0, list.size))
            .setCancelable(false).show()
        executor.execute {
            val dir = if (share) File(cacheDir, "share_apk").also { it.deleteRecursively() }
            else File(Environment.getExternalStorageDirectory(), "FileManagerPro/Backup")
            val made = ArrayList<File>()
            var failed = 0
            list.forEachIndexed { i, a ->
                main.post { if (!isDestroyed) dlg.setMessage(getString(R.string.apps_backing_up_n, i + 1, list.size)) }
                try {
                    made.add(buildBackup(a, dir))
                } catch (e: Exception) {
                    failed++
                }
            }
            main.post {
                if (isDestroyed) return@post
                dlg.dismiss()
                if (made.isEmpty()) {
                    say(getString(R.string.apps_backup_all_failed))
                    return@post
                }
                stopSelect()
                if (share) {
                    val ok = if (asDoc) Util.shareAsDocument(this, made)
                        else if (made.size == 1) Util.share(this, made[0]) else shareMany(made)
                    if (!ok) say(getString(R.string.cannot_open))
                    else if (failed > 0) say(getString(R.string.apps_backup_n_failed, failed))
                } else {
                    var t = getString(R.string.apps_backup_n_done, made.size, dir.absolutePath)
                    if (failed > 0) t += ". " + getString(R.string.apps_backup_n_failed, failed)
                    say(t)
                }
            }
        }
    }

    private fun shareMany(files: List<File>): Boolean = try {
        val uris = ArrayList<Uri>(files.map { Util.uriOf(this, it) })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
            .setType("*/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
        true
    } catch (e: Exception) {
        false
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.apps_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_system_apps).isChecked = showSystem
        menu.findItem(R.id.action_system_apps).isVisible = !selecting
        menu.findItem(R.id.action_select).isVisible = !selecting
        for (id in intArrayOf(R.id.action_sel_all, R.id.action_sel_backup, R.id.action_sel_share, R.id.action_sel_share_doc, R.id.action_sel_cancel)) {
            menu.findItem(id).isVisible = selecting
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> if (selecting) stopSelect() else finish()
            R.id.action_select -> startSelect(null)
            R.id.action_sel_cancel -> stopSelect()
            R.id.action_sel_all -> selectAll()
            R.id.action_sel_backup -> {
                val l = selectedApps()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else backupMany(l, share = false)
            }
            R.id.action_sel_share -> {
                val l = selectedApps()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else backupMany(l, share = true)
            }
            R.id.action_sel_share_doc -> {
                val l = selectedApps()
                if (l.isEmpty()) say(getString(R.string.zip_select_none)) else backupMany(l, share = true, asDoc = true)
            }
            R.id.action_system_apps -> {
                showSystem = !showSystem
                load()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
