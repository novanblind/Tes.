@echo off
rem Memberi izin tingkat tinggi ke MakroKu lewat ADB (Windows). Aktifkan USB debugging lalu jalankan file ini.
set PKG=com.makroku.automation
adb get-state >nul 2>&1 || (echo Perangkat tidak terdeteksi & exit /b 1)

adb shell pm grant %PKG% android.permission.WRITE_SECURE_SETTINGS
for %%P in (SEND_SMS RECEIVE_SMS READ_PHONE_STATE READ_CALL_LOG READ_CONTACTS READ_CALENDAR CALL_PHONE POST_NOTIFICATIONS BLUETOOTH_CONNECT) do adb shell pm grant %PKG% android.permission.%%P
adb shell appops set %PKG% WRITE_SETTINGS allow
adb shell appops set %PKG% SYSTEM_ALERT_WINDOW allow
adb shell appops set %PKG% SCHEDULE_EXACT_ALARM allow
adb shell cmd notification allow_dnd %PKG%
adb shell cmd notification allow_listener %PKG%/%PKG%.service.MacroNotificationListener
adb shell dumpsys deviceidle whitelist +%PKG%
echo.
echo Aksesibilitas: buka MakroKu - Izin via ADB - tombol "Aksesibilitas" (menambah tanpa menimpa layanan lain).
echo Selesai.
