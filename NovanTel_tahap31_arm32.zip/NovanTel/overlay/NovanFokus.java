package org.telegram.messenger;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * Novan Tel - urutan fokus pembaca layar di halaman utama (tahap 30).
 *
 * Urutan yang diinginkan (geseran pertama langsung ke tab):
 *   tab kategori (Semua, Grup, Pribadi, Channel)  ->  daftar obrolan  ->  judul/menu dan kolom cari  ->  tombol-tombol bilah bawah layar.
 *
 * Caranya memakai aturan urutan telusur bawaan Android (setAccessibilityTraversalAfter/Before), yang dipahami TalkBack
 * dan pembaca layar lain, tanpa mengubah susunan atau gambar layar. Semua pekerjaan dibungkus try/catch: bila gagal,
 * urutan fokus kembali seperti bawaan Telegram dan aplikasi tidak terganggu.
 */
public final class NovanFokus {

    private static final String TAG = "NovanFokus";

    private NovanFokus() {
    }

    /**
     * Dipanggil dari DialogsActivity (onResume dan onBecomeFullyVisible).
     *
     * @param tab    tampilan tab kategori (filterTabsView)
     * @param halaman halaman daftar obrolan (viewPages; dua halaman karena geser antar tab saling bertukar)
     * @param akar   tampilan layar DialogsActivity (fragmentView)
     * @param atas   bilah judul/menu dan kolom cari (boleh berisi null); dibaca setelah daftar obrolan
     */
    public static void atur(final View tab, final View[] halaman, final View akar, final View[] atas) {
        try {
            if (Build.VERSION.SDK_INT < 22 || tab == null || halaman == null) {
                return;
            }
            beriId(tab);
            for (View h : halaman) {
                if (h != null) {
                    beriId(h);
                    // setiap halaman daftar dibaca SETELAH tab (dua halaman, karena keduanya bergantian saat geser antar tab)
                    h.setAccessibilityTraversalAfter(tab.getId());
                }
            }
            // judul/menu dan kolom cari dibaca SETELAH daftar obrolan (halaman yang sedang tampil), jadi tab tetap yang pertama
            View tampil = null;
            for (View h : halaman) {
                if (h != null && h.getVisibility() == View.VISIBLE) {
                    tampil = h;
                    break;
                }
            }
            if (tampil == null) {
                for (View h : halaman) {
                    if (h != null) {
                        tampil = h;
                        break;
                    }
                }
            }
            if (atas != null && tampil != null) {
                for (View a : atas) {
                    if (a != null) {
                        beriId(a);
                        a.setAccessibilityTraversalAfter(tampil.getId());
                    }
                }
            }
            if (akar != null) {
                // bilah bawah baru diketahui letaknya setelah layar selesai disusun
                akar.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            aturBilahBawah(tab, halaman, akar, atas);
                        } catch (Throwable t) {
                            Log.w(TAG, "bilah bawah gagal diatur", t);
                        }
                    }
                }, 400);
            }
        } catch (Throwable t) {
            Log.w(TAG, "urutan fokus gagal diatur", t);
        }
    }

    private static void beriId(View v) {
        if (v.getId() == View.NO_ID) {
            v.setId(View.generateViewId());
        }
    }

    private static boolean leluhurDari(View calon, View v) {
        // true bila 'calon' adalah v sendiri atau salah satu induk v
        Object p = v;
        int batas = 64;
        while (p instanceof View && batas-- > 0) {
            if (p == calon) {
                return true;
            }
            p = ((View) p).getParent();
        }
        return false;
    }

    private static void aturBilahBawah(View tab, View[] halaman, View akar, View[] atas) {
        View bilah = cariBilahBawah(tab, halaman, akar);
        if (bilah == null) {
            return;
        }
        beriId(bilah);
        tab.setAccessibilityTraversalBefore(bilah.getId());
        for (View h : halaman) {
            if (h != null) {
                h.setAccessibilityTraversalBefore(bilah.getId());
            }
        }
        if (atas != null) {
            for (View a : atas) {
                if (a != null && a != bilah && !leluhurDari(a, bilah) && !leluhurDari(bilah, a)) {
                    a.setAccessibilityTraversalBefore(bilah.getId());
                }
            }
        }
        Log.i(TAG, "bilah bawah ditemukan: " + bilah.getClass().getName());
    }

    /** Mencari wadah tombol di dasar layar: lebar, rendah, menempel dekat dasar jendela, berisi beberapa tombol. */
    private static View cariBilahBawah(View tab, View[] halaman, View akar) {
        View akarJendela = akar.getRootView();
        if (!(akarJendela instanceof ViewGroup)) {
            return null;
        }
        int lebar = akarJendela.getWidth();
        int tinggi = akarJendela.getHeight();
        if (lebar <= 0 || tinggi <= 0) {
            return null;
        }
        int[] lokasiAkar = new int[2];
        akarJendela.getLocationOnScreen(lokasiAkar);
        int dasarJendela = lokasiAkar[1] + tinggi;
        float dp = akar.getResources().getDisplayMetrics().density;

        View terbaik = null;
        long luasTerbaik = -1;
        ArrayList<View> tumpukan = new ArrayList<View>();
        tumpukan.add(akarJendela);
        int diperiksa = 0;
        int[] lok = new int[2];
        while (!tumpukan.isEmpty() && diperiksa < 6000) {
            View v = tumpukan.remove(tumpukan.size() - 1);
            diperiksa++;
            if (!(v instanceof ViewGroup) || v.getVisibility() != View.VISIBLE) {
                continue;
            }
            ViewGroup g = (ViewGroup) v;
            boolean terkecualikan = leluhurDari(g, tab) || leluhurDari(tab, g);
            for (View h : halaman) {
                if (h != null && (leluhurDari(g, h) || leluhurDari(h, g))) {
                    terkecualikan = true;
                }
            }
            if (!terkecualikan && g.isShown() && g.getWidth() >= lebar * 0.5f && g.getHeight() > 0 && g.getHeight() <= tinggi * 0.3f) {
                g.getLocationOnScreen(lok);
                int dasar = lok[1] + g.getHeight();
                if (dasar >= dasarJendela - 96 * dp && lok[1] > tinggi * 0.5f && jumlahTombol(g) >= 2) {
                    long luas = (long) g.getWidth() * g.getHeight();
                    if (luas > luasTerbaik) {
                        luasTerbaik = luas;
                        terbaik = g;
                    }
                }
            }
            for (int i = 0; i < g.getChildCount(); i++) {
                tumpukan.add(g.getChildAt(i));
            }
        }
        return terbaik;
    }

    private static int jumlahTombol(ViewGroup g) {
        int n = 0;
        ArrayList<View> tumpukan = new ArrayList<View>();
        tumpukan.add(g);
        int diperiksa = 0;
        while (!tumpukan.isEmpty() && diperiksa < 200) {
            View v = tumpukan.remove(tumpukan.size() - 1);
            diperiksa++;
            if (v != g && v.getVisibility() == View.VISIBLE && (v.isClickable() || v.isFocusable())) {
                n++;
                if (n >= 2) {
                    return n;
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) v;
                for (int i = 0; i < vg.getChildCount(); i++) {
                    tumpukan.add(vg.getChildAt(i));
                }
            }
        }
        return n;
    }
}
