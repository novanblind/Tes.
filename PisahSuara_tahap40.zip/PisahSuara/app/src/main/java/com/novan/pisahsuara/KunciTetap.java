package com.novan.pisahsuara;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPublicKeySpec;

/**
 * Kunci ADB tetap (RSA 2048, PKCS#8). Karena kuncinya selalu sama, HP mengenali aplikasi ini lagi
 * setelah dihapus lalu dipasang ulang: kode pairing 6 angka cukup dimasukkan SEKALI seumur HP.
 */
final class KunciTetap {
    private KunciTetap() {}

    static final String PKCS8_BASE64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDAqYlTeAqsFeZm" +
        "T9cUT7G8XCC9k+c+ieIM92qYyRXCw0CL677dlMRCXDyPEbMGxFpUwUvDfXD8+lXg" +
        "yul3zAjEtph2XsPBG6di+PYeoidMJkxBRZCLQwkgv7gVAnpCnxu6KJiUVruH03ET" +
        "WE+x4upcJ6Tf2cj+c1eConYVX8Q9iIGVjUleE+VO15lUVwxUtbgsZJTY+p1zv5C3" +
        "WE44+BYhxLvc1QU9Mhumu11Z7HjqLAdoh6DYr4+MzkEDdg8QWpRI1fxa7xp+o58n" +
        "GW/M3sAnOSv7hhqVjztCWLWxqMvxWH6g+zPWV0pe2XJydqNlCScq/S2NyNcRd6Dr" +
        "ChDTaZZpAgMBAAECggEAA7fp8npXQ2O/UQNyuF3C5YqmJ56IiKaW3i7yx9zeroX/" +
        "84ti4UovIQRAd3btHIDy6N6bsJvVz84hlO95otIla62GAwfYcZxP5ls9fdEdnszA" +
        "7UQTUnrCXPdSTVaBR1KkkXrZ2ggUAb65GJlcXWeupAVwW1Er3cxaWKc7zfUNl63n" +
        "lgTasv/ZpY/lpLm4sgLRCrbF0EV3/pBrI2CVBDzMQ94A2zEDNtj3bzKK3eHnSU2b" +
        "MYlbzHpgE/FWKT/rd6rYDb7ljAP1JuTd6ALLOvsxRr0t2Jqn3TACRY9h5syP6vei" +
        "L6Xru3TLJfkiqlwjr7fgvi/IeK4U8+JE5lnA9iyhYQKBgQDj67fO8nD5nwEIwxkp" +
        "FdTIQJFvQvCT27sdvQ9sgntOV7kpntL1XbZaxUwgYLPPbvjtDp8APEuXjzS/cT12" +
        "vaNlIMWtO/4UkQhLQDZC5tt6tOwzdXjhn1XmB6DNvbFp3rPWwjibiZwa7FV+Zs3C" +
        "vQnmYdhItrPWiYFa4ciw4QFMoQKBgQDYZdEvDyilhn2l3pui438YcaSkTLDn9wHa" +
        "XXzke0zWobCNES35iXsjyqUWLh4J54A2/GsnFSHm3/D4B1a7kntVMB5q0NFDsAZ7" +
        "36l4Yq0geSprpwQLoe2lkJo2fqmYdachGKXUNQvRNJOpQ0fsMjEzdyUdaoN0qQIU" +
        "1K2qvsDsyQKBgQCrNnRiek8RxTcSrPRmn6azM4XMzb1JZSO/6DkA61fTdyR6NnwE" +
        "o/wLXfCc1efdKGDIO1aH58NlO8eFFHz2iOiIXEECrHFmY7iWRss8II25NNXGpjVD" +
        "T91IKmzKgPgYLppr9oRtmsbwlp52kKV652Tbcp71qIGZ5LuOWNPYw32lYQKBgFB9" +
        "ps5jTBItsWTWJXv0NN0pwDzgzdiqdwT7Sy5NcqpPIDWIk1pDOgt5H+jdJI04j+dk" +
        "ApNZ9+9Bkwce67L/bGKmcFn47C3KNs8yxX2i7pSqnQ3H5OhSxeuUmtf0Sy8LbCwS" +
        "V/RT+t5JOTd3cDQ6AzUKd0K20Mi+6KhI54QgSfCJAoGASGIMxNYbv3WdZ0kmgt9I" +
        "LIg5PCUd3E6j8SZK6WMuM4ljlsp3G7Cy4EnkXS4dihpGkKJIJlXSssOEudpWfgvs" +
        "2Vcc0UNBMF6npJA2ihjOslTpafH7Hc5YHql4LAHfVxj0gglbmrE+AECnUlhfcK8d" +
        "nWIavc0y6SO5xDlc6WCWJ5w=";

    static byte[] der() {
        return android.util.Base64.decode(PKCS8_BASE64, android.util.Base64.DEFAULT);
    }

    static PrivateKey privat() throws Exception {
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der()));
    }

    static PublicKey publik(PrivateKey p) throws Exception {
        RSAPrivateCrtKey k = (RSAPrivateCrtKey) p;
        return KeyFactory.getInstance("RSA").generatePublic(new RSAPublicKeySpec(k.getModulus(), k.getPublicExponent()));
    }
}
