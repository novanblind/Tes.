package com.novan.audiolabnovan.videolab;

import android.net.Uri;

/** Gambar tempel (logo, watermark, foto) yang muncul di waktu tertentu pada garis waktu hasil akhir. */
public class ImageItem {
    public final Uri uri;
    public final String name;
    public long startMs;
    public long endMs;
    public int anchor = 2;
    public int size = 1;
    public int opacity = 3;
    public int anim = 0;

    public ImageItem(Uri uri, String name, long startMs, long endMs) {
        this.uri = uri;
        this.name = name;
        this.startMs = startMs;
        this.endMs = endMs;
    }
}
