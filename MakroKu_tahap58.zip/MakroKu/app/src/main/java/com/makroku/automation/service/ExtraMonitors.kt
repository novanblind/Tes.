package com.makroku.automation.service

import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Context
import android.content.SyncStatusObserver
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import com.makroku.automation.engine.MacroEngine
import com.makroku.automation.model.CalendarEventTrigger
import com.makroku.automation.model.CellSignalTrigger
import com.makroku.automation.model.ClipboardChangedTrigger
import com.makroku.automation.model.FlipTrigger
import com.makroku.automation.model.MusicTrackTrigger
import com.makroku.automation.model.SensorValueTrigger
import com.makroku.automation.model.WifiNearbyTrigger
import com.makroku.automation.model.FloatingButtonTrigger
import com.makroku.automation.model.GeofenceTrigger
import com.makroku.automation.model.ProximityTrigger
import com.makroku.automation.model.LightSensorTrigger
import com.makroku.automation.model.OrientationTrigger
import com.makroku.automation.model.VpnStateTrigger
import com.makroku.automation.model.InternetStateTrigger
import com.makroku.automation.model.BrightnessChangedTrigger
import com.makroku.automation.model.VolumeKeyTrigger
import com.makroku.automation.model.WebhookTrigger
import com.makroku.automation.model.Macro
import com.makroku.automation.model.MobileDataTrigger
import com.makroku.automation.model.ShakeTrigger
import com.makroku.automation.model.SyncStateTrigger
import com.makroku.automation.model.TriggerEvent
import com.makroku.automation.model.WifiNetworkTrigger
import com.makroku.automation.model.ShellOutputTrigger
import com.makroku.automation.model.SettingChangedTrigger
import com.makroku.automation.model.MicActiveTrigger
import com.makroku.automation.model.CameraActiveTrigger
import com.makroku.automation.model.NewMediaTrigger
import com.makroku.automation.model.ScreenTextTrigger
import com.makroku.automation.model.AdbStateTrigger
import com.makroku.automation.model.ScreenDurationTrigger
import com.makroku.automation.model.TorchStateTrigger
import com.makroku.automation.model.ScreenReaderStateTrigger
import com.makroku.automation.model.FreeFallTrigger
import com.makroku.automation.model.NetworkTypeTrigger
import kotlin.math.abs
import kotlin.math.sqrt

/** Pemantau sensor/jaringan/lokasi; hanya menyala bila ada makro aktif yang memakai pemicunya. */
class ExtraMonitors(private val ctx: Context, private val engine: MacroEngine) {
    private val main = Handler(Looper.getMainLooper())
    private var wifiCb: ConnectivityManager.NetworkCallback? = null
    private var shakeL: SensorEventListener? = null
    private var locL: LocationListener? = null
    @Volatile private var lastSsid = ""
    private var cellCb: ConnectivityManager.NetworkCallback? = null
    private var syncH: Any? = null
    @Volatile private var lastSync: Boolean? = null
    private val floating = FloatingButtons(ctx, engine)
    private val adbWatch = AdbWatchers(ctx, engine)
    private var hookServer: java.net.ServerSocket? = null
    private var proxL: SensorEventListener? = null
    private var flipL: SensorEventListener? = null
    private var lightL: SensorEventListener? = null
    private var orientL: android.view.OrientationEventListener? = null
    private var vpnCb: ConnectivityManager.NetworkCallback? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var brightObs: android.database.ContentObserver? = null
    private val vpnNets = java.util.concurrent.CopyOnWriteArraySet<Network>()
    @Volatile private var lastVpn: Boolean? = null
    @Volatile private var lastNet: Boolean? = null
    @Volatile private var vpnSince = 0L
    @Volatile private var netSince = 0L

    fun update(macros: List<Macro>) {
        val trig = macros.filter { it.enabled }.flatMap { it.triggers }
        runCatching { setWifi(trig.any { it is WifiNetworkTrigger }) }
        runCatching { setShake(trig.any { it is ShakeTrigger }) }
        runCatching { setLocation(trig.any { it is GeofenceTrigger }) }
        runCatching { setCell(trig.any { it is MobileDataTrigger }) }
        runCatching { setSync(trig.any { it is SyncStateTrigger }) }
        runCatching { setWebhook(trig.any { it is WebhookTrigger }) }
        runCatching { setProximity(trig.any { it is ProximityTrigger }) }
        runCatching { setFlip(trig.any { it is FlipTrigger }) }
        runCatching { setLight(trig.any { it is LightSensorTrigger }) }
        runCatching { setOrientation(trig.any { it is OrientationTrigger }) }
        runCatching { setVpn(trig.any { it is VpnStateTrigger }) }
        runCatching { setInternet(trig.any { it is InternetStateTrigger }) }
        runCatching { setBrightness(trig.any { it is BrightnessChangedTrigger }) }
        runCatching { setShellOutput(trig.filterIsInstance<ShellOutputTrigger>()) }
        runCatching { setSettings(trig.filterIsInstance<SettingChangedTrigger>()) }
        runCatching { setMic(trig.any { it is MicActiveTrigger }) }
        runCatching { setCamera(trig.any { it is CameraActiveTrigger }) }
        runCatching { setMedia(trig.any { it is NewMediaTrigger }) }
        runCatching { setScreenText(trig.filterIsInstance<ScreenTextTrigger>()) }
        runCatching { setAdbState(trig.any { it is AdbStateTrigger }) }
        runCatching { setScreenDuration(trig.filterIsInstance<ScreenDurationTrigger>()) }
        runCatching { setTorch(trig.any { it is TorchStateTrigger }) }
        runCatching { setScreenReader(trig.any { it is ScreenReaderStateTrigger }) }
        runCatching { setFreeFall(trig.any { it is FreeFallTrigger }) }
        runCatching { setNetType(trig.any { it is NetworkTypeTrigger }) }
        runCatching { setClipboard(trig.any { it is ClipboardChangedTrigger }) }
        runCatching { setCalendar(trig.any { it is CalendarEventTrigger }) }
        runCatching { setCellSignal(trig.any { it is CellSignalTrigger }) }
        runCatching { setWifiNearby(trig.filterIsInstance<WifiNearbyTrigger>().map { it.ssid.trim() }.toSet()) }
        runCatching { setMusicTrack(trig.any { it is MusicTrackTrigger }) }
        runCatching { setSensorValues(trig.filterIsInstance<SensorValueTrigger>().map { it.sensorKind }.toSet()) }
        runCatching { adbWatch.update(trig) }
        runCatching { MacroWidget.refresh(ctx) }
        runCatching {
            floating.update(trig.filterIsInstance<FloatingButtonTrigger>().map { it.label }.filter { it.isNotBlank() }.distinct().take(3).toSet())
        }
        val keys = trig.filterIsInstance<VolumeKeyTrigger>()
        MacroAccessibilityService.wantedKeys = keys.map { it.volKey }.toSet()
        MacroAccessibilityService.blockedKeys = keys.filter { it.block }.map { it.volKey }.toSet()
    }

    fun stop() {
        runCatching { setWifi(false) }
        runCatching { setShake(false) }
        runCatching { setLocation(false) }
        runCatching { setCell(false) }
        runCatching { setSync(false) }
        runCatching { floating.removeAll() }
        runCatching { setWebhook(false) }
        runCatching { setProximity(false) }
        runCatching { setFlip(false) }
        runCatching { setLight(false) }
        runCatching { setOrientation(false) }
        runCatching { setVpn(false) }
        runCatching { setInternet(false) }
        runCatching { setBrightness(false) }
        runCatching { setShellOutput(emptyList()) }
        runCatching { setSettings(emptyList()) }
        runCatching { setMic(false) }
        runCatching { setCamera(false) }
        runCatching { setMedia(false) }
        runCatching { setScreenText(emptyList()) }
        runCatching { setAdbState(false) }
        runCatching { setScreenDuration(emptyList()) }
        runCatching { setTorch(false) }
        runCatching { setScreenReader(false) }
        runCatching { setFreeFall(false) }
        runCatching { setNetType(false) }
        runCatching { setClipboard(false) }
        runCatching { setCalendar(false) }
        runCatching { setCellSignal(false) }
        runCatching { setWifiNearby(emptySet()) }
        runCatching { setMusicTrack(false) }
        runCatching { setSensorValues(emptySet()) }
        runCatching { adbWatch.stop() }
        MacroAccessibilityService.wantedKeys = emptySet()
        MacroAccessibilityService.blockedKeys = emptySet()
    }

    /** VPN tersambung atau terputus. Kejadian dalam 1,5 detik pertama setelah mendaftar hanya dicatat, tidak memicu. */
    private fun setVpn(on: Boolean) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        if (!on) {
            vpnCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
            vpnCb = null
            vpnNets.clear()
            lastVpn = null
            return
        }
        if (vpnCb != null) return
        vpnSince = System.currentTimeMillis()
        lastVpn = null
        fun beri(now: Boolean) {
            val prev = lastVpn
            lastVpn = now
            if (prev != null && prev != now && System.currentTimeMillis() - vpnSince > 1500) {
                engine.dispatch(TriggerEvent("vpn", mapOf("connected" to now.toString())))
            }
        }
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                vpnNets.add(network)
                beri(true)
            }

            override fun onLost(network: Network) {
                vpnNets.remove(network)
                beri(vpnNets.isNotEmpty())
            }
        }
        // Keadaan awal dianggap terputus; VPN yang sudah menyala dicatat lewat onAvailable pertama tanpa memicu.
        lastVpn = false
        cm.registerNetworkCallback(req, cb)
        vpnCb = cb
    }

    /** Internet tervalidasi pada jaringan utama tersedia atau hilang. */
    private fun setInternet(on: Boolean) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        if (!on) {
            netCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
            netCb = null
            lastNet = null
            return
        }
        if (netCb != null) return
        netSince = System.currentTimeMillis()
        val awal = cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        lastNet = awal
        fun beri(now: Boolean) {
            val prev = lastNet
            lastNet = now
            if (prev != null && prev != now && System.currentTimeMillis() - netSince > 1500) {
                engine.dispatch(TriggerEvent("internet", mapOf("connected" to now.toString())))
            }
        }
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                beri(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
            }

            override fun onLost(network: Network) {
                beri(false)
            }
        }
        cm.registerDefaultNetworkCallback(cb)
        netCb = cb
    }

    /** Kecerahan diubah: menunggu 0,8 detik tanpa perubahan baru supaya geseran panjang hanya memicu sekali. */
    private fun setBrightness(on: Boolean) {
        val cr = ctx.contentResolver
        if (!on) {
            brightObs?.let { runCatching { cr.unregisterContentObserver(it) } }
            brightObs = null
            return
        }
        if (brightObs != null) return
        val kirim = Runnable {
            val v = runCatching {
                android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS)
            }.getOrDefault(-1)
            engine.dispatch(TriggerEvent("brightness", mapOf("brightness" to (if (v >= 0) v * 100 / 255 else -1).toString())))
        }
        val obs = object : android.database.ContentObserver(main) {
            override fun onChange(selfChange: Boolean) {
                main.removeCallbacks(kirim)
                main.postDelayed(kirim, 800)
            }
        }
        cr.registerContentObserver(android.provider.Settings.System.getUriFor(android.provider.Settings.System.SCREEN_BRIGHTNESS), false, obs)
        brightObs = obs
    }

    private fun setWebhook(on: Boolean) {
        if (!on) {
            runCatching { hookServer?.close() }
            hookServer = null
            return
        }
        if (hookServer != null) return
        val server = java.net.ServerSocket(8765)
        hookServer = server
        Thread {
            while (!server.isClosed) {
                val s = try { server.accept() } catch (e: Exception) { break }
                Thread { runCatching { handleHook(s) } }.start()
            }
        }.apply { isDaemon = true; name = "makroku-webhook" }.start()
    }

    private fun handleHook(s: java.net.Socket) {
        s.use { sock ->
            sock.soTimeout = 5000
            val line = sock.getInputStream().bufferedReader().readLine().orEmpty()
            val target = line.split(" ").getOrNull(1).orEmpty()
            val path = target.substringBefore("?")
            val params = target.substringAfter("?", "").split("&").filter { it.contains("=") }.associate {
                val k = java.net.URLDecoder.decode(it.substringBefore("="), "UTF-8")
                val v = java.net.URLDecoder.decode(it.substringAfter("="), "UTF-8")
                k to v
            }
            val data = HashMap<String, String>()
            data["hook"] = path
            data["token"] = params["token"].orEmpty()
            data["loopback"] = sock.inetAddress.isLoopbackAddress.toString()
            params.forEach { (k, v) ->
                val key = k.filter { it.isLetterOrDigit() || it == '_' }
                if (key.isNotEmpty() && key != "token") data["wh_$key"] = v
            }
            engine.dispatch(TriggerEvent("webhook", data))
            val body = "OK"
            val out = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: ${body.length}\r\nConnection: close\r\n\r\n$body"
            sock.getOutputStream().write(out.toByteArray())
            sock.getOutputStream().flush()
        }
    }

    private fun setLight(on: Boolean) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        if (!on) {
            lightL?.let { sm.unregisterListener(it) }
            lightL = null
            return
        }
        if (lightL != null) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT) ?: return
        val l = object : SensorEventListener {
            private var last = -1f
            private var lastAt = 0L
            override fun onSensorChanged(e: SensorEvent) {
                val lux = e.values[0]
                val now = android.os.SystemClock.elapsedRealtime()
                if (last < 0f) { last = lux; lastAt = now; return }
                if (now - lastAt < 1000L) return
                val prev = last
                last = lux
                lastAt = now
                if (lux != prev) engine.dispatch(TriggerEvent("light", mapOf("lux" to lux.toString(), "prev" to prev.toString())))
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        lightL = l
    }

    private fun setOrientation(on: Boolean) {
        if (!on) {
            orientL?.disable()
            orientL = null
            return
        }
        if (orientL != null) return
        val l = object : android.view.OrientationEventListener(ctx) {
            private var landscape: Boolean? = null
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == android.view.OrientationEventListener.ORIENTATION_UNKNOWN) return
                val now: Boolean = when {
                    orientation in 60..120 || orientation in 240..300 -> true
                    orientation <= 30 || orientation >= 330 || orientation in 150..210 -> false
                    else -> return
                }
                val prev = landscape
                landscape = now
                if (prev != null && prev != now) engine.dispatch(TriggerEvent("orientation", mapOf("landscape" to now.toString())))
            }
        }
        if (l.canDetectOrientation()) {
            l.enable()
            orientL = l
        }
    }

    private fun setProximity(on: Boolean) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        if (!on) {
            proxL?.let { sm.unregisterListener(it) }
            proxL = null
            return
        }
        if (proxL != null) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        val l = object : SensorEventListener {
            private var last: Boolean? = null
            override fun onSensorChanged(e: SensorEvent) {
                val near = e.values[0] < minOf(sensor.maximumRange, 5f)
                if (last == null) { last = near; return }
                if (last != near) {
                    last = near
                    engine.dispatch(TriggerEvent("proximity", mapOf("near" to near.toString())))
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        proxL = l
    }

    private fun setFlip(on: Boolean) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        if (!on) {
            flipL?.let { sm.unregisterListener(it) }
            flipL = null
            return
        }
        if (flipL != null) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        val l = object : SensorEventListener {
            private var down: Boolean? = null
            override fun onSensorChanged(e: SensorEvent) {
                val z = e.values[2]
                val now = when {
                    z < -7f -> true
                    z > 5f -> false
                    else -> return
                }
                if (down == null) { down = now; return }
                if (down != now) {
                    down = now
                    engine.dispatch(TriggerEvent("flip", mapOf("down" to now.toString())))
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        flipL = l
    }

    private fun setCell(on: Boolean) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        if (!on) {
            cellCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
            cellCb = null
            return
        }
        if (cellCb != null) return
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                engine.dispatch(TriggerEvent("cell_net", mapOf("connected" to "true")))
            }

            override fun onLost(network: Network) {
                engine.dispatch(TriggerEvent("cell_net", mapOf("connected" to "false")))
            }
        }
        cm.registerNetworkCallback(req, cb)
        cellCb = cb
    }

    private fun setSync(on: Boolean) {
        if (!on) {
            syncH?.let { ContentResolver.removeStatusChangeListener(it) }
            syncH = null
            lastSync = null
            return
        }
        if (syncH != null) return
        lastSync = ContentResolver.getMasterSyncAutomatically()
        syncH = ContentResolver.addStatusChangeListener(
            ContentResolver.SYNC_OBSERVER_TYPE_SETTINGS,
            SyncStatusObserver {
                val now = ContentResolver.getMasterSyncAutomatically()
                if (lastSync != now) {
                    lastSync = now
                    engine.dispatch(TriggerEvent("sync", mapOf("on" to now.toString())))
                }
            },
        )
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String {
        val s = ctx.applicationContext.getSystemService(WifiManager::class.java)?.connectionInfo?.ssid.orEmpty()
        return if (s.contains("unknown ssid")) "" else s.trim('"')
    }

    private fun setWifi(on: Boolean) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        if (!on) {
            wifiCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
            wifiCb = null
            return
        }
        if (wifiCb != null) return
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                main.postDelayed({
                    lastSsid = currentSsid()
                    engine.dispatch(TriggerEvent("wifi_net", mapOf("connected" to "true", "wifi_ssid" to lastSsid)))
                }, 1500)
            }

            override fun onLost(network: Network) {
                engine.dispatch(TriggerEvent("wifi_net", mapOf("connected" to "false", "wifi_ssid" to lastSsid)))
            }
        }
        cm.registerNetworkCallback(req, cb)
        wifiCb = cb
    }

    private fun setShake(on: Boolean) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        if (!on) {
            shakeL?.let { sm.unregisterListener(it) }
            shakeL = null
            return
        }
        if (shakeL != null) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        val l = object : SensorEventListener {
            private var last = 0L
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]
                val y = e.values[1]
                val z = e.values[2]
                val g = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                val force = abs(g - SensorManager.GRAVITY_EARTH)
                val now = System.currentTimeMillis()
                if (force > 6f && now - last > 1500) {
                    last = now
                    engine.dispatch(TriggerEvent("shake", mapOf("force" to force.toString())))
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        shakeL = l
    }

    @SuppressLint("MissingPermission")
    private fun setLocation(on: Boolean) {
        val lm = ctx.getSystemService(LocationManager::class.java)
        if (!on) {
            locL?.let { lm.removeUpdates(it) }
            locL = null
            return
        }
        if (locL != null) return
        val fine = ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> return
        }
        val l = LocationListener { loc ->
            engine.dispatch(
                TriggerEvent("location", mapOf("lat" to loc.latitude.toString(), "lon" to loc.longitude.toString())),
            )
        }
        lm.requestLocationUpdates(provider, 60_000L, 30f, l, Looper.getMainLooper())
        locL = l
    }
    // ───────────── Tahap 36: pemantau tambahan ─────────────

    private class ShellPoll(var interval: Int, var prev: String? = null, var last: Long = 0L)

    private val shellPolls = java.util.concurrent.ConcurrentHashMap<String, ShellPoll>()
    private var shellThread: Thread? = null
    @Volatile private var shellOn = false

    /** Menjalankan tiap perintah shell milik pemicu sesuai jedanya; memicu hanya mulai dari bacaan kedua. */
    private fun setShellOutput(list: List<ShellOutputTrigger>) {
        val wanted = list.filter { it.command.isNotBlank() }.groupBy { it.command.trim() }
        if (wanted.isEmpty()) {
            shellOn = false
            shellThread?.interrupt()
            shellThread = null
            shellPolls.clear()
            return
        }
        shellPolls.keys.retainAll(wanted.keys)
        wanted.forEach { (cmd, ts) ->
            val iv = ts.minOf { it.everySeconds }.coerceIn(10, 3600)
            val p = shellPolls.getOrPut(cmd) { ShellPoll(iv) }
            p.interval = iv
        }
        if (shellOn) return
        shellOn = true
        val th = Thread {
            while (shellOn) {
                try {
                    val now = System.currentTimeMillis()
                    for ((cmd, p) in shellPolls) {
                        if (now - p.last < p.interval * 1000L) continue
                        p.last = now
                        if (!com.makroku.automation.adb.AdbBackend.dipasangkan(ctx)) continue
                        val out = try {
                            com.makroku.automation.adb.AdbBackend.shell(ctx, cmd, 15).take(4000)
                        } catch (e: Exception) {
                            continue
                        }
                        val before = p.prev
                        p.prev = out
                        if (before != null) {
                            engine.dispatch(
                                TriggerEvent("shell_output", mapOf("shell_cmd" to cmd, "shell_out" to out, "shell_prev" to before)),
                            )
                        }
                    }
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                }
            }
        }
        th.isDaemon = true
        th.name = "makroku-shell-poll"
        th.start()
        shellThread = th
    }

    private val settingObs = HashMap<String, android.database.ContentObserver>()

    /** Mengamati pengaturan sistem tertentu lewat ContentObserver. */
    private fun setSettings(list: List<SettingChangedTrigger>) {
        val cr = ctx.contentResolver
        val wanted = list.filter { it.key.isNotBlank() }.map { it.ns.trim() to it.key.trim() }.toSet()
        val ids = wanted.map { it.first + ":" + it.second }.toSet()
        settingObs.keys.filter { it !in ids }.forEach { k ->
            settingObs.remove(k)?.let { runCatching { cr.unregisterContentObserver(it) } }
        }
        for ((ns, key) in wanted) {
            val id = "$ns:$key"
            if (settingObs.containsKey(id)) continue
            val uri = when (ns) {
                "system" -> android.provider.Settings.System.getUriFor(key)
                "secure" -> android.provider.Settings.Secure.getUriFor(key)
                else -> android.provider.Settings.Global.getUriFor(key)
            }
            val obs = object : android.database.ContentObserver(main) {
                override fun onChange(selfChange: Boolean) {
                    val v = runCatching {
                        when (ns) {
                            "system" -> android.provider.Settings.System.getString(cr, key)
                            "secure" -> android.provider.Settings.Secure.getString(cr, key)
                            else -> android.provider.Settings.Global.getString(cr, key)
                        }
                    }.getOrNull().orEmpty()
                    engine.dispatch(
                        TriggerEvent("setting_changed", mapOf("setting_ns" to ns, "setting_key" to key, "setting_value" to v)),
                    )
                }
            }
            runCatching {
                cr.registerContentObserver(uri, false, obs)
                settingObs[id] = obs
            }
        }
    }

    private var micCb: android.media.AudioManager.AudioRecordingCallback? = null
    @Volatile private var lastMic: Boolean? = null

    /** Mikrofon dipakai atau tidak, dari daftar rekaman aktif sistem. */
    private fun setMic(on: Boolean) {
        val am = ctx.getSystemService(android.media.AudioManager::class.java)
        if (!on) {
            micCb?.let { runCatching { am.unregisterAudioRecordingCallback(it) } }
            micCb = null
            lastMic = null
            return
        }
        if (micCb != null) return
        lastMic = null
        val cb = object : android.media.AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<android.media.AudioRecordingConfiguration>?) {
                val now = !configs.isNullOrEmpty()
                val prev = lastMic
                lastMic = now
                if (prev != null && prev != now) engine.dispatch(TriggerEvent("mic_active", mapOf("active" to now.toString())))
            }
        }
        am.registerAudioRecordingCallback(cb, main)
        micCb = cb
    }


    // ───────────── Layar menyala atau mati terus-menerus (alarm, tetap jalan saat HP tidur) ─────────────
    private val sdAction = "com.makroku.automation.SCREEN_DURATION"
    private var sdRecv: android.content.BroadcastReceiver? = null
    private var sdTriggers: List<ScreenDurationTrigger> = emptyList()
    private val sdPending = mutableListOf<android.app.PendingIntent>()
    @Volatile private var sdSince = 0L

    private fun sdCancel() {
        val am = ctx.getSystemService(android.app.AlarmManager::class.java)
        sdPending.forEach { runCatching { am.cancel(it) } }
        sdPending.clear()
    }

    /** Pasang alarm untuk tiap lama menit yang dipakai makro, dihitung sejak layar berubah keadaan. */
    private fun sdSchedule(on: Boolean) {
        sdCancel()
        val am = ctx.getSystemService(android.app.AlarmManager::class.java)
        val now = System.currentTimeMillis()
        val daftar = sdTriggers.filter { it.screenOn == on }.map { it.afterMinutes.coerceIn(1, 1440) }.distinct()
        for (m in daftar) {
            val at = sdSince + m * 60_000L
            if (at <= now) continue
            val i = android.content.Intent(sdAction).setPackage(ctx.packageName)
                .putExtra("on", on).putExtra("minutes", m)
            val pi = android.app.PendingIntent.getBroadcast(
                ctx, (if (on) 7000 else 9000) + m, i,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
            )
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
            }
            sdPending.add(pi)
        }
    }

    private fun setScreenDuration(list: List<ScreenDurationTrigger>) {
        sdTriggers = list
        if (list.isEmpty()) {
            sdRecv?.let { runCatching { ctx.unregisterReceiver(it) } }
            sdRecv = null
            sdCancel()
            return
        }
        val pm = ctx.getSystemService(android.os.PowerManager::class.java)
        if (sdRecv == null) {
            sdSince = System.currentTimeMillis()
            val r = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context, i: android.content.Intent) {
                    when (i.action) {
                        android.content.Intent.ACTION_SCREEN_ON -> { sdSince = System.currentTimeMillis(); sdSchedule(true) }
                        android.content.Intent.ACTION_SCREEN_OFF -> { sdSince = System.currentTimeMillis(); sdSchedule(false) }
                        sdAction -> {
                            val on = i.getBooleanExtra("on", true)
                            val m = i.getIntExtra("minutes", 0)
                            val sekarang = c.getSystemService(android.os.PowerManager::class.java).isInteractive
                            if (m > 0 && sekarang == on) {
                                engine.dispatch(TriggerEvent("screen_duration", mapOf("on" to on.toString(), "minutes" to m.toString())))
                            }
                        }
                    }
                }
            }
            val f = android.content.IntentFilter().apply {
                addAction(android.content.Intent.ACTION_SCREEN_ON)
                addAction(android.content.Intent.ACTION_SCREEN_OFF)
                addAction(sdAction)
            }
            androidx.core.content.ContextCompat.registerReceiver(ctx, r, f, androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
            sdRecv = r
        }
        sdSchedule(pm.isInteractive)
    }


    // ───────────── Tahap 41: senter, pembaca layar, jatuh bebas, jenis jaringan ─────────────
    private var torchCb: android.hardware.camera2.CameraManager.TorchCallback? = null
    @Volatile private var lastTorch: Boolean? = null

    private fun setTorch(on: Boolean) {
        val cm = ctx.getSystemService(android.hardware.camera2.CameraManager::class.java)
        if (!on) {
            torchCb?.let { runCatching { cm.unregisterTorchCallback(it) } }
            torchCb = null
            lastTorch = null
            return
        }
        if (torchCb != null) return
        lastTorch = null
        val cb = object : android.hardware.camera2.CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                val prev = lastTorch
                lastTorch = enabled
                if (prev != null && prev != enabled) engine.dispatch(TriggerEvent("torch", mapOf("on" to enabled.toString())))
            }
        }
        cm.registerTorchCallback(cb, main)
        torchCb = cb
    }

    // ───────────── Tahap 49: acara Kalender dan sinyal seluler ─────────────
    private var calExec: java.util.concurrent.ScheduledExecutorService? = null
    @Volatile private var calPrev: Map<String, Pair<String, String>>? = null

    /** Acara Kalender mulai atau selesai. Acara yang sedang berlangsung saat pemantauan mulai hanya menjadi acuan. */
    private fun setCalendar(on: Boolean) {
        if (!on) {
            calExec?.shutdownNow()
            calExec = null
            calPrev = null
            return
        }
        if (calExec != null) return
        val ex = java.util.concurrent.Executors.newSingleThreadScheduledExecutor()
        ex.scheduleWithFixedDelay(Runnable { runCatching { cekKalender() } }, 3, 30, java.util.concurrent.TimeUnit.SECONDS)
        calExec = ex
    }

    private fun cekKalender() {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return
        val now = System.currentTimeMillis()
        val sekarang = HashMap<String, Pair<String, String>>()
        val c = android.provider.CalendarContract.Instances.query(
            ctx.contentResolver,
            arrayOf(
                android.provider.CalendarContract.Instances.EVENT_ID,
                android.provider.CalendarContract.Instances.TITLE,
                android.provider.CalendarContract.Instances.BEGIN,
                android.provider.CalendarContract.Instances.EVENT_LOCATION,
                android.provider.CalendarContract.Instances.ALL_DAY,
            ),
            now, now + 1,
        ) ?: return
        c.use {
            while (it.moveToNext()) {
                if (it.getInt(4) == 1) continue
                sekarang[it.getLong(0).toString() + "|" + it.getLong(2)] = Pair(it.getString(1).orEmpty(), it.getString(3).orEmpty())
            }
        }
        val sebelum = calPrev
        calPrev = sekarang
        if (sebelum == null) return
        for ((k, v) in sekarang) {
            if (k !in sebelum) engine.dispatch(TriggerEvent("calendar", mapOf("cal_start" to "true", "cal_title" to v.first, "cal_location" to v.second)))
        }
        for ((k, v) in sebelum) {
            if (k !in sekarang) engine.dispatch(TriggerEvent("calendar", mapOf("cal_start" to "false", "cal_title" to v.first, "cal_location" to v.second)))
        }
    }

    private var cellRun: Runnable? = null
    @Volatile private var lastCellLevel = -1

    /** Kekuatan sinyal seluler (0 sampai 4), dicek tiap 20 detik. */
    private fun setCellSignal(on: Boolean) {
        if (!on) {
            cellRun?.let { main.removeCallbacks(it) }
            cellRun = null
            lastCellLevel = -1
            return
        }
        if (cellRun != null) return
        val r = object : Runnable {
            override fun run() {
                if (cellRun == null) return
                runCatching {
                    if (ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        val lv = ctx.getSystemService(android.telephony.TelephonyManager::class.java).signalStrength?.level
                        if (lv != null) {
                            val prev = lastCellLevel
                            lastCellLevel = lv
                            if (prev >= 0 && prev != lv) {
                                engine.dispatch(TriggerEvent("cell_signal", mapOf("level" to lv.toString(), "prev" to prev.toString(), "signal_level" to lv.toString())))
                            }
                        }
                    }
                }
                main.postDelayed(this, 20_000L)
            }
        }
        cellRun = r
        main.postDelayed(r, 1000L)
    }

    // ───────────── Tahap 48: Wi-Fi terdeteksi di sekitar ─────────────
    private var nearRx: android.content.BroadcastReceiver? = null
    private val nearState = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    @Volatile private var nearNeedles: Set<String> = emptySet()
    private val nearScan = object : Runnable {
        override fun run() {
            if (nearRx == null) return
            runCatching { ctx.applicationContext.getSystemService(WifiManager::class.java).startScan() }
            main.postDelayed(this, 60_000L)
        }
    }

    /** Jaringan Wi-Fi muncul atau menghilang dari hasil pindai. Nama kosong = jaringan apa pun. Pindai dipicu tiap menit, tapi Android membatasi pindai dari latar belakang. */
    private fun setWifiNearby(needles: Set<String>) {
        nearNeedles = needles
        nearState.keys.retainAll(needles)
        if (needles.isEmpty()) {
            nearRx?.let { runCatching { ctx.unregisterReceiver(it) } }
            nearRx = null
            main.removeCallbacks(nearScan)
            return
        }
        if (nearRx != null) return
        val rx = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: Context, i: android.content.Intent) {
                if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
                val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
                val names = runCatching { wm.scanResults.map { it.SSID.orEmpty() }.filter { it.isNotEmpty() } }.getOrNull() ?: return
                for (n in nearNeedles) {
                    val ada = if (n.isEmpty()) names.isNotEmpty() else names.any { it.equals(n, ignoreCase = true) }
                    val sebelum = nearState.put(n, ada)
                    if (sebelum != null && sebelum != ada) {
                        engine.dispatch(TriggerEvent("wifi_nearby", mapOf("needle" to n, "appear" to ada.toString(), "wifi_ssid" to n)))
                    }
                }
            }
        }
        val f = android.content.IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (android.os.Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else ctx.registerReceiver(rx, f)
        nearRx = rx
        main.postDelayed(nearScan, 5_000L)
    }

    // ───────────── Tahap 47: papan klip, lagu berganti, sensor lain ─────────────
    private var clipL: android.content.ClipboardManager.OnPrimaryClipChangedListener? = null
    @Volatile private var lastClipAt = 0L

    /** Papan klip berubah. Isi salinan hanya terbaca bila Android mengizinkan (aplikasi di depan, atau appop READ_CLIPBOARD diizinkan lewat ADB). */
    private fun setClipboard(on: Boolean) {
        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
        if (!on) {
            clipL?.let { runCatching { cm.removePrimaryClipChangedListener(it) } }
            clipL = null
            return
        }
        if (clipL != null) return
        val l = android.content.ClipboardManager.OnPrimaryClipChangedListener {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastClipAt >= 500L) {
                lastClipAt = now
                val teks = runCatching { cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() }.getOrNull().orEmpty()
                engine.dispatch(TriggerEvent("clipboard", mapOf("clip_text" to teks)))
            }
        }
        cm.addPrimaryClipChangedListener(l)
        clipL = l
    }

    private var sessL: android.media.session.MediaSessionManager.OnActiveSessionsChangedListener? = null
    private val sessCtl = mutableListOf<Pair<android.media.session.MediaController, android.media.session.MediaController.Callback>>()
    @Volatile private var lastTrack = ""

    private fun clearTrackCtl() {
        sessCtl.forEach { (c, cb) -> runCatching { c.unregisterCallback(cb) } }
        sessCtl.clear()
    }

    private fun attachControllers(list: List<android.media.session.MediaController>?) {
        clearTrackCtl()
        list.orEmpty().forEach { c ->
            if (lastTrack.isEmpty()) {
                val m0 = c.metadata
                val t0 = m0?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                if (t0.isNotEmpty()) {
                    lastTrack = c.packageName + "|" + t0 + "|" + m0?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                }
            }
            val cb = object : android.media.session.MediaController.Callback() {
                override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
                    val m = metadata ?: return
                    val title = m.getString(android.media.MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                    if (title.isEmpty()) return
                    val artist = (m.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
                        ?: m.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty()
                    val album = m.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM).orEmpty()
                    val key = c.packageName + "|" + title + "|" + artist
                    if (key == lastTrack) return
                    lastTrack = key
                    engine.dispatch(
                        TriggerEvent(
                            "music_track",
                            mapOf("track_title" to title, "track_artist" to artist, "track_album" to album, "track_app" to c.packageName),
                        ),
                    )
                }
            }
            c.registerCallback(cb, main)
            sessCtl.add(c to cb)
        }
    }

    /** Lagu berganti, dibaca dari sesi media aktif. Butuh Akses Notifikasi untuk MakroKu. */
    private fun setMusicTrack(on: Boolean) {
        val msm = ctx.getSystemService(android.media.session.MediaSessionManager::class.java)
        val comp = android.content.ComponentName(ctx, MacroNotificationListener::class.java)
        if (!on) {
            sessL?.let { runCatching { msm.removeOnActiveSessionsChangedListener(it) } }
            sessL = null
            clearTrackCtl()
            lastTrack = ""
            return
        }
        if (sessL != null) return
        val l = android.media.session.MediaSessionManager.OnActiveSessionsChangedListener { list -> attachControllers(list) }
        msm.addOnActiveSessionsChangedListener(l, comp, main)
        sessL = l
        attachControllers(msm.getActiveSessions(comp))
    }

    private val sensorL = mutableMapOf<String, SensorEventListener>()

    /** Sensor tekanan, suhu sekitar, kelembapan, dan medan magnet. Satu pendengar untuk tiap jenis yang dipakai makro aktif. */
    private fun setSensorValues(kinds: Set<String>) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        sensorL.keys.filter { it !in kinds }.forEach { k -> sensorL.remove(k)?.let { sm.unregisterListener(it) } }
        kinds.filter { it !in sensorL }.forEach { k ->
            val type = when (k) {
                "pressure" -> Sensor.TYPE_PRESSURE
                "temperature" -> Sensor.TYPE_AMBIENT_TEMPERATURE
                "humidity" -> Sensor.TYPE_RELATIVE_HUMIDITY
                "magnetic" -> Sensor.TYPE_MAGNETIC_FIELD
                else -> return@forEach
            }
            val sensor = sm.getDefaultSensor(type) ?: return@forEach
            val l = object : SensorEventListener {
                private var last = Float.NaN
                private var lastAt = 0L
                override fun onSensorChanged(e: SensorEvent) {
                    val v = if (type == Sensor.TYPE_MAGNETIC_FIELD) {
                        sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
                    } else {
                        e.values[0]
                    }
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (last.isNaN()) { last = v; lastAt = now; return }
                    if (now - lastAt < 1000L) return
                    val prev = last
                    last = v
                    lastAt = now
                    if (v != prev) {
                        engine.dispatch(TriggerEvent("sensor_value", mapOf("sensor" to k, "sensor_value" to v.toString(), "prev" to prev.toString())))
                    }
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            sensorL[k] = l
        }
    }

    private var readerL: android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener? = null

    private fun setScreenReader(on: Boolean) {
        val am = ctx.getSystemService(android.view.accessibility.AccessibilityManager::class.java)
        if (!on) {
            readerL?.let { runCatching { am.removeTouchExplorationStateChangeListener(it) } }
            readerL = null
            return
        }
        if (readerL != null) return
        val l = android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener { aktif ->
            engine.dispatch(TriggerEvent("screen_reader", mapOf("on" to aktif.toString())))
        }
        am.addTouchExplorationStateChangeListener(l)
        readerL = l
    }

    private var fallL: SensorEventListener? = null

    /** Jatuh bebas: besar percepatan di bawah 2 m/s² selama minimal 150 milidetik; jeda 3 detik antar kejadian. */
    private fun setFreeFall(on: Boolean) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        if (!on) {
            fallL?.let { sm.unregisterListener(it) }
            fallL = null
            return
        }
        if (fallL != null) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        val l = object : SensorEventListener {
            private var since = 0L
            private var last = 0L
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]
                val y = e.values[1]
                val z = e.values[2]
                val g = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                val now = System.currentTimeMillis()
                if (g < 2f) {
                    if (since == 0L) since = now
                    else if (now - since >= 150 && now - last > 3000) {
                        last = now
                        since = 0L
                        engine.dispatch(TriggerEvent("free_fall"))
                    }
                } else {
                    since = 0L
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        fallL = l
    }

    private var ntCb: ConnectivityManager.NetworkCallback? = null
    @Volatile private var lastNt: String? = null
    @Volatile private var ntSince = 0L

    private fun jenisJaringan(c: NetworkCapabilities?): String = when {
        c == null -> "none"
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
        c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
        else -> "other"
    }

    /** Jenis jaringan utama berubah. Kejadian dalam 1,5 detik pertama setelah mendaftar hanya dicatat. */
    private fun setNetType(on: Boolean) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        if (!on) {
            ntCb?.let { runCatching { cm.unregisterNetworkCallback(it) } }
            ntCb = null
            lastNt = null
            return
        }
        if (ntCb != null) return
        ntSince = System.currentTimeMillis()
        lastNt = jenisJaringan(cm.getNetworkCapabilities(cm.activeNetwork))
        fun beri(now: String) {
            val prev = lastNt
            lastNt = now
            if (prev != null && prev != now && System.currentTimeMillis() - ntSince > 1500) {
                engine.dispatch(TriggerEvent("network_type", mapOf("net" to now)))
            }
        }
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                beri(jenisJaringan(caps))
            }

            override fun onLost(network: Network) {
                beri("none")
            }
        }
        cm.registerDefaultNetworkCallback(cb)
        ntCb = cb
    }

    private var camCb: android.hardware.camera2.CameraManager.AvailabilityCallback? = null
    private val camBusy = java.util.concurrent.CopyOnWriteArraySet<String>()
    @Volatile private var lastCam: Boolean? = null
    @Volatile private var camSince = 0L

    /** Kamera dipakai atau tidak, dari ketersediaan kamera. Kejadian 1,5 detik pertama hanya dicatat. */
    private fun setCamera(on: Boolean) {
        val cm = ctx.getSystemService(android.hardware.camera2.CameraManager::class.java)
        if (!on) {
            camCb?.let { runCatching { cm.unregisterAvailabilityCallback(it) } }
            camCb = null
            camBusy.clear()
            lastCam = null
            return
        }
        if (camCb != null) return
        camSince = System.currentTimeMillis()
        lastCam = null
        fun beri() {
            val now = camBusy.isNotEmpty()
            val prev = lastCam
            lastCam = now
            if (prev != null && prev != now && System.currentTimeMillis() - camSince > 1500) {
                engine.dispatch(TriggerEvent("camera_active", mapOf("active" to now.toString())))
            }
        }
        val cb = object : android.hardware.camera2.CameraManager.AvailabilityCallback() {
            override fun onCameraUnavailable(cameraId: String) {
                camBusy.add(cameraId)
                beri()
            }

            override fun onCameraAvailable(cameraId: String) {
                camBusy.remove(cameraId)
                beri()
            }
        }
        cm.registerAvailabilityCallback(cb, main)
        camCb = cb
    }

    private var mediaObs: android.database.ContentObserver? = null
    @Volatile private var lastMediaId = -1L

    /** Gambar baru di galeri (butuh izin membaca gambar). Menunggu 1 detik supaya berkas selesai ditulis. */
    private fun setMedia(on: Boolean) {
        val cr = ctx.contentResolver
        if (!on) {
            mediaObs?.let { runCatching { cr.unregisterContentObserver(it) } }
            mediaObs = null
            return
        }
        if (mediaObs != null) return
        val uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        fun terbaru(): Triple<Long, String, String>? = runCatching {
            val proj = arrayOf(
                android.provider.MediaStore.Images.Media._ID,
                android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                android.provider.MediaStore.Images.Media.RELATIVE_PATH,
            )
            cr.query(uri, proj, null, null, android.provider.MediaStore.Images.Media._ID + " DESC")?.use { c ->
                if (c.moveToFirst()) Triple(c.getLong(0), c.getString(1).orEmpty(), c.getString(2).orEmpty()) else null
            }
        }.getOrNull()
        lastMediaId = terbaru()?.first ?: -1L
        val kirim = Runnable {
            Thread {
                val n = terbaru() ?: return@Thread
                if (n.first <= lastMediaId) return@Thread
                lastMediaId = n.first
                val low = (n.second + " " + n.third).lowercase()
                val jenis = when {
                    "screenshot" in low || "tangkapan" in low -> "screenshot"
                    "dcim" in low -> "photo"
                    else -> "other"
                }
                engine.dispatch(TriggerEvent("new_media", mapOf("media_kind" to jenis, "media_name" to n.second, "media_path" to n.third)))
            }.start()
        }
        val obs = object : android.database.ContentObserver(main) {
            override fun onChange(selfChange: Boolean) {
                main.removeCallbacks(kirim)
                main.postDelayed(kirim, 1000)
            }
        }
        runCatching {
            cr.registerContentObserver(uri, true, obs)
            mediaObs = obs
        }
    }

    private var screenTextThread: Thread? = null
    @Volatile private var screenTextOn = false
    @Volatile private var screenNeedles: Set<String> = emptySet()
    private val screenPresent = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /** Memantau teks layar tiap 2 detik (hanya saat layar menyala dan Aksesibilitas aktif). Memicu saat tulisan baru muncul. */
    private fun setScreenText(list: List<ScreenTextTrigger>) {
        val needles = list.map { it.text.trim() }.filter { it.isNotEmpty() }.toSet()
        screenNeedles = needles
        screenPresent.keys.retainAll(needles)
        if (needles.isEmpty()) {
            screenTextOn = false
            screenTextThread?.interrupt()
            screenTextThread = null
            return
        }
        if (screenTextOn) return
        screenTextOn = true
        val pm = ctx.getSystemService(android.os.PowerManager::class.java)
        val th = Thread {
            while (screenTextOn) {
                try {
                    val svc = MacroAccessibilityService.instance
                    if (svc != null && pm.isInteractive) {
                        val teks = svc.screenText(8000)
                        val pkg = MacroAccessibilityService.currentPkg
                        for (n in screenNeedles) {
                            val ada = teks.contains(n, ignoreCase = true)
                            val sebelum = screenPresent.put(n, ada)
                            if (ada && sebelum == false) {
                                engine.dispatch(
                                    TriggerEvent("screen_text", mapOf("screen_needle" to n, "app_pkg" to pkg, "screen_text" to teks.take(2000))),
                                )
                            }
                        }
                    } else {
                        screenPresent.clear()
                    }
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                }
            }
        }
        th.isDaemon = true
        th.name = "makroku-screen-text"
        th.start()
        screenTextThread = th
    }

    private var adbThread: Thread? = null
    @Volatile private var adbOn = false
    @Volatile private var lastAdb: Boolean? = null

    /** Memeriksa sambungan ADB bawaan tiap 20 detik; memicu saat berubah. */
    private fun setAdbState(on: Boolean) {
        if (!on) {
            adbOn = false
            adbThread?.interrupt()
            adbThread = null
            lastAdb = null
            return
        }
        if (adbOn) return
        adbOn = true
        lastAdb = null
        val th = Thread {
            while (adbOn) {
                try {
                    if (com.makroku.automation.adb.AdbBackend.dipasangkan(ctx)) {
                        val now = com.makroku.automation.adb.AdbBackend.tersambung(ctx)
                        val prev = lastAdb
                        lastAdb = now
                        if (prev != null && prev != now) engine.dispatch(TriggerEvent("adb_state", mapOf("connected" to now.toString())))
                    }
                    Thread.sleep(20_000)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                }
            }
        }
        th.isDaemon = true
        th.name = "makroku-adb-state"
        th.start()
        adbThread = th
    }
}
