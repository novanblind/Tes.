package com.novan.githubbynovan;

import java.math.BigInteger;
import java.security.SecureRandom;

/**
 * Enkripsi "sealed box" (setara crypto_box_seal di libsodium) dalam Java murni, tanpa pustaka tambahan.
 * Dipakai untuk mengirim rahasia ke GitHub Secrets: GitHub meminta nilai dienkripsi dengan kunci publik
 * repositori (X25519 + XSalsa20-Poly1305, nonce dari BLAKE2b).
 * Hasil: kunci publik sementara (32 byte) + tag (16 byte) + data terenkripsi.
 */
public final class SegelRahasia {
    private SegelRahasia() { }

    /** Mengenkripsi pesan untuk pemilik kunci publik (32 byte). */
    public static byte[] segel(byte[] pesan, byte[] kunciPublik) {
        byte[] esk = new byte[32];
        new SecureRandom().nextBytes(esk);
        return segel(pesan, kunciPublik, esk);
    }

    /** Versi dengan kunci rahasia sementara yang diberikan (untuk pengujian). */
    static byte[] segel(byte[] pesan, byte[] pk, byte[] esk) {
        if (pk == null || pk.length != 32) throw new IllegalArgumentException("Kunci publik harus 32 byte.");
        byte[] dasar = new byte[32];
        dasar[0] = 9;
        byte[] epk = x25519(esk, dasar);
        byte[] bersama = x25519(esk, pk);
        byte[] kunci = hsalsa20(bersama, new byte[16]);
        byte[] nonce = blake2b(gabung(epk, pk), 24);
        return gabung(epk, kotakRahasia(pesan, nonce, kunci));
    }

    // ---------- X25519 (RFC 7748) ----------

    private static final BigInteger P = BigInteger.ONE.shiftLeft(255).subtract(BigInteger.valueOf(19));
    private static final BigInteger A24 = BigInteger.valueOf(121665);

    static byte[] x25519(byte[] skalar, byte[] u) {
        byte[] k = skalar.clone();
        k[0] &= (byte) 248;
        k[31] &= (byte) 127;
        k[31] |= (byte) 64;
        byte[] ub = u.clone();
        ub[31] &= (byte) 127;
        BigInteger x1 = dariLE(ub).mod(P);
        BigInteger x2 = BigInteger.ONE, z2 = BigInteger.ZERO, x3 = x1, z3 = BigInteger.ONE;
        int tukar = 0;
        for (int t = 254; t >= 0; t--) {
            int kt = (k[t >>> 3] >>> (t & 7)) & 1;
            tukar ^= kt;
            if (tukar == 1) {
                BigInteger tmp = x2; x2 = x3; x3 = tmp;
                tmp = z2; z2 = z3; z3 = tmp;
            }
            tukar = kt;
            BigInteger a = x2.add(z2).mod(P);
            BigInteger aa = a.multiply(a).mod(P);
            BigInteger b = x2.subtract(z2).mod(P);
            BigInteger bb = b.multiply(b).mod(P);
            BigInteger e = aa.subtract(bb).mod(P);
            BigInteger c = x3.add(z3).mod(P);
            BigInteger d = x3.subtract(z3).mod(P);
            BigInteger da = d.multiply(a).mod(P);
            BigInteger cb = c.multiply(b).mod(P);
            BigInteger s = da.add(cb).mod(P);
            BigInteger df = da.subtract(cb).mod(P);
            x3 = s.multiply(s).mod(P);
            z3 = x1.multiply(df.multiply(df).mod(P)).mod(P);
            x2 = aa.multiply(bb).mod(P);
            z2 = e.multiply(aa.add(A24.multiply(e)).mod(P)).mod(P);
        }
        if (tukar == 1) {
            BigInteger tmp = x2; x2 = x3; x3 = tmp;
            tmp = z2; z2 = z3; z3 = tmp;
        }
        BigInteger hasil = x2.multiply(z2.modPow(P.subtract(BigInteger.valueOf(2)), P)).mod(P);
        return keLE(hasil, 32);
    }

    private static BigInteger dariLE(byte[] b) {
        byte[] be = new byte[b.length];
        for (int i = 0; i < b.length; i++) be[i] = b[b.length - 1 - i];
        return new BigInteger(1, be);
    }

    private static byte[] keLE(BigInteger v, int n) {
        byte[] be = v.toByteArray();
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            int idx = be.length - 1 - i;
            out[i] = idx >= 0 ? be[idx] : 0;
        }
        return out;
    }

    // ---------- Salsa20 / HSalsa20 / XSalsa20 ----------

    private static int rotl(int v, int c) { return (v << c) | (v >>> (32 - c)); }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8) | ((b[o + 2] & 0xff) << 16) | ((b[o + 3] & 0xff) << 24);
    }

    private static void taruh32(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >>> 8);
        b[o + 2] = (byte) (v >>> 16);
        b[o + 3] = (byte) (v >>> 24);
    }

    private static void putaran(int[] x) {
        for (int i = 0; i < 10; i++) {
            x[4] ^= rotl(x[0] + x[12], 7);  x[8] ^= rotl(x[4] + x[0], 9);
            x[12] ^= rotl(x[8] + x[4], 13); x[0] ^= rotl(x[12] + x[8], 18);
            x[9] ^= rotl(x[5] + x[1], 7);   x[13] ^= rotl(x[9] + x[5], 9);
            x[1] ^= rotl(x[13] + x[9], 13); x[5] ^= rotl(x[1] + x[13], 18);
            x[14] ^= rotl(x[10] + x[6], 7); x[2] ^= rotl(x[14] + x[10], 9);
            x[6] ^= rotl(x[2] + x[14], 13); x[10] ^= rotl(x[6] + x[2], 18);
            x[3] ^= rotl(x[15] + x[11], 7); x[7] ^= rotl(x[3] + x[15], 9);
            x[11] ^= rotl(x[7] + x[3], 13); x[15] ^= rotl(x[11] + x[7], 18);
            x[1] ^= rotl(x[0] + x[3], 7);   x[2] ^= rotl(x[1] + x[0], 9);
            x[3] ^= rotl(x[2] + x[1], 13);  x[0] ^= rotl(x[3] + x[2], 18);
            x[6] ^= rotl(x[5] + x[4], 7);   x[7] ^= rotl(x[6] + x[5], 9);
            x[4] ^= rotl(x[7] + x[6], 13);  x[5] ^= rotl(x[4] + x[7], 18);
            x[11] ^= rotl(x[10] + x[9], 7); x[8] ^= rotl(x[11] + x[10], 9);
            x[9] ^= rotl(x[8] + x[11], 13); x[10] ^= rotl(x[9] + x[8], 18);
            x[12] ^= rotl(x[15] + x[14], 7); x[13] ^= rotl(x[12] + x[15], 9);
            x[14] ^= rotl(x[13] + x[12], 13); x[15] ^= rotl(x[14] + x[13], 18);
        }
    }

    private static final int[] SIGMA = {0x61707865, 0x3320646e, 0x79622d32, 0x6b206574};

    private static int[] keadaan(byte[] kunci, int n0, int n1, int c0, int c1) {
        int[] x = new int[16];
        x[0] = SIGMA[0];
        for (int i = 0; i < 4; i++) x[1 + i] = le32(kunci, 4 * i);
        x[5] = SIGMA[1];
        x[6] = n0;
        x[7] = n1;
        x[8] = c0;
        x[9] = c1;
        x[10] = SIGMA[2];
        for (int i = 0; i < 4; i++) x[11 + i] = le32(kunci, 16 + 4 * i);
        x[15] = SIGMA[3];
        return x;
    }

    static byte[] hsalsa20(byte[] kunci, byte[] masuk16) {
        int[] x = keadaan(kunci, le32(masuk16, 0), le32(masuk16, 4), le32(masuk16, 8), le32(masuk16, 12));
        putaran(x);
        byte[] out = new byte[32];
        int[] idx = {0, 5, 10, 15, 6, 7, 8, 9};
        for (int i = 0; i < 8; i++) taruh32(out, 4 * i, x[idx[i]]);
        return out;
    }

    /** Aliran kunci XSalsa20 sepanjang n byte. */
    private static byte[] aliran(byte[] kunci, byte[] nonce24, int n) {
        byte[] sub = hsalsa20(kunci, java.util.Arrays.copyOfRange(nonce24, 0, 16));
        int n0 = le32(nonce24, 16), n1 = le32(nonce24, 20);
        byte[] out = new byte[n];
        long blok = 0;
        for (int pos = 0; pos < n; pos += 64, blok++) {
            int[] awal = keadaan(sub, n0, n1, (int) blok, (int) (blok >>> 32));
            int[] x = awal.clone();
            putaran(x);
            byte[] b = new byte[64];
            for (int i = 0; i < 16; i++) taruh32(b, 4 * i, x[i] + awal[i]);
            System.arraycopy(b, 0, out, pos, Math.min(64, n - pos));
        }
        return out;
    }

    // ---------- Poly1305 ----------

    private static byte[] poly1305(byte[] pesan, byte[] kunci) {
        BigInteger r = dariLE(java.util.Arrays.copyOfRange(kunci, 0, 16))
                .and(new BigInteger("0ffffffc0ffffffc0ffffffc0fffffff", 16));
        BigInteger s = dariLE(java.util.Arrays.copyOfRange(kunci, 16, 32));
        BigInteger p = BigInteger.ONE.shiftLeft(130).subtract(BigInteger.valueOf(5));
        BigInteger acc = BigInteger.ZERO;
        for (int i = 0; i < pesan.length; i += 16) {
            int n = Math.min(16, pesan.length - i);
            byte[] blok = java.util.Arrays.copyOfRange(pesan, i, i + n);
            BigInteger v = dariLE(blok).add(BigInteger.ONE.shiftLeft(8 * n));
            acc = acc.add(v).multiply(r).mod(p);
        }
        acc = acc.add(s).mod(BigInteger.ONE.shiftLeft(128));
        return keLE(acc, 16);
    }

    /** crypto_secretbox_xsalsa20poly1305: tag (16 byte) + data terenkripsi. */
    static byte[] kotakRahasia(byte[] pesan, byte[] nonce24, byte[] kunci) {
        byte[] as = aliran(kunci, nonce24, 32 + pesan.length);
        byte[] c = new byte[pesan.length];
        for (int i = 0; i < pesan.length; i++) c[i] = (byte) (pesan[i] ^ as[32 + i]);
        byte[] tag = poly1305(c, java.util.Arrays.copyOfRange(as, 0, 32));
        return gabung(tag, c);
    }

    // ---------- BLAKE2b (tanpa kunci) ----------

    private static final long[] IV = {
        0x6a09e667f3bcc908L, 0xbb67ae8584caa73bL, 0x3c6ef372fe94f82bL, 0xa54ff53a5f1d36f1L,
        0x510e527fade682d1L, 0x9b05688c2b3e6c1fL, 0x1f83d9abfb41bd6bL, 0x5be0cd19137e2179L};

    private static final int[][] SG = {
        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
        {14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3},
        {11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4},
        {7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8},
        {9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13},
        {2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9},
        {12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11},
        {13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10},
        {6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5},
        {10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0}};

    static byte[] blake2b(byte[] data, int panjangKeluar) {
        long[] h = IV.clone();
        h[0] ^= 0x01010000L ^ panjangKeluar;
        int blok = 128;
        int jumlah = Math.max(1, (data.length + blok - 1) / blok);
        long t = 0;
        for (int b = 0; b < jumlah; b++) {
            byte[] m = new byte[blok];
            int mulai = b * blok;
            int n = Math.max(0, Math.min(blok, data.length - mulai));
            if (n > 0) System.arraycopy(data, mulai, m, 0, n);
            t += n;
            kompres(h, m, t, b == jumlah - 1);
        }
        byte[] out = new byte[panjangKeluar];
        for (int i = 0; i < panjangKeluar; i++) out[i] = (byte) (h[i >>> 3] >>> (8 * (i & 7)));
        return out;
    }

    private static void kompres(long[] h, byte[] blokByte, long t, boolean akhir) {
        long[] m = new long[16];
        for (int i = 0; i < 16; i++) {
            long v = 0;
            for (int j = 7; j >= 0; j--) v = (v << 8) | (blokByte[8 * i + j] & 0xffL);
            m[i] = v;
        }
        long[] v = new long[16];
        System.arraycopy(h, 0, v, 0, 8);
        System.arraycopy(IV, 0, v, 8, 8);
        v[12] ^= t;
        if (akhir) v[14] = ~v[14];
        for (int r = 0; r < 12; r++) {
            int[] s = SG[r % 10];
            g(v, 0, 4, 8, 12, m[s[0]], m[s[1]]);
            g(v, 1, 5, 9, 13, m[s[2]], m[s[3]]);
            g(v, 2, 6, 10, 14, m[s[4]], m[s[5]]);
            g(v, 3, 7, 11, 15, m[s[6]], m[s[7]]);
            g(v, 0, 5, 10, 15, m[s[8]], m[s[9]]);
            g(v, 1, 6, 11, 12, m[s[10]], m[s[11]]);
            g(v, 2, 7, 8, 13, m[s[12]], m[s[13]]);
            g(v, 3, 4, 9, 14, m[s[14]], m[s[15]]);
        }
        for (int i = 0; i < 8; i++) h[i] ^= v[i] ^ v[i + 8];
    }

    private static void g(long[] v, int a, int b, int c, int d, long x, long y) {
        v[a] = v[a] + v[b] + x;
        v[d] = Long.rotateRight(v[d] ^ v[a], 32);
        v[c] = v[c] + v[d];
        v[b] = Long.rotateRight(v[b] ^ v[c], 24);
        v[a] = v[a] + v[b] + y;
        v[d] = Long.rotateRight(v[d] ^ v[a], 16);
        v[c] = v[c] + v[d];
        v[b] = Long.rotateRight(v[b] ^ v[c], 63);
    }

    private static byte[] gabung(byte[] a, byte[] b) {
        byte[] out = new byte[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }
}
