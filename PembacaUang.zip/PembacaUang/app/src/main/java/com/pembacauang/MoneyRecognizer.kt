package com.pembacauang

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * OCR ML Kit untuk frame NV21 dari Camera v1.
 * Seluruh blok teks digabung (dipisah baris baru) lalu diserahkan ke [onText].
 * [onDone] selalu dipanggil setelah selesai, agar buffer frame bisa dipakai lagi.
 */
class MoneyRecognizer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun process(
        nv21: ByteArray,
        width: Int,
        height: Int,
        rotationDegrees: Int,
        onText: (String) -> Unit,
        onDone: () -> Unit,
    ) {
        try {
            val input = InputImage.fromByteArray(
                nv21, width, height, rotationDegrees, InputImage.IMAGE_FORMAT_NV21,
            )
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    if (result.textBlocks.isNotEmpty()) {
                        val sb = StringBuilder()
                        for (block in result.textBlocks) sb.append(block.text).append('\n')
                        onText(sb.toString())
                    }
                }
                .addOnCompleteListener { onDone() }
        } catch (e: Exception) {
            onDone()
        }
    }

    fun close() = recognizer.close()
}
