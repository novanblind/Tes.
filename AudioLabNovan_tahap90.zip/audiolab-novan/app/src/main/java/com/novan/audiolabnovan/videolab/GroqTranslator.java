package com.novan.audiolabnovan.videolab;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Menerjemahkan teks subtitle lewat model obrolan Groq, per kelompok baris agar konteks tetap terjaga. */
public final class GroqTranslator {
    private static final String BASE = "https://api.groq.com/openai/v1";
    private static final int BATCH = 30;
    // Urutan pilihan model. Daftar model Groq berubah dari waktu ke waktu, jadi yang dipakai dipilih dari daftar milik akun.
    private static final String[] PREFERRED = {
            "openai/gpt-oss-120b", "openai/gpt-oss-20b", "llama-3.3-70b-versatile",
            "qwen/qwen3.6-27b", "llama-3.1-8b-instant"};
    private static final Pattern LINE = Pattern.compile("^\\s*(\\d+)\\s*[:|.)\\]-]\\s*(.*)$");

    public static final class Result {
        public final List<String> texts;
        public final int failed;
        public final String model;
        Result(List<String> texts, int failed, String model) {
            this.texts = texts;
            this.failed = failed;
            this.model = model;
        }
    }

    private GroqTranslator() { }

    /** Mengembalikan terjemahan sesuai urutan masukan. Baris yang gagal diterjemahkan tetap berisi teks asli. */
    public static Result translate(String apiKey, List<String> lines, String languageName) throws IOException {
        String model = pickModel(apiKey);
        List<String> out = new ArrayList<>(lines);
        int failed = 0;
        for (int from = 0; from < lines.size(); from += BATCH) {
            int to = Math.min(lines.size(), from + BATCH);
            List<String> part = lines.subList(from, to);
            String[] got = translateBatch(apiKey, model, part, languageName);
            for (int i = 0; i < part.size(); i++) {
                if (got[i] != null && !got[i].trim().isEmpty()) out.set(from + i, got[i].trim());
                else failed++;
            }
        }
        return new Result(out, failed, model);
    }

    private static String[] translateBatch(String key, String model, List<String> part, String lang)
            throws IOException {
        String[] got = parse(chat(key, model, part, lang), part.size());
        boolean missing = false;
        for (String g : got) if (g == null) missing = true;
        if (missing) {
            String[] again = parse(chat(key, model, part, lang), part.size());
            for (int i = 0; i < got.length; i++) if (got[i] == null) got[i] = again[i];
        }
        return got;
    }

    private static String chat(String key, String model, List<String> part, String lang) throws IOException {
        IOException last = null;
        for (int i = 0; i < 3; i++) {
            try {
                return chatOnce(key, model, part, lang);
            } catch (GroqTranscriber.Retryable e) {
                last = e;
                if (i == 2) break;
                try { Thread.sleep(Math.max(e.waitMs, 3000L * (i + 1))); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        throw last != null ? last : new IOException("Gagal terhubung ke Groq.");
    }

    private static String chatOnce(String key, String model, List<String> part, String lang) throws IOException {
        StringBuilder user = new StringBuilder();
        for (int i = 0; i < part.size(); i++) {
            user.append(i + 1).append(": ").append(part.get(i).replace('\n', ' ')).append('\n');
        }
        String system = "Kamu penerjemah subtitle profesional. Terjemahkan setiap baris ke bahasa " + lang
                + ". Pertahankan makna, nada, dan kesinambungan antar baris karena baris-baris ini berurutan dalam satu video. "
                + "Singkat dan alami seperti subtitle. Jawab HANYA dengan baris terjemahan memakai nomor yang sama "
                + "dengan format \"nomor: terjemahan\", satu baris untuk satu nomor, jumlah baris harus sama persis. "
                + "Jangan menambah penjelasan, catatan, atau baris kosong.";
        try {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("temperature", 0.2);
            body.put("max_tokens", 6000);
            if (model.startsWith("openai/gpt-oss")) body.put("reasoning_effort", "low");
            JSONArray msgs = new JSONArray();
            msgs.put(new JSONObject().put("role", "system").put("content", system));
            msgs.put(new JSONObject().put("role", "user").put("content", user.toString()));
            body.put("messages", msgs);
            HttpURLConnection con = open("/chat/completions", key, "POST");
            con.setDoOutput(true);
            con.setReadTimeout(120000);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = con.getResponseCode();
            String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
            long retryAfter = 0;
            try { retryAfter = Math.min(30, Long.parseLong(con.getHeaderField("Retry-After").trim())) * 1000L; } catch (Exception ignored) { }
            con.disconnect();
            if (code == 429 || code >= 500) throw new GroqTranscriber.Retryable(describeError(code, resp), retryAfter);
            if (code >= 400) throw new IOException(describeError(code, resp));
            JSONObject j = new JSONObject(resp);
            return j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "");
        } catch (IOException e) {
            if (e instanceof GroqTranscriber.Retryable) throw e;
            if (e instanceof java.net.SocketTimeoutException || e instanceof java.net.UnknownHostException
                    || e instanceof java.net.ConnectException || e instanceof java.net.SocketException) {
                throw new GroqTranscriber.Retryable("Gagal terhubung ke Groq. Periksa internet.", 0);
            }
            throw e;
        } catch (Exception e) {
            throw new IOException("Balasan Groq tidak bisa dibaca.");
        }
    }

    static String[] parse(String text, int n) {
        String[] r = new String[n];
        for (String line : text.split("\\n")) {
            Matcher m = LINE.matcher(line);
            if (!m.matches()) continue;
            int idx;
            try { idx = Integer.parseInt(m.group(1)) - 1; } catch (Exception e) { continue; }
            if (idx >= 0 && idx < n && r[idx] == null) r[idx] = m.group(2).trim();
        }
        return r;
    }

    private static String pickModel(String key) throws IOException {
        Set<String> have = new HashSet<>();
        try {
            HttpURLConnection con = open("/models", key, "GET");
            int code = con.getResponseCode();
            String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
            con.disconnect();
            if (code >= 400) throw new IOException(describeError(code, resp));
            JSONArray data = new JSONObject(resp).optJSONArray("data");
            if (data != null) {
                for (int i = 0; i < data.length(); i++) have.add(data.getJSONObject(i).optString("id", ""));
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception ignored) { }
        for (String p : PREFERRED) if (have.contains(p)) return p;
        if (have.isEmpty()) return PREFERRED[0];
        throw new IOException("Tidak ada model obrolan Groq yang cocok untuk menerjemahkan di akun ini.");
    }

    private static HttpURLConnection open(String path, String key, String method) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(BASE + path).openConnection();
        con.setRequestMethod(method);
        con.setConnectTimeout(30000);
        con.setReadTimeout(30000);
        con.setRequestProperty("Authorization", "Bearer " + key);
        con.setRequestProperty("Content-Type", "application/json");
        return con;
    }

    private static String read(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String describeError(int code, String body) {
        String msg = "";
        try { msg = new JSONObject(body).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
        if (code == 401) return "Kunci API Groq tidak valid atau sudah dicabut. Periksa kunci di pengaturan.";
        if (code == 429) return "Batas pemakaian Groq tercapai. Coba lagi beberapa saat lagi." + (msg.isEmpty() ? "" : " " + msg);
        if (code >= 500) return "Server Groq sedang bermasalah (kode " + code + "). Coba lagi nanti.";
        return "Groq menolak permintaan (kode " + code + ")." + (msg.isEmpty() ? "" : " " + msg);
    }
}
