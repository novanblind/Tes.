package com.novan.audiolabnovan.videolab;

public class SubtitleItem {
    public long startMs;
    public long endMs;
    public String text;
    /** true jika dibuat oleh subtitle otomatis; menghapusnya (mode potong lewat teks) ikut memotong video. */
    public boolean auto = false;
    /** Tanda susunan klip saat subtitle otomatis dibuat; potong lewat teks hanya jika masih sama. */
    public long sig = 0;

    public SubtitleItem(long startMs, long endMs, String text) {
        this.startMs = startMs;
        this.endMs = endMs;
        this.text = text;
    }
}
