package id.ytplayer.music

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Layanan pemutar latar belakang.
 *
 * Perpindahan lagu dibuat menyatu:
 *  - Gapless: ExoPlayer menyambung lagu berikutnya tanpa jeda.
 *  - Crossfade: ujung lagu lama memudar sambil lagu baru menguat. Berlaku untuk pergantian
 *    otomatis maupun saat tombol berikutnya/sebelumnya ditekan (bisa diatur).
 */
class PlaybackService : MediaSessionService() {

    companion object {
        @Volatile
        var instance: PlaybackService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var exo: ExoPlayer
    private var session: MediaSession? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var state: SharedPreferences

    private val attrs = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    // crossfade
    private var outgoing: ExoPlayer? = null     // pemain yang memudarkan lagu lama
    private var prewarmed: ExoPlayer? = null    // pemain lagu saat ini yang disiapkan lebih dulu
    private var prewarmedId: String? = null
    private var fading = false
    private var fadeStart = 0L
    private var fadeMs = 1L

    // timer tidur
    private var sleepEnd = 0L

    // ulang A-B
    var abA = -1L
        private set
    var abB = -1L
        private set

    private var lastSave = 0L

    // fokus audio dan ducking
    private var focusReq: AudioFocusRequest? = null
    private var focusHeld = false
    private var pausedByFocus = false      // dijeda oleh sistem; fokus tetap dipegang agar bisa lanjut
    private var resumeAfterFocus = false
    private var duckFactor = 1f
    private val focusListener = AudioManager.OnAudioFocusChangeListener { c -> onFocusChange(c) }

    // simpan posisi per lagu
    private val posPrefs by lazy { getSharedPreferences("trackpos", MODE_PRIVATE) }
    private var curDurId: String? = null
    private var curDur = 0L
    private var autoFadeFromId: String? = null

    // ReplayGain
    private var rgInfo: ReplayGain.Info? = null

    // putar otomatis saat headset/Bluetooth tersambung
    private val knownOutputs = HashSet<Int>()

    private fun isPersonalOutput(d: AudioDeviceInfo): Boolean = when (d.type) {
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_HEARING_AID -> true
        else -> false
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            var fresh = false
            for (d in addedDevices) {
                if (d.isSink && knownOutputs.add(d.id) && isPersonalOutput(d)) fresh = true
            }
            handler.postDelayed({ NovanEngine.syncDevice(this@PlaybackService) }, 500L)
            if (fresh && prefs.getBoolean(Prefs.AUTO_START_OUTPUT, false)) autoStart()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            for (d in removedDevices) knownOutputs.remove(d.id)
            handler.postDelayed({ NovanEngine.syncDevice(this@PlaybackService) }, 500L)
        }
    }

    private fun autoStart() {
        // jeda singkat agar jalur suara selesai berpindah ke perangkat baru
        handler.postDelayed({
            if (exo.mediaItemCount == 0 || exo.isPlaying) return@postDelayed
            if (exo.playbackState == Player.STATE_ENDED) return@postDelayed
            if (exo.playbackState == Player.STATE_IDLE) exo.prepare()
            exo.play()
        }, 800L)
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.AUDIO_FOCUS -> {
                if (prefs.getBoolean(Prefs.AUDIO_FOCUS, false)) {
                    if (exo.playWhenReady) requestFocus()
                } else {
                    pausedByFocus = false
                    resumeAfterFocus = false
                    abandonFocus()
                }
            }
            Prefs.RG_MODE, Prefs.RG_PREAMP, Prefs.RG_UNTAGGED -> applyReplayGain()
            Prefs.SKIP_SILENCE -> exo.setSkipSilenceEnabled(prefs.getBoolean(Prefs.SKIP_SILENCE, false))
            Prefs.PAUSE_UNPLUG -> exo.setHandleAudioBecomingNoisy(prefs.getBoolean(Prefs.PAUSE_UNPLUG, true))
            else -> {}
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (_: Throwable) {
            }
            val delay = when {
                fading -> 40L
                abB > 0 -> 80L
                else -> 250L
            }
            handler.postDelayed(this, delay)
        }
    }

    private val sleepRunnable = Runnable {
        exo.pause()
        sleepEnd = 0L
    }

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs.of(this)
        state = Prefs.state(this)
        NovanEngine.reload(this)
        NovanEngine.syncDevice(this)

        exo = ExoPlayer.Builder(this, NovanRenderersFactory(this))
            .setAudioAttributes(attrs, false) // fokus audio diurus sendiri (requestFocus) agar ducking bisa diatur
            .setHandleAudioBecomingNoisy(prefs.getBoolean(Prefs.PAUSE_UNPLUG, true))
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // Sesi audio sendiri yang tetap untuk pemain crossfade
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val sid = am.generateAudioSessionId()
        if (sid != AudioManager.ERROR) exo.setAudioSessionId(sid)

        // catat perangkat keluaran yang sudah tersambung; hanya yang baru muncul yang memicu putar otomatis
        for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) knownOutputs.add(d.id)
        am.registerAudioDeviceCallback(deviceCallback, handler)

        exo.repeatMode = state.getInt("repeat", Player.REPEAT_MODE_OFF)
        exo.shuffleModeEnabled = state.getBoolean("shuffle", false)
        exo.playbackParameters = PlaybackParameters(state.getFloat("speed", 1f), state.getFloat("pitch", 1f))
        exo.setSkipSilenceEnabled(prefs.getBoolean(Prefs.SKIP_SILENCE, false))

        exo.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (playWhenReady) {
                    pausedByFocus = false
                    resumeAfterFocus = false
                    if (!requestFocus()) exo.pause()
                } else {
                    saveTrackPos()
                    if (!pausedByFocus) abandonFocus()
                }
                if (!playWhenReady) {
                    if (fading) endFade()
                    saveState()
                    if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                        exo.setPauseAtEndOfMediaItems(false)
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                abA = -1L
                abB = -1L
                val id = prewarmedId
                if (id != null && id != mediaItem?.mediaId) dropPrewarm()
                if (mediaItem != null && reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && trackPosOn()) {
                    val saved = posPrefs.getLong("p_${mediaItem.mediaId}", 0L)
                    if (saved > 3000L && exo.currentPosition < 2000L) exo.seekTo(saved)
                }
                saveState()
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                val old = oldPosition.mediaItem ?: return
                if (old.mediaId == newPosition.mediaItem?.mediaId) return
                val dur = if (curDurId == old.mediaId) curDur else 0L
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION || old.mediaId == autoFadeFromId) {
                    autoFadeFromId = null
                    clearTrackPos(old.mediaId)
                } else if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_SKIP) {
                    storeTrackPos(old.mediaId, oldPosition.positionMs, dur)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                rgInfo = ReplayGain.read(tracks)
                applyReplayGain()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    exo.currentMediaItem?.let { clearTrackPos(it.mediaId) }
                    endFade()
                    saveState()
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Perangkat menolak laju atau mode keluaran pilihan: ulangi dengan laju berkas lagu.
                if (NovanEngine.handleSinkError(error)) {
                    exo.prepare()
                    exo.play()
                }
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                state.edit().putInt("repeat", repeatMode).apply()
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                state.edit().putBoolean("shuffle", shuffleModeEnabled).apply()
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                state.edit().putFloat("speed", playbackParameters.speed)
                    .putFloat("pitch", playbackParameters.pitch).apply()
            }
        })

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, Fwd(exo)).setId("music_player").setSessionActivity(open).build()

        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        handler.post(ticker)
        restoreQueue()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val keep = prefs.getBoolean(Prefs.AUTO_START_OUTPUT, false) && exo.mediaItemCount > 0
        if ((!exo.playWhenReady || exo.mediaItemCount == 0) && !keep) {
            saveState()
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { saveState() } catch (_: Throwable) {}
        endFade()
        dropPrewarm()
        abandonFocus()
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try {
            (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(deviceCallback)
        } catch (_: Throwable) {}
        if (android.os.Build.VERSION.SDK_INT >= 34) BitPerfect.clear(this)
        session?.run {
            release()
        }
        session = null
        exo.release()
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- pemain pembungkus

    /** Menyisipkan crossfade pada perpindahan lagu manual (tombol, notifikasi, antrean). */
    private inner class Fwd(p: ExoPlayer) : ForwardingPlayer(p) {

        override fun seekToNext() {
            if (exo.hasNextMediaItem()) changeItem { exo.seekToNextMediaItem() } else exo.seekToNext()
        }

        override fun seekToNextMediaItem() {
            if (exo.hasNextMediaItem()) changeItem { exo.seekToNextMediaItem() } else exo.seekToNextMediaItem()
        }

        override fun seekToPrevious() {
            val restart = prefs.getBoolean(Prefs.PREV_RESTART, true)
            if ((restart && exo.currentPosition > Prefs.prevRestartMs(this@PlaybackService)) || !exo.hasPreviousMediaItem()) {
                exo.seekTo(0L)
            } else {
                changeItem { exo.seekToPreviousMediaItem() }
            }
        }

        override fun seekToPreviousMediaItem() {
            if (exo.hasPreviousMediaItem()) changeItem { exo.seekToPreviousMediaItem() } else exo.seekTo(0L)
        }

        override fun seekTo(mediaItemIndex: Int, positionMs: Long) {
            if (mediaItemIndex != exo.currentMediaItemIndex) {
                changeItem { exo.seekTo(mediaItemIndex, positionMs) }
            } else {
                exo.seekTo(mediaItemIndex, positionMs)
            }
        }

        override fun seekToDefaultPosition(mediaItemIndex: Int) {
            if (mediaItemIndex != exo.currentMediaItemIndex) {
                changeItem { exo.seekToDefaultPosition(mediaItemIndex) }
            } else {
                exo.seekToDefaultPosition(mediaItemIndex)
            }
        }
    }

    // ---------------------------------------------------------------- crossfade

    private fun canManualFade(): Boolean =
        prefs.getBoolean(Prefs.CROSSFADE_MANUAL, true) &&
            Prefs.crossfadeSec(this) > 0 &&
            exo.isPlaying &&
            exo.currentMediaItem != null

    private fun changeItem(block: () -> Unit) {
        if (!canManualFade()) {
            block()
            return
        }
        endFade()
        val total = min(Prefs.crossfadeSec(this) * 1000L, 3000L)
        beginFade(total)
        block()
    }

    private fun newOutgoing(item: MediaItem, posMs: Long): ExoPlayer {
        val q = ExoPlayer.Builder(this, NovanRenderersFactory(this)).build()
        q.setAudioSessionId(exo.audioSessionId)
        q.playbackParameters = exo.playbackParameters
        q.setMediaItem(item)
        q.prepare()
        q.seekTo(posMs)
        q.playWhenReady = false
        return q
    }

    private fun dropPrewarm() {
        try { prewarmed?.release() } catch (_: Throwable) {}
        prewarmed = null
        prewarmedId = null
    }

    /** Menyiapkan salinan lagu saat ini agar siap dipakai saat crossfade dimulai. */
    private fun prewarm(item: MediaItem, startAt: Long) {
        dropPrewarm()
        prewarmed = newOutgoing(item, startAt)
        prewarmedId = item.mediaId
    }

    /** Mulai memudarkan lagu saat ini di pemain kedua; pemain utama diturunkan ke volume 0. */
    private fun beginFade(ms: Long) {
        val item = exo.currentMediaItem ?: return
        val ready = prewarmed?.takeIf { prewarmedId == item.mediaId }
        if (ready == null) {
            dropPrewarm()
        } else {
            prewarmed = null
            prewarmedId = null
        }
        val pos = exo.currentPosition
        val out = ready ?: newOutgoing(item, pos)
        out.seekTo(pos)
        out.volume = duckFactor
        out.playWhenReady = true
        outgoing = out
        exo.volume = 0f
        fadeMs = if (ms < 1L) 1L else ms
        fadeStart = SystemClock.uptimeMillis()
        fading = true
    }

    private fun tickFade() {
        val q = outgoing
        if (q == null) {
            endFade()
            return
        }
        val t = ((SystemClock.uptimeMillis() - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
        exo.volume = sin(t * PI / 2).toFloat() * duckFactor
        q.volume = cos(t * PI / 2).toFloat() * duckFactor
        if (t >= 1f) endFade()
    }

    private fun endFade() {
        try { outgoing?.release() } catch (_: Throwable) {}
        outgoing = null
        fading = false
        if (this::exo.isInitialized) exo.volume = duckFactor
    }

    private fun autoCrossfade() {
        val sec = Prefs.crossfadeSec(this)
        if (sec <= 0 || fading) return
        if (exo.getPauseAtEndOfMediaItems()) return
        if (exo.repeatMode == Player.REPEAT_MODE_ONE) return
        if (abA >= 0) return
        if (!exo.hasNextMediaItem()) return
        val item = exo.currentMediaItem ?: return
        val dur = exo.duration
        if (dur == C.TIME_UNSET || dur <= 0L) return
        val total = min(sec * 1000L, dur / 3)
        val remain = dur - exo.currentPosition
        if (remain <= total) {
            beginFade(total)
            if (fading) {
                autoFadeFromId = item.mediaId
                exo.seekToNextMediaItem()
            }
        } else if (remain <= total + 3000L && prewarmedId != item.mediaId) {
            prewarm(item, (dur - total).coerceAtLeast(0L))
        }
    }

    // ---------------------------------------------------------------- detak berkala

    private fun tick() {
        if (fading) tickFade()
        if (abA >= 0 && abB > abA && exo.currentPosition >= abB) exo.seekTo(abA)
        if (exo.isPlaying) {
            autoCrossfade()
            val now = SystemClock.elapsedRealtime()
            val d = exo.duration
            if (d != C.TIME_UNSET && d > 0L) {
                curDur = d
                curDurId = exo.currentMediaItem?.mediaId
            }
            if (now - lastSave > 5000L) {
                lastSave = now
                savePosition()
                if (!fading) saveTrackPos()
            }
        }
    }

    // ---------------------------------------------------------------- timer tidur

    fun startSleep(minutes: Int) {
        cancelSleep()
        val ms = minutes * 60_000L
        sleepEnd = SystemClock.elapsedRealtime() + ms
        handler.postDelayed(sleepRunnable, ms)
    }

    fun sleepAfterTrack() {
        cancelSleep()
        exo.setPauseAtEndOfMediaItems(true)
    }

    fun cancelSleep() {
        handler.removeCallbacks(sleepRunnable)
        sleepEnd = 0L
        exo.setPauseAtEndOfMediaItems(false)
    }

    fun sleepRemainingMs(): Long =
        if (sleepEnd > 0L) maxOf(0L, sleepEnd - SystemClock.elapsedRealtime()) else 0L

    fun isSleepAfterTrack(): Boolean = exo.getPauseAtEndOfMediaItems()

    // ---------------------------------------------------------------- ulang A-B

    fun markA(): Long {
        abA = exo.currentPosition
        abB = -1L
        return abA
    }

    fun markB(): Boolean {
        if (abA < 0) return false
        val p = exo.currentPosition
        if (p <= abA + 500L) return false
        abB = p
        exo.seekTo(abA)
        return true
    }

    fun clearAB() {
        abA = -1L
        abB = -1L
    }

    // ---------------------------------------------------------------- fokus audio dan ducking

    private fun setDuck(f: Float) {
        duckFactor = f
        if (!fading) exo.volume = f
    }

    /** Meminta fokus audio (bila diaktifkan). False bila ditolak sehingga pemutaran harus dijeda. */
    private fun requestFocus(): Boolean {
        if (!prefs.getBoolean(Prefs.AUDIO_FOCUS, false)) return true
        if (focusHeld) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val r: Int
        if (Build.VERSION.SDK_INT >= 26) {
            val pa = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            // Menerima fokus tertunda: dengan begitu sistem tidak mengecilkan volume sendiri, kita yang mengaturnya.
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(pa)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(focusListener, handler)
                .build()
            focusReq = req
            r = am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        when (r) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                focusHeld = true
                return true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                // sedang ada panggilan atau suara eksklusif: tunggu, lalu lanjut sendiri saat fokus kembali
                pausedByFocus = true
                resumeAfterFocus = true
                return false
            }
        }
        focusReq = null
        return false
    }

    private fun abandonFocus() {
        if (!focusHeld && focusReq == null) return
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            focusReq?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(focusListener)
        }
        focusReq = null
        focusHeld = false
        setDuck(1f)
    }

    private fun pauseForFocus(resume: Boolean) {
        if (!exo.playWhenReady) return
        pausedByFocus = resume
        resumeAfterFocus = resume
        exo.pause()
    }

    private fun onFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                focusHeld = true
                setDuck(1f)
                val resume = resumeAfterFocus
                resumeAfterFocus = false
                pausedByFocus = false
                if (resume) exo.play()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> when (prefs.getString(Prefs.DUCK_MODE, "duck")) {
                "pause" -> pauseForFocus(true)
                "ignore" -> {}
                else -> setDuck(prefs.getInt(Prefs.DUCK_PERCENT, 20).coerceIn(0, 100) / 100f)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> when (prefs.getString(Prefs.FOCUS_TRANSIENT, "pause_resume")) {
                "pause_resume" -> pauseForFocus(true)
                "pause" -> pauseForFocus(false)
                else -> {}
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                focusHeld = false
                if (prefs.getString(Prefs.FOCUS_LOSS, "pause") != "ignore") pauseForFocus(false)
            }
        }
    }

    // ---------------------------------------------------------------- ReplayGain

    private fun applyReplayGain() {
        NovanEngine.setReplayGain(ReplayGain.gainDb(this, rgInfo))
    }

    // ---------------------------------------------------------------- posisi per lagu

    private fun trackPosOn(): Boolean = prefs.getBoolean(Prefs.TRACK_POS, false)

    private fun clearTrackPos(id: String?) {
        if (id == null || !posPrefs.contains("p_$id")) return
        posPrefs.edit().remove("p_$id").remove("t_$id").apply()
    }

    /** Menyimpan posisi lagu panjang. Dekat awal atau akhir lagu berarti belum mulai atau sudah selesai: dihapus. */
    private fun storeTrackPos(id: String?, pos: Long, dur: Long) {
        if (!trackPosOn() || id == null || id.toLongOrNull() == null) return
        val minMs = (prefs.getString(Prefs.TRACK_POS_MIN, "10")?.toLongOrNull() ?: 10L) * 60_000L
        if (dur <= 0L || dur < minMs) return
        if (pos < 3000L || dur - pos < 8000L) {
            clearTrackPos(id)
            return
        }
        val isNew = !posPrefs.contains("p_$id")
        posPrefs.edit().putLong("p_$id", pos).putLong("t_$id", System.currentTimeMillis()).apply()
        if (isNew && posPrefs.all.size > 1200) {
            // batasi ukuran: buang 100 lagu dengan simpanan paling lama
            val old = posPrefs.all.filterKeys { it.startsWith("t_") }
                .mapNotNull { (k, v) -> (v as? Long)?.let { k.substring(2) to it } }
                .sortedBy { it.second }.take(100)
            val ed = posPrefs.edit()
            for ((i, _) in old) ed.remove("p_$i").remove("t_$i")
            ed.apply()
        }
    }

    private fun saveTrackPos() {
        val d = exo.duration
        storeTrackPos(exo.currentMediaItem?.mediaId, exo.currentPosition, if (d == C.TIME_UNSET) 0L else d)
    }

    // ---------------------------------------------------------------- simpan & pulihkan

    private fun saveState() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true)) return
        val n = exo.mediaItemCount
        if (n == 0) return
        // File yang dibuka dari luar (bukan dari pustaka) tidak disimpan
        for (i in 0 until n) if (exo.getMediaItemAt(i).mediaId.toLongOrNull() == null) return
        val sb = StringBuilder()
        for (i in 0 until n) {
            if (i > 0) sb.append(',')
            sb.append(exo.getMediaItemAt(i).mediaId)
        }
        state.edit()
            .putString("ids", sb.toString())
            .putInt("index", exo.currentMediaItemIndex)
            .putLong("pos", exo.currentPosition)
            .apply()
    }

    private fun savePosition() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true) || exo.mediaItemCount == 0) return
        if (exo.currentMediaItem?.mediaId?.toLongOrNull() == null) return
        state.edit()
            .putInt("index", exo.currentMediaItemIndex)
            .putLong("pos", exo.currentPosition)
            .apply()
    }

    /** Memulihkan antrean terakhir dalam keadaan jeda. */
    private fun restoreQueue() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true)) return
        val ids = state.getString("ids", null)
            ?.split(',')
            ?.mapNotNull { it.toLongOrNull() }
            ?: return
        if (ids.isEmpty()) return
        val index = state.getInt("index", 0)
        val pos = state.getLong("pos", 0L)
        Thread {
            val byId = Library.load(this).associateBy { it.id }
            val items = ids.mapNotNull { byId[it]?.toMediaItem() }
            handler.post {
                if (instance === this && exo.mediaItemCount == 0 && items.isNotEmpty()) {
                    val curId = ids.getOrNull(index)?.toString()
                    val start = items.indexOfFirst { it.mediaId == curId }.coerceAtLeast(0)
                    exo.setMediaItems(items, start, if (start == index) pos else 0L)
                    exo.prepare()
                }
            }
        }.start()
    }
}
