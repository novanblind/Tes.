package com.novan.audiolabnovan

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

/**
 * Tahap 62: tombol Bagikan ke status WhatsApp (pesan suara), hanya bila tombolStatusWa = true (Teks ke Suara dan Voice note Gemini).
 * Tahap 61: ditambah tombol Edit file (di atas tombol Tutup) untuk mengedit lagi berkas yang sudah jadi.
 * Tahap 58: ditambah tombol Atur jeda sebelum audio diputar (untuk kirim pesan suara WhatsApp).
 * Tahap 57: ditambah tombol Kirim ke WhatsApp sebagai pesan suara.
 * Tahap 55: dialog menu hasil yang dipakai SEMUA proses (konversi, rekaman, Teks ke Suara, Pengubah Suara, Karaoke).
 * Muncul otomatis saat proses selesai. Isi menu: Putar, Jeda, Lanjutkan, Bagikan, Ubah nama, Hapus.
 * Dialog tetap terbuka saat berkas diputar, jadi Jeda dan Lanjutkan bisa ditekan kapan saja.
 *
 * Alamat berkas boleh berupa content (MediaStore), dokumen SAF, atau file (berkas sementara di cache).
 */
class DialogHasil(private val act: Activity) {

    class Hasil(var uri: Uri, var nama: String, var mime: String = "audio/*")

    private enum class Keadaan { DIAM, MAIN, JEDA }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var keadaan = Keadaan.DIAM
    private var dialog: AlertDialog? = null
    private var daftarDialog: AlertDialog? = null

    // Tampilan menu yang sedang terbuka.
    private var tvStatus: TextView? = null
    private var tvWaktu: TextView? = null
    private var bPutar: Button? = null
    private var bJeda: Button? = null
    private var bLanjut: Button? = null

    private var sekarang: Hasil? = null
    private var daftar: List<Hasil> = emptyList()
    private var dariDaftar = false

    /** Tahap 62: true = tampilkan tombol Bagikan ke status WhatsApp. Diatur oleh Teks ke Suara dan Voice note Gemini. */
    var tombolStatusWa = false

    /** Dipanggil setelah nama berkas berhasil diubah. */
    var saatDiubah: ((Hasil) -> Unit)? = null

    /** Dipanggil setelah berkas berhasil dihapus. */
    var saatDihapus: ((Hasil) -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            segarkanWaktu()
            if (keadaan == Keadaan.MAIN) handler.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    private fun cakap(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    // =====================================================================================
    //  Tampil
    // =====================================================================================

    /** Satu hasil: langsung menu. Beberapa hasil: daftar dulu, ketuk untuk membuka menunya. */
    fun tampilkan(hasil: List<Hasil>, judulDaftar: String = "Proses selesai") {
        if (hasil.isEmpty() || act.isFinishing || act.isDestroyed) return
        daftar = ArrayList(hasil)
        try {
            if (hasil.size == 1) {
                dariDaftar = false
                menu(hasil[0])
            } else {
                tampilDaftar(judulDaftar)
            }
        } catch (_: Exception) { }
    }

    fun tampilkan(uri: Uri, nama: String, mime: String) = tampilkan(listOf(Hasil(uri, nama, mime)))

    private fun tampilDaftar(judul: String) {
        if (daftar.isEmpty()) return
        daftarDialog?.dismiss()
        daftarDialog = AlertDialog.Builder(act)
            .setTitle("$judul: ${daftar.size} berkas. Pilih berkas untuk membuka menunya.")
            .setItems(daftar.map { it.nama }.toTypedArray()) { _, i ->
                dariDaftar = true
                menu(daftar[i])
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun tombol(teks: String, aksi: () -> Unit): Button = Button(act).apply {
        text = teks
        isAllCaps = false
        minHeight = dp(48)
        setOnClickListener { aksi() }
    }

    private fun menu(h: Hasil) {
        hentikan(false)
        dialog?.dismiss()
        sekarang = h

        val akar = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        tvStatus = TextView(act).apply {
            textSize = 16f
            text = "Berkas siap. Pilih tindakan."
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, 0, 0, dp(4))
        }
        akar.addView(tvStatus)
        tvWaktu = TextView(act).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            setPadding(0, 0, 0, dp(8))
        }
        akar.addView(tvWaktu)

        val lp = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT) }
        bPutar = tombol("Putar") { putar(h) }
        bJeda = tombol("Jeda") { jeda() }
        bLanjut = tombol("Lanjutkan") { lanjut() }
        akar.addView(bPutar, lp())
        akar.addView(bJeda, lp())
        akar.addView(bLanjut, lp())
        akar.addView(tombol("Bagikan") { hentikan(true); bagikan(h) }, lp())
        if (!h.mime.startsWith("video")) {
            akar.addView(tombol("Kirim ke WhatsApp sebagai pesan suara") { hentikan(true); kirimWa(h) }, lp())
            if (tombolStatusWa) {
                akar.addView(tombol("Bagikan ke status WhatsApp (pesan suara)") { hentikan(true); kirimStatusWa(h) }, lp())
            }
            akar.addView(tombol("Atur jeda sebelum audio diputar (saat ini ${com.novan.audiolabnovan.wa.WaKirim.teksJeda(com.novan.audiolabnovan.wa.WaKirim.jedaMs(act))})") {
                hentikan(true); aturJedaWa()
            }, lp())
        }
        akar.addView(tombol("Ubah nama") { hentikan(true); tanyaNama(h) }, lp())
        akar.addView(tombol("Hapus") { hentikan(true); tanyaHapus(h) }, lp())
        akar.addView(tombol("Edit file") { hentikan(true); tanyaEdit(h) }, lp())
        segarkanTombol()

        val d = AlertDialog.Builder(act)
            .setTitle("Selesai: ${h.nama}")
            .setView(ScrollView(act).apply { addView(akar) })
            .setNegativeButton(if (dariDaftar) "Kembali" else "Tutup") { _, _ ->
                hentikan(false)
                if (dariDaftar) tampilDaftar("Proses selesai")
            }
            .setOnCancelListener { hentikan(false) }
            .create()
        dialog = d
        d.show()
    }

    private fun ubahJudul(h: Hasil) {
        dialog?.setTitle("Selesai: ${h.nama}")
    }

    // =====================================================================================
    //  Putar, jeda, lanjutkan
    // =====================================================================================

    private fun putar(h: Hasil) {
        hentikan(false)
        val mp = MediaPlayer()
        try {
            mp.setDataSource(act, h.uri)
            mp.setOnCompletionListener {
                hentikan(false)
                tvStatus?.text = "Pemutaran selesai."
            }
            mp.setOnErrorListener { _, _, _ ->
                hentikan(false)
                tvStatus?.text = "Berkas gagal diputar."
                true
            }
            mp.prepare()
            mp.start()
            player = mp
            keadaan = Keadaan.MAIN
            tvStatus?.text = "Memutar ${h.nama}."
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        } catch (e: Exception) {
            try { mp.release() } catch (_: Exception) { }
            tvStatus?.text = "Gagal memutar: ${e.message ?: "galat"}"
        }
        segarkanTombol()
    }

    private fun jeda() {
        val p = player ?: return
        if (keadaan != Keadaan.MAIN) return
        try { p.pause() } catch (_: Exception) { return }
        keadaan = Keadaan.JEDA
        handler.removeCallbacks(ticker)
        segarkanWaktu()
        tvStatus?.text = "Dijeda. Tekan Lanjutkan untuk meneruskan."
        segarkanTombol()
    }

    private fun lanjut() {
        val p = player ?: return
        if (keadaan != Keadaan.JEDA) return
        try { p.start() } catch (_: Exception) { return }
        keadaan = Keadaan.MAIN
        tvStatus?.text = "Dilanjutkan."
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        segarkanTombol()
    }

    /** Hentikan dan lepas pemutar. [umumkan] true = tulis status "dihentikan" di menu. */
    private fun hentikan(umumkan: Boolean) {
        handler.removeCallbacks(ticker)
        val ada = player != null
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            try { it.release() } catch (_: Exception) { }
        }
        player = null
        keadaan = Keadaan.DIAM
        if (umumkan && ada) tvStatus?.text = "Pemutaran dihentikan."
        segarkanTombol()
        tvWaktu?.text = ""
    }

    private fun segarkanTombol() {
        bPutar?.text = if (keadaan == Keadaan.DIAM) "Putar" else "Putar dari awal"
        bJeda?.isEnabled = keadaan == Keadaan.MAIN
        bLanjut?.isEnabled = keadaan == Keadaan.JEDA
    }

    private fun segarkanWaktu() {
        val p = player ?: return
        try {
            tvWaktu?.text = "${fmt(p.currentPosition)} dari ${fmt(p.duration)}"
        } catch (_: Exception) { }
    }

    private fun fmt(ms: Int): String {
        val s = (ms.coerceAtLeast(0) / 1000)
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    /** Dipanggil activity pemilik saat ditutup atau ditinggalkan: hentikan suara dan tutup dialog. */
    fun lepas() {
        hentikan(false)
        try { dialog?.dismiss() } catch (_: Exception) { }
        try { daftarDialog?.dismiss() } catch (_: Exception) { }
        dialog = null
        daftarDialog = null
    }

    /** Hentikan suara saja (dialog dibiarkan). */
    fun hentikanSuara() = hentikan(false)

    // =====================================================================================
    //  Bagikan
    // =====================================================================================

    private fun alamatBisaDibagikan(u: Uri): Uri? {
        if (u.scheme != "file") return u
        val f = File(u.path ?: return null)
        if (!f.exists()) return null
        return try {
            FileProvider.getUriForFile(act, act.packageName + ".berkas", f)
        } catch (_: Exception) { null }
    }

    /** Tahap 57: pilih WhatsApp atau WhatsApp Business, buka obrolan, lalu rekam, putar, dan kirim otomatis. */
    private fun kirimWa(h: Hasil) {
        val u = alamatBisaDibagikan(h.uri)
        if (u == null) {
            tvStatus?.text = "Berkas tidak ditemukan, tidak bisa dikirim."
            return
        }
        // Layanan memutar berkas dari proses ini, jadi alamat aslinya cukup (file atau content milik aplikasi).
        com.novan.audiolabnovan.wa.WaKirim.mulai(act, h.uri, h.nama) { tvStatus?.text = it }
    }

    /** Tahap 62: pilih WhatsApp atau WhatsApp Business, buka halaman status suara, lalu rekam (tahan), putar, dan kirim otomatis. */
    private fun kirimStatusWa(h: Hasil) {
        val u = alamatBisaDibagikan(h.uri)
        if (u == null) {
            tvStatus?.text = "Berkas tidak ditemukan, tidak bisa dibagikan ke status."
            return
        }
        com.novan.audiolabnovan.wa.WaKirim.mulaiStatus(act, h.uri, h.nama) { tvStatus?.text = it }
    }

    /** Tahap 58: atur jeda (detik) antara perekaman WhatsApp mulai dan audio diputar. */
    private fun aturJedaWa() {
        var pesan = ""
        com.novan.audiolabnovan.wa.WaKirim.aturJeda(act, { pesan = it; tvStatus?.text = it }) {
            // Segarkan teks tombol (nilai jeda baru) dengan membuka ulang menu berkas yang sama.
            sekarang?.let { h ->
                menu(h)
                tvStatus?.text = pesan
            }
        }
    }

    private fun bagikan(h: Hasil) {
        val u = alamatBisaDibagikan(h.uri)
        if (u == null) {
            tvStatus?.text = "Berkas tidak ditemukan, tidak bisa dibagikan."
            return
        }
        try {
            val kirim = Intent(Intent.ACTION_SEND).apply {
                type = h.mime
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            act.startActivity(Intent.createChooser(kirim, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            tvStatus?.text = "Menu Bagikan tidak bisa dibuka: ${e.message ?: "galat"}"
        }
    }

    // =====================================================================================
    //  Ubah nama
    // =====================================================================================

    private fun tanyaNama(h: Hasil) {
        val et = EditText(act).apply {
            setText(h.nama.substringBeforeLast('.', h.nama))
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT
            contentDescription = "Nama baru, tanpa ekstensi"
        }
        val pad = FrameLike(et)
        val dlg = AlertDialog.Builder(act)
            .setTitle("Ubah nama")
            .setMessage("Ketik nama baru tanpa ekstensi.")
            .setView(pad)
            .setPositiveButton("Simpan") { _, _ -> ubahNama(h, et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .create()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    private fun FrameLike(v: View): View = LinearLayout(act).apply {
        setPadding(dp(20), dp(4), dp(20), 0)
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun namaTampil(u: Uri, cadangan: String): String {
        if (u.scheme == "file") return File(u.path ?: return cadangan).name
        try {
            act.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i) ?: cadangan
                }
            }
        } catch (_: Exception) { }
        return cadangan
    }

    private fun ubahNama(h: Hasil, diketik: String) {
        val bersih = diketik.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        if (bersih.isEmpty()) {
            tvStatus?.text = "Nama tidak boleh kosong."
            return
        }
        val ekst = h.nama.substringAfterLast('.', "")
        val baru = if (ekst.isEmpty()) bersih else "$bersih.$ekst"
        if (baru == h.nama) { tvStatus?.text = "Nama tidak berubah."; return }
        try {
            when {
                h.uri.scheme == "file" -> {
                    val lama = File(h.uri.path ?: throw java.io.IOException("alamat berkas kosong"))
                    val tujuan = File(lama.parentFile, baru)
                    if (tujuan.exists()) throw java.io.IOException("nama itu sudah dipakai")
                    if (!lama.renameTo(tujuan)) throw java.io.IOException("sistem menolak")
                    h.uri = Uri.fromFile(tujuan)
                }
                DocumentsContract.isDocumentUri(act, h.uri) -> {
                    h.uri = DocumentsContract.renameDocument(act.contentResolver, h.uri, baru)
                        ?: throw java.io.IOException("sistem menolak")
                }
                else -> {
                    val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, baru) }
                    if (act.contentResolver.update(h.uri, cv, null, null) <= 0) throw java.io.IOException("sistem menolak")
                }
            }
            h.nama = namaTampil(h.uri, baru)
            ubahJudul(h)
            tvStatus?.text = "Nama diubah menjadi ${h.nama}."
            saatDiubah?.invoke(h)
        } catch (e: Exception) {
            tvStatus?.text = "Gagal mengubah nama. Mungkin nama itu sudah dipakai. ${e.message ?: ""}"
        }
    }

    // =====================================================================================
    //  Edit file (tahap 61)
    // =====================================================================================

    /** Pilih cara mengedit lagi berkas hasil: di layar utama (semua pengaturan) atau Pengubah Suara. */
    private fun tanyaEdit(h: Hasil) {
        val adaAudio = !h.mime.startsWith("video")
        val nama = ArrayList<String>()
        val aksi = ArrayList<() -> Unit>()
        nama += "Edit di layar utama (potong, kecepatan, volume, ekualiser, efek, format)"
        aksi += { editDiLayarUtama(h) }
        if (adaAudio) {
            nama += "Edit dengan Pengubah Suara"
            aksi += { editDenganPengubahSuara(h) }
        }
        if (nama.size == 1) { editDiLayarUtama(h); return }
        AlertDialog.Builder(act)
            .setTitle("Edit file: ${h.nama}")
            .setItems(nama.toTypedArray()) { _, i -> aksi[i]() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun tutupDialogUntukEdit() {
        hentikan(false)
        try { dialog?.dismiss() } catch (_: Exception) { }
        try { daftarDialog?.dismiss() } catch (_: Exception) { }
        dialog = null
        daftarDialog = null
    }

    /** Berkas hasil dijadikan berkas terpilih di layar utama, jadi semua pengaturan bisa dipakai lagi. */
    private fun editDiLayarUtama(h: Hasil) {
        val u = alamatBisaDibagikan(h.uri)
        if (u == null) {
            tvStatus?.text = "Berkas tidak ditemukan, tidak bisa diedit."
            return
        }
        try {
            val i = Intent(act, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                setDataAndType(u, h.mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            tutupDialogUntukEdit()
            act.startActivity(i)
            cakap("${h.nama} dibuka di layar utama untuk diedit.")
        } catch (e: Exception) {
            tvStatus?.text = "Gagal membuka untuk diedit: ${e.message ?: "galat"}"
        }
    }

    /** Berkas hasil dibuka di Pengubah Suara sebagai sumber. */
    private fun editDenganPengubahSuara(h: Hasil) {
        try {
            val i = Intent(act, com.novan.audiolabnovan.ubah.PengubahSuaraActivity::class.java)
                .putExtra(com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_URI, h.uri.toString())
                .putExtra(com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_NAMA, h.nama)
            tutupDialogUntukEdit()
            act.startActivity(i)
        } catch (e: Exception) {
            tvStatus?.text = "Gagal membuka Pengubah Suara: ${e.message ?: "galat"}"
        }
    }

    // =====================================================================================
    //  Hapus
    // =====================================================================================

    private fun tanyaHapus(h: Hasil) {
        AlertDialog.Builder(act)
            .setTitle("Hapus berkas?")
            .setMessage("${h.nama} akan dihapus dari penyimpanan.")
            .setPositiveButton("Hapus") { _, _ -> hapus(h) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun hapus(h: Hasil) {
        val ok = try {
            when {
                h.uri.scheme == "file" -> File(h.uri.path ?: "").delete()
                DocumentsContract.isDocumentUri(act, h.uri) -> DocumentsContract.deleteDocument(act.contentResolver, h.uri)
                else -> act.contentResolver.delete(h.uri, null, null) > 0
            }
        } catch (_: Exception) { false }
        if (!ok) {
            tvStatus?.text = "Gagal menghapus ${h.nama}."
            return
        }
        cakap("${h.nama} sudah dihapus.")
        saatDihapus?.invoke(h)
        daftar = daftar.filter { it !== h }
        hentikan(false)
        try { dialog?.dismiss() } catch (_: Exception) { }
        dialog = null
        if (dariDaftar && daftar.isNotEmpty()) tampilDaftar("Proses selesai")
    }
}
