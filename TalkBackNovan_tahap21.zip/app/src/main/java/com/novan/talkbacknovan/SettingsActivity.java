package com.novan.talkbacknovan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {
    private SharedPreferences sp;
    private LinearLayout kolom;
    private Button tombolGema;
    private Button tombolMesin;

    private static final String[] NAMA_GEMA = {"Tidak ada", "Karakter", "Kata", "Karakter dan kata"};

    public static final String EXTRA_HALAMAN = "halaman";

    static final String[][] MENU_UTAMA = {
            {"cari", "Cari"},
            {"umum", "Pengaturan umum"},
            {"tts", "Pengaturan teks ke ucapan"},
            {"umpan", "Pengaturan umpan balik"},
            {"tindakan", "Pengaturan tindakan"},
            {"konten", "Pengaturan pengucapan konten"},
            {"notifikasi", "Pengaturan pemberitahuan"},
            {"lanjutan", "Pengaturan lanjutan"},
            {"ekstensi", "Ekstensi"},
            {"alat", "Plugin dan peralatan"},
            {"lainnya", "Pengaturan lainnya"},
    };

    /** Halaman yang ikut dicari oleh menu Cari. */
    private static final String[] INDEKS = {
            "umum", "tts", "umpan", "tindakan", "gdefault", "alternatif", "gerakan", "gestur1", "gestur2", "gestur3",
            "deskripsi", "kelola", "pintasan",
            "konten", "label", "notifikasi", "lanjutan", "ocr", "masukan", "jamtimer", "jamtts", "cadang", "alat", "lainnya", "bantuan"
    };

    private static String judulHalaman(String h) {
        for (String[] m : MENU_UTAMA) if (m[0].equals(h)) return m[1];
        if (h.startsWith("segera:")) return h.substring(7);
        switch (h) {
            case "asisten": return "Pengaturan asisten suara";
            case "jamtimer": return "Pengaturan Jam dan Timer";
            case "jamtts": return "Pengaturan TTS jam dan timer";
            case "kelolatimer": return "Kelola timer";
            case "cadang": return "Kelola Pencadangan dan pemulihan";
            case "gestur1": return "Pengaturan gestur satu jari";
            case "gestur2": return "Pengaturan gestur dua jari";
            case "gestur3": return "Pengaturan gestur tiga dan empat jari";
            case "gdefault": return "Pengaturan Gestur Default";
            case "alternatif": return "Pengaturan gerakan alternatif";
            case "gerakan": return "Pengaturan gerakan";
            case "gulir": return "Pengaturan pengguliran";
            case "deskripsi": return "Deskripsi gerakan";
            case "kelola": return "Kelola gerakan";
            case "pintasan": return "Pengaturan tombol pintasan";
            case "ocr": return "Pengaturan OCR";
            case "masukan": return "Pengaturan metode masukan";
            case "label": return "Pengaturan kustom konten fokus";
            case "bantuan": return "Bantuan dan umpan balik";
            default: return "Pengaturan TalkBack Novan";
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tombolWallpaper != null) perbaruiWallpaper();
        if (teksTimer != null) perbaruiStatusTimer();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = Prefs.get(this);
        String halaman = getIntent().getStringExtra(EXTRA_HALAMAN);
        if (halaman == null) halaman = "";
        setTitle(halaman.isEmpty() ? "Pengaturan" : judulHalaman(halaman));

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        kolom.setPadding(pad, pad, pad, pad);

        if (halaman.isEmpty()) {
            for (String[] m : MENU_UTAMA) tambahMenu(m[1], m[0]);
        } else {
            bangunHalaman(halaman);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(kolom);
        setContentView(sv);
    }

    private void bangunHalaman(String halaman) {
        if (halaman.startsWith("segera:")) {
            halamanSegera(halaman.substring(7));
            return;
        }
        switch (halaman) {
            case "asisten": halamanAsisten(); break;
            case "jamtimer": halamanJamTimer(); break;
            case "jamtts": halamanJamTts(); break;
            case "kelolatimer": halamanKelolaTimer(); break;
            case "cadang": halamanCadang(); break;
            case "cari": halamanCari(); break;
            case "umum": halamanUmum(); break;
            case "tts": halamanTts(); break;
            case "umpan": halamanUmpan(); break;
            case "tindakan": halamanTindakan(); break;
            case "gestur1": halamanGestur1(); break;
            case "gestur2": halamanGestur2(); break;
            case "gestur3": halamanGestur3(); break;
            case "gdefault": halamanGdefault(); break;
            case "alternatif": halamanAlternatif(); break;
            case "gerakan": halamanGerakan(); break;
            case "gulir": halamanGulir(); break;
            case "deskripsi": halamanDeskripsi(); break;
            case "kelola": halamanKelola(); break;
            case "pintasan": halamanPintasan(); break;
            case "konten": halamanKonten(); break;
            case "label": halamanLabel(); break;
            case "notifikasi": halamanNotifikasi(); break;
            case "lanjutan": halamanLanjutan(); break;
            case "ocr": halamanOcr(); break;
            case "masukan": halamanMasukan(); break;
            case "alat": halamanAlat(); break;
            case "lainnya": halamanLainnya(); break;
            case "bantuan": halamanBantuan(); break;
            default:
                for (String[] m : MENU_UTAMA) tambahMenu(m[1], m[0]);
                break;
        }
    }

    private void halamanCari() {
        final android.widget.EditText kotak = new android.widget.EditText(this);
        kotak.setHint("Cari pengaturan");
        kotak.setSingleLine(true);
        kolom.addView(kotak);
        final LinearLayout hasil = new LinearLayout(this);
        hasil.setOrientation(LinearLayout.VERTICAL);
        kolom.addView(hasil);
        final List<String[]> indeks = bangunIndeks();
        kotak.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                tampilkanHasil(hasil, indeks, e.toString());
            }
        });
    }

    /** Kumpulkan semua teks pengaturan dari tiap halaman: {teks, halaman}. */
    private List<String[]> bangunIndeks() {
        List<String[]> daftar = new ArrayList<>();
        LinearLayout asli = kolom;
        for (String k : INDEKS) {
            kolom = new LinearLayout(this);
            bangunHalaman(k);
            for (int i = 0; i < kolom.getChildCount(); i++) {
                View v = kolom.getChildAt(i);
                if (!(v instanceof TextView)) continue;
                CharSequence t = ((TextView) v).getText();
                if (t == null || t.length() == 0 || t.length() > 120) continue;
                daftar.add(new String[]{t.toString(), k});
            }
        }
        kolom = asli;
        return daftar;
    }

    private void tampilkanHasil(LinearLayout hasil, List<String[]> indeks, String kata) {
        hasil.removeAllViews();
        String[] bagian = kata.trim().toLowerCase(java.util.Locale.getDefault()).split("\\s+");
        if (bagian.length == 1 && bagian[0].isEmpty()) return;
        int jumlah = 0;
        for (final String[] x : indeks) {
            String teks = x[0].toLowerCase(java.util.Locale.getDefault());
            boolean cocok = true;
            for (String b : bagian) if (!teks.contains(b)) cocok = false;
            if (!cocok) continue;
            Button b = new Button(this);
            b.setText(x[0] + " (" + judulHalaman(x[1]) + ")");
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new android.content.Intent(SettingsActivity.this, SettingsActivity.class)
                            .putExtra(EXTRA_HALAMAN, x[1]));
                }
            });
            hasil.addView(b);
            if (++jumlah >= 40) break;
        }
        if (jumlah == 0) {
            TextView t = new TextView(this);
            t.setText("Tidak ada hasil");
            t.setTextSize(18);
            hasil.addView(t);
        }
    }

    private void halamanAlat() {
        tambahUjiSuara();
        Button n = new Button(this);
        n.setText("Beri akses notifikasi");
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(
                        android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        kolom.addView(n);
    }

    private void halamanLainnya() {
        TextView status = new TextView(this);
        status.setTextSize(18);
        status.setText(MainActivity.layananAktif(this)
                ? "Status: TalkBack Novan aktif."
                : "Status: belum aktif. Buka pengaturan aksesibilitas, pilih TalkBack Novan, lalu nyalakan.");
        kolom.addView(status);
        Button a = new Button(this);
        a.setText("Buka pengaturan aksesibilitas");
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        kolom.addView(a);
        tambahMenu("Bantuan dan umpan balik", "bantuan");
        TextView versi = new TextView(this);
        versi.setText("TalkBack Novan versi 0.20.0 (tahap 20)");
        versi.setPadding(0, (int) (16 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(versi);
    }

    /** Tombol yang membuka halaman pengaturan lain (seperti daftar menu di JieShuo). */
    private void tambahMenu(String label, final String halaman) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (halaman.equals("ekstensi")) {
                    startActivity(new android.content.Intent(SettingsActivity.this, PluginActivity.class));
                    return;
                }
                if (halaman.equals("aksesibilitas")) {
                    startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                startActivity(new android.content.Intent(SettingsActivity.this, SettingsActivity.class)
                        .putExtra(EXTRA_HALAMAN, halaman));
            }
        });
        kolom.addView(b);
    }

    private void halamanUmum() {
        tambahMenu("Panduan", "bantuan");
        tambahGeser("Kecepatan teks ke ucapan", Prefs.K_LAJU, 50, 300, 100);
        tambahGeser("Volume teks ke ucapan", Prefs.K_VOL_TTS, 10, 100, 100);
        tambahSakelar("Baca petunjuk penggunaan", Prefs.K_PETUNJUK, true);
        tambahSakelar("Baca daftar item", Prefs.K_GULIR_INFO, true);
        tambahSakelar("Baca pemberitahuan dari panel pemberitahuan", Prefs.K_NOTIF, true);
        tambahSakelar("Gunakan gerakan ke kiri atau ke kanan dengan 1 jari untuk bernavigasi", Prefs.K_USAP_NAV, true);
        TextView ringkas = new TextView(this);
        ringkas.setText("Usap kiri/kanan pindah fokus, atas/bawah fungsi pintas.");
        ringkas.setTextSize(14);
        kolom.addView(ringkas);
        tambahMenu("Pengaturan gerakan yang dibuat", "tindakan");
    }

    private void halamanTts() {
        tombolMesin = new Button(this);
        tombolMesin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihMesin();
            }
        });
        kolom.addView(tombolMesin);
        perbaruiTombolMesin();
        Button sistem = new Button(this);
        sistem.setText("Pengaturan teks ke ucapan");
        sistem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new android.content.Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new android.content.Intent(android.provider.Settings.ACTION_SETTINGS));
                }
            }
        });
        kolom.addView(sistem);
        tambahGeser("Kecepatan teks ke ucapan", Prefs.K_LAJU, 50, 300, 100);
        tambahGeser("Volume teks ke ucapan", Prefs.K_VOL_TTS, 10, 100, 100);
        tambahGeser("Nada teks ke ucapan", Prefs.K_NADA, 50, 200, 100);
        tambahSakelarRingkas("Pengecilan audio", "Kecilkan audio lain saat berbicara.", Prefs.K_DUCK, false);
        tambahSakelarRingkas("Gunakan sensor kedekatan", "Berhenti membaca saat sensor kedekatan ditutup.",
                Prefs.K_JARAK, false);
        tambahSakelar("Sentuh layar untuk menghentikan ucapan", Prefs.K_SENTUH_DIAM, false);
    }

    private void tambahSakelarRingkas(String label, String ringkas, String kunci, boolean awal) {
        tambahSakelar(label, kunci, awal);
        TextView t = new TextView(this);
        t.setText(ringkas);
        t.setTextSize(14);
        kolom.addView(t);
    }

    private void halamanUmpan() {
        tambahSakelar("Gunakan umpan balik suara", Prefs.K_EFEK, true);
        tambahGeser("Volume tema suara", Prefs.K_EFEK_VOL, 5, 100, 60);
        tambahTombolDaftar("Aplikasi yang tidak memakai efek suara", Prefs.K_HITAM_EFEK);
        tambahSakelar("Umpan balik getaran", Prefs.K_GETAR, true);
        tambahGeser("Intensitas getaran", Prefs.K_GETAR_KUAT, 1, 255, 32, " dari 255");
        tambahGeser("Lama getaran", Prefs.K_GETAR_LAMA, 5, 100, 15, " milidetik");
    }

    /** Daftar dan urutannya sama dengan "Pengaturan tindakan" di JieShuo Lite. */
    private void halamanTindakan() {
        tambahBaris("Pengaturan Gestur Default.",
                "Kelola pengaturan skema gerakan yang diatur sebagai fungsi default, "
                        + "atau skema kustom yang menjalankan fungsi default.", "gdefault", true);
        Button tema = new Button(this);
        tema.setAllCaps(false);
        tema.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
        tema.setText("Tema gerakan:\nnovan");
        tema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Tema gerakan")
                        .setSingleChoiceItems(new String[]{"novan"}, 0, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                d.dismiss();
                            }
                        })
                        .setMessage("Baru ada satu tema. Tema lain dijadwalkan untuk tahap berikutnya.")
                        .show();
            }
        });
        kolom.addView(tema);
        tambahBaris("Pengaturan gerakan", "novan", "gerakan", true);
        tambahBaris("Deskripsi gerakan", null, "deskripsi", true);
        tambahBaris("Kelola gerakan", null, "kelola", true);
        tambahBaris("Tema gerakan per-aplikasi.", null, "segera:Tema gerakan per-aplikasi", false);
        tambahBaris("Pengaturan mode permainan", null, "segera:Pengaturan mode permainan", true);
        tambahBaris("Pengaturan pengguliran", null, "gulir", true);
        tambahBaris("Pengaturan tindakan ketuk", null, "segera:Pengaturan tindakan ketuk", true);
        tambahBaris("Pengaturan tombol pintasan", null, "pintasan", true);
        tambahBaris("Pengaturan tombol pintasan buatan", null, "segera:Pengaturan tombol pintasan buatan", true);
        tambahBaris("Pengaturan gerakan sidik jari", null, "segera:Pengaturan gerakan sidik jari", true);
        tambahBaris("Pengaturan lainnya", null, "segera:Pengaturan lainnya", true);
    }

    private void halamanGdefault() {
        tambahSakelar("Jelajah menurut jenis navigasi di semua tampilan (atas/bawah ganti jenis, kiri/kanan pindah item)",
                Prefs.K_NAV_JENIS, true);
        tambahSakelar("Tetap pada jenis navigasi saat jendela berubah", Prefs.K_JENIS_TETAP, false);
        tambahTombolJenisNavigasi();
        tambahMenu("Pengaturan gerakan alternatif", "alternatif");
    }

    private void halamanAlternatif() {
        tambahSakelar("Pindahkan kursor di kotak edit yang aktif", Prefs.K_GERAK_KURSOR, true);
        tambahSakelar("Sesuaikan kemajuan pada penggeser", Prefs.K_GERAK_PENGGESER, true);
        tambahSakelar("Gulir daftar di dalam daftar", Prefs.K_GERAK_GULIR, true);
        tambahSakelar("Gunakan gerakan multi jari", Prefs.K_MULTI_JARI, true);
    }

    /** Daftar dan urutannya sama dengan "Pengaturan pengguliran" di JieShuo Lite. */
    private void halamanGulir() {
        tambahSakelar("Gunakan item daftar untuk berpindah dengan cepat antar item di Penjelajahan Otomatis.",
                Prefs.K_GULIR_ITEM_DAFTAR, false);
        tambahSakelarRingkas("Jelajahi lebih banyak fokus:",
                "Anda dapat memilih untuk menyalakannya atau tidak, tergantung pada kebutuhan anda",
                Prefs.K_GULIR_LEBIH, true);
        tambahSakelarRingkas("Mode kecepatan:",
                "Setelah diaktifkan, perangkat lunak yang didukung merespons lebih cepat. "
                        + "Jika Anda menemukan ketidakcocokan, Anda dapat menonaktifkan opsi ini",
                Prefs.K_GULIR_CEPAT, false);
        tambahSakelar("Gunakan navigasi loop:", Prefs.K_GULIR_LOOP, true);
        tambahSakelar("Menambahkan promt kosong sebelum loop fokus:", Prefs.K_GULIR_LOOP_JEDA, false);
        tambahSakelarRingkas("Gunakan penjelajahan web default baru.",
                "Metode gerakan fokus halaman web baru dapat mendapat kecepatan penelusuran yang lebih cepat, "
                        + "tetapi juga dapat menyebabkan ketidakcocokan. Jika gerakan fokus halaman web tidak normal "
                        + "setelah digunakan, harap matikan opsi ini.",
                Prefs.K_GULIR_WEB_BARU, false);
        tambahSakelarRingkas("Gulir halaman secara otomatis:",
                "Gulir secara otomatis ke halaman berikutnya ketika Anda mencapai akhir halaman",
                Prefs.K_GULIR_HALAMAN, false);
        tambahSakelar("Pengalihan jendela otomatis.", Prefs.K_GULIR_JENDELA, false);
        tambahSakelar("Gunakan mode penelusuran object (hanya pengguna tingkat lanjut)",
                Prefs.K_GULIR_OBJEK, false);
    }

    private void halamanGerakan() {
        tambahMenu("Gestur satu jari", "gestur1");
        tambahMenu("Gestur dua jari", "gestur2");
        tambahMenu("Gestur tiga dan empat jari", "gestur3");
    }

    private static final String[][] GESTUR_BANYAK_JARI = {
            {"Usap atas dua jari", Prefs.G2_ATAS}, {"Usap bawah dua jari", Prefs.G2_BAWAH},
            {"Usap kiri dua jari", Prefs.G2_KIRI}, {"Usap kanan dua jari", Prefs.G2_KANAN},
            {"Ketuk dua kali dua jari", Prefs.G2_KETUK2},
            {"Ketuk tiga jari", Prefs.G3_KETUK}, {"Ketuk dua kali tiga jari", Prefs.G3_KETUK2},
            {"Usap atas tiga jari", Prefs.G3_ATAS}, {"Usap bawah tiga jari", Prefs.G3_BAWAH},
            {"Usap kiri tiga jari", Prefs.G3_KIRI}, {"Usap kanan tiga jari", Prefs.G3_KANAN},
    };

    private void tambahTeks(String teks) {
        TextView t = new TextView(this);
        t.setText(teks);
        t.setTextSize(16);
        t.setPadding(0, (int) (6 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
    }

    private void halamanDeskripsi() {
        tambahTeks("Ketuk dua jari: hentikan suara");
        for (String[] g : GESTUR_BANYAK_JARI) {
            tambahTeks(g[0] + ": " + Aksi.NAMA[Prefs.aksi(this, g[1])]);
        }
        for (int i = 0; i < Gestur.jumlah(); i++) {
            tambahTeks(Gestur.nama(i) + ": " + Aksi.NAMA[Prefs.aksi(this, Gestur.kunciPref(i))]);
        }
    }

    private void halamanKelola() {
        Button b = new Button(this);
        b.setText("Kembalikan semua gerakan ke bawaan");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Kembalikan gerakan")
                        .setMessage("Semua gerakan kembali ke bawaan?")
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                SharedPreferences.Editor e = sp.edit();
                                for (String k : new ArrayList<>(sp.getAll().keySet())) {
                                    if (k.startsWith("gx_") || k.startsWith("g2_") || k.startsWith("g3_")) e.remove(k);
                                }
                                e.apply();
                                android.widget.Toast.makeText(SettingsActivity.this,
                                        "Gerakan dikembalikan ke bawaan", android.widget.Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void halamanPintasan() {
        tambahSakelar("Gunakan tombol volume sebagai tombol pintasan", Prefs.K_VOLUME, true);
        tambahSakelar("Gunakan tombol headset untuk mengontrol pembaca layar", Prefs.K_HEADSET, false);
        tambahAksi("Tekan lama volume atas", Prefs.VOL_ATAS);
        tambahAksi("Tekan lama volume bawah", Prefs.VOL_BAWAH);
        tambahAksi("Dua kali klik volume naik", Prefs.VA_KLIK2);
        tambahAksi("Tiga kali klik volume naik", Prefs.VA_KLIK3);
        tambahAksi("Dua kali klik volume turun", Prefs.VB_KLIK2);
        tambahAksi("Tiga kali klik volume turun", Prefs.VB_KLIK3);
        tambahAksi("Tombol headset: klik sekali", Prefs.HS_KLIK);
        tambahAksi("Tombol headset: klik dua kali", Prefs.HS_KLIK2);
        tambahAksi("Tombol headset: tahan", Prefs.HS_LAMA);
    }

    private void halamanGestur1() {
        tambahSakelar("Usap kiri/kanan pindah fokus, atas/bawah fungsi pintas", Prefs.K_USAP_NAV, true);
        for (int g = 0; g < Gestur.JUMLAH_SATU_JARI; g++) {
            tambahAksi(Gestur.nama(g), Gestur.kunciPref(g));
        }
    }

    private void halamanGestur2() {
        tambahAksi("Usap atas dua jari", Prefs.G2_ATAS);
        tambahAksi("Usap bawah dua jari", Prefs.G2_BAWAH);
        tambahAksi("Usap kiri dua jari", Prefs.G2_KIRI);
        tambahAksi("Usap kanan dua jari", Prefs.G2_KANAN);
        tambahAksi("Ketuk dua kali dua jari", Prefs.G2_KETUK2);
    }

    private void halamanGestur3() {
        tambahAksi("Ketuk tiga jari", Prefs.G3_KETUK);
        tambahAksi("Ketuk dua kali tiga jari", Prefs.G3_KETUK2);
        tambahAksi("Usap atas tiga jari", Prefs.G3_ATAS);
        tambahAksi("Usap bawah tiga jari", Prefs.G3_BAWAH);
        tambahAksi("Usap kiri tiga jari", Prefs.G3_KIRI);
        tambahAksi("Usap kanan tiga jari", Prefs.G3_KANAN);
        bagian("Gestur tiga dan empat jari lainnya");
        for (int g = Gestur.JUMLAH_SATU_JARI; g < Gestur.jumlah(); g++) {
            tambahAksi(Gestur.nama(g), Gestur.kunciPref(g));
        }
    }

    private void halamanKonten() {
        bagian("Pengaturan pengucapan label");
        tambahSakelar("Bacakan jenis dan status kontrol yang difokuskan", Prefs.K_PERAN, true);
        tambahSakelar("Bacakan emoji dengan nama bahasa Indonesia", Prefs.K_EMOJI, true);
        bagian("Pengaturan pengucapan konten yang berubah");
        tambahSakelar("Bacakan perubahan judul jendela dan dialog", Prefs.K_JENDELA, true);
        tambahSakelar("Bacakan notifikasi dan pesan toast", Prefs.K_NOTIF, true);
        bagian("Pengaturan daftar");
        tambahSakelar("Baca posisi daftar saat digulir", Prefs.K_GULIR_INFO, true);
        bagian("Pengaturan layar hidup dan mati");
        tambahSakelar("Ucapkan waktu saat layar hidup", Prefs.K_LAYAR_HIDUP, true);
        tambahSakelar("Ucapkan persentase baterai saat layar hidup", Prefs.K_LAYAR_BATERAI, false);
        tambahSakelar("Ucapkan \"Layar mati\" saat layar dimatikan", Prefs.K_LAYAR_MATI, true);
        tambahMenu("Pengaturan kustom konten fokus", "label");
    }

    private void halamanLabel() {
        Button aturan = new Button(this);
        aturan.setText("Manajemen nama fokus (aturan ganti nama)");
        aturan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ubahAturanNama();
            }
        });
        kolom.addView(aturan);
    }

    private void halamanNotifikasi() {
        tambahSakelar("Baca pemberitahuan timbul dan pesan toast", Prefs.K_NOTIF, true);
        tambahSakelar("Baca pesan toast", Prefs.K_NOTIF_TOAST, true);
        tambahSakelar("Baca pengumuman dari aplikasi", Prefs.K_NOTIF_UMUM, true);
        tambahSakelar("Baca sumber pemberitahuan (nama aplikasi)", Prefs.K_NOTIF_APP, true);
        tambahSakelar("Baca ringkas: hanya nama aplikasi dan judul", Prefs.K_NOTIF_RINGKAS, false);
        tambahSakelar("Jangan baca pemberitahuan saat layar sedang disentuh", Prefs.K_NOTIF_DIAM_SENTUH, false);
        tambahSakelar("Jangan baca pemberitahuan saat telepon berdering atau berlangsung", Prefs.K_NOTIF_DIAM_TELEPON, false);
        tambahTombolDaftar("Daftar putih pemberitahuan (bila terisi, hanya aplikasi ini yang dibacakan)", Prefs.K_PUTIH_NOTIF);
        tambahTombolDaftar("Daftar hitam pemberitahuan (aplikasi yang notifikasinya diam)", Prefs.K_HITAM_NOTIF);
        tambahTombolDaftar("Daftar hitam konten pembacaan otomatis (perubahan isi, gulir, pengumuman)", Prefs.K_HITAM_OTOMATIS);
    }

    private static final String RINGKAS_PROFILES = "Profiles dapat dikonfigurasi dengan pengaturan independen, "
            + "dalam profiles yang berbeda, yang nyaman untuk menggunakan pembacaan layar dalam setelan yang berbeda";
    private static final String RINGKAS_WALLPAPER = "Karena beberapa ponsel mungkin mengalami masalah layar mati "
            + "di latar belakang, Anda dapat mengatur TalkBack Novan sebagai wallpaper untuk meningkatkan "
            + "stabilitas latar belakang.";

    private Button tombolWallpaper;
    private TextView teksTimer;

    /** Daftar dan urutannya sama dengan "Pengaturan lanjutan" di JieShuo Lite. */
    private void halamanLanjutan() {
        tambahBaris("Pengaturan asisten suara", null, "asisten", true);
        tambahBaris("Pengaturan OCR", null, "ocr", true);
        tambahBaris("Pengaturan Jam dan Timer", null, "jamtimer", true);
        tambahBaris("Pengaturan Aksi", null, "tindakan", true);
        tambahBaris("Pengaturan metode masukan", null, "masukan", true);
        tambahBaris("Pengaturan menu", null, "segera:Pengaturan menu", true);
        tambahBaris("Pengaturan mode baca", null, "segera:Pengaturan mode baca", true);
        tambahBaris("Pengaturan plugin otomatis", null, "ekstensi", !PluginManager.daftar(this).isEmpty());
        tambahBaris("Pengaturan jadwal tugas", null, "segera:Pengaturan jadwal tugas", true);
        tambahBaris("Profiles.", RINGKAS_PROFILES, "segera:Profiles", true);
        tambahBaris("Kelola data", null, "segera:Kelola data", true);
        tambahBaris("Kelola Pencadangan dan pemulihan", null, "cadang", true);
        tambahBaris("Kelola bahasa", null, "segera:Kelola bahasa", true);
        tambahBaris("Pengaturan daya", null, "segera:Pengaturan daya", true);
        tambahBaris("Pengaturan lainnya", null, "segera:Pengaturan lainnya", true);
        tombolWallpaper = new Button(this);
        tombolWallpaper.setAllCaps(false);
        tombolWallpaper.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
        tombolWallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaWallpaper();
            }
        });
        kolom.addView(tombolWallpaper);
        perbaruiWallpaper();
    }

    /** Baris menu dengan judul dan ringkasan (seperti daftar pengaturan JieShuo). */
    private Button tambahBaris(String judul, String ringkas, final String halaman, boolean aktif) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
        b.setText(ringkas == null ? judul : judul + "\n" + ringkas);
        b.setEnabled(aktif);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaHalaman(halaman);
            }
        });
        kolom.addView(b);
        return b;
    }

    private void bukaHalaman(String halaman) {
        if (halaman.equals("ekstensi")) {
            startActivity(new android.content.Intent(this, PluginActivity.class));
            return;
        }
        startActivity(new android.content.Intent(this, SettingsActivity.class)
                .putExtra(EXTRA_HALAMAN, halaman));
    }

    private boolean wallpaperAktif() {
        try {
            android.app.WallpaperInfo info = android.app.WallpaperManager.getInstance(this).getWallpaperInfo();
            return info != null && getPackageName().equals(info.getPackageName())
                    && NovanWallpaper.class.getName().equals(info.getServiceName());
        } catch (Exception e) {
            return false;
        }
    }

    private void perbaruiWallpaper() {
        tombolWallpaper.setText("Wallpaper TalkBack Novan. " + (wallpaperAktif() ? "Aktif." : "Nonaktif.")
                + "\n" + RINGKAS_WALLPAPER);
    }

    private void bukaWallpaper() {
        try {
            startActivity(new android.content.Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            new android.content.ComponentName(this, NovanWallpaper.class)));
        } catch (Exception e) {
            try {
                startActivity(new android.content.Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (Exception ignore) {
                android.widget.Toast.makeText(this, "Ponsel ini tidak punya pemilih wallpaper hidup.",
                        android.widget.Toast.LENGTH_LONG).show();
            }
        }
    }

    /** Halaman untuk fitur yang belum dibuat di tahap ini. */
    private void halamanSegera(String nama) {
        tambahTeks(nama + " belum tersedia di TalkBack Novan. Fitur ini dijadwalkan untuk tahap berikutnya.");
    }

    private void halamanAsisten() {
        tambahTeks("Perintah suara dipicu lewat gestur (bawaan: ketuk empat jari) dan memakai pengenal suara "
                + "bawaan sistem. Anda bisa mengganti gestur pemicunya di pengaturan gestur.");
        tambahMenu("Pengaturan gestur tiga dan empat jari", "gestur3");
    }

    // ------------------------------------------------------------------ jam dan timer

    private void halamanJamTimer() {
        tambahBaris("Pengaturan TTS jam dan timer", null, "jamtts", true);
        tambahSakelarRingkas("Jam bicara", "Umumkan waktu yang ditentukan.", Prefs.K_ALARM, false);
        tambahPilihan("Interval waktu", Prefs.K_ALARM_INTERVAL, 15,
                new String[]{"Setiap 5 menit", "Setiap 10 menit", "Setiap 15 menit", "Setiap 30 menit", "Setiap 60 menit"},
                new int[]{5, 10, 15, 30, 60});
        tambahTombolJam();
        tambahSakelar("Berbicara saat timer", Prefs.K_TIMER_UCAP, true);
        tambahPilihan("Interval timer", Prefs.K_TIMER_INTERVAL, 10,
                new String[]{"1 menit", "5 menit", "10 menit", "15 menit"}, new int[]{1, 5, 10, 15});
        tambahSakelar("Getaran saat timer", Prefs.K_TIMER_GETAR, true);
        tambahSakelar("Suara pada timer", Prefs.K_TIMER_SUARA, true);
        tambahBaris("Kelola timer", null, "kelolatimer", true);
    }

    /** Tombol yang memunculkan pilihan satu nilai bilangan dan menampilkan pilihan sekarang. */
    private void tambahPilihan(final String label, final String kunci, final int awal,
                               final String[] nama, final int[] nilai) {
        final Button b = new Button(this);
        b.setAllCaps(false);
        kolom.addView(b);
        final Runnable segarkan = new Runnable() {
            @Override
            public void run() {
                int v = sp.getInt(kunci, awal);
                String n = String.valueOf(v);
                for (int i = 0; i < nilai.length; i++) if (nilai[i] == v) n = nama[i];
                b.setText(label + ": " + n);
            }
        };
        segarkan.run();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pilih = 0;
                int sekarang = sp.getInt(kunci, awal);
                for (int i = 0; i < nilai.length; i++) if (nilai[i] == sekarang) pilih = i;
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(label)
                        .setSingleChoiceItems(nama, pilih, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                sp.edit().putInt(kunci, nilai[which]).apply();
                                segarkan.run();
                                d.dismiss();
                            }
                        })
                        .show();
            }
        });
    }

    /** Pilih jam-jam yang dibacakan jam bicara. Tanpa pilihan = semua jam. */
    private void tambahTombolJam() {
        final Button b = new Button(this);
        b.setAllCaps(false);
        kolom.addView(b);
        final Runnable segarkan = new Runnable() {
            @Override
            public void run() {
                int n = Prefs.daftar(SettingsActivity.this, Prefs.K_ALARM_JAM).size();
                b.setText("Waktu berbunyi: " + (n == 0 ? "setiap jam" : n + " jam dipilih"));
            }
        };
        segarkan.run();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] nama = new String[24];
                final boolean[] centang = new boolean[24];
                java.util.Set<String> ada = Prefs.daftar(SettingsActivity.this, Prefs.K_ALARM_JAM);
                for (int i = 0; i < 24; i++) {
                    nama[i] = String.format(java.util.Locale.getDefault(), "Pukul %02d.00", i);
                    centang[i] = ada.contains(String.valueOf(i));
                }
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Waktu berbunyi (kosong = setiap jam)")
                        .setMultiChoiceItems(nama, centang, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which, boolean dicentang) {
                                centang[which] = dicentang;
                            }
                        })
                        .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                java.util.Set<String> baru = new java.util.HashSet<>();
                                for (int i = 0; i < 24; i++) if (centang[i]) baru.add(String.valueOf(i));
                                sp.edit().putStringSet(Prefs.K_ALARM_JAM, baru).apply();
                                segarkan.run();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
    }

    private Button tombolMesinTimer;

    private void halamanJamTts() {
        tombolMesinTimer = new Button(this);
        tombolMesinTimer.setAllCaps(false);
        tombolMesinTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihMesinTimer();
            }
        });
        kolom.addView(tombolMesinTimer);
        perbaruiTombolMesinTimer();
        tambahGeser("Kecepatan teks ke ucapan", Prefs.K_TIMER_LAJU, 50, 300, 100);
        tambahGeser("Volume teks ke ucapan", Prefs.K_TIMER_VOLUME, 0, 100, 100);
        tambahGeser("Nada teks ke ucapan", Prefs.K_TIMER_NADA, 50, 200, 100);
        tambahPilihan("Saluran audio yang digunakan", Prefs.K_TIMER_SALURAN, 0,
                new String[]{"Media", "Alarm", "Aksesibilitas"}, new int[]{0, 1, 2});
    }

    private void perbaruiTombolMesinTimer() {
        String mesin = sp.getString(Prefs.K_TIMER_MESIN, "");
        tombolMesinTimer.setText("Pilih mesin TTS: " + (mesin.isEmpty() ? "bawaan sistem" : mesin));
    }

    private void pilihMesinTimer() {
        final TextToSpeech[] pemegang = new TextToSpeech[1];
        pemegang[0] = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                final List<String> nama = new ArrayList<>();
                final List<String> paket = new ArrayList<>();
                nama.add("Bawaan sistem");
                paket.add("");
                if (status == TextToSpeech.SUCCESS && pemegang[0] != null) {
                    for (TextToSpeech.EngineInfo info : pemegang[0].getEngines()) {
                        nama.add(info.label);
                        paket.add(info.name);
                    }
                }
                if (pemegang[0] != null) pemegang[0].shutdown();
                if (isFinishing() || isDestroyed()) return;
                int terpilih = Math.max(0, paket.indexOf(sp.getString(Prefs.K_TIMER_MESIN, "")));
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Pilih mesin TTS")
                        .setSingleChoiceItems(nama.toArray(new String[0]), terpilih,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putString(Prefs.K_TIMER_MESIN, paket.get(which)).apply();
                                        perbaruiTombolMesinTimer();
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
    }

    /** Kelola timer: mulai hitung mundur, jeda/lanjutkan, hentikan. */
    private void halamanKelolaTimer() {
        teksTimer = new TextView(this);
        teksTimer.setTextSize(18);
        kolom.addView(teksTimer);
        final android.widget.EditText menit = new android.widget.EditText(this);
        menit.setHint("Lama timer dalam menit");
        menit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        menit.setContentDescription("Lama timer dalam menit");
        kolom.addView(menit);
        final android.widget.EditText nama = new android.widget.EditText(this);
        nama.setHint("Nama timer (boleh kosong)");
        nama.setSingleLine(true);
        nama.setContentDescription("Nama timer, boleh kosong");
        kolom.addView(nama);
        Button mulai = new Button(this);
        mulai.setText("Mulai timer");
        mulai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JamTimer jt = JamTimer.ada();
                if (jt == null) {
                    teksTimer.setText("Layanan TalkBack Novan belum aktif. Nyalakan dulu di pengaturan aksesibilitas.");
                    return;
                }
                long m;
                try {
                    m = Long.parseLong(menit.getText().toString().trim());
                } catch (NumberFormatException e) {
                    m = 0;
                }
                if (m <= 0 || m > 24 * 60) {
                    teksTimer.setText("Isi lama timer antara 1 sampai 1440 menit.");
                    return;
                }
                jt.mulaiTimer(m * 60000L, nama.getText().toString().trim());
                perbaruiStatusTimer();
            }
        });
        kolom.addView(mulai);
        Button jeda = new Button(this);
        jeda.setText("Jeda atau lanjutkan timer");
        jeda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JamTimer jt = JamTimer.ada();
                if (jt != null) jt.jedaLanjut();
                perbaruiStatusTimer();
            }
        });
        kolom.addView(jeda);
        Button henti = new Button(this);
        henti.setText("Hentikan timer");
        henti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JamTimer jt = JamTimer.ada();
                if (jt != null) jt.hentikanTimer();
                perbaruiStatusTimer();
            }
        });
        kolom.addView(henti);
        Button segar = new Button(this);
        segar.setText("Periksa sisa waktu");
        segar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                perbaruiStatusTimer();
            }
        });
        kolom.addView(segar);
        perbaruiStatusTimer();
    }

    private void perbaruiStatusTimer() {
        JamTimer jt = JamTimer.ada();
        teksTimer.setText(jt == null
                ? "Layanan TalkBack Novan belum aktif. Nyalakan dulu di pengaturan aksesibilitas."
                : jt.status());
    }

    // ------------------------------------------------------------------ pencadangan

    private java.io.File berkasCadangan() {
        java.io.File dir = new java.io.File(getExternalFilesDir(null), "cadangan");
        if (!dir.exists()) dir.mkdirs();
        return new java.io.File(dir, "pengaturan-talkbacknovan.json");
    }

    private void halamanCadang() {
        tambahTeks("Cadangan disimpan di: Android/data/com.novan.talkbacknovan/files/cadangan/pengaturan-talkbacknovan.json");
        Button cad = new Button(this);
        cad.setText("Cadangkan pengaturan");
        cad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadangkan();
            }
        });
        kolom.addView(cad);
        Button pul = new Button(this);
        pul.setText("Pulihkan pengaturan dari cadangan");
        pul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Pulihkan pengaturan")
                        .setMessage("Semua pengaturan sekarang akan diganti dengan isi cadangan. Lanjutkan?")
                        .setPositiveButton("Pulihkan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                pulihkan();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(pul);
    }

    private void cadangkan() {
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            for (java.util.Map.Entry<String, ?> e : sp.getAll().entrySet()) {
                Object v = e.getValue();
                org.json.JSONObject x = new org.json.JSONObject();
                if (v instanceof Boolean) {
                    x.put("t", "b").put("v", v);
                } else if (v instanceof Integer) {
                    x.put("t", "i").put("v", v);
                } else if (v instanceof Long) {
                    x.put("t", "l").put("v", v);
                } else if (v instanceof Float) {
                    x.put("t", "f").put("v", (double) (Float) v);
                } else if (v instanceof String) {
                    x.put("t", "s").put("v", v);
                } else if (v instanceof java.util.Set) {
                    org.json.JSONArray a = new org.json.JSONArray();
                    for (Object i : (java.util.Set<?>) v) a.put(String.valueOf(i));
                    x.put("t", "h").put("v", a);
                } else {
                    continue;
                }
                o.put(e.getKey(), x);
            }
            java.io.FileOutputStream out = new java.io.FileOutputStream(berkasCadangan());
            try {
                out.write(o.toString(1).getBytes("UTF-8"));
            } finally {
                out.close();
            }
            android.widget.Toast.makeText(this, "Pengaturan dicadangkan: " + o.length() + " butir.",
                    android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Gagal mencadangkan: " + e.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void pulihkan() {
        try {
            java.io.File f = berkasCadangan();
            if (!f.exists()) {
                android.widget.Toast.makeText(this, "Belum ada berkas cadangan.", android.widget.Toast.LENGTH_LONG).show();
                return;
            }
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            try {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            } finally {
                in.close();
            }
            org.json.JSONObject o = new org.json.JSONObject(buf.toString("UTF-8"));
            SharedPreferences.Editor ed = sp.edit();
            ed.clear();
            java.util.Iterator<String> it = o.keys();
            int jumlah = 0;
            while (it.hasNext()) {
                String k = it.next();
                org.json.JSONObject x = o.getJSONObject(k);
                String t = x.getString("t");
                switch (t) {
                    case "b": ed.putBoolean(k, x.getBoolean("v")); break;
                    case "i": ed.putInt(k, x.getInt("v")); break;
                    case "l": ed.putLong(k, x.getLong("v")); break;
                    case "f": ed.putFloat(k, (float) x.getDouble("v")); break;
                    case "s": ed.putString(k, x.getString("v")); break;
                    case "h":
                        org.json.JSONArray a = x.getJSONArray("v");
                        java.util.Set<String> h = new java.util.HashSet<>();
                        for (int i = 0; i < a.length(); i++) h.add(a.getString(i));
                        ed.putStringSet(k, h);
                        break;
                    default: continue;
                }
                jumlah++;
            }
            ed.apply();
            android.widget.Toast.makeText(this, "Pengaturan dipulihkan: " + jumlah + " butir.",
                    android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Gagal memulihkan: " + e.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void halamanOcr() {
        tambahTombolMesinOcr();
        tambahIsian("Kunci API Gemini", Prefs.K_GEMINI_KUNCI, true);
        tambahIsian("Model Gemini", Prefs.K_GEMINI_MODEL, false);
        tambahIsian("Kunci API Groq", Prefs.K_GROQ_KUNCI, true);
        tambahIsian("Model Groq", Prefs.K_GROQ_MODEL, false);
        tambahSakelar("Buka hasil OCR di halaman baca", Prefs.K_OCR_BUKA, false);
    }

    private void halamanMasukan() {
        tombolGema = new Button(this);
        tombolGema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihGema();
            }
        });
        kolom.addView(tombolGema);
        perbaruiTombolGema();
        tambahSakelar("Bacakan tombol saat bernavigasi dengan keyboard", Prefs.K_IME_BACA_TOMBOL, true);
        tambahSakelar("Sebutkan huruf kapital saat bernavigasi dengan keyboard", Prefs.K_IME_KAPITAL, true);
        tambahSakelar("Ucapkan contoh kata dari huruf saat bernavigasi dengan keyboard", Prefs.K_IME_CONTOH, false);
        tambahSakelar("Bacakan karakter yang diketik di kolom kata sandi", Prefs.K_IME_SANDI, true);
    }

    private void halamanBantuan() {
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Gestur bawaan, mirip JieShuo:\n"
                + "Satu jari (bawaan): usap kiri = item sebelumnya; usap kanan = item berikutnya; "
                + "usap atas/bawah = ganti granularitas (fungsi pintas, bisa diganti). "
                + "Bila pilihan usap kiri/kanan dimatikan: atas/bawah pindah item, kiri/kanan menurut konteks.\n"
                + "Dua usapan: atas lalu bawah = fokus terakhir; bawah lalu atas = fokus pertama; "
                + "kiri lalu kanan = aplikasi terbaru; kanan lalu kiri = kembali; atas lalu kanan = menu tindakan; "
                + "bawah lalu kanan = menu utama; atas lalu kiri = ekstensi; bawah lalu kiri = perintah suara; "
                + "kiri lalu bawah = mode per karakter; kanan lalu atas = baca otomatis; "
                + "kiri lalu atas = notifikasi; kanan lalu bawah = daftar elemen layar.\n"
                + "Dua jari: ketuk dua kali = putar atau jeda media; ketuk = hentikan suara.\n"
                + "Tiga jari: usap bawah = notifikasi; atas = beranda; kiri = aplikasi terbaru; kanan = pengaturan cepat; "
                + "ketuk dua kali = baca otomatis.\n"
                + "Empat jari: usap bawah = ke fokus terakhir; atas = ke fokus pertama; kiri = matikan atau nyalakan "
                + "gestur banyak jari; kanan = ketuk dua kali; ketuk dua kali = mode baca.\n"
                + "Semua gestur dan tombol bisa diberi aksi lain di Pengaturan tindakan.");
        kolom.addView(t);
    }

    private void tambahUjiSuara() {
        Button uji = new Button(this);
        uji.setText("Uji suara");
        uji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TalkBackNovanService.ucapkanContoh("Ini contoh suara TalkBack Novan. \uD83D\uDE00");
            }
        });
        kolom.addView(uji);
    }

    private void tambahTombolMesinOcr() {
        final Button b = new Button(this);
        final String[] nama = {"Gemini", "Groq"};
        b.setText("Mesin OCR utama: " + nama[sp.getInt(Prefs.K_OCR_MESIN, 0) == 1 ? 1 : 0]);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Mesin OCR utama")
                        .setSingleChoiceItems(nama, sp.getInt(Prefs.K_OCR_MESIN, 0) == 1 ? 1 : 0,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putInt(Prefs.K_OCR_MESIN, which).apply();
                                        b.setText("Mesin OCR utama: " + nama[which]);
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
        kolom.addView(b);
    }

    /** Tombol yang membuka isian teks (kunci API atau nama model). */
    private void tambahIsian(final String label, final String kunci, final boolean rahasia) {
        final Button b = new Button(this);
        perbaruiIsian(b, label, kunci, rahasia);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final android.widget.EditText e = new android.widget.EditText(SettingsActivity.this);
                e.setSingleLine(true);
                e.setContentDescription(label);
                e.setText(sp.getString(kunci, ""));
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(label)
                        .setMessage(rahasia ? "" : "Kosongkan untuk memakai model bawaan.")
                        .setView(e)
                        .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                sp.edit().putString(kunci, e.getText().toString().trim()).apply();
                                perbaruiIsian(b, label, kunci, rahasia);
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void perbaruiIsian(Button b, String label, String kunci, boolean rahasia) {
        String v = sp.getString(kunci, "");
        String ringkas;
        if (rahasia) ringkas = v.isEmpty() ? "belum diisi" : "sudah diisi";
        else if (!v.isEmpty()) ringkas = v;
        else ringkas = kunci.equals(Prefs.K_GEMINI_MODEL) ? "bawaan (" + OcrKlien.MODEL_GEMINI + ")"
                : "bawaan (" + OcrKlien.MODEL_GROQ + ")";
        b.setText(label + ": " + ringkas);
    }

    private void tambahTombolDaftar(final String label, final String kunci) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pilihAplikasi(label, kunci);
            }
        });
        kolom.addView(b);
    }

    private void pilihAplikasi(String judul, final String kunci) {
        android.content.pm.PackageManager pm = getPackageManager();
        android.content.Intent q = new android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER);
        final java.util.TreeMap<String, String> urut = new java.util.TreeMap<>();
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
            String paket = ri.activityInfo.packageName;
            if (paket.equals(getPackageName())) continue;
            urut.put(ri.loadLabel(pm).toString() + "\u0000" + paket, paket);
        }
        final List<String> paket = new ArrayList<>(urut.values());
        String[] nama = new String[paket.size()];
        final boolean[] dipilih = new boolean[paket.size()];
        final java.util.Set<String> kini = Prefs.daftar(this, kunci);
        int i = 0;
        for (String k : urut.keySet()) {
            nama[i] = k.substring(0, k.indexOf('\u0000'));
            dipilih[i] = kini.contains(paket.get(i));
            i++;
        }
        new AlertDialog.Builder(this)
                .setTitle(judul)
                .setMultiChoiceItems(nama, dipilih, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean centang) {
                        if (centang) kini.add(paket.get(which));
                        else kini.remove(paket.get(which));
                    }
                })
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        sp.edit().putStringSet(kunci, kini).apply();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void ubahAturanNama() {
        final android.widget.EditText e = new android.widget.EditText(this);
        e.setMinLines(5);
        e.setGravity(android.view.Gravity.TOP);
        e.setContentDescription("Aturan ganti nama, satu per baris");
        e.setText(sp.getString(Prefs.K_NAMA, ""));
        new AlertDialog.Builder(this)
                .setTitle("Aturan ganti nama")
                .setMessage("Satu aturan per baris: teks asli=nama baru, atau id:paket:id/nama=nama baru.")
                .setView(e)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        sp.edit().putString(Prefs.K_NAMA, e.getText().toString()).apply();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Tombol yang memilih aksi untuk satu gestur atau tombol. */
    private void tambahAksi(final String label, final String kunci) {
        final Button b = new Button(this);
        b.setText(label + ": " + Aksi.NAMA[Prefs.aksi(this, kunci)]);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(label)
                        .setSingleChoiceItems(Aksi.NAMA, Prefs.aksi(SettingsActivity.this, kunci),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putInt(kunci, which).apply();
                                        b.setText(label + ": " + Aksi.NAMA[which]);
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
        kolom.addView(b);
    }

    private void bagian(String teks) {
        TextView t = new TextView(this);
        t.setText(teks);
        t.setTextSize(20);
        t.setAccessibilityHeading(true);
        t.setPadding(0, (int) (16 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
    }

    private void tambahSakelar(String label, final String kunci, boolean awal) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(kunci, awal));
        s.setMinHeight((int) (48 * getResources().getDisplayMetrics().density));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean dicentang) {
                sp.edit().putBoolean(kunci, dicentang).apply();
            }
        });
        kolom.addView(s);
    }

    private void tambahGeser(String label, String kunci, int min, int maks, int awal) {
        tambahGeser(label, kunci, min, maks, awal, " persen");
    }

    private void tambahGeser(final String label, final String kunci,
                             final int min, int maks, int awal, final String satuan) {
        final TextView t = new TextView(this);
        t.setPadding(0, (int) (8 * getResources().getDisplayMetrics().density), 0, 0);
        kolom.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(maks - min);
        int nilai = sp.getInt(kunci, awal);
        sb.setProgress(nilai - min);
        sb.setContentDescription(label);
        t.setText(label + ": " + nilai + satuan);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progres, boolean daripengguna) {
                int v = progres + min;
                t.setText(label + ": " + v + satuan);
                if (daripengguna) sp.edit().putInt(kunci, v).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        kolom.addView(sb);
    }

    private void perbaruiTombolGema() {
        int m = sp.getInt(Prefs.K_GEMA, 3);
        tombolGema.setText("Gema ketikan: " + NAMA_GEMA[m]);
    }

    private void pilihGema() {
        new AlertDialog.Builder(this)
                .setTitle("Gema ketikan")
                .setSingleChoiceItems(NAMA_GEMA, sp.getInt(Prefs.K_GEMA, 3),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                sp.edit().putInt(Prefs.K_GEMA, which).apply();
                                perbaruiTombolGema();
                                d.dismiss();
                            }
                        })
                .show();
    }

    private void perbaruiTombolMesin() {
        String mesin = sp.getString(Prefs.K_MESIN, "");
        tombolMesin.setText("Mesin suara: " + (mesin.isEmpty() ? "bawaan sistem" : mesin));
    }

    private void pilihMesin() {
        final TextToSpeech[] pemegang = new TextToSpeech[1];
        pemegang[0] = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                final List<String> nama = new ArrayList<>();
                final List<String> paket = new ArrayList<>();
                nama.add("Bawaan sistem");
                paket.add("");
                if (status == TextToSpeech.SUCCESS && pemegang[0] != null) {
                    for (TextToSpeech.EngineInfo info : pemegang[0].getEngines()) {
                        nama.add(info.label);
                        paket.add(info.name);
                    }
                }
                if (pemegang[0] != null) pemegang[0].shutdown();
                if (isFinishing() || isDestroyed()) return;
                int terpilih = Math.max(0, paket.indexOf(sp.getString(Prefs.K_MESIN, "")));
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Mesin suara")
                        .setSingleChoiceItems(nama.toArray(new String[0]), terpilih,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which) {
                                        sp.edit().putString(Prefs.K_MESIN, paket.get(which)).apply();
                                        perbaruiTombolMesin();
                                        d.dismiss();
                                    }
                                })
                        .show();
            }
        });
    }

    /** Pilih jenis navigasi mana saja yang muncul saat usap atas/bawah. */
    private void tambahTombolJenisNavigasi() {
        Button b = new Button(this);
        b.setText("Jenis navigasi yang dipakai");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int n = Granularitas.NAMA.length;
                final boolean[] dipilih = new boolean[n];
                for (int i = 0; i < n; i++) dipilih[i] = Prefs.jenisAktif(SettingsActivity.this, i);
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Jenis navigasi yang dipakai")
                        .setMultiChoiceItems(Granularitas.NAMA, dipilih,
                                new DialogInterface.OnMultiChoiceClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int which, boolean centang) {
                                        dipilih[which] = centang;
                                    }
                                })
                        .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                java.util.Set<String> hasil = new java.util.HashSet<>();
                                for (int i = 0; i < n; i++) {
                                    if (dipilih[i]) hasil.add(String.valueOf(i));
                                }
                                hasil.add(String.valueOf(Granularitas.ITEM)); // Default selalu aktif
                                sp.edit().putStringSet(Prefs.K_JENIS_AKTIF, hasil).apply();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        kolom.addView(b);
    }
}
