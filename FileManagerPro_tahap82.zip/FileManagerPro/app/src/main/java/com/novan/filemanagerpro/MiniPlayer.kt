package com.novan.filemanagerpro

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Bilah pemutar mini di bawah layar. Hanya tampil jika [PlayerService] sedang berjalan;
 * tidak pernah memulai layanan itu sendiri.
 */
class MiniPlayer(private val act: AppCompatActivity, private val bar: View) {

    private var svc: PlayerService? = null
    private var bound = false
    private val name: TextView = bar.findViewById(R.id.miniName)
    private val play: ImageButton = bar.findViewById(R.id.miniPlay)
    private val next: ImageButton = bar.findViewById(R.id.miniNext)
    private val close: ImageButton = bar.findViewById(R.id.miniClose)

    private val cb: () -> Unit = { act.runOnUiThread { update() } }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, binder: IBinder) {
            val s = (binder as PlayerService.LocalBinder).service
            svc = s
            s.onChange = cb
            update()
        }

        override fun onServiceDisconnected(n: ComponentName) {
            svc = null
            update()
        }
    }

    init {
        bar.setOnClickListener {
            act.startActivity(Intent(act, AudioPlayerActivity::class.java))
        }
        play.setOnClickListener { svc?.toggle() }
        next.setOnClickListener { svc?.next() }
        close.setOnClickListener { svc?.stopAll() }
    }

    fun start() {
        bound = try {
            act.bindService(Intent(act, PlayerService::class.java), conn, 0)
        } catch (e: Exception) {
            false
        }
        if (!bound) bar.visibility = View.GONE
    }

    fun stop() {
        if (bound) {
            val s = svc
            if (s != null && s.onChange === cb) s.onChange = null
            try {
                act.unbindService(conn)
            } catch (e: Exception) {
                // sudah lepas
            }
            bound = false
        }
        svc = null
    }

    private fun update() {
        val s = svc
        if (s == null || s.queue.isEmpty() || !(s.isPrepared() || s.isPlaying())) {
            bar.visibility = View.GONE
            return
        }
        bar.visibility = View.VISIBLE
        name.text = s.currentName()
        if (s.isPlaying()) {
            play.setImageResource(R.drawable.ic_pause)
            play.contentDescription = act.getString(R.string.audio_pause)
        } else {
            play.setImageResource(R.drawable.ic_play)
            play.contentDescription = act.getString(R.string.audio_play)
        }
        bar.contentDescription = act.getString(R.string.mini_open, s.currentName())
    }
}
