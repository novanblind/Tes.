package com.novan.audiolabnovan.karaoke

import android.Manifest
import android.content.ContentValues
import android.os.Build
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.R
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Studio karaoke. Tiga tahap dalam satu layar:
 * 1. Siap: pilih lagu pengiring dan lirik (LRC), cek headset, pilih efek.
 * 2. Menyanyi: lagu diputar, lirik bergulir, vokal direkam terpisah dari musik ([KaraokeMesin]).
 * 3. Hasil: atur gema, kerasnya vokal, dan sinkron, putar hasil, simpan MP3, bagikan ([CampurKaraoke]).
 */
class KaraokeActivity : HalamanKaraoke() {

    override val judulHalaman = R.string.judul_karaoke

    private enum class Tahap { SIAP, NYANYI, HASIL }

    companion object {
        private const val REQ_LAGU = 41
        private const val REQ_LIRIK = 42
        private const val REQ_IZIN = 43
        private const val REQ_SIMPAN = 44
        private val SR = PenguraiLagu.SR
    }

    private var tahap = Tahap.SIAP
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var wadahSiap: LinearLayout
    private lateinit var wadahNyanyi: LinearLayout
    private lateinit var wadahHasil: LinearLayout

    // ----- Tahap siap -----
    private lateinit var teksLagu: TextView
    private lateinit var teksLirik: TextView
    private lateinit var teksHeadset: TextView
    private lateinit var tMulai: Button
    private lateinit var spEfekSiap: Spinner
    private lateinit var spEfekHasil: Spinner
    private lateinit var spFilter: Spinner
    private lateinit var spAuto: Spinner
    private lateinit var spKunci: Spinner
    private lateinit var spHarmoni: Spinner
    private lateinit var swGanda: android.widget.Switch
    private lateinit var spBass: Spinner
    private lateinit var spJernih: Spinner
    private lateinit var spSelaras: Spinner
    private var lagu: Lagu? = null
    private var lirik: List<BarisLirik> = emptyList()
    private var isiLirikMentah: String? = null
    @Volatile private var tokenMuat = 0
    private var uriLagu: Uri? = null
    private var memuat = false

    // ----- Tahap menyanyi -----
    private lateinit var teksJudulNyanyi: TextView
    private lateinit var teksBaitLirik: TextView
    private lateinit var teksWaktu: TextView
    private lateinit var teksMik: TextView
    private lateinit var teksNada: TextView
    private lateinit var teksSkorLangsung: TextView
    private var skorSementaraMs = -10_000L
    private var mesin: KaraokeMesin? = null
    private var barisTampil = Int.MIN_VALUE
    private var detikTampil = -1L
    private var mikTerdengar = false

    // ----- Tahap hasil -----
    private lateinit var teksHasilInfo: TextView
    private lateinit var teksProses: TextView
    private lateinit var teksSkor: TextView
    private var skorHasil: HasilSkor? = null
    private lateinit var tPutarHasil: Button
    private lateinit var tSimpan: Button
    private lateinit var tSimpanVokal: Button
    private lateinit var tBagikan: Button
    private var nyanyi: HasilNyanyi? = null
    private var sibuk = false
    @Volatile private var tokenPutar = 0
    private var putarTrek: AudioTrack? = null
    private var campuranCache: ShortArray? = null
    private var kunciCache = ""
    private var uriTerakhir: Uri? = null
    private var namaTerakhir: String = ""
    private val dialogHasil by lazy { DialogHasil(this) }

    private val denyut = object : Runnable {
        override fun run() {
            if (tahap == Tahap.NYANYI) {
                segarkanNyanyi()
                handler.postDelayed(this, 100L)
            }
        }
    }

    // ================= Membangun tampilan =================

    override fun bangun() {
        wadahSiap = LinearLayout(this).also { it.orientation = LinearLayout.VERTICAL }
        wadahNyanyi = LinearLayout(this).also { it.orientation = LinearLayout.VERTICAL }
        wadahHasil = LinearLayout(this).also { it.orientation = LinearLayout.VERTICAL }
        root.addView(wadahSiap)
        root.addView(wadahNyanyi)
        root.addView(wadahHasil)
        induk = wadahSiap
        bangunSiap()
        induk = wadahNyanyi
        bangunNyanyi()
        induk = wadahHasil
        bangunHasil()
        induk = root
        tampilkan(Tahap.SIAP, false)
    }

    private fun bangunSiap() {
        val p = prefs
        info(getString(R.string.karaoke_petunjuk))

        bagian(getString(R.string.karaoke_pilih_lagu), 18f)
        teksLagu = info(getString(R.string.karaoke_lagu_belum))
        teksLagu.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        tombol(getString(R.string.karaoke_pilih_lagu)) { pilihBerkas(REQ_LAGU, arrayOf("audio/*")) }
        pilihan(getString(R.string.karaoke_kurangi), larik(R.array.k_kurangi_vokal), p.kKurangi) {
            p.kKurangi = it
            // Lagu diproses saat dimuat, jadi lagu yang sudah dipilih dimuat ulang dengan pilihan baru.
            uriLagu?.let { u -> muatLagu(u) }
        }
        info(getString(R.string.karaoke_kurangi_info))
        pilihan(getString(R.string.karaoke_nada_lagu), larik(R.array.k_nada_lagu), p.kNada) {
            p.kNada = it
            uriLagu?.let { u -> muatLagu(u) }
        }
        info(getString(R.string.karaoke_nada_info))

        teksLirik = info(getString(R.string.karaoke_lirik_belum))
        teksLirik.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        tombol(getString(R.string.karaoke_pilih_lirik)) {
            pilihBerkas(REQ_LIRIK, arrayOf("text/plain", "application/octet-stream", "text/*"))
        }
        tombol(getString(R.string.karaoke_buang_lirik)) {
            isiLirikMentah = null
            lirik = emptyList()
            teksLirik.text = getString(R.string.karaoke_lirik_belum)
        }

        bagian(getString(R.string.karaoke_efek), 18f)
        teksHeadset = info("")
        spEfekSiap = pilihan(getString(R.string.karaoke_efek), larik(R.array.k_efek_preset).take(6), p.kEfek) {
            p.kEfek = it
            spEfekHasil.setSelection(it, false)
        }
        saklar(getString(R.string.karaoke_pantau), p.kPantau) { p.kPantau = it }
        saklar(getString(R.string.karaoke_skor_pakai), p.kSkor) { p.kSkor = it }

        pilihan(getString(R.string.karaoke_hitung_judul), larik(R.array.k_hitung_mundur), p.kHitung) { p.kHitung = it }
        info(getString(R.string.karaoke_hitung_info))

        tMulai = tombol(getString(R.string.karaoke_mulai)) { tekanMulai() }
        tombol(getString(R.string.karaoke_bawaan)) {
            prefs.setelBawaanStudioKaraoke()
            toast(R.string.karaoke_bawaan_selesai)
            // Layar dibangun ulang supaya semua pilihan menampilkan nilai bawaan; lagu dan lirik perlu dipilih lagi.
            recreate()
        }
        info(getString(R.string.karaoke_bawaan_info))
    }

    private fun bangunNyanyi() {
        teksJudulNyanyi = info("")
        teksJudulNyanyi.textSize = 18f
        teksBaitLirik = TextView(this)
        teksBaitLirik.gravity = Gravity.CENTER_HORIZONTAL
        teksBaitLirik.setPadding(0, dp(16), 0, dp(16))
        teksBaitLirik.minHeight = dp(260)
        // Lirik berganti beberapa kali per menit; pembaca layar tidak diminta membacakannya agar tidak menabrak musik.
        teksBaitLirik.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        wadahNyanyi.addView(teksBaitLirik)
        teksWaktu = info("")
        teksMik = info("")
        // Nada dan skor berubah beberapa kali per detik; pembaca layar tidak diminta membacakannya agar tidak menabrak musik.
        teksNada = info("")
        teksNada.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        teksSkorLangsung = info("")
        teksSkorLangsung.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        info(getString(R.string.karaoke_ulang_info))
        tombol(getString(R.string.karaoke_ulang_baris)) { ulangiBaris() }
        tombol(getString(R.string.karaoke_ulang_awal)) { tandaiAwal() }
        tombol(getString(R.string.karaoke_ulang_akhir)) { tandaiAkhir() }
        tombol(getString(R.string.karaoke_ulang_lanjut)) { lanjutkanLagu() }
        tombol(getString(R.string.karaoke_berhenti)) { selesaiNyanyi() }
    }

    private fun bangunHasil() {
        bagian(getString(R.string.karaoke_hasil_judul), 22f)
        teksHasilInfo = info("")
        teksProses = info("")
        teksProses.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        bagian(getString(R.string.karaoke_skor_judul), 20f)
        teksSkor = info("")
        val p = prefs
        spEfekHasil = pilihan(getString(R.string.karaoke_efek), larik(R.array.k_efek_preset).take(6), p.kEfek) {
            p.kEfek = it
            spEfekSiap.setSelection(it, false)
        }
        bangunFilter()
        saklar(getString(R.string.karaoke_rapikan), p.kRapikan) { p.kRapikan = it }
        spSelaras = pilihan(getString(R.string.karaoke_selaras), larik(R.array.k_selaras_suara), p.kSelaras) {
            // Pilihan dari pengguna dicatat sebagai manual; pemilihan otomatis menurut headset tidak lagi menimpanya.
            if (it != p.kSelaras) {
                p.kSelaras = it
                p.kSelarasManual = true
            }
            // Jeda mikrofon ikut menentukan waktu masuk tiap baris, jadi skornya dihitung ulang.
            hitungSkor(false)
        }
        penggeser(wadahHasil, getString(R.string.karaoke_vol_vokal), p.kVolVokal) { p.kVolVokal = it }
        penggeser(wadahHasil, getString(R.string.karaoke_vol_musik), p.kVolMusik) { p.kVolMusik = it }
        pilihan(getString(R.string.karaoke_runduk_judul), larik(R.array.k_runduk_musik), p.kRunduk) { p.kRunduk = it }
        info(getString(R.string.karaoke_runduk_info))
        pilihan(getString(R.string.karaoke_keras_judul), larik(R.array.k_keras_hasil), p.kKeras) { p.kKeras = it }
        info(getString(R.string.karaoke_keras_info))
        tPutarHasil = tombol(getString(R.string.karaoke_putar_hasil)) { tekanPutar() }
        tSimpan = tombol(getString(R.string.karaoke_simpan)) { simpan(false) }
        tSimpanVokal = tombol(getString(R.string.karaoke_simpan_vokal)) { simpan(true) }
        tBagikan = tombol(getString(R.string.karaoke_bagikan)) { bukaMenuHasil() }
        tBagikan.visibility = View.GONE
        tombol(getString(R.string.karaoke_lagi)) { nyanyiLagi() }
    }

    /** Bagian filter suara di layar hasil: pilihan siap pakai, dan pengaturan satu per satu. */
    private fun bangunFilter() {
        val p = prefs
        bagian(getString(R.string.karaoke_filter_judul), 20f)
        info(getString(R.string.karaoke_filter_info))
        spFilter = pilihan(getString(R.string.karaoke_filter_pilih), larik(R.array.k_filter_preset), p.kFilter) { i ->
            p.kFilter = i
            if (i != KaraokePrefs.FILTER_MANUAL) {
                p.terapkanFilterPreset(i)
                spAuto.setSelection(p.kAuto, false)
                spKunci.setSelection(if (p.kKromatik) 1 else 0, false)
                spHarmoni.setSelection(p.kHarmoni, false)
                swGanda.isChecked = p.kGanda
                spBass.setSelection(p.kBass, false)
                spJernih.setSelection(p.kJernih, false)
                spEfekHasil.setSelection(p.kEfek, false)
                spEfekSiap.setSelection(p.kEfek, false)
            }
        }
        // Tiap pengaturan hanya bereaksi bila nilainya memang berbeda dari yang tersimpan, supaya pengisian dari
        // pilihan siap pakai tidak dianggap sebagai ubahan sendiri.
        spAuto = pilihan(getString(R.string.karaoke_filter_auto), larik(R.array.k_auto_suara), p.kAuto) {
            if (p.kAuto != it) { p.kAuto = it; jadiManual() }
        }
        spKunci = pilihan(getString(R.string.karaoke_filter_kunci), larik(R.array.k_kunci_suara), if (p.kKromatik) 1 else 0) {
            val v = it == 1
            if (p.kKromatik != v) { p.kKromatik = v; jadiManual() }
        }
        spHarmoni = pilihan(getString(R.string.karaoke_filter_harmoni), larik(R.array.k_harmoni_suara), p.kHarmoni) {
            if (p.kHarmoni != it) { p.kHarmoni = it; jadiManual() }
        }
        swGanda = saklar(getString(R.string.karaoke_filter_ganda), p.kGanda) {
            if (p.kGanda != it) { p.kGanda = it; jadiManual() }
        }
        spBass = pilihan(getString(R.string.karaoke_filter_bass), larik(R.array.k_bass_suara), p.kBass) {
            if (p.kBass != it) { p.kBass = it; jadiManual() }
        }
        spJernih = pilihan(getString(R.string.karaoke_filter_jernih), larik(R.array.k_jernih_suara), p.kJernih) {
            if (p.kJernih != it) { p.kJernih = it; jadiManual() }
        }
    }

    private fun jadiManual() {
        if (prefs.kFilter != KaraokePrefs.FILTER_MANUAL) {
            prefs.kFilter = KaraokePrefs.FILTER_MANUAL
            spFilter.setSelection(KaraokePrefs.FILTER_MANUAL, false)
        }
    }

    private fun tampilkan(t: Tahap, umumkan: Boolean) {
        tahap = t
        wadahSiap.visibility = if (t == Tahap.SIAP) View.VISIBLE else View.GONE
        wadahNyanyi.visibility = if (t == Tahap.NYANYI) View.VISIBLE else View.GONE
        wadahHasil.visibility = if (t == Tahap.HASIL) View.VISIBLE else View.GONE
        (root.parent as? android.widget.ScrollView)?.scrollTo(0, 0)
        window.let {
            if (t == Tahap.NYANYI) it.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else it.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        if (t == Tahap.SIAP) segarkanHeadset()
        if (umumkan) root.announceForAccessibility(
            getString(if (t == Tahap.HASIL) R.string.karaoke_hasil_judul else R.string.judul_karaoke)
        )
    }

    private fun segarkanHeadset() {
        teksHeadset.text = getString(
            if (KaraokeMesin.adaHeadset(this)) R.string.karaoke_headset_ada else R.string.karaoke_headset_tidak
        )
    }

    override fun onResume() {
        super.onResume()
        if (tahap == Tahap.SIAP) segarkanHeadset()
    }

    // ================= Memilih lagu dan lirik =================

    private fun pilihBerkas(kode: Int, jenis: Array<String>) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(if (kode == REQ_LAGU) "audio/*" else "*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, jenis)
        try {
            startActivityForResult(i, kode)
        } catch (e: Exception) {
            toast(R.string.gagal_bagikan)
        }
    }

    @Deprecated("Dipakai karena Activity biasa tanpa AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_SIMPAN) {
            val f = menungguSimpan
            menungguSimpan = null
            if (f == null) return
            if (resultCode != RESULT_OK || uri == null) {
                try { f.delete() } catch (e: Exception) { }
                teksProses.text = getString(R.string.karaoke_batal_simpan)
                return
            }
            val ctx = applicationContext
            val nama = namaMenunggu
            setSibuk(true)
            Thread {
                val ok = try {
                    ctx.contentResolver.openOutputStream(uri, "w")!!.use { out -> f.inputStream().use { it.copyTo(out) } }
                    true
                } catch (e: Exception) {
                    false
                } finally {
                    try { f.delete() } catch (e: Exception) { }
                }
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    setSibuk(false)
                    if (ok) {
                        uriTerakhir = uri
                        namaTerakhir = nama
                        tBagikan.visibility = View.VISIBLE
                        teksProses.text = getString(R.string.karaoke_tersimpan, nama)
                        bukaMenuHasil()
                    } else {
                        teksProses.text = getString(R.string.karaoke_gagal_simpan)
                    }
                }
            }.start()
            return
        }
        if (resultCode != RESULT_OK || uri == null) return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        if (requestCode == REQ_LAGU) muatLagu(uri) else if (requestCode == REQ_LIRIK) muatLirik(uri)
    }

    private fun muatLagu(uri: Uri) {
        batalHitung(false)
        val token = ++tokenMuat
        uriLagu = uri
        memuat = true
        lagu = null
        tMulai.isEnabled = false
        teksLagu.text = getString(R.string.karaoke_lagu_memuat, 0)
        val ctx = applicationContext
        val kurangi = PengurangVokal.KEKUATAN[prefs.kKurangi]
        val geser = prefs.setengahNada
        Thread {
            var terakhir = -10
            val hasil = PenguraiLagu.urai(ctx, uri, { token != tokenMuat || isDestroyed }) { persen ->
                // Diumumkan tiap 20 persen saja supaya pembaca layar tidak kebanjiran.
                if (persen >= terakhir + 20) {
                    terakhir = persen
                    runOnUiThread { if (token == tokenMuat) teksLagu.text = getString(R.string.karaoke_lagu_memuat, persen) }
                }
            }
            var kurangBerhasil = false
            if (hasil != null && token == tokenMuat && !isDestroyed) {
                // Peta nada dihitung dari lagu asli (melodi penyanyi ada di dalamnya), sebelum suaranya dikurangi.
                hasil.chroma = try { ChromaLagu.hitung(hasil) { token != tokenMuat || isDestroyed } } catch (e: Throwable) { null }
                if (kurangi > 0 && token == tokenMuat) {
                    runOnUiThread { if (token == tokenMuat) teksLagu.text = getString(R.string.karaoke_memproses) }
                    kurangBerhasil = try {
                        PengurangVokal.proses(hasil.pcm, PenguraiLagu.SR, kurangi) { token != tokenMuat || isDestroyed }
                    } catch (e: Throwable) {
                        false
                    }
                }
            }
            var geserBerhasil = false
            if (hasil != null && geser != 0 && token == tokenMuat && !isDestroyed) {
                runOnUiThread { if (token == tokenMuat) teksLagu.text = getString(R.string.karaoke_menggeser) }
                geserBerhasil = try {
                    PenggeserNadaLagu.proses(hasil.pcm, geser) { token != tokenMuat || isDestroyed }
                } catch (e: Throwable) {
                    false
                }
                // Peta nada ikut digeser supaya penilaian cocok dengan musik yang terdengar.
                if (geserBerhasil) hasil.chroma = hasil.chroma?.geser(geser)
            }
            runOnUiThread {
                if (token != tokenMuat || isDestroyed) return@runOnUiThread
                memuat = false
                tMulai.isEnabled = true
                lagu = hasil
                if (hasil == null) {
                    teksLagu.text = getString(R.string.karaoke_lagu_gagal)
                } else {
                    teksLagu.text = when {
                        kurangBerhasil -> getString(R.string.karaoke_lagu_siap_kurang, hasil.nama, Teks.durasi(hasil.durasiMs))
                        kurangi > 0 -> getString(R.string.karaoke_lagu_mono) + " " +
                            getString(R.string.karaoke_lagu_siap, hasil.nama, Teks.durasi(hasil.durasiMs))
                        else -> getString(R.string.karaoke_lagu_siap, hasil.nama, Teks.durasi(hasil.durasiMs))
                    }
                    // Lirik yang dipilih lebih dulu dibaca ulang sesuai panjang lagu (untuk lirik tanpa waktu).
                    if (geser != 0) {
                        teksLagu.text = teksLagu.text.toString() + " " + if (geserBerhasil) {
                            getString(R.string.karaoke_nada_terapan, resources.getStringArray(R.array.k_nada_lagu)[geser + 6])
                        } else {
                            getString(R.string.karaoke_nada_gagal)
                        }
                    }
                    isiLirikMentah?.let { lirik = Lirik.baca(it, hasil.durasiMs) }
                }
            }
        }.start()
    }

    private fun muatLirik(uri: Uri) {
        val isi = try {
            contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) {
            null
        }
        val baris = if (isi.isNullOrBlank()) emptyList() else Lirik.baca(isi, lagu?.durasiMs ?: 180_000L)
        if (baris.isEmpty()) {
            teksLirik.text = getString(R.string.karaoke_lirik_gagal)
            return
        }
        isiLirikMentah = isi
        lirik = baris
        teksLirik.text = getString(R.string.karaoke_lirik_siap, baris.size)
    }

    // ================= Menyanyi =================

    // ---- Hitung mundur sebelum mulai (tahap 49) ----
    private var menghitung = false
    private var hitungSisa = 0
    private val hitung = object : Runnable {
        override fun run() {
            if (!menghitung) return
            if (hitungSisa <= 0) {
                menghitung = false
                tMulai.text = getString(R.string.karaoke_mulai)
                mulaiNyanyi()
                return
            }
            tMulai.text = getString(R.string.karaoke_hitung_tombol, hitungSisa)
            root.announceForAccessibility(hitungSisa.toString())
            hitungSisa--
            handler.postDelayed(this, 1_000L)
        }
    }

    private fun batalHitung(umumkan: Boolean) {
        if (!menghitung) return
        menghitung = false
        handler.removeCallbacks(hitung)
        if (::tMulai.isInitialized) tMulai.text = getString(R.string.karaoke_mulai)
        if (umumkan) toast(R.string.karaoke_hitung_batal)
    }

    private fun tekanMulai() {
        if (menghitung) {
            batalHitung(true)
            return
        }
        if (memuat) return
        if (lagu == null) {
            toast(R.string.karaoke_butuh_lagu)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_IZIN)
            return
        }
        mulaiDenganHitung()
    }

    private fun mulaiDenganHitung() {
        val detik = prefs.detikHitung
        if (detik <= 0) {
            mulaiNyanyi()
            return
        }
        menghitung = true
        hitungSisa = detik
        handler.removeCallbacks(hitung)
        handler.post(hitung)
    }

    @Deprecated("Dipakai karena Activity biasa tanpa AndroidX")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_IZIN) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) mulaiDenganHitung()
        else toast(R.string.karaoke_izin)
    }

    private fun mulaiNyanyi() {
        val l = lagu ?: return
        hentikanPutar()
        val p = prefs
        val pantau = p.kPantau && KaraokeMesin.adaHeadset(this)
        p.selarasOtomatis(KaraokeMesin.headsetBluetooth(this))
        spSelaras.setSelection(p.kSelaras, false)
        val m = KaraokeMesin(
            l, pantau, p.efekPreset(p.kEfek),
            if (p.kRapikan) KonfigVokal.KARAOKE else KonfigVokal.MATI,
            true // nada selalu diukur: dipakai penilaian dan filter (penyetel nada otomatis, harmoni)
        )
        if (!m.mulai()) {
            toast(R.string.karaoke_gagal_mulai)
            return
        }
        mesin = m
        tandaAwalMs = -1L
        barisTampil = Int.MIN_VALUE
        detikTampil = -1L
        mikTerdengar = false
        skorSementaraMs = -10_000L
        teksNada.text = ""
        teksSkorLangsung.text = ""
        teksJudulNyanyi.text = getString(R.string.karaoke_bernyanyi, l.nama)
        teksMik.text = ""
        tampilkan(Tahap.NYANYI, true)
        segarkanNyanyi()
        handler.removeCallbacks(denyut)
        handler.postDelayed(denyut, 100L)
    }

    private fun segarkanNyanyi() {
        val m = mesin ?: return
        val l = lagu ?: return
        if (m.gagal != null) {
            toast(m.gagal ?: "")
            selesaiNyanyi()
            return
        }
        if (m.selesaiAlami) {
            selesaiNyanyi()
            return
        }
        val ms = m.posisiMs()
        val b = Lirik.indeks(lirik, ms)
        if (b != barisTampil) {
            barisTampil = b
            teksBaitLirik.text = susunLirik(b)
        }
        segarkanNada(m, ms)
        val detik = ms / 1000
        if (detik != detikTampil) {
            detikTampil = detik
            teksWaktu.text = getString(R.string.karaoke_waktu, Teks.durasi(ms), Teks.durasi(l.durasiMs))
            if (m.puncakMik > 600) mikTerdengar = true
            // Bila sampai 8 detik pertama tidak ada suara sama sekali, beri tahu sekali.
            teksMik.text = when {
                mikTerdengar -> getString(R.string.karaoke_mik_terdengar)
                detik >= 8 -> getString(R.string.karaoke_mik_tidak_terdengar)
                else -> ""
            }
        }
    }

    /** Dua baris sebelumnya redup, baris sekarang besar dan tebal, tiga baris berikutnya sedang. */
    private fun susunLirik(sekarang: Int): CharSequence {
        if (lirik.isEmpty()) return getString(R.string.karaoke_tanpa_lirik)
        val sb = SpannableStringBuilder()
        fun tambah(teks: String, ukuran: Float, warna: Int, tebal: Boolean) {
            val mulai = sb.length
            sb.append(if (teks.isEmpty()) "♪" else teks).append("\n\n")
            val akhir = sb.length - 2
            sb.setSpan(RelativeSizeSpan(ukuran), mulai, akhir, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(warna), mulai, akhir, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (tebal) sb.setSpan(StyleSpan(Typeface.BOLD), mulai, akhir, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val gelap = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val redup = if (gelap) Color.rgb(130, 130, 130) else Color.rgb(150, 150, 150)
        val sedang = if (gelap) Color.rgb(205, 205, 205) else Color.rgb(70, 70, 70)
        val aktif = if (gelap) Color.rgb(206, 147, 216) else Color.rgb(106, 27, 154)
        if (sekarang < 0) tambah(getString(R.string.karaoke_bersiap), 1.3f, aktif, true)
        for (i in max(0, sekarang - 2) until sekarang) tambah(lirik[i].teks, 0.9f, redup, false)
        if (sekarang >= 0) tambah(lirik[sekarang].teks, 1.6f, aktif, true)
        for (i in (sekarang + 1)..min(lirik.size - 1, sekarang + 3)) tambah(lirik[i].teks, 1.1f, sedang, false)
        return sb
    }

    private fun selesaiNyanyi() {
        handler.removeCallbacks(denyut)
        val m = mesin ?: return
        mesin = null
        val h = m.berhenti()
        if (m.dipakaiUlang) {
            toast(R.string.karaoke_latihan_selesai)
            nyanyi = null
            tampilkan(Tahap.SIAP, true)
            return
        }
        if (h == null || h.vokal.size < SR / 2 || h.frameMusik < SR / 2) {
            toast(R.string.karaoke_vokal_kosong)
            nyanyi = null
            tampilkan(Tahap.SIAP, true)
            return
        }
        nyanyi = h
        campuranCache = null
        kunciCache = ""
        uriTerakhir = null
        tBagikan.visibility = View.GONE
        teksProses.text = ""
        teksHasilInfo.text = getString(
            R.string.karaoke_hasil_info,
            lagu?.nama ?: "",
            Teks.durasi(h.frameMusik.toLong() * 1000L / SR)
        )
        tPutarHasil.text = getString(R.string.karaoke_putar_hasil)
        hitungSkor(true)
        tampilkan(Tahap.HASIL, true)
        // Ringkasan skor dibacakan setelah judul halaman selesai diumumkan.
        val ringkas = skorHasil?.let { ringkasSkor(it) }
        if (ringkas != null) handler.postDelayed({
            if (!isDestroyed && tahap == Tahap.HASIL) root.announceForAccessibility(ringkas)
        }, 1_200L)
    }

    // ================= Latihan: ulangi bagian lagu (tahap 49) =================

    private var tandaAwalMs = -1L

    private fun umumkanUlang(dari: Long, sampai: Long) {
        val teks = getString(R.string.karaoke_ulang_mulai, Teks.durasi(dari), Teks.durasi(sampai))
        toast(teks)
        root.announceForAccessibility(teks)
    }

    private fun ulangiBaris() {
        val m = mesin ?: return
        val l = lagu ?: return
        if (lirik.isEmpty()) {
            toast(R.string.karaoke_ulang_tanpa_lirik)
            return
        }
        val b = Lirik.indeks(lirik, m.posisiMs()).coerceAtLeast(0)
        // Mulai setengah detik lebih awal supaya napas pertama ikut; akhir = awal baris berikutnya (atau akhir lagu).
        val dari = max(0L, lirik[b].ms - 500L)
        var sampai = if (b + 1 < lirik.size) lirik[b + 1].ms else l.durasiMs
        sampai = min(l.durasiMs, max(sampai, dari + 2_500L))
        if (m.ulangi(dari, sampai)) umumkanUlang(dari, sampai) else toast(R.string.karaoke_ulang_pendek)
    }

    private fun tandaiAwal() {
        val m = mesin ?: return
        tandaAwalMs = m.posisiMs()
        val teks = getString(R.string.karaoke_ulang_tanda, Teks.durasi(tandaAwalMs))
        toast(teks)
        root.announceForAccessibility(teks)
    }

    private fun tandaiAkhir() {
        val m = mesin ?: return
        if (tandaAwalMs < 0) {
            toast(R.string.karaoke_ulang_butuh_awal)
            return
        }
        val akhir = m.posisiMs()
        if (m.ulangi(tandaAwalMs, akhir)) umumkanUlang(tandaAwalMs, akhir) else toast(R.string.karaoke_ulang_pendek)
    }

    private fun lanjutkanLagu() {
        val m = mesin ?: return
        if (!m.mengulang) return
        m.hentikanUlang()
        toast(R.string.karaoke_ulang_henti)
        root.announceForAccessibility(getString(R.string.karaoke_ulang_henti))
    }

    // ================= Penilaian nyanyian =================

    private fun nilaiNyanyi(m: KaraokeMesin?, hasil: HasilNyanyi?, sampaiMs: Long): HasilSkor? {
        val l = lagu ?: return null
        val pn = (m?.nada ?: hasil?.nada) ?: return null
        val awal = if (m != null) m.awalVokalSekarang else hasil?.vokalAwal ?: -1
        if (awal < 0) return null
        val sal = pn.salin()
        val durasi = if (hasil != null) hasil.frameMusik.toLong() * 1000L / SR else l.durasiMs
        val waktu = SkorNyanyi.keWaktuMusik(sal.pusat, sal.jumlah, SR, awal, KaraokePrefs.SELARAS_MS[prefs.kSelaras])
        return SkorNyanyi.hitung(sal.hz, waktu, sal.jumlah, lirik, durasi, sampaiMs, l.chroma)
    }

    /** Memperbarui nada yang sedang terdengar tiap tick, dan skor sementara tiap 3 detik. */
    private fun segarkanNada(m: KaraokeMesin, ms: Long) {
        val pn = m.nada
        if (pn == null || !prefs.kSkor) {
            teksNada.text = ""
            teksSkorLangsung.text = ""
            return
        }
        val hz = pn.nadaTerakhir
        val teks = if (hz > 0.0) {
            val sen = PemantauNada.selisihSen(hz)
            val ket = getString(
                when {
                    sen > 20 -> R.string.karaoke_nada_tinggi
                    sen < -20 -> R.string.karaoke_nada_rendah
                    else -> R.string.karaoke_nada_tepat
                }
            )
            getString(R.string.karaoke_nada_sekarang, PemantauNada.nama(hz), ket)
        } else {
            getString(R.string.karaoke_nada_diam)
        }
        if (teks != teksNada.text.toString()) teksNada.text = teks
        if (m.dipakaiUlang) {
            if (teksSkorLangsung.text.isNotEmpty()) teksSkorLangsung.text = ""
            return
        }
        if (ms - skorSementaraMs >= 3_000L) {
            skorSementaraMs = ms
            val h = try { nilaiNyanyi(m, null, ms) } catch (e: Throwable) { null }
            if (h != null) teksSkorLangsung.text = getString(R.string.karaoke_skor_sementara, h.total)
        }
    }

    /** Menghitung skor akhir dan menampilkannya di kotak skor. [umumkan] true saat pertama kali muncul. */
    private fun hitungSkor(umumkan: Boolean) {
        if (!::teksSkor.isInitialized) return
        val n = nyanyi
        if (n == null || n.nada == null || !prefs.kSkor) {
            skorHasil = null
            teksSkor.text = ""
            teksSkor.visibility = View.GONE
            return
        }
        val h = try { nilaiNyanyi(null, n, Long.MAX_VALUE) } catch (e: Throwable) { null }
        skorHasil = h
        teksSkor.visibility = View.VISIBLE
        teksSkor.text = if (h == null) getString(R.string.karaoke_skor_sedikit) else susunSkor(h)
        if (!umumkan && h != null) teksSkor.announceForAccessibility(ringkasSkor(h))
    }

    private fun ringkasSkor(h: HasilSkor): String =
        getString(R.string.karaoke_skor_ringkas, h.total, h.peringkat, h.bintang)

    private fun susunSkor(h: HasilSkor): String {
        val sb = StringBuilder(ringkasSkor(h))
        val w = h.waktu
        val c = h.lancar
        val m = h.melodi
        sb.append("\n")
        if (m != null) {
            if (w != null && c != null) sb.append(getString(R.string.karaoke_skor_rinci_melodi, h.nada, m, w, c))
            else sb.append(getString(R.string.karaoke_skor_rinci_nada_melodi, h.nada, m))
        } else if (w != null && c != null) {
            sb.append(getString(R.string.karaoke_skor_rinci, h.nada, w, c))
        } else {
            sb.append(getString(R.string.karaoke_skor_rinci_nada, h.nada))
        }
        if (h.rentetan >= 2) sb.append("\n").append(getString(R.string.karaoke_skor_rentetan, h.rentetan))
        if (h.barisLemah.isNotEmpty()) {
            sb.append("\n").append(getString(R.string.karaoke_skor_lemah))
            for (b in h.barisLemah) {
                val t = if (b.teks.length > 48) b.teks.substring(0, 48) + "…" else b.teks
                sb.append("\n").append(getString(R.string.karaoke_skor_baris, Teks.durasi(b.ms), t, b.skor))
            }
        }
        sb.append("\n").append(getString(if (m != null) R.string.karaoke_skor_catatan_melodi else R.string.karaoke_skor_catatan))
        return sb.toString()
    }

    private fun nyanyiLagi() {
        hentikanPutar()
        tampilkan(Tahap.SIAP, true)
    }

    // ================= Campuran, putar, simpan =================

    private fun setelan(vokalSaja: Boolean): SetelKampur {
        val p = prefs
        return SetelKampur(
            vokalPersen = p.kVolVokal,
            musikPersen = if (vokalSaja) 0 else p.kVolMusik,
            selarasMs = KaraokePrefs.SELARAS_MS[p.kSelaras],
            efek = p.efekPreset(p.kEfek),
            vokal = if (p.kRapikan) KonfigVokal.KARAOKE else KonfigVokal.MATI,
            pemoles = true,
            vokalOtomatis = true,
            filter = p.konfigFilter(),
            nada = nyanyi?.nada?.salin(),
            rundukDb = if (vokalSaja) 0.0 else p.rundukDb,
            kekerasan = p.kKeras
        )
    }

    private fun kunci(vokalSaja: Boolean): String {
        val p = prefs
        return "${p.kEfek}|${p.kRapikan}|${p.kSelaras}|${p.kVolVokal}|${if (vokalSaja) 0 else p.kVolMusik}|$vokalSaja|${p.kAuto}|${p.kKromatik}|${p.kHarmoni}|${p.kGanda}|${p.kBass}|${p.kJernih}|${p.kRunduk}|${p.kKeras}"
    }

    private fun setSibuk(b: Boolean) {
        sibuk = b
        tPutarHasil.isEnabled = !b || putarTrek != null
        tSimpan.isEnabled = !b
        tSimpanVokal.isEnabled = !b
    }

    /** Menyiapkan campuran (memakai hasil sebelumnya bila setelannya sama), lalu memanggil [lanjut] di utas utama. */
    private fun siapkan(vokalSaja: Boolean, lanjut: (ShortArray) -> Unit) {
        val n = nyanyi ?: return
        val l = lagu ?: return
        val k = kunci(vokalSaja)
        val cache = campuranCache
        if (cache != null && k == kunciCache) {
            lanjut(cache)
            return
        }
        setSibuk(true)
        val s = setelan(vokalSaja)
        teksProses.text = getString(R.string.karaoke_menyiapkan, 0)
        Thread {
            var terakhir = -25
            val hasil = try {
                CampurKaraoke.campur(l.pcm, n.frameMusik, n.vokal, n.vokalAwal, SR, s) { persen ->
                    if (persen >= terakhir + 25) {
                        terakhir = persen
                        runOnUiThread { if (!isDestroyed) teksProses.text = getString(R.string.karaoke_menyiapkan, persen) }
                    }
                }
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                setSibuk(false)
                // Pengguna sudah pindah (misalnya menekan Nyanyi lagi): buang hasil lama.
                if (tahap != Tahap.HASIL || nyanyi !== n) return@runOnUiThread
                if (hasil == null) {
                    teksProses.text = getString(R.string.karaoke_gagal_simpan)
                } else {
                    teksProses.text = ""
                    campuranCache = hasil
                    kunciCache = k
                    lanjut(hasil)
                }
            }
        }.start()
    }

    private fun tekanPutar() {
        if (putarTrek != null) {
            hentikanPutar()
            teksProses.text = ""
            return
        }
        if (sibuk) {
            toast(R.string.karaoke_sibuk)
            return
        }
        siapkan(false) { mulaiPutar(it) }
    }

    private fun mulaiPutar(pcm: ShortArray) {
        hentikanPutar()
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuf * 2, SR / 5 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            toast(R.string.gagal_putar)
            return
        }
        val saya = ++tokenPutar
        putarTrek = t
        tPutarHasil.text = getString(R.string.karaoke_henti_putar)
        teksProses.text = getString(R.string.karaoke_memutar)
        Thread {
            try {
                t.play()
                var pos = 0
                while (tokenPutar == saya && pos < pcm.size) {
                    val w = t.write(pcm, pos, min(8192, pcm.size - pos))
                    if (w < 0) break
                    pos += w
                }
                val total = pcm.size / 2
                var tunggu = 0
                while (tokenPutar == saya && tunggu++ < 300) {
                    if ((t.playbackHeadPosition.toLong() and 0xFFFFFFFFL) >= total) break
                    Thread.sleep(10)
                }
            } catch (e: Exception) {
            } finally {
                try { t.stop() } catch (e: Exception) { }
                try { t.release() } catch (e: Exception) { }
                val alami = tokenPutar == saya
                runOnUiThread {
                    if (putarTrek === t) {
                        putarTrek = null
                        if (!isDestroyed) {
                            tPutarHasil.text = getString(R.string.karaoke_putar_hasil)
                            if (alami) teksProses.text = getString(R.string.karaoke_selesai_putar)
                        }
                    }
                }
            }
        }.start()
    }

    private fun hentikanPutar() {
        tokenPutar++
        val t = putarTrek
        putarTrek = null
        if (t != null) {
            try { t.pause() } catch (e: Exception) { }
            try { t.flush() } catch (e: Exception) { }
        }
        if (::tPutarHasil.isInitialized) tPutarHasil.text = getString(R.string.karaoke_putar_hasil)
    }

    private fun simpan(vokalSaja: Boolean) {
        if (sibuk) {
            toast(R.string.karaoke_sibuk)
            return
        }
        hentikanPutar()
        siapkan(vokalSaja) { pcm -> simpanKeBerkas(pcm, vokalSaja) }
    }

    /** Hasil MP3 yang sudah jadi di cache, menunggu dipilihkan folder (hanya Android 9 ke bawah). */
    private var menungguSimpan: File? = null
    private var namaMenunggu = ""

    private fun simpanKeBerkas(pcm: ShortArray, vokalSaja: Boolean) {
        setSibuk(true)
        teksProses.text = getString(R.string.karaoke_menyimpan)
        val ctx = applicationContext
        val awalan = "Karaoke_" + (if (vokalSaja) "Vokal_" else "") + (lagu?.nama ?: "Lagu")
        Thread {
            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
            val bersih = awalan.replace(Regex("[^A-Za-z0-9_\\- ]"), "").trim().replace(' ', '_').ifEmpty { "Karaoke" }.take(60)
            val nama = "${bersih}_$stamp.mp3"
            val pcmFile = File(cacheDir, "karaoke_tmp.pcm")
            val mp3 = File(cacheDir, "karaoke_tmp.mp3")
            var uri: Uri? = null
            val galat: String? = try {
                // PCM 16 bit stereo 44,1 kHz ditulis mentah, lalu FFmpeg (libmp3lame) menyandinya ke MP3 192 kbps.
                java.io.BufferedOutputStream(java.io.FileOutputStream(pcmFile), 1 shl 16).use { o ->
                    val bb = java.nio.ByteBuffer.allocate(16_384 * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    var i = 0
                    while (i < pcm.size) {
                        val n = min(16_384, pcm.size - i)
                        bb.clear()
                        for (x in 0 until n) bb.putShort(pcm[i + x])
                        o.write(bb.array(), 0, n * 2)
                        i += n
                    }
                }
                mp3.delete()
                val sesi = FFmpegKit.executeWithArguments(
                    arrayOf(
                        "-y", "-nostdin", "-f", "s16le", "-ar", SR.toString(), "-ac", "2", "-i", pcmFile.absolutePath,
                        "-c:a", "libmp3lame", "-b:a", "192k", "-id3v2_version", "3", "-write_xing", "1",
                        "-metadata", "title=" + (lagu?.nama ?: "Karaoke"), "-metadata", "comment=Studio Karaoke AudioLab novan",
                        mp3.absolutePath
                    )
                )
                if (!ReturnCode.isSuccess(sesi.returnCode) || mp3.length() <= 0L) {
                    "FFmpeg gagal (kode ${sesi.returnCode}): " + (sesi.allLogsAsString ?: "").takeLast(200).replace('\n', ' ')
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    uri = simpanMediaStore(ctx, mp3, nama)
                    null
                } else {
                    null
                }
            } catch (e: Throwable) {
                uri?.let { try { ctx.contentResolver.delete(it, null, null) } catch (x: Exception) { } }
                uri = null
                e.message ?: "galat"
            } finally {
                try { pcmFile.delete() } catch (e: Exception) { }
            }
            runOnUiThread {
                if (isDestroyed) {
                    try { mp3.delete() } catch (e: Exception) { }
                    return@runOnUiThread
                }
                setSibuk(false)
                when {
                    galat != null -> {
                        try { mp3.delete() } catch (e: Exception) { }
                        teksProses.text = getString(R.string.karaoke_gagal_simpan) + " " + galat
                    }
                    uri != null -> {
                        try { mp3.delete() } catch (e: Exception) { }
                        uriTerakhir = uri
                        namaTerakhir = nama
                        tBagikan.visibility = View.VISIBLE
                        teksProses.text = getString(R.string.karaoke_tersimpan, nama)
                        bukaMenuHasil()
                    }
                    else -> {
                        // Android 9 ke bawah: tidak ada folder bersama otomatis, jadi pengguna memilih tempat simpan.
                        menungguSimpan = mp3
                        namaMenunggu = nama
                        teksProses.text = getString(R.string.karaoke_pilih_tempat)
                        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType("audio/mpeg")
                            .putExtra(Intent.EXTRA_TITLE, nama)
                        try {
                            startActivityForResult(i, REQ_SIMPAN)
                        } catch (e: Exception) {
                            try { mp3.delete() } catch (x: Exception) { }
                            menungguSimpan = null
                            teksProses.text = getString(R.string.karaoke_gagal_simpan)
                        }
                    }
                }
            }
        }.start()
    }

    /** Menulis MP3 ke Musik/AudioLab Novan/Karaoke lewat MediaStore (Android 10 ke atas, tanpa izin tambahan). */
    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanMediaStore(ctx: android.content.Context, src: File, nama: String): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, nama)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioLab Novan/Karaoke")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val koleksi = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = ctx.contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            ctx.contentResolver.openOutputStream(u, "w")!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            val selesai = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            ctx.contentResolver.update(u, selesai, null, null)
        } catch (e: Exception) {
            try { ctx.contentResolver.delete(u, null, null) } catch (x: Exception) { }
            throw e
        }
        return u
    }

    /** Tahap 55: dialog menu hasil (putar, jeda, lanjutkan, bagikan, ubah nama, hapus); muncul otomatis saat hasil tersimpan. */
    private fun bukaMenuHasil() {
        val u = uriTerakhir ?: return
        hentikanPutar()
        dialogHasil.saatDiubah = { h ->
            uriTerakhir = h.uri
            namaTerakhir = h.nama
            teksProses.text = getString(R.string.karaoke_tersimpan, h.nama)
        }
        dialogHasil.saatDihapus = {
            uriTerakhir = null
            tBagikan.visibility = View.GONE
            teksProses.text = "Hasil sudah dihapus."
        }
        dialogHasil.tampilkan(u, namaTerakhir.ifEmpty { "Karaoke.mp3" }, "audio/mpeg")
    }

    // ================= Daur hidup =================

    override fun onPause() {
        dialogHasil.hentikanSuara()
        batalHitung(false)
        // Perekaman mikrofon tidak boleh jalan di latar belakang: simpan dulu apa yang sudah dinyanyikan.
        if (tahap == Tahap.NYANYI && !isChangingConfigurations) selesaiNyanyi()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(denyut)
        handler.removeCallbacks(hitung)
        tokenMuat++
        tokenPutar++
        try { mesin?.berhenti() } catch (e: Exception) { }
        mesin = null
        dialogHasil.lepas()
        hentikanPutar()
        super.onDestroy()
    }
}
