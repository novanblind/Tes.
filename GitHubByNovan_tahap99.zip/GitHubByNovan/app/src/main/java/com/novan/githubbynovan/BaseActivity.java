package com.novan.githubbynovan;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;

/** Menangani izin penyimpanan (hanya perlu di Android 9 ke bawah). */
public abstract class BaseActivity extends Activity {
    private Runnable pending;

    protected void withStorage(Runnable r) {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            pending = r;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
            return;
        }
        r.run();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 77) {
            Runnable r = pending;
            pending = null;
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && r != null) {
                r.run();
            } else {
                Toast.makeText(this, "Izin penyimpanan ditolak. Berkas tidak bisa diunduh.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
